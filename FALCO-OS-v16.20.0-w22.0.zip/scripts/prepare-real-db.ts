/* ================================================================
 * scripts/prepare-real-db.ts — v16.15 W16 — preparazione DB REALE
 * ================================================================
 * L'operatore carica il DB reale dell'impianto (~292 MB, schema Prisma
 * 123 modelli dell'era v16.14) sovrascrivendo db/custom.db (vedi
 * db/LEGGO.md). Le onde W13-W16 hanno aggiunto SOLO tabelle nuove:
 *
 *   · StpObservation  (unique deviceId+portNum)  — porte STP per switch
 *   · VlanInventory   (unique deviceId+vlanId)   — VLAN dichiarate
 *
 * ArpEntry/FdbObservation/TopologyLink esistono già dal v15/v10: la
 * sonda L2 v16.15 li RIEMPIE, non li cambia. NESSUNA colonna di
 * tabelle esistenti viene toccata (migrazione puramente additiva).
 *
 * Questo script è IDEMPOTENTE e SICURO:
 *   1. backup automatico del DB (copia .bak con timestamp, WAL incluso);
 *   2. integrity check SQLite PRIMA di qualsiasi azione;
 *   3. controllo tabelle mancanti (solo le due nuove possono mancare);
 *   4. `prisma db push` SOLO se mancano tabelle (diff additivo);
 *   5. conteggi di sanità: nessuna riga persa nelle tabelle calde
 *      (Device/TopologyLink/AlertEvent/MetricValue prima e dopo);
 *   6. report onesto: ogni passo dichiarato, exit 1 al primo problema.
 *
 * Uso:  bun scripts/prepare-real-db.ts [--yes]
 *   (senza --yes stampa il piano e NON scrive nulla)
 * ================================================================ */

import { execSync } from 'node:child_process'
import { existsSync, copyFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { PrismaClient } from '@prisma/client'

/* v16.18.1: percorsi derivati dalla posizione di QUESTO file (funziona
 * identico nella sandbox Linux e su Windows, senza path assoluti hardocoded).
 * scripts/prepare-real-db.ts → root del progetto = ../ */
const PROJECT_ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..')
const DB_PATH = join(PROJECT_ROOT, 'db', 'custom.db')
const RUN = process.argv.includes('--yes')

/** Query asincrona generica sul DB in lettura (PRAGMA, sqlite_master,
 *  COUNT): client Prisma usa-e-getta per non tenere lock sul file
 *  durante il backup — nessuna dipendenza da bun:sqlite (stessi tipi
 *  del resto del progetto). */
async function q<T>(sql: string): Promise<T[]> {
  const db = new PrismaClient({ datasources: { db: { url: `file:${DB_PATH.replace(/\\/g, '/')}?connection_limit=1` } } })
  try {
    return (await db.$queryRawUnsafe<T[]>(sql)) ?? []
  } finally {
    await db.$disconnect().catch(() => {})
  }
}

function log(step: string, detail: string) {
  console.log(`[${new Date().toISOString()}] ${step} — ${detail}`)
}

function fail(step: string, detail: string): never {
  console.error(`[${new Date().toISOString()}] FALLITO ${step} — ${detail}`)
  process.exit(1)
}

/* --- 1. esistenza del file --- */
if (!existsSync(DB_PATH)) {
  fail('esistenza', `${DB_PATH} non trovato: caricare il DB reale (db/LEGGO.md) prima di eseguire lo script`)
}
const sizeMb = (statSync(DB_PATH).size / 1_000_000).toFixed(1)
log('esistenza', `db/custom.db presente (${sizeMb} MB)`)

/* --- 2. integrità PRIMA --- */
const integrityRows = await q<{ integrity_check: string }>('PRAGMA integrity_check')
if (String(integrityRows[0]?.integrity_check ?? 'unknown') !== 'ok') {
  fail('integrità', `PRAGMA integrity_check = ${JSON.stringify(integrityRows[0])}: DB corrotto o WAL non integrato (aprire/chiudere con SQLite per il checkpoint)`)
}
log('integrità', 'PRAGMA integrity_check = ok')

/* --- conteggi di sanità PRIMA --- */
const HOT_TABLES = ['Device', 'Plant', 'Location', 'TopologyLink', 'AlertEvent', 'MetricValue', 'AuditLog', 'User', 'FdbObservation', 'ArpEntry'] as const
const before = new Map<string, number>()
for (const t of HOT_TABLES) {
  try {
    const rows = await q<{ n: number | bigint }>(`SELECT COUNT(*) AS n FROM "${t}"`)
    before.set(t, Number(rows[0]?.n ?? -1))
  } catch {
    before.set(t, -1) // tabella assente: contata come anomalia SOLO se obbligatoria
  }
}

/* --- 3. tabelle v16.15 mancanti? --- */
const tableRows = await q<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table'")
const tables = new Set(tableRows.map((r) => r.name))
const NEW_TABLES = ['StpObservation', 'VlanInventory'] as const
const missing = NEW_TABLES.filter((t) => !tables.has(t))

if (missing.length === 0) {
  log('schema', 'tabelle v16.15 (StpObservation, VlanInventory) già presenti: nessuna azione necessaria')
  console.log('\nDB già pronto per FALCO-OS v16.15. Buon lavoro.')
  process.exit(0)
}

log('schema', `tabelle mancanti: ${missing.join(', ')} — serve UN push additivo (nessuna tabella esistente verrà modificata)`)
if (!RUN) {
  console.log('\nPIANO (modalità dry-run, nessuna scrittura):')
  console.log(`  1. backup di db/custom.db (${sizeMb} MB) in db/custom.db.bak-<timestamp>`)
  console.log('  2. bun run db:push (diff additivo: CREATE TABLE StpObservation/VlanInventory + indici)')
  console.log('  3. verifica conteggi tabelle calde invariati')
  console.log('\nRieseguire con: bun scripts/prepare-real-db.ts --yes')
  process.exit(0)
}

/* --- 4. backup --- */
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
const backupPath = `${DB_PATH}.bak-${stamp}`
copyFileSync(DB_PATH, backupPath)
log('backup', `copia salvata in ${backupPath}`)

/* --- 5. push additivo --- */
try {
  const out = execSync('bun run db:push 2>&1', { cwd: PROJECT_ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = out.trim().split('\n').slice(-3).join(' · ')
  log('db:push', tail || 'completato')
} catch (e) {
  fail('db:push', String(e).slice(0, 400))
}

/* --- 6. verifica DOPO --- */
const integrity2Rows = await q<{ integrity_check: string }>('PRAGMA integrity_check')
if (String(integrity2Rows[0]?.integrity_check ?? 'unknown') !== 'ok') {
  fail('integrità finale', 'il DB NON è integro dopo il push: RIPRISTINARE il backup e contattare il supporto')
}
let mismatch = 0
for (const [t, n] of before) {
  const rows = await q<{ n: number | bigint }>(`SELECT COUNT(*) AS n FROM "${t}"`)
  const now = Number(rows[0]?.n ?? -1)
  if (now !== n) {
    console.error(`  ANOMALIA: ${t} era ${n}, ora ${now}`)
    mismatch += 1
  }
}
for (const t of NEW_TABLES) {
  const rows = await q<{ name: string }>('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=?'.replace('?', `"${t}"`))
  if (rows.length === 0) {
    console.error(`  ANOMALIA: tabella ${t} ancora assente dopo il push`)
    mismatch += 1
  }
}

if (mismatch > 0) {
  fail('conteggi', `${mismatch} anomalie: RIPRISTINARE il backup (${backupPath}) e riprovare`)
}

log('verifica finale', 'integrità ok · conteggi invariati · tabelle nuove presenti')
console.log(`\nDB reale preparato per FALCO-OS v16.15 (backup: ${backupPath}).`)
console.log('Avviare/restartare i tre servizi (next :3000, realtime :3001, discovery :3002).')
