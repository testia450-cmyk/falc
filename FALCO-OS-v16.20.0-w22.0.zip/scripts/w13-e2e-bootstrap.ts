/* ================================================================
 * scripts/w13-e2e-bootstrap.ts — ambiente di test end-to-end W13/W14
 * ================================================================
 * Prepara il DB (placeholder vuoto in attesa del DB reale) per la
 * verifica browser/API della sonda L2 v16.15:
 *   · utente admin SUPER_ADMIN (password demo documentata FalcoDemo2026!,
 *     decisione D1 del worklog — SOLO per il DB di sviluppo);
 *   · impianto «test-l2» + 8 apparati che puntano ai DUE simulatori
 *     SNMP (127.0.0.1:1161 SW-CENTRALE, 127.0.0.1:1162 SW-DISTRIBUZIONE)
 *     con MAC/hostname IDENTICI a quelli dichiarati dai simulatori,
 *     così la correlazione FDB_MUTUAL/STP ha tutto ciò che serve.
 *
 * IDEMPOTENTE e REVERSIBILE: --revert rimuove SOLO ciò che ha creato
 * (l'audit è append-only e resta). NESSUN dato del DB reale viene
 * toccato (l'impianto è separato; le rotte sono per-impianto).
 * ================================================================ */

import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

const PLANT_NAME = 'test-l2'
const DEMO_PASSWORD = 'FalcoDemo2026!'

const DEVICES = [
  { hostname: 'GW-PRINCIPALE', ip: '192.168.88.1', macAddress: 'AA:BB:CC:11:22:33', type: 'GATEWAY', snmpPort: 1161 },
  { hostname: 'SW-CENTRALE', ip: '127.0.0.1', macAddress: 'CC:CC:CC:00:00:01', type: 'SWITCH', snmpPort: 1161 },
  { hostname: 'SW-DISTRIBUZIONE', ip: '127.0.0.1', macAddress: 'DC:DD:DD:00:00:02', type: 'SWITCH', snmpPort: 1162 },
  { hostname: 'CAM-1-IPCAM', ip: '192.168.88.20', macAddress: 'DE:AD:BE:EF:00:11', type: 'CAMERA', snmpPort: 161 },
  { hostname: 'CAM-2-GARDEN', ip: '192.168.88.51', macAddress: 'DE:AD:BE:EF:00:22', type: 'CAMERA', snmpPort: 161 },
  { hostname: 'AP-TETTO', ip: '192.168.88.52', macAddress: 'DE:AD:BE:EF:00:33', type: 'AP', snmpPort: 161 },
  { hostname: 'SRV-UTILITY', ip: '192.168.88.50', macAddress: 'DE:AD:BE:EF:00:44', type: 'SERVER', snmpPort: 161 },
  { hostname: 'NVR-SCALA', ip: '192.168.88.10', macAddress: 'EE:EE:EE:99:00:01', type: 'NVR', snmpPort: 161 },
  { hostname: 'CAM-3-CORTILE', ip: '192.168.88.10', macAddress: 'EE:EE:EE:00:00:0A', type: 'CAMERA', snmpPort: 161 },
  { hostname: 'AP-MAGAZZINO', ip: '192.168.88.11', macAddress: 'EE:EE:EE:00:00:0B', type: 'AP', snmpPort: 161 },
]

async function main() {
  const revert = process.argv.includes('--revert')

  if (revert) {
    // REVERT: rimuove l'inventario di test (link prima, poi dispositivi,
    // poi osservazioni ARP/STP/VLAN/FDB del plant, poi il plant).
    const plant = await db.plant.findFirst({ where: { name: PLANT_NAME } })
    if (plant) {
      await db.topologyLink.deleteMany({ where: { plantId: plant.id } })
      await db.fdbObservation.deleteMany({ where: { plantId: plant.id } })
      await db.stpObservation.deleteMany({ where: { plantId: plant.id } })
      await db.vlanInventory.deleteMany({ where: { plantId: plant.id } })
      await db.arpEntry.deleteMany({ where: { plantId: plant.id } })
      const ids = await db.device.findMany({ where: { plantId: plant.id }, select: { id: true } })
      await db.device.deleteMany({ where: { plantId: plant.id } })
      await db.plant.delete({ where: { id: plant.id } }).catch(() => {})
      console.log(`REVERT: impianto test-l2 rimosso (${ids.length} dispositivi)`)
    } else {
      console.log('REVERT: impianto test-l2 assente (già pulito)')
    }
    const admin = await db.user.findFirst({ where: { email: 'admin@falco-os.local' } })
    if (admin && admin.passwordHash === '$2a$10$' + admin.passwordHash.slice(10)) {
      // non rimuoviamo l'admin: serve al login della verifica (documentato)
      console.log('REVERT: utente admin conservato (serve al login)')
    }
    return
  }

  // (1) admin SUPER_ADMIN se assente (password demo D1)
  const existing = await db.user.findFirst({ where: { email: 'admin@falco-os.local' } })
  if (!existing) {
    await db.user.create({
      data: {
        name: 'Amministratore',
        email: 'admin@falco-os.local',
        passwordHash: bcrypt.hashSync(DEMO_PASSWORD, 10),
        role: 'SUPER_ADMIN',
      },
    })
    console.log('utente admin creato (admin@falco-os.local / ' + DEMO_PASSWORD + ')')
  } else {
    console.log('utente admin già presente')
  }

  // (2) impianto di test
  let plant = await db.plant.findFirst({ where: { name: PLANT_NAME } })
  if (!plant) {
    plant = await db.plant.create({
      data: { name: PLANT_NAME, comune: 'Sandbox', notes: 'impianto di verifica W13/W14 — eliminabile' },
    })
    console.log('impianto test-l2 creato')
  }

  // (3) apparati (idempotente per hostname)
  for (const d of DEVICES) {
    const found = await db.device.findFirst({ where: { plantId: plant.id, hostname: d.hostname } })
    if (!found) {
      await db.device.create({
        data: {
          plantId: plant.id,
          hostname: d.hostname,
          ip: d.ip,
          macAddress: d.macAddress,
          type: d.type,
          snmpPort: d.snmpPort,
          snmpCommunity: 'public',
        },
      })
      console.log('  +', d.hostname, d.type)
    }
  }
  const count = await db.device.count({ where: { plantId: plant.id } })
  console.log(`impianto test-l2 pronto: ${count} dispositivi`)
}

main()
  .catch((e) => { console.error('ERRORE:', e); process.exit(1) })
  .finally(() => db.$disconnect())
