#!/usr/bin/env node
/* ================================================================
 * FALCO-OS v16.18.1 — post-build cross-platform
 * Sostituisce i «cp -r» Unix dello script "build" (cmd.exe di Windows
 * non ha cp; PowerShell li tradurrebbe ma la shell degli script npm/bun
 * su Windows resta cmd). Copia .next/static e public dentro
 * .next/standalone come richiesto dal deployment standalone di Next 16.
 * Compatible Node ≥16.7 e Bun (fs.cpSync).
 * ================================================================ */
import { cpSync, existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

const root = process.cwd()
const standalone = join(root, '.next', 'standalone')

if (!existsSync(standalone)) {
  console.error('[postbuild] .next/standalone assente: eseguire prima «next build» (output: standalone in next.config.ts)')
  process.exit(1)
}

mkdirSync(join(standalone, '.next'), { recursive: true })
cpSync(join(root, '.next', 'static'), join(standalone, '.next', 'static'), { recursive: true })
cpSync(join(root, 'public'), join(standalone, 'public'), { recursive: true })

console.log('[postbuild] .next/static  → .next/standalone/.next/static OK')
console.log('[postbuild] public        → .next/standalone/public OK')
