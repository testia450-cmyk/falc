/* ================================================================
 * CORREZIONE TOPOLOGIA EGIDIO — dati REALI dell'operatore (W11)
 *
 * Fonti (upload/):
 *   · «Sant Egidio Monte Albino.xlsx» → inventario reale (Rete Nuova):
 *     sedi, apparati con IP/nome/SSID/credenziali/seriali;
 *   · «Sant Egidio Monte Albino.kmz» → mappa reale: punti GPS delle
 *     sedi + PERCORSI «Linea N» (polilinee multi-hop: le coppie di
 *     waypoint consecutivi sono i collegamenti fisici sede↔sede).
 *
 * Cosa corregge (richiesta: «questo è quello reale di come è la rete,
 * non come lo hai disegnata tu»):
 *   1. dispositivi riconciliati per IP: hostname reali (fine dei
 *      DEV-19.150-x da scansione), tipi corretti, SSID, credenziali
 *      cifrate, sede dalla sezione Excel;
 *   2. topologia: gli 892 collegamenti auto-scoperti (LLDP/MNDP/UISP/
 *      FDB/BRIDGE_MIB — hub sbagliati tipo «ST Scuola» con 171 link)
 *      vengono SOSTITUITI dalla rete reale:
 *        · link radio dai gruppi SSID (Comune↔P8, P3↔P4,
 *          P10↔{P11,P12,Pulcinella}, AP01Comune PTMP, …);
 *        · LAN di sede (radio hub → SW POE → telecamere): tutti i
 *          dispositivi entrano nell'albero della raggiera;
 *        · basestation sintetica «Stadio» @ RIP Stadio (fuori
 *          inventario Excel) con le sue 2 stazioni;
 *        · link da percorsi KMZ dove l'Excel non copre:
 *          RIP1↔Comune (Linea 23), PA9↔RIP Stadio (Linea 17);
 *        · FIBRA Comando→Via Califano («(Fibra) Fuori Comando»):
 *          chiude l'albero dalla radice Router SETI;
 *   3. radice topologica = Router SETI (Comando PL);
 *   4. centro mappa dell'impianto dall'estensione reale dei punti KMZ.
 *
 * Idempotente: rilanciabile (riconcilia, i link duplicati saltano).
 * ================================================================ */

import { readFileSync } from 'fs'
import { db } from '../src/lib/db'
import { parseSetiXlsx } from '../src/lib/domain/xlsx-parser'
import { planXlsxImport } from '../src/lib/domain/xlsx-import-plan'
import { applyXlsxImport } from '../src/lib/domain/xlsx-apply'
import { deriveKmzGapLinks } from '../src/lib/domain/kmz-gap-links'
import { parsePointsFileFull } from '../src/lib/domain/kmz-parser'
import type { Prisma } from '@prisma/client'

const XLSX_PATH = '/home/z/my-project/upload/Sant Egidio Monte Albino.xlsx'
const KMZ_PATH = '/home/z/my-project/upload/Sant Egidio Monte Albino.kmz'

/** Abbinamenti manuali sezione-Excel → sede esistente (sinonimi
 *  dell'operatore che il fuzzy non può indovinare). */
const MANUAL_LOCATION_MAP: Record<string, string> = {
  'Comando PL': 'Polizia Municipale', // il Comando della Polizia Locale È la sede «Polizia Municipale»
  'P.A 7 Via Giacomo Leopardi 2 tlc': 'P.A 7 Via Giovanni Falcone', // stessa sede PA7, strada rinominata nel KMZ
}

async function main() {
  const plant = await db.plant.findFirst({ where: { name: { contains: 'egidio' } } })
  if (!plant) throw new Error('impianto egidio non trovato')

  /* ---- parse delle fonti reali ---- */
  const xlsxBuf = readFileSync(XLSX_PATH)
  const summary = parseSetiXlsx(xlsxBuf, 'Sant Egidio Monte Albino.xlsx')
  console.log(`XLSX: foglio «${summary.sheetName}» (${summary.network}) — ${summary.sections.length} sezioni, ${summary.sections.reduce((a, s) => a + s.devices.length, 0)} apparati`)

  const kmzBuf = readFileSync(KMZ_PATH)
  const { placemarks, polylines } = await parsePointsFileFull(kmzBuf, 'Sant Egidio Monte Albino.kmz')
  console.log(`KMZ: ${placemarks.length} punti, ${polylines.length} percorsi «Linea»`)

  /* ---- piano di import (riconciliazione, NESSUNA scrittura) ---- */
  const locations = await db.location.findMany({
    where: { plantId: plant.id },
    select: { id: true, name: true, identifier: true },
  })
  const devices = await db.device.findMany({
    where: { plantId: plant.id },
    select: { id: true, ip: true, hostname: true, type: true, ssid: true, locationId: true },
  })

  const manualByIndex: Record<number, string> = {}
  for (const [sectionName, locationName] of Object.entries(MANUAL_LOCATION_MAP)) {
    const section = summary.sections.find((s) => s.name === sectionName)
    const loc = locations.find((l) => l.name === locationName)
    if (section && loc) {
      manualByIndex[section.index] = loc.id
      console.log(`mappa manuale: sezione «${sectionName}» → sede «${locationName}»`)
    }
  }

  const autoLinkCount = await db.topologyLink.count({
    where: { plantId: plant.id, sourceOfTruth: { not: 'TECHNICIAN' } },
  })

  const plan = planXlsxImport(summary, locations, devices, autoLinkCount, {
    manualLocationMap: manualByIndex,
  })

  console.log('\n=== PIANO ===')
  console.log(`sedi: ${plan.stats.locationsCreate} create, ${plan.stats.locationsMap} abbinate`)
  console.log(`dispositivi: ${plan.stats.devicesCreate} nuovi, ${plan.stats.devicesUpdate} aggiornati`)
  console.log(`link SSID: ${plan.stats.links} · sintetiche: ${plan.stats.synthetic}`)
  console.log(`link auto-scoperti attuali: ${plan.autoLinkCount}`)
  console.log(`dispositivi DB fuori Excel: ${plan.unmatchedExisting.length}`)
  console.log(`SSID solitari: ${plan.lonelySsids.map((l) => l.ssid).join(', ') || '-'}`)

  console.log('\n=== SEZIONI → SEDE ===')
  for (const s of plan.sections) {
    const flag = s.action === 'MAP' ? `→ ${s.locationName} [${s.confidence}] ${s.reason}` : `→ CREAZIONE (${s.reason})`
    console.log(`  ${s.sectionName.padEnd(50)} ${flag}`)
  }

  console.log('\n=== LINK SSID ===')
  for (const l of plan.links) {
    console.log(`  ${l.ssid.padEnd(22)} ${l.sourceSection.slice(0, 22).padEnd(24)} → ${l.targetSection.slice(0, 30)} ${l.frequency}`)
  }

  for (const s of plan.synthetic) {
    console.log(`\nSINTETICA: ${s.name} → ${s.locationName ?? 'da scegliere'} (${s.locationBasis})`)
    console.log(`  stazioni: ${s.stations.map((st) => `${st.name}@${st.section}`).join(' | ')}`)
  }

  /* ---- basestation sintetiche → RIP Stadio (il ripetitore) ---- */
  const ripStadio = locations.find((l) => /rip\s*stadio/i.test(l.name))
  const syntheticConfirms = ripStadio
    ? plan.synthetic.map((_, i) => ({ index: i, locationId: ripStadio.id }))
    : []

  /* ---- ESECUZIONE (transazione unica) ---- */
  console.log('\n=== APPLICAZIONE ===')
  const result = await db.$transaction(async (tx) => {
    const wiped = await tx.topologyLink.deleteMany({ where: { plantId: plant.id } })
    console.log(`link esistenti rimossi (pulizia completa): ${wiped.count}`)

    const counts = await applyXlsxImport(summary, plan, {
      plantId: plant.id,
      sections: plan.sections.map((s) => ({
        sectionIndex: s.sectionIndex,
        locationId: s.locationId,
      })),
      createLinks: true,
      createLanLinks: true,
      synthetic: syntheticConfirms,
      purgeAutoLinks: false, // già eliminati sopra
      actor: 'fix-egidio-topology',
    }, tx)

    /* ---- link dai PERCORSI KMZ (buchi dell'Excel) ---- */
    const gap = await deriveKmzGapLinks(tx, plant.id, polylines)
    counts.linksCreated += gap

    /* ---- radice topologica: Router SETI ---- */
    const router = await tx.device.findFirst({
      where: { plantId: plant.id, ip: '172.19.150.1' },
      select: { id: true, hostname: true },
    })
    if (router) {
      await tx.plant.update({ where: { id: plant.id }, data: { topologyRootDeviceId: router.id } })
      console.log(`radice topologica: ${router.hostname}`)
    }

    /* ---- centro mappa reale ---- */
    const lats = placemarks.map((p) => p.lat)
    const lngs = placemarks.map((p) => p.lng)
    if (lats.length > 0) {
      const cLat = Number(((Math.min(...lats) + Math.max(...lats)) / 2).toFixed(6))
      const cLng = Number(((Math.min(...lngs) + Math.max(...lngs)) / 2).toFixed(6))
      await tx.plant.update({
        where: { id: plant.id },
        data: { mapCenterLat: cLat, mapCenterLng: cLng, mapZoom: 15 },
      })
      console.log(`centro mappa: ${cLat}, ${cLng} (zoom 15)`)
    }

    await tx.auditLog.create({
      data: {
        action: 'DEVICE_IMPORT_XLSX',
        actor: 'fix-egidio-topology',
        targetId: plant.id,
        targetLabel: plant.name,
        plantId: plant.id,
        details: JSON.stringify({
          source: 'Sant Egidio Monte Albino.xlsx + .kmz (upload operatore)',
          ...counts,
          wipedLinks: wiped.count,
        }),
      },
    })

    /* ---- artefatti di scansione fuori rete: dismissione ----
     * Solo dispositivi GIÀ NEL DB prima dell'import (piano.unmatched)
     * con IP FUORI dalla rete dell'Excel (192.168.1.x = resto di una
     * scansione vecchia). I dispositivi in-subnet fuori Excel restano
     * attivi (decide l'operatore). La dismissione è reversibile. */
    if (summary.network) {
      const netBase = summary.network.split('/')[0]
      const prefix = netBase.split('.').slice(0, 2).join('.')
      const junkIps = plan.unmatchedExisting
        .filter((u) => !u.ip.startsWith(prefix))
        .map((u) => u.ip)
      if (junkIps.length > 0) {
        await tx.device.updateMany({
          where: { plantId: plant.id, ip: { in: junkIps }, decommissionedAt: null },
          data: {
            decommissionedAt: new Date(),
            decommissionReason: `Fuori rete ${summary.network}: artefatto di scansione (correzione topologia ${new Date().toISOString().slice(0, 10)})`,
          },
        })
        console.log(`dispositivi fuori rete dismessi: ${junkIps.join(', ')}`)
      }
      // ripara la basestation sintetica se un giro precedente l'ha dismessa
      await tx.device.updateMany({
        where: { plantId: plant.id, ip: '0.0.0.0', decommissionedAt: { not: null } },
        data: { decommissionedAt: null, decommissionReason: '' },
      })
    }

    return counts
  })

  console.log('\n=== RISULTATO ===')
  console.log(JSON.stringify(result, null, 2))

  /* ---- verifica finale ---- */
  const finalLinks = await db.topologyLink.count({ where: { plantId: plant.id } })
  const finalDevices = await db.device.findMany({
    where: { plantId: plant.id },
    select: { hostname: true, locationId: true },
  })
  const orphans = finalDevices.filter((d) => !d.locationId).length
  const devJunk = finalDevices.filter((d) => /^DEV-19\./.test(d.hostname)).length
  console.log(`\nVERIFICA: link finali ${finalLinks}, dispositivi ${finalDevices.length}, senza sede ${orphans}, hostname DEV- residui ${devJunk}`)
}



main()
  .catch((e) => {
    console.error('ERRORE:', e)
    process.exitCode = 1
  })
  .finally(() => db.$disconnect())
