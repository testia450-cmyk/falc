/* ================================================================
 * scripts/w21-gen-demo-assets.ts — asset per il wizard Setup Impianto
 * ================================================================
 * Genera i file di test per la verifica E2E del wizard «Setup impianto»:
 *   · demo-assets/w21-impianto.xlsx — Excel «formato SETI»: 2 sezioni
 *     (sedi) e 8 apparati dichiarati (la «rete ipotetica» dell'operatore),
 *     con credenziali admin/simpass per gli apparati gestiti;
 *   · demo-assets/w21-sedi.kmz     — KMZ (doc.kml zippato) con 2
 *     placemark = le 2 sedi con coordinate reali (area di Verona).
 *
 * Gli apparati dichiarati puntano ai simulatori del wizard (W21):
 *   127.0.0.2 SW-CENTRALE        (SNMP :16111 scenario centrale  + SSH :2222)
 *   127.0.0.3 SW-DISTRIBUZIONE   (SNMP :16111 scenario distribuzione + SSH :2223)
 *   127.0.0.4 PTP Antenna Tetto  (SNMP :16111 scenario radio       + SSH :2224)
 *   127.0.0.5 TLC ONT Municipio  (HTTP :8081 banner Alcatel-Lucent)
 *   127.0.0.9 TLC ONT Scuola     (NESSUN servizio: mancato all'appello onesto)
 *   192.168.88.1/.10/.20         (rete «reale» fuori dal CIDR del demo:
 *                                 GW-PRINCIPALE, NVR-SCALA, CAM-1-IPCAM —
 *                                 linkabili via LLDP/CDP dalla sonda L2)
 * Uso: bun scripts/w21-gen-demo-assets.ts [--clean]
 * ================================================================ */

import * as XLSX from 'xlsx'
import JSZip from 'jszip'
import { mkdirSync, rmSync, existsSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const DIR = join(process.cwd(), 'demo-assets')

async function main() {
  if (process.argv.includes('--clean')) {
    if (existsSync(DIR)) rmSync(DIR, { recursive: true })
    console.log('demo-assets rimossa')
    return
  }
  mkdirSync(DIR, { recursive: true })

  /* ---------------- Excel «formato SETI» ----------------
   * Struttura REALE del formato (xlsx-parser): colonna A = IP, B = nome
   * (sezione = riga senza IP con nome in B), C = SSID/WAN, D = utente,
   * E = password, F = seriale. I nomi di sede iniziano con «P.A n»
   * (pattern riconosciuto come sede, non come apparato). */
  const rows: Array<Array<string | number>> = [
    // metadati di rete: «Rete | 127.0.0.0/29» (label in B, CIDR in C)
    ['', 'Rete', '127.0.0.0/29', '', '', ''],
    [],
    // SEZIONE 1 = sede (nome in colonna B, riga senza IP)
    ['', 'P.A 1 - Sala Tecnica Comunale', '', '', '', ''],
    ['127.0.0.2', 'SW-CENTRALE', '', 'admin', 'simpass', ''],
    ['127.0.0.3', 'SW-DISTRIBUZIONE', '', 'admin', 'simpass', ''],
    ['127.0.0.4', 'PTP Antenna Tetto', 'FALCO-VERONA-PTP', 'admin', 'simpass', ''],
    ['192.168.88.1', 'Router GW-PRINCIPALE', '172.150.150.1', 'admin', 'simpass', ''],
    ['192.168.88.10', 'NVR-SCALA', '', 'admin', 'simpass', 'DS-7616NI-K2'],
    ['192.168.88.20', 'CAM-1-IPCAM', '', 'admin', 'simpass', 'DS-2CD2143G2'],
    [],
    // SEZIONE 2 = sede
    ['', 'P.A 2 - Municipio Uffici', '', '', '', ''],
    ['127.0.0.5', 'TLC ONT Municipio', '', '', '', ''],
    ['127.0.0.9', 'TLC ONT Scuola', '', '', '', ''],
  ]
  const ws = XLSX.utils.aoa_to_sheet(rows)
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'rete')
  const xlsxBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer
  const xlsxPath = join(DIR, 'w21-impianto.xlsx')
  writeFileSync(xlsxPath, xlsxBuffer)
  console.log(`scritto ${xlsxPath} (${xlsxBuffer.length} byte, ${rows.length} righe)`)

  /* ---------------- KMZ (doc.kml zippato) ----------------
   * I placemark hanno gli STESSI nomi delle sezioni Excel: l'import
   * non crea sedi doppie, aggiorna le coordinate di quelle esistenti. */
  const kml = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>Verona Sud — sedi</name>
    <Placemark>
      <name>P.A 1 - Sala Tecnica Comunale</name>
      <Point><coordinates>10.991600,45.438400,0</coordinates></Point>
    </Placemark>
    <Placemark>
      <name>P.A 2 - Municipio Uffici</name>
      <Point><coordinates>10.987600,45.439800,0</coordinates></Point>
    </Placemark>
  </Document>
</kml>`
  const zip = new JSZip()
  zip.file('doc.kml', kml)
  const kmzBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' })
  const kmzPath = join(DIR, 'w21-sedi.kmz')
  writeFileSync(kmzPath, kmzBuffer)
  console.log(`scritto ${kmzPath} (${kmzBuffer.length} byte, 2 placemark)`)
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
