/* Backup del DB reale (db + wal + shm, come da runbook incidenti) — W10 */
import { PrismaClient } from '@prisma/client'
import { copyFileSync, statSync, existsSync } from 'node:fs'
const db = new PrismaClient()
async function main() {
  const cnt = await db.device.count()
  for (const f of ['db/custom.db', 'db/custom.db-wal', 'db/custom.db-shm']) {
    if (existsSync(f)) copyFileSync(f, '/tmp/db-save-w10/' + f.split('/').pop())
  }
  console.log('devices:', cnt, '| backup files:', statSync('/tmp/db-save-w10/custom.db').size, 'bytes (+wal/shm se presenti)')
}
main().catch(e => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
