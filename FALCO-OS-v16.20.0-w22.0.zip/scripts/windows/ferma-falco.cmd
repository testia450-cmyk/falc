@echo off
REM ================================================================
REM FALCO-OS v16.18.1 — fermo dei servizi su Windows
REM Termina i processi in ascolto sulle porte 3000/3001/3002 (NOC,
REM realtime, discovery). Cerca i PID con netstat e li chiude.
REM Se una porta e gia libera, il messaggio di errore di taskkill
REM e innocuo e si puo ignorare.
REM ================================================================
echo Fermo FALCO-OS (porte 3000 / 3001 / 3002)...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr "LISTENING" ^| findstr ":3000 :3001 :3002"') do (
  echo   PID %%a
  taskkill /PID %%a /F >nul 2>&1
)
echo Fatto. (I messaggi «non trovato» sono normali se un servizio era gia spento.)
pause
