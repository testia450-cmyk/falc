@echo off
REM ================================================================
REM FALCO-OS v16.18.1 — avvio completo su Windows (sviluppo)
REM Apre 3 finestre: NOC (:3000), realtime (:3001), discovery (:3002).
REM Richiede bun nel PATH. Da eseguire con doppio clic o da terminale
REM (il file si trova in scripts\windows\, risale da solo alla root).
REM ================================================================
setlocal
set ROOT=%~dp0..\..

start "FALCO-OS - NOC :3000" cmd /k "cd /d %ROOT% && bun run dev:win"
start "FALCO-OS - realtime :3001" cmd /k "cd /d %ROOT%\mini-services\realtime-service && bun run dev"
start "FALCO-OS - discovery :3002" cmd /k "cd /d %ROOT%\mini-services\discovery-service && bun run dev"

echo.
echo FALCO-OS avviato in 3 finestre:
echo   NOC        http://localhost:3000   (admin@falco-os.local / FalcoDemo2026!)
echo   realtime   porta 3001 (canale live, interno)
echo   discovery  porta 3002 (sonde di rete, interno)
echo.
echo Per fermare: chiudere le 3 finestre oppure scripts\windows\ferma-falco.cmd
endlocal
