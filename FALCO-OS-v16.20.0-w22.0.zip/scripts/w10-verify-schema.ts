/* W10 — verifica post-push: integrità, plantId NOT NULL con FK, conteggi */
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
async function main() {
  const ic = await db.$queryRawUnsafe<Array<{ integrity_check: string }>>('SELECT integrity_check FROM pragma_integrity_check')
  const infoAll = await db.$queryRawUnsafe<Array<Record<string, unknown>>>("SELECT * FROM pragma_table_info('Device')")
  const info = infoAll.filter((c) => c.name === 'plantId') as Array<{ name: string; notnull: number }>
  const fk = await db.$queryRawUnsafe<Array<{ table: string; from: string; to: string }>>("SELECT * FROM pragma_foreign_key_list('Device')")
  const cnt = await db.device.count()
  const dist = await db.device.groupBy({ by: ['plantId'], _count: { _all: true } })
  const alerts = await db.alertEvent.count()
  const links = await db.topologyLink.count()
  console.log('integrity:', ic[0]?.integrity_check)
  console.log('Device.plantId notnull:', info[0]?.notnull, '(1 = NOT NULL)')
  console.log('FK di Device verso Plant:', JSON.stringify(fk.filter((f) => f.table === "Plant" && f.from === "plantId"), (_k, v) => (typeof v === "bigint" ? Number(v) : v)))
  console.log('devices:', cnt, '| per plant:', JSON.stringify(dist))
  console.log('alertEvents:', alerts, '| topologyLinks:', links)
  const orphan = await db.$queryRawUnsafe<Array<{ n: number | bigint }>>('SELECT count(*) AS n FROM "Device" d LEFT JOIN "Plant" p ON p."id" = d."plantId" WHERE p."id" IS NULL')
  console.log('Device con plantId orfano:', orphan[0]?.n)
}
main().catch((e) => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
