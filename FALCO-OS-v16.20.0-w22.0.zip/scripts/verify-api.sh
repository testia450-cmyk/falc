#!/bin/bash
# verify-api.sh — Verifica sistematica delle 44+ route /api/v2/* di FALCO-OS v16
# Login NextAuth reale + GET su tutte le route + envelope check.
BASE=http://localhost:3000
JAR=/home/z/my-project/scripts/.verify-cookies.txt
OUT=/home/z/my-project/scripts/.verify-out.json
rm -f "$JAR" "$OUT"

echo "=== 1. LOGIN (NextAuth credentials) ==="
CSRF=$(curl -s -c "$JAR" "$BASE/api/auth/csrf" | python3 -c "import sys,json;print(json.load(sys.stdin)['csrfToken'])")
LOGIN_CODE=$(curl -s -b "$JAR" -c "$JAR" -X POST "$BASE/api/auth/callback/credentials" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data-urlencode "email=admin@falco-os.local" \
  --data-urlencode "password=FalcoDemo2026!" \
  --data-urlencode "csrfToken=$CSRF" \
  --data-urlencode "json=true" \
  -o /dev/null -w "%{http_code}")
echo "login HTTP $LOGIN_CODE"
SESSION=$(curl -s -b "$JAR" "$BASE/api/auth/session" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('user',{}).get('email','NO-SESSION'))")
echo "session: $SESSION"

# id dispositivo reale per overview
DEV_ID=$(curl -s -b "$JAR" "$BASE/api/v2/devices?page=1&pageSize=10" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];print(d['items'][0]['id'])")
echo "device campione: $DEV_ID"

check() {
  local METHOD=$1; local PATH_Q=$2; local EXPECT=$3; local LABEL=$4
  local CODE=$(curl -s -b "$JAR" -X "$METHOD" -o "$OUT" -w "%{http_code}" "$BASE$PATH_Q")
  local OK=$(python3 -c "import json;d=json.load(open('$OUT'));print('ok='+str(d.get('ok'))+' asOf='+str(d.get('asOf'))+' mode='+str(d.get('mode')))" 2>/dev/null || echo "no-envelope")
  local VERDICT="OK"
  [ "$CODE" != "$EXPECT" ] && VERDICT="FAIL (atteso $EXPECT)"
  printf "%-4s %-28s → HTTP %-3s %-40s %s\n" "$METHOD" "$LABEL" "$CODE" "$OK" "$VERDICT"
}

echo ""
echo "=== 2. ROUTE GET (22) ==="
check GET "/api/v2/system/health" 200 "system/health"
check GET "/api/v2/noc/summary" 200 "noc/summary"
check GET "/api/v2/devices?page=1&pageSize=10" 200 "devices"
check GET "/api/v2/devices/$DEV_ID/overview" 200 "devices/[id]/overview"
check GET "/api/v2/topology/graph" 200 "topology/graph"
check GET "/api/v2/links/weak?limit=5" 200 "links/weak"
check GET "/api/v2/events?limit=5" 200 "events"
check GET "/api/v2/alarms" 200 "alarms"
check GET "/api/v2/cameras" 200 "cameras"
check GET "/api/v2/traffic/series?hours=24" 200 "traffic/series"
check GET "/api/v2/search?q=sw" 200 "search"
check GET "/api/v2/plants" 200 "plants"
check GET "/api/v2/locations" 200 "locations"
check GET "/api/v2/tickets?page=1&pageSize=10" 200 "tickets"
check GET "/api/v2/maintenance" 200 "maintenance"
check GET "/api/v2/audit?limit=5" 200 "audit"
check GET "/api/v2/admin/stats" 200 "admin/stats"
check GET "/api/v2/discovery/health" 200 "discovery/health (16.6)"
check GET "/api/v2/adozione" 200 "adozione coda (16.6)"
check GET "/api/v2/discovery/oui?mac=40:7A:A4:69:F3:BD" 200 "discovery/oui MAC Dahua (16.6)"
check GET "/api/v2/event-policies" 200 "event-policies (16.7)"
check GET "/api/v2/custom-oids" 200 "custom-oids (16.7)"
check GET "/api/v2/config-requests" 200 "config-requests (16.7)"
check GET "/api/v2/bulk-config" 200 "bulk-config (16.7)"
check GET "/api/v2/firmware" 200 "firmware (16.7)"
check GET "/api/v2/playbooks" 200 "playbooks (16.7)"
check GET "/api/v2/automation-tasks" 200 "automation-tasks (16.7)"
check GET "/api/v2/integrations" 200 "integrations (16.7 W7)"
check GET "/api/v2/integrations/webhooks" 200 "webhooks (16.7 W7)"
check GET "/api/v2/cameras/streams?pageSize=10" 200 "cameras/streams"
check GET "/api/v2/device-groups" 200 "device-groups"
check GET "/api/v2/reports/availability?windowHours=48" 200 "reports/availability"
check GET "/api/v2/mac-inventory?pageSize=25" 200 "mac-inventory"
WH=$(curl -s -b "$JAR" "$BASE/api/v2/cameras/streams?pageSize=10" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];print('windowHours='+str(d.get('windowHours'))+' total='+str(d.get('total')))")
echo "cameras/streams: $WH (finestra realmente analizzata, dichiarata nel payload)"
AV=$(curl -s -b "$JAR" "$BASE/api/v2/reports/availability?windowHours=48" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];import datetime;ct=d.get('coverageTo');print('total='+str(d.get('total'))+' conCampioni='+str(sum(1 for r in d['items'] if r['lossSamples']>0))+' coverageTo='+(datetime.datetime.fromtimestamp(ct/1000,datetime.timezone.utc).strftime('%d/%m %H:%M') if ct else 'null'))")
echo "reports/availability: $AV (copertura reale dichiarata nel payload)"
# v16.16 W17-b — raggruppamento per sede: contratto + coerenza dei contatori
curl -s -b "$JAR" "$BASE/api/v2/reports/availability?windowHours=48" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
bl = d.get('byLocation')
assert isinstance(bl, list), 'byLocation mancante nella risposta'
tot = 0
for g in bl:
    for k in ['locationId','locationName','devices','withData','withoutData','availabilityAvgPct','availabilityMinPct','worstHostname','lossSamples','coverageFrom','coverageTo']:
        assert k in g, f'manca byLocation.{k}'
    assert g['devices'] == g['withData'] + g['withoutData'], 'contatori sede incoerenti'
    tot += g['devices']
assert tot == d['total'], f'somma sedi {tot} != total {d[\"total\"]}: il raggruppamento perde righe'
assert bl[-1]['locationId'] is None or all(g['locationId'] is not None for g in bl), '«senza sede» deve stare ultima'
print(f\"  byLocation: {len(bl)} gruppi · {tot} apparati = total · peggiore prima, senza sede ultima\")
"
echo "reports/availability byLocation: contratto W17-b verificato"
MI=$(curl -s -b "$JAR" "$BASE/api/v2/mac-inventory?pageSize=25" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];s=d['summary'];print('total='+str(d.get('total'))+' resolved='+str(s.get('resolvedCount'))+' unresolved='+str(s.get('unresolvedCount'))+' switches='+str(len(d.get('switches',[])))+' lastSeenMax='+str(s.get('lastSeenMax')))" 2>/dev/null)
echo "mac-inventory: $MI (osservazioni FDB reali × inventario, 3.307 attese)"

# --- Tab «Porte» (16.5.0): switch REALE con osservazioni FDB ---
# Prende gli id dalla API devices?type=SWITCH e usa il primo switch con FDB.
SWITCH_IDS=$(curl -s -b "$JAR" "$BASE/api/v2/devices?type=SWITCH&pageSize=200" | python3 -c "import sys,json;print(' '.join(d['id'] for d in json.load(sys.stdin)['data']['items']))")
PORTS_SW=""
for sid in $SWITCH_IDS; do
  CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/devices/$sid/ports")
  NUMS=$(python3 -c "import json;d=json.load(open('$OUT'))['data'];s=d['summary'];print(str(s['totalPorts'])+' '+str(s['macsTotal'])+' '+str(s['resolvedCount']))" 2>/dev/null)
  if [ -n "$NUMS" ] && [ "$(echo "$NUMS" | cut -d' ' -f2)" != "0" ]; then
    PORTS_SW=$sid
    printf "%-4s %-28s → HTTP %-3s porte=%-3s macsTotal=%-5s resolvedCount=%-5s %s\n" "GET" "devices/[switch]/ports" "$CODE" "$(echo "$NUMS" | cut -d' ' -f1)" "$(echo "$NUMS" | cut -d' ' -f2)" "$(echo "$NUMS" | cut -d' ' -f3)" "OK"
    break
  fi
done
if [ -z "$PORTS_SW" ]; then
  echo "ATTENZIONE: nessun switch con osservazioni FDB trovato (attese 3.307 righe su 20 apparati)"
fi

echo ""
echo "=== 3. MUTAZIONI sicure (validazione contratto, nessuna modifica al DB) ==="
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/tickets")
echo "POST tickets body vuoto → HTTP $CODE (atteso 422 validazione zod)"
CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{"status":"IN_PROGRESS"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/tickets/non-esiste")
echo "PATCH tickets id inesistente → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"note":"verifica"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/alarms/non-esiste/ack")
echo "POST ack id inesistente → HTTP $CODE (atteso 404)"

echo ""
echo "=== 3b. CICLO MANUTENZIONE (16.2: POST → PATCH pausa → ripresa → DELETE) ==="
POST_CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
  -d '{"name":"[verifica] Finestra temporanea","description":"creata da verify-api.sh, rimossa a fine verifica","type":"WITH_DATA","scheduleType":"DAILY","startTime":"03:00","endTime":"04:00"}' \
  -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance")
MW_ID=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['id'] if d.get('ok') else '')" 2>/dev/null)
echo "POST creazione → HTTP $POST_CODE (atteso 201)"
if [ -n "$MW_ID" ]; then
  echo "creata finestra $MW_ID"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{"state":"PAUSED"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
  ST=$(python3 -c "import json;d=json.load(open('$OUT'))['data'];print(d['state'],d['name'])" 2>/dev/null)
  echo "PATCH PAUSED → HTTP $CODE ($ST)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{"state":"PAUSED"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
  echo "PATCH PAUSED di nuovo (identico) → HTTP $CODE (atteso 422 INVALID_TRANSITION)"
  CODE=$(curl -s -b "$JAR" -X DELETE -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
  echo "DELETE → HTTP $CODE (atteso 200, id=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['id'])" 2>/dev/null))"
  CODE=$(curl -s -b "$JAR" -X DELETE -o /dev/null -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
  echo "DELETE di nuovo → HTTP $CODE (atteso 404)"
else
  echo "POST manutenzione FALLITO: $(head -c 300 "$OUT")"
fi
echo "Validazione body: orario identico → atteso 422"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"name":"test","type":"WITH_DATA","scheduleType":"ONCE","startTime":"03:00","endTime":"03:00"}' -o /dev/null -w "%{http_code}" "$BASE/api/v2/maintenance")
echo "POST startTime=endTime → HTTP $CODE"

echo ""
echo "=== 3c. CICLO DEVICE-GROUPS (16.3 W3: POST → PATCH membership → no-op → DELETE) ==="
DEV_ID2=$(curl -s -b "$JAR" "$BASE/api/v2/devices?page=1&pageSize=10" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];print(d['items'][1]['id'])")
G_CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
  -d "{\"name\":\"[verifica] Gruppo temporaneo\",\"description\":\"da verify-api.sh, rimosso a fine verifica\",\"color\":\"#7c3aed\",\"deviceIds\":[\"$DEV_ID\",\"$DEV_ID2\"]}" \
  -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
G_ID=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['id'] if d.get('ok') else '')" 2>/dev/null)
MC=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['memberCount'])" 2>/dev/null)
echo "POST creazione (2 membri) → HTTP $G_CODE (atteso 201, memberCount=$MC atteso 2)"
if [ -n "$G_ID" ]; then
  CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"name":"[verifica] Gruppo temporaneo"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
  echo "POST duplicato stesso nome → HTTP $CODE (atteso 422 GROUP_EXISTS)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d "{\"deviceIds\":[\"$DEV_ID\"]}" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$G_ID")
  echo "PATCH membership sostituzione integrale 2→1 → HTTP $CODE (atteso 200, memberCount=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['memberCount'])" 2>/dev/null))"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{"name":"[verifica] Gruppo temporaneo"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$G_ID")
  echo "PATCH senza cambi effettivi → HTTP $CODE (atteso 422 NO_CHANGES)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$G_ID")
  echo "PATCH body vuoto → HTTP $CODE (atteso 422 refine almeno-un-campo)"
  CODE=$(curl -s -b "$JAR" -X DELETE -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$G_ID")
  echo "DELETE → HTTP $CODE (atteso 200, removedScopes=$(python3 -c "import json;print(json.load(open('$OUT'))['data'].get('removedScopes'))" 2>/dev/null))"
  CODE=$(curl -s -b "$JAR" -X DELETE -o /dev/null -w "%{http_code}" "$BASE/api/v2/device-groups/$G_ID")
  echo "DELETE di nuovo → HTTP $CODE (atteso 404)"
else
  echo "POST gruppo FALLITO: $(head -c 300 "$OUT")"
fi

echo ""
echo "=== 3c-bis. CICLO GRUPPO DYNAMIC (16.4 W3: POST regola → PATCH regola → guardie → DELETE) ==="
D_CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
  -d "{\"name\":\"[verifica] Gruppo dinamico\",\"description\":\"da verify-api.sh\",\"ruleType\":\"DYNAMIC\",\"rules\":{\"deviceTypes\":[\"CAMERA\"]}}" \
  -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
D_ID=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['id'] if d.get('ok') else '')" 2>/dev/null)
D_MC=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data'].get('memberCount'))" 2>/dev/null)
D_RT=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data'].get('ruleType'))" 2>/dev/null)
echo "POST DYNAMIC regola {deviceTypes:[CAMERA]} → HTTP $D_CODE (atteso 201, ruleType=$D_RT, memberCount calcolato=$D_MC atteso 87)"
if [ -n "$D_ID" ]; then
  CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d "{\"name\":\"[verifica] Dinamico mancante\",\"ruleType\":\"DYNAMIC\"}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
  echo "POST DYNAMIC senza rules → HTTP $CODE (atteso 422 refine)"
  CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d "{\"name\":\"[verifica] Dinamico contraddittorio\",\"ruleType\":\"DYNAMIC\",\"rules\":{\"deviceTypes\":[\"CAMERA\"]},\"deviceIds\":[]}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
  echo "POST DYNAMIC con deviceIds → HTTP $CODE (atteso 422 refine)"
  CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d "{\"name\":\"[verifica] Dinamico valori fantasma\",\"ruleType\":\"DYNAMIC\",\"rules\":{\"deviceTypes\":[\"CAMERA\",\"HOLOGRAM\"]}}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
  echo "POST DYNAMIC con tipo inesistente HOLOGRAM → HTTP $CODE (atteso 422 con offensori)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" \
    -d "{\"rules\":{\"deviceTypes\":[\"CAMERA\"],\"statuses\":[\"ONLINE\"]}}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$D_ID")
  echo "PATCH regola estesa {CAMERA + ONLINE} → HTTP $CODE (atteso 200, memberCount=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['memberCount'])" 2>/dev/null) — ri-calcolato)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" \
    -d "{\"rules\":{\"statuses\":[\"ONLINE\"],\"deviceTypes\":[\"CAMERA\"]}}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$D_ID")
  echo "PATCH regola identica (ordine diversi) → HTTP $CODE (atteso 422 NO_CHANGES)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" \
    -d "{\"deviceIds\":[\"$DEV_ID\"]}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$D_ID")
  echo "PATCH deviceIds su DYNAMIC → HTTP $CODE (atteso 422 RULE_TYPE)"
  CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" \
    -d "{\"ruleType\":\"MANUAL\"}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$D_ID")
  echo "PATCH ruleType (immutabile) → HTTP $CODE (atteso 422 RULE_TYPE_IMMUTABLE)"
  CODE=$(curl -s -b "$JAR" -X DELETE -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$D_ID")
  echo "DELETE gruppo dinamico → HTTP $CODE (atteso 200, removedScopes=$(python3 -c "import json;print(json.load(open('$OUT'))['data'].get('removedScopes'))" 2>/dev/null))"
else
  echo "POST gruppo DYNAMIC FALLITO: $(head -c 300 "$OUT")"
fi

echo ""
echo "=== 3d. MANUTENZIONE + SCOPE GRUPPI (16.3 W3: groupIds, PATCH campi) ==="
G_CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
  -d "{\"name\":\"[verifica] Scope temporaneo\",\"description\":\"da verify-api.sh\",\"deviceIds\":[\"$DEV_ID\"]}" \
  -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups")
G_ID=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['id'] if d.get('ok') else '')" 2>/dev/null)
echo "POST gruppo scope → HTTP $G_CODE (atteso 201)"
if [ -n "$G_ID" ]; then
  MW_CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d "{\"name\":\"[verifica] Finestra con scope\",\"type\":\"NO_DATA\",\"scheduleType\":\"WEEKLY\",\"daysOfWeek\":[1,2,3,4,5],\"startTime\":\"02:00\",\"endTime\":\"03:00\",\"groupIds\":[\"$G_ID\"]}" \
    -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance")
  MW_ID=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['id'] if d.get('ok') else '')" 2>/dev/null)
  SC=$(python3 -c "import json;d=json.load(open('$OUT'));s=d['data'].get('scopes',[]);print(s[0]['name'] if s else 'NESSUNO')" 2>/dev/null)
  echo "POST finestra con groupIds → HTTP $MW_CODE (atteso 201, scope=$SC atteso '[verifica] Scope temporaneo')"
  if [ -n "$MW_ID" ]; then
    CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{"name":"[verifica] Finestra con scope rinominata"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
    echo "PATCH rinominazione → HTTP $CODE (atteso 200, name=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['name'])" 2>/dev/null))"
    CODE=$(curl -s -b "$JAR" -X PATCH -H "Content-Type: application/json" -d '{"scheduleType":"DAILY","daysOfWeek":[1]}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
    echo "PATCH giorni forniti con schedule effettiva DAILY → HTTP $CODE (atteso 422)"
    CODE=$(curl -s -b "$JAR" -X DELETE -o /dev/null -w "%{http_code}" "$BASE/api/v2/maintenance/$MW_ID")
    echo "DELETE finestra → HTTP $CODE (atteso 200)"
  fi
  CODE=$(curl -s -b "$JAR" -X DELETE -o "$OUT" -w "%{http_code}" "$BASE/api/v2/device-groups/$G_ID")
  echo "DELETE gruppo scope → HTTP $CODE (atteso 200, removedScopes=$(python3 -c "import json;print(json.load(open('$OUT'))['data'].get('removedScopes'))" 2>/dev/null) — finestra già eliminata)"
fi

echo ""
echo "=== 3e. DISCOVERY & ADOZIONE (16.6 W3.4: motori v15 portati :3002) ==="
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"cidr":"127.0.0.1/32","ports":[3000,3001,3002]}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/discovery/scan")
UP=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['summary']['up'])" 2>/dev/null)
echo "POST discovery/scan 127.0.0.1/32 → HTTP $CODE (atteso 200, host vivi=$UP atteso 1)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"cidr":"10.255.255.0/30"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/discovery/scan")
echo "POST discovery/scan rete muta → HTTP $CODE (atteso 200 con up=0, onesto)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"cidr":"non-un-cidr"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/discovery/scan")
echo "POST discovery/scan cidr invalido → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"ip":"127.0.0.1"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/discovery/probe")
ALIVE=$(python3 -c "import json;d=json.load(open('$OUT'));print(d['data']['alive'])" 2>/dev/null)
echo "POST discovery/probe 127.0.0.1 → HTTP $CODE (atteso 200, alive=$ALIVE onesto)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"ip":"999.1.1.1"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/discovery/probe")
echo "POST discovery/probe ip invalido → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/discovery/oui?mac=ZZ")
echo "GET discovery/oui mac invalido → HTTP $CODE (atteso 422)"
ORF=$(curl -s -b "$JAR" "$BASE/api/v2/adozione" | python3 -c "import sys,json;print(len(json.load(sys.stdin)['data']['orphans']))")
echo "GET adozione orfani reali → $ORF (atteso 30 nel DB egidio)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"action":"adopt","deviceId":"inesistente","locationId":"inesistente"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/adozione")
echo "POST adozione adopt id inesistente → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"action":"dismiss","deviceId":"inesistente"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/adozione")
echo "POST adozione dismiss id inesistente → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/adozione")
echo "POST adozione body vuoto → HTTP $CODE (atteso 422)"

echo ""
echo "=== 3f. OPERAZIONI EVOLUTE + INTEGRAZIONI (16.7 W3.5+W7.0) ==="
SYS_N=$(curl -s -b "$JAR" "$BASE/api/v2/event-policies" | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['systemCount'])")
echo "event-policies regole SYS reali → $SYS_N (atteso 10 nel DB egidio)"
CODE=$(curl -s -b "$JAR -X POST -H Content-Type: application/json -d {}" -o /dev/null -w "%{http_code}" "$BASE/api/v2/event-policies" 2>/dev/null)
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/event-policies")
echo "POST event-policies body vuoto → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"deviceId":"x","title":"t","commands":["rm -rf /"]}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/config-requests")
echo "POST config-requests guardrail rm -rf → HTTP $CODE (atteso 422 FORBIDDEN_COMMAND)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"kind":"webhook"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/integrations/test")
echo "POST integrations/test kind webhook → HTTP $CODE (atteso 422 BAD_KIND)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"kind":"tcp","port":3000}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/integrations/test")
echo "POST integrations/test tcp senza host → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -X POST -H "Content-Type: application/json" -d '{"name":"x"}' -o "$OUT" -w "%{http_code}" "$BASE/api/v2/integrations/webhooks")
echo "POST webhooks body incompleto → HTTP $CODE (atteso 422)"

echo ""
echo "=== 3g. W2 RESIDUA + W6 CERTIFICAZIONE (16.8) ==="
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/reports/sla")
echo "GET reports/sla default → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
tot = d['tickets']['total']
cre = d['tickets']['created']
meas = d['responseTime']['measured']
slad = d['slaCompliance']['slaDefinitions']
hist = len(d['history'])
assert tot == 74, tot
assert meas == 0 and slad == 0
print(f'  sla: coorte {cre}/74, measured risposta {meas} (onesto), SLADef {slad} (D19), history {hist}')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/reports/sla?month=2020-01")
echo "GET reports/sla mese senza dati → HTTP $CODE (atteso 200 con coorte 0 onesta)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['tickets']['created'] == 0
print('  mese 2020-01: coorte 0 (onesto)')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/reports/sla?month=13-99")
echo "GET reports/sla month invalido → HTTP $CODE (atteso 422)"
TID=$(curl -s -b "$JAR" "$BASE/api/v2/tickets?pageSize=10" | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['items'][0]['id'])")
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/tickets/$TID")
echo "GET tickets/{id} scheda intervento → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
tit = d['ticket']['title'][:40]
tl = len(d['timeline'])
iv = len(d['interventions'])
assert 'ticket' in d and 'timeline' in d and 'honesty' in d
print(f'  scheda: ticket righa timeline {tl} audit reali, interventi {iv}')
"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" "$BASE/api/v2/tickets/inesistente123")
echo "GET tickets/{id} inesistente → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/reports/scheduled")
echo "GET reports/scheduled (vuoto onesto) → HTTP $CODE (atteso 200)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/reports/scheduled" -H 'Content-Type: application/json' -d '{"name":"verifica semantica","frequency":"WEEKLY","hour":8,"channels":["PDF"],"recipients":["a@b.it"],"includeSections":["devices"]}')
echo "POST scheduled WEEKLY senza dayOfWeek → HTTP $CODE (atteso 422 BAD_FREQUENCY)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/reports/scheduled" -H 'Content-Type: application/json' -d '{"name":"x","frequency":"DAILY","hour":8,"channels":["PDF"],"recipients":["non-email"],"includeSections":["devices"]}')
echo "POST scheduled destinatario non email → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/audit/export?limit=3")
echo "GET audit/export envelope → HTTP $CODE (atteso 200 con manifest)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
m = d['manifest']
tr = m['totalRows']
sr = m['sealedRows']
cd = m['chainDigest'][:16] if m['chainDigest'] else '—'
assert tr >= 48046, tr
assert sr > 47000
assert m['chainDigest']
print(f'  export: total {tr}, sealed {sr}, chainDigest {cd}…')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/audit/chain")
echo "GET audit/chain stato → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
ns = len(d['seals'])
sr = d['sealedRows']
tr = d['totalRows']
assert ns == 64, ns
assert sr > 47000
print(f'  catena: {sr} sigillate su {tr}, {ns} sigilli v15 reali')
"
CODE=$(curl -s -b "$JAR" -m 60 -o "$OUT" -w "%{http_code}" "$BASE/api/v2/audit/chain/verify")
echo "GET audit/chain/verify (ricalcolo completo) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
rv = d['recordsVerified']
rs = d['recordsSealed']
sv = d['sealsVerified']
ms = d['durationMs']
assert d['verified'] is True, d['breakages'][:2]
assert rv > 47000 and sv == 64
print(f'  verifica: CATENA INTEGRA — {rv}/{rs} righe, {sv}/64 sigilli in {ms} ms')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -D /tmp/verify-export-h.txt "$BASE/api/v2/audit/export?format=csv&to=1792773300000")
echo "GET audit/export format=csv (file certificato) → HTTP $CODE (atteso 200 + header sha256)"
grep -qi "x-falco-export-sha256" /tmp/verify-export-h.txt && echo "  header x-falco-export-sha256 presente (digest certificato)"

echo ""
echo "=== 3h. ONDA W4 (16.9: KB, RMA, ondate, CVE, speed test, admin utenti/permessi) ==="
# Dispositivo REALE con sede (le prime pagine includono 30 orfani senza sede,
# esclusi dal perimetro RMA/ondate per ADR-005 come in v15)
DEV_LOC=$(curl -s -b "$JAR" "$BASE/api/v2/devices?page=1&pageSize=50" | python3 -c "
import sys, json
items = json.load(sys.stdin)['data']['items']
dev = next((d for d in items if d.get('locationId')), None)
assert dev, 'nessun dispositivo con sede nelle prime 50 righe'
print(dev['id'])
")
echo "device con sede per RMA/ondate: $DEV_LOC"

CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/kb")
echo "GET kb (vuota onesta) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['total'] == 0 and d['items'] == [], d
print('  kb: 0 articoli nel DB reale (onesto)')
"

# --- CICLO KB: POST create → PATCH → DELETE (self-cleaning, audit resta) ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/kb" -H "Content-Type: application/json" -d '{"title":"Verifica API — articolo di prova","body":"Corpo di prova della knowledge base (viene eliminato subito).","tags":["verifica","api"]}')
echo "POST kb create → HTTP $CODE (atteso 201)"
KB_ID=$(python3 -c "import json; print(json.load(open('$OUT'))['data']['id'])")
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/kb/$KB_ID" -H "Content-Type: application/json" -d '{"title":"Verifica API — articolo MODIFICATO"}')
echo "PATCH kb update → HTTP $CODE (atteso 200)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/kb/$KB_ID" -H "Content-Type: application/json" -d '{}')
echo "PATCH kb no-op → HTTP $CODE (atteso 422 NO_CHANGES)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/kb/$KB_ID")
echo "DELETE kb → HTTP $CODE (atteso 200, ciclo chiuso)"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" -X DELETE "$BASE/api/v2/kb/$KB_ID")
echo "DELETE kb di nuovo → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" -X POST "$BASE/api/v2/kb" -H "Content-Type: application/json" -d '{"title":""}')
echo "POST kb title vuoto → HTTP $CODE (atteso 422)"

# --- RMA: piano in sola lettura sul device reale ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/rma?deviceId=$DEV_LOC")
echo "GET rma piano (dati reali) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['deviceId'] == '$DEV_LOC'
assert isinstance(d['impact']['downstreamVictims'], int)
assert isinstance(d['portable']['credentials'], list)
print(f\"  piano: {d['hostname']} — {d['impact']['downstreamVictims']} vittime a valle, {len(d['portable']['credentials'])} credenziali portabili, {len(d['warnings'])} avvisi\")
"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" "$BASE/api/v2/rma")
echo "GET rma senza deviceId → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" -X POST "$BASE/api/v2/rma" -H "Content-Type: application/json" -d '{"oldDeviceId":"inesistente","replacement":{"hostname":"x","ip":"10.0.0.1","type":"SWITCH"}}')
echo "POST rma device inesistente → HTTP $CODE (atteso 404)"

# --- CICLO ONDATA: POST create (preflight reale) → DELETE (self-cleaning) ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/waves" -H "Content-Type: application/json" -d "{\"name\":\"Verifica API — ondata di prova\",\"kind\":\"CONFIG\",\"deviceIds\":[\"$DEV_LOC\"],\"batchSize\":5,\"canarySize\":1}")
echo "POST waves create (preflight reale) → HTTP $CODE (atteso 201)"
WAVE_ID=$(python3 -c "import json; print(json.load(open('$OUT'))['data']['wave']['id'])")
python3 -c "
import json
d = json.load(open('$OUT'))['data']
pf = d['preflight'][0]
assert d['wave']['status'] == 'DRAFT'
print(f\"  ondata DRAFT: preflight {d['scarti']} scarti su 1 target — {pf['reason']}\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/waves/$WAVE_ID")
echo "DELETE waves DRAFT → HTTP $CODE (atteso 200, ciclo chiuso)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/waves")
echo "GET waves (vuota onesta + D2) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['total'] == 0 and d['executionAvailable'] is False
print('  waves: 0 ondate, executionAvailable false (onestà D2)')
"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" -X POST "$BASE/api/v2/waves" -H "Content-Type: application/json" -d '{"name":"","deviceIds":[]}')
echo "POST waves nome vuoto → HTTP $CODE (atteso 422)"

# --- CVE: catalogo vuoto, scan no-op onesto, import invalido ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/cve")
echo "GET cve catalogo (vuoto onesto) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['total'] == 0 and d['demoCatalogAvailable'] == 12
print('  catalogo: 0 voci reali, 12 dimostrative importabili (dichiarate)')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/cve/scan")
echo "POST cve/scan (no-op: catalogo vuoto) → HTTP $CODE (atteso 201)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
# W11: 183 dispositivi attivi (200 - 22 artefatti 192.168.1.x dismessi)
assert d['scanned'] == 183 and d['findings'] == 0
print(f\"  scan: {d['scanned']} dispositivi scansionati, 0 finding (catalogo vuoto — nessuna riga scritta)\")
"
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" -X POST "$BASE/api/v2/cve/import" -H "Content-Type: application/json" -d '{}')
echo "POST cve/import body vuoto → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/cve/findings")
echo "GET cve/findings (vuota onesta) → HTTP $CODE (atteso 200)"

# --- SPEED TEST: executor assente → 501 ONESTO, nessuna riga scritta ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/speed-tests" -H "Content-Type: application/json" -d "{\"deviceId\":\"$DEV_LOC\",\"executor\":\"IPERF3\"}")
echo "POST speed-tests IPERF3 (binario assente) → HTTP $CODE (atteso 501 onesto)"
python3 -c "
import json
d = json.load(open('$OUT'))
assert d['ok'] is False and d['error']['code'] == 'EXECUTOR_DOWN'
print(f\"  {d['error']['code']}: {d['error']['message'][:60]}…\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/speed-tests")
echo "GET speed-tests (vuota: NESSUNA riga scritta dal 501) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['stats']['total'] == 0
print('  storico: 0 righe (il 501 non scrive — onestà)')
"

# --- ADMIN: utenti (1 reale), permessi (matrice v15), sessioni (onestà JWT) ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/admin/users")
echo "GET admin/users → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['total'] == 1 and d['users'][0]['role'] == 'SUPER_ADMIN'
print(f\"  utenti: {d['total']} reale ({d['users'][0]['email']})\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/admin/users" -H "Content-Type: application/json" -d '{"name":"Test Policy","email":"policy-test@falco-os.local","password":"password123"}')
echo "POST admin/users password fuori policy → HTTP $CODE (atteso 422 BAD_PASSWORD)"
python3 -c "
import json
d = json.load(open('$OUT'))
assert d['error']['code'] == 'BAD_PASSWORD', d['error']['code']
print(f\"  policy: {d['error']['message'][:80]}…\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/admin/users" -H "Content-Type: application/json" -d '{"name":"Gia","email":"admin@falco-os.local","password":"Cortina!2026x"}')
echo "POST admin/users email duplicata → HTTP $CODE (atteso 409, nessuna riga scritta)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/admin/permissions")
echo "GET admin/permissions → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['version'] == 2 and len(d['catalog']) == 36 and len(d['roles']) == 4
print(f\"  matrice RBAC v2: {len(d['catalog'])} permessi × 4 ruoli, {len(d['modules'])} moduli\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/admin/sessions")
echo "GET admin/sessions → HTTP $CODE (atteso 200 con nota JWT onesta)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['total'] == 0 and 'JWT stateless' in d['note']
print('  sessioni: 0 persistite (JWT stateless — dichiarato)')
"

# --- ASSISTENTE: validazione input (lo stream SSE è verificato via browser) ---
CODE=$(curl -s -b "$JAR" -o /dev/null -w "%{http_code}" -X POST "$BASE/api/v2/assistente" -H "Content-Type: application/json" -d '{}')
echo "POST assistente body vuoto → HTTP $CODE (atteso 422)"

echo ""
echo "=== 3i. ONDA W8 (16.10: impianti, KMZ, gestione collegamenti topologici) ==="

# --- IMPIANTI: GET riga completa + ciclo CRUD self-cleaning su impianto scratch ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/plants")
echo "GET plants → HTTP $CODE (atteso 200, riga estesa)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert len(d) >= 1
p = d[0]
for k in ['name','comune','telegramChatId','kmzFile','outageTimerMinutes','snmpCommunities','topologyRootDeviceId','deviceCount','locationCount','ticketCount','createdAt']:
    assert k in p, f'manca {k}'
print(f\"  {len(d)} impianto/i · riga estesa completa · deviceCount={p['deviceCount']} locations={p['locationCount']}\")
"
EGIDIO=$(python3 -c "import json; d=json.load(open('$OUT'))['data']; print([p['id'] for p in d if p['name']=='egidio'][0])")
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/plants" -H "Content-Type: application/json" -d '{}')
echo "POST plants body vuoto → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/plants" -H "Content-Type: application/json" -d '{"name":"","comune":"x"}')
echo "POST plants name vuoto → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/plants" -H "Content-Type: application/json" -d '{"name":"Verifica E2E W8","comune":"Test","pingIntervalSec":3}')
echo "POST plants pingIntervalSec=3 (min 5) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/plants" -H "Content-Type: application/json" -d '{"name":"Verifica E2E W8","comune":"Comune di Prova","address":"Via Test 1","telegramChatId":"-100999","outageTimerMinutes":10}')
echo "POST plants crea scratch → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['name'] == 'Verifica E2E W8' and d['deviceCount'] == 0 and d['outageTimerMinutes'] == 10
print(f\"  impianto scratch: {d['id']} · vuoto (0 dispositivi) · timer 10 min\")
PLANT_W8 = d['id']
open('/tmp/plant-w8-id.txt','w').write(PLANT_W8)
"
PLANT_W8=$(cat /tmp/plant-w8-id.txt)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/plants/$PLANT_W8" -H "Content-Type: application/json" -d '{}')
echo "PATCH plants/$PLANT_W8 vuoto → HTTP $CODE (atteso 422 NO_CHANGES)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/plants/$PLANT_W8" -H "Content-Type: application/json" -d '{"telegramChatId":"-1001234","snmpCommunities":"public,ro-test"}')
echo "PATCH plants telegram+snmp → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['telegramChatId'] == '-1001234' and d['snmpCommunities'] == 'public,ro-test'
print('  telegram + community SNMP aggiornate')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/plants/$PLANT_W8" -H "Content-Type: application/json" -d '{"topologyRootDeviceId":"inesistente"}')
echo "PATCH plants root inesistente → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/plants/$EGIDIO")
echo "DELETE plants/egidio (200 dispositivi) → HTTP $CODE (atteso 409 PLANT_NOT_EMPTY)"
python3 -c "
import json
e = json.load(open('$OUT'))['error']
assert e['code'] == 'PLANT_NOT_EMPTY' and 'dispositivi' in e['message']
print('  guardia onesta: impianto reale NON eliminabile')
"

# --- KMZ: preview con KML sintetico (2 punti) → apply su scratch → REVERT ---
cat > /tmp/falco-w8-test.kml <<'KML'
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document>
<Placemark><name>Piazza Verifica</name><Point><coordinates>14.12345,41.12345,0</coordinates></Point></Placemark>
<Placemark><name>Scuola Verifica</name><description>Punto di test</description><Point><coordinates>14.23456,41.23456,0</coordinates></Point></Placemark>
</Document></kml>
KML
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/locations/import-kmz/preview" -F "file=@/tmp/falco-w8-test.kml;type=application/vnd.google-earth.kml+xml" -F "plantId=$PLANT_W8")
echo "POST import-kmz/preview (KML 2 punti) → HTTP $CODE (atteso 200, NESSUNA scrittura)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['created'] == 2 and len(d['points']) == 2 and d['fileName'].endswith('.kml')
assert d['points'][0]['action'] == 'CREATE' and d['points'][0]['lat'] == 41.12345
print(f\"  piano: 2 CREATE · fileId {d['fileId'][:8]}… · zero scritture\")
open('/tmp/kmz-fileid.txt','w').write(d['fileId'])
"
KMZFILE=$(cat /tmp/kmz-fileid.txt)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/locations/import-kmz/preview" -F "file=@/tmp/falco-w8-test.kml;type=application/vnd.google-earth.kml+xml" -F "plantId=inesistente")
echo "POST preview plantId inesistente → HTTP $CODE (atteso 404)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/locations/import-kmz/apply" -H "Content-Type: application/json" -d "{\"fileId\":\"$KMZFILE\",\"plantId\":\"$PLANT_W8\",\"points\":[{\"placemarkIndex\":0,\"action\":\"CREATE\"}]}")
echo "POST apply (1 punto confermato) → HTTP $CODE (atteso 200)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['created'] == 1 and d['plantKmzFile'] != ''
print(f\"  1 punto creato · KMZ conservato: {d['plantKmzFile'][:20]}…\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/locations/import-kmz/apply" -H "Content-Type: application/json" -d "{\"fileId\":\"$KMZFILE\",\"plantId\":\"$PLANT_W8\",\"points\":[{\"placemarkIndex\":0,\"action\":\"CREATE\"}]}")
echo "POST apply RIUSO stesso fileId → HTTP $CODE (atteso 404: file temporaneo consumato)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/locations/import-kmz/apply" -H "Content-Type: application/json" -d "{\"fileId\":\"$KMZFILE\",\"plantId\":\"$PLANT_W8\",\"points\":[]}")
echo "POST apply points vuoto → HTTP $CODE (atteso 422)"

# --- GESTIONE PUNTI: DELETE location scratch (guardia + pulizia per il revert) ---
LOC_W8=$(curl -s -b "$JAR" "$BASE/api/v2/locations?plantId=$PLANT_W8" | python3 -c "import json,sys; d=json.load(sys.stdin)['data']; print([l['id'] for l in d if l['name']=='Piazza Verifica'][0])")
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/locations/$LOC_W8")
echo "DELETE locations/punto scratch → HTTP $CODE (atteso 200 LOCATION_DELETE)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['deleted'] == True
print('  punto creato dall\'import eliminato: revert pulito')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/locations/$LOC_W8")
echo "DELETE locations già eliminato → HTTP $CODE (atteso 404)"
# guardia su punto REALE con dispositivi: la prima sede di egidio con dispositivi
curl -s -b "$JAR" "$BASE/api/v2/locations" -o /tmp/w8-locs.json
LOC_REAL=$(python3 -c "
import json
d = json.load(open('/tmp/w8-locs.json'))['data']
cands = [l['id'] for l in d if l['devices'] > 0]
assert cands, 'nessuna sede con dispositivi nella risposta locations: ' + json.dumps(d)[:200]
print(cands[0])
")
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/locations/$LOC_REAL")
echo "DELETE locations/punto reale con dispositivi → HTTP $CODE (atteso 409 LOCATION_IN_USE)"

# --- TOPOLOGY LINKS: elenco + stats + ciclo CRUD self-cleaning (create→confirm→delete) ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/topology/links?pageSize=10")
echo "GET topology/links → HTTP $CODE (atteso 200 con stats inventario)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
# W11 (16.13): topologia REALE dell'operatore (Excel SETI + percorsi KMZ):
# 181 collegamenti TECHNICIAN confermati al posto dei 892 auto-scoperti
assert d['total'] == 181 and d['stats']['total'] == 181 and d['stats']['confirmed'] == 181
srcs = {s['source']: s['count'] for s in d['stats']['bySource']}
assert srcs.get('TECHNICIAN') == 181
print(f\"  inventario: {d['stats']['total']} collegamenti reali (W11) · confermati {d['stats']['confirmed']} · TECHNICIAN {srcs.get('TECHNICIAN')}\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/topology/links?source=PINO")
echo "GET links source=PINO → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/topology/graph?sources=PINO")
echo "GET graph sources=PINO → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/topology/graph?sources=TECHNICIAN,LLDP")
echo "GET graph sources=TECHNICIAN,LLDP → HTTP $CODE (atteso 200 filtrato)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['sources'] == ['TECHNICIAN','LLDP']
# W11: tutti i link sono TECHNICIAN confermati — nessun inferito da escludere
assert d['linkStats']['total'] == 181 and d['linkStats']['included'] == 181 and d['linkStats']['excludedInferred'] == 0
print(f\"  filtro: inclusi {d['linkStats']['included']}/181 · esclusi {d['linkStats']['excludedInferred']} · archi albero {len(d['edges'])}\")
"
# coppia di dispositivi SENZA un collegamento esistente (idempotente:
# il test crea e poi elimina il suo link — mai 409 per colpa di un link reale)
curl -s -b "$JAR" "$BASE/api/v2/devices?pageSize=50" -o /tmp/w8-devs.json
curl -s -b "$JAR" "$BASE/api/v2/topology/links?pageSize=200" -o /tmp/w8-links.json
PAIR=$(python3 -c "
import json
devs = json.load(open('/tmp/w8-devs.json'))['data']['items']
links = json.load(open('/tmp/w8-links.json'))['data']['links']
pairs = set()
for l in links:
    a, b = l.get('sourceDeviceId'), l.get('targetDeviceId')
    if a and b:
        pairs.add((a, b)); pairs.add((b, a))
for i in range(len(devs)):
    for j in range(i+1, len(devs)):
        if (devs[i]['id'], devs[j]['id']) not in pairs:
            print(devs[i]['id'], devs[j]['id'])
            raise SystemExit
" | head -1)
DEV1=$(echo "$PAIR" | cut -d' ' -f1)
DEV2=$(echo "$PAIR" | cut -d' ' -f2)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/topology/links" -H "Content-Type: application/json" -d "{\"plantId\":\"$EGIDIO\",\"sourceDeviceId\":\"$DEV1\",\"targetDeviceId\":\"$DEV2\",\"linkType\":\"UTP_COPPER\",\"label\":\"Verifica E2E W8\"}")
echo "POST topology/links crea manuale → HTTP $CODE (atteso 200 TECHNICIAN/confirmed)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['sourceOfTruth'] == 'TECHNICIAN' and d['confirmed'] == True and d['confidence'] == 'HIGH'
print(f\"  link manuale: {d['sourceHostname']} → {d['targetHostname']} · confermato alla nascita\")
open('/tmp/link-w8-id.txt','w').write(d['id'])
"
LINK_W8=$(cat /tmp/link-w8-id.txt)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/topology/links" -H "Content-Type: application/json" -d "{\"plantId\":\"$EGIDIO\",\"sourceDeviceId\":\"$DEV1\",\"targetDeviceId\":\"$DEV2\"}")
echo "POST link duplicato → HTTP $CODE (atteso 409 LINK_EXISTS)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/topology/links/$LINK_W8" -H "Content-Type: application/json" -d '{}')
echo "PATCH link vuoto → HTTP $CODE (atteso 422 NO_CHANGES)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X PATCH "$BASE/api/v2/topology/links/$LINK_W8" -H "Content-Type: application/json" -d '{"label":"Corretto in verifica","speedMbps":1000}')
echo "PATCH link correzione → HTTP $CODE (atteso 200)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/topology/links/$LINK_W8")
echo "DELETE link scratch → HTTP $CODE (atteso 200, revert)"

# --- PURGE: dryRun onesto (conta, NON scrive) + guardia TECHNICIAN ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/topology/links/purge" -H "Content-Type: application/json" -d "{\"plantId\":\"$EGIDIO\",\"sources\":[\"INFERRED\",\"FDB\",\"DAISY_CHAIN\"],\"dryRun\":true}")
echo "POST purge dryRun (INFERRED+FDB+DAISY_CHAIN) → HTTP $CODE (atteso 200 conteggio)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
# W11: gli inferiti non esistono più (892 auto-scoperti sostituiti da 181 reali)
assert d['dryRun'] == True and d['count'] == 0 and len(d['sample']) <= 5
print(f\"  dry-run onesto: {d['count']} collegamenti inferiti NON confermati sarebbero eliminabili (NESSUNA scrittura)\")
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/topology/links/purge" -H "Content-Type: application/json" -d "{\"plantId\":\"$EGIDIO\",\"sources\":[\"TECHNICIAN\"],\"dryRun\":true}")
echo "POST purge sources=TECHNICIAN → HTTP $CODE (atteso 422: guardia)"
# NB: l'ESECUZIONE reale del purge NON viene mai provata sull'impianto reale
# (D25: il DB non deve contenere artefatti dei test): si prova sul plant scratch.
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/topology/links/purge" -H "Content-Type: application/json" -d "{\"plantId\":\"$PLANT_W8\",\"sources\":[\"LLDP\",\"INFERRED\"],\"dryRun\":false}")
echo "POST purge esecuzione su impianto SCRATCH → HTTP $CODE (atteso 200, 0 righe)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['count'] == 0
print('  scratch: 0 eliminazioni (impianto vuoto) — esecuzione reale provata senza danni')
"

# --- REVERT W8 COMPLETO: elimina impianto scratch (vuoto) + file temporanei ---
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/plants/$PLANT_W8")
echo "DELETE plants/scratch (vuoto) → HTTP $CODE (atteso 200: revert finale)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['deleted'] == True
print('  DB reale PRISTINO: impianto scratch eliminato, audit pulito nei test successivi')
"
rm -f /tmp/falco-w8-test.kml /tmp/plant-w8-id.txt /tmp/kmz-fileid.txt /tmp/link-w8-id.txt /tmp/w8-devs.json /tmp/w8-links.json


echo "=== 3j. MULTI-IMPIANTO «A SE STANTI» (16.12 W10: isolamento reale) ==="
# impianto A = il più vecchio (default deterministico W8); impianto B = il secondo
# reale se esiste, altrimenti uno scratch vuoto (creato/eliminato qui).
PLANT_B=$(curl -s -b "$JAR" "$BASE/api/v2/plants" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
plants = sorted(d, key=lambda p: p['createdAt'])
print(plants[1]['id'] if len(plants) > 1 else '')")
PLANT_B_CREATED=0
if [ -z "$PLANT_B" ]; then
  CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/plants" -H "Content-Type: application/json" \
    -d '{"name":"[verifica] isolamento","comune":"verifica"}')
  PLANT_B=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['id'])")
  PLANT_B_CREATED=1
  echo "impianto scratch di isolamento creato: $PLANT_B"
fi
PLANT_A=$(curl -s -b "$JAR" "$BASE/api/v2/plants" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
plants = sorted(d, key=lambda p: p['createdAt'])
print(plants[0]['id'])")
echo "impianto A (default): $PLANT_A · impianto B: $PLANT_B"

# 1. inventario completamente separato
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/devices?plantId=$PLANT_A&pageSize=10")
echo "devices impianto A → HTTP $CODE (atteso 200)"
TOTAL_A=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['total'])")
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/devices?plantId=$PLANT_B&pageSize=10")
echo "devices impianto B → HTTP $CODE (atteso 200)"
TOTAL_B=$(python3 -c "import json;print(json.load(open('$OUT'))['data']['total'])")
echo "  A total=$TOTAL_A · B total=$TOTAL_B (isolamento: B non vede i dispositivi di A)"
python3 -c "
assert $TOTAL_A == 183, 'impianto A deve vedere i suoi 183 dispositivi attivi (W11: 200 - 22 artefatti dismessi)'
assert $TOTAL_B == 0, 'impianto B non deve vedere i dispositivi di A (bug operatore W10)'
print('  isolamento inventario: OK')
"

# 2. conteggi nel selettore impianti
curl -s -b "$JAR" "$BASE/api/v2/plants" | python3 -c "
import sys, json
plants = {p['id']: p for p in json.load(sys.stdin)['data']}
a, b = plants['$PLANT_A'], plants['$PLANT_B']
assert a['deviceCount'] == 183 and b['deviceCount'] == 0, 'conteggi per impianto errati'
print('  conteggi selettore: A', a['deviceCount'], 'dispositivi ·', a['locationCount'], 'sedi · B', b['deviceCount'], 'dispositivi (0)')
"

# 3. orfani (host scoperti) SOLO nel loro impianto
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/adozione?plantId=$PLANT_B")
echo "adozione impianto B → HTTP $CODE (atteso 200, coda VUOTA)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert len(d['orphans']) == 0 and len(d['toConfirm']) == 0, 'orfani di A non devono apparire nella coda di B'
print('  coda adozione di B: 0 orfani (quelli di A restano da A)')
"
curl -s -b "$JAR" -o "$OUT" "$BASE/api/v2/adozione?plantId=$PLANT_A"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert len(d['orphans']) == 1, 'impianto A deve vedere il suo unico orfano reale (172.19.150.46, fuori Excel — W11)'
print('  coda adozione di A: 1 orfano (172.19.150.46 — fuori Excel, dichiarato: gli altri 29 sono stati abbinati alle sedi reali dal fix W11)')
"

# 4. dettaglio dispositivo di A chiesto con plantId B → 404
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/devices/$DEV_ID/overview?plantId=$PLANT_B")
echo "overview dispositivo di A con plantId B → HTTP $CODE (atteso 404)"
python3 -c "assert $CODE == 404"

# 5. topologia e NOC di B: vuote ONESTE
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/topology/graph?plantId=$PLANT_B")
echo "topology/graph impianto B → HTTP $CODE (atteso 200, vuoto)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert len(d['nodes']) == 0 and len(d['edges']) == 0
print('  grafo di B: 0 nodi · 0 archi')
"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/noc/summary?plantId=$PLANT_B")
echo "noc/summary impianto B → HTTP $CODE (atteso 200, zeri onesti)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert d['devices']['total'] == 0 and d['alarms']['open'] == 0 and d['cameras']['total'] == 0
print('  NOC di B: 0 dispositivi · 0 allarmi · 0 telecamere')
"

# 6. RMA: piano di un dispositivo di A chiesto con plantId B → 404
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/rma?deviceId=$DEV_LOC&plantId=$PLANT_B")
echo "rma piano dispositivo di A con plantId B → HTTP $CODE (atteso 404)"
python3 -c "assert $CODE == 404"

# 7. la raggiera/grafico di A resta intatto (regressione)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/topology/graph?plantId=$PLANT_A")
echo "topology/graph impianto A → HTTP $CODE (atteso 200, invariato)"
python3 -c "
import json
d = json.load(open('$OUT'))['data']
assert len(d['nodes']) == 183, 'A deve vedere i suoi 183 nodi (W11: topologia reale — 200 meno 22 artefatti dismessi)'
print('  grafo di A: ', len(d['nodes']), 'nodi (nessuna regressione)')
"

if [ "$PLANT_B_CREATED" = "1" ]; then
  CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X DELETE "$BASE/api/v2/plants/$PLANT_B")
  echo "DELETE plants/scratch isolamento → HTTP $CODE (atteso 200)"
  python3 -c "import json;assert json.load(open('$OUT'))['data']['deleted'] == True"
fi
rm -f /tmp/plant-iso.txt

echo "=== 3k. RICOSTRUZIONE L2 v16.15 (W13-W16: ARP/STP/VLAN + correlazione multi-switch) ==="

# 1. rotta singola: dispositivo inesistente → 404 onesto
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2" -H "Content-Type: application/json" -d '{"deviceId":"inesistente-w13"}')
echo "POST discovery/l2 deviceId inesistente → HTTP $CODE (atteso 404)"
python3 -c "assert $CODE == 404"

# 2. batch: deviceIds vuoto → 422 (mai fallback silenzioso)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/batch" -H "Content-Type: application/json" -d '{"deviceIds":[]}')
echo "POST discovery/l2/batch deviceIds vuoto → HTTP $CODE (atteso 422)"
python3 -c "assert $CODE == 422"

# 3. batch: contratto della risposta (forma onesta, ambiente-adattivo)
CODE=$(curl -s -b "$JAR" -o /tmp/l2batch.json -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/batch" -H "Content-Type: application/json" -d '{}')
echo "POST discovery/l2/batch default → HTTP $CODE (atteso 200)"
python3 -c "
import json
j = json.load(open('/tmp/l2batch.json'))
assert j['ok'] == True
d = j['data']
for k in ['scanned','reachable','concurrency','durationMs','switchLinks','rootBridgeMac','rootVotes','rootPorts','arpCandidates','perSwitch','persistence','warnings']:
    assert k in d, f'manca {k}'
p = d['persistence']
for k in ['linksCreated','linksUpdated','linksSkippedOperator','observationsSaved','arpSaved','stpSaved','vlanSaved']:
    assert k in p, f'manca persistence.{k}'
for s in d['perSwitch']:
    for k in ['deviceId','hostname','reachable','matched','sysName','stats','warnings']:
        assert k in s, f'manca perSwitch.{k}'
    st = s['stats']
    for k in ['lldpNeighbors','cdpNeighbors','fdbEntries','vlanFdbEntries','arpEntries','stpPorts','vlans','matchedLinks','unmatchedNeighbors','sharedPorts','unmatchedMacsWithIp','observations']:
        assert k in st, f'manca perSwitch.stats.{k}'
print(f\"  contratto batch completo · {d['scanned']} switch scansionati · {d['reachable']} raggiunti · {len(d['switchLinks'])} link switch↔switch\")
"

# 4. con l'impianto di test test-l2 + simulatori attivi: la correlazione FDB_MUTUAL deve esistere nel DB
TESTL2=$(curl -s -b "$JAR" "$BASE/api/v2/plants" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
m = [p['id'] for p in d if p['name'] == 'test-l2']
print(m[0] if m else '')")
if [ -n "$TESTL2" ]; then
  CODE=$(curl -s -b "$JAR" -o /tmp/l2batch-t.json -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/batch" -H "Content-Type: application/json" -d "{\"plantId\":\"$TESTL2\",\"concurrency\":2}")
  echo "POST discovery/l2/batch test-l2 → HTTP $CODE (atteso 200)"
  python3 -c "
import json
j = json.load(open('/tmp/l2batch-t.json'))
d = j['data']
assert d['reachable'] >= 1, 'almeno uno switch simulato deve rispondere'
assert d['rootBridgeMac'] != '', 'la root STP deve essere dichiarata'
kinds = [l['kind'] for l in d['switchLinks']]
assert 'FDB_MUTUAL' in kinds, f'atteso link FDB_MUTUAL, trovati: {kinds}'
print(f\"  {d['reachable']}/{d['scanned']} switch · root {d['rootBridgeMac']} ({d['rootVotes']} voti) · link: {kinds} · ARP salvate {d['persistence']['arpSaved']} · STP {d['persistence']['stpSaved']} · VLAN {d['persistence']['vlanSaved']}\")
"
  # 5. il grafo con INFERRED deve includere i link del correlatore (vocabolario v16.15)
  CODE=$(curl -s -b "$JAR" -o /tmp/graph-l2.json -w "%{http_code}" "$BASE/api/v2/topology/graph?plantId=$TESTL2&sources=TECHNICIAN,LLDP,CDP,MNDP,UISP,INFERRED,FDB,BRIDGE_MIB,DAISY_CHAIN,FDB_MUTUAL,FDB_PAIR,STP_DESIGNATED")
  echo "topology/graph test-l2 (fonti v16.15) → HTTP $CODE (atteso 200)"
  python3 -c "
import json
d = json.load(open('/tmp/graph-l2.json'))['data']
evs = [e.get('evidence','') for e in d['edges']]
assert any('FDB_MUTUAL' in e for e in evs), f'il link FDB_MUTUAL deve stare nell\\'albero, evidenze: {evs}'
print(f\"  grafo: {len(d['nodes'])} nodi · {len(d['edges'])} archi · FDB_MUTUAL incluso\")
"
  # 6. inventario MAC: campo arpIp presente (join ARP reale)
  CODE=$(curl -s -b "$JAR" -o /tmp/macinv.json -w "%{http_code}" "$BASE/api/v2/mac-inventory?plantId=$TESTL2&page=1&pageSize=25")
  echo "GET mac-inventory (join ARP) → HTTP $CODE (atteso 200)"
  python3 -c "
import json
d = json.load(open('/tmp/macinv.json'))['data']
assert len(d['items']) > 0, 'osservazioni FDB attese nell\\'impianto di test'
withip = [r for r in d['items'] if r.get('arpIp')]
assert all('arpIp' in r for r in d['items']), 'il campo arpIp deve esserci su ogni riga (anche vuoto)'
print(f\"  {len(d['items'])} osservazioni · {len(withip)} con IP risolto dall'ARP\")
"
else
  echo "  (impianto test-l2 assente: verifiche FDB_MUTUAL saltate — servono i simulatori SNMP, vedi mini-services/discovery-service/sim/)"
fi

echo "=== 3l. ADOZIONE CANDIDATO ARP v16.16 (W17-a: il pulsante «Adotta» del report batch) ==="

# 1. corpo invalido: MAC rotto → 422 (mai creato un device da input marcio)
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/adopt-arp" -H "Content-Type: application/json" -d '{"mac":"zzz","ip":"192.168.88.61","hostname":"rotto","type":"UNKNOWN"}')
echo "POST adopt-arp MAC invalido → HTTP $CODE (atteso 422)"
python3 -c "assert $CODE == 422"

# 2. MAC già in inventario → 422 MAC_INVENTORY (guardia a valle: il mondo cambia)
INVMAC=$(curl -s -b "$JAR" "$BASE/api/v2/devices?page=1&pageSize=50" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
m = [i['macAddress'] for i in d['items'] if i.get('macAddress')]
print(m[0] if m else '')")
INVIP=$(curl -s -b "$JAR" "$BASE/api/v2/devices?page=1&pageSize=50" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
for i in d['items']:
    if i.get('macAddress') == '$INVMAC':
        print(i.get('ip') or ''); break")
if [ -n "$INVMAC" ]; then
  CODE=$(curl -s -b "$JAR" -o /tmp/adopt-inv.json -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/adopt-arp" -H "Content-Type: application/json" -d "{\"mac\":\"$INVMAC\",\"ip\":\"192.168.88.99\",\"hostname\":\"doppione\",\"type\":\"UNKNOWN\"}")
  echo "POST adopt-arp MAC già in inventario → HTTP $CODE (atteso 422)"
  python3 -c "
import json
j = json.load(open('/tmp/adopt-inv.json'))
assert j['error']['code'] == 'MAC_INVENTORY', j['error']['code']
print('  guardia MAC: ' + j['error']['message'][:70] + '…')"
else
  echo "  (nessun device con MAC in prima pagina: guardia MAC saltata)"
fi

# 3. ciclo completo sull'impianto test-l2: adotta il candidato simulato → verifica → doppione → REVERT
if [ -n "$TESTL2" ]; then
  CODE=$(curl -s -b "$JAR" -o /tmp/adopt-ok.json -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/adopt-arp?plantId=$TESTL2" -H "Content-Type: application/json" -d '{"mac":"00:1F:29:61:14:61","ip":"192.168.88.61","hostname":"verifica-w17","type":"PRINTER","connectionType":"ETHERNET","notes":"ciclo di verifica verify-api 3l"}')
  echo "POST adopt-arp candidato simulato → HTTP $CODE (atteso 200)"
  python3 -c "
import json
j = json.load(open('/tmp/adopt-ok.json'))
assert j['ok'] == True
d = j['data']
for k in ['id','hostname','ip','macAddress','type','brand','connectionType','locationId','locationName','baselineUntil','evidence','seenBy','ouiVendor']:
    assert k in d, f'manca {k}'
assert d['macAddress'] == '00:1F:29:61:14:61'
print(f\"  creato «{d['hostname']}» · vendor IEEE «{d['ouiVendor']}» · evidenza {d['evidence']} · visto da {d['seenBy']} · baseline 24h\")
open('/tmp/adopt-id.txt','w').write(d['id'])"
  # 3b. il doppione è rifiutato (MAC appena adottato)
  CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" -X POST "$BASE/api/v2/discovery/l2/adopt-arp?plantId=$TESTL2" -H "Content-Type: application/json" -d '{"mac":"00:1F:29:61:14:61","ip":"192.168.88.61","hostname":"doppione","type":"UNKNOWN"}')
  echo "POST adopt-arp doppione → HTTP $CODE (atteso 422)"
  python3 -c "assert $CODE == 422"
  # 3c. REVERT: rimuove SOLO il device di verifica (audit append-only conservato)
  if [ -f /tmp/adopt-id.txt ]; then
    bun -e "
const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()
const id = require('fs').readFileSync('/tmp/adopt-id.txt', 'utf8').trim()
db.device.delete({ where: { id } }).then(() => { console.log('  REVERT: device di verifica rimosso (audit append-only conservato)'); return db.\$disconnect() }).catch(() => { console.log('  ATTENZIONE: revert non riuscito (device già rimosso?)'); return db.\$disconnect() })
" 2>/dev/null || echo "  (revert via bun non disponibile: rimuovere a mano il device verifica-w17)"
    rm -f /tmp/adopt-id.txt
  fi
else
  echo "  (impianto test-l2 assente: ciclo adozione saltato)"
fi

echo "=== 3m. MAPPA UISP v16.17 (W18: filtro devices per sede del punto) ==="

# 1. filtro locationId additivo: i dispositivi del punto tornano SOLO quelli
if [ -n "$TESTL2" ]; then
  LOCJSON=$(curl -s -b "$JAR" "$BASE/api/v2/locations?plantId=$TESTL2")
  LOCID=$(echo "$LOCJSON" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
loc = [l for l in d if l['devices'] > 0]
print(loc[0]['id'] if loc else '')")
  if [ -n "$LOCID" ]; then
    CODE=$(curl -s -b "$JAR" -o /tmp/loc-dev.json -w "%{http_code}" "$BASE/api/v2/devices?locationId=$LOCID&pageSize=200&plantId=$TESTL2")
    echo "GET devices?locationId=<sede demo> → HTTP $CODE (atteso 200)"
    EXPECTED=$(echo "$LOCJSON" | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
loc = [l for l in d if l['devices'] > 0]
print(loc[0]['devices'])")
    python3 -c "
import json
j = json.load(open('/tmp/loc-dev.json'))
d = j['data']
assert d['total'] == $EXPECTED, f\"total {d['total']} != devices della sede {$EXPECTED}\"
bad = [i for i in d['items'] if i['locationId'] != '$LOCID']
assert not bad, f'{len(bad)} righe di ALTRA sede nella risposta'
print(f\"  {d['total']}/{d['total']} dispositivi della sede · nessuna riga estranea\")
open('/tmp/loc-dev-count.txt','w').write(str(d['total']))"
    # 2. sede inesistente → zero onesti (non tutti, non errori)
    CODE=$(curl -s -b "$JAR" -o /tmp/loc-none.json -w "%{http_code}" "$BASE/api/v2/devices?locationId=inesistente-w18&plantId=$TESTL2")
    echo "GET devices?locationId=inesistente → HTTP $CODE (atteso 200)"
    python3 -c "
import json
d = json.load(open('/tmp/loc-none.json'))['data']
assert d['total'] == 0, d['total']
print('  total 0 (nessun dispositivo di una sede che non esiste)')"
    rm -f /tmp/loc-dev.json /tmp/loc-none.json /tmp/loc-dev-count.txt
  else
    echo "  (nessuna sede con dispositivi nel DB demo: filtro locationId verificato solo via browser e2e)"
  fi
else
  echo "  (impianto test-l2 assente: verifica locationId saltata)"
fi

echo "=== 4. VALIDAZIONE QUERY (zod sui parametri) ==="
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/devices?page=1&pageSize=99999")
echo "devices pageSize=99999 (max 200) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/traffic/series?hours=xyz")
echo "traffic/series hours=xyz → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/tickets?page=-1")
echo "tickets page=-1 → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/cameras/streams?pageSize=5")
echo "cameras/streams pageSize=5 (min 10) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" -o "$OUT" -w "%{http_code}" "$BASE/api/v2/cameras/streams?windowHours=10")
echo "cameras/streams windowHours=10 (min 24) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" "$BASE/api/v2/reports/availability?windowHours=10" -o /dev/null -w "%{http_code}")
echo "reports/availability windowHours=10 (min 24) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" "$BASE/api/v2/reports/availability?windowHours=200" -o /dev/null -w "%{http_code}")
echo "reports/availability windowHours=200 (max 168) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" "$BASE/api/v2/mac-inventory?pageSize=5" -o /dev/null -w "%{http_code}")
echo "mac-inventory pageSize=5 (min 10) → HTTP $CODE (atteso 422)"
CODE=$(curl -s -b "$JAR" "$BASE/api/v2/mac-inventory?page=0" -o /dev/null -w "%{http_code}")
echo "mac-inventory page=0 (min 1) → HTTP $CODE (atteso 422)"

echo ""
echo "=== 5. AUTH: 401 senza sessione (tutte le route) ==="
ROUTES="system/health noc/summary devices devices/$DEV_ID/overview devices/$DEV_ID/ports mac-inventory topology/graph topology/links links/weak events alarms cameras cameras/streams traffic/series plants locations tickets maintenance audit admin/stats search device-groups reports/availability discovery/health adozione discovery/oui event-policies custom-oids config-requests bulk-config firmware playbooks automation-tasks integrations integrations/webhooks reports/sla reports/scheduled audit/export audit/chain audit/chain/verify kb waves cve cve/findings speed-tests admin/users admin/permissions admin/sessions rma?deviceId=x"
FAIL=0
for r in $ROUTES; do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/v2/$r")
  V="OK"; [ "$CODE" != "401" ] && { V="FAIL"; FAIL=1; }
  printf "%-22s → %s %s\n" "$r" "$CODE" "$V"
done
[ "$FAIL" = "0" ] && echo "TUTTE le route rispondono 401 senza sessione" || echo "ATTENZIONE: alcune route non bloccano senza sessione"
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/v2/audit/seal")
V="OK"; [ "$CODE" != "401" ] && V="FAIL"
printf "%-22s → %s %s (POST senza sessione)\n" "audit/seal" "$CODE" "$V"
for r in "plants:POST" "topology/links:POST" "topology/links/purge:POST" "locations/import-kmz/preview:POST" "locations/import-kmz/apply:POST" "discovery/l2/adopt-arp:POST"; do
  path="${r%%:*}"; method="${r##*:}"
  CODE=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$BASE/api/v2/$path")
  V="OK"; [ "$CODE" != "401" ] && V="FAIL"
  printf "%-22s → %s %s (%s senza sessione)\n" "$path" "$CODE" "$V" "$method"
done

rm -f "$JAR" "$OUT"
