#!/usr/bin/env bash
# ================================================================
# FALCO-OS v16 — Pacchetto di certificazione (W6, 16.8)
# ================================================================
# Assembla l'evidenza certificativa della console in un unico ZIP:
#   · contratti API generati dai contratti zod (API_CONTRATTI.md)
#   · audit a11y (A11Y_AUDIT.md, 19 contesti / 0 violazioni)
#   · matrice di parità v15→v16 (PARITA_V15_V16.md)
#   · roadmap/changelog/runbook (ROADMAP_CHANGELOG_RUNBOOK.md)
#   · decisioni architetturali (ARCHITETTURA_E_DECISIONI.md, con D22)
#   · MANIFEST della catena audit: conteggi reali, chainDigest
#     (SHA-256 dei recordHash sigillati in ordine di seq), ultimo
#     sigillo, revisione git
#   · REPORT di verifica crittografica della catena (ricalcolo
#     completo: sigilli/righe/rotture) — catturato dal vivo
# Tutto da dati REALI: nessun valore scritto a mano.
# Uso: bash scripts/gen-cert-package.sh   (richiede dev server :3000
# attivo e credenziali demo in FALCO_DEMO_EMAIL/FALCO_DEMO_PASSWORD)
# ================================================================
set -euo pipefail

BASE=http://localhost:3000
OUT=release
VERSION=$(python3 -c "import json;print(json.load(open('package.json'))['version'])")
STAMP=$(date +%Y%m%d-%H%M%S)
WORK=$(mktemp -d)
JAR="$WORK/cert-cookies.txt"

EMAIL="${FALCO_DEMO_EMAIL:-admin@falco-os.local}"
PASS="${FALCO_DEMO_PASSWORD:-FalcoDemo2026!}"

echo "=== Pacchetto di certificazione FALCO-OS v$VERSION ==="

# --- login demo (audit LOGIN_SUCCESS: tollerato, è l'evidenza dell'operazione) ---
CSRF=$(curl -s -c "$JAR" "$BASE/api/auth/csrf" | python3 -c "import sys,json;print(json.load(sys.stdin)['csrfToken'])")
LOGIN=$(curl -s -b "$JAR" -c "$JAR" -o /dev/null -w "%{http_code}" -X POST "$BASE/api/auth/callback/credentials" \
  --data-urlencode "csrfToken=$CSRF" --data-urlencode "email=$EMAIL" --data-urlencode "password=$PASS")
echo "login: HTTP $LOGIN"
[ "$LOGIN" = "200" ] || [ "$LOGIN" = "302" ] || { echo "ERRORE: login non riuscito"; exit 1; }

# --- 1. manifest catena (conteggi + digest) ---
curl -s -b "$JAR" "$BASE/api/v2/audit/export?limit=1" \
  | python3 -c "
import sys, json
d = json.load(sys.stdin)
assert d['ok'], d
m = d['data']['manifest']
out = {
  'generatedAt': d['asOf'],
  'version': '$VERSION',
  'auditChain': {
    'totalRows': m['totalRows'],
    'sealedRows': m['sealedRows'],
    'unsealedRows': m['unsealedRows'],
    'firstSeq': m['firstSeq'],
    'lastSeq': m['lastSeq'],
    'chainDigest': m['chainDigest'],
    'note': m['note'],
  },
}
print(json.dumps(out, indent=2, ensure_ascii=False))
" > "$WORK/cert-manifest.json"
echo "manifest catena: $(python3 -c "import json;m=json.load(open('$WORK/cert-manifest.json'))['auditChain'];print(f\"{m['sealedRows']}/{m['totalRows']} sigillate · chainDigest {m['chainDigest'][:20]}…\")")"

# --- 2. verifica crittografica dal vivo (ricalcolo completo) ---
curl -s -b "$JAR" -m 120 "$BASE/api/v2/audit/chain/verify" \
  | python3 -c "
import sys, json
d = json.load(sys.stdin)
assert d['ok'], d
v = d['data']
out = {
  'checkedAt': v['checkedAt'],
  'verified': v['verified'],
  'genesisHash': v['genesisHash'],
  'sealsVerified': v['sealsVerified'],
  'sealsTotal': v['sealsTotal'],
  'recordsVerified': v['recordsVerified'],
  'recordsSealed': v['recordsSealed'],
  'unsealedCount': v['unsealedCount'],
  'breakages': v['breakages'][:20],
  'durationMs': v['durationMs'],
}
print(json.dumps(out, indent=2, ensure_ascii=False))
" > "$WORK/cert-chain-verify.json"
echo "verifica catena: $(python3 -c "import json;v=json.load(open('$WORK/cert-chain-verify.json'));print('INTEGRA' if v['verified'] else 'ROTTA', f\"— {v['sealsVerified']}/{v['sealsTotal']} sigilli, {v['recordsVerified']} righe in {v['durationMs']} ms\")")"

# --- 3. stato API (health) come evidenza ambiente ---
curl -s -b "$JAR" "$BASE/api/v2/system/health" > "$WORK/cert-system-health.json"
echo "system health: $(python3 -c "import json;h=json.load(open('$WORK/cert-system-health.json'))['data'];print(f\"v{h['version']} · dbReachable={h['dbReachable']} · replay={h['replay']['enabled']}\")")"

# --- 4. documenti di evidenza ---
for f in API_CONTRATTI.md A11Y_AUDIT.md; do
  [ -f "docs/$f" ] && cp "docs/$f" "$WORK/"
done
for f in PARITA_V15_V16.md ROADMAP_CHANGELOG_RUNBOOK.md ARCHITETTURA_E_DECISIONI.md; do
  [ -f "docs/$f" ] && cp "docs/$f" "$WORK/"
done

# --- 5. revisione codice ---
{
  echo "git HEAD: $(git rev-parse HEAD 2>/dev/null || echo 'n.d.')"
  echo "git branch: $(git branch --show-current 2>/dev/null || echo 'n.d.')"
  echo "data pacchetto: $(date -Is)"
  echo "versione: $VERSION"
} > "$WORK/cert-revision.txt"

# --- 6. digest del pacchetto stesso ---
python3 - "$WORK" <<'PY'
import hashlib, sys, os, json
work = sys.argv[1]
entries = []
for root, _, files in os.walk(work):
    for f in sorted(files):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, work)
        h = hashlib.sha256(open(p, 'rb').read()).hexdigest()
        entries.append({'file': rel, 'sha256': h, 'bytes': os.path.getsize(p)})
with open(os.path.join(work, 'SHA256SUMS.json'), 'w') as fh:
    json.dump({'files': entries}, fh, indent=2)
print('SHA256SUMS.json:', len(entries), 'file')
PY

# --- assembla lo ZIP (MAI il cookie jar di sessione dentro il pacchetto) ---
ZIP="$OUT/FALCO-OS-cert-v$VERSION-$STAMP.zip"
mkdir -p "$OUT"
rm -f "$JAR"
(cd "$WORK" && zip -q -r -9 "/tmp/falco-cert.zip" . -x 'cert-cookies.txt') && mv /tmp/falco-cert.zip "$ZIP"
chmod 644 "$ZIP"
echo "=== pacchetto: $ZIP ($(du -h "$ZIP" | cut -f1)) ==="
rm -rf "$WORK"
