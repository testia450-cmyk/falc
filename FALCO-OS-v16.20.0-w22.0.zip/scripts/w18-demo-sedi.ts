/* W18: sedi DEMO nell'impianto test-l2 del DB placeholder in consegna —
 * così la mappa UISP-like (popup, pannello dispositivi, linee) si prova
 * subito dal Preview anche prima del DB reale. Idempotente. */
import { db } from '../src/lib/db'

async function main() {
  const plant = await db.plant.findFirst({ where: { name: 'test-l2' } })
  if (!plant) throw new Error('plant test-l2 non trovato')

  const ensure = async (identifier: string, name: string, lat: number, lng: number) => {
    const existing = await db.location.findFirst({ where: { identifier, plantId: plant.id } })
    if (existing) { console.log(`esiste già: ${name}`); return existing }
    const loc = await db.location.create({ data: { identifier, name, address: 'demo', plantId: plant.id, lat, lng } })
    console.log(`creata: ${name}`)
    return loc
  }

  const centrale = await ensure('DEMO-CENTRALE', 'Sede Centrale (demo)', 45.4642, 9.1900)
  const distaccata = await ensure('DEMO-DISTACCATA', 'Sede Distaccata (demo)', 45.4680, 9.1820)

  const inCentrale = ['GW-PRINCIPALE', 'SW-CENTRALE', 'NVR-SCALA', 'CAM-1-IPCAM', 'CAM-2-GARDEN', 'AP-TETTO', 'SRV-UTILITY']
  const inDistaccata = ['SW-DISTRIBUZIONE', 'CAM-3-CORTILE', 'AP-MAGAZZINO']
  for (const h of inCentrale) await db.device.updateMany({ where: { hostname: h, plantId: plant.id }, data: { locationId: centrale.id } })
  for (const h of inDistaccata) await db.device.updateMany({ where: { hostname: h, plantId: plant.id }, data: { locationId: distaccata.id } })

  const locs = await db.location.count({ where: { plantId: plant.id } })
  const devs = await db.device.count({ where: { plantId: plant.id, locationId: { not: null }, decommissionedAt: null } })
  console.log(`esito: ${locs} sedi · ${devs} dispositivi assegnati`)
  await db.$disconnect()
}

main()
