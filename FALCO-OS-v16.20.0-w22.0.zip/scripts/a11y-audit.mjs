/* ================================================================
 * a11y-audit.mjs — FALCO-OS v16 — Certificazione accessibilità ripetibile
 * Suite Playwright + axe-core su TUTTE le viste dell'app (WCAG 2.2 AA).
 *
 * Uso:
 *   bun scripts/a11y-audit.mjs            # audit completo (9 viste desktop
 *                                          # 1280×800 + tab secondarie + 3 viste
 *                                          #   mobile 390×844) → report + exit 1
 *                                          #   se ci sono violazioni
 *   bun scripts/a11y-audit.mjs --list     # elenca le viste auditate ed esce
 *
 * Login reale (admin demo) + navigazione per deep link ?view=…, iniezione
 * di axe-core nel contesto di pagina, raccolta violazioni per
 * {vista, viewport} con selettore dei nodi offensori (max 5 per regola).
 *
 * Output:
 *   docs/A11Y_AUDIT.md       report umano (rigenerato a ogni run)
 *   scripts/.a11y-last.json  ultimo run in formato macchina
 *
 * Regole: tag axe ['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa'].
 * Onestà: l'audit copre il DOM reso a riposo (nessuna interazione oltre
 * ai tab): stati di focus/hover e finestre di dialogo aperte NON sono
 * coperti da questa suite e restano verificati a mano (TEST §1).
 * ================================================================ */

import { chromium } from 'playwright'
import { readFileSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const AXE_SRC = readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8')

const BASE = process.env.A11Y_BASE ?? 'http://localhost:3000'
const EMAIL = process.env.A11Y_EMAIL ?? 'admin@falco-os.local'
const PASSWORD = process.env.A11Y_PASSWORD ?? 'FalcoDemo2026!'

/* Viste auditabili: deep link + eventuale label della vista + tab NON di
 * default da attraversare (il tab di default è già nel contesto iniziale). */
const VIEWS = [
  { id: '', label: 'Dashboard', tabs: [] },
  { id: 'rete', label: 'Rete', tabs: [] },
  { id: 'dispositivi', label: 'Dispositivi', tabs: [] },
  { id: 'telecamere', label: 'Telecamere', tabs: [{ name: 'Registro flussi' }] },
  { id: 'allarmi', label: 'Allarmi', tabs: [] },
  { id: 'operazioni', label: 'Operazioni', tabs: [{ name: 'Finestre di manutenzione' }, { name: 'Gruppi dispositivi' }] },
  { id: 'report', label: 'Report', tabs: [] },
  { id: 'amministrazione', label: 'Amministrazione', tabs: [] },
  { id: 'wallboard', label: 'Wallboard', tabs: [] },
]

/* Mobile: le 3 viste più rappresentative (la suite completa per ogni
 * viewport raddoppierebbe il tempo senza coprire regole diverse: axe
 * non ha regole viewport-specifiche oltre a quelle già nei tag). */
const MOBILE_VIEWS = ['', 'dispositivi', 'allarmi']

/* Tema chiaro: le stesse 3 viste (i token di colore cambiano col tema —
 * l'audit DEVE coprire entrambi i temi per la certificazione AA). */
const LIGHT_VIEWS = ['', 'dispositivi', 'allarmi']

const TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa']

const now = () => new Date()

function log(...args) {
  console.log(`[${now().toISOString().slice(11, 19)}]`, ...args)
}

if (process.argv.includes('--list')) {
  for (const v of VIEWS) {
    console.log(`/?view=${v.id || '(dashboard)'} — ${v.label}${v.tabs.length ? ` [tab: ${v.tabs.map((t) => t.name).join(' | ')}]` : ''}`)
  }
  process.exit(0)
}

/* ---------------- Esecuzione axe in pagina ---------------- */

async function runAxe(page) {
  await page.addScriptTag({ content: AXE_SRC })
  return page.evaluate(async (tags) => {
    const results = await window.axe.run(document, {
      runOnly: { type: 'tag', values: tags },
      resultTypes: ['violations'],
    })
    return results.violations.map((v) => ({
      id: v.id,
      impact: v.impact ?? '—',
      help: v.help,
      description: v.description ?? '',
      helpUrl: v.helpUrl ?? '',
      nodes: v.nodes.slice(0, 5).map((n) => ({
        target: Array.isArray(n.target) ? n.target.join(' ') : String(n.target),
        summary: n.failureSummary ?? '',
        html: (n.html ?? '').slice(0, 220),
      })),
      nodeCount: v.nodes.length,
    }))
  }, TAGS)
}

/* ---------------- Audit di una vista (con attraversamento tab) ---------------- */

async function auditView(page, view, viewportLabel) {
  const out = []
  await page.goto(`${BASE}/?view=${view.id}`, { waitUntil: 'domcontentloaded' })
  await page.waitForSelector('main', { timeout: 20_000 })
  await page.waitForTimeout(2500) // idratazione + primo caricamento dati

  const contexts = [{ label: 'default' }]
  for (const tab of view.tabs) {
    try {
      const el = page.getByRole('tab', { name: tab.name, exact: false })
      await el.click({ timeout: 4000 })
      await page.waitForTimeout(1800) // caricamento dati del tab (es. registro flussi)
      contexts.push({ label: `tab:${tab.name}` })
    } catch {
      contexts.push({ label: `tab:${tab.name}`, error: 'tab non raggiungibile in questo run' })
    }
  }

  for (const ctx of contexts) {
    let violations = []
    let error = ctx.error ?? null
    try {
      violations = await runAxe(page)
    } catch (e) {
      error = `axe fallito: ${String(e).slice(0, 120)}`
    }
    out.push({
      view: view.label || 'Dashboard',
      deepLink: `/?view=${view.id}`,
      viewport: viewportLabel,
      context: ctx.label,
      violations,
      error,
    })
    log(
      `${viewportLabel} · ${view.label || 'Dashboard'}${ctx.label !== 'default' ? ` (${ctx.label})` : ''} →`,
      error ? `ERRORE: ${error}` : `${violations.length} violazioni`,
    )
  }
  return out
}

/* ---------------- Main ---------------- */

const browser = await chromium.launch()
const results = []
const pageErrors = []

try {
  /* --- Desktop 1280×800: login una volta sola --- */
  const desktop = await browser.newContext({ viewport: { width: 1280, height: 800 } })
  const page = await desktop.newPage()
  page.on('pageerror', (err) => pageErrors.push(`pagina: ${String(err).slice(0, 160)}`))

  log(`login su ${BASE} (${EMAIL})…`)
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await page.waitForSelector('input[type="email"]', { timeout: 20_000 })
  await page.fill('input[type="email"]', EMAIL)
  await page.fill('input[type="password"]', PASSWORD)
  await page.click('button[type="submit"]')
  await page.waitForSelector('main', { timeout: 20_000 })
  await page.waitForTimeout(2500)
  log('login OK — sessione stabilita')

  for (const view of VIEWS) {
    results.push(...(await auditView(page, view, 'desktop 1280×800')))
  }
  /* --- Dettaglio dispositivo (deep link ?view=dispositivi&device=…):
   * prende un id REALE dall'API con la sessione appena stabilita. --- */
  try {
    const devId = await page.evaluate(async () => {
      const r = await fetch('/api/v2/devices?page=1&pageSize=10')
      if (!r.ok) return null
      const j = await r.json()
      return j?.data?.items?.[0]?.id ?? null
    })
    if (devId) {
      await page.goto(`${BASE}/?view=dispositivi&device=${devId}`, { waitUntil: 'domcontentloaded' })
      await page.waitForSelector('main', { timeout: 20_000 })
      await page.waitForTimeout(3000) // pannello dettaglio + metriche
      let violations = []
      try { violations = await runAxe(page) } catch (e) { log(`axe fallito sul dettaglio: ${String(e).slice(0, 80)}`) }
      results.push({ view: 'Dispositivi (dettaglio)', deepLink: `/?view=dispositivi&device=${devId}`, viewport: 'desktop 1280×800', context: 'quick-look', violations, error: null })
      log(`desktop 1280×800 · Dispositivi (dettaglio ${devId.slice(0, 10)}…) → ${violations.length} violazioni`)
    } else {
      log('dettaglio dispositivo: nessun id dalla API (fetch non-ok o items vuoti)')
    }
  } catch (e) {
    log(`dettaglio dispositivo saltato: ${String(e).slice(0, 80)}`)
  }
  await desktop.close()

  /* --- Mobile 390×844: la sessione NON passa a un nuovo contesto → nuovo login --- */
  const mobile = await browser.newContext({ viewport: { width: 390, height: 844 } })
  const mpage = await mobile.newPage()
  mpage.on('pageerror', (err) => pageErrors.push(`pagina (mobile): ${String(err).slice(0, 160)}`))
  await mpage.goto(BASE, { waitUntil: 'domcontentloaded' })
  await mpage.waitForSelector('input[type="email"]', { timeout: 20_000 })
  await mpage.fill('input[type="email"]', EMAIL)
  await mpage.fill('input[type="password"]', PASSWORD)
  await mpage.click('button[type="submit"]')
  await mpage.waitForSelector('main', { timeout: 20_000 })
  await mpage.waitForTimeout(2500)
  log('login mobile OK')

  for (const viewId of MOBILE_VIEWS) {
    const view = VIEWS.find((v) => v.id === viewId)
    results.push(...(await auditView(mpage, { ...view, tabs: [] }, 'mobile 390×844')))
  }
  await mobile.close()

  /* --- Tema CHIARO 1280×800: nuovo contesto (nuovo login), tema impostato
   * in localStorage PRIMA del caricamento così next-themes parte in chiaro. --- */
  const light = await browser.newContext({ viewport: { width: 1280, height: 800 } })
  const lpage = await light.newPage()
  lpage.on('pageerror', (err) => pageErrors.push(`pagina (chiaro): ${String(err).slice(0, 160)}`))
  await lpage.goto(BASE, { waitUntil: 'domcontentloaded' })
  await lpage.evaluate(() => { try { localStorage.setItem('theme', 'light') } catch { /* noop */ } })
  await lpage.reload({ waitUntil: 'domcontentloaded' })
  await lpage.waitForSelector('input[type="email"]', { timeout: 20_000 })
  await lpage.fill('input[type="email"]', EMAIL)
  await lpage.fill('input[type="password"]', PASSWORD)
  await lpage.click('button[type="submit"]')
  await lpage.waitForSelector('main', { timeout: 20_000 })
  await lpage.waitForTimeout(2500)
  const isLight = await lpage.evaluate(() => document.documentElement.classList.contains('light'))
  log(`login tema chiaro OK (html.light = ${isLight})`)
  for (const viewId of LIGHT_VIEWS) {
    const view = VIEWS.find((v) => v.id === viewId)
    results.push(...(await auditView(lpage, { ...view, tabs: [] }, isLight ? 'chiaro 1280×800' : 'chiaro NON attivo 1280×800')))
  }
  await light.close()
} finally {
  await browser.close()
}

/* ---------------- Report ---------------- */

const totalViolations = results.reduce((acc, r) => acc + r.violations.length, 0)
const auditedContexts = results.filter((r) => !r.error).length
const byRule = new Map()
for (const r of results) {
  for (const v of r.violations) {
    const cur = byRule.get(v.id) ?? { rule: v.id, impact: v.impact, help: v.help, helpUrl: v.helpUrl, occurrences: 0, nodes: 0, where: new Set() }
    cur.occurrences += 1
    cur.nodes += v.nodeCount
    cur.where.add(`${r.view} (${r.viewport}${r.context !== 'default' ? `, ${r.context}` : ''})`)
    byRule.set(v.id, cur)
  }
}

const json = {
  tool: { playwright: 'chromium (headless shell)', axeCore: '4.14.x', tags: TAGS },
  at: now().toISOString(),
  base: BASE,
  contexts: results.length,
  auditedContexts,
  totalViolations,
  pageErrors,
  results,
}
writeFileSync('scripts/.a11y-last.json', JSON.stringify(json, null, 2))

const lines = []
lines.push(`# Audit accessibilità WCAG 2.2 AA — ${now().toISOString().slice(0, 10)}`)
lines.push('')
lines.push(`Strumento ripetibile: \`bun scripts/a11y-audit.mjs\` (Playwright chromium headless + axe-core, tag ${TAGS.join(', ')}).`)
lines.push(`Contesti auditati: **${auditedContexts}/${results.length}** · **violazioni totali: ${totalViolations}** · errori pagina durante l'audit: ${pageErrors.length}.`)
lines.push('')
lines.push('Copertura: 9 viste desktop 1280×800 con attraversamento delle schede non di default (Registro flussi; Finestre, Gruppi) + dettaglio dispositivo (deep link ?device=) + 3 viste mobile 390×844 + 3 viste in tema CHIARO 1280×800, login reale, DOM a riposo dopo caricamento dati. Stati di focus/hover e finestre di dialogo NON coperti (verifica manuale, TEST §1).')
lines.push('')
if (totalViolations === 0) {
  lines.push('## Esito: 🟢 NESSUNA violazione WCAG 2.2 AA rilevata da axe-core in copertura')
} else {
  lines.push('## Esito: 🔴 violazioni rilevate (da correggere o dichiarare)')
  lines.push('')
  lines.push('| Regola axe | impatto | occorrenze | nodi | dove |')
  lines.push('|---|---|---|---|---|')
  for (const r of [...byRule.values()].sort((a, b) => b.occurrences - a.occurrences)) {
    lines.push(`| [${r.rule}](${r.helpUrl}) | ${r.impact} | ${r.occurrences} | ${r.nodes} | ${[...r.where].slice(0, 4).join('; ')}${r.where.size > 4 ? '…' : ''} |`)
  }
  lines.push('')
  lines.push('## Dettaglio per contesto')
  for (const r of results) {
    if (r.violations.length === 0) continue
    lines.push('')
    lines.push(`### ${r.view} — ${r.viewport}${r.context !== 'default' ? ` (${r.context})` : ''}`)
    for (const v of r.violations) {
      lines.push(`- **[${v.id}]** (${v.impact}) ${v.help} — ${v.nodeCount} nodi`)
      for (const n of v.nodes.slice(0, 3)) {
        lines.push(`  - \`${n.target.slice(0, 160)}\`${n.summary ? ` — ${String(n.summary).split('\n')[0].slice(0, 120)}` : ''}`)
      }
    }
  }
}
lines.push('')
lines.push(`JSON macchina dell'ultimo run: \`scripts/.a11y-last.json\` (rigenerato a ogni esecuzione).`)
writeFileSync('docs/A11Y_AUDIT.md', `${lines.join('\n')}\n`)

log(`fine: ${totalViolations} violazioni su ${auditedContexts} contesti → docs/A11Y_AUDIT.md`)
process.exit(totalViolations > 0 ? 1 : 0)
