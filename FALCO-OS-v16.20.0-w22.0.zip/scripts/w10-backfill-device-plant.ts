/* W10 — fase 1: aggiunge Device.plantId NULLABLE via SQL nativo e backfilla:
 *  · con sede → plant DELLA SEDE (UPDATE correlato, esatto);
 *  · orfani → plant dei LORO allarmi (SYS:NEW_HOST dell'impianto che li ha
 *    scoperti), fallback impianto più vecchio (regola default W8).
 * Verifica finale: zero plantId null. */
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

async function main() {
  const cols = await db.$queryRawUnsafe<Array<{ name: string }>>(
    "SELECT name FROM pragma_table_info('Device') WHERE name = 'plantId'",
  )
  if (cols.length === 0) {
    await db.$executeRawUnsafe('ALTER TABLE "Device" ADD COLUMN "plantId" TEXT')
    console.log('colonna Device.plantId aggiunta (nullable)')
  } else {
    console.log('colonna Device.plantId già presente')
  }

  const oldest = await db.plant.findFirst({ orderBy: { createdAt: 'asc' }, select: { id: true, name: true } })
  if (!oldest) throw new Error('nessun Plant nel DB')
  console.log('impianto di fallback (più vecchio):', oldest.name, oldest.id)

  // 1) dispositivi con sede → plant della sede (correlato, esatto)
  const r1 = await db.$executeRawUnsafe(
    'UPDATE "Device" SET "plantId" = (SELECT "plantId" FROM "Location" WHERE "Location"."id" = "Device"."locationId") WHERE "plantId" IS NULL AND "locationId" IS NOT NULL',
  )
  console.log('backfill da sede:', r1)

  // 2) orfani → plant del primo allarme che li riguarda; fallback oldest
  const r2 = await db.$executeRawUnsafe(
    'UPDATE "Device" SET "plantId" = COALESCE((SELECT "plantId" FROM "AlertEvent" WHERE "AlertEvent"."deviceId" = "Device"."id" LIMIT 1), ?) WHERE "plantId" IS NULL',
    oldest.id,
  )
  console.log('backfill orfani (allarmi o fallback):', r2)

  // 3) verifica finale
  const nulls = await db.$queryRawUnsafe<Array<{ n: number }>>('SELECT count(*) AS n FROM "Device" WHERE "plantId" IS NULL')
  const dist = await db.$queryRawUnsafe<Array<{ plantId: string; n: number }>>(
    'SELECT "plantId", count(*) AS n FROM "Device" GROUP BY "plantId"',
  )
  console.log('plantId null residui:', nulls[0]?.n, '| distribuzione:', JSON.stringify(dist, (_k, v) => (typeof v === 'bigint' ? Number(v) : v)))
  if ((nulls[0]?.n ?? 0) > 0) throw new Error('backfill incompleto: esistono Device.plantId null')
}

main().catch((e) => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
