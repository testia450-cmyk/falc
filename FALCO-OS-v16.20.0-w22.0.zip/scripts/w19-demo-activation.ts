/* ================================================================
 * scripts/w19-demo-activation.ts — demo «Attivazione SNMP assistita»
 * ================================================================
 * Aggiunge all'impianto demo «test-l2» (creato da w13-e2e-bootstrap)
 * gli apparati che puntano ai SIMULATORI di verifica:
 *   · SW-ROUTEROS-DEMO  — MikroTik CRS317 (RouterOS): SSH sim
 *     :2222, SNMP sim :1161, credenziali CIFRATE salvate
 *     (admin/simpass) → «usa credenziali salvate» funziona davvero;
 *   · SW-SWOS-DEMO      — MikroTik RB260GSP (SwOS, il caso richiesto
 *     dall'operatore): pannello SwOS sim :8080 (digest admin/''),
 *     SNMP sim :1161 → ricetta mikrotik-swos API HTTP;
 *   · ANT-AIRMAX-DEMO   — Ubiquiti NanoBeam NBE-5AC-Gen2 (airOS):
 *     SSH sim :2222 + credenziali salvate → ricetta ubiquiti-airos
 *     (i 3 campi community/contact/location scritti esplicitamente);
 *   · NVR-HIKVISION-DEMO— Hikvision DS-7616 (nessuna CLI): ricetta
 *     MANUALE → dimostra il percorso MANUAL_REQUIRED in UI;
 *   · DEMO-CAM-PING     — telecamera demo già dichiarata ping-only
 *     (monitorMode='ping', porta 3002 del servizio discovery: viva
 *     in sandbox → la spazzata ping produce campioni VERI).
 *
 * IDEMPOTENTE (skip se hostname già presente) e REVERSIBILE
 * (--revert rimuove SOLO questi apparati; l'audit è append-only).
 * Richiede DEVICE_CREDENTIALS_KEY (per cifrare le credenziali demo):
 * senza chiave l'apparato viene creato SENZA credenziali salvate e
 * lo script lo dichiara (onestà, nessun fallimento silenzioso).
 *
 * Uso: bun run scripts/w19-demo-activation.ts [--revert]
 * ================================================================ */

import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()
const PLANT_NAME = 'test-l2'

/* Cifratura AES-256-GCM come src/lib/crypto.ts (dipendenza minima:
 * lo script gira fuori da Next e non può importare '@/lib/crypto'). */
import { createCipheriv, randomBytes } from 'node:crypto'

function encryptSecret(plain: string): string | null {
  const hex = process.env.DEVICE_CREDENTIALS_KEY
  if (!hex || !/^[0-9a-fA-F]{64}$/.test(hex)) return null
  const key = Buffer.from(hex, 'hex')
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, iv)
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()])
  const tag = cipher.getAuthTag()
  return `${iv.toString('base64')}.${tag.toString('base64')}.${enc.toString('base64')}`
}

const DEMO_DEVICES = [
  {
    hostname: 'SW-ROUTEROS-DEMO',
    ip: '127.0.0.1',
    macAddress: 'CC:CC:CC:00:00:10',
    type: 'SWITCH',
    brand: 'MikroTik',
    model: 'CRS317-1G-16S+',
    snmpPort: 1161,
    sshPort: 2222,
    port: 80,
    username: 'admin',
    plainPassword: 'simpass',
    notes: 'Demo attivazione SNMP: RouterOS via SSH (simulatore :2222), verifica SNMP su :1161. Credenziali demo cifrate salvate.',
    monitorMode: 'full',
  },
  {
    hostname: 'SW-SWOS-DEMO',
    ip: '127.0.0.1',
    macAddress: 'CC:CC:CC:00:00:11',
    type: 'SWITCH',
    brand: 'MikroTik',
    model: 'RB260GSP',
    snmpPort: 1161,
    sshPort: 22,
    port: 8080,
    username: '',
    plainPassword: '',
    notes: 'Demo attivazione SNMP: RB260GSP con SwOS (simulatore pannello :8080, digest admin / password vuota). Il pick automatico sceglie la ricetta SwOS.',
    monitorMode: 'full',
  },
  {
    hostname: 'ANT-AIRMAX-DEMO',
    ip: '127.0.0.1',
    macAddress: '24:A4:3C:00:00:12',
    type: 'AP',
    brand: 'Ubiquiti',
    model: 'NBE-5AC-Gen2',
    snmpPort: 1161,
    sshPort: 2222,
    port: 443,
    username: 'admin',
    plainPassword: 'simpass',
    notes: 'Demo attivazione SNMP: airMAX via SSH (simulatore :2222). airOS esige community/contact/location SCRITTI: la ricetta li valorizza tutti.',
    monitorMode: 'full',
  },
  {
    hostname: 'NVR-HIKVISION-DEMO',
    ip: '127.0.0.1',
    macAddress: 'C0:56:E3:00:00:13',
    type: 'NVR',
    brand: 'Hikvision',
    model: 'DS-7616NI-K2',
    snmpPort: 161,
    sshPort: 22,
    port: 80,
    username: '',
    plainPassword: '',
    notes: 'Demo percorso MANUALE: Hikvision gestito senza CLI — FALCO-OS mostra le istruzioni e marca MANUAL_REQUIRED, mai comandi alla cieca.',
    monitorMode: 'full',
  },
  {
    hostname: 'DEMO-CAM-PING',
    ip: '127.0.0.1',
    macAddress: 'DE:AD:BE:EF:00:99',
    type: 'CAMERA',
    brand: 'Hikvision',
    model: 'DS-2CD2143G2',
    snmpPort: 161,
    sshPort: 22,
    port: 3002,
    username: '',
    plainPassword: '',
    notes: 'Demo monitoraggio PING: telecamera dichiarata monitorMode=ping (porta 3002 viva in sandbox → la spazzata produce campioni reali online).',
    monitorMode: 'ping',
  },
]

async function main() {
  if (process.argv.includes('--revert')) {
    const plant = await db.plant.findFirst({ where: { name: PLANT_NAME } })
    if (!plant) { console.log('REVERT: impianto demo assente'); return }
    const hostnames = DEMO_DEVICES.map((d) => d.hostname)
    const removed = await db.device.deleteMany({ where: { plantId: plant.id, hostname: { in: hostnames } } })
    console.log(`REVERT: ${removed.count} apparati demo rimossi`)
    return
  }

  const plant = await db.plant.findFirst({ where: { name: PLANT_NAME } })
  if (!plant) {
    console.log('ERRORE: impianto «test-l2» assente — lanciare prima scripts/w13-e2e-bootstrap.ts')
    process.exit(1)
  }

  let created = 0
  let skipped = 0
  let credOk = 0

  for (const d of DEMO_DEVICES) {
    const exists = await db.device.findFirst({ where: { plantId: plant.id, hostname: d.hostname }, select: { id: true } })
    if (exists) { skipped++; continue }

    const enc = d.plainPassword !== '' ? encryptSecret(d.plainPassword) : null
    if (d.plainPassword !== '' && enc) credOk++

    await db.device.create({
      data: {
        plantId: plant.id,
        ip: d.ip,
        hostname: d.hostname,
        type: d.type,
        status: 'UNKNOWN',
        connectionType: d.type === 'AP' ? 'RADIO' : 'ETHERNET',
        macAddress: d.macAddress,
        brand: d.brand,
        model: d.model,
        snmpPort: d.snmpPort,
        sshPort: d.sshPort,
        port: d.port,
        username: d.username,
        password: enc ?? '',
        notes: d.notes,
        monitorMode: d.monitorMode,
        snmpCommunityEnc: '',
      },
    })
    created++
    console.log(`  + ${d.hostname} (${d.brand} ${d.model})${enc ? ' · credenziali demo cifrate salvate' : d.plainPassword !== '' ? ' · ATTENZIONE: chiave master assente, credenziali NON salvate' : ''}`)
  }

  console.log(`demo attivazione pronta: ${created} creati, ${skipped} già presenti, ${credOk} con credenziali cifrate`)
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => { void db.$disconnect() })
