// Probe one-shot: copertura vendor/SNMP/modello nel DB reale (sola lettura)
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

const rows = await db.device.findMany({
  select: {
    id: true, type: true, brand: true, model: true, macAddress: true,
    serialNumber: true, firmwareVersion: true, hostname: true, ip: true,
    snmpVersion: true, snmpCommunity: true, snmpCommunityEnc: true,
    status: true, rtspStream: true, ssid: true, signalStrength: true,
    currentFrequency: true, radioMode: true, linkMode: true, antennaType: true,
  },
})

console.log(`TOTALE DEVICE: ${rows.length}`)
console.log(`\n=== COPERTURA CAMPI IDENTIFICATIVI ===`)
const pct = (n: number) => `${n} (${((n / rows.length) * 100).toFixed(0)}%)`
for (const f of ['brand', 'model', 'macAddress', 'serialNumber', 'firmwareVersion', 'hostname', 'snmpVersion', 'snmpCommunityEnc', 'snmpCommunity', 'rtspStream', 'ssid'] as const) {
  const filled = rows.filter((r) => r[f] && String(r[f]).trim() !== '').length
  console.log(`${f.padEnd(20)} ${pct(filled)}`)
}

console.log(`\n=== PER TIPO (famiglia) ===`)
const byType = new Map<string, { total: number; brand: number; model: number; mac: number; snmp: number }>()
for (const r of rows) {
  const t = r.type || 'NULL'
  const e = byType.get(t) || { total: 0, brand: 0, model: 0, mac: 0, snmp: 0 }
  e.total++
  if (r.brand) e.brand++
  if (r.model) e.model++
  if (r.macAddress) e.mac++
  if (r.snmpVersion) e.snmp++
  byType.set(t, e)
}
for (const [t, e] of [...byType.entries()].sort((a, b) => b[1].total - a[1].total)) {
  console.log(`${t.padEnd(10)} tot=${String(e.total).padStart(3)} brand=${String(e.brand).padStart(3)} model=${String(e.model).padStart(3)} mac=${String(e.mac).padStart(3)} snmpVer=${String(e.snmp).padStart(3)}`)
}

console.log(`\n=== BRAND x TIPO (radio: AP/STA + GATEWAY; video: CAMERA/LPR; switch) ===`)
const radioRows = rows.filter((r) => ['AP', 'STA', 'GATEWAY', 'BRIDGE', 'REPEATER'].includes(r.type || ''))
const videoRows = rows.filter((r) => ['CAMERA', 'LPR', 'NVR'].includes(r.type || ''))
const switchRows = rows.filter((r) => r.type === 'SWITCH')
const tally = (rs: typeof rows, label: string) => {
  console.log(`\n--- ${label} (${rs.length}) ---`)
  const m = new Map<string, number>()
  for (const r of rs) m.set(r.brand || '(nessun brand)', (m.get(r.brand || '(nessun brand)') || 0) + 1)
  for (const [b, c] of [...m.entries()].sort((a, b) => b[1] - a[1])) console.log(`  ${b.padEnd(25)} ${c}`)
}
tally(radioRows, 'RADIO (AP/STA/GATEWAY/BRIDGE/REPEATER)')
tally(videoRows, 'VIDEO (CAMERA/LPR/NVR)')
tally(switchRows, 'SWITCH')

console.log(`\n=== MODELLI FOTO/VIDEO (primi 15 con modello) ===`)
for (const r of videoRows.filter((x) => x.model).slice(0, 15)) {
  console.log(`  [${r.type}] ${r.brand || '?'} ${r.model} | mac=${r.macAddress || '-'} | ser=${r.serialNumber || '-'} | fw=${r.firmwareVersion || '-'} | rtsp=${r.rtspStream ? 'sì' : '-'}`)
}

console.log(`\n=== MODELLI RADIO (primi 15 con modello) ===`)
for (const r of radioRows.filter((x) => x.model).slice(0, 15)) {
  console.log(`  [${r.type}] ${r.brand || '?'} ${r.model} | ssid=${r.ssid || '-'} | freq=${r.currentFrequency || '-'} | radioMode=${r.radioMode || '-'} | linkMode=${r.linkMode || '-'} | ant=${r.antennaType || '-'}`)
}

console.log(`\n=== SNMP VERSION DistribUZIONE ===`)
const sv = new Map<string, number>()
for (const r of rows) sv.set(r.snmpVersion || '(vuoto)', (sv.get(r.snmpVersion || '(vuoto)') || 0) + 1)
for (const [v, c] of sv) console.log(`  snmpVersion=${v}: ${c}`)

console.log(`\n=== POLLING SCHEDULE (tipo gruppo) ===`)
const ps = await db.pollingSchedule.groupBy({ by: ['metricGroup'], _count: true })
for (const g of ps) console.log(`  ${g.metricGroup}: ${g._count}`)

console.log(`\n=== SNMPTEMPLATES / OUI / IPAM ===`)
const [tpl, sub, ip] = await Promise.all([
  db.snmpVendorTemplate?.count?.() ?? -1,
  db.subnet?.count?.() ?? -1,
  db.ipAddress?.count?.() ?? -1,
])
console.log(`  SnmpVendorTemplate: ${tpl}`)
console.log(`  Subnet (IPAM): ${sub}`)
console.log(`  IpAddress (IPAM): ${ip}`)

await db.$disconnect()
