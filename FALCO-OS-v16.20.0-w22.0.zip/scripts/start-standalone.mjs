#!/usr/bin/env node
/* ================================================================
 * FALCO-OS v16.18.1 — avvio produzione cross-platform
 * Sostituisce «NODE_ENV=production bun .next/standalone/server.js | tee
 * server.log» (env inline e tee sono sintassi Unix). Qui: NODE_ENV/PORT/
 * HOSTNAME impostati in modo portabile, server standalone lanciato con
 * l'interprete corrente (bun o node), output duplicato su server.log.
 * ================================================================ */
import { spawn } from 'node:child_process'
import { createWriteStream, existsSync } from 'node:fs'
import { join } from 'node:path'

const root = process.cwd()
const serverJs = join(root, '.next', 'standalone', 'server.js')

if (!existsSync(serverJs)) {
  console.error('[start] .next/standalone/server.js assente: eseguire prima «bun run build»')
  process.exit(1)
}

process.env.NODE_ENV = 'production'
process.env.PORT = process.env.PORT || '3000'
process.env.HOSTNAME = process.env.HOSTNAME || '127.0.0.1'

const log = createWriteStream(join(root, 'server.log'), { flags: 'a' })
const child = spawn(process.execPath, [serverJs], {
  stdio: ['inherit', 'pipe', 'pipe'],
  env: { ...process.env },
})

for (const stream of [child.stdout, child.stderr]) {
  stream.on('data', (chunk) => {
    process.stdout.write(chunk)
    log.write(chunk)
  })
}
child.on('exit', (code) => {
  log.end()
  process.exit(code ?? 0)
})
