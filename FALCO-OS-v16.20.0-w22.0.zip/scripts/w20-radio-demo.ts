/* ================================================================
 * scripts/w20-radio-demo.ts — demo telemetria radio (W20)
 * ================================================================
 * Aggiunge all'impianto demo «test-l2» (creato da w13-e2e-bootstrap)
 * l'antenna PTP che punta allo scenario «radio» del simulatore SNMP:
 *   · ANT-PTP-LINK — MikroTik SXT SA 5 ac (RouterOS): SNMP sim :1163
 *     con tabelle wireless mtxrWl REALI (stat: SSID/segnale/CCQ/SNR/
 *     frequenza/tx-rx/noise floor; registration: UN client → la sonda
 *     deduce radioMode=ap + linkMode=PTP), salute (mtxrHl +
 *     HOST-RESOURCES: CPU/RAM), ether1 1000 full-duplex (EtherLike).
 *
 * Prerequisito (simulatore in ascolto su :1163):
 *   bun mini-services/discovery-service/sim/snmp-sim.ts 1163 radio
 *
 * Poi la verifica: POST /api/v2/discovery/radio su questo apparato
 * (dal pannello «Telemetria radio» della scheda o via API).
 *
 * IDEMPOTENTE (skip se hostname già presente) e REVERSIBILE
 * (--revert rimuove SOLO questo apparato; l'audit è append-only).
 *
 * Uso: bun run scripts/w20-radio-demo.ts [--revert]
 * ================================================================ */

import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()
const PLANT_NAME = 'test-l2'

const DEVICE = {
  hostname: 'ANT-PTP-LINK',
  ip: '127.0.0.1',
  macAddress: 'D4:CA:6D:00:00:21',
  type: 'AP',
  brand: 'MikroTik',
  model: 'SXT SA 5 ac',
  snmpPort: 1163,
  sshPort: 22,
  port: 80,
  notes: 'Demo telemetria radio W20: antenna PTP (scenario «radio» del simulatore SNMP :1163) — SSID/segnale/CCQ/CPU/RAM/client con provenance per campo.',
  monitorMode: 'full',
}

async function main() {
  if (process.argv.includes('--revert')) {
    const plant = await db.plant.findFirst({ where: { name: PLANT_NAME } })
    if (!plant) { console.log('REVERT: impianto demo assente'); return }
    const removed = await db.device.deleteMany({
      where: { plantId: plant.id, hostname: DEVICE.hostname },
    })
    console.log(`REVERT: ${removed.count} apparato rimosso`)
    return
  }

  const plant = await db.plant.findFirst({ where: { name: PLANT_NAME } })
  if (!plant) {
    console.log('ERRORE: impianto «test-l2» assente — lanciare prima scripts/w13-e2e-bootstrap.ts')
    process.exit(1)
  }

  const exists = await db.device.findFirst({
    where: { plantId: plant.id, hostname: DEVICE.hostname },
    select: { id: true },
  })
  if (exists) {
    console.log(`già presente: ${DEVICE.hostname} — nessuna azione`)
    return
  }

  const created = await db.device.create({
    data: {
      plantId: plant.id,
      ip: DEVICE.ip,
      hostname: DEVICE.hostname,
      type: DEVICE.type,
      status: 'UNKNOWN',
      connectionType: 'RADIO',
      macAddress: DEVICE.macAddress,
      brand: DEVICE.brand,
      model: DEVICE.model,
      snmpPort: DEVICE.snmpPort,
      sshPort: DEVICE.sshPort,
      port: DEVICE.port,
      username: '',
      password: '',
      notes: DEVICE.notes,
      monitorMode: DEVICE.monitorMode,
      snmpCommunityEnc: '',
    },
  })
  console.log(`+ ${created.hostname} (${created.brand} ${created.model}) · SNMP :${created.snmpPort} (scenario «radio» del simulatore)`)
  console.log('verifica: POST /api/v2/discovery/radio { deviceId: ' + created.id + ' } — attenderla con il simulatore attivo su :1163')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => { void db.$disconnect() })
