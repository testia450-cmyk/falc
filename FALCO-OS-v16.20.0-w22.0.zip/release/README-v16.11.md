# FALCO-OS v16.11.0-w9.0 — Onda W9: Topologia «a raggiera»

**Richiesta operatore (30/10/2026):** «una topologia tipo cosi» — con screenshot di riferimento
che mostrava una rappresentazione fan-out: radice a sinistra, card delle sedi impilate a destra,
linee tratteggiate colorate per stato, conteggi dispositivi per sede.

## Cosa trovi dentro

**Vista Rete → Topologia — la raggiera è ora il DEFAULT.**

| Elemento | Com'è |
|---|---|
| Radice | Card prominente a sinistra, centrata verticalmente: icona torre colorata per stato, hostname + IP, badge «radice scelta dall'operatore» o «radice inferita», contatori totali |
| Card sedi | Una per sede con i dispositivi raggruppati per appartenenza: icona torre colorata per salute aggregata, nome, «M/N online · K offline · D degradati», badge GIÙ/partial, testo sfumato per le sedi tutte giù |
| Connettori | Linee bezier **tratteggiate** colorate per stato (verde/ambra/rosso) dalla radice a ogni sede — come l'immagine. Su mobile: riga tratteggiata verticale |
| Espansione | Click sulla sede → i suoi dispositivi (stato, tipo, segnale radio, «N a valle», **chip della fonte** del collegamento: MNDP/LLDP/UISP/… veri dal DB). Click sul dispositivo → quick-look; click sul chip → dettaglio arco |
| Profondità | I dispositivi con figli si espandono a loro volta in sottogruppi per sede (guide tratteggiate indentate) |
| «Espandi tutto» | Un click per le 41 sedi (o comprimi tutto) |
| Onestà | I dispositivi non raggiunti dall'albero stanno nella sezione dichiarata «Fuori dall'albero» — mai nascosti né appesi a caso |
| Toggle | **Raggiera \| Grafo** accanto ai filtri fonti: il canvas ELK di W8 resta disponibile; scelta nel deep link `?view=rete&vista=grafo` |

## Verifica (disciplina W9)

- `bunx tsc --noEmit` → 0 errori · `bun run lint` → 0 errori
- `scripts/verify-api.sh` → **exit 0, 205 controlli verdi** (usato anche come preriscaldo route)
- Browser e2e desktop 1440 + mobile 390: raggiera con root «Router SETI» e 4 sedi reali; linee
  verde/ambra/rosse verificate visivamente; espansione → quick-look → dettaglio arco MNDP;
  toggle grafo/raggiera con URL; filtro fonti integrato; **zero errori console**; **nessun overflow
  orizzontale a 390px**
- DB **pristine**: 200 dispositivi · 892 link · 0 confermati · 41 sedi · 1 impianto · 1 utente
  (solo righe audit di login)

## Note tecniche

- **Nessuna route API nuova**: la raggiera consuma lo STESSO contratto `/api/v2/topology/graph`
  di W8 (117 route documentate invariate) — stessa query TanStack, cache condivisa.
- Connettori SVG misurati dal vivo (rAF + ResizeObserver) con **doppio gate**: viewport ≥768
  (coerente col CSS `md:`) E contenitore ≥520px — sidebar+aside restringono la vista anche a
  schermo intero (difetto reale trovato e corretto in verifica: la prima soglia a 768 sul
  contenitore lasciava la raggiera senza linee).
- Dichiarazione (D2): la raggiera raggruppa per SEDE DI APPARTENENZA dei dispositivi (fedele
  all'immagine), non per percorso nell'albero; la struttura padre/figlio resta navigabile
  espandendo i dispositivi con «N a valle» e nel grafo ELK. Il motore topologico v15 non gira in
  riproduzione: l'albero resta quello dei collegamenti in inventario per le fonti attive.
- Runbook §4 aggiornato con la **ricetta anti-OOM consolidata** (5 kill diagnosticati in sessione:
  avvio double-fork orfanizzante → preriscaldo route via verify-api.sh → solo poi il browser).

## Avvio (sandbox)

```bash
cd /home/z/my-project
( setsid bun run dev > /tmp/falco-dev.log 2>&1 & )
# realtime :3001 e discovery :3002 vedi runbook §4
```

Login demo: `admin@falco-os.local` / `FalcoDemo2026!`
