# FALCO-OS v16.6.0-w3.4 — NOC (release sorgente)

Release del **27/10/2026 (sera)** — **DISCOVERY & ADOZIONE**: i motori di rete ATTIVI del vecchio software v15.16.0 (che nella sandbox replay non giravano) sono stati **portati in v16 come capacità viva** e cablati nel NOC, su richiesta diretta dell'operatore: «riesci a fare scansione rete? Adozione, leggere SNMP, OUI, marche vendor? ONVIF e brand di telecamere con modello e dati? Switch con vendor e SNMP completi? Antenne Ubiquiti/MikroTik/Cambium/Ceragon?».

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.6.0-w3.4 (rispetto a 16.5.0-w3.3)

- **Mini-service `discovery-service` (porta 3002 fissa)** — motori v15.16.0 portati con copia fedele dei file originali dove possibile:
  - **Scansione di rete**: sweep TCP-connect multi-porta (`pingHost` di v15: UP = almeno una porta risponde, latenza = minima; porte v15 incluse 8291 Winbox, 37777 Hikvision, 34567 Dahua, 5000 LPR, 161 SNMP); CIDR fino a 256 host.
  - **SNMP v1/v2c/v3** (lib `net-snmp`): sysDescr/sysObjectID/sysName/sysLocation/sysContact/sysUpTime + walk ifDescr (max 64 interfacce) + MAC da ifPhysAddress; **vendor da enterprise OID** (48 voci della mappa v15: Cisco 9, Ubiquiti 41112, MikroTik 350/14988, Cambium 17713…).
  - **ONVIF** scritto a mano come in v15: GetDeviceInformation con WS-Security UsernameToken PasswordDigest (SHA1), fallback porta 8899 (Dahua) → **Produttore/Modello/Firmware/Seriale/HardwareId**; WS-Discovery UDP 3702 (Probe NetworkVideoTransmitter).
  - **OUI IEEE**: database v15 INTEGRALE (10.679 prefissi · 101 brand, longest-prefix MA-S 36→MA-M 28→MA-L 24, file verificato byte a byte).
  - **Sweep UDP vendor**: Ubiquiti discovery (porta 10001, TLV MAC/nome/firmware/platform, zero credenziali) e **MNDP MikroTik** (UDP 5678).
  - **Fusione evidenze** con priorità v15: ONVIF > SNMP > banner > porte → classificazione {tipo, brand, modello, confidenza alta/media/bassa, catena di evidenze}.
  - Onestà strutturale: timeout = timeout, rete muta = lista vuota, MAI dati inventati; guardia globale ~15 s.
- **API v2 (37 route totali)**: `GET /api/v2/discovery/health` (stato+capacità+conteggio OUI) · `POST /api/v2/discovery/scan` (audit DISCOVERY_SCAN) · `POST /api/v2/discovery/probe` (sonda in SOLA LETTURA) · `GET /api/v2/discovery/oui` (MAC→vendor, 404 onesto) · **`GET/POST /api/v2/adozione`** — coda adozione portata da v15 §13.8: **orfani senza sede (i 30 REALI del DB egidio** — host scoperti SYS:NEW_HOST mai adottati) + «da confermare» + 41 sedi reali; `adopt` (role ≥ TECNICO, audit ADOZIONE_ADOPT, sede verificata, provenienza manuale) e `dismiss` (audit ADOZIONE_DISMISS); **nessuna auto-adozione: la decisione resta umana**. Proxy con auth a monte; servizio spento → 503 SERVICE_DOWN (il NOC continua).
- **UI — quarto tab «Scansione & Adozione» in Operazioni**: striscia stato motore (badge + 7 chip capabilities + «OUI IEEE: 10.679 prefissi · 101 brand»), form scansione CIDR/porte con banner onestà sandbox, tabella host vivi con latenza e porte, dialog «Identifica apparato» (classificazione + blocchi ONVIF/SNMP/OUI/banner + catena di evidenze + «sonda in sola lettura»), **coda adozione** con KPI reali, tabella scrollabile, selettore delle 41 sedi reali e AlertDialog di conferma → toast + invalidazione dispositivi.
- **Verifiche**: ciclo adozione end-to-end da browser (30→29 orfani → REVERT, DB lasciato PRISTINO); scansione 127.0.0.1/32 → 3 servizi della sandbox trovati; SNMP/ONVIF testati contro apparati di laboratorio reali (RouterOS → MikroTik da OID 14988; device-service ONVIF → marca/modello/seriale); OUI testato sui MAC reali del DB (Dahua/Ubiquiti/Hikvision); `verify-api.sh` §3e (10 controlli nuovi) + 401 sulle 3 rotte nuove — tutto verde; tsc 0 errori; lint 0 errori (1 warning preesistente); mobile 390=390; zero errori console.
- **PARITÀ_V15_V16 aggiornata** (intestazione 16.6 + voci §1.2/§1.6): coda adozione orfani CONSEGNATA; resta ⚠️ solo la parte duplicati/lifecycle. **D20 aggiornata + D21** in ARCHITETTURA: il motore OUI REALE è una capacità viva on-demand, mai retro-dato sui dati congelati.

## Risposte alle domande dell'operatore (riepilogo)

| Domanda | Risposta |
|---|---|
| Scansione rete? | **SÌ** — sweep TCP multi-porta portato da v15 (sandbox: 127.0.0.1; su sito: rete impianto) |
| Adozione? | **SÌ** — coda orfani (30 reali) + «da confermare», azione umana con audit |
| SNMP? | **SÌ** — v1/v2c/v3, sysDescr/OID/interfacce/MAC, vendor da enterprise OID (48 voci v15) |
| OUI / marche vendor? | **SÌ** — 10.679 prefissi IEEE · 101 brand (DB v15 integrale, longest-prefix) |
| ONVIF + brand telecamere con modello e dati? | **SÌ** — GetDeviceInformation (marca/modello/fw/seriale/hw) + WS-Discovery; i dati STORICI di 102 apparati video (Hikvision 59, Axis 18, Dahua 17…) sono già nel DB |
| Switch vendor+SNMP completi? | **SÌ** — sonda standard (IF-MIB sys*) su ogni vendor; 15 MikroTik + 1 Hikvision nell'impianto reale, tutti con brand/MAC/SNMP registrati |
| Antenne Ubiquiti/MikroTik/Cambium/Ceragon? | **SÌ** — Ubiquiti (UDP 10001 + MIB airMAX), MikroTik (MNDP 5678 + MIB mtxr), Cambium (OID 17713/ePMP), Ceragon (LLDP+standard, come v15: nessuna MIB proprietaria). Nell'impianto reale: 57 Ubiquiti + 7 MikroTik radio, 0 Cambium/Ceragon |

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: 37 rotte con contratti zod; viste: Dashboard, Rete (Topologia|Mappa|MAC), Dispositivi (scheda 6 tab), Telecamere (2 tab), Allarmi, **Operazioni (4 tab con Scansione & Adozione)**, Report (+ disponibilità), Amministrazione + Wallboard)
- `prisma/schema.prisma` — schema del DB reale (123 modelli, invariato dall'import)
- `mini-services/realtime-service/` — socket.io (porta 3001, tick 30 s in **modalità riproduzione dichiarata**)
- `mini-services/discovery-service/` — **motori di rete v15** (porta 3002: scansione, SNMP, ONVIF, OUI, UDP Ubiquiti/MNDP/WS-Discovery; `bun install` scarica net-snmp)
- `docs/` — 7 documenti vivi (AUDIT, ARCHITETTURA fino a **D21**, DESIGN_SYSTEM, API_CONTRATTI generato 37 rotte, TEST, ROADMAP_CHANGELOG fino a 16.6.0, PARITA_V15_V16 aggiornata)
- `worklog.md` — registro di lavoro (Task 1–28)
- `scripts/` — gen-api-contracts.ts, verify-api.sh (§3e incluso), a11y-audit.mjs
- `.env.example`, `db/LEGGO.md`

**NON incluso**: `node_modules/`, `.next/`, `db/custom.db`, `.env` (segreti), `bun.lock` dei mini-services (si rigenera con `bun install`).

## Requisiti

- Node 20+ / Bun 1.1+ · `bun install` (radice) · DB reale in `db/custom.db` + `.env` (vedi `.env.example`) · `bunx prisma generate` · `bun run dev` (:3000) · `mini-services/realtime-service`: `bun --hot index.ts` (:3001, stessa DATABASE_URL) · `mini-services/discovery-service`: `bun install && bun run dev` (:3002, facoltativo ma consigliato).

## Verifica (ripetibile)

```bash
bash scripts/verify-api.sh        # login reale + 25 GET + cicli (manutenzione, gruppi, discovery & adozione §3e) + 422 + 401 — tutto verde
bun scripts/a11y-audit.mjs        # suite a11y WCAG 2.2 AA: 0 violazioni su 19 contesti
bunx tsc --noEmit && bun run lint # 0 errori (1 warning noto preesistente)
curl -s http://127.0.0.1:3002/health   # motore discovery: capabilities + OUI 10.679
```
