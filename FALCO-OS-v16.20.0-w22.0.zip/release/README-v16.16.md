# FALCO-OS v16.16.0-w17.0 — NOC (release sorgente)

Release del **31/10/2026** — **I DUE RESIDUI DICHIARATI, CHIUSI**: la **candidatura ARP diventa adozione a un click** (il report batch «Tutti gli switch» elencava i MAC→IP non in inventario come candidati «solo report» — ora il pulsante **«Adotta»** crea il dispositivo con la dichiarazione umana) e la **disponibilità arriva PER SEDE** (la roadmap W2 la dichiarava: `byLocation` nel report disponibilità) — su richiesta operatore «rilascia zip aggiornato e poi proseguire».

> In più, trovato in verifica: **fix globale dei dialog alti** (`DialogContent` senza cap di altezza tagliava la testata su mobile — ora `max-h` + scroll interno, ogni dialog dell'app ne beneficia), e lo **ZIP v16.15 corretto** (il pacchetto precedente escludeva il `custom.db` placeholder che LEGGO.md documentava come incluso: il download non partiva senza `db:push`; mancava anche il 6° screenshot di evidenza).

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.16.0-w17.0 (rispetto a 16.15.0-w13.0-w16.0)

### 1 · W17-a — Adozione candidato ARP («il pulsante che mancava»)

- **Tabella candidati con azione**: il report batch elenca i MAC con IP noto NON in inventario in una tabella (MAC · IP · visto da · azione) con scroll interno, al posto del paragrafo elenco. Il pulsante **«Adotta»** appare ai ruoli TECNICO+ (i CLIENTE vedono «sola lettura»); dopo l'adozione la riga si spegne col badge «adottato».
- **`POST /api/v2/discovery/l2/adopt-arp`** (role ≥ TECNICO): crea il dispositivo dalla dichiarazione dell'operatore.
  - **Il server NON sceglie nulla**: MAC e IP arrivano dal report (evidenza di sonda reale, ri-normalizzati lato server); hostname/tipo/collegamento/sede/note sono la dichiarazione umana; il **vendor IEEE** arriva dal database OUI (10.679 prefissi, lookup best-effort: un MAC fuori banca dati resta vendor «», mai inventato); `lastSeenAt` arriva dalla riga di evidenza (ArpEntry → FdbObservation → null); **baselineUntil 24 h** come l'RMA (anti falsi allarmi post-provisioning).
  - **Guardie a valle** (il mondo cambia tra il report e il click): MAC già in inventario → `422 MAC_INVENTORY` col device che lo porta (se dismesso: si indica il flusso RMA); IP già di un ALTRO device attivo → `422 IP_IN_USE` che indica l'RMA (mai doppioni); sede verificata per impianto; corpo zod stretto (regex MAC e IPv4, hostname 1-80, enum tipi completo inclusi UPS/PRINTER/PBX/PHONE/NAS/MODEM, connectionType dichiarata dall'operatore).
  - **Audit `ADOZIONE_ARP_ADOPT`** (in transazione con la creazione): evidenza (ARP/FDB/REPORT), seenBy, vendor OUI, lastSeenAt, decisione — la catena completa della scelta umana.
  - **Le osservazioni ARP/FDB NON vengono toccate**: sono il registro append-only delle sonde; il nuovo dispositivo con `macAddress` noto viene riconosciuto da solo ai prossimi giri (il join MAC↔inventario della tab MAC e i candidati del batch successivo si chiudono da sé).
- **Dialog di adozione**: vendor IEEE mostrato come EVIDENZA con **tipo suggerito** dalla categoria OUI (link «usa» — la scelta resta umana), hostname pre-compilato NEUTRO (`nuovo-<ultime5>`), sede facoltativa (dalla coda adozione: «assegnabile anche dopo»), note, spiegazione della finestra di assestamento. Invalidazioni a valle: albero, link, dispositivi, coda adozione.
- **Simulatore centrale +1 voce ARP**: `192.168.88.61` con prefisso IEEE reale (HP Inc.) NON in inventario — il DB demo in consegna mostra SUBITO un candidato adottabile: **il pulsante si può provare per intero dal Preview**.

### 2 · W17-b — Disponibilità PER SEDE (roadmap W2 chiusa)

- **`byLocation` nel report disponibilità** (`GET /api/v2/reports/availability`): una riga per sede con apparati, **con dati / senza dati** (i «senza dati» contati a parte: MAI azzerati né cento inventati), **disponibilità media delle SOLE righe con campioni**, **peggiore apparato con hostname e valore**, campioni totali, copertura reale per sede. Media semplice dichiarata (pesarla per i campioni sposterebbe il numero verso chi è campionato più spesso).
- **Ordinamento onesto**: peggior disponibilità prima; sedi senza dati dopo; **«senza sede» SEMPRE ultima** (l'orfanotrofio non è una sede).
- **UI**: tabella per sede sopra quella per dispositivo nella sezione Disponibilità del Report (scroll interno, colori SOLO descrittivi del numero — SLADefinition = 0: nessuna soglia inventata).
- `AvailabilityRow` porta ora anche `locationId` (chiave del raggruppamento, additivo).

### 3 · Fix globale trovato in verifica

- **`DialogContent` senza cap di altezza né scroll** (shadcn base): i dialog PIÙ ALTI della viewport — il batch L2 su mobile 390px, cresciuto con la tabella candidati — tagliavano la testata sopra il viewport senza via di scroll (misurato: box 1104px su viewport 844px). Ora `max-h-[calc(100dvh-2rem)] overflow-y-auto` nel componente base: dopo il fix il dialog sta in 16→828 con scroll interno. **Ogni dialog dell'app ne beneficia** (i dialog corti non cambiano di una pixel).

### 4 · ZIP v16.15 corretto (pre-work, stessa versione)

- Il pacchetto originale escludeva `db/custom.db` placeholder (il pattern «senza db reale» era giusto per il DB da 292 MB, ma il placeholder da 2,1 MB con l'impianto test-l2 è quello che LEGGO.md documenta come incluso: senza, il download non partiva senza `db:push`) e il 6° screenshot evidence (`dashboard-finale.png`, creato 2 minuti dopo lo zip). Rigenerato: 488 voci · custom.db incluso · 6/6 screenshot · `unzip -t` OK. Stessa versione 16.15.0: il contenuto sorgente era identico al commit.

## Verifica (disciplina di sempre)

- **API e2e con login reale**: adozione → response con vendor IEEE «HP Inc.», evidenza `ARP`, seenBy `SW-CENTRALE`, baseline 24h → le 4 guardie (`MAC_INVENTORY` su doppione, `IP_IN_USE` su IP altrui con indicazione RMA, `BAD_BODY` su MAC rotto, `UNAUTHORIZED` senza sessione) → audit verificato via Prisma (dettagli completi) → **REVERT** con device rimosso e audit append-only conservato.
- **Matematica byLocation al centesimo**: campioni seminati (SW-CENTRALE loss 0/2/4/6 → 97%; GW-PRINCIPALE 10/20 → 85%; AP-TETTO 0,5/0,2 → 99,65%) → gruppo «senza sede»: media **93.88%** = (97+85+99.65)/3 esatto, peggiore GW-PRINCIPALE 85.00%, 3 con dati + 7 n.d. → campioni rimossi → post-revert onesto `n.d.`.
- **Browser e2e (agent-browser) desktop + 390px**: tabella candidati nel report batch → «Adotta» → dialog con vendor IEEE e suggerimento tipo → toast «'stampante-e2e-w17' adottato · 00:1F:29:61:14:61 · 192.168.88.61 · HP Inc. — finestra di assestamento 24 h» → badge «adottato» → tabella per sede in Report (93.88% esatto in UI) → dialog mobile PRIMA/DOPO il fix scroll (misurato via eval) → zero errori console/pagina.
- **verify-api.sh**: **§3l NUOVA** (auto-pulente: 422 onesti, guardia MAC dal device REALE di inventario, ciclo completo adotta→verifica→doppione→REVERT via bun, audit conservato) + **asserzioni byLocation** nella sezione report (somma sedi = total, contatori coerenti, «senza sede» ultima) + route nella lista 401 senza sessione.
- tsc **0 errori** · lint **0 errori** (1 warning noto TanStack Table, documentato).

## Contenuto del pacchetto

- Sorgente completo dell'app (488 voci): `src/` (Next.js 16 App Router, 86 route API v2), `mini-services/` (realtime :3001, discovery :3002 con sonde e simulatore SNMP a due scenari), `prisma/schema.prisma` (125 modelli), `scripts/` (verify-api.sh, prepare-real-db.ts, w13-e2e-bootstrap.ts), `docs/` (ROADMAP/PARITA/API_CONTRATTI/ARCHITETTURA…), `release/evidence/w17/` (4 screenshot di questa onda), `db/custom.db` placeholder con impianto `test-l2` + admin demo.
- **NON inclusi** (come da pattern): `node_modules/`, `.next/`, `.git/`, `.env` (vedi `.env.example`), `upload/`, DB reale dell'operatore.

## Avvio rapido (come 16.15)

```bash
bun install
cp .env.example .env            # compilare le 4 chiavi (vedi sotto)
bunx prisma generate            # client Prisma (già schema 125 modelli)
bun run dev                     # app su :3000
# mini-servizi (altri terminali):
cd mini-services/realtime-service && bun run dev     # :3001
cd mini-services/discovery-service && bun run dev    # :3002
# simulatori SNMP per provare L2/ARP/STP/candidati:
cd mini-services/discovery-service
bun sim/snmp-sim.ts 1161 centrale
bun sim/snmp-sim.ts 1162 distribuzione
```

`.env` richiede 4 righe: `DATABASE_URL` (assoluta, verso `db/custom.db`), `NEXTAUTH_SECRET` (senza questa il login dà 200 ma TUTTE le API rispondono 401), `NEXTAUTH_URL` (opzionale in dev), `DEVICE_CREDENTIALS_KEY` (AES integrazioni).

Login demo (DB placeholder): `admin@falco-os.local` / `FalcoDemo2026!` — impianto `test-l2` (10 apparati puntano ai simulatori). **Per provare l'adozione ARP**: vista Rete → «Ricostruisci L2» → modalità «Tutti gli switch» → «Scansiona» → riga `00:1F:29:61:14:61 → 192.168.88.61` → «Adotta».

## DB reale dell'operatore (~292 MB, quando arriva)

Come 16.15: copiare il file in `db/custom.db` e **`bun scripts/prepare-real-db.ts --yes`** (migrazione puramente additiva: crea SOLO `StpObservation` e `VlanInventory` se mancanti — backup automatico, integrity check, conteggi di sanità prima/dopo; senza `--yes` stampa il piano e non scrive nulla). **NESSUNA migrazione necessaria per W17**: l'adozione ARP usa `ArpEntry` (esiste dal v15) e il campo `Device.macAddress` (esiste da sempre) — zero modifiche allo schema in questa onda. Istruzioni complete in `db/LEGGO.md`.

## Evidence

`release/evidence/w17/`: `dialog-adozione-arp.png` (report batch con tabella candidati e dialog di adozione, vendor IEEE), `report-disponibilita-sede.png` (tabella per sede nel Report), `candidati-arp-mobile.png` e `report-sede-mobile.png` + `dialog-adozione-mobile.png` (mobile 390px: tabelle con scroll interno, dialog contenuto dopo il fix).
