# FALCO-OS v16.4.0-w3.2 — NOC (release sorgente)

Release del **27/10/2026** — **gruppi dispositivi DYNAMIC** (regola valutata a runtime, W3) e **report disponibilità di rete** dalla serie reale packetLoss (W2 residua), dopo il ripristino del DB reale dall'incidente di piattaforma #2.

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.4.0-w3.2 (rispetto a 16.3.1-w3.1)

- **Gruppi dispositivi DYNAMIC (W3)**: la membership di un gruppo può essere una REGOLA invece di un elenco — criteri `deviceTypes` / `statuses` / `connectionTypes` / `locationIds` (AND fra criteri, OR fra valori), tutti campi reali del modello Device. La membership **non viene mai salvata**: il server la ricalcola a ogni lettura con la stessa query di scope di `/devices` (host scoperti compresi) — se un dispositivo cambia tipo/stato/connessione/sede entra o esce dal gruppo da solo. Valori della regola validati contro i dati REALI dell'impianto (422 con offensori per criterio: niente regole su valori fantasma); `ruleType` immutabile dopo la creazione (422 `RULE_TYPE_IMMUTABLE`); regola identica → 422 `NO_CHANGES`; audit `DEVICE_GROUP_*` con regola e conteggio calcolato. UI: scelta del tipo alla creazione, costruttore di regola con chip sui valori distinti reali dell'inventario, multi-select sedi, **anteprima live del conteggio**, card con sintesi della regola e nota di ricalcolo.
- **Report disponibilità di rete (W2 residua)**: nuova rotta GET `/api/v2/reports/availability` (29ª di v2) — disponibilità = 100 − perdita pacchetti media dalla serie REALE `packetLoss` (170 dispositivi coperti). Finestra 24–168 h **dichiarata insieme alla copertura effettiva** (`coverageFrom`/`coverageTo`); la serie è congelata al 26/10 10:36 (fine del prelievo reale) e il report lo dichiara: righe senza campioni → «n.d.» (mai 100% inventato). `pingLatency` solo come statistiche supplementari (NON fonte di disponibilità: la presenza dei campioni dipende dalla rotazione del replay). `SLADefinition` = 0 nel DB reale → nessuna soglia di conformità inventata. Vista Report: sezione con selettore finestra, tabella peggior-disponibilità-prima, export CSV.
- **Incidente piattaforma #2 risolto (16.3.2)**: un secondo ripristino d'ambiente ha sostituito il DB reale con uno vuoto e svuotato `.env` (persa `NEXTAUTH_SECRET`: login 200 ma TUTTE le API 401 — difetto sordo documentato). DB ripristinato per intero dall'unica copia superstite (200 dispositivi, 771.388 metriche, 74 ticket, 48.046 audit), backup ricreato in `/home/z/falco-real/`, procedure nel runbook §4 e `.env.example`.
- **Difetti corretti in verifica**: overflow mobile del TabsList di Operazioni (3 tab ≈ 400px a 390px → scroll orizzontale, rimesurato 390=390); 3 skeleton di caricamento senza ruolo accessibile (`aria-label` su div senza ruolo → `role="status"` + sr-only).
- **Certificazione a11y mantenuta**: suite Playwright+axe-core rieseguita sulle UI nuove → **0 violazioni WCAG 2.2 AA su 19 contesti**.
- `verify-api.sh`: 20 GET, nuovo ciclo §3c-bis gruppi DYNAMIC (creazione con regola → 87 membri calcolati → modifica regola → 75 ricalcolati → guardie 422 → eliminazione), validazioni availability (windowHours 10/200 → 422), 401 su tutte le 20 rotte.

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: 29 rotte con contratti zod; viste: Dashboard, Rete, Dispositivi, Telecamere (2 tab), Allarmi, Operazioni (3 tab), Report (+ disponibilità), Amministrazione + Wallboard; design system a due temi)
- `prisma/schema.prisma` — schema del DB reale (123 modelli, invariato dall'import)
- `mini-services/realtime-service/` — servizio socket.io (porta 3001, tick 30 s in **modalità riproduzione dichiarata** + hold flussi video)
- `docs/` — 6 documenti vivi: AUDIT_E_INVENTARIO, ARCHITETTURA_E_DECISIONI (fino a D19), DESIGN_SYSTEM, API_CONTRATTI (generato da zod: `bun scripts/gen-api-contracts.ts`), TEST_E_CERTIFICAZIONE (matrice T01–T45), ROADMAP_CHANGELOG_RUNBOOK (CHANGELOG fino a 16.4.0)
- `worklog.md` — registro di lavoro condiviso tra agenti (storia completa, incluse le forensiche dei due incidenti di piattaforma)
- `scripts/` — generatore dei contratti API, verifica API end-to-end (`bash scripts/verify-api.sh`), suite a11y (`bun scripts/a11y-audit.mjs`)
- `.env.example`, `db/LEGGO.md` — configurazione e istruzioni per il DB (NON incluso: il DB reale ~292 MB resta di proprietà dell'operatore)

**NON incluso**: `node_modules/`, `.next/`, `db/custom.db`, `.env` (segreti).

## Requisiti

- Node 20+ / Bun 1.1+ · `bun install` · DB reale in `db/custom.db` (vedi `db/LEGGO.md`) · `.env` dalle 3 righe di `.env.example` (`DATABASE_URL` assoluta + `NEXTAUTH_SECRET`, senza la quale il login risponde 200 ma tutte le API 401) · `bunx prisma generate` · `bun run dev` (Next :3000) + `bun --hot index.ts` in `mini-services/realtime-service` (realtime :3001, con la STESSA `DATABASE_URL`).

## Verifica (ripetibile)

```bash
bash scripts/verify-api.sh        # ~30 s: login reale + 20 GET + cicli (manutenzione, gruppi MANUAL, gruppi DYNAMIC, scope) + 422 + 401 — tutto verde
bun scripts/a11y-audit.mjs        # suite a11y WCAG 2.2 AA: 0 violazioni su 19 contesti
bunx tsc --noEmit && bun run lint # 0 errori (1 warning noto preesistente)
```

Accessi demo: `admin@falco-os.local` / `FalcoDemo2026!` (hash bcrypt nel DB).
