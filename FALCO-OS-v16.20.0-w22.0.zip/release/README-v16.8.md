# FALCO-OS v16.8.0-w2.2-w6.0 — Rilascio onde W2 e W6

Data: 29/10/2026 · Richiesta operatore: «Esegui i w2 e w6»

## Che cosa contiene

### W2 piena — Report e gestione (le 3 voci residue)
- **Report SLA mensile + storico** — `GET /api/v2/reports/sla`: coorte dei ticket creati
  nel mese; tempi di prima risposta (`firstResponseAt`) e risoluzione (`resolvedAt` al
  netto di `slaPausedMinutes`); conformità valutata SOLO dove i target `slaDueAt` esistono.
  Copertura DICHIARATA (nel DB reale: `firstResponseAt` 0/74, `SLADefinition` 0 — D19):
  statistiche assenti → «n.d.» in UI, mai 0. Storico mese-per-mese con export CSV.
- **Scheda intervento** — `GET /api/v2/tickets/{id}` + dialog con anteprima e
  «Stampa / PDF» (finestra autonoma stampabile, pattern sintesi impianto): dati reali
  del ticket, dispositivo/sede, passi diagnostici, causa radice/risoluzione, registro
  interventi REALE (0 righe nel plant egidio: dichiarato), timeline = audit reale.
- **Report schedulati PDF** — CRUD `ScheduledReport` v15 (frequenza/canali/destinatari/
  sezioni con guardie semantiche e audit `REPORT_SCHEDULED_*`). Onestà D2: il motore di
  schedulazione NON gira in riproduzione — `lastRunAt` null, `runCount` 0, nessun
  artefatto (banner in UI).
- vitest NON portato (dichiarato): la disciplina di verifica della piattaforma è
  verify-api.sh + tsc + lint + browser e2e.

### W6 — Hardening, dismissione, pacchetto di certificazione
- **Catena audit a prova di manomissione** — formula RECUPERATA dal sorgente v15.16.0
  superstite (`upload/folder/7da6efe5/FALCO-OS-v15.16.0.zip`): il verificatore v16
  conferma la catena REALE del DB (**64/64 sigilli · 47.348/47.348 righe · zero rotture**,
  ~1 s). Sealer API (`POST /api/v2/audit/seal`, SUPER_ADMIN) che CONTINUA la catena v15
  — testato end-to-end (734 righe, 65° sigillo) e REVERTITO: il DB resta al baseline.
- **Export certificato SHA-256** — contratto v15 V12-F: `format=csv|json` con header
  `x-falco-export-sha256` = digest del BODY (verificato byte-per-byte), CSV RFC 4180,
  tetto 50.000 righe, audit `AUDIT_EXPORT` con digest; envelope JSON con manifest
  (chainDigest, exportDigest) per l'UI.
- **Hardening dimostrato** — header di sicurezza su tutte le risposte (nosniff,
  Referrer-Policy, Permissions-Policy; X-Frame-Options assente per scelta documentata:
  pannello di anteprima); `Cache-Control: no-store` su OGNI risposta API v2; throttle
  PER-IP anti-spraying sul login (30 fallimenti/15 min → 5 min, in-memory) con audit
  BOUNDED — verificato: credenziali corrette RIFIUTATE sotto throttle, restart azzera.
- **Dismissione vecchia UI** — scansione del codice: zero componenti orfani su 21;
  l'atto di dismissione è la matrice PARITA (v16 sostituisce integralmente la UI v15
  nell'ambito consegnato).
- **Pacchetto di certificazione** — `scripts/gen-cert-package.sh`: ZIP di evidenza con
  manifest catena + chainDigest, verifica crittografica DAL VIVO, system health,
  contratti API (82 route), a11y, PARITA, ROADMAP/RUNBOOK, ARCHITETTURA, revisione git,
  SHA256SUMS. Anche in `release/FALCO-OS-cert-v16.8.0-*.zip`.

### Incidenti e fix
- **Incidente piattaforma #4** (pre-work): DB sostituito da vuoto, .env dimezzato,
  .env.example e backup rimossi → ripristino integrale dallo snapshot /tmp/my-project/db
  (baseline combacianti), secret rigenerati, 62 file mode normalizzati.
- **FIX buco 16.7.0**: `src/app/api/v2/integrations/test/route.ts` non era mai entrato
  nel commit 7aeac79 (era solo nello ZIP) — recuperato dallo ZIP di release e committato.
- **FIX UI reale**: la tabella sigilli dentro Radix ScrollArea non clippava verticalmente
  (copriva in hit-test i pulsanti delle card sottostanti) → pattern consolidato
  div max-h + overflow + header sticky (stesso fix alla timeline della scheda).

## Verifiche (tutte verdi)
- `bash scripts/verify-api.sh`: §1-§3g con **ZERO mismatch** (82 route, §3g nuova con
  16 controlli W2+W6: SLA onesto, guardie scheduled, manifest export, catena 64 sigilli,
  CATENA INTEGRA, header sha256) + 401 su tutte le route senza sessione.
- `bunx tsc --noEmit`: 0 errori · `bun run lint`: 0 errori (1 warning noto preesistente).
- Browser e2e: SLA (74/74 con «n.d.» onesti), ciclo completo report pianificati
  (creazione→eliminazione), scheda intervento (dialog + stampa autonoma), Certificazione
  (verifica CATENA INTEGRA dal browser, SIGILLO E2E con revert, download CSV certificato
  48.082 righe), mobile 390 px senza overflow, zero errori console.
- DB egidio PRISTINO alla chiusura: 48.046 audit · 47.348 sigillate · 64 sigilli v15 ·
  0 righe nelle tabelle di test.

## Avvio
Vedi RUNBOOK §4 in `docs/ROADMAP_CHANGELOG_RUNBOOK.md` (pattern subshell, .env con
QUATTRO chiavi, ripristino dati da /tmp/my-project/db, pacchetto certificazione).

## Stato onde
W0 ✅ · W1 ✅ · W2 ✅ (16.8) · W3 ✅ (16.7) · W5 ❌ (decisione operatore) ·
W6 ✅ (16.8) · W7 ✅ (16.7) · **resta W4** (knowledge base, RMA/ondate, CVE, speed test,
assistente, amministrazione completa — vedi PARITA §3 per le voci ⚠️ residue).
