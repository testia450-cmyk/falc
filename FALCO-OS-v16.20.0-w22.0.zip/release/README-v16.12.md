# FALCO-OS v16.12.0-w10.0 — Impianti «a se stanti»

**Richiesta operatore (30/10/2026):** «ho creato un altro impianto ma vedo in dispositivi
quelli di un altro, gli impianti devono avere tutte le schermate separate ogni impianto è
a se stante» — dopo la creazione dell'impianto reale «cagliari» dal pannello W8.

## Cosa è cambiato

**Ogni impianto è ora completamente isolato in OGNI schermata.**

| Prima (il difetto) | Ora |
|---|---|
| L'appartenenza all'impianto passava SOLO dalla sede del dispositivo | Ogni dispositivo ha un **impianto di proprietà esplicito** (`Device.plantId`, colonna con vincolo di integrità) |
| I 30 dispositivi scoperti senza sede (orfani di egidio) apparivano in OGNI impianto | Gli orfani appartengono al loro impianto e **non attraversano il confine** |
| RMA e ondate usavano sempre l'impianto di default, ignorando il selettore | Ogni operazione segue l'impianto attivo del selettore |
| L'assistente AI ragionava su TUTTO il DB | L'assistente risponde **solo con i dati dell'impianto attivo** |
| Il selettore dichiarava «170 dispositivi» (solo quelli con sede) | Il selettore dichiara i conteggi reali di proprietà: «egidio 200 · cagliari 0» |

**Com'è ora (verificato nel browser):**
- **cagliari** (impianto nuovo): Dashboard con tutti i KPI a zero e testi onesti, Dispositivi
  «0 dispositivi · impianto cagliari» con empty state, Topologia «L'albero di topologia è
  vuoto», Allarmi «Nessun allarme aperto», Ticket 0/0/0, Impianti con card vuota onesta.
- **egidio** (impianto reale): **INVARIATO** — 200 dispositivi (pagina 1 di 4), raggiera
  intatta con root «Router SETI» e card «Senza sede 30/0 GIÙ», 71 ticket aperti, 82 allarmi.
- Chiedere un dettaglio di un dispositivo di egidio mentre è attivo cagliari → **404**
  (nessun dato mescolato). L'assistente con cagliari attivo risponde: «L'impianto di
  Cagliari ha 0 dispositivi totali».
- Un impianto con dispositivi **non si può eliminare** (409 PLANT_NOT_EMPTY + vincolo DB).

**Come si popola un impianto nuovo:** Operazioni → Scansione & Adozione (la coda è ora
per-impianto: mostra solo gli orfani dell'impianto attivo) oppure importa i punti KMZ/KML
e assegna i dispositivi alle sedi. Il wizard di inserimento manuale completo è la naturale
prossima ondata.

## Verifica (disciplina W10)

- Migrazione DB in 3 fasi con **backup** (db+wal+shm): colonna nullable → backfill
  (170 da sede · 30 orfani dai loro allarmi SYS:NEW_HOST) → NOT NULL + FK RESTRICT;
  `PRAGMA integrity_check` ok; 200 dispositivi · 9235 allarmi · 892 link intatti
- `bunx tsc --noEmit` → 0 errori · `bun run lint` → 0 errori (1 warning noto pre-esistente)
- `scripts/verify-api.sh` → **exit 0** con la nuova **§3j (16 controlli di isolamento
  multi-impianto)**: A=200/B=0 dispositivi, coda adozione B vuota e A=30 orfani, overview
  cross-impianto → 404, grafo B 0 nodi/0 archi, NOC B a zeri, RMA cross → 404, grafo A
  invariato a 200 nodi — suite completa (§1–§5) verde, §3i W8 intatta (892 link, dry-run 243)
- Browser e2e desktop 1440 + mobile 390: switch impianto dal topbar, tutte le viste di
  cagliari oneste a zero, egidio senza regressioni, assistente SSE per-impianto, nessun
  overflow orizzontale a 390px, **zero errori console**
- DB reale: egidio 200 dispositivi (tutti con plantId) · cagliari vuoto come creato
  dall'operatore · nessuna scrittura manuale di test

## Servizi

Next :3000 (dev) · realtime :3001 (tick 30 s, replay ancorato all'impianto più vecchio) ·
discovery :3002. Login demo: admin@falco-os.local / FalcoDemo2026!
