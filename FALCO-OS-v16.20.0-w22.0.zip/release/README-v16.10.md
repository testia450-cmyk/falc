# FALCO-OS v16.10.0-w8.0 — MULTI-IMPIANTO, IMPORT KMZ, TOPOLOGIA RIVISTA

**Data:** 30/10/2026 · **Richiesta operatore:** «come aggiungo un altro impianto? posso caricare la mappa KMZ dell'impianto di appartenenza? la topologia che hai riportato è sbagliata, le letture SNMP del bridge sono sbagliate; trova una soluzione migliore di rappresentazione» · **Task worklog:** 36
**Contenuto:** ZIP sorgente · **DB reale NON incluso** (proprietà dell'operatore, vedi db/LEGGO.md)

## Le tre risposte

### 1 · Come si aggiunge un altro impianto
- Tab **«Impianti»** in Amministrazione (prima tab): crea/modifica/elimina con TUTTI i campi v15 (comune, indirizzo, canale Telegram, mappa centro/zoom, intervallo ping, timer interruzione, community SNMP, note, attivo).
- L'impianto nuovo nasce **vuoto** (nessun job/poller in riproduzione — dichiarato, D2). Eliminazione possibile SOLO se vuoto: un impianto con dati reali viene **rifiutato** con i conteggi (409) — «egidio» non si cancella per errore.
- **Selettore «Impianto attivo» nel topbar**: ogni vista, query e mutazione segue l'impianto scelto (iniezione `?plantId=` su OGNI chiamata API). Default deterministico = l'impianto più vecchio; la scelta persiste.
- Perimetro v15: chi non è SUPER_ADMIN vede solo gli impianti assegnati (assegnabili da «Utenti e permessi», W4).

### 2 · La mappa KMZ dell'impianto si carica
- **Import punti KMZ/KML a due fasi** (porta fedele v15 v11.16) dal menu dell'impianto: l'**anteprima** mostra il PIANO (punti da creare/aggiornare/invariati + proposte di associazione dispositivi con confidenza ALTA/MEDIA/BASSA e il perché) **senza scrivere nulla**; l'**applica** confermata scrive in una transazione riverificando tutto dal FILE (il client non decide nulla da solo).
- Le associazioni confermate diventano àncore **manuali** per il motore topologico; il KMZ viene conservato e registrato sull'impianto. Difese v15: zip-bomb, namespace Google Earth, description CDATA, validazione coordinate.
- Punti creati per errore: eliminabili (409 se hanno dispositivi assegnati — prima si spostano).

### 3 · La topologia sbagliata si CORREGGE, non si nasconde
L'operatore ha ragione: l'inventario reale ha **892 collegamenti, ZERO confermati dall'operatore, 243 inferiti dalle letture bridge/FDB** — la «stella» di 162 vicini diretti del gateway non è la rete fisica. La nuova topologia è uno **strumento di correzione**:
- **Filtri per famiglia di fonte**: operatore (confermati) · protocolli LLDP/MNDP · UISP attivi di default; **inferiti esclusi di default** — con la riga di onestà sempre visibile: «Albero costruito su 649 di 892 collegamenti · 243 inferenze escluse».
- **Gestione collegamenti** (dialog completo): inventario con filtri e statistiche per fonte; **conferma** (cristallizzazione: il link diventa verità dell'operatore); **correggi**; **elimina** lo sbagliato; **nuovo** manuale; **ripulisci inferenze in blocco** con dry-run che conta ESATTAMENTE cosa sparirebbe (mai i confermati: guardia strutturale).
- **Radice scelta dall'operatore** dal pannello nodo (batte ogni euristica, v11.27).
- Nuova resa visiva: legenda fonti, archi per evidenza (confermato pieno verde · protocollo pieno · UISP tratteggiato · inferito puntinato), cluster per sede, deep link `?view=rete&fonti=…`.

## Numeri
- **API:** 11 route v2 nuove → **117 totali documentate** (docs/API_CONTRATTI.md, generato dai contratti zod)
- **Verifica:** verify-api.sh **§3i** (impianti CRUD · KMZ preview/apply · punti · links CRUD+purge) — run completa **exit 0, 205 controlli, zero traceback**; tsc 0 · lint 0 errori/1 warning noto
- **Browser e2e:** desktop 1440 + mobile 390 px, zero errori console — creazione impianto, import KMZ reale (3 sedi), cristallizzazione link E2E + revert, radice E2E + revert, dry-run purge 243 su egidio
- **DB finale PRISTINO** (D25): 892 link · 0 confermati · 41 sedi · 200 dispositivi · 1 impianto · audit 48.046 = baseline

## Avvio
```bash
bun install && bunx prisma generate && bun run dev          # :3000
cd mini-services/realtime-service && bun run dev             # :3001 (tick 30 s)
cd mini-services/discovery-service && bun run dev            # :3002 (motori v15)
```
Login demo: `admin@falco-os.local` / `FalcoDemo2026!`

## Dichiarato e NON consegnato (onestà)
- Il motore topologico v15 (inferenza LLDP/FDB live, site-autoassign) **non gira in riproduzione**: la W8 corregge l'inventario esistente, non produce nuove inferenze.
- Export/import completo per-impianto (plant-backup v15) e job/poller per impianto nuovi: fuori linea d'onda (D2).
- Web Push VAPID (PARITÀ §1.10): mai stato in roadmap §1.
