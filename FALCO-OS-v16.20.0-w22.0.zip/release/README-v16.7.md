# FALCO-OS v16.7.0-w3.5-w7.0 — NOC (release sorgente)

Release del **29/10/2026** — **onda W3 COMPLETATA** (operazioni evolute) + **onda W7 INTEGRAZIONI**, su richiesta diretta dell'operatore («Fai w7 e w3»).

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.7.0 (rispetto a 16.6.0-w3.4)

### Incidente piattaforma #3 (29/10 ore 05:35) — ripristino integrale
Terzo ripristino d'ambiente: DB reale cancellato (sostituito da uno vuoto), `.env` dimezzato (perse NEXTAUTH_SECRET/URL), `.env.example` eliminato. Ripristino dallo snapshot `/tmp/my-project/db` (fusione WAL pulita, integrity ok): 200 dispositivi · 9.235 allarmi · **10 regole SYS** · 771k metriche · 48k audit — tutte le baseline combacianti. Backup multipli in `/tmp/db-save{,2}`.

### Bug critico risolto: tempesta Fast Refresh (socket.io polling)
Il client socket.io usava `transports: ['polling']`: ogni poll sui collegamenti diretti colpiva la route pagina `/` di Next → ricompilazione ogni ~4 s → Fast Refresh che azzerava lo stato React delle mutation. Fix: **`transports: ['websocket']`** (pattern prescritto dal gateway; degrado onesto dove l'upgrade non passa) + log dev-server fuori dall'albero osservato (`tee /tmp/falco-dev.log`). Verificato: 0 eventi console in 15 s (prima 7+).

### W3.5 — Operazioni evolute (onda W3 completata, 13 route nuove)
- **Event-policies** — le **10 regole SYS:\* REALI** del motore v15 (SYS:ANOMALY, SYS:CAMERA_STREAM_DOWN, SYS:NEW_HOST, SYS:PACKET_LOSS…) tarabili operativamente (enabled/soglie/cooldown/severità) ma **mai eliminabili o ristrutturate** (422 SYSTEM_RULE); regole utente con CRUD completo validato sui dati REALI (tipi distinti dell'inventario, scope sedi/dispositivi/link, nome univoco per impianto). UI: tab **«Regole evento» in Allarmi**.
- **Custom-oids** — CRUD + **test SNMP LIVE** via discovery-service (get reale dell'OID sull'IP del dispositivo; community legacy in chiaro se presente altrimenti «public», dichiarato; in sandbox timeout onesto — su sito legge il valore vero). UI: tab **«OID custom» in Amministrazione**.
- **Config-requests** — macchina a stati completa (PENDING→APPROVED→APPLIED→CONFIRMED/ROLLED_BACK + REJECTED) con **guardrail v15** (FORBIDDEN_COMMAND_PATTERNS: `rm -rf`, `erase flash`, `factory-reset`… → 422), finestra **commit-confirm** (scaduta → 422 WINDOW_EXPIRED), dry-run dichiarato per executor SIMULATED («NESSUN comando inviato»), SSH → 422 REPLAY_NOEXEC.
- **Bulk-config** — tetto v15 R8 (max 50 target), guardrail comandi, dry-run sincrono con report per dispositivo (`simulated: true` dichiarato).
- **Firmware-center** — schedulazione job (SCHEDULED→CANCELED) con firmware attuale dal DB; nessuna esecuzione in riproduzione (dichiarato).
- **Playbooks** — CRUD con builder passi (vocabolario azioni v15: check_status, check_metric, send_command, open_ticket, notify, wait), riordino, runCount 0 onesto.
- **Automation-tasks** — CRUD con tetto guardrailMaxDevices; nessun run in riproduzione.
- **Terminale SSH** — sonda REALE della porta 22 via discovery-service; **nessun terminale emulato, nessuna sessione fittizia**.
- UI: quinto tab **«Operazioni evolute» in Operazioni** (6 sub-tab).

### W7.0 — Integrazioni (9 route nuove + ricevitore pubblico)
- **Configurazioni cifrate** — IntegrationConfig per 12 famiglie v15 (telegram, osticket, email, grafana, checkmk, cnmaestro, unifi, splashtop, ldap, prometheus, backup, general); valori cifrati **AES-256-GCM a riposo** (crypto.ts portata da v15, chiave master `DEVICE_CREDENTIALS_KEY`); i segreti escono SEMPRE mascherati «\*\*\*»; audit senza mai il valore.
- **Test di connessione REALI** — http/tcp/telegram con esiti onesti della rete: la sandbox HA internet e **Telegram risponde 401 ai token falsi** (verità del test, non simulazione).
- **Webhook con firma HMAC-SHA256** — consegna di test firmata (`X-Falco-Signature: t=<epoch>,v1=HMAC-SHA256(secret, t.body)`); il ricevitore locale pubblico `/api/hooks/test-receiver` risponde con l'eco {bodySha256, timestamp} → **verifica crittografica end-to-end lato mittente** (`signatureVerified: true` dimostrato in sandbox); consegne registrate (DELIVERED/DEAD, attempts 1/6, latenza); segreto generato mostrato **UNA sola volta** alla creazione.
- UI: tab **«Integrazioni» in Amministrazione**.

### Conteggi e verifica
- **API v2: 72 route documentate** (gen-api-contracts.ts rigenerato).
- verify-api.sh: 10 GET nuove + **§3f** (10 regole SYS reali · guardrail rm -rf → 422 · BAD_KIND · tcp senza host → 422 · webhook incompleto → 422) + 401 su tutte le 10 route nuove — **TUTTO VERDE**.
- tsc 0 errori · lint 0 errori / 1 warning noto · 0 errori console browser.
- Browser: tab Regole evento (10 SYS reali), Integrazioni (config → «\*\*\*», webhook E2E con firma verificata nel DOM: «Consegnata · HTTP 200 · 28 ms · firma verificata end-to-end»), OID custom empty onesto, Operazioni evolute (6 sub-tab, terminale onesto).
- Ogni test di scrittura REVERTITO e audit puliti: **DB egidio PRISTINO** (10 regole SYS, 0 righe nelle nuove tabelle).

## Contenuto del pacchetto

- `src/` — applicazione (API v2: 72 rotte; viste: Dashboard, Rete (3 tab), Dispositivi (6 tab), Telecamere (2 tab), **Allarmi (+Regole evento)**, **Operazioni (5 tab)**, Report, **Amministrazione (3 tab)** + Wallboard)
- `prisma/schema.prisma` — schema del DB reale (123 modelli, invariato)
- `mini-services/realtime-service/` — socket.io :3001 (tick 30 s, riproduzione dichiarata)
- `mini-services/discovery-service/` — motori di rete v15 :3002 (scansione, SNMP, ONVIF, OUI, UDP vendor, get OID custom)
- `src/app/api/hooks/test-receiver/` — ricevitore webhook pubblico (verifica firma)
- `docs/` — 7 documenti vivi (CHANGELOG fino a 16.7.0, PARITÀ aggiornata W3 completa + W7)
- `worklog.md` — registro (Task 1–33, incluse le forensiche dei 3 incidenti piattaforma)
- `scripts/` — gen-api-contracts (72 route), verify-api.sh (§3f nuovo), a11y-audit.mjs

**NON incluso**: `node_modules/`, `.next/`, `db/custom.db`, `.env` (segreti), `bun.lock` dei mini-services.

## Requisiti

- Node 20+ / Bun 1.1+ · `bun install` · DB reale in `db/custom.db` + `.env` (4 variabili: DATABASE_URL, NEXTAUTH_SECRET, NEXTAUTH_URL, **DEVICE_CREDENTIALS_KEY** — vedi `.env.example`) · `bunx prisma generate` · `bun run dev` (:3000) · realtime :3001 e discovery :3002 (vedi RUNBOOK §4).

## Verifica (ripetibile)

```bash
bash scripts/verify-api.sh        # login reale + 35 GET + cicli (manutenzione, gruppi, discovery, W3.5+W7 §3f) + 422 + 401 — tutto verde
bun scripts/a11y-audit.mjs        # suite a11y WCAG 2.2 AA
bunx tsc --noEmit && bun run lint # 0 errori (1 warning noto preesistente)
```
