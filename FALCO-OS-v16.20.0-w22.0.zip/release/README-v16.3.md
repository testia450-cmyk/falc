# FALCO-OS v16.3.1-w3.1 — NOC (release sorgente)

Release del **27/10/2026** — registro flussi video con finestra dichiarata (W2 residua), gruppi dispositivi + manutenzioni complete + scope per gruppi (W3), hold dei flussi video nel realtime, decontaminazione dopo incidente di piattaforma, **certificazione a11y WCAG 2.2 AA (0 violazioni su 19 contesti)**.

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.3.0-w3.0 (rispetto a 16.2.0-w2.1)

- **Registro flussi video** (W2 residua «Telecamere/NVR evoluto»): nuova rotta GET `/api/v2/cameras/streams` — per ogni apparato video: stato flusso, ultimo controllo, ultimo cambio stato OSSERVATO, uptime 24h e sulla finestra, campioni, RTT. La finestra è **dichiarata nel payload** (168h richieste → 48h reali se la serie supera il limite di carico) e l'uptime è calcolato SOLO sui campioni presenti (null → «n.d.», mai 0% inventato). Filtro sede `locationId` su `/api/v2/cameras` (41 sedi reali). Vista Telecamere a 2 tab.
- **Gruppi dispositivi (W3)**: CRUD completo (`/api/v2/device-groups`, 28 endpoint v2 totali) con membership a SOSTITUZIONE integrale, univocità nome per impianto, cap 500 membri dichiarato, audit `DEVICE_GROUP_*` in transazione. I gruppi sono entità gestite dall'operatore (il DB reale parte da 0: nessun gruppo finto).
- **Manutenzioni complete (W3)**: PATCH retrocompatibile ({state} continua a validare) su tutti i campi con diff onesto lato server (422 `NO_CHANGES` su patch senza effetto), POST con `groupIds` → scope per gruppi con nomi reali, 422 `INVALID_TRANSITION`/`GROUP_EXISTS` come contratto.
- **Realtime — hold flussi video**: il servizio (porta 3001) riscrive l'ULTIMO valore reale noto di `cameraStreamAlive` per i 106 apparati già campionati (ogni 10° tick): senza, il registro sarebbe decaduto a «n.d.» entro 24h mentre i dispositivi restano ONLINE. Nessuna transizione inventata (1 resta 1, 0 resta 0; i 5 flussi fermi reali restano fermi; i 12 mai campionati restano «n.d.»).
- **Incidente di piattaforma risolto**: un ripristino d'ambiente del sandbox aveva contaminato il repo con file del template dimostrativo (rotte con altro schema Prisma) e rigenerato il client Prisma dal template → login 401. Decontaminazione integrale (13 rotte + viste + librerie demo rimosse), DB reale verificato PULITO, client rigenerato dallo schema reale. Forensica completa in worklog Task 18 / ARCHITETTURA D16.
- **Difetto corretto**: PATCH device-groups senza cambi effettivi → 422 `NO_CHANGES` (prima 200 silenzioso).
- `verify-api.sh` esteso: 19 GET, ciclo gruppi (§3c), manutenzione+scope (§3d) con self-cleanup, validazioni streams, 401 su tutte.

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: 28 rotte con contratti zod; viste: Dashboard, Rete, Dispositivi, Telecamere (2 tab), Allarmi, Operazioni (3 tab), Report, Amministrazione + Wallboard; design system a due temi)
- `prisma/schema.prisma` — schema del DB reale (123 modelli, invariato dall'import)
- `mini-services/realtime-service/` — servizio socket.io (porta 3001, tick 30 s in **modalità riproduzione dichiarata** + hold flussi video)
- `docs/` — 6 documenti vivi: AUDIT_E_INVENTARIO, ARCHITETTURA_E_DECISIONI (fino a D17), DESIGN_SYSTEM, API_CONTRATTI (generato da zod: `bun scripts/gen-api-contracts.ts`), TEST_E_CERTIFICAZIONE (matrice T01–T39), ROADMAP_CHANGELOG_RUNBOOK
- `worklog.md` — registro di lavoro condiviso tra agenti (storia completa, incluso l'incidente Task 18)
- `scripts/` — generatore dei contratti API + verifica API end-to-end (`bash scripts/verify-api.sh`)
- `.env.example`, `db/LEGGO.md` — configurazione e istruzioni per il DB (NON incluso: il DB reale ~292 MB resta di proprietà dell'operatore)

**NON incluso**: `node_modules/`, `.next/`, `db/custom.db`, `.env` (segreti).

## Requisiti

- Bun ≥ 1.3 (o Node ≥ 20 + npm: adattare gli script)
- ~2 GB di RAM liberi per lo sviluppo (dev server + servizio realtime)

## Installazione

```bash
bun install                # dipendenze
cp .env.example .env       # e valorizzare i segreti
bunx prisma generate       # client Prisma dallo schema reale (123 modelli)
# DB: copiare il proprio custom.db in db/custom.db
bun run dev                # Next su :3000
cd mini-services/realtime-service && bun run dev   # realtime su :3001
```

Verifica post-installazione: `bash scripts/verify-api.sh` (login admin + 19 GET + cicli CRUD con audit + 401/422).

## Certificazione accessibilità (16.3.1)

- Strumento ripetibile nel repo: `bun scripts/a11y-audit.mjs` (Playwright chromium + axe-core, tag WCAG 2.x AA): login reale, 9 viste scuro + tab secondarie + dettaglio dispositivo + 3 viste mobile + 3 viste tema chiaro → **0 violazioni su 19 contesti** (report `docs/A11Y_AUDIT.md`, JSON `scripts/.a11y-last.json`, exit 1 se regredisce).
- Correzioni strutturali incluse: React Flow `colorMode` sincronizzato col tema (il grafo riceveva i token del tema sbagliato), token colore sdoppiati per uso testuale/decorativo (--crit-text/--crit-solid) e portati ad AA in entrambi i temi, pattern overlay sulle KPI card (niente controlli annidati, target ≥ 24px), ruoli ARIA validi, nome accessibile conforme al testo visibile.

## Qualità dichiarata

- tsc 0 errori · ESLint 0 errori (1 warning noto: TanStack Table + React Compiler, tracciato in TEST §3)
- verify-api.sh TUTTO VERDE (28 endpoint, envelope `{ok, asOf, mode:'replay'}`, 401 auth-first su ogni rotta, 422 BAD_QUERY su parametri fuori contratto)
- Verifica browser: 8 viste + wallboard con dati reali, doppio tema, mobile 390px senza overflow, zero errori console
- Onestà: nessun dato demo; uptime null → «n.d.»; 5 flussi fermi reali restano fermi; stati dispositivo mai inventati dal realtime
