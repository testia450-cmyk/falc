# FALCO-OS v16.5.0-w3.3 — NOC (release sorgente)

Release del **27/10/2026** — **tab «Porte» nella scheda dispositivo** (parità v15 G3, W3-proroga) e **Inventario MAC** (FDB × inventario, voce W4 anticipata perché il dato reale esiste), dopo la **verifica di parità col software originale v15.16.0** richiesta dall'operatore.

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.5.0-w3.3 (rispetto a 16.4.0-w3.2)

- **Verifica di parità v15.16.0 → v16 (richiesta operatore)**: nuova matrice `docs/PARITA_V15_V16.md` — 92 capacità del vecchio software inventate per dominio e incrociate con lo stato v16: **24 ✅ consegnate · 11 🟡 parziali · 21 ⬜ pianificate · 28 ⚠️ fuori roadmap (da allocare) · 3 ❌ vetate (W5) · 5 ⚙️ non applicabili alla sandbox**. I conteggi sono stati verificati sui sorgenti originali (248 file rotte, 117 gruppi API, integrazioni: Telegram/osTicket/Grafana/check_mk/Splashtop/Push/webhook/LDAP…). Il core NOC quotidiano è consegnato; il gap principale = operazioni evolute (config/firmware/terminal — in roadmap W3), integrazioni (12 famiglie, fuori roadmap) e motori intelligenti (8, fuori roadmap) → §3 della matrice propone l'allocazione, la decisione spetta all'operatore.
- **Tab «Porte» (scheda dispositivo, W3-proroga)**: nuova rotta GET `/api/v2/devices/[id]/ports` (30ª di v2) — «cosa c'è su ogni porta» costruita SOLO da tre fonti REALI del DB in union (nessuna porta inventata): `TopologyLink` (collegato a, evidenza/confidenza, velocità negoziata STORICA), `FdbObservation` (MAC visti per porta, elenco limitato a 20 con conteggio reale), serie `port_utilization:<porta>` (ultimo campione + copertura dichiarata). Risoluzione MAC→inventario via `macAddress`+`extraMacs` (non risolto → «non in inventario»). Onestà dichiarata: stato live della porta, velocità corrente e PoE richiedono SNMP — fuori replay. Uplink = peer INFRA della stessa classificazione dei tier. Tab disabilitata per i non-switch.
- **Inventario MAC (FDB × inventario, W4 anticipata)**: nuova rotta GET `/api/v2/mac-inventory` (31ª di v2) — ogni riga è UNA osservazione FDB reale (apparato · porta · MAC · ultima volta visto) con risoluzione inventario. Filtri: ricerca MAC/hostname, apparato (20 reali con FDB), scope risolti/non risolti, ordinamento, paginazione reale (pageSize 10–200, 422 fuori range). Summary GLOBALE prima dei filtri. UI: terzo tab «MAC» nella vista Rete (`?rete=mac`) con 3.307 osservazioni reali (2.977 in inventario / 330 fuori su 20 apparati), export CSV della pagina con provenienza, serie congelata DICHIARATA («termina al 26/10 09:50:40 — nessun MAC fresco inventato»).
- **Dati reali verificati**: SW_STADIO 4 porte · 191 osservazioni MAC (170 in inventario / 21 fuori); switch di verify-api: 6 porte · 113 MAC · 108 risolti; inventario MAC 3.307 righe combaciante col probe DB.
- `verify-api.sh`: **22 GET** (incluse le due nuove), 422 su `pageSize=5` di mac-inventory, 401 su tutte le 22 rotte.
- API_CONTRATTI.md rigenerato: **30 rotte** documentate. Decisioni: **D20** in ARCHITETTURA (porte/MAC solo dato DB reale, SNMP live fuori replay, nessun OUI), matrice di parità come registro dell'onestà della roadmap.
- Certificazione a11y mantenuta: **0 violazioni WCAG 2.2 AA su 19 contesti**; mobile 390=390 sulle UI nuove; zero errori console.

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: 30 rotte con contratti zod; viste: Dashboard, Rete (Topologia|Mappa|MAC), Dispositivi (scheda 6 tab con Porte), Telecamere (2 tab), Allarmi, Operazioni (3 tab), Report (+ disponibilità), Amministrazione + Wallboard; design system a due temi)
- `prisma/schema.prisma` — schema del DB reale (123 modelli, invariato dall'import)
- `mini-services/realtime-service/` — servizio socket.io (porta 3001, tick 30 s in **modalità riproduzione dichiarata** + hold flussi video)
- `docs/` — 7 documenti vivi: AUDIT_E_INVENTARIO, ARCHITETTURA_E_DECISIONI (fino a D20), DESIGN_SYSTEM, API_CONTRATTI (generato: `bun scripts/gen-api-contracts.ts`), TEST_E_CERTIFICAZIONE (matrice T01–T48), ROADMAP_CHANGELOG_RUNBOOK (CHANGELOG fino a 16.5.0), **PARITA_V15_V16** (matrice di parità col vecchio software)
- `worklog.md` — registro di lavoro condiviso tra agenti (storia completa, incluse le forensiche dei due incidenti di piattaforma)
- `scripts/` — generatore dei contratti API, verifica API end-to-end (`bash scripts/verify-api.sh`), suite a11y (`bun scripts/a11y-audit.mjs`)
- `.env.example`, `db/LEGGO.md` — configurazione e istruzioni per il DB (NON incluso: il DB reale ~292 MB resta di proprietà dell'operatore)

**NON incluso**: `node_modules/`, `.next/`, `db/custom.db`, `.env` (segreti).

## Requisiti

- Node 20+ / Bun 1.1+ · `bun install` · DB reale in `db/custom.db` (vedi `db/LEGGO.md`) · `.env` dalle 3 righe di `.env.example` (`DATABASE_URL` assoluta + `NEXTAUTH_SECRET`, senza la quale il login risponde 200 ma tutte le API 401) · `bunx prisma generate` · `bun run dev` (Next :3000) + `bun --hot index.ts` in `mini-services/realtime-service` (realtime :3001, con la STESSA `DATABASE_URL`).

## Verifica (ripetibile)

```bash
bash scripts/verify-api.sh        # ~30 s: login reale + 22 GET + cicli (manutenzione, gruppi MANUAL, gruppi DYNAMIC, scope) + 422 + 401 — tutto verde
bun scripts/a11y-audit.mjs        # suite a11y WCAG 2.2 AA: 0 violazioni su 19 contesti
bunx tsc --noEmit && bun run lint # 0 errori (1 warning noto preesistente)
```

Accessi demo: `admin@falco-os.local` / `FalcoDemo2026!` (hash bcrypt nel DB).
