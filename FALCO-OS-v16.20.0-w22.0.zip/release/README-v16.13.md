# FALCO-OS v16.13.0-w11.0 — La rete REALE dell'operatore (import Excel + KMZ)

**Data:** 30/10/2026 · **Richiesta operatore:** «guarda questo link questo è quello reale di
come è la rete non come lo hai disegnata tu, correggiamo; magari posso caricare excel e kmz
in modo che troviamo modo anche per altri impianti di partire già avvantaggiati» — seguita
da «Rilascia zip completo».

## Che cosa contiene

### W11 — Topologia egidio = la rete VERA (fonti: Excel SETI + KMZ dell'operatore)
- La topologia precedente era disegnata sui **892 collegamenti auto-scoperti** (LLDP/MNDP/
  UISP/FDB/BRIDGE_MIB) con hub fantasmi («ST Scuola» a 171 link, «Router SETI» a 169).
  La rete REALE dell'Excel è un albero gerarchico: Comando → fibra → Via Califano → 60 GHz
  → caffe → Comune → {P8→P10→{P11,P12,Pulcinella→{PA8,AltroPalo,Mandrino}}, P5→
  CampoSportivo→{PA1,P9}, Cimitero→ViaCimitero, AP01Comune PTMP→{P2,P3,PA2→PA5→P6,PA4,PEPE},
  PA7…} + catena stadio (RIP Stadio basestation → Scuola/Tagliamonte → PA10/PapaGiovanni/
  a004) + RIP1→P1.
- **Risultato su egidio: 183 nodi · 178 archi · 1 solo irraggiungibile** (172.19.150.46,
  fuori Excel: dichiarato in coda adozione). Radice = **Router SETI** (scelta operatore),
  raggiera con 41 sedi e conteggi reali (Polizia Municipale 20, CapoSportivo 5, RIP Stadio
  1 basestation…). Hostname DEV-19.x da scansione: **ZERO** (nomi reali). 22 artefatti
  192.168.1.x fuori rete: dismessi reversibili.

### Import Excel «formato SETI» (nuova funzionalità — gap PARITA colmato)
- Amministrazione → Impianti → «Importa Excel installazione…»: **anteprima a zero
  scritture** con abbinamento fuzzy sezione↔sede calibrato sui nomi reali (confidenza e
  motivo visibili, ogni abbinamento correggibile a tendina), 5 KPI, proposte di basestation
  sintetica **mai pre-spinflate**, opzioni link radio/LAN/purge dei link auto-scoperti.
- **Apply in UNA transazione**: sedi, apparati (IP/nome/tipo/SSID/seriale, password
  CIFRATE AES-256-GCM — rifiuto se manca la chiave master), link RADIO dai gruppi SSID con
  direzione upstream, LAN di sede (hub radio → SW POE → apparati: tutto in albero), FIBRA
  dalla sezione «(Fibra)» che chiude l'albero dal gateway. Idempotente per hostname
  basestation e coppie link. Tetti: 15 MB / 200.000 celle.

### Import KMZ con PERCORSI «Linea»
- Oltre ai punti GPS (40 sedi: 26 attive + 14 OLD), il parser ora legge le **polilinee
  multi-hop**: i waypoint consecutivi sono i collegamenti sede↔sede. I gap-link chiudono i
  buchi dell'Excel con regole d'onestà a due livelli (STA senza padre ← hub AP dell'altra
  sede, altrimenti AP-ripetitore; **mai** un secondo padre, **mai** il gateway come
  stazione servita). Risposta apply con `linksCreated` (contratto retrocompatibile).

### Ricetta per un impianto NUOVO ( KMZ → Excel → (ri)KMZ )
1. **KMZ**: crea le sedi col GPS reale (e la mappa dell'impianto);
2. **Excel**: popola apparati e topologia (link radio + LAN + credenziali cifrate);
3. **(ri)KMZ**: chiude i buchi coi percorsi «Linea» dove l'Excel non copre.
Bootstrap completo verificato end-to-end su impianto vergine: **182 nodi · 178 archi ·
0 irraggiungibili** in tre passi documentati.

### Incidente piattaforma #6 (30/10 ~21:06) e ripristino totale
- L'ambiente ha riportato l'albero al 29/10 (v16.8.0): **persa un'intera giornata di onde
  completate** (W4, W8, W9, W10 già rilasciate come ZIP v16.9–v16.12; W11 completata e
  verificata ma non ancora rilasciata), DB sostituito da vuoto, .env dimezzato.
- **Recupero TOTALE** dallo snapshot superstite /tmp/my-project: sorgente via rsync
  (16.12.0 + W11), DB baseline (integrity ok, conteggi combacianti al 100%: 200/41/9.235/
  74/48.046/892), migrazione W10 riapplicata (Device.plantId: backfill 170+30, NOT NULL +
  FK RESTRICT), **fix topologia W11 riapplicato** con gli script idempotenti e le fonti
  reali superstite in upload/, impianto «cagliari» ricreato vuoto via API (audit incluso).
- La suite verify-api è stata **adeguata alla rete reale**: le asserzioni ora descrivono
  181 link confermati (0 inferiti, dry-run purge 0), 183 dispositivi/nodi attivi, 1 orfano
  reale in coda (172.19.150.46) — non più i numeri dell'era auto-scoperta.

## Verifica (tutte verde)
- `scripts/verify-api.sh` → **exit 0 · 0 FAIL · 0 asserzioni fallite**: §1–§5 completa
  (login reale, ~90 GET/POST/PATCH/DELETE, validazioni zod, 401 su tutte le route senza
  sessione, §3i gestione collegamenti, **§3j isolamento multi-impianto A=183/B=0**).
- `bunx tsc --noEmit` → 0 errori · `bun run lint` → 0 errori (1 warning noto TanStack Table).
- Browser e2e (desktop 1440 + mobile 390): login → Rete → Topologia **raggiera con la rete
  reale** (radice «Router SETI · RADICE SCELTA DALL'OPERATORE», 182 dispositivi · 166
  online · 13 giù · 3 degradati, 41 sedi, «Albero costruito su 181 di 181 collegamenti · 0
  inferenze escluse») → Dispositivi «183 · impianto egidio · pagina 1 di 4» → mobile 390 px
  senza overflow → **zero errori console/pagina**.
- DB reale finale: egidio **183 attivi + 22 dismessi reversibili** · 42 sedi · 74 ticket ·
  181 link reali · cagliari vuoto come lasciato dall'operatore.

## Stato onde
W0 ✅ · W1 ✅ · W2 ✅ · W3 ✅ · W4 ✅ (16.9) · W5 ❌ (decisione operatore) · W6 ✅ ·
W7 ✅ · W8 ✅ (16.10) · W9 ✅ (16.11) · W10 ✅ (16.12) · **W11 ✅ (16.13 — questa)**.
Linea d'onda §1 completata. Residui dichiarati in PARITA §3 (⚠️): template SNMP vendor
importabili, wizard inserimento manuale dispositivo, ReAct v15, web push VAPID.

## Avvio
Vedi RUNBOOK §4 in `docs/ROADMAP_CHANGELOG_RUNBOOK.md`: pattern double-fork + preriscaldo
route via `scripts/verify-api.sh` PRIMA del browser e2e (ricetta anti-OOM della sandbox
4 GB), .env con le QUATTRO chiavi, DB reale da /tmp/my-project/db (baseline) o dal proprio
backup, ordine KMZ → Excel → (ri)KMZ per impianti nuovi.

Login demo: `admin@falco-os.local` / `FalcoDemo2026!` — Next :3000 (dev) · realtime :3001
(tick 30 s) · discovery :3002.
