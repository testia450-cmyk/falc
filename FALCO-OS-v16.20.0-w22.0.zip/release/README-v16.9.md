# FALCO-OS v16.9.0-w4.0 — ONDA W4 COMPLETA

**Data:** 30/10/2026 · **Richiesta operatore:** «Vai con w4» · **Task worklog:** 35
**Contenuto:** ZIP sorgente (251 file) · **DB reale NON incluso** (proprietà dell'operatore, vedi db/LEGGO.md)

## Cosa è stato consegnato (W4 — l'ultima onda residua della roadmap §1)

| Voce | consegna | note |
|---|---|---|
| **Knowledge base impianto** | CRUD + «da ticket» | il corpo nasce dai campi REALI del ticket (Problema/Soluzione); KB=0 righe nel DB reale → empty onesto |
| **RMA guidata con genealogia** | port fedele v15.12.0 decisione 53 | piano (BFS reachability multi-gateway, credenziali cifrate portabili, avvisi guasto a monte) + esecuzione 5 passi in transazione; verificata E2E su dispositivo scratch e REVERTITA |
| **Ondate config/firmware** | pianificazione completa | preflight reale con scarti onesti, lotto 1 = canary; D2: motore di esecuzione dichiarato non attivo in riproduzione |
| **CVE scan** | motore cve-match v15 portato FEDELE | **79 finding REALI sul plant egidio** (23 CRITICAL · 37 HIGH · 19 MEDIUM) con il catalogo dimostrativo importato — poi revertito: la scelta spetta all'operatore (un click) |
| **Speed test iperf3** | v11.9 G6 portato | binario assente → 501 EXECUTOR_DOWN ONESTO senza riga scritta; executor SIMULATED marcato, mai spacciato |
| **Assistente AI** | STREAMING reale su contesto REALE del DB | model della piattaforma (z-ai-web-dev-sdk, solo backend — decisione D24); audit bounded senza contenuto |
| **Amministrazione completa** | CRUD utenti + matrice RBAC v2 + sessioni | policy password enterprise v15 V12-H, guardie ultimo SUPER_ADMIN/self-delete, 36 permessi × 4 ruoli, onestà JWT stateless |

**API:** 24 route v2 nuove → **106 totali documentate** (docs/API_CONTRATTI.md, generato dai contratti zod).
**UI:** 2 tab nuove in Operazioni (Knowledge base · RMA e ondate), tab CVE in Allarmi, tab Speed test in Rete, tab Utenti e permessi in Amministrazione, vista Assistente in sidebar.

## Verifica (evidenze)

- `scripts/verify-api.sh` — **176 controlli verdi**, sezione §3h W4 nuova (cicli self-cleaning KB/ondate, RMA piano+422+404, CVE no-op onesto, speed 501 senza righe, admin users/policy/409/permissions/sessions); 401 su 37 route senza sessione.
- Browser e2e completo (desktop 1440 + mobile 390 px, zero errori console): ogni ciclo è stato REVERTITO — **il DB reale resta PRISTINO** (200 dispositivi · 1 utente · 0 righe in tutte le tabelle W4, D25).
- Screenshot in download/: w4-cve-finding-reali.png (79 finding sul reale), w4-assistente.png (streaming con dati reali), w4-rma-piano.png, w4-utenti.png, w4-speedtest.png, w4-kb-mobile.png, w4-assistente-mobile.png, w4-cve-vuota.png.
- tsc 0 errori · lint 0 errori (1 warning pre-esistente TanStack/React Compiler).

## Incidenti e fix della sessione

- **Incidente piattaforma #5** (30/10, pre-work): DB di nuovo vuoto + .env dimezzato → ripristino standard consolidato (baseline combacianti al 100%, verify-api verde post-ripristino).
- **FIX tab Rete controlled**: lo store `reteTab` scartava il valore 'speed' → tab Speed test non attivabile; tipo e mapper estesi, deep link `?view=rete&rete=speed`.
- **FIX buco git 16.7/16.8**: la regola `.gitignore` «test» (senza slash) ignorava OGNI percorso chiamato test — la route `/api/v2/integrations/test` (W7) era presente solo nell'ZIP di release e MAI committata. Regola ristretta a `/test` + route recuperata byte-per-byte.
- Due OOM del dev server durante la compilazione in raffica delle route nuove → runbook: pre-compilazione sequenziale prima dei test.

## Stato della roadmap

W0 ✅ · W1 ✅ · **W2 ✅ 16.8** · **W3 ✅ 16.7** · **W4 ✅ 16.9** · W5 ❌ (bocciata dall'operatore) · **W6 ✅ 16.8** · **W7 ✅ 16.7**.
**Tutte le onde della roadmap §1 sono ora completate.** Residui dichiarati (onestà): le voci ⚠️ della matrice PARITA §3 (motori batch, 2FA, API token, push VAPID, template SNMP vendor…) restano decisione dell'operatore; le esecuzioni SSH/SNMP/poller non girano in modalità riproduzione (D2).

## Avvio

Vedi RUNBOOK §4 in docs/ROADMAP_CHANGELOG_RUNBOOK.md (pattern subshell, .env a 4 righe, pre-compilazione).
Login demo: `admin@falco-os.local` / `FalcoDemo2026!`.
