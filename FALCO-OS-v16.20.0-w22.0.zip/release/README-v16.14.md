# FALCO-OS v16.14.0-w12.0 — NOC (release sorgente)

Release del **30/10/2026 (notte)** — **MIGLIORAMENTO INTEGRATO DEI MOTORI DI MONITORAGGIO**: ricostruzione **Layer-2 della rete in bridge** (LLDP-MIB + CDP cache + BRIDGE-MIB/Q-BRIDGE FDB), SNMP **multi-community**, identificazione **batch** («puller» integrato), sweep **mDNS/SSDP** universali, classificazione **intelligente** con identità prodotto dal sysDescr e ping TCP **adattivo a due passate** — su richiesta diretta dell'operatore: «migliorare compatibilità vendor e letture SNMP · migliorare grafica e tipografia · migliorare performance · migliorare puller e integrazione · migliorare intelligenza · migliorare Discovery e adattamento a tutte le tipologie di rete · migliorare motore scansione e riconoscimento prodotti e apparati · migliorare topologia e situazioni con rete in bridge per letture e ricostruzione rete in modo giusto».

> Etichetta interna del codice: **«v16.8 ondata miglioramenti»** nei commenti dei nuovi moduli (l'onda di sviluppo è stata battezzata così durante il lavoro; il rilascio segue la numerazione della serie: 16.14.0-w12.0).

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.14.0-w12.0 (rispetto a 16.13.0-w11.0)

### 1 · Motore di ricostruzione Layer-2 — «la rete in bridge, letta per davvero»

- **`mini-services/discovery-service/lib/snmp-l2.ts` (NUOVO, ~650 righe)**: sonda SNMP Layer-2 di uno switch/router che legge TUTTE le dichiarazioni reali:
  - **LLDP-MIB** (IEEE 802.1AB, `1.0.8802.1.1.2.1.4.1`): vicini per porta locale con sysName/sysDesc/**chassisId e portId decodificati per subtype** (MAC, indirizzo di rete IPv4/IPv6, nome interfaccia, locale — decodifica a due fasi perché il subtype arriva DOPO il valore nell'ordine OID);
  - **CDP cache** (CISCO-CDP-MIB): deviceId/devicePort/version/platform per ifIndex;
  - **BRIDGE-MIB**: `dot1dBasePortIfIndex` (porta bridge → ifIndex) + **`dot1dTpFdbPort`** (la tabella MAC appresa: il MAC è nell'INDICE OID, 6 archi finali — fonte canonica; **i MAC multicast/broadcast sono scartati** perché il traffico inondato non è un dispositivo);
  - **Q-BRIDGE-MIB** (`dot1qTpFdbPort`): FDB VLAN-aware con **VLAN ID decodificato dall'indice dot1qFdbId** (tollerante a 4 e 8 ottetti);
  - **IF-MIB**: ifDescr/ifName/ifType/ifAdminStatus/ifOperStatus/ifSpeed/ifHighSpeed → porte con nome e stato REALI.
  - Multi-community come la sonda di sistema (community cifrata del device → aggiuntive → public), fallback v2c→v1 (un agente solo-v1 scarta le richieste v2c in silenzio: senza tentativo v1 resterebbe invisibile), sessione dedicata ai walk con timeout corto e 1 ritrasmissione.
- **`POST /probe/l2` (mini-service)**: un'unica sonda che restituisce vicini LLDP/CDP + FDB classica + FDB VLAN + interfacce + AVVISI onesti (walk mancato = avviso, mai dato inventato). Guardia dedicata 40 s.
- **`src/lib/domain/l2-reconstruct.ts` (NUOVO, funzione pura)**: la ricostruzione combina le tre dichiarazioni in ordine di affidabilità:
  - **LLDP/CDP → link HIGH** (il vicino dichiara se stesso; abbinamento per sysName o chassisId MAC);
  - **FDB → link MEDIUM** (`FDB_ENDPOINT`): il MAC di un dispositivo NOTO appare su UNA porta → è collegato lì;
  - **più dispositivi noti sulla STESSA porta → segmento condiviso**: link LOW `DAISY_CHAIN` — l'onestà di NON fingere un cavo dedicato dove c'è un bridge/daisy-chain (con segnalazione delle porte condivise);
  - vicini dichiarati ma assenti dall'inventario → «non abbinati» (l'adozione resta umana); MAC appresi su più porte (flapping/STP) → link NON creato, avviso.
- **`POST /api/v2/discovery/l2` (role ≥ TECNICO)**: sonda l'apparato dell'inventario → ricostruzione → **persistenza**: `FdbObservation` upsert (alimenta l'inventario MAC e la vista per porta) + `TopologyLink` upsert **SOLO su link inferiti** (i link dell'OPERATORE — TECHNICIAN o confirmed — sono INToccabili per costruzione) + `AuditLog TOPOLOGY_L2_SCAN` (chi/che cosa/esito). Community: prima quella CIFRATA del dispositivo, poi le aggiuntive, poi public — il servizio dichiara quale ha risposto (`matched`).
- **UI — dialog «Ricostruisci L2» nella vista Rete**: pulsante nella barra fonti → scelta apparato (switch/router/gateway in cima, il resto segue) → community aggiuntive → report onesto: badge «SNMP raggiunto · public (v2c)», conteggi LLDP/CDP/FDB, link creati/aggiornati/dell'operatore-saltati, elenco link con porta locale+remota+velocità, vicini non abbinati, segmenti condivisi, avvisi. **Se la sonda produce link FDB, la famiglia «Inferiti (bridge/FDB)» si accende da sola** (l'operatore li vede subito, può sempre spegnerla coi chip). Fonte **CDP** aggiunta a LINK_SOURCES e alla famiglia «Protocolli». Legenda aggiornata: archi FDB/Q-BRIDGE puntinati.

### 2 · Compatibilità vendor e letture SNMP

- **Enterprise OID: +16 voci IANA verificate** (ora ~66): 3Com, Apple, Arista, H3C 25506/2013, Brocade, Foundry, Accton (OEM), Ericsson, Siemens, MGE UPS, Synology, VMware ESXi, NetApp, e **net-snmp/UCD 2021+8072 — l'agente Linux standard** (un'intera categoria di server ora identificata per OID).
- **SNMP MULTI-COMMUNITY** (`communities[]`, max 8): un agente con community errata scarta il pacchetto IN SILENZIO — provare le successive è l'unica strada onesta; il risultato dichiara quale ha risposto. Disponibile su /probe/snmp, /probe/vendor, batch e L2.
- **Fallback v2c→v1** su errore di protocollo; **SNMPv3 completo**: SHA-2 (sha224/256/384/512) e AES-192/256 oltre a md5/sha/aes/des.
- **Estrazione identità prodotto** (`guessProductIdentity`, dal sysDescr REALE): Cisco IOS/NX-OS/ASA (modello+versione), RouterOS/SwOS, ePMP, FortiOS (modello+fw), Huawei VRP, Comware, APC NMC, Synology DSM, Linux kernel, Windows build, VyOS/pfSense, AirOS/UniFi con modello board — esposta come `product {osFamily, osVersion, model}` e nella classificazione (`os`, `osVersion`, `firmwareVersion`).
- **Firme vendor estese** in sysDescr/banner/OUI: Arista, H3C, Synology, QNAP, DrayTek, Yealink, Fanvil, brand stampanti (HP LaserJet/JetDirect, Kyocera, Ricoh, Xerox, Lexmark, Brother, Zebra), brand UPS (APC, Eaton, Vertiv), pfSense/OPNsense, VyOS, OpenWrt, Windows.
- **Banner HTTP arricchito**: realm `WWW-Authenticate` + **impronta del certificato TLS** (CN/issuer del peer certificate self-signed: router e camere spesso dichiarano vendor e modello nel CN — un'impronta gratuita). Porte del set v15 allargate: **5060 SIP · 631 IPP · 9100 JetDirect · 7547 TR-069**.

### 3 · Intelligenza del classificatore (`classify.ts`)

- **NUOVI TIPI**: UPS (schede APC NMC/Eaton/MGE/Verti + OUI), PRINTER (JetDirect, 9100/631, brand di stampa), PBX (UCM/3CX/Asterisk), PHONE (SIP 5060 con firma VoIP), NAS (Synology/QNAP/ReadyNAS), MODEM (TR-069 7547), SERVER (net-snmp Linux+SSH+HTTP, ESXi), CLIENT Windows via SNMP. Le etichette italiane complete in `TYPE_LABELS` (Gruppo di continuità, Stampante di rete, Centralino VoIP, Telefono SIP…).
- **Confidenza PESATA per fonte**: ONVIF 4 · enterprise-OID 3 · sysDescr 2 · banner 1,5 · realm/CN 1,5 · OUI 0,75 · porte 0,5 → soglie high ≥3 / medium ≥1,5; la concordanza di ≥2 fonti resta «high». Stesso contratto API (high/medium/low), punteggio ora motivato.
- Priorità dichiarazione > euristica: UPS/NAS/PBX/PRINTER entrano PRIMA delle euristiche generiche di porta.

### 4 · Performance e «puller» integrato

- **`POST /probe/vendor/batch`** (+ `/api/v2/discovery/vendor-batch`): identificazione di **N≤32 IP in UNA richiesta** (concurrency 1-16 controllata, guardia 55 s): il puller fa UN round-trip verso il motore invece di N fetch sequenziali da 5-15 s l'uno. UI: «**Identifica tutti**» nella tabella della scansione → classificazione inline per IP (tipo/brand/modello/confidenza), durata e concorrenza dichiarate.
- **Ping TCP adattivo a DUE PASSATE**: prima passata col timeout richiesto (gli host vivi rispondono subito, costo invariato); SOLO gli host ancora muti riprovano le porte chiuse a ~2,5× — gli host lenti non allungano il tempo di quelli veloci. Campi `slowHost`/`secondPass`/`slowHosts` (badge «lento» onesto nella UI).
- **mDNS + SSDP (nuovi sweep universali)**: DNS-SD/Bonjour UDP 5353 multicast (parser DNS leggero con compression pointer: hostname + servizi dichiarati) e UPnP SSDP UDP 1900 (SERVER/USN/ST/LOCATION) — **funzionano su QUALSIASI rete senza credenziali**: stampanti, NAS, Chromecast, CPE, TV. Rotte `/discover/mdns` e `/discover/ssdp`; capacità dichiarate in /health.
- **FIX CRITICO (preesistente)**: `bun --hot` **spezza i callback dei socket UDP** in Bun 1.3.14 — le sonde SNMP/mDNS/SSDP/Ubiquiti/MNDP erano MUTE nel servizio avviato in hot mode (timeout eterni). Scoperto con test empirici e documentato in package.json: il servizio ora gira con `bun` diretto (+ watchdog per l'ambiente sandbox). Questo da solo ripristina le letture SNMP reali.

### 5 · Grafica, tipografia e contesto

- **Tipografia dati**: `.num` con feature-settings tnum+cv03 e letter-spacing (IP/MAC/latenze mai tremolanti), `.num-mono`, headings con tracking ottico, `.dl-grid`, `.table-data` (densità tabelle), `.press` (micro-feedback), `.fade-in-80` (con prefers-reduced-motion), `.list-clamp` (liste lunghe con overscroll-contain), scrollbar più sottile con hover.
- **Scanner view potenziata**: campo **community SNMP** (lista tentata dichiarata nel risultato), colonna Classificazione con chip inline, indicatore «lento» per gli host della seconda passata, 10 nuove capability badge del motore (LLDP-MIB, CDP cache, BRIDGE-MIB (FDB), Q-BRIDGE (VLAN), mDNS/Bonjour, SSDP/UPnP, Batch identify, Impronta TLS, Multi-community, Ping 2 passate).
- **Dialog «Identifica apparato»**: badge community+versione che hanno risposto, identità dichiarata (OS/firmware), OS estratto dal sysDescr, realm HTTP e CN del certificato TLS.

## Verifica (onda w12.0)

- **Simulatore SNMP dedicato** (`mini-services/discovery-service/sim/snmp-sim.ts`, BER scritto a mano, zero dipendenze): switch MikroTik CRS317 simulato con 6 interfacce, 2 vicini LLDP (chassisId MAC e networkAddress IPv4), 1 vicino CDP, FDB con MAC multicast da scartare, FDB Q-BRIDGE VLAN 20.
- **Motore L2 contro il simulatore**: reachable + sysName + matched public/v2c · 2 LLDP decodificati (MAC e IP!) · 1 CDP completo · 5 FDB (multicast scartato) · 1 vlanFdb (VLAN 20 decodificata) · 6 interfacce (ether4 operStatus=2 letto correttamente) · zero avvisi.
- **l2Reconstruct (funzione pura) con asserzioni**: 7 link attesi esatti — 2 LLDP HIGH (porta+porta remota), 1 CDP HIGH, 4 DAISY_CHAIN LOW su 2 segmenti condivisi (ether5: 2 dispositivi, ether4: 2 dispositivi) · orfano NON collegato · multicast escluso · vicini non abbinati onesti.
- **Browser e2e (agent-browser, login reale admin)**: vista Rete → dialog «Ricostruisci L2» → sonda su switch di test → **7 link creati nel DB reale + 6 osservazioni FDB + audit TOPOLOGY_L2_SCAN** (verificati via query Prisma) → famiglia INFERRED accesa automaticamente → grafo con 8 archi per lo switch (1 operatore + 2 LLDP + 1 CDP + 4 daisy-chain, evidenze e confidenze corrette). Vista Operazioni → Scansione: capabilities nuove visibili → scansione 127.0.0.1/32 porte custom → 1 host vivo → **«Identifica tutti» → batch in 2,5 s · concorrenza 8** con esito onesto 0/0 (localhost non espone porte di servizio standard) e chip «Da classificare» in tabella.
- **Multi-community verificata**: community sbagliata → silenzio → public risponde (matched dichiarato). **Estrazione prodotto**: «RouterOS 7.15.2 (stable) CRS317-1G-16S+» → RouterOS 7.15.2 + modello CRS317-1G-16S+ + MikroTik da OID 14988.
- **Ambiente**: tsc 0 errori · lint 0 errori (1 warning preesistente TanStack) · tutte le viste 200 · zero errori console · DB demo lasciato PRISTINO (dispositivi/link/osservazioni di test rimossi, audit append-only conservato).
- **Nota ambiente sandbox (documentata)**: 4 GB di RAM condivisi con next-dev + chromium provocano OOM sporadici sui SERVIZI durante le compilate della UI (il killer colpisce anche il dev server); il watchdog `watchdog.sh` tiene in vita il discovery. Nessun effetto sul codice rilasciato.

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: ora ~44 rotte; nuove `/discovery/l2` e `/discovery/vendor-batch`; contratti zod con L2/batch/CDP; `lib/domain/l2-reconstruct.ts` funzione pura; viste Dashboard/Rete/Dispositivi/Telecamere/Allarmi/Operazioni/Assistente/Report/Amministrazione + Wallboard)
- `prisma/schema.prisma` — schema invariato (123 modelli: le FdbObservation e i TopologyLink con fonti FDB/BRIDGE_MIB/DAISY_CHAIN/CDP esistevano già — ora hanno un MOTORE REALE che le riempie)
- `mini-services/realtime-service/` — socket.io (porta 3001)
- `mini-services/discovery-service/` — motori di rete (porta 3002): TCP 2 passate · SNMP v1/v2c/v3 multi-community · **sonda L2 (LLDP+CDP+BRIDGE+Q-BRIDGE+IF-MIB)** · ONVIF · OUI 10.679 prefissi · Ubiquiti/MNDP/WS-Discovery · **mDNS/SSDP** · **batch** · impronta TLS; `sim/snmp-sim.ts` simulatore di verifica; `watchdog.sh`
- `docs/` — 7 documenti vivi (ROADMAP_CHANGELOG aggiornato alla 16.14.0-w12.0)
- `release/evidence/w12/` — screenshot della topologia con i link L2 ricostruiti

**Nota deploy**: `cd mini-services/discovery-service && bun install` (scarica net-snmp) poi `bun run dev`; il servizio Next con `bun run dev`. Il DB demo (non incluso nello zip sorgente, come da convenzione) resta nel deployment esistente.
