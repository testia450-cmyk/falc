# FALCO-OS v16.2.0-w2.1 — NOC (release sorgente)

Release del **26/10/2026** — wallboard TV per monitor dedicato, finestre di manutenzione in scrittura (inizio W3), export «Sintesi impianto PDF» via stampa del browser.

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.2.0-w2.1 (rispetto a 16.1.0-w2.0)

- **Wallboard TV**: `/?view=wallboard` (o bottone monitor in topbar) — overlay a tutto schermo per sala operazioni con KPI grandi aggiornati dal tick realtime, allarmi aperti per gravità, link radio deboli, orologio, uscita con Esc. Segue tema chiaro/scuro. Non è una voce di menu: è una modalità di presentazione.
- **Finestre di manutenzione in scrittura** (inizio W3): creazione (POST reale con audit `MAINTENANCE_CREATE`), pausa/ripresa (PATCH ACTIVE⇄PAUSED con audit `MAINTENANCE_STATE`), eliminazione (DELETE con audit `MAINTENANCE_DELETE`; gli interventi collegati restano nel registro). Scope per gruppi non ancora selezionabile: nel DB reale `DeviceGroup` è vuoto (0 righe) — dichiarato in UI.
- **Report**: 4ª card export «Sintesi impianto (PDF)» — documento autonomo con gli indicatori reali, apre la finestra di stampa del browser («Salva come PDF»).
- API: 3 rotte nuove (POST `/api/v2/maintenance`, PATCH/DELETE `/api/v2/maintenance/{id}`) → **23 totali**, contratti zod e `docs/API_CONTRATTI.md` rigenerati.
- Strumento di verifica ripetibile: `bash scripts/verify-api.sh` (login reale, 17 GET, ciclo manutenzione completo con auto-pulizia, 401 senza sessione).

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: 23 rotte con contratti zod; viste: Dashboard, Rete, Dispositivi, Telecamere, Allarmi, Operazioni, Report, Amministrazione + Wallboard; design system a due temi)
- `prisma/schema.prisma` — schema del DB reale (123 modelli, invariato dall'import)
- `mini-services/realtime-service/` — servizio socket.io (porta 3001, tick 30 s in **modalità riproduzione dichiarata**)
- `docs/` — 6 documenti vivi: AUDIT_E_INVENTARIO, ARCHITETTURA_E_DECISIONI (D14/D15 nuove), DESIGN_SYSTEM, API_CONTRATTI (generato da zod: `bun scripts/gen-api-contracts.ts`), TEST_E_CERTIFICAZIONE (matrice T01–T34), ROADMAP_CHANGELOG_RUNBOOK
- `worklog.md` — registro di lavoro condiviso tra agenti (storia completa delle decisioni)
- `scripts/` — generatore dei contratti API + verifica API (`verify-api.sh`)

**NON incluso**: `node_modules/`, `.next/`, `db/custom.db` (il DB reale dell'impianto, ~292 MB, resta di proprietà dell'operatore — vedi sotto), `.env` (segreti).

## Requisiti

- Bun ≥ 1.3 (o Node ≥ 20 + npm: adattare gli script)
- ~2 GB di RAM liberi per lo sviluppo (dev server + servizio realtime)

## Installazione

```bash
bun install                # dipendenze
cp .env.example .env       # e valorizzare i segreti (vedi sotto)
bun run db:generate        # genera il client Prisma
# DB: copiare il proprio custom.db (schema 123 modelli) in db/custom.db
bun run db:push            # allinea lo schema (nessuna migrazione distruttiva sui dati esistenti)
```

Avvio completo (due processi):

```bash
bun run dev                                        # app su :3000
cd mini-services/realtime-service
DATABASE_URL="file:/percorso/assoluto/db/custom.db" bun --hot index.ts   # realtime su :3001
```

Accesso: `admin@falco-os.local` / `FalcoDemo2026!` (password demo: l'hash originale di produzione resta nel DB dell'operatore). La sessione è cookie-based (NextAuth credentials).

## Onestà del dato (regola di progetto)

- Nessun dato inventato: ogni numero proviene dal DB reale o viene etichettato «n.d.»/UNKNOWN.
- La modalità **riproduzione** (realtime-service) simula la freschezza del polling su dati reali importati: è dichiarata in ogni schermata e in ogni risposta API (`mode`).
- Le funzioni non costruite NON sono simulate: restano roadmap dichiarate nelle viste (Report → «Report programmati», Amministrazione → «Roadmap»).

## Documentazione

Vedi `docs/ROADMAP_CHANGELOG_RUNBOOK.md` per il runbook operativo (avvio, diagnosi, wallboard su TV, verifica API) e `docs/TEST_E_CERTIFICAZIONE.md` per la matrice di certificazione T01–T34 con evidenze.
