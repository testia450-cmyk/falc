# FALCO-OS v16.15.0-w13.0-w16.0 — NOC (release sorgente)

Release del **31/10/2026** — **LE DUE DICHIAZIONI CHE MANCAVANO + LA CORRELAZIONE MULTI-SWITCH**: la sonda Layer-2 ora legge anche la **tabella ARP** (IP-MIB ipNetToMedia + ipNetToPhysical RFC 4293) e lo **Spanning Tree** (BRIDGE-MIB dot1dStp: root, rootPort, bridge designato per porta), inventaria le **VLAN** (Q-BRIDGE dot1qVlanStaticTable) e — il cuore dell'onda — **correla più switch in una sola scansione** («Tutti gli switch»): avvistamenti reciproci in FDB → link **FDB_MUTUAL** con le porte di ENTRAMBI i lati, direzione dell'albero dettata dall'STP, promozione dei link inferiori — su conferma operatore «Esegui punti 2 e 3 per il db dopo fatto te lo carico» (onde W13→W16 in un'unica onda; il DB reale ~292 MB verrà caricato dall'operatore a valle: `scripts/prepare-real-db.ts` lo prepara in modo idempotente).

> Convenzione delle onde: W13 (fondazioni: modelli ARP/STP/VLAN + motori) → **W14 (topologia bridge multi-switch — la priorità dichiarata)** → W15 (viste: STP per porta, IP ARP nell'inventario MAC) → W16 (verifica, script DB reale, documentazione).

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Novità 16.15.0-w13.0-w16.0 (rispetto a 16.14.0-w12.0)

### 1 · W13 — I motori delle due dichiarazioni mancanti (OID verificati su fonti ufficiali)

- **`lib/snmp-arp.ts` (NUOVO)**: tabella ARP completa — **ipNetToPhysicalTable** (RFC 4293, IPv4+IPv6, indice ifIndex+tipo+indirizzo decodificato) e **ipNetToMediaTable** (legacy IPv4, l'unica esposta da MikroTik RouterOS e molti agenti embedded) con merge a precedenza (la moderna vince, la legacy riempie); voci `invalid` e MAC multicast scartati con onestà. OID verificati byte per byte sul file MIB ufficiale net-snmp.
- **`lib/snmp-stp.ts` (NUOVO)**: Spanning Tree — scalari in UNA get multi-varbind (dot1dStpDesignatedRoot 8 ottetti decodificati in priorità+MAC, dot1dStpRootPort, dot1dStpProtocolSpecification, dot1dBaseBridgeAddress = il MAC bridge PROPRIO) + dot1dStpPortTable per porta: **stato** (disabled/blocking/listening/learning/forwarding/broken), **bridge designato** (LA chiave per orientare l'albero), porta designata (2 ottetti), costo (PathCost32 preferito). OID verificati sul BRIDGE-MIB net-snmp (dot1dStpPortTable = 17.2.15.1, DesignatedRoot = 17.2.5.0 — NON le posizioni «intuitive»).
- **`lib/snmp-vlan.ts` (NUOVO)**: inventario VLAN — dot1qVlanStaticName + **dot1qVlanStaticEgressPorts decodificato da bitmap** (porta N ⇔ bit 7-((N-1)%8) dell'ottetto (N-1)/8) + RowStatus (solo active) + **dot1qPvid** per porta bridge (VLAN di ingresso dei frame non taggati). OID verificati sul testo del RFC 2674.
- La sonda `/probe/l2` esegue TUTTO nella stessa sessione walk (zero handshake extra): il payload cresce di `arp`, `stp`, `vlans`, `portVlans` + contatori nel `summary`.
- **Schema Prisma ADDITIVO** (nessuna tabella esistente toccata): nuovo modello **`StpObservation`** (unique deviceId+portNum: stato, bridge designato/ID, porta designata, pathCost, isRootPort, rootBridgeId) e **`VlanInventory`** (unique deviceId+vlanId: nome, porte egress CSV); **`ArpEntry`** esisteva dal v15 — ora ha il motore che lo riempie (upsert ip+deviceId, con vendor non toccato in update).

### 2 · W14 — La correlazione multi-switch («come NetDisco, con l'onestà FALCO»)

- **`src/lib/domain/l2-correlate.ts` (NUOVO, funzione pura ~450 righe)**: dati N switch sondati + inventario →
  - **avvistamento reciproco**: A vede il MAC bridge di B su porta pA E B vede quello di A su pB → link **FDB_MUTUAL HIGH con le porte di ENTRAMBI i lati**;
  - **avvistamento singolo** (FDB dell'altro muta o non letta) → **FDB_PAIR MEDIUM**;
  - **direzione dell'albero**: la dice l'STP (chi ha la rootPort sulla porta del link è a valle; poi il bridge designato; tie-break sul bridgeId dichiarato nel dettaglio);
  - **link STP_DESIGNATED** verso apparati d'inventario NOTI ma non sondati (la dichiarazione STP come unica verità disponibile);
  - **root bridge votata dalla maggioranza** + porte verso la root per switch;
  - **ARP di tutti gli switch fuso**: MAC non in inventario con IP noto → `arpCandidates` (candidati adozione con IP e chi li ha visti — l'adozione resta umaNA);
  - MAC flapping (visti su più porte) esclusi con avviso.
- **`POST /probe/l2/batch`** (mini-service): fino a **12 switch in UNA richiesta**, concorrenza 1-4 (bassa e dichiarata: i walk L2 sono many-RTT), guardia dedicata 300 s, dedup target per **ip:porta**.
- **`POST /api/v2/discovery/l2/batch`** (role ≥ TECNICO): selezione automatica degli SWITCH/GATEWAY/ROUTER/FIREWALL attivi dell'impianto (o `deviceIds` espliciti), community CIFRATA del device per ciascuno → sonda batch → `l2Reconstruct` per switch + `l2Correlate` una volta → persistenza con **precedenza delle evidenze** (LLDP/CDP > FDB_MUTUAL > FDB_PAIR/STP_DESIGNATED > FDB_ENDPOINT/DAISY_CHAIN: i link inferiori vengono **PROMOSSI** quando il correlatore porta dati superiori — promozione dichiarata negli avvisi) → audit **TOPOLOGY_L2_BATCH_SCAN**. La rotta singola `/api/v2/discovery/l2` persiste ora anche ArpEntry/StpObservation/VlanInventory con cap onesti (256/128/32) e risposta estesa (blocchi `arp`/`stp`/`vlans`, link con `sourcePortNum` e `stpCorroborated`).
- **`l2-reconstruct.ts` potenziato**: l'STP **corrobora** i link creati (il bridge designato della porta coincide col MAC del target → chip «STP ✓»; discordanze → avviso, mai correzione silenziosa); l'ARP risolve gli IP dei MAC non in inventario (`unmatchedMacsWithIp`).

### 3 · W15 — Le viste

- **Dialog «Ricostruzione Layer-2» con due modalità**: «Singolo apparato» (flusso W12 intatto, report arricchito: blocco STP con root e link confermati, chip VLAN con porte in tooltip, MAC non inventariati con IP ARP, contatori ARP/STP/VLAN) e **«Tutti gli switch»** → report della correlazione: switch raggiunti/durata/concorrenza, root STP votata, porte verso la root, **lista link switch↔switch con badge tipo** (FDB_MUTUAL ok / FDB_PAIR warn / STP_DESIGNATED info) e «STP ✓», tabella per-switch (community che ha risposto, LLDP/CDP/FDB/ARP/STP/VLAN reali), candidati ARP, persistenza, promozioni evidenziate. Auto-accensione della famiglia «Inferiti» (fattorizzata).
- **Scheda dispositivo → tab Porte**: chip **stato STP per porta** (forwarding ok / blocking-learning warn / disabled-broken crit) + chip **«root port»**, dal modello StpObservation.
- **Tab MAC della vista Rete**: colonna **«IP (ARP)»** — l'IP risolto dalla tabella ARP accanto ai MAC non in inventario (join per MAC con doppia normalizzazione, solo sulla pagina corrente), anche nell'export CSV.

### 4 · W16 — Vocabolario, DB reale, verifica

- **LINK_SOURCES completato**: +FDB_MUTUAL/FDB_PAIR/STP_DESIGNATED (il vocabolario v15 li conosceva in `link-rules` TIER_ATTACH_COST; il grafo v16 li escludeva per omissione — **bug trovato in verifica e corretto**: ora i link del correlatore entrano nell'albero e nella famiglia «Inferiti», arco puntato).
- **`scripts/prepare-real-db.ts` (NUOVO)**: preparazione idempotenta del DB reale dell'operatore — backup automatico con timestamp → `PRAGMA integrity_check` PRIMA → push SOLO se mancano le due tabelle nuove (diff additivo) → conteggi di sanità sulle 10 tabelle calde prima/dopo (nessuna riga persa) → report onesto per ogni passo. Dry-run di default; `--yes` per eseguire.
- **`scripts/w13-e2e-bootstrap.ts` (NUOVO)**: ambiente di verifica riproducibile (utente admin demo + impianto `test-l2` con 10 apparati che puntano ai simulatori; `--revert` per pulire).

## Verifica (onde W13-W16)

- **Simulatore SNMP a DUE switch** (`sim/snmp-sim.ts [porta] [scenario]`): SW-CENTRALE (7 if · 2 LLDP · 1 CDP · 7 FDB con multicast da scartare · Q-BRIDGE vlan 20 · **STP con root GW-PRINCIPALE e porta 4 disabled** · **5 ARP legacy** · **2 VLAN + PVID**) e **SW-DISTRIBUZIONE** (nessun LLDP/CDP — il test della correlazione PURA: MAC bridge di SW-CENTRALE in FDB sulla porta 1 = avvistamento reciproco, STP con porta 1 designata da SW-CENTRALE, **ARP moderna RFC 4293** — testa anche il parser nuovo).
- **Scoperte empiricali durante lo sviluppo** (documentate nel codice): il MAC di test `DD:DD:DD:…` aveva il bit multicast acceso e veniva correttamente scartato (corretto in `DC:DD:DD`); il dedup del batch per solo IP collassava due agenti sullo stesso host (corretto per **ip:porta**); gli scalari STP vanno letti con GET non walk (il walk parte dall'OID successivo).
- **Catena di dominio verificata a mano**: `l2Reconstruct` su entrambi gli switch (link LLDP/CDP con **STP ✓**, segmenti condivisi, VLAN) + `l2Correlate` → **FDB_MUTUAL ether6↔ether1 con direzione da rootPort STP**, root votata 2/2, STP_DESIGNATED verso il GW non sondato.
- **API e2e con login reale**: rotta singola → 7 link + 5 ArpEntry + 6 StpObservation + 2 VlanInventory persistiti; batch → **promozione FDB_MUTUAL dichiarata** («era FDB»), 11 link aggiornati, 10 FDB + 9 ARP + 10 STP + 3 VLAN, audit TOPOLOGY_L2_BATCH_SCAN; il grafo con le fonti v16.15 → **10 nodi · 9 archi · FDB_MUTUAL incluso** con i figli a valle.
- **Browser e2e (agent-browser, desktop + mobile 390px)**: login → Rete → dialog L2 → «Tutti gli switch» → report completo (2/3 switch raggiunti — GW onestamente irraggiungibile, root STP AA:BB:CC…11:22:33 (2 voti), link con porte dei due lati e «STP ✓», tabella per-switch, promozioni evidenziate) → scheda SW-CENTRALE → tab Porte con **chip «STP forwarding» e «root port» su ether1** → tab MAC → raggiera **«Albero costruito su 9 di 9 collegamenti · 0 inferenze escluse»**. Mobile 390px: scrollWidth = clientWidth (nessun overflow); ZERO errori console/pagina.
- **verify-api.sh §3k NUOVA** (testata isolata, tutta verde): 404/422 onesti, contratto batch completo (12 campi data + 7 persistence + 12 stats per-switch), FDB_MUTUAL nel grafo, `arpIp` nell'inventario MAC — **ambiente-adattiva** (senza l'impianto di test salta le verifiche che richiedono i simulatori, dichiarandolo).
- Ambiente: tsc 0 errori · lint 0 errori (1 warning preesistente TanStack) · tre servizi attivi.

## Il DB in consegna e il DB reale

Il `db/custom.db` del pacchetto è il **placeholder di verifica** con l'impianto `test-l2` (10 apparati verso i due simulatori SNMP) e l'utente admin demo documentato (admin@falco-os.local / FalcoDemo2026!) — serve a provare subito la correlazione dal Preview. Quando l'operatore carica il DB reale (~292 MB):

1. `cp /percorso/custom.db db/custom.db`
2. `bun scripts/prepare-real-db.ts --yes` (backup + integrity + push additivo + conteggi)
3. riavviare i tre servizi.

Tutte le novità W13-W16 funzionano identiche sul DB reale: le tabelle nuove nascono vuote e si riempiono alla prima «Ricostruisci L2» / «Tutti gli switch».

## Contenuto del pacchetto

- `src/` — applicazione (API additive `/api/v2/*`: ora ~46 rotte; **nuova `/discovery/l2/batch`**; contratti zod con batch/correlazione; **`lib/domain/l2-correlate.ts`** funzione pura; `lib/v2/l2-persist.ts` persistenza condivisa con cap onesti; viste + dialog L2 due modalità + chip STP/IP ARP)
- `prisma/schema.prisma` — **+2 modelli additivi** (StpObservation, VlanInventory + back-relations): 125 modelli
- `mini-services/realtime-service/` — socket.io (porta 3001)
- `mini-services/discovery-service/` — motori di rete (porta 3002): tutto W12 + **sonda ARP (legacy+RFC 4293) · STP · VLAN/PVID · `/probe/l2/batch` (max 12, concorrenza 1-4)**; `sim/snmp-sim.ts` a **DUE scenari**; watchdog
- `scripts/` — **`prepare-real-db.ts`** (migrazione additiva idempotenta per il DB reale) · `w13-e2e-bootstrap.ts` (ambiente di verifica reversibile) · verify-api.sh con §3k
- `docs/` — 7 documenti vivi (ROADMAP changelog 16.15, PARITA aggiornata: ARP/STP/VLAN/porte/MAC-inventory)
- `release/evidence/w13-16/` — screenshot (dialog batch, porte con STP, raggiera completa, mobile)

**Nota deploy**: `cd mini-services/discovery-service && bun install` (scarica net-snmp) poi `bun run dev`; il servizio Next con `bun run dev`. Il DB placeholder resta nel pacchetto SOLO come ambiente di prova (vedi db/LEGGO.md).
