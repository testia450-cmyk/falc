# FALCO-OS v16.17.0-w18.0 — NOC (release sorgente)

Release del **31/10/2026 (sera)** — **LA MAPPA DIVENTA UISP**: i punti sulla mappa dicono il loro nome, **il click apre l'elenco di TUTTI i dispositivi della sede** (pattern UISP di Ubiquiti), e **la rete reale si vede sul territorio** (linee tra le sedi dall'albero topologico) — su richiesta operatore «come faccio a caricare file excel e file kmz? come viene interpretato il file excel? permetti poi ai punti sulla mappa: uno di sapere il nome del punto, due quando ci clicco deve apparire tutti i dispositivi appartengono al punto come fa UISP di ubiquity, tre facciamo in modo che il file excel venga analizzato cosi puo essere d'aiuto alla ricostruzione della rete».

> **Dove si carica Excel e KMZ** (domanda 1): **Amministrazione → Impianti → menu ⋯ della card dell'impianto** → «Importa punti KMZ/KML…» / «Importa Excel installazione…». Da questa release anche **un tasto direttamente dalla mappa** (Rete → Mappa → «Importa Excel/KMZ») col deep-link `?view=amministrazione&sez=impianti`. **Ordine consigliato per un impianto nuovo**: KMZ → Excel → (ri)KMZ (il primo crea le sedi col GPS, l'Excel popola apparati+topologia, l'ultimo KMZ chiude i buchi coi percorsi «Linea»).

App: Next.js 16 (App Router) + React 19 + TypeScript 5 + Tailwind 4 + shadcn/ui + Prisma 6 (SQLite) + TanStack Query/Table + zod v4 + socket.io. Unica pagina visibile: route `/` (navigazione a stato URL: `?view=…&device=…`).

## Come viene interpretato l'Excel «formato SETI» (domanda 2)

Il parser (SheetJS, lato server, tetti 15 MB / 200k celle) legge il primo foglio con IPv4 in colonna A (di solito «Rete Nuova»):

- **Sezioni = sedi**: le righe SENZA IP e con un nome («P1 - Via …», «Comando PL», «OLD Cimitero»…) aprono una sezione; le righe di servizio («Rete 172.19.150.0/23», «Ultimo …») e le sub-righe di apparato («Hicentral web») sono scartate CON MOTIVO visibile in anteprima.
- **Righe apparato**: IPv4 in colonna A → `IP · nome · SSID (col C quando non è un IP WAN) · utente (D) · password (E) · seriale (F)`. Il tipo è dedotto dal nome (GATEWAY/NVR/SERVER/SWITCH/STA/AP/LPR/CAMERA, PTP esplicito → connectionType PTP); IP senza nome = slot non assegnato (ignorato).
- **Abbinamento sezione↔sede FUZZY calibrato sui nomi reali** (squash-exact 0.95 · coverage token 0.9 · squash-prefix 0.8 «RIP1»⊂«RIP 1 Via Mazzini» …), con override a tendina in anteprima; i pareggi diventano CREATE col motivo.
- **La ricostruzione della rete (domanda 3, già motore W11 e ora presentata dalla mappa)**: i **GRUPPI SSID** diventano i link RADIO confermati (direzione source=upstream); la **LAN di sede** collega radio hub → SW-POE → apparati (tutto l'albero); la sezione «(Fibra)» chiude l'albero dal gateway; purge OPT-IN dei soli link auto-scoperti; proposte di basestation sintetica MAI pre-confermate. Le **password sono cifrate AES-256-GCM** (rifiuto onesto se manca la chiave).

## Novità 16.17.0-w18.0 (rispetto a 16.16.0-w17.0)

### 1 · W18 — Il punto sulla mappa: nome, popup e TUTTI i dispositivi (pattern UISP)

- **Nome del punto**: sempre visibile nell'etichetta del marker («nome · n. dispositivi», già W1) e ora anche nel **popup Leaflet al click**: nome in evidenza, dispositivi · online · offline · degradati · apparati video. Funziona anche nella mappa compatta della Dashboard. (Bug trovato e corretto in verifica: il popup aperto al click veniva distrutto dal re-render della selezione — ora si apre DOPO la ricostruzione dei marker, e un refresh dati non riapre ciò che l'utente ha chiuso.)
- **Pannello «Dispositivi della sede»**: il click sul punto (o sulla riga della lista sedi) riempie il pannello laterale con l'elenco COMPLETO dei dispositivi della sede — stato, tipo, IP, segnale radio, ultimo visto — ordinati dal peggiore; **ogni riga apre la scheda apparato**. Footer con conteggio e link all'Inventario; scroll interno; invalidazione realtime allo stesso ritmo della mappa.
- **API additiva**: `GET /api/v2/devices?locationId=…` (filtro sede esatta; sede inesistente → `total: 0` onesto; chi non lo passa non lo nota).

### 2 · La rete REALE sul territorio

- Per ogni collegamento dell'albero topologico (fonti già filtrate dal selettore famiglie: **mappa e topologia mostrano la STESSA verità**) con i due capi in sedi diverse e coordinate GPS: **una retta tra i due punti**, disegnata sotto i marker.
- **Stessa colorazione/tratteggio del canvas topologico** (coerenza visiva): giù = rosso tratteggiato · operatore = verde · protocollo (LLDP/CDP/MNDP) = pieno · UISP = info tratteggiato · inferiti = puntinato. **Tooltip al passaggio**: i due capi, tipo collegamento, segnale dBm quando campionato. Contatore in testa («N collegamenti sul territorio»).
- Onestà dichiarata: NESSUNA linea senza dato; più link paralleli tra le stesse due sedi si sovrappongono sulla stessa retta (il tooltip mostra i capi reali).

### 3 · Import a un tasto dalla mappa

- Tasto **«Importa Excel/KMZ»** nell'aside della tab Mappa → deep-link `?view=amministrazione&sez=impianti` (chiave URL `adminSez` additiva nello store; la tab Amministrazione è ora controllata dallo store: condivisibile e refresh-sicura come ogni altro stato).
- Il dialog Excel è invariato (due fasi a zero scritture fino alla conferma; opzioni link/LAN/purge; proposte basestation mai pre-spinlate).

### 4 · DB demo in consegna

- L'impianto `test-l2` del `custom.db` placeholder ora ha **2 sedi demo** («Sede Centrale (demo)» con 7 apparati · «Sede Distaccata (demo)» con 3, coordinate Milano): **la mappa UISP-like si prova SUBITO dal Preview** (popup, pannello dispositivi, linea del collegamento switch↔switch attivando la famiglia «Inferiti» nel selettore fonti). Script idempotente `scripts/w18-demo-sedi.ts`.
- **NESSUNA modifica allo schema Prisma in W18**: il DB reale (~292 MB) entra con `scripts/prepare-real-db.ts` senza migrazioni nuove.

## Verifica (disciplina di sempre)

- **Browser e2e (agent-browser) desktop 1440 + mobile 390**: popup con nome e conteggi (Dashboard e Rete); pannello con TUTTI i dispositivi della sede cliccata; riga dispositivo → scheda apparato (`?device=…`); linee sul territorio col tooltip hover («SW-CENTRALE → SW-DISTRIBUZIONE · ETHERNET»); tasto Importa → Amministrazione con tab **Impianti già selezionata**; menu ⋯ con entrambe le voci di import; **dialog Excel aperto col file reale** `Sant Egidio Monte Albino.xlsx` → anteprima «39 sedi da creare · 181 apparati · 33 link radio · rete 172.19.150.0/23» SENZA scritture (chiuso senza apply); mobile 390px **NESSUN overflow** (scrollW 0 vs clientW 390) con pannello pienamente scorribile; **zero errori console/pagina**.
- **verify-api.sh §3m NUOVA** (filtro `locationId`): `total` == dispositivi della sede, NESSUNA riga di altre sedi nella risposta, sede inesistente → 0 — verde. Suite completa: le asserzioni delle sezioni real-DB (egidio: sla/tickets/audit-chain/purge) restano rosse sul DB placeholder come documentato dall'era W11 (il loro dato non esiste in questo ambiente); tutte le verifiche indipendenti dal dato verde.
- API a mano: `/locations` (2 sedi demo con conteggi), `/devices?locationId=…` (7/3), `/topology/graph` (linkStats coerenti).
- tsc **0 errori** · lint **0 errori** (1 warning noto TanStack Table, documentato).

## Contenuto del pacchetto

- Sorgente completo dell'app: `src/` (Next.js 16 App Router, 86+ route API v2), `mini-services/` (realtime :3001, discovery :3002 con sonde e simulatore SNMP a due scenari), `prisma/schema.prisma` (125 modelli — invariato in W18), `scripts/` (verify-api.sh con §3m, prepare-real-db.ts, w18-demo-sedi.ts), `docs/` (ROADMAP/PARITA/API_CONTRATTI rigenerato/ARCHITETTURA…), `release/evidence/w18/` (5 screenshot di questa onda), `db/custom.db` placeholder con impianto `test-l2` + 2 sedi demo + admin demo.
- **NON inclusi** (come da pattern): `node_modules/`, `.next/`, `.git/`, `.env` (vedi `.env.example`), `upload/` (i file reali dell'operatore restano suoi), DB reale (~292 MB).

## Avvio rapido (come 16.16)

```bash
bun install
cp .env.example .env            # compilare le 4 chiavi (vedi RUNBOOK)
bunx prisma generate            # client Prisma
bun run dev                     # app su :3000
# mini-servizi (altri terminali):
cd mini-services/realtime-service && bun run dev     # :3001
cd mini-services/discovery-service && bun run dev    # :3002
# simulatori SNMP per provare L2/ARP/STP/candidati:
cd mini-services/discovery-service && bun sim/snmp-sim.ts 1161 centrale &
cd mini-services/discovery-service && bun sim/snmp-sim.ts 1162 distribuzione &
```

Login demo: `admin@falco-os.local` / `FalcoDemo2026!` (impianto `test-l2`). La mappa si apre in **Rete → Mappa**: click su un punto → popup + pannello dispositivi; per vedere la linea switch↔switch attivare «Inferiti» nel selettore fonti della tab Topologia (o deep-link `?view=rete&rete=mappa&fonti=TECHNICIAN,PROTOCOLS,UISP,INFERRED`).

## Prossimo passo operativo (invariato)

Il DB reale (~292 MB) entra con `bun scripts/prepare-real-db.ts --yes` (backup automatico, integrity check, push SOLO additivo se mancano le tabelle W13-W16 — W18 NON ne aggiunge). Vedi `db/LEGGO.md`.
