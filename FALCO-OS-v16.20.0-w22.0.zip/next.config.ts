import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* W6 hardening — header di sicurezza su TUTTE le risposte:
   *  · nosniff: nessun MIME sniffing del browser;
   *  · Referrer-Policy stretta;
   *  · Permissions-Policy: API camera/mic/geo NON usate dalla console
   *    (i flussi video sono <img>/<video> dai NVR, non getUserMedia).
   * X-Frame-Options/frame-ancestors NON viene impostato: la console è
   * incorporata LEGITTIMAMENTE nel pannello di anteprima sandbox (e in
   * produzione in eventuali wallboard iframe): la scelta è DOCUMENTATA,
   * in produzione con dominio dedicato valutare frame-ancestors 'self'.
   */
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
  /* Ambiente sandbox (4 GB RAM): il server dev con Turbopack sta a
   * ~2,3-2,6 GB di RSS (limite memoria ≠ RSS: verificato W9 abbassando
   * a 512 MiB — nessun calo, solo più eviction di cache). L'RSS è del
   * grafo moduli dell'app e non si comprime: la ricetta W9 per non
   * finire nell'OOM killer è (1) avviare il server con double-fork
   * orfanizzante — vedi RUNBOOK §Avvio sandbox — così il reaper del
   * terminale non lo uccide, (2) PRERISCALDARE tutte le route via
   * scripts/verify-api.sh PRIMA di aprire il browser e2e. */
  experimental: {
    turbopackMemoryLimit: 1_073_741_824, // 1,0 GiB (abbassato da 1,5: OOM killer durante le ricompilazioni)
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
