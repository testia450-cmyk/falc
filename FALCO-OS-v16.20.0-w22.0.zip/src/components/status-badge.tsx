/* Stato = COLORE + ICONA + TESTO, sempre (§4.2): mai un semplice
 * punto colorato (difetto dei mockup §3.3.2). */

'use client'

import { Badge } from '@/components/ui/badge'
import {
  Wifi, WifiOff, TriangleAlert, Wrench, HelpCircle, EyeOff, type LucideIcon,
} from 'lucide-react'
import { STATUS_META } from '@/lib/client/format'
import { cn } from '@/lib/utils'

const STATUS_ICONS: Record<string, LucideIcon> = {
  ONLINE: Wifi,
  DEGRADED: TriangleAlert,
  OFFLINE: WifiOff,
  MAINTENANCE: Wrench,
  UNKNOWN: HelpCircle,
  NOT_MONITORED: EyeOff,
}

export function StatusBadge({
  status,
  size = 'sm',
  className,
}: {
  status: string
  size?: 'sm' | 'xs'
  className?: string
}) {
  const meta = STATUS_META[status] ?? STATUS_META.UNKNOWN
  const Icon = STATUS_ICONS[status] ?? HelpCircle
  return (
    <Badge
      variant="outline"
      className={cn(
        'gap-1.5 font-medium whitespace-nowrap',
        meta.cls,
        size === 'xs' ? 'px-1.5 py-0 text-[11px]' : 'px-2 py-0.5 text-xs',
        className,
      )}
    >
      <Icon className={size === 'xs' ? 'size-3' : 'size-3.5'} aria-hidden />
      {meta.label}
    </Badge>
  )
}

/** Punto di stato (solo dove il testo è già presente altrove, con sr-only) */
export function StatusDot({ status, className }: { status: string; className?: string }) {
  const meta = STATUS_META[status] ?? STATUS_META.UNKNOWN
  return (
    <span className={cn('inline-block size-2 rounded-full shrink-0', meta.dot, className)}>
      <span className="sr-only">{meta.label}</span>
    </span>
  )
}
