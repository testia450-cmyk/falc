/* KPI card (§6.1): numero reale + barra a stati + asOf + definizione.
 * La barra rispetta la regola: totale = online+degradato+offline+
 * manutenzione+sconosciuto+non monitorato (i colori non sono mai
 * l'unico veicolo di informazione: tooltip + testo). */

'use client'

import { Info } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { AsOf } from '@/components/stale-indicator'
import { cn } from '@/lib/utils'

export interface KpiSegments {
  online: number
  degraded: number
  offline: number
  maintenance: number
  unknown: number
  notMonitored: number
}

const SEGMENTS: Array<{ key: keyof KpiSegments; label: string; cls: string }> = [
  { key: 'online', label: 'Online', cls: 'bg-ok' },
  { key: 'degraded', label: 'Degradati', cls: 'bg-warn' },
  { key: 'offline', label: 'Offline', cls: 'bg-crit' },
  { key: 'maintenance', label: 'Manutenzione', cls: 'bg-info' },
  { key: 'unknown', label: 'Sconosciuti', cls: 'bg-warn/60' },
  { key: 'notMonitored', label: 'Non monitorati', cls: 'bg-crit/60' },
]

export function KpiCard({
  label,
  value,
  unit,
  icon,
  asOf,
  definition,
  segments,
  foot,
  onClick,
  accent,
}: {
  label: string
  value: number | string
  unit?: string
  icon?: React.ReactNode
  asOf?: number | null
  definition?: string
  segments?: KpiSegments
  foot?: React.ReactNode
  onClick?: () => void
  accent?: 'ok' | 'warn' | 'crit' | 'info' | 'none'
}) {
  const total = segments ? SEGMENTS.reduce((acc, s) => acc + (segments[s.key] ?? 0), 0) : 0
  const interactive = !!onClick
  /* A11y (audit 16.3): la card NON è un «button» annidato con altri controlli
   * (nested-interactive). Pattern overlay: UN solo pulsante a tutta card per
   * l'azione primaria; il contenuto è pointer-events-none e il bottone
   * «Definizione» sta sopra (pointer-events-auto) → fratelli, mai annidati.
   * Il focus visibile dell'overlay disegna l'anello sull'intera card. */
  return (
    <Card
      className={cn(
        'relative overflow-hidden border-border/70 bg-surface',
        interactive && 'transition-colors hover:border-link/50',
      )}
    >
      {interactive ? (
        <button
          type="button"
          onClick={onClick}
          aria-label={`Apri la sezione: ${label}`}
          className="absolute inset-0 z-0 cursor-pointer rounded-xl focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ring"
        />
      ) : null}
      <CardContent className="relative z-10 p-4 pointer-events-none">
        <div className="flex items-start justify-between gap-2">
          <p className="text-[13px] font-medium text-text-2 leading-tight">{label}</p>
          {definition ? (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  {/* h-6 w-6 = 24px: target-size WCAG 2.2 AA; pointer-events-auto
                   * perché il contenuto della card è pointer-events-none (overlay). */}
                  <button className="pointer-events-auto inline-flex h-6 w-6 items-center justify-center rounded-md text-text-2 hover:text-link focus-visible:outline-2 focus-visible:outline-ring" aria-label={`Definizione: ${label}`}>
                    <Info className="size-3.5" aria-hidden />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-64 text-xs leading-relaxed">
                  {definition}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ) : icon ? <span className="text-text-2">{icon}</span> : null}
        </div>
        <div className="mt-2 flex items-baseline gap-1.5">
          <span className={cn(
            'num text-[28px] font-semibold leading-none tracking-tight',
            accent === 'ok' && 'text-ok',
            accent === 'warn' && 'text-warn',
            accent === 'crit' && 'text-crit',
            accent === 'info' && 'text-info',
          )}>
            {value}
          </span>
          {unit ? <span className="text-sm text-text-2">{unit}</span> : null}
        </div>
        {segments && total > 0 ? (
          <div
            className="mt-3 flex h-1.5 w-full overflow-hidden rounded-full bg-raised"
            role="img"
            aria-label={SEGMENTS.map((s) => `${s.label}: ${segments[s.key]}`).join(', ')}
          >
            {SEGMENTS.map((s) => {
              const v = segments[s.key] ?? 0
              if (v <= 0) return null
              return (
                <div
                  key={s.key}
                  className={cn(s.cls)}
                  style={{ width: `${(v / total) * 100}%` }}
                  title={`${s.label}: ${v}`}
                />
              )
            })}
          </div>
        ) : null}
        {foot ? <div className="mt-2.5 text-xs text-text-2">{foot}</div> : null}
        {asOf ? <AsOf ts={asOf} className="mt-2" /> : null}
      </CardContent>
    </Card>
  )
}
