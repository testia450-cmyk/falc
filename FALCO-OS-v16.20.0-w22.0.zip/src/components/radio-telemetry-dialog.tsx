/* ================================================================
 * FALCO-OS v16.18 W20 — Dialog «Sonda telemetria radio & salute»
 * ================================================================
 * Mostra TUTTO ciò che la sonda SNMP ha letto DAVVERO da un apparato:
 *  · SALUTE: CPU %, RAM usata/totale;
 *  · RADIO: SSID, banda, frequenza, segnale dBm, noise floor, SNR,
 *    velocità tx/rx (la «WLAN speed»), CCQ;
 *  · CLIENT RADIO: MAC, segnale, velocità, IP (registration table);
 *  · PORTE ETHERNET: velocità e duplex negoziali;
 *  · PROVENANCE per ogni campo: quale OID ha risposto e con che
 *    confidenza (verified / high / medium) — l'operatore verifica;
 *  · note onesti: country NON esposto via SNMP (serve SSH/console).
 * La sonda è in SOLA LETTURA e persiste i valori letti (Device +
 * campioni MetricValue): i KPI della scheda si aggiornano subito.
 * Componente CONTROLLATO: il padre decide open/onOpenChange e riceve
 * onDone dopo una lettura riuscita (per invalidare le query).
 * ================================================================ */

'use client'

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import {
  Activity, Cable, Cpu, Gauge, Loader2, MemoryStick, RadioTower, Signal, Users,
} from 'lucide-react'

import { api, ApiError } from '@/lib/client/api'
import type { RadioTelemetryResult } from '@/lib/v2/contracts'
import { fmtDbm, fmtPct, fmtUptime } from '@/lib/client/format'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

function errMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message
  if (e instanceof Error) return e.message
  return 'Errore sconosciuto'
}

/** Tono del segnale (soglie della scheda apparato: −65/−75/−85 dBm). */
function signalTone(dbm: number): { label: string; cls: string } {
  if (dbm >= -65) return { label: 'buono', cls: 'text-ok' }
  if (dbm >= -75) return { label: 'attenzione', cls: 'text-warn' }
  if (dbm >= -85) return { label: 'debole', cls: 'text-crit-text' }
  return { label: 'molto debole', cls: 'text-crit-text' }
}

const CONFIDENCE_META: Record<string, { label: string; cls: string }> = {
  verified: { label: 'standard verificato', cls: 'bg-ok-soft text-ok border-ok/40' },
  high: { label: 'documentata', cls: 'bg-raised text-text-2 border-border' },
  medium: { label: 'da confermare sul campo', cls: 'bg-warn-soft text-warn border-warn/40' },
}

/** Riga dati: etichetta · valore · provenance badge. */
function DataRow({
  label, value, prov, tone,
}: {
  label: string
  value: string
  prov?: RadioTelemetryResult['provenance'][number]
  tone?: string
}) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1 border-b border-border/50 py-1.5">
      <dt className="text-xs text-text-2">{label}</dt>
      <dd className="flex flex-wrap items-center gap-2">
        <span className={cn('num text-sm font-medium', tone)}>{value}</span>
        {prov ? (
          <Badge
            variant="outline"
            className={cn('text-[9px]', CONFIDENCE_META[prov.confidence]?.cls ?? 'bg-raised text-text-2 border-border')}
            title={`${prov.label} — OID ${prov.oid}`}
          >
            {CONFIDENCE_META[prov.confidence]?.label ?? prov.confidence}
          </Badge>
        ) : null}
      </dd>
    </div>
  )
}

function provFor(result: RadioTelemetryResult, field: string): RadioTelemetryResult['provenance'][number] | undefined {
  return result.provenance.find((p) => p.field === field || p.field.startsWith(field))
}

export function RadioTelemetryDialog({
  deviceId, open, onOpenChange, onDone,
}: {
  deviceId: string
  open: boolean
  onOpenChange: (open: boolean) => void
  onDone?: () => void
}) {
  const [pending, setPending] = useState(false)
  const [result, setResult] = useState<RadioTelemetryResult | null>(null)
  const [ranFor, setRanFor] = useState<string>('')

  const run = useCallback(async () => {
    setPending(true)
    try {
      const r = await api.radioTelemetry({ deviceId })
      setResult(r)
      if (r.reachable) {
        const bits: string[] = []
        if (r.health.cpuLoadPct != null) bits.push(`CPU ${r.health.cpuLoadPct}%`)
        if (r.radios[0]?.signalDbm != null) bits.push(`segnale ${r.radios[0].signalDbm} dBm`)
        if (r.radios[0]?.ssid) bits.push(`SSID «${r.radios[0].ssid}»`)
        toast.success('Telemetria letta', {
          description: bits.length > 0 ? bits.join(' · ') : 'Nessun valore radio/salute su questo apparato (vedi note).',
        })
        onDone?.()
      } else {
        toast.error('Apparato non raggiungibile via SNMP', { description: r.detail ?? r.error ?? 'nessuna risposta' })
      }
    } catch (e) {
      toast.error('Sonda telemetria non riuscita', { description: errMessage(e) })
    } finally {
      setPending(false)
    }
  }, [deviceId, onDone])

  useEffect(() => {
    if (open && !pending && (!result || ranFor !== deviceId)) {
      setRanFor(deviceId)
      void run()
    }
  }, [open, deviceId])

  const ramLabel = (r: RadioTelemetryResult) => {
    if (r.health.ramTotalKb == null || r.health.ramUsedKb == null) return 'n.d.'
    const used = r.health.ramUsedKb / 1024
    const total = r.health.ramTotalKb / 1024
    return `${used.toFixed(0)} / ${total.toFixed(0)} MB (${Math.round((r.health.ramUsedKb / r.health.ramTotalKb) * 100)}%)`
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] w-[min(46rem,94vw)] overflow-hidden p-0 sm:max-w-[46rem]">
        <DialogHeader className="px-5 pt-5 pb-3 sm:px-6">
          <DialogTitle className="flex items-center gap-2 text-base">
            <RadioTower className="size-4 text-primary" aria-hidden /> Sonda telemetria radio &amp; salute
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed">
            Sonda SNMP in <strong>sola lettura</strong>: CPU, RAM, SSID, segnale, CCQ, frequenza,
            velocità radio, client associati e porte ethernet — ogni campo dichiara l&apos;OID che ha
            risposto (provenance).
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[62vh] border-t bg-canvas/40">
          <div className="space-y-4 px-5 py-4 sm:px-6">
            {pending ? (
              <div className="space-y-2">
                <Skeleton className="h-8 w-1/2" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ) : result ? (
              <>
                {!result.reachable ? (
                  <div className="rounded-lg border border-crit/30 bg-crit-soft/50 p-3 text-sm">
                    <p className="font-medium text-crit-text">Apparato non raggiungibile via SNMP</p>
                    <p className="mt-1 text-xs text-text-2">{result.detail ?? result.error}</p>
                    <Button size="sm" variant="outline" className="mt-2 h-9" onClick={() => void run()}>
                      <Loader2 className="mr-1.5 size-3.5" aria-hidden /> Riprova
                    </Button>
                  </div>
                ) : (
                  <>
                    {/* --- identità --- */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-text-2">
                      <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40">SNMP attivo</Badge>
                      {result.sysName ? <span>sysName <span className="num">{result.sysName}</span></span> : null}
                      {result.matched ? <span>community <span className="num">{result.matched.community}</span> ({result.matched.version})</span> : null}
                    </div>

                    {/* --- SALUTE --- */}
                    <section aria-label="Salute apparato">
                      <h3 className="mb-1 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-text-2">
                        <Activity className="size-3.5" aria-hidden /> Salute (health)
                      </h3>
                      <dl>
                        <DataRow
                          label="Carico CPU"
                          value={result.health.cpuLoadPct != null ? `${result.health.cpuLoadPct}%` : 'n.d.'}
                          prov={provFor(result, 'cpuLoadPct')}
                          tone={result.health.cpuLoadPct != null && result.health.cpuLoadPct > 90 ? 'text-crit-text' : undefined}
                        />
                        <DataRow
                          label="RAM usata / totale"
                          value={ramLabel(result)}
                          prov={provFor(result, 'ramUsedKb')}
                        />
                      </dl>
                    </section>

                    {/* --- RADIO --- */}
                    <section aria-label="Radio wireless">
                      <h3 className="mb-1 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-text-2">
                        <Signal className="size-3.5" aria-hidden /> Radio wireless
                      </h3>
                      {result.radios.length === 0 ? (
                        <p className="rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2">
                          Nessuna tabella wireless leggibile su questo apparato (switch/router
                          senza radio, o vendor non ancora supportato).
                        </p>
                      ) : result.radios.map((r) => (
                        <dl key={r.index} className="mb-2 rounded-lg border bg-canvas p-3">
                          <DataRow label="SSID" value={r.ssid ?? 'n.d.'} prov={provFor(result, 'ssid')} />
                          <DataRow label="Banda" value={r.band ?? 'n.d.'} />
                          <DataRow label="Frequenza" value={r.frequencyMhz != null ? `${r.frequencyMhz} MHz` : 'n.d.'} prov={provFor(result, 'frequencyMhz')} />
                          <DataRow
                            label="Segnale"
                            value={fmtDbm(r.signalDbm)}
                            prov={provFor(result, 'signalDbm')}
                            tone={r.signalDbm != null ? signalTone(r.signalDbm).cls : undefined}
                          />
                          <DataRow label="Noise floor" value={fmtDbm(r.noiseFloorDbm)} />
                          <DataRow label="SNR" value={r.snrDb != null ? `${r.snrDb} dB` : 'n.d.'} prov={provFor(result, 'snrDb')} />
                          <DataRow label="Velocità WLAN (tx / rx)" value={`${r.txRateMbps != null ? `${r.txRateMbps} Mbps` : 'n.d.'} / ${r.rxRateMbps != null ? `${r.rxRateMbps} Mbps` : 'n.d.'}`} prov={r.txRateMbps != null ? provFor(result, 'txRateMbps') : undefined} />
                          <DataRow label="Qualità link (CCQ)" value={fmtPct(r.ccqPercent)} prov={provFor(result, 'ccqPercent')} />
                        </dl>
                      ))}
                      {result.derived.note ? (
                        <p className="text-[11px] leading-relaxed text-text-2">
                          <Gauge className="mr-1 inline size-3" aria-hidden />
                          {result.derived.note}
                          {result.derived.radioMode ? (
                            <>
                              {' → modalità '}
                              <span className="font-medium">{result.derived.radioMode.toUpperCase()}</span>
                              {result.derived.linkMode ? ` (${result.derived.linkMode})` : ''}
                            </>
                          ) : null}
                        </p>
                      ) : null}
                    </section>

                    {/* --- CLIENT RADIO --- */}
                    {result.clients.length > 0 ? (
                      <section aria-label="Client radio associati">
                        <h3 className="mb-1.5 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-text-2">
                          <Users className="size-3.5" aria-hidden /> Client radio associati ({result.clients.length})
                        </h3>
                        <ul className="space-y-1.5">
                          {result.clients.map((c, i) => (
                            <li key={c.mac ?? i} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-md border bg-canvas px-3 py-2 text-xs">
                              <span className="num font-medium">{c.mac ?? 'MAC ?'}</span>
                              {c.signalDbm != null ? (
                                <span className={cn('num', signalTone(c.signalDbm).cls)}>{c.signalDbm} dBm</span>
                              ) : null}
                              {c.txRateMbps != null ? <span className="num text-text-2">tx {c.txRateMbps} Mbps</span> : null}
                              {c.rxRateMbps != null ? <span className="num text-text-2">rx {c.rxRateMbps} Mbps</span> : null}
                              {c.lastIp ? <span className="num text-text-2">{c.lastIp}</span> : null}
                            </li>
                          ))}
                        </ul>
                      </section>
                    ) : null}

                    {/* --- PORTE ETHERNET --- */}
                    {result.ports.length > 0 ? (
                      <section aria-label="Porte ethernet">
                        <h3 className="mb-1.5 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-text-2">
                          <Cable className="size-3.5" aria-hidden /> Porte ethernet ({result.ports.length})
                        </h3>
                        <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                          {result.ports.map((p) => (
                            <li key={p.ifIndex} className="flex items-center justify-between gap-2 rounded-md border bg-canvas px-3 py-1.5 text-xs">
                              <span className="num truncate font-medium">{p.name ?? `if${p.ifIndex}`}</span>
                              <span className="num shrink-0 text-text-2">
                                {p.speedMbps != null ? `${p.speedMbps} Mbps` : '—'}
                                {p.duplex ? ` · ${p.duplex === 'full' ? 'full' : 'half'}` : ''}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </section>
                    ) : null}

                    {/* --- cosa è stato persistito --- */}
                    <p className="rounded-md bg-ok-soft/40 px-3 py-2 text-[11px] leading-relaxed text-text-2">
                      <Cpu className="mr-1 inline size-3" aria-hidden />
                      Valori persistiti sulla scheda apparato: {[result.persisted.cpuLoad ? 'CPU' : null, result.persisted.ram ? 'RAM' : null, result.persisted.ssid ? 'SSID' : null, result.persisted.signalStrength ? 'segnale' : null, result.persisted.linkQuality ? 'CCQ' : null, result.persisted.currentFrequency ? 'frequenza' : null, result.persisted.radioMode ? 'modalità radio' : null, result.persisted.uptimeSeconds ? 'uptime' : null].filter(Boolean).join(', ') || 'nessuno (nessun valore letto)'}
                      {result.persisted.metricsSaved > 0 ? ` · ${result.persisted.metricsSaved} campioni metrica salvati` : ''}.
                    </p>

                    {/* --- note oneste --- */}
                    {result.notes.length > 0 ? (
                      <p className="rounded-md bg-raised/50 px-3 py-2 text-[11px] leading-relaxed text-text-2">
                        {result.notes.map((n, i) => <span key={i} className="block">{n}</span>)}
                      </p>
                    ) : null}
                  </>
                )}
              </>
            ) : null}
          </div>
        </ScrollArea>

        <div className="flex items-center justify-between gap-2 border-t px-5 py-3 sm:px-6">
          <p className="text-[11px] text-text-2">
            <MemoryStick className="mr-1 inline size-3" aria-hidden />
            Sonda in sola lettura (nessuna scrittura sull&apos;apparato)
          </p>
          <Button size="sm" variant="outline" className="h-9" disabled={pending} onClick={() => void run()}>
            {pending ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden /> : null}
            Rilancia sonda
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
