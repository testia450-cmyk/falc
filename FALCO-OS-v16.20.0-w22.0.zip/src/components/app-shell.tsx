/* AppShell: sidebar + topbar + contenuto + footer sticky (§regole layout).
 * Struttura: wrapper min-h-screen flex-col; footer con mt-auto. */

'use client'

import { useSession } from 'next-auth/react'
import { Sidebar } from '@/components/sidebar'
import { Topbar } from '@/components/topbar'
import { LoginOverlay } from '@/components/login-overlay'
import { useApp } from '@/lib/client/store'
import { VIEW_LABELS } from '@/lib/client/store'
import { useStateInit } from '@/components/use-state-init'
import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/client/api'
import { Database, RadioTower, ShieldCheck } from 'lucide-react'

export function AppShell({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession()
  const view = useApp((s) => s.view)
  const hydrate = useApp((s) => s.hydrate)

  // Idratazione dello stato dall'URL (deep link §5)
  useStateInit(() => { if (typeof window !== 'undefined') hydrate() })

  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    refetchInterval: 60_000,
    enabled: status === 'authenticated',
  })

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-sm text-text-2">Caricamento sessione…</p>
      </div>
    )
  }

  if (status !== 'authenticated' || !session?.user) {
    return <LoginOverlay />
  }

  const h = health.data?.data
  const replay = h?.replay.enabled ?? false

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1 min-h-0">
        <div className="hidden lg:block sticky top-0 h-screen">
          <Sidebar />
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar />
          <main id="contenuto" className="flex-1 min-w-0 px-4 py-4 sm:px-6" aria-label={`Sezione ${VIEW_LABELS[view]}`}>
            {children}
          </main>
          {/* Footer sticky (mt-auto): stato REALE, mai statico (§3.3.3) */}
          <footer className="mt-auto border-t border-border bg-surface/70 px-4 py-2" role="contentinfo">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-text-2">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="size-3.5" aria-hidden />
                FALCO-OS <span className="num">{h?.version ?? '…'}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Database className="size-3.5" aria-hidden />
                DB {h?.dbReachable ? 'operativo' : 'non raggiungibile'}
                {h?.lastDbWrite ? <span className="num">· scritto {new Date(h.lastDbWrite).toLocaleTimeString('it-IT')}</span> : null}
              </span>
              <span className="flex items-center gap-1.5">
                <RadioTower className="size-3.5" aria-hidden />
                {replay ? (
                  <>Riproduzione attiva · dati reali importati {h?.replay.importedAt ? new Date(h.replay.importedAt).toLocaleString('it-IT') : '—'} · ciclo 30 s</>
                ) : (
                  <>Realtime non attivo · fermo immagine dei dati importati</>
                )}
              </span>
              <span className="ml-auto hidden sm:block">Ogni numero proviene dal backend: nessun dato di esempio</span>
            </div>
          </footer>
        </div>
      </div>
    </div>
  )
}
