/* ================================================================
 * FALCO-OS v16 — Pannello «Speed test» iperf3 (16.9 ondata W4)
 * Misura di banda verso un dispositivo dell'inventario. Executor
 * IPERF3 = misura REALE: se il binario manca il server risponde 501
 * ONESTO (EXECUTOR_DOWN) e NON scrive nessuna riga. Executor
 * SIMULATED = riga MARCATA nel DB (executor, banda a zero): mai
 * spacciata per misura reale.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Activity, Gauge, Loader2, Play, RefreshCw } from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { KpiCard } from '@/components/kpi-card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { api, ApiError, type SpeedTestRunResult } from '@/lib/client/api'
import { fmtDateTime, fmtMbps, fmtNumber } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Helper ---------------- */

function errInfo(e: unknown): { message: string; code?: string; status?: number } {
  if (e instanceof ApiError) return { message: e.message, code: e.code, status: e.status }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Badge executor: SIMULATED sempre marcato in ambra (mai spacciato) */
function ExecutorBadge({ executor }: { executor: string }) {
  if (executor === 'SIMULATED') {
    return <Badge variant="outline" className="border-warn/40 bg-warn-soft font-medium text-warn">SIMULATO</Badge>
  }
  return <Badge variant="outline" className="border-border bg-raised font-normal text-text-2">{executor}</Badge>
}

/* ================================================================
 * Pannello Speed test (renderizzato dalla vista padre in tab)
 * ================================================================ */

export function SpeedTestPanel() {
  const queryClient = useQueryClient()

  /* --- Storico + statistiche REALI --- */
  const tests = useQuery({
    queryKey: ['speed-tests'],
    queryFn: () => api.speedTests(),
    staleTime: 30_000,
  })
  const rows = tests.data?.data.tests ?? []
  const stats = tests.data?.data.stats

  /* --- Dispositivi per il selettore (primi 100, orfani compresi) --- */
  const devices = useQuery({
    queryKey: ['devices', 'speed-test', 1, 100],
    queryFn: () => api.devices({ page: 1, pageSize: 100 }),
    staleTime: 60_000,
  })
  const deviceList = devices.data?.data.items ?? []

  /* --- Form --- */
  const [deviceId, setDeviceId] = useState('')
  const [host, setHost] = useState('')
  const [port, setPort] = useState('5201')
  const [durationSec, setDurationSec] = useState('10')
  const [mode, setMode] = useState<'TCP' | 'UDP'>('TCP')
  const [direction, setDirection] = useState<'UP' | 'DOWN'>('DOWN')
  const [executor, setExecutor] = useState<'IPERF3' | 'SIMULATED'>('IPERF3')

  const selectedDevice = deviceList.find((d) => d.id === deviceId) ?? null

  /* --- Esito dell'ultima esecuzione --- */
  const [lastResult, setLastResult] = useState<SpeedTestRunResult | null>(null)
  const [runError, setRunError] = useState<{ message: string; code?: string; status?: number } | null>(null)

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['speed-tests'] })
  }

  const run = useMutation({
    mutationFn: (input: { deviceId: string; host?: string; port: number; durationSec: number; mode: 'TCP' | 'UDP'; direction: 'UP' | 'DOWN'; executor: 'IPERF3' | 'SIMULATED' }) =>
      api.runSpeedTest(input),
    onSuccess: (res) => {
      setLastResult(res)
      setRunError(null)
      invalidate()
      if (res.ok && res.executor === 'IPERF3') {
        toast.success('Misura reale completata', {
          description: `iperf3: ${fmtMbps(res.bandwidthMbps)} registrati nel DB (riga reale).`,
        })
      } else if (res.executor === 'SIMULATED') {
        toast.success('Riga simulata registrata', {
          description: 'Executor SIMULATED: misura a zero e riga MARCATA — mai spacciata per reale.',
        })
      } else {
        toast.error('Speed test fallito', {
          description: res.error || 'Esito negativo registrato nel DB (riga reale con errore).',
        })
      }
    },
    onError: (e) => {
      const info = errInfo(e)
      setRunError(info)
      setLastResult(null)
      if (info.status === 501 || info.code === 'EXECUTOR_DOWN') {
        toast.error('iperf3 non disponibile', {
          description: 'Il server risponde 501 in modo onesto: nessuna riga scritta nel DB.',
        })
      } else {
        toast.error('Esecuzione non riuscita', {
          description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
        })
      }
    },
  })

  const submitRun = () => {
    if (!deviceId || run.isPending) return
    const portNum = Number.parseInt(port, 10)
    const durNum = Number.parseInt(durationSec, 10)
    if (!Number.isInteger(portNum) || portNum < 1 || portNum > 65_535) return
    if (!Number.isInteger(durNum) || durNum < 1 || durNum > 60) return
    run.mutate({
      deviceId,
      host: host.trim() || undefined,
      port: portNum,
      durationSec: durNum,
      mode,
      direction,
      executor,
    })
  }

  const honestDown = runError && (runError.status === 501 || runError.code === 'EXECUTOR_DOWN')

  return (
    <div className="grid min-w-0 grid-cols-1 gap-4">
      {/* --- KPI: statistiche REALI dello storico --- */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <KpiCard
          label="Test totali"
          value={stats ? fmtNumber(stats.total) : '…'}
          definition="Righe SpeedTest presenti nel DB reale (reali + simulate)."
        />
        <KpiCard
          label="Reali (iperf3 ok)"
          value={stats ? fmtNumber(stats.real) : '…'}
          accent={stats && stats.real > 0 ? 'ok' : 'none'}
          definition="Misure eseguite davvero con il binario iperf3 ed esito riuscito."
        />
        <KpiCard
          label="Simulati"
          value={stats ? fmtNumber(stats.simulated) : '…'}
          accent={stats && stats.simulated > 0 ? 'warn' : 'none'}
          definition="Righe generate dall'executor SIMULATED: misura a zero, riga marcata (mai spacciata per reale)."
        />
        <KpiCard
          label="Banda media / massima"
          value={stats && stats.avgMbps > 0 ? fmtMbps(stats.avgMbps) : '—'}
          definition="Media e massimo delle misure con banda maggiore di zero dello storico reale («—» quando non ce ne sono)."
          foot={stats && stats.maxMbps > 0 ? <>massima <span className="num font-medium text-foreground">{fmtMbps(stats.maxMbps)}</span></> : undefined}
        />
        <KpiCard
          label="Ultimo reale"
          value={stats && stats.lastRealAt ? fmtDateTime(stats.lastRealAt) : '—'}
          definition="Data e ora dell'ultima misura iperf3 riuscita («—» se non è mai avvenuta in questo ambiente)."
        />
      </div>

      {/* --- Esecuzione --- */}
      <Card className="min-w-0 border-border/70 bg-surface">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
            <Gauge className="size-4 text-text-2" aria-hidden />
            Esecuzione speed test
          </CardTitle>
          <CardDescription>
            Executor iperf3 assente in questo ambiente → risposta 501 onesta, nessuna riga
            scritta. L&apos;executor SIMULATED registra righe marcate.
          </CardDescription>
          <CardAction>
            <Button variant="ghost" size="icon" className="size-8" onClick={() => { void tests.refetch() }} disabled={tests.isFetching} aria-label="Aggiorna lo storico degli speed test">
              <RefreshCw className={cn('size-3.5', tests.isFetching && 'animate-spin')} aria-hidden />
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent className="space-y-4">
          {devices.isError ? (
            <ErrorPanel
              message={errInfo(devices.error).message}
              code={errInfo(devices.error).code}
              onRetry={() => { void devices.refetch() }}
            />
          ) : (
            <form
              className="grid gap-3 sm:grid-cols-2"
              onSubmit={(e) => { e.preventDefault(); submitRun() }}
              noValidate
              aria-label="Form di esecuzione speed test"
            >
              <div className="grid gap-1.5 sm:col-span-2">
                <label htmlFor="st-device" className="text-xs font-medium text-text-2">
                  Dispositivo (primi 100 dell&apos;inventario reale)
                </label>
                <Select value={deviceId} onValueChange={setDeviceId}>
                  <SelectTrigger
                    id="st-device"
                    className="w-full"
                    disabled={devices.isPending || deviceList.length === 0}
                    aria-label="Dispositivo su cui eseguire lo speed test"
                  >
                    <SelectValue
                      placeholder={devices.isPending
                        ? 'caricamento dispositivi…'
                        : deviceList.length === 0 ? 'nessun dispositivo' : 'Scegli dispositivo…'}
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {deviceList.map((d) => (
                      <SelectItem key={d.id} value={d.id}>
                        {d.hostname} · {d.ip}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5 sm:col-span-2">
                <label htmlFor="st-host" className="text-xs font-medium text-text-2">Host iperf3</label>
                <Input
                  id="st-host"
                  value={host}
                  maxLength={200}
                  onChange={(e) => setHost(e.target.value)}
                  placeholder={selectedDevice?.ip ?? 'IP o hostname del server iperf3 (vuoto = IP del dispositivo)'}
                  className="font-mono text-xs"
                />
                <p className="text-xs text-text-2">vuoto = verso l&apos;IP del dispositivo scelto</p>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="st-port" className="text-xs font-medium text-text-2">Porta</label>
                <Input
                  id="st-port"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={65535}
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                  className="num"
                />
                <p className="text-xs text-text-2">1–65535 (default 5201)</p>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="st-duration" className="text-xs font-medium text-text-2">Durata (s)</label>
                <Input
                  id="st-duration"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={60}
                  value={durationSec}
                  onChange={(e) => setDurationSec(e.target.value)}
                  className="num"
                />
                <p className="text-xs text-text-2">1–60 s (default 10)</p>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="st-mode" className="text-xs font-medium text-text-2">Modalità</label>
                <Select value={mode} onValueChange={(v) => setMode(v as 'TCP' | 'UDP')}>
                  <SelectTrigger id="st-mode" className="w-full" aria-label="Modalità del test">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TCP">TCP</SelectItem>
                    <SelectItem value="UDP">UDP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="st-direction" className="text-xs font-medium text-text-2">Direzione</label>
                <Select value={direction} onValueChange={(v) => setDirection(v as 'UP' | 'DOWN')}>
                  <SelectTrigger id="st-direction" className="w-full" aria-label="Direzione del flusso">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DOWN">DOWN (ricezione)</SelectItem>
                    <SelectItem value="UP">UP (trasmissione)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5 sm:col-span-2">
                <label htmlFor="st-executor" className="text-xs font-medium text-text-2">Executor</label>
                <Select value={executor} onValueChange={(v) => setExecutor(v as 'IPERF3' | 'SIMULATED')}>
                  <SelectTrigger id="st-executor" className="w-full" aria-label="Executor della misura">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="IPERF3">IPERF3 (misura reale)</SelectItem>
                    <SelectItem value="SIMULATED">SIMULATED (riga marcata)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-text-2">SIMULATED: riga marcata, misure a zero — mai spacciata per reale.</p>
              </div>
              <div className="sm:col-span-2">
                <Button
                  type="submit"
                  disabled={run.isPending || !deviceId || devices.isPending}
                  aria-label="Esegui lo speed test con i parametri impostati"
                >
                  {run.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Play className="size-3.5" aria-hidden />}
                  Esegui speed test
                </Button>
              </div>
            </form>
          )}

          {/* --- Esito --- */}
          {run.isPending ? (
            <div role="status" aria-busy="true" className="flex items-center gap-2.5 rounded-md border border-border/70 bg-raised/40 px-3 py-4 text-sm text-text-2">
              <Loader2 className="size-4 animate-spin" aria-hidden />
              Esecuzione in corso ({executor === 'IPERF3' ? 'binario iperf3' : 'executor simulato'})…
            </div>
          ) : honestDown ? (
            <div role="alert" className="space-y-1.5 rounded-lg border border-crit/40 bg-crit-soft px-4 py-3">
              <p className="text-sm font-medium text-crit-text">
                iperf3 non disponibile sul server — misura reale non eseguibile in questo ambiente
              </p>
              <p className="text-xs leading-relaxed text-text-2">
                {runError?.message}{runError?.code ? ` (codice ${runError.code})` : ''} · nessuna riga scritta nel DB:
                il fallimento è dichiarato, non simulato.
              </p>
            </div>
          ) : runError ? (
            <ErrorPanel
              message={runError.message}
              code={runError.code}
              onRetry={submitRun}
            />
          ) : lastResult ? (
            <div className="space-y-3 rounded-lg border border-border/70 bg-raised/40 px-4 py-3.5" role="status" aria-live="polite">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-baseline gap-2">
                  <span className={cn('num text-3xl font-semibold tracking-tight', lastResult.ok ? '' : 'text-crit-text')}>
                    {lastResult.ok ? fmtMbps(lastResult.bandwidthMbps) : '—'}
                  </span>
                  <span className="text-xs text-text-2">{lastResult.ok ? 'banda misurata' : 'misura non riuscita'}</span>
                </div>
                <div className="flex items-center gap-2">
                  {lastResult.ok ? (
                    <Badge variant="outline" className="border-ok/40 bg-ok-soft font-medium text-ok">Riuscito</Badge>
                  ) : (
                    <Badge variant="outline" className="border-crit/40 bg-crit-soft font-medium text-crit-text">Fallito</Badge>
                  )}
                  <ExecutorBadge executor={lastResult.executor} />
                </div>
              </div>
              <dl className="grid gap-x-6 gap-y-1.5 text-xs sm:grid-cols-2">
                <div className="flex justify-between gap-3 sm:justify-start">
                  <dt className="text-text-2">Ritrasmissioni</dt>
                  <dd className="num font-medium">{fmtNumber(lastResult.retransmits)}</dd>
                </div>
                <div className="flex justify-between gap-3 sm:justify-start">
                  <dt className="text-text-2">Jitter</dt>
                  <dd className="num font-medium">{lastResult.jitterMs > 0 ? `${lastResult.jitterMs} ms` : '—'}</dd>
                </div>
                <div className="flex justify-between gap-3 sm:justify-start">
                  <dt className="text-text-2">Perdita pacchetti</dt>
                  <dd className="num font-medium">{lastResult.lossPercent > 0 ? `${lastResult.lossPercent} %` : '—'}</dd>
                </div>
                <div className="flex justify-between gap-3 sm:justify-start">
                  <dt className="text-text-2">Riga DB</dt>
                  <dd className="font-mono text-[11px]">{lastResult.testId ? 'scritta' : 'nessuna (misura non riuscita)'}</dd>
                </div>
              </dl>
              {lastResult.error ? (
                <p className="text-xs leading-relaxed text-crit-text" role="alert">
                  {lastResult.error}
                </p>
              ) : null}
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* --- Storico --- */}
      <Card className="min-w-0 border-border/70 bg-surface">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
            <Activity className="size-4 text-text-2" aria-hidden />
            Storico misure
            {tests.data ? (
              <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
                {fmtNumber(stats?.total ?? 0)} righe
              </Badge>
            ) : null}
          </CardTitle>
          <CardDescription>
            Righe REALI della tabella SpeedTest: le misure simulate sono marcate
            dall&apos;executor e mostrate con badge ambra.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {tests.isPending ? (
            <LoadingRows rows={4} />
          ) : tests.isError ? (
            <ErrorPanel
              message={errInfo(tests.error).message}
              code={errInfo(tests.error).code}
              onRetry={() => { void tests.refetch() }}
            />
          ) : rows.length === 0 ? (
            <EmptyState
              icon={<Activity className="size-10" aria-hidden />}
              title="Nessuno speed test eseguito"
              description="Nessun speed test eseguito: 0 righe nel database reale. La prima riga arriva dall'esecuzione qui sopra (iperf3 riuscito o riga SIMULATA marcata)."
            />
          ) : (
            <div
              className="max-h-80 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70"
              role="region"
              aria-label="Storico degli speed test, scorribile"
              tabIndex={0}
            >
              <Table>
                <TableCaption className="sr-only">
                  Storico speed test: data, dispositivo, destinazione, modalità, executor, esito, banda e errore
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="w-[150px]">Data/ora</TableHead>
                    <TableHead scope="col" className="min-w-[160px]">Dispositivo</TableHead>
                    <TableHead scope="col" className="min-w-[170px]">Destinazione</TableHead>
                    <TableHead scope="col" className="w-[120px]">Modalità</TableHead>
                    <TableHead scope="col" className="w-[110px]">Executor</TableHead>
                    <TableHead scope="col" className="w-[70px] text-center">Esito</TableHead>
                    <TableHead scope="col" className="w-[120px] text-right">Banda</TableHead>
                    <TableHead scope="col" className="min-w-[140px]">Errore</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="num whitespace-nowrap text-xs" title={fmtDateTime(r.createdAt)}>
                        {fmtDateTime(r.createdAt)}
                      </TableCell>
                      <TableCell className="min-w-[160px]">
                        <p className="truncate text-xs font-medium" title={r.deviceHostname}>{r.deviceHostname}</p>
                        <p className="num text-[11px] text-text-2">{r.deviceIp}</p>
                      </TableCell>
                      <TableCell className="min-w-[170px]">
                        <p className="truncate font-mono text-xs" title={`${r.host}:${r.port}`}>{r.host}:{r.port}</p>
                        <p className="num text-[11px] text-text-2">{r.durationSec} s</p>
                      </TableCell>
                      <TableCell className="w-[120px]">
                        <span className="text-xs">{r.mode} · {r.direction}</span>
                      </TableCell>
                      <TableCell className="w-[110px]">
                        <ExecutorBadge executor={r.executor} />
                      </TableCell>
                      <TableCell className="w-[70px] text-center">
                        {r.ok ? (
                          <span className="font-medium text-ok" title="riuscito">✓<span className="sr-only"> riuscito</span></span>
                        ) : (
                          <span className="font-medium text-crit-text" title="fallito">✗<span className="sr-only"> fallito</span></span>
                        )}
                      </TableCell>
                      <TableCell className="num w-[120px] whitespace-nowrap text-right text-xs">
                        {r.ok ? fmtMbps(r.bandwidthMbps) : '—'}
                      </TableCell>
                      <TableCell className="min-w-[140px]">
                        {r.error ? (
                          <span className="block max-w-[220px] truncate text-xs text-crit-text" title={r.error}>{r.error}</span>
                        ) : (
                          <span className="text-xs text-text-2">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          {tests.data ? <AsOf ts={tests.data.asOf} prefix="storico alle" className="mt-1" /> : null}
        </CardContent>
      </Card>
    </div>
  )
}
