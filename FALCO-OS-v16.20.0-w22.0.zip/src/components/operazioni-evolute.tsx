/* ================================================================
 * FALCO-OS v16 — Sezione «Operazioni evolute» (16.7 ondata W3.5)
 * Quinto tab della vista Operazioni: (A) richieste di configurazione
 * con pipeline commit-confirm e guardrail v15, (B) ondate bulk
 * (tetto 50 target, dry-run dichiarato), (C) firmware center
 * (schedulazione registrata con audit, NESSUNA esecuzione in
 * riproduzione), (D) playbook (CRUD completo, esecuzione non
 * disponibile senza motori attivi), (E) automazioni periodiche
 * (CRUD + guardrail sul tetto dispositivi), (F) terminale SSH
 * (tentativo ONESTO sulla porta 22: MAI un terminale emulato).
 * Onestà (D2): tabelle vuote dichiarate (il DB reale parte da 0),
 * runCount/appliedCount mostrati come 0 reali, output dry-run
 * evidenziato, errori backend (FORBIDDEN_COMMAND, INVALID_TRANSITION,
 * REPLAY_NOEXEC, WINDOW_EXPIRED…) mostrati col messaggio completo.
 * Nessun dato inventato: «n.d.» / «—» per i campi mancanti.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  ArrowDown, ArrowUp, Bot, CalendarClock, Check, CircleCheck, CircleX, ClipboardList, Eye,
  FileText, Hourglass, Info, ListChecks, Loader2, Monitor, Pencil, Play, Plus, RefreshCw,
  ScanSearch, Search, ServerCog, ShieldCheck, SquareTerminal, Trash2, TriangleAlert, Undo2,
  Waves, Workflow, type LucideIcon,
} from 'lucide-react'

import { KpiCard } from '@/components/kpi-card'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
} from '@/components/ui/command'
import { api, ApiError, type DeviceRow } from '@/lib/client/api'
import type {
  AutomationTaskRow, BulkConfigRow, ConfigRequestRow, FirmwareJobRow, PlaybookRow, TerminalProbeResult,
} from '@/lib/v2/contracts'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtRelative, typeLabel } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Costanti & vocabolari ---------------- */

/** Pick-list dispositivi: stessa query key ['devices'] del resto
 * dell'app (invalidata dal topbar), pagina 1 × 50 elementi. */
const DEVICE_PAGE_SIZE = 50

/** Tetto v15 R8 per ondata bulk: guardrail client-side coerente col backend. */
const BULK_MAX_TARGETS_UI = 50

/** Massimo passi di un playbook (contratto: 1..30). */
const PLAYBOOK_MAX_STEPS = 30

/** Executor: badge icona+testo, mai solo colore (§4.2). */
const EXECUTOR_META: Record<string, { label: string; cls: string }> = {
  SSH: { label: 'SSH', cls: 'bg-warn-soft text-warn border-warn/40' },
  SIMULATED: { label: 'SIMULATED · dry-run', cls: 'bg-info-soft text-info border-info/40' },
}

/* Stati della macchina a stati commit-confirm (v11.8 S1): il DB reale
 * parte da 0 richieste — gli stati NASCONO dalle transizioni, nessuno
 * è inventato. Valore ignoto → badge neutro col valore raw. */
const CONFIG_STATUS_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  PENDING: { label: 'In attesa', cls: 'bg-raised text-text-2 border-border', Icon: Hourglass },
  APPROVED: { label: 'Approvata', cls: 'bg-info-soft text-info border-info/40', Icon: Check },
  APPLIED: { label: 'Applicata (dry-run)', cls: 'bg-warn-soft text-warn border-warn/40', Icon: Play },
  CONFIRMED: { label: 'Confermata', cls: 'bg-ok-soft text-ok border-ok/40', Icon: CircleCheck },
  REJECTED: { label: 'Respinta', cls: 'bg-crit-soft text-crit-text border-crit/40', Icon: CircleX },
  ROLLED_BACK: { label: 'Rollback', cls: 'bg-raised text-text-2 border-border', Icon: Undo2 },
  FAILED: { label: 'Fallita', cls: 'bg-crit-soft text-crit-text border-crit/40', Icon: TriangleAlert },
}

/* Stati firmware: in riproduzione esistono SOLO SCHEDULED/CANCELED
 * (nessuna esecuzione); il resto del vocabolario è pronto e onesto. */
const FIRMWARE_STATUS_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  SCHEDULED: { label: 'Programmato', cls: 'bg-info-soft text-info border-info/40', Icon: CalendarClock },
  RUNNING: { label: 'In esecuzione', cls: 'bg-warn-soft text-warn border-warn/40', Icon: Loader2 },
  APPLIED: { label: 'Applicato', cls: 'bg-warn-soft text-warn border-warn/40', Icon: Play },
  CONFIRMED: { label: 'Confermato', cls: 'bg-ok-soft text-ok border-ok/40', Icon: CircleCheck },
  ROLLED_BACK: { label: 'Rollback', cls: 'bg-raised text-text-2 border-border', Icon: Undo2 },
  FAILED: { label: 'Fallito', cls: 'bg-crit-soft text-crit-text border-crit/40', Icon: TriangleAlert },
  CANCELED: { label: 'Annullato', cls: 'bg-raised text-text-2 border-border', Icon: CircleX },
}

/* Ondate bulk: il backend crea SOLO status COMPLETED con risultati
 * simulati (dry-run dichiarato) — mai altri stati in riproduzione. */
const BULK_STATUS_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  COMPLETED: { label: 'Completata (dry-run)', cls: 'bg-ok-soft text-ok border-ok/40', Icon: CircleCheck },
}

/* Vocabolario azioni dei passi playbook (contratto PLAYBOOK_ACTIONS):
 * etichette italiane, valore raw come valore dell'enum. */
const PLAYBOOK_ACTIONS_UI = ['check_status', 'check_metric', 'send_command', 'open_ticket', 'notify', 'wait'] as const
type PlaybookAction = (typeof PLAYBOOK_ACTIONS_UI)[number]

const PLAYBOOK_ACTION_LABELS: Record<PlaybookAction, string> = {
  check_status: 'Verifica stato (check_status)',
  check_metric: 'Verifica metrica (check_metric)',
  send_command: 'Invia comando (send_command)',
  open_ticket: 'Apri ticket (open_ticket)',
  notify: 'Notifica (notify)',
  wait: 'Attendi (wait)',
}

function isPlaybookAction(v: string): v is PlaybookAction {
  return (PLAYBOOK_ACTIONS_UI as readonly string[]).includes(v)
}

/* ---------------- Helpers ---------------- */

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Textarea → righe pulite: una per riga, spazi tolti, vuote scartate. */
function parseLines(raw: string): string[] {
  return raw.split('\n').map((l) => l.trim()).filter((l) => l.length > 0)
}

/** Campo numerico intero: null se vuoto/non intero. */
function parseIntField(raw: string): number | null {
  const t = raw.trim()
  if (t === '') return null
  const n = Number(t)
  return Number.isInteger(n) ? n : null
}

/** Durata ms compatta: sotto il secondo resta in ms (0 ms onesto). */
function fmtMs(ms: number): string {
  if (ms < 1000) return `${fmtNumber(ms)} ms`
  return `${(ms / 1000).toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} s`
}

/** Intervallo delle automazioni: secondi → forma leggibile. */
function fmtIntervalSec(sec: number): string {
  if (sec < 60) return `${fmtNumber(sec)} s`
  if (sec < 3600) return `${fmtNumber(Math.round(sec / 60))} min`
  if (sec % 3600 === 0) return `${fmtNumber(sec / 3600)} h`
  return `${Math.floor(sec / 3600)} h ${Math.round((sec % 3600) / 60)} min`
}

/** Inventario reale per le pick-list (chiave ['devices'] condivisa). */
function useDevices50() {
  return useQuery({
    queryKey: ['devices'],
    queryFn: () => api.devices({ page: 1, pageSize: DEVICE_PAGE_SIZE }),
    staleTime: 30_000,
  })
}

/* ---------------- Micro-componenti condivisi ---------------- */

/** Badge di vocabolario con fallback onesto sul valore raw. */
function VocabBadge({ label, cls, Icon }: { label: string; cls: string; Icon?: LucideIcon }) {
  return (
    <Badge className={cls}>
      {Icon ? <Icon className="size-3" aria-hidden /> : null}
      {label}
    </Badge>
  )
}

function ExecutorBadge({ executor }: { executor: string }) {
  const meta = EXECUTOR_META[executor]
  return (
    <Badge
      variant="outline"
      className={meta?.cls ?? 'bg-raised text-text-2 border-border'}
      title={executor === 'SSH'
        ? 'Esecuzione SSH reale: in modalità riproduzione viene rifiutata onestamente (REPLAY_NOEXEC)'
        : 'Dry-run dichiarato: i comandi sono convalidati e MAI inviati al dispositivo'}
    >
      {meta?.label ?? executor}
    </Badge>
  )
}

/** Nota informativa onesta (banner) — stessa lingua visiva della vista. */
function InfoNote({ children, id }: { children: React.ReactNode; id?: string }) {
  return (
    <p
      id={id}
      role="note"
      className="flex items-start gap-2 rounded-md border border-info/40 bg-info-soft px-2.5 py-1.5 text-xs leading-relaxed text-info"
    >
      <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
      <span className="min-w-0">{children}</span>
    </p>
  )
}

/** Selettore dispositivo reale (primi 50 dell'inventario). */
function DeviceSelectField({
  id,
  value,
  onChange,
  items,
  isPending,
  isError,
  total,
  label = 'Dispositivo *',
}: {
  id: string
  value: string
  onChange: (id: string) => void
  items: DeviceRow[]
  isPending: boolean
  isError: boolean
  total: number | undefined
  label?: string
}) {
  return (
    <div className="grid gap-1.5">
      <label htmlFor={id} className="text-xs font-medium text-text-2">{label}</label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger id={id} aria-label="Dispositivo target della operazione">
          <SelectValue placeholder={isPending ? 'Caricamento dispositivi…' : 'Seleziona un dispositivo reale'} />
        </SelectTrigger>
        <SelectContent>
          {items.map((d) => (
            <SelectItem key={d.id} value={d.id}>
              <span className="inline-flex min-w-0 items-center gap-1.5">
                <Monitor className="size-3.5 shrink-0 text-text-2" aria-hidden />
                <span className="max-w-[200px] truncate">{d.hostname}</span>
                <span className="shrink-0 text-xs text-text-2">· {typeLabel(d.type)}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <p className="text-[11px] leading-snug text-text-2">
        {isPending
          ? 'Inventario reale in caricamento…'
          : isError
            ? 'Inventario non raggiungibile: chiudi e riapri il form per ritentare.'
            : total != null && total > items.length
              ? `Primi ${fmtNumber(items.length)} dispositivi dell'inventario reale (di ${fmtNumber(total)} totali: pick-list limitata a ${DEVICE_PAGE_SIZE}).`
              : `Primi ${fmtNumber(items.length)} dispositivi dell'inventario reale.`}
      </p>
    </div>
  )
}

/** Executor: RadioGroup SIMULATED (consigliato) / SSH con nota onesta
 * sulla riproduzione (pattern del costruttore gruppi). */
function ExecutorFieldset({
  value,
  onChange,
  sshNote,
}: {
  value: 'SSH' | 'SIMULATED'
  onChange: (v: 'SSH' | 'SIMULATED') => void
  sshNote: string
}) {
  return (
    <fieldset className="grid gap-1.5">
      <legend className="text-xs font-medium text-text-2">Executor *</legend>
      <RadioGroup
        value={value}
        onValueChange={(v) => onChange(v === 'SSH' ? 'SSH' : 'SIMULATED')}
        className="grid gap-2"
        aria-label="Executor dei comandi"
      >
        <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-raised p-3 transition-colors has-[button[data-state=checked]]:border-primary">
          <RadioGroupItem value="SIMULATED" className="mt-0.5" />
          <span className="grid gap-0.5">
            <span className="text-xs font-medium">SIMULATED — dry-run (consigliato)</span>
            <span className="text-[11px] leading-snug text-text-2">
              I comandi vengono convalidati e registrati con audit, MAI inviati al dispositivo:
              output dry-run dichiarato.
            </span>
          </span>
        </label>
        <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-raised p-3 transition-colors has-[button[data-state=checked]]:border-primary">
          <RadioGroupItem value="SSH" className="mt-0.5" />
          <span className="grid gap-0.5">
            <span className="text-xs font-medium">SSH</span>
            <span className="text-[11px] leading-snug text-text-2">{sshNote}</span>
          </span>
        </label>
      </RadioGroup>
    </fieldset>
  )
}

/* ================================================================
 * Radice: sub-tab interni (sesto tab della vista Operazioni)
 * ================================================================ */

export default function OperazioniEvoluteSection() {
  return (
    <Tabs defaultValue="config">
      {/* 6 sub-tab: su mobile la lista scorre orizzontalmente (pattern
       * della vista Operazioni) invece di sbordare. */}
      <TabsList
        aria-label="Sottosezioni delle operazioni evolute"
        className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit"
      >
        <TabsTrigger value="config" className="shrink-0">Richieste configurazione</TabsTrigger>
        <TabsTrigger value="bulk" className="shrink-0">Ondate (bulk)</TabsTrigger>
        <TabsTrigger value="firmware" className="shrink-0">Firmware</TabsTrigger>
        <TabsTrigger value="playbook" className="shrink-0">Playbook</TabsTrigger>
        <TabsTrigger value="automazioni" className="shrink-0">Automazioni</TabsTrigger>
        <TabsTrigger value="terminale" className="shrink-0">Terminale SSH</TabsTrigger>
      </TabsList>
      <TabsContent value="config" className="mt-4">
        <ConfigRequestsCard />
      </TabsContent>
      <TabsContent value="bulk" className="mt-4">
        <BulkConfigsCard />
      </TabsContent>
      <TabsContent value="firmware" className="mt-4">
        <FirmwareCard />
      </TabsContent>
      <TabsContent value="playbook" className="mt-4">
        <PlaybooksCard />
      </TabsContent>
      <TabsContent value="automazioni" className="mt-4">
        <AutomationTasksCard />
      </TabsContent>
      <TabsContent value="terminale" className="mt-4">
        <TerminalCard />
      </TabsContent>
    </Tabs>
  )
}

/* ================================================================
 * A — Richieste di configurazione (commit-confirm + guardrail)
 * ================================================================ */

function ConfigRequestsCard() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [detailId, setDetailId] = useState<string | null>(null)

  const q = useQuery({
    queryKey: ['config-requests'],
    queryFn: () => api.configRequests(),
    staleTime: 15_000,
  })
  const items = q.data?.data.items ?? []
  const total = q.data?.data.total ?? 0
  /* KPI onesti: conteggi REALI dell'elenco (0 quando il DB è vuoto). */
  const pendingCount = items.filter((r) => r.status === 'PENDING').length
  const appliedCount = items.filter((r) => r.status === 'APPLIED' || r.status === 'CONFIRMED').length
  const detail = detailId != null ? items.find((r) => r.id === detailId) ?? null : null

  /* Transizioni della macchina a stati: ogni azione è una mutation;
   * gli errori del backend (INVALID_TRANSITION, WINDOW_EXPIRED,
   * REPLAY_NOEXEC) arrivano col messaggio completo nel toast. */
  const action = useMutation({
    mutationFn: (v: { id: string; act: Parameters<typeof api.configRequestAction>[1] }) =>
      api.configRequestAction(v.id, v.act),
    onSuccess: (row, v) => {
      toast.success(ACTION_TOAST[v.act] ?? 'Azione registrata', {
        description: `«${row.title}» → ${CONFIG_STATUS_META[row.status]?.label ?? row.status}.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['config-requests'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Azione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ClipboardList className="size-4 text-text-2" aria-hidden />
          Richieste di configurazione
        </CardTitle>
        <CardDescription>
          Pipeline commit-confirm del DB reale: guardrail sui comandi distruttivi, approvazione,
          applicazione dry-run e finestra di conferma.
        </CardDescription>
        <CardAction>
          <div className="flex items-center gap-1.5">
            {q.data ? <AsOf ts={q.data.asOf} /> : null}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void q.refetch() }}
              disabled={q.isFetching}
              aria-label="Aggiorna l'elenco delle richieste"
            >
              <RefreshCw className={cn('size-3.5', q.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden />
              Nuova richiesta
            </Button>
          </div>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {q.isPending ? (
          <LoadingRows rows={3} />
        ) : q.isError ? (
          <ErrorPanel
            message={errInfo(q.error).message}
            code={errInfo(q.error).code}
            onRetry={() => { void q.refetch() }}
          />
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-3">
              <KpiCard
                label="Richieste totali"
                value={fmtNumber(total)}
                definition="Richieste di modifica configurazione registrate nel DB reale, in qualsiasi stato del workflow."
              />
              <KpiCard
                label="In attesa di approvazione"
                value={fmtNumber(pendingCount)}
                accent="info"
                definition="Stato PENDING: la richiesta attende l'approvazione (o il rifiuto) di un tecnico."
              />
              <KpiCard
                label="Applicate (dry-run)"
                value={fmtNumber(appliedCount)}
                accent="warn"
                definition="Stati APPLIED e CONFIRMED: comandi applicati SOLO in dry-run in modalità riproduzione — nessun comando è mai stato inviato ai dispositivi."
              />
            </div>

            {items.length === 0 ? (
              <EmptyState
                icon={<ClipboardList className="size-10" aria-hidden />}
                title="Nessuna richiesta di configurazione"
                description="Il DB reale non contiene richieste: nessuna riga di esempio viene inventata. La pipeline commit-confirm (guardrail sui comandi distruttivi, approvazione, finestra di conferma) si attiva alla prima richiesta creata."
                action={
                  <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                    <Plus className="size-3.5" aria-hidden />
                    Nuova richiesta
                  </Button>
                }
              />
            ) : (
              <div
                className={cn(
                  'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
                  q.isFetching && 'opacity-70',
                )}
                aria-busy={q.isFetching}
              >
                <TooltipProvider delayDuration={150}>
                  <Table>
                    <TableCaption className="sr-only">
                      Richieste di configurazione del DB reale: titolo, dispositivo, numero comandi,
                      executor, stato del workflow commit-confirm, finestra di conferma e azioni contestuali
                    </TableCaption>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead scope="col" className="min-w-[210px]">Titolo</TableHead>
                        <TableHead scope="col" className="w-[90px] text-center">Comandi</TableHead>
                        <TableHead scope="col" className="w-[150px]">Executor</TableHead>
                        <TableHead scope="col" className="w-[160px]">Stato</TableHead>
                        <TableHead scope="col" className="w-[140px]">Conferma entro</TableHead>
                        <TableHead scope="col" className="w-[280px]">Azioni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((r) => {
                        const meta = CONFIG_STATUS_META[r.status]
                        const StatusIcon = meta?.Icon
                        const rowBusy = action.isPending && action.variables?.id === r.id
                        return (
                          <TableRow key={r.id}>
                            <TableCell className="min-w-[210px]">
                              <p className="truncate font-medium" title={r.title}>{r.title}</p>
                              <p className="mt-0.5 truncate text-xs text-text-2" title={`${r.deviceHostname} · ${typeLabel(r.deviceType)}`}>
                                <Monitor className="mr-1 inline size-3 align-[-2px]" aria-hidden />
                                {r.deviceHostname} · {typeLabel(r.deviceType)}
                              </p>
                            </TableCell>
                            <TableCell className="w-[90px] text-center num" title={`${r.commands.length} comandi (di cui ${r.rollback.length} di rollback)`}>
                              {fmtNumber(r.commands.length)}
                            </TableCell>
                            <TableCell className="w-[150px]">
                              <ExecutorBadge executor={r.executor} />
                            </TableCell>
                            <TableCell className="w-[160px]">
                              <VocabBadge
                                label={meta?.label ?? r.status}
                                cls={meta?.cls ?? 'bg-raised text-text-2 border-border'}
                                Icon={StatusIcon}
                              />
                            </TableCell>
                            <TableCell className="w-[140px] text-xs">
                              {r.confirmBy != null ? (
                                <span
                                  className={cn('num', r.status === 'APPLIED' && r.confirmBy < Date.now() && 'text-warn')}
                                  title={`Finestra commit-confirm entro ${fmtDateTimeFull(r.confirmBy)}${r.status === 'APPLIED' && r.confirmBy < Date.now() ? ' — scaduta: la conferma verrà rifiutata (WINDOW_EXPIRED), eseguire il rollback' : ''}`}
                                >
                                  {fmtDateTime(r.confirmBy)}
                                </span>
                              ) : (
                                <span className="text-text-2">—</span>
                              )}
                            </TableCell>
                            <TableCell className="w-[280px]">
                              {/* Azioni CONTESTUALI: SOLO le transizioni legali dallo stato attuale. */}
                              <div className="flex flex-wrap items-center gap-1.5">
                                {r.status === 'PENDING' ? (
                                  <>
                                    <Button
                                      size="sm" className="h-8" disabled={rowBusy}
                                      onClick={() => action.mutate({ id: r.id, act: 'approve' })}
                                    >
                                      {rowBusy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Check className="size-3.5" aria-hidden />}
                                      Approva
                                    </Button>
                                    <Button
                                      variant="outline" size="sm" className="h-8 text-crit-text" disabled={rowBusy}
                                      onClick={() => action.mutate({ id: r.id, act: 'reject' })}
                                    >
                                      <CircleX className="size-3.5" aria-hidden />
                                      Respingi
                                    </Button>
                                  </>
                                ) : null}
                                {r.status === 'APPROVED' ? (
                                  <>
                                    <Button
                                      size="sm" className="h-8" disabled={rowBusy}
                                      onClick={() => action.mutate({ id: r.id, act: 'apply' })}
                                    >
                                      {rowBusy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Play className="size-3.5" aria-hidden />}
                                      Applica
                                    </Button>
                                    <Button
                                      variant="outline" size="sm" className="h-8 text-crit-text" disabled={rowBusy}
                                      onClick={() => action.mutate({ id: r.id, act: 'reject' })}
                                    >
                                      <CircleX className="size-3.5" aria-hidden />
                                      Respingi
                                    </Button>
                                  </>
                                ) : null}
                                {r.status === 'APPLIED' ? (
                                  <>
                                    <Button
                                      size="sm" className="h-8" disabled={rowBusy}
                                      onClick={() => action.mutate({ id: r.id, act: 'confirm' })}
                                    >
                                      {rowBusy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <CircleCheck className="size-3.5" aria-hidden />}
                                      Conferma
                                    </Button>
                                    <Button
                                      variant="outline" size="sm" className="h-8" disabled={rowBusy}
                                      onClick={() => action.mutate({ id: r.id, act: 'rollback' })}
                                    >
                                      <Undo2 className="size-3.5" aria-hidden />
                                      Rollback
                                    </Button>
                                  </>
                                ) : null}
                                {r.status === 'CONFIRMED' ? (
                                  <Button
                                    variant="outline" size="sm" className="h-8" disabled={rowBusy}
                                    onClick={() => action.mutate({ id: r.id, act: 'rollback' })}
                                  >
                                    {rowBusy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Undo2 className="size-3.5" aria-hidden />}
                                    Rollback
                                  </Button>
                                ) : null}
                                <Button
                                  variant="ghost" size="sm" className="h-8"
                                  onClick={() => setDetailId(r.id)}
                                  aria-label={`Dettagli della richiesta ${r.title}`}
                                >
                                  <Eye className="size-3.5" aria-hidden />
                                  Dettaglio
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </TooltipProvider>
              </div>
            )}
          </>
        )}
      </CardContent>

      {/* Dialog creazione: montato SOLO quando serve (prefill pulito). */}
      {createOpen ? (
        <ConfigRequestCreateDialog
          open
          onOpenChange={(o) => { if (!o) setCreateOpen(false) }}
        />
      ) : null}

      {/* Dialog dettaglio: riga reale dell'elenco. */}
      {detail ? (
        <ConfigRequestDetailDialog
          row={detail}
          onOpenChange={(o) => { if (!o) setDetailId(null) }}
        />
      ) : null}
    </Card>
  )
}

const ACTION_TOAST: Record<Parameters<typeof api.configRequestAction>[1], string> = {
  approve: 'Richiesta approvata',
  reject: 'Richiesta respinta',
  apply: 'Applicazione registrata (dry-run)',
  confirm: 'Applicazione confermata',
  rollback: 'Rollback eseguito (dry-run)',
}

/* ---------------- Dialog creazione richiesta ---------------- */

function ConfigRequestCreateDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const queryClient = useQueryClient()
  const devices = useDevices50()
  const deviceItems = devices.data?.data.items ?? []

  const [deviceId, setDeviceId] = useState('')
  const [title, setTitle] = useState('')
  const [commandsRaw, setCommandsRaw] = useState('')
  const [rollbackRaw, setRollbackRaw] = useState('')
  const [executor, setExecutor] = useState<'SSH' | 'SIMULATED'>('SIMULATED')
  const [confirmMinutes, setConfirmMinutes] = useState('10')
  const [note, setNote] = useState('')
  const [formError, setFormError] = useState<string | null>(null)

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createConfigRequest>[0]) => api.createConfigRequest(input),
    onSuccess: (row) => {
      toast.success('Richiesta creata', {
        description: `«${row.title}» su ${row.deviceHostname} — stato iniziale ${CONFIG_STATUS_META[row.status]?.label ?? row.status}; guardrail superato (${row.safety.checked} comandi verificati).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['config-requests'] })
      onOpenChange(false)
    },
    onError: (e) => {
      /* Messaggio completo del backend: per FORBIDDEN_COMMAND include i
       * label dei pattern vietati — il rifiuto non è mai silenziato. */
      const info = errInfo(e)
      toast.error(info.code === 'FORBIDDEN_COMMAND' ? 'Comando vietato dal guardrail' : 'Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const submit = () => {
    setFormError(null)
    /* Validazione onesta lato client (la stessa del contratto server). */
    if (!deviceId) { setFormError('Seleziona un dispositivo target reale.'); return }
    if (title.trim().length < 3) { setFormError('Il titolo richiede almeno 3 caratteri.'); return }
    const commands = parseLines(commandsRaw)
    if (commands.length === 0) { setFormError('Inserisci almeno un comando (uno per riga).'); return }
    const cm = parseIntField(confirmMinutes)
    if (cm == null || cm < 0 || cm > 120) { setFormError('La finestra di conferma deve essere un numero intero fra 0 e 120 minuti.'); return }
    const rollback = parseLines(rollbackRaw)
    create.mutate({
      deviceId,
      title: title.trim(),
      commands,
      rollback: rollback.length > 0 ? rollback : undefined,
      executor,
      confirmMinutes: cm,
      note: note.trim() || undefined,
    })
  }

  const pending = create.isPending

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!pending || o) onOpenChange(o) }}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Nuova richiesta di configurazione</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Crea una richiesta REALE nel DB dell&apos;impianto: stato iniziale «In attesa», guardrail
            v15 attivo sulla creazione (i comandi distruttivi vengono rifiutati), esecuzione in
            dry-run con finestra commit-confirm.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <DeviceSelectField
            id="cr-device"
            value={deviceId}
            onChange={setDeviceId}
            items={deviceItems}
            isPending={devices.isPending}
            isError={devices.isError}
            total={devices.data?.data.total}
          />

          <div className="grid gap-1.5">
            <label htmlFor="cr-title" className="text-xs font-medium text-text-2">Titolo (min 3 caratteri) *</label>
            <Input
              id="cr-title"
              value={title}
              maxLength={120}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="es. Aggiornazione VLAN di gestione switch sala B"
              aria-required="true"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="cr-commands" className="text-xs font-medium text-text-2">
              Comandi (uno per riga, min 1) *
            </label>
            <Textarea
              id="cr-commands"
              value={commandsRaw}
              onChange={(e) => setCommandsRaw(e.target.value)}
              placeholder={'es.\ninterface eth1\ndescription uplink-core'}
              className="min-h-24 font-mono text-xs"
              aria-required="true"
            />
            <p className="text-[11px] leading-snug text-text-2">
              Ogni riga è un comando: il guardrail rifiuta la richiesta SE un comando matcha un
              pattern distruttivo (es. «rm -rf», reload senza confirm).
            </p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="cr-rollback" className="text-xs font-medium text-text-2">
              Comandi di rollback (opzionali, uno per riga)
            </label>
            <Textarea
              id="cr-rollback"
              value={rollbackRaw}
              onChange={(e) => setRollbackRaw(e.target.value)}
              placeholder="es. no description eth1"
              className="min-h-16 font-mono text-xs"
            />
          </div>

          <ExecutorFieldset
            value={executor}
            onChange={setExecutor}
            sshNote="SSH non eseguibile in riproduzione: la apply verrà rifiutata onestamente (REPLAY_NOEXEC)."
          />

          <div className="grid gap-1.5">
            <label htmlFor="cr-confirm" className="text-xs font-medium text-text-2">Finestra commit-confirm (minuti) *</label>
            <Input
              id="cr-confirm"
              type="number"
              min={0}
              max={120}
              value={confirmMinutes}
              onChange={(e) => setConfirmMinutes(e.target.value)}
              aria-required="true"
            />
            <p className="text-[11px] text-text-2">0 = senza finestra (applicazione definitiva); default 10 minuti.</p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="cr-note" className="text-xs font-medium text-text-2">Nota (opzionale)</label>
            <Input
              id="cr-note"
              value={note}
              maxLength={300}
              onChange={(e) => setNote(e.target.value)}
              placeholder="es. cambio concordato col cliente per la manutenzione del 12"
            />
          </div>

          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs leading-relaxed text-crit-text">
              {formError}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>Annulla</Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
            Crea richiesta
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Dialog dettaglio richiesta ---------------- */

function ConfigRequestDetailDialog({ row, onOpenChange }: { row: ConfigRequestRow; onOpenChange: (o: boolean) => void }) {
  const status = CONFIG_STATUS_META[row.status]
  const dryRun = /DRY-RUN/i.test(row.output)

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="pr-6">{row.title}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {row.deviceHostname} · {typeLabel(row.deviceType)} · executor {row.executor} · stato{' '}
            {status?.label ?? row.status}. Richiesta da {row.requestedBy} il {fmtDateTime(row.createdAt)}.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          {/* Output: mono; il dry-run dichiarato è EVIDENZIATO, mai spacciato per esecuzione. */}
          <div className="grid gap-1.5">
            <p className="flex items-center gap-1.5 text-xs font-medium text-text-2">
              <FileText className="size-3.5" aria-hidden />
              Output dell&apos;applicazione
            </p>
            {row.output ? (
              <div className={cn(
                'rounded-md border p-3',
                dryRun ? 'border-warn/40 bg-warn-soft' : 'border-border bg-raised/40',
              )}>
                {dryRun ? (
                  <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-warn">
                    <ShieldCheck className="size-3.5" aria-hidden />
                    DRY-RUN: NESSUN comando inviato al dispositivo
                  </p>
                ) : null}
                <pre className="whitespace-pre-wrap break-words font-mono text-xs leading-relaxed">{row.output}</pre>
              </div>
            ) : (
              <p className="rounded-md border border-dashed border-border px-3 py-2.5 text-xs text-text-2">
                — nessun output: la richiesta non è ancora stata applicata.
              </p>
            )}
          </div>

          {/* Safety report congelato alla creazione (v15 S1). */}
          <div className="rounded-md border border-border bg-raised/40 p-3">
            <p className="flex items-center gap-1.5 text-xs font-medium text-text-2">
              <ShieldCheck className="size-3.5" aria-hidden />
              Report guardrail (congelato alla creazione)
            </p>
            <dl className="mt-2 grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Comandi verificati</dt>
                <dd className="num text-sm">{fmtNumber(row.safety.checked)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Pattern vietati</dt>
                <dd className="text-sm break-words">
                  {row.safety.forbidden.length > 0 ? row.safety.forbidden.join(' · ') : 'nessuno (richiesta pulita)'}
                </dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Tetto comandi</dt>
                <dd className="num text-sm">{fmtNumber(row.safety.maxCommands)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Modalità</dt>
                <dd className="text-sm">
                  {row.safety.dryRunOnly ? 'solo dry-run (SIMULATED)' : 'esecuzione reale prevista (SSH)'}
                </dd>
              </div>
            </dl>
          </div>

          {/* Comandi e rollback: elenchi mono reali del DB. */}
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-md border border-border p-3">
              <p className="text-xs font-medium text-text-2">Comandi ({fmtNumber(row.commands.length)})</p>
              <ol className="mt-1.5 space-y-1 font-mono text-xs leading-relaxed">
                {row.commands.map((c, i) => (
                  <li key={i} className="break-all"><span className="text-text-2">{i + 1}.</span> {c}</li>
                ))}
              </ol>
            </div>
            <div className="rounded-md border border-border p-3">
              <p className="text-xs font-medium text-text-2">Rollback ({fmtNumber(row.rollback.length)})</p>
              {row.rollback.length > 0 ? (
                <ol className="mt-1.5 space-y-1 font-mono text-xs leading-relaxed">
                  {row.rollback.map((c, i) => (
                    <li key={i} className="break-all"><span className="text-text-2">{i + 1}.</span> {c}</li>
                  ))}
                </ol>
              ) : (
                <p className="mt-1.5 text-xs text-text-2">Nessun comando di rollback registrato.</p>
              )}
            </div>
          </div>

          {/* Audit: chi ha fatto cosa, con valori onesti «—» se assenti. */}
          <div className="rounded-md border border-border bg-raised/40 p-3">
            <p className="text-xs font-medium text-text-2">Audit e finestra di conferma</p>
            <dl className="mt-2 grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Richiesta da</dt>
                <dd className="truncate text-sm" title={row.requestedBy}>{row.requestedBy}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Approvata da</dt>
                <dd className="truncate text-sm" title={row.approvedBy ?? undefined}>{row.approvedBy ?? '—'}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Applicata il</dt>
                <dd className="num text-sm">{fmtDateTime(row.appliedAt)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Conferma entro</dt>
                <dd className="num text-sm">{fmtDateTime(row.confirmBy)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Finestra</dt>
                <dd className="num text-sm">
                  {row.confirmMinutes > 0 ? `${fmtNumber(row.confirmMinutes)} min` : 'senza finestra (0 min)'}
                </dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Ultimo aggiornamento</dt>
                <dd className="num text-sm" title={fmtDateTimeFull(row.updatedAt)}>
                  {fmtDateTime(row.updatedAt)} ({fmtRelative(row.updatedAt)})
                </dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2 sm:col-span-2">
                <dt className="text-xs text-text-2">Nota</dt>
                <dd className="text-sm break-words">{row.note || '—'}</dd>
              </div>
            </dl>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Chiudi</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * B — Ondate di configurazione bulk (v15 R8: max 50 target)
 * ================================================================ */

function BulkConfigsCard() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [resultRow, setResultRow] = useState<BulkConfigRow | null>(null)

  const q = useQuery({
    queryKey: ['bulk-configs'],
    queryFn: () => api.bulkConfigs(),
    staleTime: 15_000,
  })
  const items = q.data?.data.items ?? []
  const total = q.data?.data.total ?? 0
  /* KPI onesti calcolati sui dati REALI: le esecuzioni non simulate
   * sono 0 in riproduzione (dry-run dichiarato in ogni risultato). */
  const targetSum = items.reduce((acc, w) => acc + w.targetCount, 0)
  const realExecutions = items.reduce((acc, w) => acc + w.results.filter((r) => !r.simulated).length, 0)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Waves className="size-4 text-text-2" aria-hidden />
          Ondate di configurazione (bulk)
        </CardTitle>
        <CardDescription>
          Cambi di configurazione su più dispositivi reali: tetto v15 R8 di 50 target per ondata,
          guardrail sui comandi e risultati per dispositivo.
        </CardDescription>
        <CardAction>
          <div className="flex items-center gap-1.5">
            {q.data ? <AsOf ts={q.data.asOf} /> : null}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void q.refetch() }}
              disabled={q.isFetching}
              aria-label="Aggiorna l'elenco delle ondate"
            >
              <RefreshCw className={cn('size-3.5', q.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden />
              Nuova ondata
            </Button>
          </div>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {q.isPending ? (
          <LoadingRows rows={3} />
        ) : q.isError ? (
          <ErrorPanel
            message={errInfo(q.error).message}
            code={errInfo(q.error).code}
            onRetry={() => { void q.refetch() }}
          />
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-3">
              <KpiCard
                label="Ondate registrate"
                value={fmtNumber(total)}
                definition="Ondate bulk registrate nel DB reale (ogni ondata è una riga con risultati per target)."
              />
              <KpiCard
                label="Target coinvolti"
                value={fmtNumber(targetSum)}
                definition="Somma dei dispositivi target di tutte le ondate registrate (tetto di 50 per ondata, v15 R8)."
              />
              <KpiCard
                label="Comandi inviati davvero"
                value={fmtNumber(realExecutions)}
                accent="warn"
                definition="Righe di risultato NON simulate. In modalità riproduzione ogni ondata è un dry-run dichiarato: nessun comando raggiunge i dispositivi."
              />
            </div>

            {items.length === 0 ? (
              <EmptyState
                icon={<Waves className="size-10" aria-hidden />}
                title="Nessuna ondata registrata"
                description="Il DB reale parte da zero ondate bulk: nessuna riga di esempio viene inventata. Ogni ondata futura avrà tetto di 50 target e, in modalità riproduzione, esito dry-run dichiarato."
                action={
                  <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                    <Plus className="size-3.5" aria-hidden />
                    Nuova ondata
                  </Button>
                }
              />
            ) : (
              <div
                className={cn(
                  'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
                  q.isFetching && 'opacity-70',
                )}
                aria-busy={q.isFetching}
              >
                <Table>
                  <TableCaption className="sr-only">
                    Ondate bulk del DB reale: titolo, numero target, numero comandi, executor, stato,
                    durata e risultati per dispositivo
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col" className="min-w-[220px]">Titolo</TableHead>
                      <TableHead scope="col" className="w-[90px] text-center">Target</TableHead>
                      <TableHead scope="col" className="w-[100px] text-center">Comandi</TableHead>
                      <TableHead scope="col" className="w-[150px]">Executor</TableHead>
                      <TableHead scope="col" className="w-[170px]">Stato</TableHead>
                      <TableHead scope="col" className="w-[110px]">Durata</TableHead>
                      <TableHead scope="col" className="w-[130px]">
                        <span className="sr-only">Azioni</span>
                        Azioni
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((w) => {
                      const meta = BULK_STATUS_META[w.status]
                      const StatusIcon = meta?.Icon
                      const duration = w.completedAt != null && w.startedAt != null ? w.completedAt - w.startedAt : null
                      return (
                        <TableRow key={w.id}>
                          <TableCell className="min-w-[220px]">
                            <p className="truncate font-medium" title={w.title}>{w.title}</p>
                            <p className="mt-0.5 truncate text-xs text-text-2" title={w.targetHostnames.join(', ') || undefined}>
                              {w.targetHostnames.slice(0, 3).join(', ')}
                              {w.targetCount > 3 ? ` … (+${fmtNumber(w.targetCount - 3)})` : ''}
                            </p>
                          </TableCell>
                          <TableCell className="w-[90px] text-center num" title={`${w.targetCount} dispositivi target`}>
                            {fmtNumber(w.targetCount)}
                          </TableCell>
                          <TableCell className="w-[100px] text-center num" title={`${w.commands.length} comandi`}>
                            {fmtNumber(w.commands.length)}
                          </TableCell>
                          <TableCell className="w-[150px]">
                            <ExecutorBadge executor={w.executor} />
                          </TableCell>
                          <TableCell className="w-[170px]">
                            <VocabBadge
                              label={meta?.label ?? w.status}
                              cls={meta?.cls ?? 'bg-raised text-text-2 border-border'}
                              Icon={StatusIcon}
                            />
                          </TableCell>
                          <TableCell className="w-[110px] text-xs num" title={duration != null ? `${duration} ms (startedAt→completedAt)` : undefined}>
                            {duration != null ? fmtMs(duration) : '—'}
                          </TableCell>
                          <TableCell className="w-[130px]">
                            <Button
                              variant="outline" size="sm" className="h-8"
                              onClick={() => setResultRow(w)}
                              aria-label={`Risultati per dispositivo dell'ondata ${w.title}`}
                            >
                              <ListChecks className="size-3.5" aria-hidden />
                              Risultati
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </>
        )}
      </CardContent>

      {createOpen ? (
        <BulkCreateDialog open onOpenChange={(o) => { if (!o) setCreateOpen(false) }} />
      ) : null}
      {resultRow ? (
        <BulkResultsDialog row={resultRow} onOpenChange={(o) => { if (!o) setResultRow(null) }} />
      ) : null}
    </Card>
  )
}

/* ---------------- Dialog creazione ondata ---------------- */

function BulkCreateDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const queryClient = useQueryClient()
  const devices = useDevices50()
  const deviceItems = devices.data?.data.items ?? []

  const [title, setTitle] = useState('')
  const [commandsRaw, setCommandsRaw] = useState('')
  const [executor, setExecutor] = useState<'SSH' | 'SIMULATED'>('SIMULATED')
  const [picked, setPicked] = useState<string[]>([])
  const [pickerOpen, setPickerOpen] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  const togglePicked = (id: string) => {
    setPicked((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createBulkConfig>[0]) => api.createBulkConfig(input),
    onSuccess: (row) => {
      toast.success('Ondata registrata (dry-run)', {
        description: `«${row.title}» — ${fmtNumber(row.targetCount)} target · ${fmtNumber(row.results.length)} risultati simulati: nessun comando inviato ai dispositivi.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['bulk-configs'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error(info.code === 'FORBIDDEN_COMMAND' ? 'Comando vietato dal guardrail' : 'Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const overCap = picked.length > BULK_MAX_TARGETS_UI
  const pending = create.isPending

  const submit = () => {
    setFormError(null)
    if (title.trim().length < 3) { setFormError('Il titolo richiede almeno 3 caratteri.'); return }
    const commands = parseLines(commandsRaw)
    if (commands.length === 0) { setFormError('Inserisci almeno un comando (uno per riga).'); return }
    if (picked.length === 0) { setFormError('Seleziona almeno un dispositivo target.'); return }
    if (overCap) { setFormError(`Tetto v15 R8 superato: ${picked.length} > ${BULK_MAX_TARGETS_UI} target.`); return }
    create.mutate({ title: title.trim(), commands, deviceIds: picked, executor })
  }

  const pickedDevices = deviceItems.filter((d) => picked.includes(d.id))

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!pending || o) onOpenChange(o) }}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Nuova ondata (bulk)</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Cambi di configurazione su più dispositivi reali dell&apos;impianto: tetto di{' '}
            {BULK_MAX_TARGETS_UI} target (v15 R8), guardrail sui comandi distruttivi, risultati per
            dispositivo. In riproduzione l&apos;esito è dry-run dichiarato.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <label htmlFor="bulk-title" className="text-xs font-medium text-text-2">Titolo (min 3 caratteri) *</label>
            <Input
              id="bulk-title"
              value={title}
              maxLength={120}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="es. Abilitazione syslog verso il collector centrale"
              aria-required="true"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="bulk-commands" className="text-xs font-medium text-text-2">Comandi (uno per riga, min 1) *</label>
            <Textarea
              id="bulk-commands"
              value={commandsRaw}
              onChange={(e) => setCommandsRaw(e.target.value)}
              placeholder={'es.\nlogging host 10.0.0.9\nlogging trap informational'}
              className="min-h-24 font-mono text-xs"
              aria-required="true"
            />
          </div>

          {/* Target: multi-select Popover+Command (pattern dei gruppi)
           * con contatore N/50 e guardrail client-side sul tetto. */}
          <div className="grid gap-1.5">
            <span className="text-xs font-medium text-text-2" id="bulk-targets-label">
              Dispositivi target ({fmtNumber(picked.length)}/{BULK_MAX_TARGETS_UI}) *
            </span>
            {pickedDevices.length > 0 ? (
              <div
                className="flex max-h-32 flex-wrap gap-1.5 overflow-y-auto scroll-thin"
                role="list"
                aria-labelledby="bulk-targets-label"
                aria-label="Dispositivi target dell'ondata"
              >
                {pickedDevices.map((d) => (
                  <Badge key={d.id} variant="outline" className="gap-1.5 border-link/40 bg-info-soft font-normal text-info" role="listitem">
                    <Monitor className="size-3.5 shrink-0" aria-hidden />
                    <span className="max-w-[170px] truncate" title={`${d.hostname} · ${typeLabel(d.type)}`}>{d.hostname}</span>
                    <button
                      type="button"
                      className="ml-1 rounded-sm hover:text-foreground"
                      aria-label={`Rimuovi ${d.hostname} dai target`}
                      onClick={() => togglePicked(d.id)}
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            ) : null}
            <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-11 sm:h-9"
                  aria-expanded={pickerOpen}
                  aria-haspopup="listbox"
                  aria-label="Aggiungi dispositivi ai target dell'ondata (inventario reale)"
                >
                  <Search className="size-3.5" aria-hidden />
                  Aggiungi dispositivi
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[340px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Cerca hostname, IP…" />
                  <CommandList>
                    {devices.isPending ? (
                      <div className="flex items-center justify-center gap-2 px-3 py-6 text-xs text-text-2">
                        <Loader2 className="size-4 animate-spin" aria-hidden />
                        caricamento inventario…
                      </div>
                    ) : devices.isError ? (
                      <div className="px-3 py-6 text-center text-xs text-crit">
                        Inventario non raggiungibile: {errInfo(devices.error).message}
                      </div>
                    ) : (
                      <>
                        <CommandEmpty>Nessun dispositivo trovato con questa ricerca.</CommandEmpty>
                        <CommandGroup heading={`Primi ${fmtNumber(deviceItems.length)} dispositivi reali dell'impianto`}>
                          {deviceItems.map((d) => {
                            const selected = picked.includes(d.id)
                            return (
                              <CommandItem
                                key={d.id}
                                value={`${d.hostname} ${d.ip}`}
                                onSelect={() => togglePicked(d.id)}
                                aria-label={`${d.hostname}${selected ? ' (già selezionato: clic per rimuoverlo)' : ''}`}
                              >
                                {selected
                                  ? <Check className="size-4 shrink-0 text-ok" aria-hidden />
                                  : <Monitor className="size-4 shrink-0" aria-hidden />}
                                <span className="min-w-0 flex-1 truncate">{d.hostname}</span>
                                <span className="num shrink-0 text-xs text-text-2">{d.ip}</span>
                              </CommandItem>
                            )
                          })}
                        </CommandGroup>
                      </>
                    )}
                  </CommandList>
                  <div className="flex items-center justify-between border-t border-border/60 p-2">
                    <p className="px-1 text-xs text-text-2">
                      <span className="num">{fmtNumber(picked.length)}</span>/{BULK_MAX_TARGETS_UI} selezionati
                    </p>
                    <Button type="button" size="sm" variant="outline" className="h-8" onClick={() => setPickerOpen(false)}>
                      Fatto
                    </Button>
                  </div>
                </Command>
              </PopoverContent>
            </Popover>
            {overCap ? (
              <p className="text-xs text-warn" role="alert">
                Tetto v15 R8 superato: {fmtNumber(picked.length)} &gt; {BULK_MAX_TARGETS_UI} — riduci la
                selezione per abilitare il salvataggio.
              </p>
            ) : (
              <p className="text-[11px] leading-snug text-text-2">
                Massimo {BULK_MAX_TARGETS_UI} dispositivi per ondata (guardrail v15 R8, verificato
                anche dal backend alla creazione).
              </p>
            )}
          </div>

          <ExecutorFieldset
            value={executor}
            onChange={setExecutor}
            sshNote="In riproduzione l'ondata SSH viene rifiutata onestamente alla creazione (REPLAY_NOEXEC): usare SIMULATED."
          />

          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs leading-relaxed text-crit-text">
              {formError}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>Annulla</Button>
          <Button onClick={submit} disabled={pending || overCap || picked.length === 0}>
            {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
            Registra ondata
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Dialog risultati per dispositivo ---------------- */

function BulkResultsDialog({ row, onOpenChange }: { row: BulkConfigRow; onOpenChange: (o: boolean) => void }) {
  const meta = BULK_STATUS_META[row.status]
  const okCount = row.results.filter((r) => r.ok).length

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Risultati · {row.title}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {fmtNumber(row.targetCount)} target · executor {row.executor} · stato{' '}
            {meta?.label ?? row.status} · {fmtNumber(okCount)}/{fmtNumber(row.results.length)} convalidati.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3">
          <InfoNote>
            In modalità riproduzione l&apos;ondata è un dry-run: i risultati dichiarano la
            CONVALIDA dei comandi su ogni target, non un&apos;esecuzione di rete (nessun comando inviato).
          </InfoNote>

          <ul className="grid gap-1.5" role="list" aria-label="Risultati per dispositivo">
            {row.results.map((r) => (
              <li
                key={r.deviceId}
                className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-md border border-border bg-raised/40 px-3 py-2"
              >
                <span className="min-w-0 flex-1 truncate text-sm" title={r.hostname}>
                  <Monitor className="mr-1 inline size-3.5 align-[-3px] text-text-2" aria-hidden />
                  {r.hostname}
                </span>
                {r.ok ? (
                  <VocabBadge label="ok" cls="bg-ok-soft text-ok border-ok/40" Icon={CircleCheck} />
                ) : (
                  <VocabBadge label="errore" cls="bg-crit-soft text-crit-text border-crit/40" Icon={CircleX} />
                )}
                {r.simulated ? (
                  <Badge variant="outline" className="bg-raised text-text-2 border-border" title="Il backend registra la convalida, non l'invio">
                    dry-run: nessun comando inviato
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-warn-soft text-warn border-warn/40">
                    eseguito davvero
                  </Badge>
                )}
                {r.error ? (
                  <span className="w-full break-words font-mono text-xs text-crit-text" title={r.error}>{r.error}</span>
                ) : null}
                <span className="num text-xs text-text-2" title={`${r.durationMs} ms`}>{fmtMs(r.durationMs)}</span>
              </li>
            ))}
          </ul>

          <div className="rounded-md border border-border bg-raised/40 p-3">
            <p className="flex items-center gap-1.5 text-xs font-medium text-text-2">
              <ShieldCheck className="size-3.5" aria-hidden />
              Report guardrail (v15 R8)
            </p>
            <dl className="mt-2 grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Comandi verificati</dt>
                <dd className="num text-sm">{fmtNumber(row.safety.checked)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Tetto target</dt>
                <dd className="num text-sm">{fmtNumber(row.safety.maxTargets)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Pattern vietati</dt>
                <dd className="text-sm break-words">
                  {row.safety.forbidden.length > 0 ? row.safety.forbidden.join(' · ') : 'nessuno (ondata pulita)'}
                </dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Solo dry-run</dt>
                <dd className="text-sm">{row.safety.dryRunOnly ? 'sì (modalità riproduzione)' : 'no'}</dd>
              </div>
            </dl>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Chiudi</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * C — Firmware center (schedulazione onesta, mai esecuzione)
 * ================================================================ */

function FirmwareCard() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)

  const q = useQuery({
    queryKey: ['firmware-jobs'],
    queryFn: () => api.firmwareJobs(),
    staleTime: 15_000,
  })
  const items = q.data?.data.items ?? []
  const total = q.data?.data.total ?? 0

  const cancel = useMutation({
    mutationFn: (id: string) => api.cancelFirmwareJob(id),
    onSuccess: (row) => {
      toast.success('Upgrade annullato', {
        description: `${row.deviceHostname} → ${row.targetFirmware}: job passato a CANCELED nel DB reale (nessuna esecuzione era in corso).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['firmware-jobs'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Annullamento non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ServerCog className="size-4 text-text-2" aria-hidden />
          Firmware
        </CardTitle>
        <CardDescription>
          Schedulazione degli upgrade firmware sui dispositivi reali: versione attuale dal DB,
          versione di destinazione e annullamento.
        </CardDescription>
        <CardAction>
          <div className="flex items-center gap-1.5">
            {q.data ? <AsOf ts={q.data.asOf} /> : null}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void q.refetch() }}
              disabled={q.isFetching}
              aria-label="Aggiorna l'elenco dei job firmware"
            >
              <RefreshCw className={cn('size-3.5', q.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden />
              Schedula upgrade
            </Button>
          </div>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Onestà strutturale: la schedulazione è un REGISTRO (audit),
         * l'esecuzione dell'upgrade NON avviene in riproduzione. */}
        <InfoNote>
          Nessuna esecuzione in modalità riproduzione: la schedulazione è registrata (audit),
          l&apos;upgrade richiede i motori attivi.
        </InfoNote>

        {q.isPending ? (
          <LoadingRows rows={3} />
        ) : q.isError ? (
          <ErrorPanel
            message={errInfo(q.error).message}
            code={errInfo(q.error).code}
            onRetry={() => { void q.refetch() }}
          />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<ServerCog className="size-10" aria-hidden />}
            title={`Nessun upgrade firmware schedulato (${fmtNumber(total)} job)`}
            description="Il DB reale non contiene job firmware: nessuna riga di esempio viene inventata. Una schedulazione futura sarà registrata con audit e resterà «Programmato» finché i motori non saranno attivi."
            action={
              <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                <Plus className="size-3.5" aria-hidden />
                Schedula upgrade
              </Button>
            }
          />
        ) : (
          <div
            className={cn(
              'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
              q.isFetching && 'opacity-70',
            )}
            aria-busy={q.isFetching}
          >
            <Table>
              <TableCaption className="sr-only">
                Job firmware del DB reale: dispositivo, versione attuale e di destinazione,
                schedulazione, finestra di conferma, stato e annullamento
              </TableCaption>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead scope="col" className="min-w-[190px]">Dispositivo</TableHead>
                  <TableHead scope="col" className="min-w-[200px]">Firmware</TableHead>
                  <TableHead scope="col" className="w-[150px]">Programmato il</TableHead>
                  <TableHead scope="col" className="w-[110px] text-center">Conferma</TableHead>
                  <TableHead scope="col" className="w-[150px]">Stato</TableHead>
                  <TableHead scope="col" className="w-[130px]">
                    <span className="sr-only">Azioni</span>
                    Azioni
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((j) => {
                  const meta = FIRMWARE_STATUS_META[j.status]
                  const StatusIcon = meta?.Icon
                  const busy = cancel.isPending && cancel.variables === j.id
                  return (
                    <TableRow key={j.id}>
                      <TableCell className="min-w-[190px]">
                        <p className="truncate font-medium" title={j.deviceHostname}>{j.deviceHostname}</p>
                        <p className="mt-0.5 text-xs text-text-2">{typeLabel(j.deviceType)}</p>
                      </TableCell>
                      <TableCell className="min-w-[200px]">
                        <p className="font-mono text-xs">
                          {/* Attuale dal DB: «n.d.» se il campo è vuoto (mai inventato). */}
                          <span className={j.deviceFirmware ? 'text-text' : 'text-text-2'} title={j.deviceFirmware || 'versione attuale non presente nel DB'}>
                            {j.deviceFirmware || 'n.d.'}
                          </span>
                          <span className="mx-1.5 text-text-2" aria-hidden>→</span>
                          <span className="font-semibold" title={`Versione di destinazione: ${j.targetFirmware}`}>{j.targetFirmware}</span>
                        </p>
                      </TableCell>
                      <TableCell className="w-[150px] text-xs num" title={fmtDateTimeFull(j.scheduledAt)}>
                        {fmtDateTime(j.scheduledAt)}
                      </TableCell>
                      <TableCell className="w-[110px] text-center text-xs num">
                        {fmtNumber(j.confirmMinutes)} min
                      </TableCell>
                      <TableCell className="w-[150px]">
                        <VocabBadge
                          label={meta?.label ?? j.status}
                          cls={meta?.cls ?? 'bg-raised text-text-2 border-border'}
                          Icon={StatusIcon}
                        />
                      </TableCell>
                      <TableCell className="w-[130px]">
                        {/* Annulla: SOLO per i job SCHEDULED (transizione legale). */}
                        {j.status === 'SCHEDULED' ? (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="outline" size="sm" className="h-8 text-crit-text"
                                disabled={busy}
                                aria-label={`Annulla l'upgrade firmware di ${j.deviceHostname}`}
                              >
                                {busy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <CircleX className="size-3.5" aria-hidden />}
                                Annulla
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Annullare l&apos;upgrade di {j.deviceHostname}?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Il job passa a CANCELED nel DB reale (voce di audit). Nessuna
                                  esecuzione era in corso: in modalità riproduzione la schedulazione
                                  è solo un registro. L&apos;operazione non è reversibile: ricrea il
                                  job se ti serve di nuovo.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel disabled={busy}>Mantieni</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-crit-solid text-white hover:bg-crit-solid/90"
                                  disabled={busy}
                                  onClick={(e) => {
                                    e.preventDefault()
                                    cancel.mutate(j.id)
                                  }}
                                >
                                  <CircleX className="size-3.5" aria-hidden />
                                  Annulla upgrade
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        ) : (
                          <span className="text-xs text-text-2">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {createOpen ? (
        <FirmwareCreateDialog open onOpenChange={(o) => { if (!o) setCreateOpen(false) }} />
      ) : null}
    </Card>
  )
}

/* ---------------- Dialog schedulazione upgrade firmware ---------------- */

function FirmwareCreateDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const queryClient = useQueryClient()
  const devices = useDevices50()
  const deviceItems = devices.data?.data.items ?? []

  const [deviceId, setDeviceId] = useState('')
  const [targetFirmware, setTargetFirmware] = useState('')
  const [commandsRaw, setCommandsRaw] = useState('')
  const [confirmMinutes, setConfirmMinutes] = useState('10')
  const [scheduleRaw, setScheduleRaw] = useState('')
  const [formError, setFormError] = useState<string | null>(null)

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createFirmwareJob>[0]) => api.createFirmwareJob(input),
    onSuccess: (row) => {
      toast.success('Upgrade schedulato (nessuna esecuzione)', {
        description: `${row.deviceHostname} → ${row.targetFirmware}: schedulazione registrata con audit; l'esecuzione richiede i motori attivi (mai simulata).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['firmware-jobs'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error(info.code === 'FORBIDDEN_COMMAND' ? 'Comando vietato dal guardrail' : 'Schedulazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const submit = () => {
    setFormError(null)
    if (!deviceId) { setFormError('Seleziona un dispositivo target reale.'); return }
    if (targetFirmware.trim().length === 0) { setFormError('La versione di destinazione è obbligatoria.'); return }
    const cm = parseIntField(confirmMinutes)
    if (cm == null || cm < 1 || cm > 120) { setFormError('La finestra di conferma deve essere un numero intero fra 1 e 120 minuti.'); return }
    let scheduledAt: number | undefined
    if (scheduleRaw.trim() !== '') {
      const t = new Date(scheduleRaw).getTime()
      if (!Number.isFinite(t) || t < 0) { setFormError('Data di schedulazione non valida.'); return }
      scheduledAt = t
    }
    const commands = parseLines(commandsRaw)
    create.mutate({
      deviceId,
      targetFirmware: targetFirmware.trim(),
      commands: commands.length > 0 ? commands : undefined,
      confirmMinutes: cm,
      scheduledAt,
    })
  }

  const pending = create.isPending

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!pending || o) onOpenChange(o) }}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Schedula upgrade firmware</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Registra un job REALE nel DB dell&apos;impianto (stato «Programmato», audit
            FIRMWARE_CREATE). In modalità riproduzione nessun upgrade viene eseguito: la
            schedulazione è un registro onesto.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <DeviceSelectField
            id="fw-device"
            value={deviceId}
            onChange={setDeviceId}
            items={deviceItems}
            isPending={devices.isPending}
            isError={devices.isError}
            total={devices.data?.data.total}
          />

          <div className="grid gap-1.5">
            <label htmlFor="fw-target" className="text-xs font-medium text-text-2">Versione di destinazione *</label>
            <Input
              id="fw-target"
              value={targetFirmware}
              maxLength={80}
              onChange={(e) => setTargetFirmware(e.target.value)}
              placeholder="es. v2.1.4"
              aria-required="true"
            />
            <p className="text-[11px] text-text-2">La versione attuale è letta dal DB e mostrata nella tabella.</p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="fw-commands" className="text-xs font-medium text-text-2">
              Comandi aggiuntivi (opzionali, uno per riga)
            </label>
            <Textarea
              id="fw-commands"
              value={commandsRaw}
              onChange={(e) => setCommandsRaw(e.target.value)}
              placeholder="es. system backup pre-upgrade"
              className="min-h-16 font-mono text-xs"
            />
            <p className="text-[11px] text-text-2">Sottoposti allo stesso guardrail dei comandi di configurazione.</p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="fw-confirm" className="text-xs font-medium text-text-2">Finestra di conferma (minuti) *</label>
            <Input
              id="fw-confirm"
              type="number"
              min={1}
              max={120}
              value={confirmMinutes}
              onChange={(e) => setConfirmMinutes(e.target.value)}
              aria-required="true"
            />
            <p className="text-[11px] text-text-2">Default 10 minuti: conferma obbligatoria dopo l&apos;upgrade (commit-confirm).</p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="fw-schedule" className="text-xs font-medium text-text-2">Schedulazione (opzionale)</label>
            <Input
              id="fw-schedule"
              type="datetime-local"
              value={scheduleRaw}
              onChange={(e) => setScheduleRaw(e.target.value)}
            />
            <p className="text-[11px] text-text-2">Vuoto = appena possibile (ora). Nessuna esecuzione automatica in riproduzione.</p>
          </div>

          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs leading-relaxed text-crit-text">
              {formError}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>Annulla</Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <CalendarClock className="size-3.5" aria-hidden />}
            Schedula upgrade
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * D — Playbook (CRUD; esecuzione = motori attivi)
 * ================================================================ */

function PlaybooksCard() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [editing, setEditing] = useState<PlaybookRow | null>(null)

  const q = useQuery({
    queryKey: ['playbooks'],
    queryFn: () => api.playbooks(),
    staleTime: 15_000,
  })
  const items = q.data?.data.items ?? []
  const total = q.data?.data.total ?? 0

  /* Toggle enabled: PATCH parziale reale (audit PLAYBOOK_UPDATE). */
  const toggle = useMutation({
    mutationFn: (v: { id: string; enabled: boolean }) => api.updatePlaybook(v.id, { enabled: v.enabled }),
    onSuccess: (row) => {
      toast.success(row.enabled ? 'Playbook attivato' : 'Playbook disattivato', {
        description: `«${row.name}» — enabled ${row.enabled} nel DB reale. L'esecuzione resta legata ai motori attivi.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['playbooks'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Modifica non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const del = useMutation({
    mutationFn: (id: string) => api.deletePlaybook(id),
    onSuccess: (_res, id) => {
      const name = items.find((p) => p.id === id)?.name ?? id
      toast.success('Playbook eliminato', {
        description: `«${name}» rimosso dal DB reale (audit PLAYBOOK_DELETE).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['playbooks'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Workflow className="size-4 text-text-2" aria-hidden />
          Playbook
        </CardTitle>
        <CardDescription>
          Sequenze di passi (verifica, comando, ticket, notifica, attesa) su dati reali del DB:
          creazione, modifica completa, attivazione ed eliminazione.
        </CardDescription>
        <CardAction>
          <div className="flex items-center gap-1.5">
            {q.data ? <AsOf ts={q.data.asOf} /> : null}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void q.refetch() }}
              disabled={q.isFetching}
              aria-label="Aggiorna l'elenco dei playbook"
            >
              <RefreshCw className={cn('size-3.5', q.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden />
              Nuovo playbook
            </Button>
          </div>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        <InfoNote>
          L&apos;esecuzione dei playbook richiede i motori attivi: in riproduzione sono modificabili
          ma non eseguibili.
        </InfoNote>

        {q.isPending ? (
          <LoadingRows rows={3} />
        ) : q.isError ? (
          <ErrorPanel
            message={errInfo(q.error).message}
            code={errInfo(q.error).code}
            onRetry={() => { void q.refetch() }}
          />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<Workflow className="size-10" aria-hidden />}
            title={`Nessun playbook nel DB reale (${fmtNumber(total)})`}
            description="Il database dell'impianto non contiene playbook: nessuna riga di esempio viene inventata. Creane uno: i passi usano il vocabolario delle azioni (verifica stato, metrica, comando, ticket, notifica, attesa) e restano modificabili anche in riproduzione."
            action={
              <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                <Plus className="size-3.5" aria-hidden />
                Nuovo playbook
              </Button>
            }
          />
        ) : (
          <div
            className={cn(
              'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
              q.isFetching && 'opacity-70',
            )}
            aria-busy={q.isFetching}
          >
            <TooltipProvider delayDuration={150}>
              <Table>
                <TableCaption className="sr-only">
                  Playbook del DB reale: nome, numero passi, trigger, esecuzioni registrate, stato
                  attivo e azioni di modifica o eliminazione
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="min-w-[210px]">Nome</TableHead>
                    <TableHead scope="col" className="w-[90px] text-center">Passi</TableHead>
                    <TableHead scope="col" className="min-w-[160px]">Trigger</TableHead>
                    <TableHead scope="col" className="w-[110px] text-center">Esecuzioni</TableHead>
                    <TableHead scope="col" className="w-[90px] text-center">Attivo</TableHead>
                    <TableHead scope="col" className="w-[150px]">
                      <span className="sr-only">Azioni</span>
                      Azioni
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((p) => {
                    const busy = (toggle.isPending && toggle.variables?.id === p.id) || (del.isPending && del.variables === p.id)
                    return (
                      <TableRow key={p.id}>
                        <TableCell className="min-w-[210px]">
                          <p className="truncate font-medium" title={p.name}>{p.name}</p>
                          {p.description ? (
                            <p className="mt-0.5 line-clamp-1 max-w-[280px] text-xs text-text-2" title={p.description}>{p.description}</p>
                          ) : null}
                        </TableCell>
                        <TableCell className="w-[90px] text-center num" title={`${p.steps.length} passi (ordine stepOrder)`}>
                          {fmtNumber(p.steps.length)}
                        </TableCell>
                        <TableCell className="min-w-[160px]">
                          {p.triggerRule ? (
                            <span className="truncate font-mono text-xs" title={`Trigger: ${p.triggerRule}`}>{p.triggerRule}</span>
                          ) : (
                            <Badge variant="outline" className="bg-raised text-text-2 border-border" title="Nessuna regola collegata: esecuzione solo manuale (quando i motori saranno attivi)">
                              Manuale
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="w-[110px] text-center">
                          {/* runCount = 0 ONESTO: il tooltip dichiara il perché. */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                type="button"
                                className="num text-sm underline decoration-dotted underline-offset-4"
                                aria-label={`Esecuzioni registrate: ${fmtNumber(p.runCount)} — ${p.runCount === 0 ? 'mai eseguito: motori non attivi in riproduzione' : `ultima ${fmtDateTime(p.lastRunAt)}`}`}
                              >
                                {fmtNumber(p.runCount)}
                              </button>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-64 text-xs leading-relaxed">
                              {p.runCount === 0
                                ? 'mai eseguito: motori non attivi in riproduzione'
                                : `${fmtNumber(p.runCount)} esecuzioni · ultima ${fmtDateTime(p.lastRunAt)}`}
                            </TooltipContent>
                          </Tooltip>
                        </TableCell>
                        <TableCell className="w-[90px] text-center">
                          <Switch
                            checked={p.enabled}
                            onCheckedChange={(v) => toggle.mutate({ id: p.id, enabled: v })}
                            disabled={busy}
                            className="h-5 w-9 cursor-pointer"
                            aria-label={`${p.enabled ? 'Disattiva' : 'Attiva'} il playbook ${p.name}`}
                          />
                        </TableCell>
                        <TableCell className="w-[150px]">
                          <div className="flex items-center gap-1.5">
                            <Button
                              variant="outline" size="sm" className="h-8"
                              onClick={() => setEditing(p)}
                              aria-label={`Modifica il playbook ${p.name}`}
                            >
                              <Pencil className="size-3.5" aria-hidden />
                              Modifica
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="ghost" size="icon" className="size-8 text-crit-text"
                                  disabled={busy}
                                  aria-label={`Elimina il playbook ${p.name}`}
                                >
                                  <Trash2 className="size-3.5" aria-hidden />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Eliminare «{p.name}»?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Il playbook ({fmtNumber(p.steps.length)} passi,{' '}
                                    {fmtNumber(p.runCount)} esecuzioni registrate) sarà rimosso dal DB
                                    reale con voce di audit. L&apos;operazione non è reversibile.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel disabled={del.isPending}>Annulla</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-crit-solid text-white hover:bg-crit-solid/90"
                                    disabled={del.isPending}
                                    onClick={(e) => {
                                      e.preventDefault()
                                      del.mutate(p.id)
                                    }}
                                  >
                                    <Trash2 className="size-3.5" aria-hidden />
                                    Elimina definitivamente
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TooltipProvider>
          </div>
        )}
      </CardContent>

      {createOpen ? (
        <PlaybookFormDialog mode="create" open onOpenChange={(o) => { if (!o) setCreateOpen(false) }} />
      ) : null}
      {editing ? (
        <PlaybookFormDialog mode="edit" row={editing} open onOpenChange={(o) => { if (!o) setEditing(null) }} />
      ) : null}
    </Card>
  )
}

/* ---------------- Dialog creazione/modifica playbook (condiviso) ---------------- */

type StepDraft = { key: string; name: string; action: string; params: string }

function PlaybookFormDialog({
  mode,
  row,
  open,
  onOpenChange,
}: {
  mode: 'create' | 'edit'
  row?: PlaybookRow | null
  open: boolean
  onOpenChange: (o: boolean) => void
}) {
  const queryClient = useQueryClient()

  /* Prefill: create → default onesti; edit → valori REALI della riga
   * (azioni fuori vocabolario conservate col valore raw, mai riscritte). */
  const [name, setName] = useState(row?.name ?? '')
  const [description, setDescription] = useState(row?.description ?? '')
  const [triggerRule, setTriggerRule] = useState(row?.triggerRule ?? '')
  const [enabled, setEnabled] = useState(row?.enabled ?? true)
  const [steps, setSteps] = useState<StepDraft[]>(
    row && row.steps.length > 0
      ? row.steps.map((s) => ({ key: s.id, name: s.name, action: s.action, params: s.params }))
      : [{ key: 'step-1', name: '', action: 'check_status' satisfies PlaybookAction, params: '' }],
  )
  const [formError, setFormError] = useState<string | null>(null)

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createPlaybook>[0]) => api.createPlaybook(input),
    onSuccess: (r) => {
      toast.success('Playbook creato', {
        description: `«${r.name}» — ${fmtNumber(r.steps.length)} passi scritti nel DB reale. Esecuzione non disponibile in riproduzione: runCount resterà 0 finché i motori non saranno attivi.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['playbooks'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Creazione non riuscita', { description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}` })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const update = useMutation({
    mutationFn: (v: { id: string; patch: Parameters<typeof api.updatePlaybook>[1] }) => api.updatePlaybook(v.id, v.patch),
    onSuccess: (r) => {
      toast.success('Playbook aggiornato', {
        description: `«${r.name}» — modifiche salvate nel DB reale (audit PLAYBOOK_UPDATE con diff).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['playbooks'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Aggiornamento non riuscito', { description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}` })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const pending = create.isPending || update.isPending

  const addStep = () => {
    setSteps((prev) => prev.length >= PLAYBOOK_MAX_STEPS ? prev : [
      ...prev,
      { key: `step-${Date.now()}-${prev.length}`, name: '', action: 'check_status', params: '' },
    ])
  }

  const removeStep = (idx: number) => {
    setSteps((prev) => (prev.length <= 1 ? prev : prev.filter((_, i) => i !== idx)))
  }

  const moveStep = (idx: number, dir: -1 | 1) => {
    setSteps((prev) => {
      const j = idx + dir
      if (j < 0 || j >= prev.length) return prev
      const next = [...prev]
      const [moved] = next.splice(idx, 1)
      next.splice(j, 0, moved)
      return next
    })
  }

  const patchStep = (idx: number, patch: Partial<StepDraft>) => {
    setSteps((prev) => prev.map((s, i) => (i === idx ? { ...s, ...patch } : s)))
  }

  const submit = () => {
    setFormError(null)
    if (name.trim().length < 3) { setFormError('Il nome richiede almeno 3 caratteri.'); return }
    if (steps.length === 0) { setFormError('Serve almeno un passo.'); return }
    for (let i = 0; i < steps.length; i++) {
      if (steps[i].name.trim().length === 0) { setFormError(`Il passo ${i + 1} richiede un nome.`); return }
      if (!isPlaybookAction(steps[i].action)) {
        setFormError(`Il passo ${i + 1} usa un'azione fuori vocabolario («${steps[i].action}»): scegline una valida.`)
        return
      }
    }
    const stepInputs = steps.map((s) => ({
      name: s.name.trim(),
      action: s.action as PlaybookAction,
      params: s.params.trim() || undefined,
    }))
    if (mode === 'edit' && row) {
      /* Patch integrale: il server calcola il diff e rifiuta NO_CHANGES
       * se nulla è realmente cambiato (onesto, mai scrittura vuota). */
      update.mutate({
        id: row.id,
        patch: {
          name: name.trim(),
          description: description.trim(),
          triggerRule: triggerRule.trim(),
          enabled,
          steps: stepInputs,
        },
      })
    } else {
      create.mutate({
        name: name.trim(),
        description: description.trim() || undefined,
        triggerRule: triggerRule.trim() || undefined,
        enabled,
        steps: stepInputs,
      })
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!pending || o) onOpenChange(o) }}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === 'edit' ? `Modifica playbook · ${row?.name ?? ''}` : 'Nuovo playbook'}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {mode === 'edit'
              ? 'Le modifiche sostituiscono nome, descrizione, trigger, stato attivo e passi nel DB reale (audit con diff).'
              : 'Crea un playbook REALE nel DB dell\'impianto: sequenza di passi con azioni del vocabolario. In riproduzione resta modificabile ma non eseguibile.'}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <label htmlFor="pb-name" className="text-xs font-medium text-text-2">Nome (min 3 caratteri) *</label>
            <Input
              id="pb-name"
              value={name}
              maxLength={120}
              onChange={(e) => setName(e.target.value)}
              placeholder="es. Radio degradata → verifica e ticket"
              aria-required="true"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="pb-desc" className="text-xs font-medium text-text-2">Descrizione (opzionale)</label>
            <Input
              id="pb-desc"
              value={description}
              maxLength={500}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="es. Quando una radio degrada, raccoglie lo stato, apre il ticket e notifica la NOC"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="pb-trigger" className="text-xs font-medium text-text-2">Trigger (opzionale)</label>
            <Input
              id="pb-trigger"
              value={triggerRule}
              maxLength={200}
              onChange={(e) => setTriggerRule(e.target.value)}
              placeholder="id regola evento o pattern"
            />
            <p className="text-[11px] text-text-2">Vuoto = playbook manuale (nessuna regola collegata).</p>
          </div>

          <div className="flex items-center justify-between rounded-md border border-border bg-raised/40 px-3 py-2">
            <label htmlFor="pb-enabled" className="text-xs font-medium text-text-2">
              Attivo
            </label>
            <Switch
              id="pb-enabled"
              checked={enabled}
              onCheckedChange={setEnabled}
              className="h-5 w-9 cursor-pointer"
            />
          </div>

          {/* Builder dei passi: aggiunta / rimozione / riordino su-giù,
           * min 1 max 30 (contratto). */}
          <div className="grid gap-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-text-2" id="pb-steps-label">
                Passi ({fmtNumber(steps.length)}/{PLAYBOOK_MAX_STEPS}) — minimo 1 *
              </span>
              <Button type="button" variant="outline" size="sm" className="h-8" onClick={addStep} disabled={steps.length >= PLAYBOOK_MAX_STEPS}>
                <Plus className="size-3.5" aria-hidden />
                Aggiungi passo
              </Button>
            </div>
            <ol className="grid gap-2" aria-labelledby="pb-steps-label">
              {steps.map((s, idx) => (
                <li key={s.key} className="grid gap-2 rounded-lg border border-border bg-raised/40 p-2.5">
                  <div className="flex items-center gap-2">
                    <span className="num shrink-0 text-xs text-text-2" aria-hidden>{idx + 1}.</span>
                    <Input
                      value={s.name}
                      maxLength={80}
                      onChange={(e) => patchStep(idx, { name: e.target.value })}
                      placeholder="es. Verifica stato del link radio"
                      aria-label={`Nome del passo ${idx + 1}`}
                    />
                    <div className="flex shrink-0 items-center">
                      <Button
                        type="button" variant="ghost" size="icon" className="size-8"
                        onClick={() => moveStep(idx, -1)} disabled={idx === 0}
                        aria-label={`Sposta il passo ${idx + 1} su`}
                      >
                        <ArrowUp className="size-3.5" aria-hidden />
                      </Button>
                      <Button
                        type="button" variant="ghost" size="icon" className="size-8"
                        onClick={() => moveStep(idx, 1)} disabled={idx === steps.length - 1}
                        aria-label={`Sposta il passo ${idx + 1} giù`}
                      >
                        <ArrowDown className="size-3.5" aria-hidden />
                      </Button>
                      <Button
                        type="button" variant="ghost" size="icon" className="size-8 text-crit-text"
                        onClick={() => removeStep(idx)} disabled={steps.length <= 1}
                        aria-label={`Rimuovi il passo ${idx + 1}`}
                      >
                        <Trash2 className="size-3.5" aria-hidden />
                      </Button>
                    </div>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-[minmax(0,220px)_1fr]">
                    <Select value={s.action} onValueChange={(v) => patchStep(idx, { action: v })}>
                      <SelectTrigger aria-label={`Azione del passo ${idx + 1}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PLAYBOOK_ACTIONS_UI.map((a) => (
                          <SelectItem key={a} value={a}>{PLAYBOOK_ACTION_LABELS[a]}</SelectItem>
                        ))}
                        {/* Azione fuori vocabolario del DB: mostrata col
                         * valore raw (mai riscritta in silenzio). */}
                        {!isPlaybookAction(s.action) ? (
                          <SelectItem value={s.action}>{s.action} (fuori vocabolario)</SelectItem>
                        ) : null}
                      </SelectContent>
                    </Select>
                    <Input
                      value={s.params}
                      maxLength={500}
                      onChange={(e) => patchStep(idx, { params: e.target.value })}
                      placeholder="params (opzionale, testo libero)"
                      aria-label={`Parametri del passo ${idx + 1}`}
                      className="font-mono text-xs"
                    />
                  </div>
                </li>
              ))}
            </ol>
          </div>

          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs leading-relaxed text-crit-text">
              {formError}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>Annulla</Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Workflow className="size-3.5" aria-hidden />}
            {mode === 'edit' ? 'Salva modifiche' : 'Crea playbook'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * E — Automazioni periodiche (CRUD; run = motori attivi)
 * ================================================================ */

function AutomationTasksCard() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [editing, setEditing] = useState<AutomationTaskRow | null>(null)

  const q = useQuery({
    queryKey: ['automation-tasks'],
    queryFn: () => api.automationTasks(),
    staleTime: 15_000,
  })
  const items = q.data?.data.items ?? []
  const total = q.data?.data.total ?? 0

  const toggle = useMutation({
    mutationFn: (v: { id: string; enabled: boolean }) => api.updateAutomationTask(v.id, { enabled: v.enabled }),
    onSuccess: (row) => {
      toast.success(row.enabled ? 'Automazione attivata' : 'Automazione disattivata', {
        description: `«${row.name}» — enabled ${row.enabled} nel DB reale. L'esecuzione periodica resta legata ai motori attivi.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['automation-tasks'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Modifica non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const del = useMutation({
    mutationFn: (id: string) => api.deleteAutomationTask(id),
    onSuccess: (_res, id) => {
      const name = items.find((t) => t.id === id)?.name ?? id
      toast.success('Automazione eliminata', {
        description: `«${name}» rimossa dal DB reale (audit AUTOMATION_TASK_DELETE).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['automation-tasks'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Bot className="size-4 text-text-2" aria-hidden />
          Automazioni
        </CardTitle>
        <CardDescription>
          Task periodici sui dispositivi reali: comandi, intervallo, tetto dispositivi (guardrail)
          e finestra di conferma — creazione, modifica, attivazione, eliminazione.
        </CardDescription>
        <CardAction>
          <div className="flex items-center gap-1.5">
            {q.data ? <AsOf ts={q.data.asOf} /> : null}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void q.refetch() }}
              disabled={q.isFetching}
              aria-label="Aggiorna l'elenco delle automazioni"
            >
              <RefreshCw className={cn('size-3.5', q.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden />
              Nuova automazione
            </Button>
          </div>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        <InfoNote>
          L&apos;esecuzione delle automazioni richiede i motori attivi: in riproduzione sono
          modificabili ma non eseguibili (nessun run periodico).
        </InfoNote>

        {q.isPending ? (
          <LoadingRows rows={3} />
        ) : q.isError ? (
          <ErrorPanel
            message={errInfo(q.error).message}
            code={errInfo(q.error).code}
            onRetry={() => { void q.refetch() }}
          />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<Bot className="size-10" aria-hidden />}
            title={`Nessuna automazione nel DB reale (${fmtNumber(total)})`}
            description="Il database dell'impianto non contiene automazioni: nessuna riga di esempio viene inventata. Ogni automazione futura dichiara intervallo, comandi, tetto dispositivi (guardrail) e finestra di conferma; l'esecuzione periodica richiede i motori attivi."
            action={
              <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                <Plus className="size-3.5" aria-hidden />
                Nuova automazione
              </Button>
            }
          />
        ) : (
          <div
            className={cn(
              'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
              q.isFetching && 'opacity-70',
            )}
            aria-busy={q.isFetching}
          >
            <TooltipProvider delayDuration={150}>
              <Table>
                <TableCaption className="sr-only">
                  Automazioni del DB reale: nome, intervallo, target, tetto dispositivi guardrail,
                  esecuzioni registrate, ultimo errore, stato attivo e azioni
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="min-w-[200px]">Nome</TableHead>
                    <TableHead scope="col" className="w-[110px]">Intervallo</TableHead>
                    <TableHead scope="col" className="w-[90px] text-center">Target</TableHead>
                    <TableHead scope="col" className="w-[90px] text-center">Tetto</TableHead>
                    <TableHead scope="col" className="w-[110px] text-center">Esecuzioni</TableHead>
                    <TableHead scope="col" className="min-w-[160px]">Ultimo errore</TableHead>
                    <TableHead scope="col" className="w-[90px] text-center">Attiva</TableHead>
                    <TableHead scope="col" className="w-[150px]">
                      <span className="sr-only">Azioni</span>
                      Azioni
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((t) => {
                    const busy = (toggle.isPending && toggle.variables?.id === t.id) || (del.isPending && del.variables === t.id)
                    return (
                      <TableRow key={t.id}>
                        <TableCell className="min-w-[200px]">
                          <p className="truncate font-medium" title={t.name}>{t.name}</p>
                          {t.description ? (
                            <p className="mt-0.5 line-clamp-1 max-w-[260px] text-xs text-text-2" title={t.description}>{t.description}</p>
                          ) : null}
                        </TableCell>
                        <TableCell className="w-[110px] text-xs num" title={`intervalSec = ${t.intervalSec}`}>
                          {fmtIntervalSec(t.intervalSec)}
                        </TableCell>
                        <TableCell className="w-[90px] text-center num" title={t.targetCount > 0 ? (t.targetHostnames.join(', ') || `${t.targetCount} target`) : 'nessun target esplicito'}>
                          {fmtNumber(t.targetCount)}
                        </TableCell>
                        <TableCell className="w-[90px] text-center num" title={`Guardrail: l'automazione non supera ${t.guardrailMaxDevices} dispositivi per run`}>
                          {fmtNumber(t.guardrailMaxDevices)}
                        </TableCell>
                        <TableCell className="w-[110px] text-center">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                type="button"
                                className="num text-sm underline decoration-dotted underline-offset-4"
                                aria-label={`Esecuzioni registrate: ${fmtNumber(t.runCount)} — ${t.runCount === 0 ? 'mai eseguito: motori non attivi in riproduzione' : `ultima ${fmtDateTime(t.lastRunAt)}`}`}
                              >
                                {fmtNumber(t.runCount)}
                              </button>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-64 text-xs leading-relaxed">
                              {t.runCount === 0
                                ? 'mai eseguito: motori non attivi in riproduzione'
                                : `${fmtNumber(t.runCount)} esecuzioni · ultima ${fmtDateTime(t.lastRunAt)}`}
                            </TooltipContent>
                          </Tooltip>
                        </TableCell>
                        <TableCell className="min-w-[160px]">
                          {t.lastError ? (
                            <span className="truncate font-mono text-xs text-crit-text" title={t.lastError}>{t.lastError}</span>
                          ) : (
                            <span className="text-xs text-text-2">—</span>
                          )}
                        </TableCell>
                        <TableCell className="w-[90px] text-center">
                          <Switch
                            checked={t.enabled}
                            onCheckedChange={(v) => toggle.mutate({ id: t.id, enabled: v })}
                            disabled={busy}
                            className="h-5 w-9 cursor-pointer"
                            aria-label={`${t.enabled ? 'Disattiva' : 'Attiva'} l'automazione ${t.name}`}
                          />
                        </TableCell>
                        <TableCell className="w-[150px]">
                          <div className="flex items-center gap-1.5">
                            <Button
                              variant="outline" size="sm" className="h-8"
                              onClick={() => setEditing(t)}
                              aria-label={`Modifica l'automazione ${t.name}`}
                            >
                              <Pencil className="size-3.5" aria-hidden />
                              Modifica
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="ghost" size="icon" className="size-8 text-crit-text"
                                  disabled={busy}
                                  aria-label={`Elimina l'automazione ${t.name}`}
                                >
                                  <Trash2 className="size-3.5" aria-hidden />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Eliminare «{t.name}»?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    L&apos;automazione (intervallo {fmtIntervalSec(t.intervalSec)},
                                    tetto {fmtNumber(t.guardrailMaxDevices)} dispositivi,{' '}
                                    {fmtNumber(t.runCount)} esecuzioni registrate) sarà rimossa dal
                                    DB reale con voce di audit. L&apos;operazione non è reversibile.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel disabled={del.isPending}>Annulla</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-crit-solid text-white hover:bg-crit-solid/90"
                                    disabled={del.isPending}
                                    onClick={(e) => {
                                      e.preventDefault()
                                      del.mutate(t.id)
                                    }}
                                  >
                                    <Trash2 className="size-3.5" aria-hidden />
                                    Elimina definitivamente
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TooltipProvider>
          </div>
        )}
      </CardContent>

      {createOpen ? (
        <AutomationFormDialog mode="create" open onOpenChange={(o) => { if (!o) setCreateOpen(false) }} />
      ) : null}
      {editing ? (
        <AutomationFormDialog mode="edit" row={editing} open onOpenChange={(o) => { if (!o) setEditing(null) }} />
      ) : null}
    </Card>
  )
}

/* ---------------- Dialog creazione/modifica automazione (condiviso) ---------------- */

function AutomationFormDialog({
  mode,
  row,
  open,
  onOpenChange,
}: {
  mode: 'create' | 'edit'
  row?: AutomationTaskRow | null
  open: boolean
  onOpenChange: (o: boolean) => void
}) {
  const queryClient = useQueryClient()
  const devices = useDevices50()
  const deviceItems = devices.data?.data.items ?? []

  /* Prefill: create → default onesti del backend (3600 s / 10 min /
   * tetto 10 / attiva); edit → valori REALI della riga. */
  const [name, setName] = useState(row?.name ?? '')
  const [description, setDescription] = useState(row?.description ?? '')
  const [commandsRaw, setCommandsRaw] = useState(row ? row.commands.join('\n') : '')
  const [intervalRaw, setIntervalRaw] = useState(String(row?.intervalSec ?? 3600))
  const [confirmRaw, setConfirmRaw] = useState(String(row?.confirmMinutes ?? 10))
  const [capRaw, setCapRaw] = useState(String(row?.guardrailMaxDevices ?? 10))
  const [enabled, setEnabled] = useState(row?.enabled ?? true)
  const [picked, setPicked] = useState<string[]>([])
  const [formError, setFormError] = useState<string | null>(null)

  const togglePicked = (id: string) => {
    setPicked((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createAutomationTask>[0]) => api.createAutomationTask(input),
    onSuccess: (r) => {
      toast.success('Automazione creata', {
        description: `«${r.name}» — intervallo ${fmtIntervalSec(r.intervalSec)}, tetto ${fmtNumber(r.guardrailMaxDevices)} dispositivi. Esecuzione non disponibile in riproduzione: runCount resterà 0 finché i motori non saranno attivi.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['automation-tasks'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error(info.code === 'FORBIDDEN_COMMAND' ? 'Comando vietato dal guardrail' : 'Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const update = useMutation({
    mutationFn: (v: { id: string; patch: Parameters<typeof api.updateAutomationTask>[1] }) => api.updateAutomationTask(v.id, v.patch),
    onSuccess: (r) => {
      toast.success('Automazione aggiornata', {
        description: `«${r.name}» — modifiche salvate nel DB reale (audit AUTOMATION_TASK_UPDATE).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['automation-tasks'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Aggiornamento non riuscito', { description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}` })
      setFormError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const pending = create.isPending || update.isPending

  const submit = () => {
    setFormError(null)
    if (name.trim().length < 3) { setFormError('Il nome richiede almeno 3 caratteri.'); return }
    const commands = parseLines(commandsRaw)
    if (commands.length === 0) { setFormError('Inserisci almeno un comando (uno per riga).'); return }
    const iv = parseIntField(intervalRaw)
    if (iv == null || iv < 60 || iv > 86400) { setFormError('L\'intervallo deve essere un numero intero fra 60 e 86400 secondi.'); return }
    const cm = parseIntField(confirmRaw)
    if (cm == null || cm < 0 || cm > 120) { setFormError('La finestra di conferma deve essere un numero intero fra 0 e 120 minuti.'); return }
    const cap = parseIntField(capRaw)
    if (cap == null || cap < 1 || cap > 50) { setFormError('Il tetto dispositivi deve essere un numero intero fra 1 e 50.'); return }

    if (mode === 'edit' && row) {
      /* Patch integrale; i target vengono SOSTITUITI solo se la lista è
       * stata riempita (l'elenco attuale non è ricostruibile dagli id:
       * la riga espone solo i primi 20 hostname — scelta onesta). */
      const patch: Parameters<typeof api.updateAutomationTask>[1] = {
        name: name.trim(),
        description: description.trim(),
        commands,
        intervalSec: iv,
        confirmMinutes: cm,
        guardrailMaxDevices: cap,
        enabled,
      }
      if (picked.length > 0) patch.deviceIds = picked
      update.mutate({ id: row.id, patch })
    } else {
      create.mutate({
        name: name.trim(),
        description: description.trim() || undefined,
        commands,
        ...(picked.length > 0 ? { deviceIds: picked } : {}),
        intervalSec: iv,
        confirmMinutes: cm,
        guardrailMaxDevices: cap,
        enabled,
      })
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!pending || o) onOpenChange(o) }}>
      <DialogContent className="max-h-[85vh] overflow-y-auto scroll-thin sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{mode === 'edit' ? `Modifica automazione · ${row?.name ?? ''}` : 'Nuova automazione'}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {mode === 'edit'
              ? 'Le modifiche sostituiscono nome, descrizione, comandi, intervallo, tetto e stato attivo nel DB reale (audit con diff).'
              : 'Crea un task periodico REALE nel DB dell\'impianto: comandi con guardrail, tetto dispositivi e finestra di conferma. In riproduzione resta modificabile ma non eseguibile.'}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <label htmlFor="at-name" className="text-xs font-medium text-text-2">Nome (min 3 caratteri) *</label>
            <Input
              id="at-name"
              value={name}
              maxLength={120}
              onChange={(e) => setName(e.target.value)}
              placeholder="es. Backup configurazioni switch settimanale"
              aria-required="true"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="at-desc" className="text-xs font-medium text-text-2">Descrizione (opzionale)</label>
            <Input
              id="at-desc"
              value={description}
              maxLength={500}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="es. Salva la running-config degli switch e registra l'esito"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="at-commands" className="text-xs font-medium text-text-2">Comandi (uno per riga, min 1) *</label>
            <Textarea
              id="at-commands"
              value={commandsRaw}
              onChange={(e) => setCommandsRaw(e.target.value)}
              placeholder={'es.\ncopy running-config tftp://10.0.0.9/backups'}
              className="min-h-24 font-mono text-xs"
              aria-required="true"
            />
            <p className="text-[11px] text-text-2">Il guardrail rifiuta i comandi distruttivi alla creazione.</p>
          </div>

          {/* Target opzionali: lista check scrollabile (max-h-64). In
           * modifica la lista vuota MANTIENE i target attuali. */}
          <div className="grid gap-1.5">
            <span className="text-xs font-medium text-text-2" id="at-targets-label">
              Target (opzionali){picked.length > 0 ? ` — ${fmtNumber(picked.length)} selezionati` : ''}
            </span>
            {mode === 'edit' && row ? (
              <p className="rounded-md border border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2">
                Target attuali: <strong className="num">{fmtNumber(row.targetCount)}</strong>
                {row.targetHostnames.length > 0
                  ? ` · ${row.targetHostnames.slice(0, 5).join(', ')}${row.targetCount > 5 ? ` … (primi 5 di ${fmtNumber(row.targetCount)})` : ''}`
                  : ''}
                . Lascia la lista vuota per mantenerli; selezionare dei dispositivi li sostituisce.
              </p>
            ) : null}
            <div
              className="max-h-64 overflow-y-auto scroll-thin rounded-md border border-border p-2"
              role="group"
              aria-labelledby="at-targets-label"
              aria-label="Target dell'automazione (primi 50 dispositivi reali)"
            >
              {devices.isPending ? (
                <div className="flex items-center justify-center gap-2 px-3 py-6 text-xs text-text-2">
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                  caricamento inventario…
                </div>
              ) : devices.isError ? (
                <div className="px-3 py-6 text-center text-xs text-crit">
                  Inventario non raggiungibile: {errInfo(devices.error).message}
                </div>
              ) : deviceItems.length === 0 ? (
                <p className="px-3 py-6 text-center text-xs text-text-2">Nessun dispositivo nell&apos;inventario.</p>
              ) : (
                deviceItems.map((d) => (
                  <label
                    key={d.id}
                    className="flex cursor-pointer items-center gap-2 rounded-sm px-1.5 py-1.5 text-xs hover:bg-raised/60"
                  >
                    <Checkbox
                      checked={picked.includes(d.id)}
                      onCheckedChange={() => togglePicked(d.id)}
                      aria-label={`Includi ${d.hostname} nei target`}
                    />
                    <span className="min-w-0 flex-1 truncate" title={d.hostname}>{d.hostname}</span>
                    <span className="shrink-0 text-text-2">
                      {typeLabel(d.type)} · <span className="num">{d.ip}</span>
                    </span>
                  </label>
                ))
              )}
            </div>
            <p className="text-[11px] text-text-2">
              Vuoto = nessun target esplicito (l&apos;automazione definisce comunque comandi e cadenza).
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="grid gap-1.5">
              <label htmlFor="at-interval" className="text-xs font-medium text-text-2">Intervallo (s) *</label>
              <Input
                id="at-interval"
                type="number"
                min={60}
                max={86400}
                value={intervalRaw}
                onChange={(e) => setIntervalRaw(e.target.value)}
                aria-required="true"
              />
              <p className="text-[11px] text-text-2">60 s – 86400 s (24 h).</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="at-confirm" className="text-xs font-medium text-text-2">Conferma (min) *</label>
              <Input
                id="at-confirm"
                type="number"
                min={0}
                max={120}
                value={confirmRaw}
                onChange={(e) => setConfirmRaw(e.target.value)}
                aria-required="true"
              />
              <p className="text-[11px] text-text-2">Default 10.</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="at-cap" className="text-xs font-medium text-text-2">Tetto dispositivi *</label>
              <Input
                id="at-cap"
                type="number"
                min={1}
                max={50}
                value={capRaw}
                onChange={(e) => setCapRaw(e.target.value)}
                aria-required="true"
              />
              <p className="text-[11px] text-text-2">Guardrail: default 10, max 50.</p>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-md border border-border bg-raised/40 px-3 py-2">
            <label htmlFor="at-enabled" className="text-xs font-medium text-text-2">
              Attiva
            </label>
            <Switch
              id="at-enabled"
              checked={enabled}
              onCheckedChange={setEnabled}
              className="h-5 w-9 cursor-pointer"
            />
          </div>

          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs leading-relaxed text-crit-text">
              {formError}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={pending}>Annulla</Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Bot className="size-3.5" aria-hidden />}
            {mode === 'edit' ? 'Salva modifiche' : 'Crea automazione'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * F — Terminale SSH: verifica ONESTA della porta 22 (mai emulato)
 * ================================================================ */

function TerminalCard() {
  const devices = useDevices50()
  const deviceItems = devices.data?.data.items ?? []
  const [deviceId, setDeviceId] = useState('')
  const [result, setResult] = useState<TerminalProbeResult | null>(null)

  /* Sonda TCP porta 22: risultato REALE del tentativo (audit
   * TERMINAL_PROBE). Nessuna sessione fittizia, mai. */
  const probe = useMutation({
    mutationFn: (id: string) => api.terminalProbe(id),
    onSuccess: (r) => {
      setResult(r)
      toast.info('Verifica completata', {
        description: `${r.hostname} (${r.ip ?? 'IP n.d.'}): ${r.detail}`,
      })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Sonda non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <SquareTerminal className="size-4 text-text-2" aria-hidden />
          Terminale SSH
        </CardTitle>
        <CardDescription>
          Verifica di raggiungibilità della porta 22 sui dispositivi reali (sonda TCP del motore
          discovery): nessun terminale emulato, nessuna sessione fittizia.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <InfoNote>
          Il terminale interattivo non viene MAI emulato: in modalità riproduzione non si aprono
          sessioni fittizie e nessun comando viene inviato ai dispositivi.
        </InfoNote>

        <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
          <DeviceSelectField
            id="term-device"
            value={deviceId}
            onChange={setDeviceId}
            items={deviceItems}
            isPending={devices.isPending}
            isError={devices.isError}
            total={devices.data?.data.total}
          />
          <Button
            className="h-11 sm:h-9"
            disabled={!deviceId || probe.isPending}
            onClick={() => {
              setResult(null)
              probe.mutate(deviceId)
            }}
          >
            {probe.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <ScanSearch className="size-3.5" aria-hidden />}
            Verifica raggiungibilità porta 22
          </Button>
        </div>

        {probe.isPending ? (
          <div className="flex items-center gap-2 rounded-md border border-border bg-raised/40 px-3 py-3 text-xs text-text-2" role="status">
            <Loader2 className="size-4 animate-spin" aria-hidden />
            Tentativo TCP sulla porta 22 di {deviceItems.find((d) => d.id === deviceId)?.hostname ?? deviceId}…
          </div>
        ) : result ? (
          <div className="grid gap-2.5 rounded-md border border-border bg-raised/40 p-3" role="status">
            <div className="flex flex-wrap items-center gap-1.5">
              <p className="mr-1 text-xs font-medium text-text-2">
                {result.hostname}
                {result.ip ? <span className="num"> ({result.ip})</span> : null}:
              </p>
              {result.sshPortOpen ? (
                <VocabBadge label="Porta 22 aperta" cls="bg-ok-soft text-ok border-ok/40" Icon={CircleCheck} />
              ) : (
                <VocabBadge label="Porta 22 chiusa" cls="bg-crit-soft text-crit-text border-crit/40" Icon={CircleX} />
              )}
              <Badge variant="outline" className="bg-raised text-text-2 border-border" title="reachable dal risultato reale della scansione TCP">
                {result.reachable ? 'raggiungibile' : 'non raggiungibile'}
              </Badge>
              <Badge variant="outline" className="bg-raised text-text-2 border-border num" title="Latenza del tentativo TCP (nulla se l'host non ha risposto: non misurabile)">
                {result.latencyMs != null ? `${fmtNumber(result.latencyMs)} ms` : 'latenza non misurabile'}
              </Badge>
            </div>
            {/* Dettaglio ONESTO del backend: es. host non raggiungibile
             * sulla porta 22 (rete dimostrativa non instradata). */}
            <p className="break-words font-mono text-xs leading-relaxed text-text" title={result.detail}>
              {result.detail}
            </p>
            {result.sessionOpened ? (
              <p className="text-xs text-ok">Sessione SSH aperta.</p>
            ) : (
              <p className="text-xs leading-relaxed text-warn" role="note">
                Sessione SSH non aperta in modalità riproduzione: nessuna sessione fittizia registrata.
              </p>
            )}
          </div>
        ) : (
          <p className="rounded-md border border-dashed border-border px-3 py-3 text-xs text-text-2">
            Nessuna verifica eseguita: scegli un dispositivo e lancia la sonda (l&apos;esito del
            tentativo viene registrato nell&apos;audit).
          </p>
        )}
      </CardContent>
    </Card>
  )
}
