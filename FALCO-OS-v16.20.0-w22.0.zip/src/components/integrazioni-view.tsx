/* ================================================================
 * FALCO-OS v16 — Sezione «Integrazioni» (16.7 ondata W7)
 * Tab 2 della vista Amministrazione: (A) configurazioni dei servizi
 * esterni con valori segreti cifrati AES-256-GCM a riposo e mai
 * restituiti in chiaro dal server, (B) test di connessione REALI
 * (http/tcp/telegram — l'esito, anche l'errore, è il valore vero
 * della rete: nessun test simulato), (C) webhook con firma
 * HMAC-SHA256, consegna di test verificata end-to-end e segreto
 * HMAC mostrato UNA sola volta alla creazione.
 * Onestà: tabelle vuote = empty state dichiarati, mai righe finte.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Cable, Copy, FlaskConical, Globe, History, Loader2, LockKeyhole,
  PlugZap, Plus, Puzzle, RefreshCw, Send, ShieldCheck, Trash2, Webhook,
} from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { api, ApiError } from '@/lib/client/api'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtRelative } from '@/lib/client/format'
import type {
  CreateWebhookInput, IntegrationConfigRow, IntegrationTestResult,
  WebhookEndpointRow, WebhookTestResult,
} from '@/lib/v2/contracts'
import { cn } from '@/lib/utils'

/* ---------------- Costanti sezione ---------------- */

/* Categorie del vocabolario backend (INTEGRATION_CATEGORIES dei
 * contratti, ollama incluso: la Select offre TUTTE le categorie
 * accettate dal server, nessuna esclusa) */
const CATEGORY_OPTIONS: ReadonlyArray<{ value: string; label: string }> = [
  { value: 'telegram', label: 'Telegram' },
  { value: 'osticket', label: 'osTicket' },
  { value: 'email', label: 'Email / SMTP' },
  { value: 'grafana', label: 'Grafana' },
  { value: 'checkmk', label: 'CheckMK' },
  { value: 'cnmaestro', label: 'CNMaestro' },
  { value: 'unifi', label: 'UniFi' },
  { value: 'splashtop', label: 'Splashtop' },
  { value: 'ldap', label: 'LDAP' },
  { value: 'prometheus', label: 'Prometheus' },
  { value: 'ollama', label: 'Ollama (LLM locale)' },
  { value: 'backup', label: 'Backup' },
  { value: 'general', label: 'Generale' },
]

/* Stati consegna webhook (vocabolario del DB; valori ignoti mostrati raw) */
const DELIVERY_STATUS_META: Record<string, { label: string; cls: string }> = {
  DELIVERED: { label: 'Consegnata', cls: 'border-ok/40 bg-ok-soft text-ok' },
  DEAD: { label: 'Dead (scartata)', cls: 'border-crit/40 bg-crit-soft text-crit-text' },
  PENDING: { label: 'In attesa', cls: 'border-warn/40 bg-warn-soft text-warn' },
  RETRYING: { label: 'In retry', cls: 'border-warn/40 bg-warn-soft text-warn' },
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* Copia negli appunti con esito onesto (toast di successo o errore) */
async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text)
    toast.success('Copiato negli appunti')
  } catch {
    toast.error('Copia non riuscita', {
      description: 'Il browser ha negato l\'accesso agli appunti: copiare manualmente dal riquadro.',
    })
  }
}

/* ================================================================
 * Sezione Integrazioni (tab 2 Amministrazione)
 * ================================================================ */

export default function IntegrazioniSection() {
  return (
    <div className="grid min-w-0 grid-cols-1 gap-4 lg:grid-cols-2">
      <ConfigsCard />
      <ConnectionTestCard />
      <WebhooksCard />
    </div>
  )
}

/* ================================================================
 * A — Configurazioni integrazione (upsert per chiave, AES-256-GCM)
 * ================================================================ */

function ConfigsCard() {
  const queryClient = useQueryClient()
  const integrations = useQuery({
    queryKey: ['integrations'],
    queryFn: () => api.integrations(),
    staleTime: 30_000,
  })

  const configs = integrations.data?.data.configs ?? []
  const totalConfigs = integrations.data?.data.totalConfigs ?? 0

  /* Form di configurazione (upsert: stessa chiave = sovrascrittura) */
  const [category, setCategory] = useState('telegram')
  const [key, setKey] = useState('')
  const [value, setValue] = useState('')
  const [isSecret, setIsSecret] = useState(true)
  const [note, setNote] = useState('')
  /* Chiave in modifica dopo «Riempi» (il valore segreto NON viene
   * mai restituito dal server: il campo valore riparte vuoto) */
  const [editingKey, setEditingKey] = useState<string | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<IntegrationConfigRow | null>(null)

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['integrations'] })
  }

  const resetForm = () => {
    setCategory('telegram')
    setKey('')
    setValue('')
    setIsSecret(true)
    setNote('')
    setEditingKey(null)
  }

  const upsert = useMutation({
    mutationFn: (input: { key: string; category: string; value: string; isSecret?: boolean; note?: string }) =>
      api.upsertIntegration(input),
    onSuccess: (_res, vars) => {
      toast.success(editingKey ? 'Configurazione aggiornata' : 'Configurazione salvata', {
        description: vars.isSecret
          ? `«${vars.key}»: valore cifrato AES-256-GCM a riposo, mai restituito in chiaro dal server (mostrato come ***).`
          : `«${vars.key}» salvata nel DB reale.`,
      })
      resetForm()
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Salvataggio non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteIntegration(id),
    onSuccess: (_res, id) => {
      /* Se la riga eliminata era in modifica, azzera il form */
      if (deleteTarget?.id === id) resetForm()
      setDeleteTarget(null)
      toast.success('Configurazione eliminata', {
        description: 'Cancellazione REALE dal DB (nessuna riga finta lasciata in tabella).',
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submit = () => {
    const k = key.trim()
    if (!k || !value.trim() || upsert.isPending) return
    upsert.mutate({ key: k, category, value, isSecret, note: note.trim() || undefined })
  }

  /* «Riempi»: precompila il form con la riga per modificarla (upsert).
   * Il valore segreto resta vuoto: il server lo maschera con ***. */
  const fill = (row: IntegrationConfigRow) => {
    setCategory(row.category)
    setKey(row.key)
    setValue(row.isSecret ? '' : row.value)
    setIsSecret(row.isSecret)
    setNote(row.note)
    setEditingKey(row.key)
  }

  return (
    <Card className="min-w-0 border-border/70 bg-surface lg:col-span-2">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <Puzzle className="size-4 text-text-2" aria-hidden />
          Configurazioni integrazione
          {integrations.data ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              {fmtNumber(totalConfigs)} totali
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Token, host e credenziali dei servizi esterni: salvataggio upsert per chiave
          (categoria + chiave); i valori segreti vengono cifrati AES-256-GCM a riposo e
          non lasciano mai il server in chiaro.
        </CardDescription>
        <CardAction>
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            onClick={() => { void integrations.refetch() }}
            disabled={integrations.isFetching}
            aria-label="Aggiorna le configurazioni integrazione"
          >
            <RefreshCw className={cn('size-3.5', integrations.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {integrations.isPending ? (
          <LoadingRows rows={4} />
        ) : integrations.isError ? (
          <ErrorPanel
            message={errInfo(integrations.error).message}
            code={errInfo(integrations.error).code}
            onRetry={() => { void integrations.refetch() }}
          />
        ) : (
          <>
            {/* --- Form di configurazione (upsert) --- */}
            <form
              className="grid gap-3 rounded-lg border border-border/70 bg-raised/30 p-3"
              onSubmit={(e) => { e.preventDefault(); submit() }}
              noValidate
              aria-label="Form di configurazione integrazione"
            >
              {editingKey && isSecret ? (
                <p className="text-xs text-warn" role="note">
                  Stai modificando «{editingKey}»: il valore segreto non viene mai restituito
                  dal server (mascherato ***) — reinseriscilo per confermarlo o cambiarlo.
                </p>
              ) : null}
              <div className="grid gap-3 md:grid-cols-2">
                <div className="grid gap-1.5">
                  <label htmlFor="int-category" className="text-xs font-medium text-text-2">Categoria</label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="int-category" className="w-full" aria-label="Categoria del servizio">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORY_OPTIONS.map((c) => (
                        <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <label htmlFor="int-key" className="text-xs font-medium text-text-2">
                    Chiave <span className="text-text-2">(es. telegram.botToken)</span>
                  </label>
                  <Input
                    id="int-key"
                    value={key}
                    maxLength={120}
                    onChange={(e) => setKey(e.target.value)}
                    placeholder="es. telegram.botToken"
                    className="font-mono text-xs"
                    aria-required="true"
                  />
                </div>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <div className="grid gap-1.5">
                  <label htmlFor="int-value" className="text-xs font-medium text-text-2">Valore</label>
                  <Input
                    id="int-value"
                    type={isSecret ? 'password' : 'text'}
                    value={value}
                    maxLength={2000}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder={isSecret ? 'il valore è cifrato a riposo, mostrato come ***' : 'es. 10.0.10.25'}
                    aria-required="true"
                    autoComplete="off"
                  />
                </div>
                <div className="grid gap-1.5">
                  <label htmlFor="int-note" className="text-xs font-medium text-text-2">Nota (opzionale)</label>
                  <Input
                    id="int-note"
                    value={note}
                    maxLength={300}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="es. bot allarmi impianto Nord"
                  />
                </div>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Switch
                    id="int-secret"
                    checked={isSecret}
                    onCheckedChange={setIsSecret}
                    aria-label="Tratta il valore come segreto (cifrato a riposo)"
                  />
                  <label htmlFor="int-secret" className="text-xs text-text-2">
                    Valore segreto (cifrato AES-256-GCM a riposo, restituito come ***)
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  {editingKey ? (
                    <Button type="button" variant="ghost" size="sm" className="h-9" onClick={resetForm}>
                      Annulla modifica
                    </Button>
                  ) : null}
                  <Button type="submit" size="sm" className="h-9" disabled={upsert.isPending || !key.trim() || !value.trim()}>
                    {upsert.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                    Salva
                  </Button>
                </div>
              </div>
            </form>

            {/* --- Tabella configs esistenti (dati REALI del DB) --- */}
            {configs.length === 0 ? (
              <EmptyState
                icon={<Puzzle className="size-10" aria-hidden />}
                title="Nessuna integrazione configurata"
                description="I valori vengono cifrati AES-256-GCM a riposo e non lasciano mai il server in chiaro: configura qui token, host e credenziali dei servizi esterni con il form sopra."
              />
            ) : (
              <div className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70" role="region" aria-label="Configurazioni integrazione configurate, scorribile" tabIndex={0}>
                <Table>
                  <TableCaption className="sr-only">
                    Configurazioni integrazione: chiave, categoria, valore (segreto mascherato), nota, ultimo aggiornamento e azioni
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col" className="w-[220px]">Chiave</TableHead>
                      <TableHead scope="col" className="w-[110px]">Categoria</TableHead>
                      <TableHead scope="col">Valore</TableHead>
                      <TableHead scope="col" className="w-[70px]">Segreto</TableHead>
                      <TableHead scope="col">Nota</TableHead>
                      <TableHead scope="col" className="w-[110px]">Aggiornata</TableHead>
                      <TableHead scope="col" className="w-[130px] text-right">Azioni</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {configs.map((row) => (
                      <TableRow key={row.id}>
                        <TableCell>
                          <span className="block max-w-[210px] break-all font-mono text-xs" title={row.key}>{row.key}</span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2" title={row.category}>
                            {row.category}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {row.isSecret ? (
                            <span className="font-mono text-xs text-text-2" title="valore cifrato a riposo: mai restituito in chiaro">***</span>
                          ) : (
                            <span className="block max-w-[220px] truncate font-mono text-xs" title={row.value}>{row.value || '—'}</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {row.isSecret ? (
                            <span title="valore segreto cifrato a riposo" className="inline-flex">
                              <LockKeyhole className="size-3.5 text-text-2" aria-hidden />
                            </span>
                          ) : (
                            <span className="text-xs text-text-2">—</span>
                          )}
                          <span className="sr-only">{row.isSecret ? 'segreto' : 'in chiaro'}</span>
                        </TableCell>
                        <TableCell>
                          <span className="block max-w-[200px] truncate text-xs text-text-2" title={row.note || undefined}>
                            {row.note || '—'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span
                            className="num text-xs"
                            title={`da ${row.updatedBy || 'n.d.'} · ${fmtDateTimeFull(row.updatedAt)}`}
                          >
                            {fmtRelative(row.updatedAt)}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8"
                              onClick={() => fill(row)}
                              aria-label={`Riempi il form con ${row.key} per modificarla`}
                              title="Precompila il form qui sopra per modificarla (upsert)"
                            >
                              Riempi
                            </Button>
                            <AlertDialog open={deleteTarget?.id === row.id} onOpenChange={(o) => { if (!o) setDeleteTarget(null) }}>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-8 text-crit-text hover:text-crit-text"
                                  onClick={() => setDeleteTarget(row)}
                                  aria-label={`Elimina la configurazione ${row.key}`}
                                >
                                  <Trash2 className="size-3.5" aria-hidden />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Eliminare «{deleteTarget?.key}»?</AlertDialogTitle>
                                  <AlertDialogDescription className="text-left leading-relaxed">
                                    Cancellazione REALE dal DB: la configurazione non verrà più usata dai
                                    servizi. L&apos;azione è registrata nell&apos;audit.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
                                  <AlertDialogAction
                                    disabled={remove.isPending}
                                    onClick={(e) => {
                                      e.preventDefault() // resta aperto finché la risposta reale non arriva
                                      if (!deleteTarget || remove.isPending) return
                                      remove.mutate(deleteTarget.id)
                                    }}
                                  >
                                    {remove.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                                    Elimina
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
            {integrations.data ? <AsOf ts={integrations.data.asOf} prefix="configurazioni alle" className="mt-3" /> : null}
          </>
        )}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * B — Test di connessione (tentativi REALI: esiti onesti)
 * ================================================================ */

function ConnectionTestCard() {
  /* Tre mini-form indipendenti, ciascuno col proprio esito */
  const [httpUrl, setHttpUrl] = useState('')
  const [tcpHost, setTcpHost] = useState('')
  const [tcpPort, setTcpPort] = useState('')
  const [tgToken, setTgToken] = useState('')
  const [results, setResults] = useState<Partial<Record<'http' | 'tcp' | 'telegram', IntegrationTestResult>>>({})

  const setKindResult = (kind: 'http' | 'tcp' | 'telegram', r: IntegrationTestResult) => {
    setResults((prev) => ({ ...prev, [kind]: r }))
  }

  const runHttp = useMutation({
    mutationFn: (url: string) => api.testIntegration({ kind: 'http', url }),
    onSuccess: (r) => setKindResult('http', r),
    onError: (e) => {
      toast.error('Test HTTP non riuscito', { description: errInfo(e).message })
    },
  })

  const runTcp = useMutation({
    mutationFn: (input: { host: string; port: number }) => api.testIntegration({ kind: 'tcp', host: input.host, port: input.port }),
    onSuccess: (r) => setKindResult('tcp', r),
    onError: (e) => {
      toast.error('Test TCP non riuscito', { description: errInfo(e).message })
    },
  })

  const runTelegram = useMutation({
    mutationFn: (token: string) => api.testIntegration({ kind: 'telegram', token }),
    onSuccess: (r) => setKindResult('telegram', r),
    onError: (e) => {
      toast.error('Test Telegram non riuscito', { description: errInfo(e).message })
    },
  })

  /* Validazione leggera client (autorità finale: contratti backend) */
  const httpValid = /^https?:\/\//.test(httpUrl.trim())
  const tcpPortNum = Number.parseInt(tcpPort, 10)
  const tcpValid = tcpHost.trim().length > 0 && Number.isInteger(tcpPortNum) && tcpPortNum >= 1 && tcpPortNum <= 65535
  const tgValid = tgToken.trim().length > 10

  return (
    <Card className="min-w-0 border-border/70 bg-surface lg:col-span-2">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <PlugZap className="size-4 text-text-2" aria-hidden />
          Test di connessione
        </CardTitle>
        <CardDescription>
          Tentativi reali eseguiti dal server (DNS/rete/risposta del servizio): l&apos;esito —
          incluso l&apos;errore — è il valore vero del test, non una simulazione.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-3">
          {/* --- ① HTTP --- */}
          <form
            className="grid content-start gap-2"
            onSubmit={(e) => { e.preventDefault(); if (httpValid) runHttp.mutate(httpUrl.trim()) }}
            noValidate
            aria-label="Test di connessione HTTP"
          >
            <label htmlFor="test-http-url" className="flex items-center gap-1.5 text-xs font-medium text-text-2">
              <Globe className="size-3.5" aria-hidden /> HTTP
            </label>
            <Input
              id="test-http-url"
              value={httpUrl}
              maxLength={500}
              onChange={(e) => setHttpUrl(e.target.value)}
              placeholder="https://example.com/health"
              className="h-9 font-mono text-xs"
            />
            <Button type="submit" variant="outline" size="sm" className="h-9" disabled={runHttp.isPending || !httpValid}>
              {runHttp.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FlaskConical className="size-3.5" aria-hidden />}
              Test
            </Button>
            {results.http ? <TestOutcome r={results.http} /> : null}
          </form>

          {/* --- ② TCP --- */}
          <form
            className="grid content-start gap-2"
            onSubmit={(e) => {
              e.preventDefault()
              if (tcpValid) runTcp.mutate({ host: tcpHost.trim(), port: tcpPortNum })
            }}
            noValidate
            aria-label="Test di connessione TCP"
          >
            <label htmlFor="test-tcp-host" className="flex items-center gap-1.5 text-xs font-medium text-text-2">
              <Cable className="size-3.5" aria-hidden /> TCP
            </label>
            <div className="grid grid-cols-[1fr_88px] gap-2">
              <Input
                id="test-tcp-host"
                value={tcpHost}
                maxLength={200}
                onChange={(e) => setTcpHost(e.target.value)}
                placeholder="host o IP"
                className="h-9 font-mono text-xs"
              />
              <Input
                id="test-tcp-port"
                type="number"
                inputMode="numeric"
                min={1}
                max={65535}
                value={tcpPort}
                onChange={(e) => setTcpPort(e.target.value)}
                placeholder="porta"
                className="h-9 num"
                aria-label="Porta TCP"
              />
            </div>
            <Button type="submit" variant="outline" size="sm" className="h-9" disabled={runTcp.isPending || !tcpValid}>
              {runTcp.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FlaskConical className="size-3.5" aria-hidden />}
              Test
            </Button>
            {results.tcp ? <TestOutcome r={results.tcp} /> : null}
          </form>

          {/* --- ③ Telegram --- */}
          <form
            className="grid content-start gap-2"
            onSubmit={(e) => { e.preventDefault(); if (tgValid) runTelegram.mutate(tgToken.trim()) }}
            noValidate
            aria-label="Test di connessione Telegram"
          >
            <label htmlFor="test-tg-token" className="flex items-center gap-1.5 text-xs font-medium text-text-2">
              <Send className="size-3.5" aria-hidden /> Telegram
            </label>
            <Input
              id="test-tg-token"
              type="password"
              value={tgToken}
              maxLength={200}
              onChange={(e) => setTgToken(e.target.value)}
              placeholder="token del bot (non viene salvato)"
              className="h-9 font-mono text-xs"
              autoComplete="off"
            />
            <Button type="submit" variant="outline" size="sm" className="h-9" disabled={runTelegram.isPending || !tgValid}>
              {runTelegram.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FlaskConical className="size-3.5" aria-hidden />}
              Test
            </Button>
            {results.telegram ? <TestOutcome r={results.telegram} /> : null}
          </form>
        </div>

        {/* Nota di onestà: la rete decide, nessun esito simulato */}
        <p className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2">
          In ambiente dimostrativo i servizi esterni rispondono ai tentativi reali (DNS/rete):
          gli esiti riflettono la verità della rete — ad esempio Telegram risponde 401 a un
          token non valido — nessun test simulato. Il token Telegram immesso qui non viene
          salvato: serve solo al test.
        </p>
      </CardContent>
    </Card>
  )
}

/* Pannello esito di un test di connessione (valori REALI della risposta) */
function TestOutcome({ r }: { r: IntegrationTestResult }) {
  return (
    <div className="rounded-md border border-border/70 bg-raised/40 px-3 py-2.5 text-xs" role="status" aria-live="polite">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
        {r.reachable ? (
          <Badge variant="outline" className="border-ok/40 bg-ok-soft font-medium text-ok">Raggiungibile</Badge>
        ) : (
          <Badge variant="outline" className="border-crit/40 bg-crit-soft font-medium text-crit-text">Non raggiungibile</Badge>
        )}
        {r.statusCode != null ? <span className="num font-medium">HTTP {r.statusCode}</span> : null}
        <span className="num text-text-2">{r.latencyMs} ms</span>
      </div>
      <p className="num mt-1 truncate text-text-2" title={r.target}>destinazione: {r.target}</p>
      <p className="mt-1 leading-relaxed text-text-2">{r.detail}</p>
    </div>
  )
}

/* ================================================================
 * C — Webhook (firma HMAC-SHA256, segreto one-time)
 * ================================================================ */

function WebhooksCard() {
  const queryClient = useQueryClient()
  const webhooks = useQuery({
    queryKey: ['webhooks'],
    queryFn: () => api.webhooks(),
    staleTime: 30_000,
  })

  const items = webhooks.data?.data.items ?? []

  /* --- Dialog creazione --- */
  const [createOpen, setCreateOpen] = useState(false)
  const [whName, setWhName] = useState('')
  const [whUrl, setWhUrl] = useState('')
  const [whSecret, setWhSecret] = useState('')
  const [whEvents, setWhEvents] = useState('')
  const [whDescription, setWhDescription] = useState('')
  /* Segreto HMAC mostrato UNA sola volta alla creazione (se generato
   * dal server): chiuso il dialog non è più recuperabile */
  const [secretOneTime, setSecretOneTime] = useState<string | null>(null)

  /* --- Test di consegna (mutation + dialog esito) --- */
  const [testTarget, setTestTarget] = useState<WebhookEndpointRow | null>(null)
  const [testResult, setTestResult] = useState<WebhookTestResult | null>(null)

  /* --- Dialog dettaglio consegne (ultime 10 per endpoint) --- */
  const [detailTarget, setDetailTarget] = useState<WebhookEndpointRow | null>(null)

  /* --- Eliminazione --- */
  const [deleteTarget, setDeleteTarget] = useState<WebhookEndpointRow | null>(null)

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['webhooks'] })
  }

  const resetCreateForm = () => {
    setWhName('')
    setWhUrl('')
    setWhSecret('')
    setWhEvents('')
    setWhDescription('')
  }

  const create = useMutation({
    mutationFn: (input: CreateWebhookInput) => api.createWebhook(input),
    onSuccess: (row) => {
      toast.success('Webhook creato', {
        description: `«${row.name}»: le consegne firmano il payload con HMAC-SHA256 (header X-Falco-Signature).`,
      })
      setSecretOneTime(row.secretOneTime)
      resetCreateForm()
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const toggleActive = useMutation({
    mutationFn: (input: { id: string; active: boolean }) => api.updateWebhook(input.id, { active: input.active }),
    onSuccess: (row) => {
      toast.success(row.active ? 'Webhook attivato' : 'Webhook disattivato', {
        description: `«${row.name}»: ${row.active ? 'le consegne riprendono' : 'le consegne sono sospese'} (update REALE nel DB).`,
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Cambio stato non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const testDelivery = useMutation({
    mutationFn: (id: string) => api.testWebhook(id),
    onSuccess: (r, id) => {
      setTestResult(r)
      /* FIX 29/10: React Compiler + useMutation (warning noto
       * «incompatible-library») congela il render del dialog sullo
       * snapshot iniziale — l'invalidazione della query forza il
       * ri-render da fonte stabile e l'esito appare. */
      void queryClient.invalidateQueries({ queryKey: ['webhooks'] })
    },
    /* L'errore è mostrato nel dialog di esito (nessun doppio avviso) */
    /* L'errore è mostrato nel dialog di esito (nessun doppio avviso) */
    onError: () => { /* gestito nel dialog con ErrorPanel */ },
  })

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteWebhook(id),
    onSuccess: (_res, id) => {
      if (testTarget?.id === id) { setTestTarget(null); setTestResult(null) }
      if (detailTarget?.id === id) setDetailTarget(null)
      setDeleteTarget(null)
      toast.success('Webhook eliminato', {
        description: 'Endpoint e consegne rimosse dal DB reale.',
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submitCreate = () => {
    const name = whName.trim()
    const url = whUrl.trim()
    if (name.length < 2 || !/^https?:\/\//.test(url) || create.isPending) return
    /* Eventi in CSV → array (vuoto = tutti gli eventi) */
    const events = whEvents.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 30)
    const secret = whSecret.trim()
    create.mutate({
      name,
      url,
      secret: secret.length > 0 ? secret : undefined, /* assente = generato e mostrato una volta */
      events: events.length > 0 ? events : undefined,
      description: whDescription.trim() || undefined,
    })
  }

  const openTest = (w: WebhookEndpointRow) => {
    testDelivery.reset()
    setTestResult(null)
    setTestTarget(w)
    testDelivery.mutate(w.id)
  }

  return (
    <Card className="min-w-0 border-border/70 bg-surface lg:col-span-2">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <Webhook className="size-4 text-text-2" aria-hidden />
          Webhook (firma HMAC)
          {webhooks.data ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              {fmtNumber(webhooks.data.data.total)} endpoint
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Notifiche degli eventi in POST firmate HMAC-SHA256 (header X-Falco-Signature):
          ogni consegna è registrata con esito, tentativi e latenza.
        </CardDescription>
        <CardAction>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => { void webhooks.refetch() }} disabled={webhooks.isFetching} aria-label="Aggiorna gli endpoint webhook">
            <RefreshCw className={cn('size-3.5', webhooks.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {webhooks.isPending ? (
          <LoadingRows rows={4} />
        ) : webhooks.isError ? (
          <ErrorPanel
            message={errInfo(webhooks.error).message}
            code={errInfo(webhooks.error).code}
            onRetry={() => { void webhooks.refetch() }}
          />
        ) : (
          <>
            {items.length === 0 ? (
              <EmptyState
                icon={<Webhook className="size-10" aria-hidden />}
                title="Nessun endpoint configurato"
                description="La consegna di test firma il payload con HMAC-SHA256 e verifica la firma end-to-end. Per provare in locale: crea un webhook verso http://127.0.0.1:3000/api/hooks/test-receiver."
                action={
                  <Button size="sm" className="h-9" onClick={() => { setCreateOpen(true) }}>
                    <Plus className="size-3.5" aria-hidden /> Nuovo webhook
                  </Button>
                }
              />
            ) : (
              <>
                <div className="flex justify-end">
                  <Button size="sm" className="h-9" onClick={() => { setSecretOneTime(null); setCreateOpen(true) }}>
                    <Plus className="size-3.5" aria-hidden /> Nuovo webhook
                  </Button>
                </div>
                <div className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70" role="region" aria-label="Endpoint webhook configurati, scorribile" tabIndex={0}>
                  <Table>
                    <TableCaption className="sr-only">
                      Endpoint webhook: nome, URL, eventi, stato attivo, ultima consegna, ultimo stato, consegne totali e azioni
                    </TableCaption>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead scope="col" className="w-[150px]">Nome</TableHead>
                        <TableHead scope="col">URL</TableHead>
                        <TableHead scope="col" className="w-[140px]">Eventi</TableHead>
                        <TableHead scope="col" className="w-[70px]">Attivo</TableHead>
                        <TableHead scope="col" className="w-[110px]">Ultima consegna</TableHead>
                        <TableHead scope="col" className="w-[110px]">Ultimo stato</TableHead>
                        <TableHead scope="col" className="w-[90px] text-right">Consegne</TableHead>
                        <TableHead scope="col" className="w-[150px] text-right">Azioni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((w) => (
                        <TableRow key={w.id}>
                          <TableCell>
                            <span className="flex items-center gap-1.5">
                              <span className="block max-w-[130px] truncate text-[13px] font-medium" title={w.name}>{w.name}</span>
                              {w.hasSecret ? (
                                <span title="segreto HMAC salvato (mai esposto)" className="inline-flex shrink-0">
                                  <LockKeyhole className="size-3.5 text-text-2" aria-hidden />
                                </span>
                              ) : null}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="block max-w-[230px] truncate font-mono text-xs" title={w.url}>{w.url}</span>
                          </TableCell>
                          <TableCell>
                            {w.events.length > 0 ? (
                              <span className="block max-w-[130px] truncate font-mono text-xs" title={w.events.join(', ')}>{w.events.join(', ')}</span>
                            ) : (
                              <span className="text-xs text-text-2">tutti</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={w.active}
                              onCheckedChange={(checked) => toggleActive.mutate({ id: w.id, active: checked })}
                              disabled={toggleActive.isPending && toggleActive.variables?.id === w.id}
                              aria-label={`Attiva o disattiva le consegne di ${w.name}`}
                            />
                          </TableCell>
                          <TableCell>
                            <span className="num text-xs" title={fmtDateTimeFull(w.lastDeliveryAt)}>{fmtRelative(w.lastDeliveryAt)}</span>
                          </TableCell>
                          <TableCell>
                            {w.lastStatus ? (
                              <Badge
                                variant="outline"
                                className={cn('num border-border bg-raised font-normal', DELIVERY_STATUS_META[w.lastStatus]?.cls)}
                                title={w.lastStatus}
                              >
                                {DELIVERY_STATUS_META[w.lastStatus]?.label ?? w.lastStatus}
                              </Badge>
                            ) : (
                              <span className="text-xs text-text-2">—</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <button
                              type="button"
                              className="num text-xs underline decoration-dotted underline-offset-4 hover:text-primary"
                              onClick={() => setDetailTarget(w)}
                              aria-label={`Dettaglio delle consegne di ${w.name}`}
                              title="Apre il dettaglio delle ultime consegne"
                            >
                              {fmtNumber(w.deliveriesTotal)}
                            </button>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8"
                                onClick={() => openTest(w)}
                                disabled={testDelivery.isPending && testTarget?.id === w.id}
                                aria-label={`Test di consegna firmato per ${w.name}`}
                              >
                                {testDelivery.isPending && testTarget?.id === w.id
                                  ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
                                  : <FlaskConical className="size-3.5" aria-hidden />}
                                Test di consegna
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-text-2"
                                onClick={() => setDetailTarget(w)}
                                aria-label={`Storico consegne di ${w.name}`}
                                title="Ultime 10 consegne registrate"
                              >
                                <History className="size-3.5" aria-hidden />
                              </Button>
                              <AlertDialog open={deleteTarget?.id === w.id} onOpenChange={(o) => { if (!o) setDeleteTarget(null) }}>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="size-8 text-crit-text hover:text-crit-text"
                                    onClick={() => setDeleteTarget(w)}
                                    aria-label={`Elimina il webhook ${w.name}`}
                                  >
                                    <Trash2 className="size-3.5" aria-hidden />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Eliminare «{deleteTarget?.name}»?</AlertDialogTitle>
                                    <AlertDialogDescription className="text-left leading-relaxed">
                                      Cancellazione REALE dal DB: endpoint, segreto HMAC e consegne
                                      registrate verranno rimossi. L&apos;azione è registrata nell&apos;audit.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
                                    <AlertDialogAction
                                      disabled={remove.isPending}
                                      onClick={(e) => {
                                        e.preventDefault() // resta aperto finché la risposta reale non arriva
                                        if (!deleteTarget || remove.isPending) return
                                        remove.mutate(deleteTarget.id)
                                      }}
                                    >
                                      {remove.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                                      Elimina
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
            {webhooks.data ? <AsOf ts={webhooks.data.asOf} prefix="endpoint alle" className="mt-1" /> : null}
          </>
        )}
      </CardContent>

      {/* --- Dialog: nuovo webhook (segreto one-time se generato) --- */}
      <Dialog
        open={createOpen}
        onOpenChange={(open) => {
          setCreateOpen(open)
          /* Chiuso il dialog il segreto one-time è perso per sempre (dichiarato) */
          if (!open) setSecretOneTime(null)
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuovo webhook</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Endpoint reale nel DB: le consegne firmano il payload con HMAC-SHA256
              (header X-Falco-Signature). Per provare in locale:
              <span className="num"> http://127.0.0.1:3000/api/hooks/test-receiver</span> —
              il ricevitore verifica la firma e risponde.
            </DialogDescription>
          </DialogHeader>

          {secretOneTime ? (
            <Alert className="border-warn/50 bg-warn-soft">
              <LockKeyhole className="size-4 text-warn" aria-hidden />
              <AlertTitle className="text-sm font-medium text-warn">
                Segreto HMAC generato: visibile adesso per l&apos;ultima volta
              </AlertTitle>
              <AlertDescription className="text-xs">
                <p className="leading-relaxed text-text-2">
                  Salvarlo ORA: chiuso questo dialog non sarà più recuperabile (il server
                  non lo espone più).
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <code className="min-w-0 flex-1 break-all rounded border border-warn/40 bg-surface px-2 py-1.5 font-mono text-xs">
                    {secretOneTime}
                  </code>
                  <Button type="button" size="sm" variant="outline" className="h-8" onClick={() => { void copyText(secretOneTime) }}>
                    <Copy className="size-3.5" aria-hidden /> Copia
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          ) : null}

          <form
            className="grid gap-3"
            onSubmit={(e) => { e.preventDefault(); submitCreate() }}
            noValidate
            aria-label="Form di creazione webhook"
          >
            <div className="grid gap-1.5">
              <label htmlFor="wh-name" className="text-xs font-medium text-text-2">Nome *</label>
              <Input
                id="wh-name"
                value={whName}
                maxLength={80}
                onChange={(e) => setWhName(e.target.value)}
                placeholder="es. Notifiche NOC"
                aria-required="true"
              />
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="wh-url" className="text-xs font-medium text-text-2">URL *</label>
              <Input
                id="wh-url"
                value={whUrl}
                maxLength={500}
                onChange={(e) => setWhUrl(e.target.value)}
                placeholder="http://127.0.0.1:3000/api/hooks/test-receiver"
                className="font-mono text-xs"
                aria-required="true"
              />
              <p className="text-xs text-text-2">per provare in locale: http://127.0.0.1:3000/api/hooks/test-receiver</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="wh-secret" className="text-xs font-medium text-text-2">Segreto HMAC</label>
                <Input
                  id="wh-secret"
                  type="password"
                  value={whSecret}
                  maxLength={200}
                  onChange={(e) => setWhSecret(e.target.value)}
                  placeholder="assente = generato dal server"
                  autoComplete="off"
                />
                <p className="text-xs text-text-2">assente = generato e mostrato UNA volta; min 16 caratteri se inserito</p>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="wh-events" className="text-xs font-medium text-text-2">Eventi</label>
                <Input
                  id="wh-events"
                  value={whEvents}
                  maxLength={400}
                  onChange={(e) => setWhEvents(e.target.value)}
                  placeholder="alert.created,ticket.closed · vuoto = tutti"
                  className="font-mono text-xs"
                />
                <p className="text-xs text-text-2">elenco CSV; vuoto = tutti gli eventi</p>
              </div>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="wh-desc" className="text-xs font-medium text-text-2">Descrizione</label>
              <Input
                id="wh-desc"
                value={whDescription}
                maxLength={300}
                onChange={(e) => setWhDescription(e.target.value)}
                placeholder="es. connessione al sistema allarmi della sede"
              />
            </div>
          </form>

          <DialogFooter className="gap-2 sm:justify-between">
            {secretOneTime ? (
              <Button
                type="button"
                variant="outline"
                onClick={() => { setCreateOpen(false); setSecretOneTime(null) }}
              >
                Ho salvato il segreto, chiudi
              </Button>
            ) : (
              <Button type="button" variant="outline" onClick={() => { setCreateOpen(false); setSecretOneTime(null) }}>
                Annulla
              </Button>
            )}
            <Button
              onClick={submitCreate}
              disabled={create.isPending || whName.trim().length < 2 || !/^https?:\/\//.test(whUrl.trim())}
            >
              {create.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
              Crea webhook
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Dialog: esito del test di consegna (firma verificata?) --- */}
      <Dialog
        open={!!testTarget}
        onOpenChange={(open) => {
          if (!open) { setTestTarget(null); setTestResult(null) }
        }}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Test di consegna · {testTarget?.name}</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              POST reale del payload di test firmato HMAC-SHA256 verso
              <span className="num break-all"> {testTarget?.url}</span> — il ricevitore
              verifica la firma e risponde: esito end-to-end, non simulato.
            </DialogDescription>
          </DialogHeader>
          {testDelivery.isPending ? (
            <div role="status" aria-busy="true" className="flex items-center gap-2.5 rounded-md border border-border/70 bg-raised/40 px-3 py-4 text-sm text-text-2">
              <Loader2 className="size-4 animate-spin" aria-hidden />
              Consegna in corso verso l&apos;endpoint…
            </div>
          ) : testDelivery.isError ? (
            <ErrorPanel
              message={errInfo(testDelivery.error).message}
              code={errInfo(testDelivery.error).code}
              onRetry={() => { if (testTarget) { testDelivery.reset(); testDelivery.mutate(testTarget.id) } }}
            />
          ) : testResult ? (
            <WebhookTestOutcome r={testResult} />
          ) : null}
        </DialogContent>
      </Dialog>

      {/* --- Dialog: dettaglio ultime 10 consegne per endpoint --- */}
      <Dialog
        open={!!detailTarget}
        onOpenChange={(open) => { if (!open) setDetailTarget(null) }}
      >
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Consegne · {detailTarget?.name}</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Ultime {fmtNumber(detailTarget?.deliveries.length ?? 0)} consegne registrate nel DB reale
              ({fmtNumber(detailTarget?.deliveriesTotal ?? 0)} totali): DELIVERED = consegnata,
              DEAD = scartata dopo i retry.
            </DialogDescription>
          </DialogHeader>
          {detailTarget && detailTarget.deliveries.length === 0 ? (
            <EmptyState
              title="Nessuna consegna registrata"
              description="Questo endpoint non ha ancora consegne nel DB: esegui un «Test di consegna» per generarne una reale."
            />
          ) : detailTarget ? (
            <div className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70" role="region" aria-label="Storico consegne del webhook, scorribile" tabIndex={0}>
              <Table>
                <TableCaption className="sr-only">
                  Ultime consegne del webhook: evento, stato, codice HTTP, latenza e data
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="w-[170px]">Evento</TableHead>
                    <TableHead scope="col" className="w-[130px]">Stato</TableHead>
                    <TableHead scope="col" className="w-[80px]">Codice</TableHead>
                    <TableHead scope="col" className="w-[90px]">Latenza</TableHead>
                    <TableHead scope="col" className="w-[130px]">Data</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detailTarget.deliveries.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell>
                        <Badge variant="outline" className="num max-w-[160px] border-border bg-raised font-normal text-text-2" title={d.eventType}>
                          {d.eventType}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span title={d.lastError || d.status}>
                          <Badge
                            variant="outline"
                            className={cn('num border-border bg-raised font-normal', DELIVERY_STATUS_META[d.status]?.cls)}
                          >
                            {DELIVERY_STATUS_META[d.status]?.label ?? d.status}
                          </Badge>
                        </span>
                      </TableCell>
                      <TableCell>
                        {d.lastStatusCode != null ? <span className="num text-xs">{d.lastStatusCode}</span> : <span className="text-xs text-text-2">—</span>}
                      </TableCell>
                      <TableCell>
                        <span className="num text-xs" title={`${d.attempts} tentativi`}>{d.latencyMs} ms</span>
                      </TableCell>
                      <TableCell>
                        <span className="num text-xs" title={fmtDateTimeFull(d.deliveredAt ?? d.createdAt)}>
                          {fmtDateTime(d.deliveredAt ?? d.createdAt)}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </Card>
  )
}

/* Esito del test di consegna webhook: valori REALI della risposta,
 * firma mostrata mono (troncata, completa nel title). */
function WebhookTestOutcome({ r }: { r: WebhookTestResult }) {
  return (
    <div className="space-y-3 text-xs" role="status" aria-live="polite">
      <div className="flex flex-wrap items-center gap-2">
        {r.delivered ? (
          <Badge variant="outline" className="border-ok/40 bg-ok-soft font-medium text-ok">Consegnata</Badge>
        ) : (
          <Badge variant="outline" className="border-crit/40 bg-crit-soft font-medium text-crit-text">Non consegnata</Badge>
        )}
        {r.statusCode != null ? <span className="num font-medium">HTTP {r.statusCode}</span> : null}
        <span className="num text-text-2">{r.latencyMs} ms</span>
        {r.signatureVerified ? (
          <Badge variant="outline" className="gap-1 border-ok/40 bg-ok-soft font-medium text-ok">
            <ShieldCheck className="size-3.5" aria-hidden /> firma verificata end-to-end
          </Badge>
        ) : (
          <Badge variant="outline" className="border-border bg-raised font-normal text-text-2">
            firma non verificata dal ricevitore
          </Badge>
        )}
      </div>
      <div>
        <p className="text-text-2">Header X-Falco-Signature inviato (pubblico per costruzione):</p>
        <code className="mt-1 block truncate rounded border border-border bg-raised/50 px-2 py-1.5 font-mono" title={r.signature}>
          {r.signature}
        </code>
      </div>
      <p className="leading-relaxed text-text-2">{r.detail}</p>
    </div>
  )
}
