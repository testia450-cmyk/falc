/* Stati obbligatori per ogni componente (§4.2): vuoto · errore · caricamento */

'use client'

import { FolderSearch, CloudOff, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: React.ReactNode
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn('flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border bg-surface/50 px-6 py-12 text-center', className)}>
      <div className="text-text-2">{icon ?? <FolderSearch className="size-10" aria-hidden />}</div>
      <div>
        <p className="text-sm font-medium">{title}</p>
        {description ? <p className="mt-1 max-w-sm text-xs text-text-2">{description}</p> : null}
      </div>
      {action}
    </div>
  )
}

export function ErrorPanel({
  message,
  code,
  onRetry,
  className,
}: {
  message: string
  code?: string
  onRetry?: () => void
  className?: string
}) {
  return (
    <div role="alert" className={cn('flex flex-col items-start gap-3 rounded-lg border border-crit/40 bg-crit-soft px-4 py-4', className)}>
      <div className="flex items-center gap-2.5">
        <CloudOff className="size-5 text-crit-text shrink-0" aria-hidden />
        <div>
          <p className="text-sm font-medium text-crit-text">Dati non disponibili</p>
          <p className="mt-0.5 text-xs text-text-2">{message}{code ? ` (codice ${code})` : ''}</p>
        </div>
      </div>
      {onRetry ? (
        <Button variant="outline" size="sm" onClick={onRetry} className="h-9">
          <Loader2 className="mr-1.5 size-3.5" aria-hidden /> Riprova
        </Button>
      ) : null}
    </div>
  )
}

export function LoadingRows({ rows = 5, className }: { rows?: number; className?: string }) {
  return (
    <div className={cn('space-y-2', className)} role="status" aria-busy="true">
      <span className="sr-only">Caricamento righe…</span>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-10 animate-pulse rounded-md bg-raised/60" />
      ))}
    </div>
  )
}
