/* ================================================================
 * FALCO-OS v16 — Sezione «RMA guidata + Ondate» (16.9 ondata W4)
 * Tab della vista Amministrazione: (A) SOSTITUZIONE GUASTO GUIDATA
 * in 5 passi (port fedele da v15): il piano d'impatto REALE — BFS
 * a valle, portabilità delle credenziali cifrate, genealogia
 * append-only — viene mostrato PRIMA del cambio; l'esecuzione è una
 * mutazione REALE e irreversibile: il vecchio viene DISMESSO
 * (credenziali revocate, allarmi chiusi, polling spento, cronologia
 * intatta) e il nuovo nasce nello stesso punto con gruppi e
 * collegamenti portati. (B) ONDATE di configurazione/firmware:
 * pianificazione reale con preflight per target, lotti col canary.
 * ONESTÀ D2: il motore di esecuzione per-dispositivo non è attivo
 * in modalità riproduzione → le ondate nascono e restano DRAFT;
 * nessuna adozione automatica. Mai dati inventati.
 * ================================================================ */

'use client'

import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  ArrowRight, Check, ChevronsUpDown, CircleCheck, History, Layers, Loader2,
  Plus, RefreshCw, Replace, Trash2, TriangleAlert, X,
} from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { api, ApiError } from '@/lib/client/api'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtRelative, typeLabel, STATUS_META } from '@/lib/client/format'
import type { CreateWaveInput, RmaExecuteInput, RmaPlan, WaveRow } from '@/lib/v2/contracts'
import { cn } from '@/lib/utils'

/* ---------------- Costanti sezione ---------------- */

/* Tipi dispositivo accettati per il sostituto (enum del contratto RMA) */
const REPLACEMENT_TYPES = ['AP', 'STA', 'CAMERA', 'LPR', 'SWITCH', 'NVR', 'GATEWAY', 'ONT'] as const
type ReplacementType = (typeof REPLACEMENT_TYPES)[number]

/* Tipi ondata (vocabolario del DB; valori ignoti mostrati raw) */
const WAVE_KIND_META: Record<string, { label: string; cls: string }> = {
  CONFIG: { label: 'Configurazione', cls: 'border-info/40 bg-info-soft text-info' },
  FIRMWARE: { label: 'Firmware', cls: 'border-warn/40 bg-warn-soft text-warn' },
}

/* Stati ondata (badge: colore + testo, §4.2 — mai solo colore) */
const WAVE_STATUS_META: Record<string, { label: string; cls: string }> = {
  DRAFT: { label: 'DRAFT', cls: 'border-border bg-raised text-text-2' },
  READY: { label: 'READY', cls: 'border-info/40 bg-info-soft text-info' },
  RUNNING: { label: 'RUNNING', cls: 'border-warn/40 bg-warn-soft text-warn' },
  STOPPED: { label: 'STOPPED', cls: 'border-crit/40 bg-crit-soft text-crit-text' },
  COMPLETED: { label: 'COMPLETED', cls: 'border-ok/40 bg-ok-soft text-ok' },
}

/* Esito dell'esecuzione RMA (contratto POST /api/v2/rma) */
interface RmaExecResult {
  newDeviceId: string
  steps: Array<{ step: string; ok: boolean; detail: string }>
}

/* Esito della pianificazione ondata (contratto POST /api/v2/waves) */
interface WaveCreateData {
  wave: WaveRow | null
  preflight: Array<{ deviceId: string; hostname: string; ok: boolean; reason: string }>
  batches: Array<{ number: number; deviceIds: string[]; isCanary: boolean }>
  scarti: number
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* ================================================================
 * Pannello «RMA guidata + Ondate» (onda W4)
 * ================================================================ */

export function RmaOndatePanel() {
  return (
    <Tabs defaultValue="rma">
      <TabsList
        aria-label="Sezioni RMA guidata e ondate"
        className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit"
      >
        <TabsTrigger value="rma" className="shrink-0">RMA guidata</TabsTrigger>
        <TabsTrigger value="ondate" className="shrink-0">Ondate</TabsTrigger>
      </TabsList>
      <TabsContent value="rma" className="mt-4">
        <RmaSection />
      </TabsContent>
      <TabsContent value="ondate" className="mt-4">
        <OndateSection />
      </TabsContent>
    </Tabs>
  )
}

/* ================================================================
 * A — Sostituzione guasto guidata (5 passi v15)
 * ================================================================ */

function RmaSection() {
  const queryClient = useQueryClient()

  /* Passo 1 — inventario reale per il selettore del guasto */
  const devices = useQuery({
    queryKey: ['devices', 1, 100],
    queryFn: () => api.devices({ page: 1, pageSize: 100 }),
    staleTime: 60_000,
  })
  const deviceList = devices.data?.data.items ?? []

  const [deviceId, setDeviceId] = useState('')
  /* Il piano viene caricato SOLO su «Prepara piano» (decisione esplicita) */
  const [planFor, setPlanFor] = useState('')
  const plan = useQuery({
    queryKey: ['rma-plan', planFor],
    queryFn: () => api.rmaPlan(planFor),
    enabled: !!planFor,
    staleTime: 30_000,
  })

  /* Passo 2 — scheda del sostituto */
  const [repHostname, setRepHostname] = useState('')
  const [repIp, setRepIp] = useState('')
  const [repType, setRepType] = useState<ReplacementType>('AP')
  const [repBrand, setRepBrand] = useState('')
  const [repModel, setRepModel] = useState('')
  const [repMac, setRepMac] = useState('')
  const [repPort, setRepPort] = useState('')
  const [repConnection, setRepConnection] = useState('')
  const [reason, setReason] = useState('')

  /* Passo 3 — conferma + esecuzione + esito */
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [execResult, setExecResult] = useState<RmaExecResult | null>(null)
  const [execHostname, setExecHostname] = useState('')

  const portNum = repPort.trim() === '' ? undefined : Number.parseInt(repPort, 10)
  const portValid = portNum === undefined || (Number.isInteger(portNum) && portNum >= 1 && portNum <= 65_535)
  const canExecute = !!planFor && !!plan.data
    && repHostname.trim().length > 0 && repIp.trim().length >= 7 && portValid

  const resetReplacementForm = () => {
    setRepHostname('')
    setRepIp('')
    setRepType('AP')
    setRepBrand('')
    setRepModel('')
    setRepMac('')
    setRepPort('')
    setRepConnection('')
    setReason('')
  }

  const execute = useMutation({
    mutationFn: (input: RmaExecuteInput) => api.rmaExecute(input),
    onSuccess: (r) => {
      setExecResult(r)
      setConfirmOpen(false)
      setDeviceId('')
      setPlanFor('')
      resetReplacementForm()
      toast.success('Sostituzione eseguita', {
        description: `Nuovo dispositivo ${r.newDeviceId}: il vecchio è DISMESSO con cronologia intatta, genealogia registrata (append-only).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['devices'] })
      void queryClient.invalidateQueries({ queryKey: ['rma-plan'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Sostituzione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submitExecute = () => {
    if (!planFor || !canExecute || execute.isPending) return
    setExecHostname(repHostname.trim())
    execute.mutate({
      oldDeviceId: planFor,
      reason: reason.trim() || undefined,
      replacement: {
        hostname: repHostname.trim(),
        ip: repIp.trim(),
        type: repType,
        brand: repBrand.trim() || undefined,
        model: repModel.trim() || undefined,
        macAddress: repMac.trim() || undefined,
        port: portNum,
        connectionType: repConnection.trim() || undefined,
      },
    })
  }

  const selectDevice = (id: string) => {
    setDeviceId(id)
    setPlanFor('') // il piano è specifico del dispositivo: si riprepara
    setExecResult(null)
  }

  return (
    <div className="grid min-w-0 grid-cols-1 gap-4">
      <Card className="min-w-0 border-border/70 bg-surface">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
            <Replace className="size-4 text-text-2" aria-hidden />
            Sostituzione guasto guidata
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">5 passi · v15</Badge>
          </CardTitle>
          <CardDescription>
            Piano d&apos;impatto reale prima del cambio (dispositivi a valle per BFS, portabilità delle
            credenziali cifrate, genealogia), poi esecuzione irreversibile confermata esplicitamente:
            il vecchio viene dismesso senza perdere la cronologia, il nuovo nasce nello stesso punto.
          </CardDescription>
          <CardAction>
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void devices.refetch() }}
              disabled={devices.isFetching}
              aria-label="Aggiorna l'inventario dei dispositivi"
            >
              <RefreshCw className={cn('size-3.5', devices.isFetching && 'animate-spin')} aria-hidden />
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* --- Passo 1: dispositivo guasto + piano --- */}
          <section aria-labelledby="rma-step1" className="grid gap-2.5">
            <h4 id="rma-step1" className="text-xs font-medium text-text-2">
              Passo 1 — Dispositivo guasto e piano d&apos;impatto
            </h4>
            <div className="grid gap-2.5 sm:grid-cols-[1fr_auto] sm:items-center">
              <Select value={deviceId} onValueChange={selectDevice}>
                <SelectTrigger
                  id="rma-device"
                  className="w-full"
                  disabled={devices.isPending || deviceList.length === 0}
                  aria-label="Dispositivo da sostituire"
                >
                  <SelectValue
                    placeholder={devices.isPending
                      ? 'caricamento inventario…'
                      : deviceList.length === 0 ? 'nessun dispositivo' : 'Scegli il dispositivo guasto…'}
                  />
                </SelectTrigger>
                <SelectContent>
                  {deviceList.map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.hostname} · {d.ip}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={() => {
                  setExecResult(null)
                  if (deviceId === planFor) { void plan.refetch() } else { setPlanFor(deviceId) }
                }}
                disabled={!deviceId || plan.isFetching}
                className="sm:w-auto"
                aria-label="Prepara il piano di sostituzione per il dispositivo scelto"
              >
                {plan.isFetching ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <History className="size-3.5" aria-hidden />}
                Prepara piano
              </Button>
            </div>
            {devices.isError ? (
              <p className="text-xs text-crit-text" role="alert">
                Inventario non disponibile: {errInfo(devices.error).message}
              </p>
            ) : null}
          </section>

          {/* --- Piano (dato REALE del DB per il dispositivo scelto) --- */}
          {planFor ? (
            plan.isFetching ? (
              <div role="status" aria-busy="true" className="space-y-2 rounded-lg border border-border/70 bg-raised/30 p-3">
                <span className="sr-only">Calcolo del piano di sostituzione in corso…</span>
                <LoadingRows rows={3} />
              </div>
            ) : plan.isError ? (
              <ErrorPanel
                message={errInfo(plan.error).message}
                code={errInfo(plan.error).code}
                onRetry={() => { void plan.refetch() }}
              />
            ) : plan.data ? (
              <>
                <RmaPlanView plan={plan.data.data} />
                <AsOf ts={plan.data.asOf} prefix="piano calcolato alle" />
              </>
            ) : null
          ) : null}

          {/* --- Passo 2: scheda del sostituto --- */}
          <Separator />
          <section aria-labelledby="rma-step2" className="grid gap-2.5">
            <h4 id="rma-step2" className="text-xs font-medium text-text-2">
              Passo 2 — Sostituto (hostname, IP, tipo) e motivo
            </h4>
            <div className="grid gap-3 rounded-lg border border-border/70 bg-raised/30 p-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="rep-hostname" className="text-xs font-medium text-text-2">Hostname *</label>
                <Input
                  id="rep-hostname"
                  value={repHostname}
                  maxLength={200}
                  onChange={(e) => setRepHostname(e.target.value)}
                  placeholder="es. atena-nuova"
                  className="font-mono text-xs"
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-ip" className="text-xs font-medium text-text-2">IP *</label>
                <Input
                  id="rep-ip"
                  value={repIp}
                  maxLength={45}
                  onChange={(e) => setRepIp(e.target.value)}
                  placeholder="es. 10.0.10.25"
                  className="font-mono text-xs"
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-type" className="text-xs font-medium text-text-2">Tipo *</label>
                <Select value={repType} onValueChange={(v) => setRepType(v as ReplacementType)}>
                  <SelectTrigger id="rep-type" className="w-full" aria-label="Tipo del dispositivo sostituto">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {REPLACEMENT_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>{t} · {typeLabel(t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-port" className="text-xs font-medium text-text-2">Porta (opzionale)</label>
                <Input
                  id="rep-port"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={65535}
                  value={repPort}
                  onChange={(e) => setRepPort(e.target.value)}
                  className="num"
                  aria-invalid={!portValid}
                />
                {!portValid ? <p className="text-xs text-crit-text" role="alert">porta non valida (1–65535)</p> : null}
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-brand" className="text-xs font-medium text-text-2">Marca</label>
                <Input
                  id="rep-brand"
                  value={repBrand}
                  maxLength={100}
                  onChange={(e) => setRepBrand(e.target.value)}
                  placeholder="es. Ubiquiti"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-model" className="text-xs font-medium text-text-2">Modello</label>
                <Input
                  id="rep-model"
                  value={repModel}
                  maxLength={100}
                  onChange={(e) => setRepModel(e.target.value)}
                  placeholder="es. LiteBeam 5AC"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-mac" className="text-xs font-medium text-text-2">MAC address</label>
                <Input
                  id="rep-mac"
                  value={repMac}
                  maxLength={50}
                  onChange={(e) => setRepMac(e.target.value)}
                  placeholder="es. 24:A4:3C:00:00:00"
                  className="font-mono text-xs"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="rep-conn" className="text-xs font-medium text-text-2">Tipo collegamento</label>
                <Input
                  id="rep-conn"
                  value={repConnection}
                  maxLength={50}
                  onChange={(e) => setRepConnection(e.target.value)}
                  placeholder="es. wireless"
                />
              </div>
              <div className="grid gap-1.5 sm:col-span-2">
                <label htmlFor="rep-reason" className="text-xs font-medium text-text-2">Motivo (max 500)</label>
                <Input
                  id="rep-reason"
                  value={reason}
                  maxLength={500}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="es. guasto radio: segnale assente da giorni"
                />
                <p className="text-xs text-text-2">registrato nella genealogia e nell&apos;audit (RMA)</p>
              </div>
            </div>
          </section>

          {/* --- Passo 3: esecuzione --- */}
          <Separator />
          <section aria-labelledby="rma-step3" className="grid gap-2.5">
            <h4 id="rma-step3" className="text-xs font-medium text-text-2">
              Passo 3 — Esecuzione (i passi server 2–5 girano in un&apos;unica transazione)
            </h4>
            <div className="flex flex-wrap items-center gap-3">
              <AlertDialog open={confirmOpen} onOpenChange={(o) => { if (!o && !execute.isPending) setConfirmOpen(false) }}>
                <Button
                  className="bg-crit-solid text-white hover:bg-crit-solid/90"
                  onClick={() => setConfirmOpen(true)}
                  disabled={!canExecute || execute.isPending}
                  aria-label="Esegui la sostituzione guidata (azione irreversibile)"
                >
                  {execute.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Replace className="size-3.5" aria-hidden />}
                  Esegui sostituzione
                </Button>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confermi la sostituzione irreversibile?</AlertDialogTitle>
                    <AlertDialogDescription className="text-left leading-relaxed">
                      Esecuzione irreversibile: il vecchio viene <strong className="text-foreground">DISMESSO</strong> (credenziali
                      revocate, allarmi chiusi, polling spento — cronologia intatta), il nuovo nasce nello stesso
                      punto con credenziali/gruppi/collegamenti portati, la genealogia è append-only.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <p className="break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2">
                    {plan.data ? plan.data.data.hostname : '—'} ({planFor}) → <span className="font-mono">{repHostname.trim() || '—'}</span>{' '}
                    {repIp.trim() ? `· ${repIp.trim()}` : ''} · {repType}
                    {reason.trim() ? ` · motivo: ${reason.trim()}` : ''}
                  </p>
                  <AlertDialogFooter>
                    <AlertDialogCancel disabled={execute.isPending}>Annulla</AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-crit-solid text-white hover:bg-crit-solid/90"
                      disabled={execute.isPending}
                      onClick={(e) => {
                        e.preventDefault() // resta aperto finché la risposta reale non arriva
                        submitExecute()
                      }}
                    >
                      {execute.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Replace className="size-4" aria-hidden />}
                      Esegui ora
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              {!canExecute && !execute.isPending ? (
                <p className="text-xs text-text-2">
                  Serve il piano preparato (passo 1) e la scheda del sostituto completa: hostname e IP.
                </p>
              ) : null}
            </div>
          </section>

          {/* --- Esito: passi reali dell'esecuzione --- */}
          {execResult ? <RmaStepsView r={execResult} newHostname={execHostname} /> : null}
          {execute.isError && !execResult ? (
            <ErrorPanel
              message={errInfo(execute.error).message}
              code={errInfo(execute.error).code}
              onRetry={submitExecute}
            />
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}

/* Piano della sostituzione (dato reale): impatto a valle, portabilità,
 * genealogia e avvisi amber — ogni numero è del DB, mai inventato. */
function RmaPlanView({ plan }: { plan: RmaPlan }) {
  return (
    <div className="space-y-3 rounded-lg border border-border/70 bg-raised/30 p-3">
      <p className="text-xs">
        <span className="text-text-2">Piano per</span>{' '}
        <span className="font-mono font-medium" title={plan.deviceId}>{plan.hostname}</span>
      </p>

      {/* Impatto a valle (BFS reachability) */}
      <section aria-labelledby="rma-impact">
        <h4 id="rma-impact" className="text-xs font-medium">Impatto a valle</h4>
        <p className="mt-0.5 text-xs text-text-2">
          <span className="num font-medium text-foreground">{fmtNumber(plan.impact.downstreamVictims)}</span>{' '}
          {plan.impact.downstreamVictims === 1 ? 'dispositivo a valle dipende' : 'dispositivi a valle dipendono'} da
          questo apparato (reachability BFS sui collegamenti reali).
        </p>
        {plan.impact.victims.length > 0 ? (
          <div
            className="mt-2 max-h-40 overflow-y-auto scroll-thin overflow-x-auto rounded-md border border-border/70"
            role="region"
            aria-label="Dispositivi a valle del guasto, elenco scorribile"
            tabIndex={0}
          >
            <Table>
              <TableCaption className="sr-only">
                Dispositivi a valle: hostname, indirizzo IP, tipo e stato
              </TableCaption>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead scope="col">Hostname</TableHead>
                  <TableHead scope="col" className="w-[110px]">IP</TableHead>
                  <TableHead scope="col" className="w-[100px]">Tipo</TableHead>
                  <TableHead scope="col" className="w-[120px]">Stato</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {plan.impact.victims.map((v) => (
                  <TableRow key={v.id}>
                    <TableCell>
                      <span className="block max-w-[160px] truncate font-mono text-xs" title={v.hostname}>{v.hostname}</span>
                    </TableCell>
                    <TableCell className="num font-mono text-xs">{v.ip}</TableCell>
                    <TableCell><span className="text-xs text-text-2">{typeLabel(v.type)}</span></TableCell>
                    <TableCell><StatusChip status={v.status} /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : null}
        {plan.impact.downstreamVictims > plan.impact.victims.length ? (
          <p className="mt-1 text-xs text-text-2">
            Elenco limitato ai primi {fmtNumber(plan.impact.victims.length)} di {fmtNumber(plan.impact.downstreamVictims)} (contratto: max 50).
          </p>
        ) : null}
      </section>

      <Separator />

      {/* Portabilità sul sostituto */}
      <section aria-labelledby="rma-portable">
        <h4 id="rma-portable" className="text-xs font-medium">Portabilità sul sostituto</h4>
        <dl className="mt-1 grid gap-x-6 gap-y-1.5 sm:grid-cols-2">
          <PlanRow
            label="Credenziali"
            value={plan.portable.credentials.length > 0 ? (
              <span className="flex flex-wrap gap-1">
                {plan.portable.credentials.map((c) => (
                  <Badge key={c} variant="outline" className="border-border bg-raised font-normal text-text-2">{c}</Badge>
                ))}
              </span>
            ) : <span className="text-text-2">nessuna: il sostituto parte senza credenziali</span>}
          />
          <PlanRow label="Punto di rete" value={plan.portable.pointIdentifier ?? plan.portable.locationId ?? 'n.d.'} />
          <PlanRow label="Gruppi" value={`${fmtNumber(plan.portable.groupIds.length)} ${plan.portable.groupIds.length === 1 ? 'gruppo' : 'gruppi'}`} />
          <PlanRow label="Collegamenti confermati" value={fmtNumber(plan.portable.confirmedLinks)} />
          <PlanRow label="Note" value={plan.portable.notes ? 'presenti (riportate sul sostituto)' : 'nessuna'} />
        </dl>
      </section>

      <Separator />

      {/* Genealogia (append-only) */}
      <section aria-labelledby="rma-genealogy">
        <h4 id="rma-genealogy" className="text-xs font-medium">Genealogia (append-only)</h4>
        {plan.genealogy.length === 0 ? (
          <p className="mt-1 text-xs text-text-2">
            Nessuna sostituzione precedente nel DB reale: quest&apos;apparato non ha antenati.
          </p>
        ) : (
          <ul className="mt-1 space-y-1">
            {plan.genealogy.map((g, i) => (
              <li key={`${g.oldDeviceId}-${i}`} className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs">
                <span className="font-mono text-text-2" title={g.oldDeviceId}>{g.oldDeviceId.slice(0, 10)}…</span>
                <ArrowRight className="size-3 shrink-0 text-text-2" aria-hidden />
                <span className="font-mono" title={g.newDeviceId}>{g.newDeviceId.slice(0, 10)}…</span>
                <span className="text-text-2" title={fmtDateTimeFull(g.at)}>{fmtDateTime(g.at)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Avvisi (amber): guasto a monte, vittime a valle, già dismesso */}
      {plan.warnings.length > 0 ? (
        <div className="space-y-2" role="region" aria-label="Avvisi del piano di sostituzione">
          {plan.warnings.map((w, i) => (
            <Alert key={i} className="border-warn/50 bg-warn-soft">
              <TriangleAlert className="size-4 text-warn" aria-hidden />
              <AlertTitle className="text-sm font-medium text-warn">Avviso del piano</AlertTitle>
              <AlertDescription className="text-xs">
                <p className="leading-relaxed text-text-2">{w}</p>
              </AlertDescription>
            </Alert>
          ))}
        </div>
      ) : null}
    </div>
  )
}

/* Esito dell'esecuzione: passi reali con esito ✓/✗ e dettaglio. */
function RmaStepsView({ r, newHostname }: { r: RmaExecResult; newHostname: string }) {
  return (
    <div className="space-y-2 rounded-lg border border-ok/40 bg-ok-soft p-3" role="status" aria-live="polite">
      <p className="flex flex-wrap items-center gap-2 text-xs font-medium">
        <CircleCheck className="size-4 shrink-0 text-ok" aria-hidden />
        Sostituzione eseguita: nuovo dispositivo
        <span className="font-mono" title={r.newDeviceId}>{r.newDeviceId}</span>
        <span className="text-text-2">({newHostname || 'nuovo dispositivo'})</span>
      </p>
      <ul className="space-y-1.5">
        {r.steps.map((s, i) => (
          <li key={i} className="flex items-start gap-2 text-xs">
            {s.ok
              ? <Check className="mt-0.5 size-3.5 shrink-0 text-ok" aria-hidden />
              : <X className="mt-0.5 size-3.5 shrink-0 text-crit-text" aria-hidden />}
            <span className="min-w-0">
              <span className="font-medium">{s.step}</span>
              <span className="mt-0.5 block leading-relaxed text-text-2">{s.detail}</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

/* ---------------- Helper visuali ---------------- */

function PlanRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-2">
      <dt className="w-40 shrink-0 text-text-2">{label}</dt>
      <dd className="min-w-0 break-words">{value}</dd>
    </div>
  )
}

function StatusChip({ status }: { status: string }) {
  const meta = STATUS_META[status]
  return (
    <Badge variant="outline" className={cn('font-normal', meta?.cls ?? 'border-border bg-raised text-text-2')}>
      {meta?.label ?? status}
    </Badge>
  )
}

/* ================================================================
 * B — Ondate di configurazione/firmware
 * ================================================================ */

function OndateSection() {
  const queryClient = useQueryClient()

  const waves = useQuery({
    queryKey: ['waves'],
    queryFn: () => api.waves(),
    staleTime: 30_000,
  })
  const items = waves.data?.data.items ?? []

  /* --- Dialog creazione: form --- */
  const [createOpen, setCreateOpen] = useState(false)
  const [wName, setWName] = useState('')
  const [wKind, setWKind] = useState<'CONFIG' | 'FIRMWARE'>('CONFIG')
  const [wAction, setWAction] = useState('')
  const [wSearch, setWSearch] = useState('')
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [wBatch, setWBatch] = useState('5')
  const [wCanary, setWCanary] = useState('1')
  const [wDryRun, setWDryRun] = useState(true)
  const [wStop, setWStop] = useState(true)

  /* Dispositivi per il picker (caricati solo a dialog aperto) */
  const devices = useQuery({
    queryKey: ['devices', 1, 100],
    queryFn: () => api.devices({ page: 1, pageSize: 100 }),
    staleTime: 60_000,
    enabled: createOpen,
  })
  const deviceList = devices.data?.data.items ?? []
  const filteredDevices = useMemo(() => {
    const needle = wSearch.trim().toLowerCase()
    if (!needle) return deviceList
    return deviceList.filter((d) =>
      d.hostname.toLowerCase().includes(needle) || d.ip.includes(needle))
  }, [deviceList, wSearch])

  /* --- Esiti --- */
  const [lastCreate, setLastCreate] = useState<WaveCreateData | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<WaveRow | null>(null)

  const resetCreateForm = () => {
    setWName('')
    setWKind('CONFIG')
    setWAction('')
    setWSearch('')
    setSelectedIds([])
    setWBatch('5')
    setWCanary('1')
    setWDryRun(true)
    setWStop(true)
  }

  const create = useMutation({
    mutationFn: (input: CreateWaveInput) => api.createWave(input),
    onSuccess: (r) => {
      setLastCreate(r)
      setCreateOpen(false)
      resetCreateForm()
      toast.success('Ondata pianificata', {
        description: `«${r.wave?.name ?? 'n.d.'}»: ${r.batches.length} ${r.batches.length === 1 ? 'lotto' : 'lotti'} (lotto 1 = canary), ${r.scarti} ${r.scarti === 1 ? 'scarto' : 'scarti'} al preflight. Resta DRAFT: nessuna esecuzione automatica.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['waves'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Pianificazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteWave(id),
    onSuccess: (_res, id) => {
      if (lastCreate?.wave?.id === id) setLastCreate(null)
      setDeleteTarget(null)
      toast.success('Ondata eliminata', {
        description: 'Cancellazione REALE dal DB (righe ConfigWave e ConfigWaveItem) con voce di audit.',
      })
      void queryClient.invalidateQueries({ queryKey: ['waves'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const batchNum = Number.parseInt(wBatch, 10)
  const canaryNum = Number.parseInt(wCanary, 10)
  const batchValid = Number.isInteger(batchNum) && batchNum >= 1 && batchNum <= 50
  const canaryValid = Number.isInteger(canaryNum) && canaryNum >= 1 && canaryNum <= 10

  const toggleDevice = (id: string, checked: boolean) => {
    setSelectedIds((prev) => (checked ? [...prev, id] : prev.filter((x) => x !== id)))
  }

  const submitCreate = () => {
    const name = wName.trim()
    if (!name || selectedIds.length === 0 || create.isPending) return
    if (!batchValid || !canaryValid) return
    create.mutate({
      name,
      kind: wKind,
      action: wAction.trim() || undefined,
      deviceIds: selectedIds,
      batchSize: batchNum,
      canarySize: canaryNum,
      stopOnFirstFailure: wStop,
      dryRun: wDryRun,
    })
  }

  return (
    <div className="grid min-w-0 grid-cols-1 gap-4">
      <Card className="min-w-0 border-border/70 bg-surface">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
            <Layers className="size-4 text-text-2" aria-hidden />
            Ondate di configurazione/firmware
            {waves.data ? (
              <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
                {fmtNumber(waves.data.data.total)} pianificate
              </Badge>
            ) : null}
          </CardTitle>
          <CardDescription>
            Pianificazione reale con preflight per ogni target (dismesso, manutenzione, credenziali
            assenti, offline → scarto onesto) e lotti col canary: il lotto 1 va per primo.
          </CardDescription>
          <CardAction className="flex items-center gap-1.5">
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void waves.refetch() }}
              disabled={waves.isFetching}
              aria-label="Aggiorna l'elenco delle ondate"
            >
              <RefreshCw className={cn('size-3.5', waves.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-8" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden /> Nuova ondata
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Banner di onestà D2: sempre visibile */}
          <Alert className="border-warn/50 bg-warn-soft" role="note">
            <TriangleAlert className="size-4 text-warn" aria-hidden />
            <AlertTitle className="text-sm font-medium text-warn">Esecuzione non disponibile in riproduzione</AlertTitle>
            <AlertDescription className="text-xs">
              <p className="leading-relaxed text-text-2">
                Il motore di esecuzione per-dispositivo non è attivo in modalità riproduzione: le ondate
                nascono e restano DRAFT (pianificazione reale con preflight). Nessuna adozione automatica.
              </p>
            </AlertDescription>
          </Alert>

          {waves.isPending ? (
            <LoadingRows rows={3} />
          ) : waves.isError ? (
            <ErrorPanel
              message={errInfo(waves.error).message}
              code={errInfo(waves.error).code}
              onRetry={() => { void waves.refetch() }}
            />
          ) : (
            <>
              {lastCreate ? <WaveCreateOutcome r={lastCreate} /> : null}

              {items.length === 0 ? (
                <EmptyState
                  icon={<Layers className="size-10" aria-hidden />}
                  title="Nessuna ondata"
                  description="0 righe ConfigWave nel database reale. La prima nasce da «Nuova ondata»: preflight reale per ogni target, lotti col canary, stato DRAFT."
                  action={
                    <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                      <Plus className="size-3.5" aria-hidden /> Nuova ondata
                    </Button>
                  }
                />
              ) : (
                <div
                  className="max-h-[520px] space-y-3 overflow-y-auto scroll-thin pr-1"
                  role="region"
                  aria-label="Ondate pianificate, elenco scorribile"
                  tabIndex={0}
                >
                  {items.map((w) => (
                    <WaveCard
                      key={w.id}
                      wave={w}
                      onDelete={setDeleteTarget}
                      removePending={remove.isPending && remove.variables === w.id}
                    />
                  ))}
                </div>
              )}
              {waves.data ? <AsOf ts={waves.data.asOf} prefix="ondate alle" className="mt-1" /> : null}
            </>
          )}
        </CardContent>
      </Card>

      {/* --- Dialog: nuova ondata --- */}
      <Dialog
        open={createOpen}
        onOpenChange={(open) => {
          setCreateOpen(open)
          if (!open) resetCreateForm()
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuova ondata</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Pianificazione REALE nel DB: preflight per ogni target (scarti dichiarati con motivo),
              lotto 1 = canary, poi lotti da batchSize. L&apos;ondata nasce DRAFT: nessuna esecuzione
              automatica in riproduzione.
            </DialogDescription>
          </DialogHeader>

          <form
            className="grid gap-3"
            onSubmit={(e) => { e.preventDefault(); submitCreate() }}
            noValidate
            aria-label="Form di creazione ondata"
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="wave-name" className="text-xs font-medium text-text-2">Nome *</label>
                <Input
                  id="wave-name"
                  value={wName}
                  maxLength={200}
                  onChange={(e) => setWName(e.target.value)}
                  placeholder="es. Config IPv6 sedi nord"
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="wave-kind" className="text-xs font-medium text-text-2">Tipo *</label>
                <Select value={wKind} onValueChange={(v) => setWKind(v as 'CONFIG' | 'FIRMWARE')}>
                  <SelectTrigger id="wave-kind" className="w-full" aria-label="Tipo di ondata">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CONFIG">CONFIG · configurazione</SelectItem>
                    <SelectItem value="FIRMWARE">FIRMWARE · aggiornamento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="wave-action" className="text-xs font-medium text-text-2">Azione (opzionale)</label>
              <Input
                id="wave-action"
                value={wAction}
                maxLength={100}
                onChange={(e) => setWAction(e.target.value)}
                placeholder="es. applica template vlan25"
              />
            </div>

            {/* Selettore target: checkbox con filtro, limitato ai primi 100 */}
            <div className="grid gap-1.5">
              <label htmlFor="wave-search" className="text-xs font-medium text-text-2">
                Target · <span className="num">{fmtNumber(selectedIds.length)}</span> selezionati
              </label>
              <Input
                id="wave-search"
                type="search"
                value={wSearch}
                onChange={(e) => setWSearch(e.target.value)}
                placeholder="Filtra per hostname o IP…"
                aria-label="Filtro dei dispositivi target"
              />
              {devices.isPending ? (
                <LoadingRows rows={3} />
              ) : devices.isError ? (
                <ErrorPanel
                  message={errInfo(devices.error).message}
                  code={errInfo(devices.error).code}
                  onRetry={() => { void devices.refetch() }}
                />
              ) : (
                <div
                  className="max-h-60 overflow-y-auto scroll-thin rounded-lg border border-border/70"
                  role="region"
                  aria-label="Dispositivi target dell'ondata, elenco scorribile"
                  tabIndex={0}
                >
                  {filteredDevices.length === 0 ? (
                    <p className="px-3 py-4 text-center text-xs text-text-2">
                      Nessun dispositivo dell&apos;inventario corrisponde al filtro.
                    </p>
                  ) : (
                    filteredDevices.map((d) => (
                      <label
                        key={d.id}
                        className="flex cursor-pointer items-center gap-2.5 border-b border-border/40 px-3 py-2 last:border-0 hover:bg-raised/40"
                      >
                        <Checkbox
                          checked={selectedIds.includes(d.id)}
                          onCheckedChange={(c) => toggleDevice(d.id, c === true)}
                        />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-xs font-medium" title={d.hostname}>{d.hostname}</span>
                          <span className="block truncate text-xs text-text-2">
                            <span className="num">{d.ip}</span> · {typeLabel(d.type)}
                          </span>
                        </span>
                      </label>
                    ))
                  )}
                </div>
              )}
              <p className="text-xs text-text-2">
                Elenco limitato ai primi <span className="num">100</span> dispositivi dell&apos;inventario
                reale {devices.data ? `(di ${fmtNumber(devices.data.data.total)})` : ''}; selezionati{' '}
                <span className="num">{fmtNumber(selectedIds.length)}</span> (limite contratto: 500).
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="wave-batch" className="text-xs font-medium text-text-2">Dimensione lotto</label>
                <Input
                  id="wave-batch"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={50}
                  value={wBatch}
                  onChange={(e) => setWBatch(e.target.value)}
                  className="num"
                  aria-invalid={!batchValid}
                />
                <p className="text-xs text-text-2">1–50 dispositivi per lotto</p>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="wave-canary" className="text-xs font-medium text-text-2">Canary</label>
                <Input
                  id="wave-canary"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={10}
                  value={wCanary}
                  onChange={(e) => setWCanary(e.target.value)}
                  className="num"
                  aria-invalid={!canaryValid}
                />
                <p className="text-xs text-text-2">1–10 dispositivi nel lotto 1</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <Switch
                id="wave-dryrun"
                checked={wDryRun}
                onCheckedChange={setWDryRun}
                aria-label="Esecuzione in dry-run (consigliata)"
              />
              <label htmlFor="wave-dryrun" className="text-xs text-text-2">
                dry-run (consigliato): l&apos;esecuzione, quando il motore sarà attivo, non scriverà configurazioni
              </label>
            </div>
            <div className="flex items-center gap-2.5">
              <Switch
                id="wave-stop"
                checked={wStop}
                onCheckedChange={setWStop}
                aria-label="Arresta l'ondata al primo fallimento"
              />
              <label htmlFor="wave-stop" className="text-xs text-text-2">
                arresto al primo fallimento
              </label>
            </div>
          </form>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setCreateOpen(false); resetCreateForm() }}>
              Annulla
            </Button>
            <Button
              onClick={submitCreate}
              disabled={create.isPending || wName.trim().length === 0 || selectedIds.length === 0 || !batchValid || !canaryValid}
            >
              {create.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
              Pianifica ondata
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Conferma eliminazione ondata (solo DRAFT) --- */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o && !remove.isPending) setDeleteTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare l&apos;ondata «{deleteTarget?.name}»?</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Eliminazione REALE dal DB (ConfigWave e relative righe ConfigWaveItem), con voce di audit
              WAVE_DELETED. Consentita solo sulle ondate DRAFT: se lo stato è diverso il server rifiuta
              con INVALID_STATE e il messaggio viene mostrato tale e quale.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={remove.isPending}
              onClick={(e) => {
                e.preventDefault() // resta aperto finché la risposta reale non arriva
                if (!deleteTarget || remove.isPending) return
                remove.mutate(deleteTarget.id)
              }}
            >
              {remove.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

/* Esito della pianificazione: preflight per target, lotti (canary in
 * evidenza amber) e scarti — tutto dal payload REALE del server. */
function WaveCreateOutcome({ r }: { r: WaveCreateData }) {
  const hostById = new Map(r.preflight.map((p) => [p.deviceId, p.hostname]))
  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <CircleCheck className="size-4 text-ok" aria-hidden />
          Pianificazione di «{r.wave?.name ?? 'n.d.'}»
          {r.wave ? (
            <Badge variant="outline" className={cn('font-normal', WAVE_STATUS_META[r.wave.status]?.cls ?? 'border-border bg-raised text-text-2')}>
              {WAVE_STATUS_META[r.wave.status]?.label ?? r.wave.status}
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Preflight reale per ogni target e lotti pianificati: l&apos;ondata resta DRAFT
          (nessuna esecuzione automatica in modalità riproduzione).
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid gap-1.5">
          <p className="text-xs font-medium text-text-2">
            Preflight · <span className="num">{fmtNumber(r.preflight.length)}</span> target
          </p>
          <div
            className="max-h-40 overflow-y-auto scroll-thin rounded-md border border-border/70 bg-raised/30"
            role="region"
            aria-label="Esiti del preflight per target, elenco scorribile"
            tabIndex={0}
          >
            <ul className="space-y-1 p-2">
              {r.preflight.map((p) => (
                <li key={p.deviceId} className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 text-xs">
                  <span className="min-w-0 truncate font-mono" title={p.deviceId}>{p.hostname}</span>
                  {p.ok ? (
                    <Badge variant="outline" className="border-ok/40 bg-ok-soft font-normal text-ok">
                      <Check className="size-3" aria-hidden /> preflight superato
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="border-crit/40 bg-crit-soft font-normal text-crit-text">
                      <X className="size-3" aria-hidden /> {p.reason}
                    </Badge>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="grid gap-1.5">
          <p className="text-xs font-medium text-text-2">
            Lotti pianificati · <span className="num">{fmtNumber(r.batches.length)}</span>
          </p>
          {r.batches.map((b) => (
            <div
              key={b.number}
              className={cn(
                'flex flex-wrap items-baseline gap-x-2 gap-y-1 rounded-md border px-2.5 py-1.5 text-xs',
                b.isCanary ? 'border-warn/40 bg-warn-soft' : 'border-border/70 bg-raised/30',
              )}
            >
              <span className="font-medium">Lotto <span className="num">{fmtNumber(b.number)}</span></span>
              {b.isCanary ? (
                <Badge variant="outline" className="border-warn/40 bg-warn-soft font-medium text-warn">CANARY</Badge>
              ) : null}
              <span className="num text-text-2">
                {fmtNumber(b.deviceIds.length)} {b.deviceIds.length === 1 ? 'dispositivo' : 'dispositivi'}
              </span>
              <span className="min-w-0 flex-1 truncate text-text-2" title={b.deviceIds.map((id) => hostById.get(id) ?? id).join(', ')}>
                {b.deviceIds.map((id) => hostById.get(id) ?? id).join(', ')}
              </span>
            </div>
          ))}
        </div>

        <p className="text-xs text-text-2">
          Scarti al preflight: <span className="num font-medium text-foreground">{fmtNumber(r.scarti)}</span>
          {r.scarti > 0 ? ' (esclusi dai lotti, motivi elencati sopra)' : ' — nessun target escluso'}.
        </p>
      </CardContent>
    </Card>
  )
}

/* Card ondata: stato, conteggi reali e preflight espandibile
 * (collapsible: i motivi per target restano ispezionabili). */
function WaveCard({
  wave,
  onDelete,
  removePending,
}: {
  wave: WaveRow
  onDelete: (w: WaveRow) => void
  removePending: boolean
}) {
  const [preflightOpen, setPreflightOpen] = useState(false)
  const kind = WAVE_KIND_META[wave.kind] ?? { label: wave.kind, cls: 'border-border bg-raised text-text-2' }
  const status = WAVE_STATUS_META[wave.status] ?? { label: wave.status, cls: 'border-border bg-raised text-text-2' }
  const scarti = wave.preflight ? wave.preflight.filter((p) => !p.ok).length : null

  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <span className="min-w-0 break-words font-medium">{wave.name}</span>
          <Badge variant="outline" className={cn('font-normal', kind.cls)}>{kind.label}</Badge>
          <Badge variant="outline" className={cn('font-medium', status.cls)}>{status.label}</Badge>
          {wave.dryRun ? (
            <Badge variant="outline" className="border-border bg-raised font-normal text-text-2">dry-run</Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          creata {fmtDateTime(wave.createdAt)} ({fmtRelative(wave.createdAt)}) da {wave.createdBy}
          {wave.action ? ` · azione: ${wave.action}` : ''}
          {` · lotto da ${fmtNumber(wave.batchSize)} · canary ${fmtNumber(wave.canarySize)}`}
          {wave.stopOnFirstFailure ? ' · arresto al primo fallimento' : ''}
        </CardDescription>
        {wave.status === 'DRAFT' ? (
          <CardAction>
            <Button
              variant="ghost"
              size="icon"
              className="size-8 text-crit-text hover:text-crit-text"
              onClick={() => onDelete(wave)}
              disabled={removePending}
              aria-label={`Elimina l'ondata ${wave.name}`}
            >
              <Trash2 className="size-3.5" aria-hidden />
            </Button>
          </CardAction>
        ) : null}
      </CardHeader>
      <CardContent className="space-y-2.5">
        <p className="text-xs text-text-2">
          target totali <span className="num font-medium text-foreground">{fmtNumber(wave.counts.total)}</span>
          {' · '}canary <span className="num">{fmtNumber(wave.counts.canary)}</span>
          {' · '}in attesa <span className="num">{fmtNumber(wave.counts.pending)}</span>
          {' · '}scarti al preflight {scarti == null ? 'n.d.' : <span className="num">{fmtNumber(scarti)}</span>}
          {wave.counts.applied > 0 ? ` · applicati ${fmtNumber(wave.counts.applied)}` : ''}
          {wave.counts.failed > 0 ? ` · falliti ${fmtNumber(wave.counts.failed)}` : ''}
          {wave.counts.skipped > 0 ? ` · saltati ${fmtNumber(wave.counts.skipped)}` : ''}
        </p>

        {wave.preflight ? (
          <Collapsible open={preflightOpen} onOpenChange={setPreflightOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 text-xs text-text-2">
                <ChevronsUpDown className="size-3.5" aria-hidden />
                Preflight · <span className="num">{fmtNumber(wave.preflight.length)}</span> target
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <ul className="mt-1 space-y-1 rounded-md border border-border/70 bg-raised/30 p-2">
                {wave.preflight.map((p) => (
                  <li key={p.deviceId} className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 text-xs">
                    <span className="min-w-0 truncate font-mono" title={p.deviceId}>{p.hostname}</span>
                    {p.ok ? (
                      <Badge variant="outline" className="border-ok/40 bg-ok-soft font-normal text-ok">
                        <Check className="size-3" aria-hidden /> {p.reason}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="border-crit/40 bg-crit-soft font-normal text-crit-text">
                        <X className="size-3" aria-hidden /> {p.reason}
                      </Badge>
                    )}
                  </li>
                ))}
              </ul>
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <p className="text-xs text-text-2">
            Preflight non disponibile per quest&apos;ondata (NULL nel DB, dichiarato).
          </p>
        )}
      </CardContent>
    </Card>
  )
}
