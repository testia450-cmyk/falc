/* Indicatore di obsolescenza/origine del dato (regola §2.1-2.2):
 * ogni numero mostra QUANDO è stato acquisito e se è riprodotto. */

'use client'

import { Clock, RefreshCw, History } from 'lucide-react'
import { fmtRelative, fmtTime } from '@/lib/client/format'
import { cn } from '@/lib/utils'

export function AsOf({
  ts,
  prefix = 'aggiornato alle',
  className,
}: {
  ts: number | null | undefined
  prefix?: string
  className?: string
}) {
  return (
    <span className={cn('inline-flex items-center gap-1 text-xs text-text-2 num', className)}>
      <Clock className="size-3" aria-hidden />
      {prefix} {fmtTime(ts)}
    </span>
  )
}

export function StaleIndicator({ stale, lastSeenAt }: { stale: boolean; lastSeenAt: number | null }) {
  if (!stale) return null
  return (
    <span className="inline-flex items-center gap-1 text-xs text-warn" title={`Dato obsoleto: ultima vista ${fmtRelative(lastSeenAt)}`}>
      <History className="size-3" aria-hidden />
      obsoleto ({fmtRelative(lastSeenAt)})
    </span>
  )
}

/** Badge «Modalità riproduzione» — onestà D2: sempre visibile quando attiva */
export function ReplayBadge({ mode, importedAt }: { mode: 'replay' | 'static'; importedAt?: number | null }) {
  if (mode === 'static') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md border border-warn/40 bg-warn-soft px-2 py-0.5 text-xs font-medium text-warn">
        <History className="size-3.5" aria-hidden />
        Fermo immagine (realtime non attivo)
      </span>
    )
  }
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-md border border-info/40 bg-info-soft px-2 py-0.5 text-xs font-medium text-info"
      title={importedAt ? `Dati reali importati dal DB di produzione il ${new Date(importedAt).toLocaleString('it-IT')}` : undefined}
    >
      <RefreshCw className="size-3.5" aria-hidden />
      Modalità riproduzione
    </span>
  )
}
