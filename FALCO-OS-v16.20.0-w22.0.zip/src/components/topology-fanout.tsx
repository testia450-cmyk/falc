/* ================================================================
 * FALCO-OS v16.11 — Topologia «a raggiera» (vista Rete, W9)
 *
 * Richiesta operatore (immagine di riferimento): radice a sinistra,
 * card delle sedi impilate a destra, linee tratteggiate colorate per
 * stato, conteggio dispositivi per sede, dispositivi giù con testo
 * sfumato. Questa è quella rappresentazione, sui dati REALI del
 * contratto /api/v2/topology/graph (nessun nodo inventato):
 *
 *  · ROOT: la radice dell'albero (gateway scelto o inferito) in una
 *    card prominente, centrata verticalmente rispetto alla colonna;
 *  · CARD SEDE: i dispositivi dell'albero raggruppati per la SEDE in
 *    cui si trovano (la propria locationId, non il percorso): icona
 *    torre radio colorata per lo stato aggregato, nome bold, conteggi
 *    «M/N online · K offline», chevron per espandere i dispositivi;
 *  · CONNETTORI: bezier tratteggiate SVG misurate dal vivo (root →
 *    bordo sinistro di ogni card), colore = stato peggiore della sede
 *    (verde online · ambra degradato/sconosciuto · rosso offline);
 *    su mobile la riga tratteggiata verticale della lista fa lo stesso
 *    lavoro (l'SVG è nascosto sotto md);
 *  · ESPANSIONE: ogni card sede elenca i suoi dispositivi (punto di
 *    stato, hostname, tipo/modello, segnale radio, badge «N a valle»,
 *    chip della FONTE del collegamento in ingresso → dettaglio arco);
 *    un dispositivo con figli si espande a sua volta in sottogruppi
 *    per sede indentati (alberi profondi restano navigabili);
 *  · FUORI ALBERO: i dispositivi non raggiunti dalla radice con le
 *    fonti scelte stanno in una sezione separata e dichiarata (mai
 *    nascosti, mai appesi alla radice a caso);
 *  · «Espandi tutto / Comprimi tutto» per le 41 sedi dell'impianto
 *    reale senza click a raffica.
 *
 * Onestà (D2/W8): l'albero è quello calcolato dai collegamenti in
 * inventario per le famiglie di fonti attive — qui si RAPPRESENTA, la
 * correzione delle letture resta nella gestione collegamenti.
 * ================================================================ */

'use client'

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { RadioTower, ChevronDown, ChevronRight, MapPin, Signal, ArrowDown, AlertTriangle, Network, UnfoldVertical, FoldVertical } from 'lucide-react'
import { useApp } from '@/lib/client/store'
import { fmtDbm, typeLabel, STATUS_META } from '@/lib/client/format'
import { usePalette, statusColor, type ThemePalette } from '@/lib/client/theme-palette'
import { Button } from '@/components/ui/button'
import { EmptyState } from '@/components/states'
import { cn } from '@/lib/utils'
import type { TopoGraphData, TopoNode, TopoEdge } from './topology-view'

/* ---------------- Tipi e derivazioni pure ---------------- */

/** Salute aggregata di un insieme di dispositivi. */
type Health = 'ok' | 'warn' | 'crit' | 'info'

/** Colore palette dalla salute (verde/ambra/rosso/blu). */
function healthColor(h: Health, p: ThemePalette): string {
  return h === 'ok' ? p.ok : h === 'warn' ? p.warn : h === 'crit' ? p.crit : p.info
}

/** Salute peggiore di un gruppo di dispositivi (crit > warn > info > ok). */
function healthOf(devices: TopoNode[]): Health {
  let crit = 0
  let warn = 0
  let info = 0
  for (const d of devices) {
    const s = d.uiStatus
    if (s === 'OFFLINE' || s === 'NOT_MONITORED') crit += 1
    else if (s === 'DEGRADED' || s === 'UNKNOWN') warn += 1
    else if (s === 'MAINTENANCE') info += 1
  }
  if (crit > 0) return 'crit'
  if (warn > 0) return 'warn'
  if (info > 0) return 'info'
  return 'ok'
}

/** Ordine di famiglia per l'elenco dispositivi dentro una card
 * (infrastruttura → radio → video → altro; specchia il grafo W8). */
const TYPE_RANK: Record<string, number> = {
  GATEWAY: 0, ROUTER: 1, FIREWALL: 2, SWITCH: 3,
  AP: 10, STA: 11,
  NVR: 20, CAMERA: 21, LPR: 22,
  SERVER: 30,
}

function sortDevices(devices: TopoNode[]): TopoNode[] {
  return [...devices].sort((a, b) => {
    const ra = TYPE_RANK[a.type] ?? 90
    const rb = TYPE_RANK[b.type] ?? 90
    if (ra !== rb) return ra - rb
    return a.hostname.localeCompare(b.hostname, 'it')
  })
}

/** Un gruppo di dispositivi della stessa sede. */
interface LocGroup {
  key: string
  name: string
  devices: TopoNode[]
  total: number
  online: number
  down: number
  degraded: number
  health: Health
}

/** Raggruppa i dispositivi per sede (la PROPRIA: il punto di ripresa,
 * non il percorso nell'albero) e ordina per nome. */
function groupByLocation(devices: TopoNode[]): LocGroup[] {
  const byLoc = new Map<string, TopoNode[]>()
  for (const d of devices) {
    const key = d.locationId ?? '__senza-sede'
    const list = byLoc.get(key)
    if (list) list.push(d)
    else byLoc.set(key, [d])
  }
  const groups: LocGroup[] = []
  for (const [key, list] of byLoc) {
    const name = list[0]?.locationName ?? (key === '__senza-sede' ? 'Senza sede' : key)
    let online = 0
    let down = 0
    let degraded = 0
    for (const d of list) {
      if (d.uiStatus === 'ONLINE') online += 1
      else if (d.uiStatus === 'OFFLINE' || d.uiStatus === 'NOT_MONITORED') down += 1
      else degraded += 1
    }
    groups.push({
      key,
      name,
      devices: sortDevices(list),
      total: list.length,
      online,
      down,
      degraded,
      health: healthOf(list),
    })
  }
  return groups.sort((a, b) => a.name.localeCompare(b.name, 'it'))
}

/** Fonte (famiglia) dell'arco in ingresso, badge del chip sul device. */
function incomingFamily(e: TopoEdge | undefined): string {
  if (!e) return ''
  if (e.manual) return 'operatore'
  const ev = (e.evidence ?? '').toUpperCase()
  if (ev.includes('LLDP')) return 'LLDP'
  if (ev.includes('MNDP')) return 'MNDP'
  if (ev.includes('UISP')) return 'UISP'
  if (ev.includes('BRIDGE_MIB')) return 'BRIDGE_MIB'
  if (ev.includes('FDB')) return 'FDB'
  if (ev.includes('DAISY_CHAIN')) return 'DAISY_CHAIN'
  return ev || 'archivio'
}

/* ---------------- Props ---------------- */

export interface TopologyFanoutProps {
  /** Dati REALE del contratto /api/v2/topology/graph (già caricati). */
  data: TopoGraphData
  /** Notifica la selezione di un arco (chip della fonte su un device). */
  onSelectEdge?: (edgeId: string | null) => void
  className?: string
}

/* ---------------- Componente principale ---------------- */

export default function TopologyFanout({ data, onSelectEdge, className }: TopologyFanoutProps) {
  const set = useApp((s) => s.set)
  const topologyNode = useApp((s) => s.topologyNode)
  const p = usePalette()

  /* --- derivazioni (dati puri, memo) --- */
  const root = useMemo(
    () => (data.gatewayId ? data.nodes.find((n) => n.id === data.gatewayId) ?? null : null),
    [data],
  )
  const { groups, outOfTree, childrenOf, incomingEdge } = useMemo(() => {
    const nodesById = new Map(data.nodes.map((n) => [n.id, n]))
    const children = new Map<string, TopoNode[]>()
    const incoming = new Map<string, TopoEdge>()
    for (const e of data.edges) {
      const target = nodesById.get(e.target)
      /* nodi "fantasma" mai: il contratto espone solo coppie con entrambi
       * gli endpoint nell'inventario, ma la guardia resta (onestà). */
      if (!target) continue
      const list = children.get(e.source)
      if (list) list.push(target)
      else children.set(e.source, [target])
      if (!incoming.has(e.target)) incoming.set(e.target, e)
    }
    const inTree = data.gatewayId
      ? data.nodes.filter((n) => n.id !== data.gatewayId && n.tier >= 0)
      : []
    const out = data.gatewayId
      ? data.nodes.filter((n) => n.id !== data.gatewayId && n.tier < 0)
      : data.nodes
    return { groups: groupByLocation(inTree), outOfTree: out, childrenOf: children, incomingEdge: incoming }
  }, [data])

  const selectedNodeId = topologyNode

  /* --- espansione (card sedi + device con figli) --- */
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [layoutTick, setLayoutTick] = useState(0)
  const toggleKey = useCallback((key: string) => {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }))
    setLayoutTick((t) => t + 1)
  }, [])

  const allExpandable = useMemo(
    () => [
      ...groups.map((g) => g.key),
      ...data.nodes.filter((n) => (childrenOf.get(n.id)?.length ?? 0) > 0).map((n) => n.id),
    ],
    [groups, data.nodes, childrenOf],
  )
  const allOpen = allExpandable.length > 0 && allExpandable.every((k) => expanded[k])

  const expandAll = useCallback(() => {
    const next: Record<string, boolean> = {}
    for (const k of allExpandable) next[k] = true
    setExpanded(next)
    setLayoutTick((t) => t + 1)
  }, [allExpandable])
  const collapseAll = useCallback(() => {
    setExpanded({})
    setLayoutTick((t) => t + 1)
  }, [])

  /* --- selezione nodo (quick-look, stesso contratto del grafo) --- */
  const selectNode = useCallback(
    (id: string) => {
      set({ topologyNode: id, deviceId: id })
      onSelectEdge?.(null)
    },
    [set, onSelectEdge],
  )

  /* --- connettori SVG misurati dal vivo (solo desktop md+) --- */
  const wrapRef = useRef<HTMLDivElement>(null)
  const rootRef = useRef<HTMLDivElement>(null)
  const cardRefs = useRef<Map<string, HTMLDivElement>>(new Map())
  const [paths, setPaths] = useState<{ key: string; d: string; color: string }[]>([])
  const healthByKey = useMemo(() => new Map(groups.map((g) => [g.key, g.health])), [groups])

  const measure = useCallback(() => {
    const wrap = wrapRef.current
    const rootEl = rootRef.current
    if (!wrap || !rootEl) return
    const wrapRect = wrap.getBoundingClientRect()
    /* Doppiò gate, coerente col CSS: riga solo a viewport md (768, come
     * Tailwind) E contenitore largo (sidebar+aside restringono la vista a
     * ~650px anche a schermo intero; sotto 520 la raggiera verticale con
     * riga tratteggiata CSS fa lo stesso lavoro). */
    const rowLayout = typeof window !== 'undefined' && window.matchMedia('(min-width: 768px)').matches
    if (!rowLayout || wrapRect.width < 520) {
      setPaths((prev) => (prev.length === 0 ? prev : []))
      return
    }
    const rootRect = rootEl.getBoundingClientRect()
    const x1 = rootRect.right - wrapRect.left
    const y1 = rootRect.top + rootRect.height / 2 - wrapRect.top
    const next: { key: string; d: string; color: string }[] = []
    for (const [key, el] of cardRefs.current) {
      const r = el.getBoundingClientRect()
      if (r.width === 0) continue
      const x2 = r.left - wrapRect.left
      const y2 = r.top + r.height / 2 - wrapRect.top
      const dx = Math.max(48, (x2 - x1) * 0.42)
      next.push({
        key,
        d: `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`,
        color: healthColor(healthByKey.get(key) ?? 'ok', p),
      })
    }
    setPaths((prev) => {
      if (prev.length === next.length && prev.every((q, i) => q.d === next[i].d && q.color === next[i].color)) return prev
      return next
    })
  }, [healthByKey, p])

  useLayoutEffect(() => {
    const raf = requestAnimationFrame(() => measure())
    return () => cancelAnimationFrame(raf)
  }, [measure, layoutTick, groups])

  useEffect(() => {
    const wrap = wrapRef.current
    if (!wrap || typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver(() => measure())
    ro.observe(wrap)
    return () => ro.disconnect()
  }, [measure])

  const setCardRef = useCallback((key: string, el: HTMLDivElement | null) => {
    if (el) cardRefs.current.set(key, el)
    else cardRefs.current.delete(key)
  }, [])

  /* --- contatori complessivi --- */
  const totals = useMemo(() => {
    let online = 0
    let down = 0
    let degraded = 0
    for (const g of groups) {
      online += g.online
      down += g.down
      degraded += g.degraded
    }
    return { total: groups.reduce((a, g) => a + g.total, 0), online, down, degraded }
  }, [groups])

  /* --- nessuna radice: stato onesto (non si inventa una raggiera) --- */
  if (!root) {
    return (
      <EmptyState
        className={cn('min-h-[520px]', className)}
        icon={<Network className="size-10" aria-hidden />}
        title="Nessuna radice per la raggiera"
        description={
          data.nodes.length === 0
            ? 'Nessun dispositivo in inventario: la topologia è vuota.'
            : 'Nessun gateway né radice scelta: imposta la radice nel pannello dettaglio di un dispositivo o apri la gestione collegamenti.'
        }
      />
    )
  }

  const rootColor = statusColor(root.uiStatus, p)

  /* ---------------- Render ---------------- */

  return (
    <div ref={wrapRef} className={cn('relative w-full', className)}>
      {/* Connettori tratteggiati (desktop): sotto le card, misurati dal vivo */}
      <svg
        className="pointer-events-none absolute inset-0 z-0 hidden h-full w-full md:block"
        aria-hidden="true"
        focusable="false"
      >
        {paths.map((q) => (
          <path
            key={q.key}
            d={q.d}
            fill="none"
            stroke={q.color}
            strokeWidth={2}
            strokeDasharray="7 5"
            strokeLinecap="round"
            opacity={0.85}
          />
        ))}
      </svg>

      <div className="relative z-10 flex flex-col gap-5 md:flex-row md:items-center md:gap-[7%]">
        {/* --- Card radice (sinistra, centrata verticalmente) --- */}
        <div
          ref={rootRef}
          className={cn(
            'w-full shrink-0 rounded-lg border bg-surface p-4 shadow-md md:w-52',
            root.uiStatus === 'ONLINE' ? 'border-ok/40' : 'border-border',
          )}
        >
          <div className="flex items-start gap-3">
            <span
              className="flex size-11 shrink-0 items-center justify-center rounded-full border"
              style={{ borderColor: `${rootColor}66`, background: `${rootColor}14`, color: rootColor }}
              aria-hidden
            >
              <RadioTower className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1.5 text-sm font-semibold leading-tight">
                <span className="size-2 shrink-0 rounded-full" style={{ background: rootColor }} aria-hidden />
                <span className="truncate" title={root.hostname}>{root.hostname}</span>
              </p>
              <p className="mt-0.5 truncate text-xs text-text-2">
                {typeLabel(root.type)}{root.ip ? ` · ${root.ip}` : ''}
              </p>
            </div>
          </div>
          <p className="mt-3 text-[10px] font-semibold uppercase tracking-wider text-text-2">
            {data.rootSource === 'operator' ? 'Radice scelta dall’operatore' : data.rootSource === 'inferred' ? 'Radice inferita (gateway)' : 'Radice'}
          </p>
          <p className="num mt-1 text-xs text-text-2">
            {totals.total} dispositivi · {totals.online} online
            {totals.down > 0 ? ` · ${totals.down} giù` : ''}
            {totals.degraded > 0 ? ` · ${totals.degraded} degradati` : ''}
          </p>
          <p className="mt-1 text-xs text-text-2">
            {groups.length} sedi in raggiera
            {outOfTree.length > 0 ? ` · ${outOfTree.length} fuori albero` : ''}
          </p>
        </div>

        {/* --- Colonna card sedi (destra) --- */}
        <div className="flex min-w-0 flex-1 flex-col gap-2.5">
          {/* intestazione: contatori + espandi/comprimi + mini legenda */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <p className="num text-[11px] text-text-2">
              {groups.length} sedi · {totals.total} dispositivi · {totals.online} online · {totals.down} giù · {totals.degraded} degradati
            </p>
            <span className="mx-0.5 h-3 w-px bg-border" aria-hidden />
            <span className="flex items-center gap-1 text-[10px] text-text-2"><span className="size-2 rounded-full" style={{ background: p.ok }} aria-hidden />online</span>
            <span className="flex items-center gap-1 text-[10px] text-text-2"><span className="size-2 rounded-full" style={{ background: p.warn }} aria-hidden />degradata</span>
            <span className="flex items-center gap-1 text-[10px] text-text-2"><span className="size-2 rounded-full" style={{ background: p.crit }} aria-hidden />offline</span>
            <span className="ml-auto flex items-center gap-1">
              <Button
                type="button" variant="outline" size="sm"
                className="h-7 px-2 text-xs"
                onClick={allOpen ? collapseAll : expandAll}
                aria-label={allOpen ? 'Comprimi tutte le sedi e i dispositivi' : 'Espandi tutte le sedi'}
                title={allOpen ? 'Comprimi tutto' : 'Espandi tutto'}
              >
                {allOpen ? <FoldVertical className="size-3.5" aria-hidden /> : <UnfoldVertical className="size-3.5" aria-hidden />}
                <span className="hidden sm:inline">{allOpen ? 'Comprimi tutto' : 'Espandi tutto'}</span>
              </Button>
            </span>
          </div>

          {/* lista card: riga tratteggiata verticale su mobile (connessione visiva alla radice) */}
          <div
            className="flex flex-col gap-2.5 border-l border-dashed border-control-border/60 pl-4 md:border-l-0 md:pl-0"
            role="tree"
            aria-label={`Raggiera per sede: ${groups.length} sedi, ${totals.total} dispositivi`}
          >
            {groups.map((g) => {
              const open = !!expanded[g.key]
              const color = healthColor(g.health, p)
              const downGroup = g.health === 'crit'
              return (
                <div
                  key={g.key}
                  ref={(el) => setCardRef(g.key, el)}
                  className={cn(
                    'overflow-hidden rounded-lg border bg-surface shadow-sm transition-colors',
                    downGroup ? 'border-crit/30' : g.health === 'ok' ? 'border-ok/25' : 'border-warn/30',
                  )}
                >
                  <button
                    type="button"
                    role="treeitem"
                    aria-expanded={open}
                    aria-selected={false}
                    onClick={() => toggleKey(g.key)}
                    className="flex w-full items-center gap-3 p-3 text-left transition-colors hover:bg-raised/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    aria-label={`${g.name}: ${g.total} dispositivi, ${g.online} online${g.down > 0 ? `, ${g.down} offline` : ''}${g.degraded > 0 ? `, ${g.degraded} degradati` : ''}. ${open ? 'Comprimi' : 'Espandi'}.`}
                  >
                    <span
                      className="flex size-10 shrink-0 items-center justify-center rounded-full border"
                      style={{ borderColor: `${color}66`, background: `${color}14`, color }}
                      aria-hidden
                    >
                      <RadioTower className="size-5" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className={cn(
                        'flex items-center gap-1.5 text-[13px] font-semibold leading-tight',
                        downGroup && 'text-text-2',
                      )}>
                        <span className="truncate" title={g.name}>{g.name}</span>
                        {downGroup ? (
                          <span className="shrink-0 rounded-full border border-crit/40 bg-crit-soft px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-crit-text">
                            giù
                          </span>
                        ) : g.health === 'warn' ? (
                          <span className="shrink-0 rounded-full border border-warn/40 bg-warn-soft px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-warn">
                            {g.down > 0 ? 'parziale' : 'degradata'}
                          </span>
                        ) : null}
                      </span>
                      <span className={cn('mt-0.5 block truncate text-[11px] leading-tight', downGroup ? 'text-text-2/70' : 'text-text-2')}>
                        {g.total} dispositivi · {g.online}/{g.total} online
                        {g.down > 0 ? ` · ${g.down} offline` : ''}
                        {g.degraded > 0 ? ` · ${g.degraded} degradati` : ''}
                      </span>
                    </span>
                    <span className="shrink-0 text-text-2" aria-hidden>
                      {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
                    </span>
                  </button>

                  {open ? (
                    <div role="group" aria-label={`Dispositivi della sede ${g.name}`}>
                      {g.devices.map((d) => (
                        <DeviceRow
                          key={d.id}
                          node={d}
                          depth={0}
                          expanded={expanded}
                          onToggle={toggleKey}
                          onSelect={selectNode}
                          selectedId={selectedNodeId}
                          childrenOf={childrenOf}
                          incomingEdge={incomingEdge}
                          onSelectEdge={onSelectEdge}
                        />
                      ))}
                    </div>
                  ) : null}
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* --- Fuori albero (onesta sezione separata) --- */}
      {outOfTree.length > 0 ? (
        <div className="mt-6 rounded-lg border border-dashed border-border p-3">
          <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-text-2">
            <AlertTriangle className="size-3.5 text-warn" aria-hidden />
            Fuori dall’albero · {outOfTree.length} dispositivi non raggiunti
          </p>
          <p className="mt-1 text-xs text-text-2">
            Esistono in inventario ma nessun collegamento delle fonti attive li aggancia alla radice:
            cambiano fonte, conferma un collegamento nella gestione, oppure resta così (reale).
          </p>
          <div className="mt-2 flex flex-col">
            {sortDevices(outOfTree).map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => selectNode(d.id)}
                className="flex items-center gap-2.5 border-t border-border/60 px-1 py-1.5 text-left text-xs transition-colors hover:bg-raised/50"
                aria-label={`Seleziona ${d.hostname}, non raggiunto dall'albero`}
              >
                <span className="size-2 shrink-0 rounded-full" style={{ background: statusColor(d.uiStatus, p) }} aria-hidden />
                <span className="truncate font-medium">{d.hostname}</span>
                <span className="truncate text-text-2">
                  {typeLabel(d.type)}{d.locationName ? ` · ${d.locationName}` : ' · senza sede'}
                </span>
                <span className="ml-auto shrink-0 rounded-full border border-border px-1.5 py-0.5 text-[9px] uppercase tracking-wide text-text-2">
                  non raggiunto
                </span>
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  )
}

/* ---------------- Riga dispositivo (ricorsiva sui figli) ---------------- */

function DeviceRow({
  node,
  depth,
  expanded,
  onToggle,
  onSelect,
  selectedId,
  childrenOf,
  incomingEdge,
  onSelectEdge,
}: {
  node: TopoNode
  depth: number
  expanded: Record<string, boolean>
  onToggle: (key: string) => void
  onSelect: (id: string) => void
  selectedId: string | null
  childrenOf: Map<string, TopoNode[]>
  incomingEdge: Map<string, TopoEdge>
  onSelectEdge?: (edgeId: string | null) => void
}) {
  const p = usePalette()
  const color = statusColor(node.uiStatus, p)
  const children = childrenOf.get(node.id) ?? []
  const childOpen = !!expanded[node.id] && children.length > 0
  const inc = incomingEdge.get(node.id)
  const family = incomingFamily(inc)
  const isRadio = node.type === 'AP' || node.type === 'STA'
  const selected = selectedId === node.id

  return (
    <>
      <div
        className={cn(
          'flex items-center gap-2.5 border-t border-border/60 py-1.5 pl-3 pr-3 transition-colors',
          depth > 0 && 'pl-6',
          selected ? 'bg-raised/70' : 'hover:bg-raised/40',
        )}
      >
        <button
          type="button"
          role="treeitem"
          aria-selected={selected}
          onClick={() => onSelect(node.id)}
          className="flex min-w-0 flex-1 items-center gap-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          title={`${node.hostname} · ${node.ip || 'n.d.'} · ${STATUS_META[node.uiStatus]?.label ?? node.uiStatus}`}
          aria-label={`Seleziona ${node.hostname}: ${typeLabel(node.type)}, ${STATUS_META[node.uiStatus]?.label ?? node.uiStatus}${children.length > 0 ? `, ${children.length} dispositivi a valle` : ''}`}
        >
          <span className="size-2 shrink-0 rounded-full" style={{ background: color }} aria-hidden />
          <span className={cn('truncate text-[13px] font-medium leading-tight', node.uiStatus === 'OFFLINE' || node.uiStatus === 'NOT_MONITORED' ? 'text-text-2' : '')}>
            {node.hostname}
          </span>
          <span className="hidden truncate text-[11px] text-text-2 sm:inline">
            {typeLabel(node.type)}{node.model ? ` · ${node.model}` : ''}
          </span>
          {isRadio && node.signalDbm != null ? (
            <span className="num hidden shrink-0 items-center gap-1 text-[11px] text-text-2 md:inline-flex">
              <Signal className="size-3" aria-hidden />
              {fmtDbm(node.signalDbm)}
            </span>
          ) : null}
          {node.downstreamCount > 0 ? (
            <span className="num inline-flex shrink-0 items-center gap-0.5 rounded-full border border-border bg-raised/60 px-1.5 py-0.5 text-[10px] text-text-2">
              <ArrowDown className="size-2.5" aria-hidden />
              {node.downstreamCount} a valle
            </span>
          ) : null}
        </button>

        {/* chip della FONTE del collegamento in ingresso → dettaglio arco */}
        {inc ? (
          <button
            type="button"
            onClick={() => onSelectEdge?.(inc.id)}
            className="shrink-0 rounded-full border border-border bg-surface px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wide text-text-2 transition-colors hover:border-control-border hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            title={`Collegamento in ingresso · fonte: ${family}${inc.linkType ? ` · ${inc.linkType}` : ''} — apri dettaglio arco`}
            aria-label={`Fonte del collegamento verso ${node.hostname}: ${family}. Apri dettaglio arco`}
          >
            {family}
          </button>
        ) : null}

        {children.length > 0 ? (
          <button
            type="button"
            onClick={() => onToggle(node.id)}
            aria-expanded={childOpen}
            className="shrink-0 text-text-2 transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={childOpen ? `Comprimi i ${children.length} dispositivi a valle di ${node.hostname}` : `Espandi i ${children.length} dispositivi a valle di ${node.hostname}`}
          >
            {childOpen ? <ChevronDown className="size-4" aria-hidden /> : <ChevronRight className="size-4" aria-hidden />}
          </button>
        ) : null}
      </div>

      {/* figli raggruppati per sede, indentati con guida tratteggiata */}
      {childOpen ? (
        <div className="ml-6 border-l border-dashed border-control-border/50 pl-2 sm:ml-8">
          {groupByLocation(children).map((sub) => (
            <div key={sub.key} className="py-0.5">
              <p className="flex items-center gap-1.5 px-1 py-1 text-[10px] font-semibold uppercase tracking-wider text-text-2">
                <MapPin className="size-3" aria-hidden />
                <span className="truncate">{sub.name}</span>
                <span className="num font-normal normal-case tracking-normal">
                  {sub.online}/{sub.total} online
                </span>
              </p>
              {sub.devices.map((c) => (
                <DeviceRow
                  key={c.id}
                  node={c}
                  depth={depth + 1}
                  expanded={expanded}
                  onToggle={onToggle}
                  onSelect={onSelect}
                  selectedId={selectedId}
                  childrenOf={childrenOf}
                  incomingEdge={incomingEdge}
                  onSelectEdge={onSelectEdge}
                />
              ))}
            </div>
          ))}
        </div>
      ) : null}
    </>
  )
}
