/* ================================================================
 * FALCO-OS v16 — Sezione «OID custom» (16.7 ondata W3.5)
 * Tab 3 della vista Amministrazione: definizione degli OID SNMP
 * personalizzati che estendono il polling con metriche vendor
 * specifiche (es. CCQ Ubiquiti 1.3.6.1.4.1.41112.1.4), e test SNMP
 * REALE su un dispositivo dell'inventario: in sandbox la rete
 * dell'impianto non è instradabile → timeout ONESTO, mai un valore
 * inventato. appliedCount è sempre dichiarato (0 in replay: nessuna
 * applicazione finta).
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { FlaskConical, Loader2, Plus, RadioTower, RefreshCw, Trash2 } from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { api, ApiError } from '@/lib/client/api'
import { fmtDateTimeFull, fmtNumber, fmtRelative } from '@/lib/client/format'
import type { CreateCustomOidInput, CustomOidRow, CustomOidTestResult } from '@/lib/v2/contracts'
import { cn } from '@/lib/utils'

/* ---------------- Costanti sezione ---------------- */

/* Tipi dato del vocabolario backend (enum dei contratti, raw in badge) */
const DATA_TYPES: ReadonlyArray<'FLOAT' | 'INT' | 'COUNTER'> = ['FLOAT', 'INT', 'COUNTER']

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* ================================================================
 * Sezione OID custom (tab 3 Amministrazione)
 * ================================================================ */

export default function CustomOidsSection() {
  return (
    <div className="grid min-w-0 grid-cols-1 gap-4">
      <CustomOidsCard />
    </div>
  )
}

function CustomOidsCard() {
  const queryClient = useQueryClient()
  const oids = useQuery({
    queryKey: ['custom-oids'],
    queryFn: () => api.customOids(),
    staleTime: 30_000,
  })

  const items = oids.data?.data.items ?? []
  const total = oids.data?.data.total ?? 0

  /* --- Dialog creazione --- */
  const [createOpen, setCreateOpen] = useState(false)
  const [coName, setCoName] = useState('')
  const [coOid, setCoOid] = useState('')
  const [coUnit, setCoUnit] = useState('')
  const [coScale, setCoScale] = useState('1')
  const [coDataType, setCoDataType] = useState<'FLOAT' | 'INT' | 'COUNTER'>('FLOAT')
  const [coInterval, setCoInterval] = useState('300')
  const [coDescription, setCoDescription] = useState('')
  const [coEnabled, setCoEnabled] = useState(true)

  /* --- Dialog test SNMP --- */
  const [testTarget, setTestTarget] = useState<CustomOidRow | null>(null)
  const [testDeviceId, setTestDeviceId] = useState('')
  const [testResult, setTestResult] = useState<CustomOidTestResult | null>(null)

  /* --- Eliminazione --- */
  const [deleteTarget, setDeleteTarget] = useState<CustomOidRow | null>(null)

  /* Dispositivi per il test: primi 50 dell'inventario reale
   * (caricati solo quando serve il selettore) */
  const devices = useQuery({
    queryKey: ['devices', 1, 50],
    queryFn: () => api.devices({ page: 1, pageSize: 50 }),
    staleTime: 60_000,
    enabled: !!testTarget,
  })
  const deviceList = devices.data?.data.items ?? []

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['custom-oids'] })
  }

  const resetCreateForm = () => {
    setCoName('')
    setCoOid('')
    setCoUnit('')
    setCoScale('1')
    setCoDataType('FLOAT')
    setCoInterval('300')
    setCoDescription('')
    setCoEnabled(true)
  }

  const create = useMutation({
    mutationFn: (input: CreateCustomOidInput) => api.createCustomOid(input),
    onSuccess: (row) => {
      toast.success('OID custom creato', {
        description: `«${row.name}» (${row.oid}): estende il polling SNMP con una metrica vendor. Testabile subito su un dispositivo reale.`,
      })
      resetCreateForm()
      setCreateOpen(false)
      invalidate()
      /* Flusso ondata 16.7: dopo la creazione apre subito il test SNMP */
      testRun.reset()
      setTestResult(null)
      setTestDeviceId('')
      setTestTarget(row)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const toggleEnabled = useMutation({
    mutationFn: (input: { id: string; enabled: boolean }) => api.updateCustomOid(input.id, { enabled: input.enabled }),
    onSuccess: (row) => {
      toast.success(row.enabled ? 'OID attivato' : 'OID disattivato', {
        description: `«${row.name}»: ${row.enabled ? 'incluso' : 'escluso'} dal polling (update REALE nel DB).`,
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Cambio stato non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const testRun = useMutation({
    mutationFn: (input: { id: string; deviceId: string }) => api.testCustomOid(input.id, input.deviceId),
    onSuccess: (r) => setTestResult(r),
    /* L'errore è mostrato nel dialog di esito (nessun doppio avviso) */
    onError: () => { /* gestito nel dialog con ErrorPanel */ },
  })

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteCustomOid(id),
    onSuccess: (_res, id) => {
      if (testTarget?.id === id) { setTestTarget(null); setTestResult(null) }
      setDeleteTarget(null)
      toast.success('OID custom eliminato', {
        description: 'Definizione rimossa dal DB reale.',
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submitCreate = () => {
    const name = coName.trim()
    const oid = coOid.trim()
    if (name.length < 2 || oid.length === 0 || create.isPending) return
    const scaleNum = coScale.trim() === '' ? undefined : Number(coScale)
    if (scaleNum != null && !Number.isFinite(scaleNum)) return
    const intervalNum = Number.parseInt(coInterval, 10)
    if (!Number.isInteger(intervalNum) || intervalNum < 30 || intervalNum > 86400) return
    create.mutate({
      name,
      oid,
      unit: coUnit.trim() || undefined,
      scale: scaleNum,
      dataType: coDataType,
      intervalSec: intervalNum,
      description: coDescription.trim() || undefined,
      enabled: coEnabled,
    })
  }

  const openTest = (row: CustomOidRow) => {
    testRun.reset()
    setTestResult(null)
    setTestDeviceId('')
    setTestTarget(row)
  }

  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <RadioTower className="size-4 text-text-2" aria-hidden />
          OID custom
          {oids.data ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              {fmtNumber(total)} definiti
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Metriche vendor specifiche che estendono il polling SNMP: definizione tecnica
          (OID numerico, tipo, intervallo) e test reale per dispositivo. Il conteggio
          applicazioni è quello vero del DB.
        </CardDescription>
        <CardAction>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => { void oids.refetch() }} disabled={oids.isFetching} aria-label="Aggiorna gli OID custom">
            <RefreshCw className={cn('size-3.5', oids.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {oids.isPending ? (
          <LoadingRows rows={4} />
        ) : oids.isError ? (
          <ErrorPanel
            message={errInfo(oids.error).message}
            code={errInfo(oids.error).code}
            onRetry={() => { void oids.refetch() }}
          />
        ) : (
          <>
            {items.length === 0 ? (
              <EmptyState
                icon={<RadioTower className="size-10" aria-hidden />}
                title="Nessun OID personalizzato"
                description="Un OID custom estende il polling SNMP con una metrica vendor specifica (es. CCQ Ubiquiti 1.3.6.1.4.1.41112.1.4): creane uno per testarlo su un dispositivo reale dell'inventario."
                action={
                  <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                    <Plus className="size-3.5" aria-hidden /> Nuovo OID
                  </Button>
                }
              />
            ) : (
              <>
                <div className="flex justify-end">
                  <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                    <Plus className="size-3.5" aria-hidden /> Nuovo OID
                  </Button>
                </div>
                <div className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70" role="region" aria-label="OID personalizzati definiti, scorribile" tabIndex={0}>
                  <Table>
                    <TableCaption className="sr-only">
                      OID personalizzati: nome, OID numerico, unità, tipo dato, intervallo di polling, applicazioni, stato attivo e azioni
                    </TableCaption>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead scope="col" className="w-[150px]">Nome</TableHead>
                        <TableHead scope="col">OID</TableHead>
                        <TableHead scope="col" className="w-[90px]">Unità</TableHead>
                        <TableHead scope="col" className="w-[100px]">Tipo</TableHead>
                        <TableHead scope="col" className="w-[100px]">Intervallo</TableHead>
                        <TableHead scope="col">Applicazioni</TableHead>
                        <TableHead scope="col" className="w-[70px]">Attivo</TableHead>
                        <TableHead scope="col" className="w-[140px] text-right">Azioni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((row) => (
                        <TableRow key={row.id}>
                          <TableCell>
                            <span className="block max-w-[140px] truncate font-mono text-xs" title={row.description || row.name}>
                              {row.name}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="block max-w-[220px] break-all font-mono text-xs" title={row.oid}>{row.oid}</span>
                          </TableCell>
                          <TableCell>
                            <span className="text-xs">{row.unit || '—'}</span>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">{row.dataType}</Badge>
                          </TableCell>
                          <TableCell>
                            <span className="num text-xs">{fmtNumber(row.intervalSec)} s</span>
                          </TableCell>
                          <TableCell>
                            <span className="flex flex-wrap items-baseline gap-x-1.5">
                              <span className="num text-xs font-medium">{fmtNumber(row.appliedCount)}</span>
                              {row.appliedCount === 0 ? (
                                <span className="text-xs text-text-2">— statistiche oneste: nessuna applicazione in replay</span>
                              ) : null}
                            </span>
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={row.enabled}
                              onCheckedChange={(checked) => toggleEnabled.mutate({ id: row.id, enabled: checked })}
                              disabled={toggleEnabled.isPending && toggleEnabled.variables?.id === row.id}
                              aria-label={`Attiva o disattiva il polling di ${row.name}`}
                            />
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8"
                                onClick={() => openTest(row)}
                                disabled={testRun.isPending && testTarget?.id === row.id}
                                aria-label={`Test SNMP di ${row.name} su un dispositivo`}
                              >
                                {testRun.isPending && testTarget?.id === row.id
                                  ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
                                  : <FlaskConical className="size-3.5" aria-hidden />}
                                Test SNMP
                              </Button>
                              <AlertDialog open={deleteTarget?.id === row.id} onOpenChange={(o) => { if (!o) setDeleteTarget(null) }}>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="size-8 text-crit-text hover:text-crit-text"
                                    onClick={() => setDeleteTarget(row)}
                                    aria-label={`Elimina l'OID ${row.name}`}
                                  >
                                    <Trash2 className="size-3.5" aria-hidden />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Eliminare «{deleteTarget?.name}»?</AlertDialogTitle>
                                    <AlertDialogDescription className="text-left leading-relaxed">
                                      Cancellazione REALE dal DB: la definizione non verrà più usata dal
                                      polling SNMP. L&apos;azione è registrata nell&apos;audit.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
                                    <AlertDialogAction
                                      disabled={remove.isPending}
                                      onClick={(e) => {
                                        e.preventDefault() // resta aperto finché la risposta reale non arriva
                                        if (!deleteTarget || remove.isPending) return
                                        remove.mutate(deleteTarget.id)
                                      }}
                                    >
                                      {remove.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                                      Elimina
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
            {oids.data ? <AsOf ts={oids.data.asOf} prefix="definizioni alle" className="mt-1" /> : null}
          </>
        )}
      </CardContent>

      {/* --- Dialog: nuovo OID custom --- */}
      <Dialog
        open={createOpen}
        onOpenChange={(open) => {
          setCreateOpen(open)
          if (!open) resetCreateForm()
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuovo OID custom</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Definizione REALE nel DB: estende il polling SNMP con una metrica vendor
              (es. CCQ Ubiquiti <span className="num">1.3.6.1.4.1.41112.1.4</span>). Dopo la
              creazione si apre subito il test su un dispositivo reale.
            </DialogDescription>
          </DialogHeader>

          <form
            className="grid gap-3"
            onSubmit={(e) => { e.preventDefault(); submitCreate() }}
            noValidate
            aria-label="Form di creazione OID custom"
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="co-name" className="text-xs font-medium text-text-2">Nome tecnico *</label>
                <Input
                  id="co-name"
                  value={coName}
                  maxLength={64}
                  onChange={(e) => setCoName(e.target.value)}
                  placeholder="es. ccq.athena"
                  className="font-mono text-xs"
                  aria-required="true"
                />
                <p className="text-xs text-text-2">lettere, cifre, . _ - (min 2)</p>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="co-oid" className="text-xs font-medium text-text-2">OID numerico *</label>
                <Input
                  id="co-oid"
                  value={coOid}
                  maxLength={120}
                  onChange={(e) => setCoOid(e.target.value)}
                  placeholder="es. 1.3.6.1.4.1.41112.1.4.1.1"
                  className="font-mono text-xs"
                  aria-required="true"
                />
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="co-unit" className="text-xs font-medium text-text-2">Unità</label>
                <Input
                  id="co-unit"
                  value={coUnit}
                  maxLength={16}
                  onChange={(e) => setCoUnit(e.target.value)}
                  placeholder="es. %"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="co-scale" className="text-xs font-medium text-text-2">Scala</label>
                <Input
                  id="co-scale"
                  type="number"
                  inputMode="decimal"
                  step="any"
                  value={coScale}
                  onChange={(e) => setCoScale(e.target.value)}
                  className="num"
                />
                <p className="text-xs text-text-2">fattore applicato al valore grezzo</p>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="co-type" className="text-xs font-medium text-text-2">Tipo dato</label>
                <Select value={coDataType} onValueChange={(v) => setCoDataType(v as 'FLOAT' | 'INT' | 'COUNTER')}>
                  <SelectTrigger id="co-type" className="w-full" aria-label="Tipo dato dell'OID">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DATA_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="co-interval" className="text-xs font-medium text-text-2">Intervallo (s)</label>
                <Input
                  id="co-interval"
                  type="number"
                  inputMode="numeric"
                  min={30}
                  max={86400}
                  value={coInterval}
                  onChange={(e) => setCoInterval(e.target.value)}
                  className="num"
                />
                <p className="text-xs text-text-2">30–86400 s</p>
              </div>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="co-desc" className="text-xs font-medium text-text-2">Descrizione</label>
              <Input
                id="co-desc"
                value={coDescription}
                maxLength={300}
                onChange={(e) => setCoDescription(e.target.value)}
                placeholder="es. AirMAX CCQ della radio Athena"
              />
            </div>
            <div className="flex items-center gap-2.5">
              <Switch
                id="co-enabled"
                checked={coEnabled}
                onCheckedChange={setCoEnabled}
                aria-label="OID attivo nel polling"
              />
              <label htmlFor="co-enabled" className="text-xs text-text-2">attivo (incluso nel polling SNMP)</label>
            </div>
          </form>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setCreateOpen(false); resetCreateForm() }}>
              Annulla
            </Button>
            <Button
              onClick={submitCreate}
              disabled={create.isPending || coName.trim().length < 2 || coOid.trim().length === 0}
            >
              {create.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
              Crea OID
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Dialog: test SNMP reale per dispositivo --- */}
      <Dialog
        open={!!testTarget}
        onOpenChange={(open) => {
          if (!open) { setTestTarget(null); setTestResult(null); setTestDeviceId('') }
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Test SNMP · {testTarget?.name}</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Get SNMP reale dell&apos;OID <span className="num break-all">{testTarget?.oid}</span> verso
              l&apos;IP del dispositivo scelto, eseguita dal servizio di scoperta: l&apos;esito —
              anche il timeout — è quello vero della rete.
            </DialogDescription>
          </DialogHeader>

          {/* Banner di onestà: la rete dimostrativa non è instradata */}
          <p className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2" role="note">
            Il test esegue una get SNMP REALE verso l&apos;IP del dispositivo: in ambiente
            dimostrativo la rete dell&apos;impianto non è raggiungibile (timeout onesto);
            su sito legge il valore vero.
          </p>

          <div className="grid gap-1.5">
            <label htmlFor="oid-test-device" className="text-xs font-medium text-text-2">
              Dispositivo (primi 50 dell&apos;inventario reale)
            </label>
            <Select value={testDeviceId} onValueChange={setTestDeviceId}>
              <SelectTrigger
                id="oid-test-device"
                className="w-full"
                disabled={devices.isPending || deviceList.length === 0}
                aria-label="Dispositivo su cui eseguire la get SNMP"
              >
                <SelectValue
                  placeholder={devices.isPending
                    ? 'caricamento dispositivi…'
                    : deviceList.length === 0 ? 'nessun dispositivo' : 'Scegli dispositivo…'}
                />
              </SelectTrigger>
              <SelectContent>
                {deviceList.map((d) => (
                  <SelectItem key={d.id} value={d.id}>
                    {d.hostname} · {d.ip}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {devices.isError ? (
              <p className="text-xs text-crit-text" role="alert">
                Dispositivi non disponibili: {errInfo(devices.error).message}
              </p>
            ) : null}
          </div>

          <Button
            onClick={() => { if (testTarget && testDeviceId) testRun.mutate({ id: testTarget.id, deviceId: testDeviceId }) }}
            disabled={!testDeviceId || testRun.isPending}
            aria-label="Esegui la get SNMP verso il dispositivo scelto"
          >
            {testRun.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FlaskConical className="size-3.5" aria-hidden />}
            Esegui get SNMP
          </Button>

          {testRun.isPending ? (
            <div role="status" aria-busy="true" className="flex items-center gap-2.5 rounded-md border border-border/70 bg-raised/40 px-3 py-4 text-sm text-text-2">
              <Loader2 className="size-4 animate-spin" aria-hidden />
              Get SNMP in corso verso il dispositivo…
            </div>
          ) : testRun.isError ? (
            <ErrorPanel
              message={errInfo(testRun.error).message}
              code={errInfo(testRun.error).code}
              onRetry={() => { if (testTarget && testDeviceId) { testRun.reset(); testRun.mutate({ id: testTarget.id, deviceId: testDeviceId }) } }}
            />
          ) : testResult ? (
            <OidTestOutcome r={testResult} />
          ) : null}
        </DialogContent>
      </Dialog>
    </Card>
  )
}

/* Esito del test SNMP: valori REALI del varbind quando raggiungibile,
 * timeout dichiarato altrimenti; nota del backend sempre visibile. */
function OidTestOutcome({ r }: { r: CustomOidTestResult }) {
  return (
    <div className="space-y-2.5 rounded-md border border-border/70 bg-raised/40 px-3 py-2.5 text-xs" role="status" aria-live="polite">
      <div className="flex flex-wrap items-center gap-2">
        {r.reachable ? (
          <Badge variant="outline" className="border-ok/40 bg-ok-soft font-medium text-ok">Raggiungibile</Badge>
        ) : (
          <Badge variant="outline" className="border-crit/40 bg-crit-soft font-medium text-crit-text">timeout</Badge>
        )}
        <span className="num text-text-2">{r.durationMs} ms</span>
        <span className="font-mono break-all text-text-2" title={r.oid}>{r.oid}</span>
      </div>
      <dl className="grid gap-x-6 gap-y-1.5 sm:grid-cols-2">
        <OutcomeRow label="Dispositivo" value={`${r.hostname} (${r.ip ?? 'n.d.'})`} />
        <OutcomeRow label="Valore grezzo" value={r.rawValue ?? '—'} />
        <OutcomeRow label="Valore numerico" value={r.numericValue != null ? String(r.numericValue) : 'n.d.'} />
        <OutcomeRow label="Errore" value={r.error ?? '—'} />
      </dl>
      <p className="leading-relaxed text-text-2">{r.note}</p>
    </div>
  )
}

function OutcomeRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-2">
      <dt className="w-32 shrink-0 text-text-2">{label}</dt>
      <dd className="min-w-0 break-all font-mono">{value}</dd>
    </div>
  )
}
