/* ================================================================
 * FALCO-OS v16 — Sezione «Scansione & Adozione» (16.6 ondata W3.4)
 * Quarto tab della vista Operazioni: (A) stato del motore discovery
 * (servizio reale su porta 3002: capacità + DB OUI IEEE), (B) sweep
 * TCP su CIDR con sonda di identificazione combinata (ONVIF, SNMP,
 * banner HTTP, OUI) in SOLA LETTURA, (D) coda di adozione con gli
 * orfani REALI del DB (SYS:NEW_HOST senza sede) e adozione esplicita
 * con audit. Onestà: «n.d.» sui campi mancanti, errori e timeout
 * mostrati come tali, nessun dato inventato; l'adozione è SEMPRE una
 * decisione umana, mai automatica (regola v15 §13.8).
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Archive, Check, CircleAlert, CircleCheck, CircleHelp, CloudOff, Fingerprint, Info,
  Loader2, LogIn, MapPin, Network, Radar, RefreshCw, ScanSearch, ShieldCheck,
  type LucideIcon,
} from 'lucide-react'

import { KpiCard } from '@/components/kpi-card'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  api, ApiError,
  type AdoptionCandidate, type DiscoveryScanResult, type VendorProbeResult,
} from '@/lib/client/api'
import { fmtDateTimeFull, fmtNumber, fmtRelative, fmtUptime, typeLabel } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Costanti sezione ---------------- */

/* Confidenza della classificazione (badge icona+testo, §4.2) */
const CONFIDENCE_META: Record<'high' | 'medium' | 'low', { label: string; cls: string; Icon: LucideIcon }> = {
  high: { label: 'alta', cls: 'bg-ok-soft text-ok border-ok/40', Icon: CircleCheck },
  medium: { label: 'media', cls: 'bg-warn-soft text-warn border-warn/40', Icon: CircleAlert },
  low: { label: 'bassa', cls: 'bg-raised text-text-2 border-border', Icon: CircleHelp },
}

/* Capacità del motore: etichette italiane, valore raw come fallback (mai inventato) */
const CAPABILITY_LABELS: Record<string, string> = {
  'tcp-scan': 'Scansione TCP',
  'snmp-v2c-v3': 'SNMP v2c/v3',
  'multi-community': 'Multi-community',
  onvif: 'ONVIF',
  oui: 'OUI IEEE',
  'ubiquiti-udp': 'Ubiquiti UDP',
  mndp: 'MNDP',
  'ws-discovery': 'WS-Discovery',
  // --- v16.8 ---
  'lldp-mib': 'LLDP-MIB',
  'cdp-cache': 'CDP cache',
  'bridge-mib': 'BRIDGE-MIB (FDB)',
  'qbridge-mib': 'Q-BRIDGE (VLAN)',
  mdns: 'mDNS/Bonjour',
  ssdp: 'SSDP/UPnP',
  'vendor-batch': 'Batch identify',
  'tls-fingerprint': 'Impronta TLS',
  'adaptive-ping': 'Ping 2 passate',
}

/* Sorgenti della catena di evidenze (fallback: valore raw) */
const EVIDENCE_SOURCE_LABELS: Record<string, string> = {
  onvif: 'ONVIF',
  snmp: 'SNMP',
  banner: 'Banner HTTP',
  port: 'Porta',
  oui: 'OUI',
}

/* Sorgente del vendor guess SNMP */
const SNMP_SOURCE_LABELS: Record<string, string> = {
  'enterprise-oid': 'da OID enterprise',
  sysdescr: 'da sysDescr',
}

/* Categorie OUI del triage v15 (fallback: valore raw) */
const OUI_CATEGORY_LABELS: Record<string, string> = {
  RADIO: 'Radio',
  CAMERA: 'Telecamera',
  SWITCH: 'Switch',
  NVR: 'NVR',
  GENERIC: 'Generico',
}

/* ---------------- Helpers ---------------- */

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Uptime del motore: secondi sotto il minuto, poi formato compatto. */
function engineUptime(sec: number): string {
  return sec < 60 ? `${sec} s` : fmtUptime(sec)
}

/** Durata scansione in secondi con virgola decimale italiana (es. 0,0 s). */
function fmtScanSeconds(ms: number): string {
  return `${(ms / 1000).toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} s`
}

/** Parse della lista porte (virgola/spazio/punto-e-virgola): null = formato non valido. */
function parsePorts(raw: string): number[] | null {
  const tokens = raw.split(/[\s,;]+/).filter((t) => t.length > 0)
  const out: number[] = []
  for (const t of tokens) {
    const n = Number(t)
    if (!Number.isInteger(n) || n < 1 || n > 65535) return null
    if (!out.includes(n)) out.push(n)
  }
  return out
}

/** Valore onesto: «n.d.» quando manca (mai vuoto spacciato per dato). */
function Nd({ v, mono = false }: { v: string | null | undefined; mono?: boolean }) {
  const missing = v == null || v === ''
  return (
    <span
      className={cn(missing ? 'text-text-2' : 'min-w-0', !missing && mono && 'font-mono text-xs num')}
      title={missing ? undefined : v}
    >
      {missing ? 'n.d.' : v}
    </span>
  )
}

/** Riga etichetta/valore dei blocchi sonda (dt/dd, «n.d.» se assente). */
function Field({ label, value, mono = false }: { label: string; value: string | number | null | undefined; mono?: boolean }) {
  const missing = value == null || value === ''
  const text = missing ? 'n.d.' : String(value)
  return (
    <div className="grid grid-cols-[86px_1fr] items-baseline gap-2">
      <dt className="text-xs text-text-2">{label}</dt>
      <dd
        className={cn('min-w-0 break-words text-sm', missing && 'text-text-2', !missing && mono && 'font-mono text-xs break-all')}
        title={missing ? undefined : text}
      >
        {text}
      </dd>
    </div>
  )
}

/* ================================================================
 * Sezione radice: striscia motore + scansione + coda adozione
 * ================================================================ */

export default function ScansioneAdozioneSection() {
  return (
    <div className="space-y-4">
      <EngineStatusCard />
      <NetworkScanCard />
      <AdoptionQueueCard />
    </div>
  )
}

/* ================================================================
 * A — Striscia stato del motore discovery (:3002)
 * ================================================================ */

function EngineStatusCard() {
  const health = useQuery({
    queryKey: ['discovery-health'],
    queryFn: () => api.discoveryHealth(),
    staleTime: 30_000,
  })
  const h = health.data?.data

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Radar className="size-4 text-text-2" aria-hidden />
          Motore di scansione
        </CardTitle>
        <CardDescription>
          {h ? `Servizio ${h.service} · versione ${h.version}` : 'Stato del servizio di discovery (porta 3002)'}
        </CardDescription>
        <CardAction>
          <div className="flex items-center gap-1.5">
            {health.data ? <AsOf ts={health.data.asOf} prefix="stato verificato alle" /> : null}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void health.refetch() }}
              disabled={health.isFetching}
              aria-label="Aggiorna lo stato del motore"
            >
              <RefreshCw className={cn('size-3.5', health.isFetching && 'animate-spin')} aria-hidden />
            </Button>
          </div>
        </CardAction>
      </CardHeader>
      <CardContent>
        {health.isPending ? (
          <LoadingRows rows={2} />
        ) : health.isError ? (
          <div role="alert" className="space-y-1.5">
            <Badge className="bg-crit-soft text-crit-text border-crit/40">
              <CloudOff className="size-3" aria-hidden />
              Motore non raggiungibile (porta 3002)
            </Badge>
            <p className="break-words text-xs text-crit-text">
              {errInfo(health.error).message}
              {errInfo(health.error).code ? ` (codice ${errInfo(health.error).code})` : ''}
            </p>
          </div>
        ) : h ? (
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge className="bg-ok-soft text-ok border-ok/40">
                <CircleCheck className="size-3" aria-hidden />
                Motore attivo · uptime {engineUptime(h.uptimeSec)}
              </Badge>
              {h.capabilities.map((cap) => (
                <Badge
                  key={cap}
                  variant="outline"
                  className="bg-raised/50 text-text-2 border-border"
                  title={`Capacità dichiarata dal servizio: ${cap}`}
                >
                  {CAPABILITY_LABELS[cap] ?? cap}
                </Badge>
              ))}
            </div>
            <p className="text-xs text-text-2">
              OUI IEEE: <span className="num">{fmtNumber(h.oui.total)}</span> prefissi ·{' '}
              <span className="num">{fmtNumber(h.oui.brands)}</span> brand
            </p>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * B — Scansione di rete (sweep TCP su CIDR) + dialog identificazione
 * ================================================================ */

function NetworkScanCard() {
  const [cidr, setCidr] = useState('127.0.0.1/32')
  const [portsRaw, setPortsRaw] = useState('')
  const [communitiesRaw, setCommunitiesRaw] = useState('')
  const [lastInput, setLastInput] = useState<{ cidr: string; ports?: number[] } | null>(null)
  const [lastResult, setLastResult] = useState<DiscoveryScanResult | null>(null)
  const [probeIp, setProbeIp] = useState<string | null>(null)
  /* v16.8 — identificazione batch: risultati per IP (classificazione inline) */
  const [batchByIp, setBatchByIp] = useState<Record<string, VendorProbeResult> | null>(null)

  /* Community dalla lista separata da virgola → array (max 8, onesto) */
  const communities = communitiesRaw
    .split(/[\s,;]+/)
    .map((c) => c.trim())
    .filter((c) => c.length > 0)
    .slice(0, 8)

  /* Sweep TCP: mutation (azione esplicita), toast d'errore col messaggio
   * del backend (es. TOO_LARGE oltre 256 host). */
  const scan = useMutation({
    mutationFn: (input: { cidr: string; ports?: number[] }) => api.discoveryScan(input),
    onSuccess: (res) => {
      setLastResult(res)
      setBatchByIp(null) // nuova scansione: pulizia dei risultati batch precedenti
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Scansione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  /* v16.8 — Identificazione BATCH di tutti gli host trovati: UNA richiesta
   * per ≤32 IP (il motore sonda in parallelo): il «puller» integrato. */
  const batch = useMutation({
    mutationFn: (targets: string[]) =>
      api.discoveryVendorBatch({
        targets,
        snmp: communities.length > 0 ? { communities } : undefined,
      }),
    onSuccess: (res) => {
      const byIp: Record<string, VendorProbeResult> = {}
      for (const r of res.results) byIp[r.ip] = r
      setBatchByIp(byIp)
      toast.success(`Identificati ${res.classified} di ${res.total} host`, {
        description: `Sonda combinata in ${(res.durationMs / 1000).toLocaleString('it-IT', { maximumFractionDigits: 1 })} s · ${res.alive} vivi · concorrenza ${res.concurrency}`,
      })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Identificazione batch non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const identifyAll = () => {
    if (!lastResult) return
    const targets = lastResult.hosts.map((h) => h.ip).slice(0, 32)
    if (targets.length === 0) return
    if (lastResult.hosts.length > 32) {
      toast.info('Identificazione limitata ai primi 32 host', {
        description: `La scansione ha trovato ${lastResult.hosts.length} host: il batch identifica fino a 32 IP per richiesta — rilanciala dopo aver ristretto la rete.`,
      })
    }
    batch.mutate(targets)
  }

  /* Sonda combinata (sola lettura) sull'IP scelto dalla tabella
   * v16.8: passa anche le community della sessione di scansione */
  const probe = useMutation({
    mutationFn: (ip: string) =>
      api.discoveryProbe({ ip, snmp: communities.length > 0 ? { communities } : undefined }),
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Identificazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const openProbe = (ip: string) => {
    probe.reset() // niente risultato stantio di un IP precedente
    setProbeIp(ip)
    probe.mutate(ip)
  }

  const runScan = () => {
    const net = cidr.trim()
    if (!net) return
    let ports: number[] | undefined
    if (portsRaw.trim()) {
      const parsed = parsePorts(portsRaw)
      if (!parsed) {
        toast.error('Porte non valide', {
          description: 'Inserisci numeri di porta TCP (1–65535) separati da virgola, es. 3000,3001,80,161.',
        })
        return
      }
      if (parsed.length > 64) {
        toast.error('Troppe porte', { description: 'Massimo 64 porte per scansione (limite del motore).' })
        return
      }
      ports = parsed
    }
    setLastInput({ cidr: net, ports })
    scan.mutate({ cidr: net, ports })
  }

  const res = lastResult

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ScanSearch className="size-4 text-text-2" aria-hidden />
          Scansione di rete
        </CardTitle>
        <CardDescription>
          Sweep TCP su un CIDR (massimo 256 host): il motore risponde con i soli host vivi
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Banner onestà: ambiente dimostrativo */}
        <div className="flex items-start gap-2.5 rounded-lg border border-border/70 bg-raised/40 px-3 py-2">
          <Info className="mt-0.5 size-4 shrink-0 text-text-2" aria-hidden />
          <p className="min-w-0 flex-1 text-xs text-text-2">
            Ambiente dimostrativo: la scansione raggiunge solo la rete locale del server (127.0.0.1) —
            in produzione su sito opera sulla rete reale dell&apos;impianto.
          </p>
        </div>

        {/* Form: griglia responsive (1 colonna su mobile) */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_1fr_1fr_auto]">
          <div className="grid gap-1.5">
            <label htmlFor="scan-cidr" className="text-xs font-medium text-text-2">Rete (CIDR)</label>
            <Input
              id="scan-cidr"
              value={cidr}
              onChange={(e) => setCidr(e.target.value)}
              placeholder="es. 192.168.1.0/24"
              aria-label="Rete da scansionare in formato CIDR"
              autoComplete="off"
            />
          </div>
          <div className="grid gap-1.5">
            <label htmlFor="scan-ports" className="text-xs font-medium text-text-2">Porte TCP (opzionale)</label>
            <Input
              id="scan-ports"
              value={portsRaw}
              onChange={(e) => setPortsRaw(e.target.value)}
              placeholder="opz.: 3000,3001,80,161…"
              aria-label="Porte TCP da verificare, separate da virgola (opzionale)"
              autoComplete="off"
            />
          </div>
          <div className="grid gap-1.5">
            <label htmlFor="scan-communities" className="text-xs font-medium text-text-2">
              Community SNMP (opz., max 8)
              <span className="ml-1 font-normal text-text-3" title="Il motore tenta le community in ordine (default: public) e dichiara quale ha risposto">ⓘ</span>
            </label>
            <Input
              id="scan-communities"
              value={communitiesRaw}
              onChange={(e) => setCommunitiesRaw(e.target.value)}
              placeholder="opz.: public,miaCommunity"
              aria-label="Community SNMP da tentare durante l'identificazione, separate da virgola (opzionale)"
              autoComplete="off"
            />
          </div>
          <div className="flex items-end">
            <Button onClick={runScan} disabled={!cidr.trim() || scan.isPending} className="w-full sm:w-auto">
              {scan.isPending
                ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
                : <ScanSearch className="size-3.5" aria-hidden />}
              Esegui scansione
            </Button>
          </div>
        </div>

        {/* Risultato */}
        {scan.isError ? (
          <ErrorPanel
            message={errInfo(scan.error).message}
            code={errInfo(scan.error).code}
            onRetry={lastInput ? () => scan.mutate(lastInput) : undefined}
          />
        ) : !res ? (
          <EmptyState
            icon={<Radar className="size-10 text-text-2" aria-hidden />}
            title="Nessuna scansione eseguita"
            description="Imposta una rete (CIDR) ed esegui la scansione: l'elenco degli host vivi compare qui con latenza e porte aperte."
          />
        ) : res.hosts.length === 0 ? (
          <EmptyState
            icon={<Network className="size-10 text-text-2" aria-hidden />}
            title="Nessun host vivo: la rete scansionata non ha risposto"
            description={`La scansione di ${res.cidr} (${fmtScanSeconds(res.durationMs)}) non ha trovato host attivi: la rete è muta o non raggiungibile dall'ambiente dimostrativo.`}
          />
        ) : (
          <div className={cn('space-y-2', scan.isPending && 'opacity-60')} aria-busy={scan.isPending}>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
              <p className="min-w-0 flex-1 text-xs text-text-2">
                Rete <span className="num">{res.cidr}</span> ·{' '}
                <span className="num font-medium text-foreground">{res.summary.up}</span>{' '}
                {res.summary.up === 1 ? 'host vivo' : 'host vivi'} su{' '}
                <span className="num">{res.summary.scanned}</span>{' '}
                {res.summary.scanned === 1 ? 'scansionato' : 'scansionati'} ·{' '}
                <span className="num">{res.summary.withOpenPorts}</span> con porte aperte ·{' '}
                <span className="num">{fmtScanSeconds(res.durationMs)}</span>
              </p>
              {/* v16.8 — puller integrato: UNA richiesta per tutti gli host */}
              <Button
                variant="secondary"
                size="sm"
                className="h-8"
                onClick={identifyAll}
                disabled={batch.isPending || res.hosts.length === 0}
                aria-label="Identifica in batch tutti gli host trovati dalla scansione"
              >
                {batch.isPending
                  ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
                  : <Fingerprint className="size-3.5" aria-hidden />}
                Identifica tutti ({Math.min(res.hosts.length, 32)})
              </Button>
            </div>
            {batch.data && !batch.isPending ? (
              <p className="text-xs text-text-2" role="status">
                Identificazione completata in{' '}
                <span className="num">{fmtScanSeconds(batch.data.durationMs)}</span>:{' '}
                <span className="num font-medium text-foreground">{batch.data.classified}</span> classificati ·{' '}
                <span className="num">{batch.data.alive}</span> vivi · concorrenza{' '}
                <span className="num">{batch.data.concurrency}</span>
                {communities.length > 0 ? <> · community tentate: <code className="font-mono">{communities.join(', ')}</code></> : null}
              </p>
            ) : null}
            <div className="overflow-x-auto rounded-lg border border-border/70 bg-surface">
              <Table>
                <TableCaption className="sr-only">
                  Host vivi della scansione di {res.cidr}: indirizzo IP, latenza in millisecondi, porte aperte, classificazione e azione di identificazione
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="min-w-[130px]">IP</TableHead>
                    <TableHead scope="col" className="w-[110px]">Latenza (ms)</TableHead>
                    <TableHead scope="col" className="min-w-[160px]">Porte aperte</TableHead>
                    <TableHead scope="col" className="min-w-[200px]">Classificazione</TableHead>
                    <TableHead scope="col" className="w-[130px]">
                      <span className="sr-only">Azioni</span>
                      Azioni
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {res.hosts.map((host) => {
                    const identified = batchByIp?.[host.ip] ?? null
                    const conf = identified ? CONFIDENCE_META[identified.classification.confidence] : null
                    return (
                      <TableRow key={host.ip}>
                        <TableCell className="num font-mono text-xs">{host.ip}</TableCell>
                        <TableCell className="num">
                          {host.latencyMs}
                          {host.secondPass ? (
                            <span className="ml-1 text-[10px] text-warn" title="Risposto solo alla seconda passata del ping (host lento)">· lento</span>
                          ) : null}
                        </TableCell>
                        <TableCell>
                          {host.openPorts.length === 0 ? (
                            <span className="text-xs text-text-2">nessuna</span>
                          ) : (
                            <span className="flex flex-wrap gap-1">
                              {host.openPorts.map((p) => (
                                <Badge
                                  key={p.port}
                                  variant="outline"
                                  className="num bg-raised/50 text-text-2 border-border"
                                  title={`Porta ${p.port} · ${p.state}`}
                                >
                                  {p.port}
                                </Badge>
                              ))}
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          {batch.isPending ? (
                            <span className="inline-flex h-5 w-24 animate-pulse rounded bg-raised/60" aria-label="identificazione in corso" />
                          ) : identified ? (
                            <span className="flex flex-wrap items-center gap-1.5">
                              <Badge className="bg-raised text-text-2 border-border" title={`Tipo classificato: ${identified.classification.type}`}>
                                {typeLabel(identified.classification.type)}
                              </Badge>
                              {identified.classification.brand ? (
                                <span className="text-xs">{identified.classification.brand}</span>
                              ) : null}
                              {identified.classification.model ? (
                                <span className="num text-xs text-text-2">{identified.classification.model}</span>
                              ) : null}
                              {conf ? (
                                <conf.Icon className={cn('size-3.5', identified.classification.confidence === 'high' ? 'text-ok' : identified.classification.confidence === 'medium' ? 'text-warn' : 'text-text-3')} aria-label={`confidenza ${conf.label}`} />
                              ) : null}
                            </span>
                          ) : (
                            <span className="text-xs text-text-2">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8"
                            onClick={() => openProbe(host.ip)}
                            aria-label={`Identifica l'apparato ${host.ip}`}
                          >
                            <Fingerprint className="size-3.5" aria-hidden />
                            Dettaglio
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>

      {/* C — Dialog «Identifica apparato» (mount condizionato) */}
      {probeIp ? (
        <ProbeDialog
          ip={probeIp}
          result={probe.data ?? null}
          isPending={probe.isPending}
          error={probe.error}
          onRetry={() => probe.mutate(probeIp)}
          onOpenChange={(o) => { if (!o) setProbeIp(null) }}
        />
      ) : null}
    </Card>
  )
}

/* ================================================================
 * C — Dialog «Identifica apparato»: sonda combinata in sola lettura
 * ================================================================ */

function ProbeDialog({
  ip, result, isPending, error, onRetry, onOpenChange,
}: {
  ip: string
  result: VendorProbeResult | null
  isPending: boolean
  error: unknown
  onRetry: () => void
  onOpenChange: (open: boolean) => void
}) {
  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            Identifica apparato · <span className="num">{ip}</span>
          </DialogTitle>
          <DialogDescription>
            Sonda combinata in sola lettura: porte TCP, banner HTTP, SNMP, ONVIF e OUI IEEE,
            fuse in una classificazione con catena di evidenze.
          </DialogDescription>
        </DialogHeader>

        {isPending ? (
          <div className="space-y-2" role="status" aria-busy="true">
            <span className="sr-only">Sonda in corso su {ip}…</span>
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-10 animate-pulse rounded-md bg-raised/60" />
            ))}
          </div>
        ) : error ? (
          <ErrorPanel message={errInfo(error).message} code={errInfo(error).code} onRetry={onRetry} />
        ) : result ? (
          <ProbeBody r={result} />
        ) : null}

        {/* Banner permanence: la sonda non scrive mai sull'inventario */}
        <p className="flex items-start gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2 text-xs text-text-2">
          <ShieldCheck className="mt-0.5 size-3.5 shrink-0" aria-hidden />
          <span>
            Sonda in sola lettura: nessuna scrittura sull&apos;inventario
            (l&apos;adozione è un&apos;azione umana esplicita).
          </span>
        </p>
      </DialogContent>
    </Dialog>
  )
}

function ProbeBody({ r }: { r: VendorProbeResult }) {
  const conf = CONFIDENCE_META[r.classification.confidence]
  const osText = [r.classification.os ?? r.snmp?.product?.osFamily, r.classification.osVersion ?? r.snmp?.product?.osVersion]
    .filter(Boolean)
    .join(' ')
  return (
    <div className="space-y-3">
      {/* Intestazione: classificazione fusa (tipo + brand/modello + confidenza) */}
      <div className="flex flex-wrap items-center gap-2">
        <Badge className="bg-raised text-text-2 border-border" title={`Tipo classificato: ${r.classification.type}`}>
          {typeLabel(r.classification.type)}
        </Badge>
        <p className="min-w-0 text-sm">
          <span className="font-medium">{r.classification.brand ?? 'n.d.'}</span>
          <span className="text-text-2"> · {r.classification.model ?? r.snmp?.product?.model ?? 'n.d.'}</span>
        </p>
        <span className="text-xs text-text-2">confidenza</span>
        <Badge className={conf.cls}>
          <conf.Icon className="size-3" aria-hidden />
          {conf.label}
        </Badge>
        {r.latencyMs != null ? <span className="num text-xs text-text-2">· {r.latencyMs} ms</span> : null}
        {r.slowHost ? (
          <Badge className="bg-warn-soft text-warn border-warn/40" title="Host lento: ha risposto solo alla seconda passata del ping">
            lento (2ª passata)
          </Badge>
        ) : null}
      </div>

      {/* v16.8 — identità dichiarata dall'apparato (sysDescr/ONVIF) */}
      {osText || r.classification.firmwareVersion ? (
        <p className="flex flex-wrap items-center gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2 text-xs">
          <span className="font-medium text-text-2">Identità dichiarata:</span>
          {osText ? <span className="num">{osText}</span> : null}
          {r.classification.firmwareVersion && r.classification.firmwareVersion !== (r.classification.osVersion ?? '') ? (
            <Badge variant="outline" className="num bg-raised/50 text-text-2 border-border">fw {r.classification.firmwareVersion}</Badge>
          ) : null}
        </p>
      ) : null}

      {/* Host muto: messaggio onesto, nessuna porta di servizio ha risposto */}
      {!r.alive ? (
        <p role="status" className="flex items-center gap-2 rounded-lg border border-warn/40 bg-warn-soft px-3 py-2 text-xs text-warn">
          <CircleAlert className="size-3.5 shrink-0" aria-hidden />
          Host non raggiungibile sulle porte di servizio.
        </p>
      ) : null}

      {/* ONVIF (solo se il blocco è presente nella risposta) */}
      {r.onvif ? (
        r.onvif.reachable ? (
          <section className="space-y-2 rounded-lg border border-border/70 p-3" aria-label="Evidenze ONVIF">
            <h4 className="text-xs font-semibold text-text-2">ONVIF</h4>
            <dl className="grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
              <Field label="Produttore" value={r.onvif.manufacturer} />
              <Field label="Modello" value={r.onvif.model} />
              <Field label="Firmware" value={r.onvif.firmwareVersion} />
              <Field label="Seriale" value={r.onvif.serialNumber} mono />
              <Field label="Hardware" value={r.onvif.hardwareId} mono />
            </dl>
          </section>
        ) : (
          <p className="flex flex-wrap items-center gap-2 text-xs text-text-2">
            <Badge className="bg-raised text-text-2 border-border">ONVIF</Badge>
            {r.onvif.error ?? 'non raggiungibile'}
          </p>
        )
      ) : null}

      {/* SNMP */}
      {r.snmp ? (
        r.snmp.reachable ? (
          <section className="space-y-2 rounded-lg border border-border/70 p-3" aria-label="Evidenze SNMP">
            <h4 className="flex flex-wrap items-center gap-2 text-xs font-semibold text-text-2">
              SNMP
              {r.snmp.matched ? (
                <Badge variant="outline" className="num bg-ok-soft text-ok border-ok/40" title="Community e versione che hanno risposto">
                  {r.snmp.matched.community} · {r.snmp.matched.version}
                </Badge>
              ) : null}
            </h4>
            <dl className="grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
              <div className="grid grid-cols-[86px_1fr] items-baseline gap-2 sm:col-span-2">
                <dt className="text-xs text-text-2">sysDescr</dt>
                <dd className="min-w-0">
                  {r.snmp.sysDescr ? (
                    <code
                      className="block truncate rounded-md bg-raised/50 px-2 py-1 font-mono text-xs"
                      title={r.snmp.sysDescr}
                    >
                      {r.snmp.sysDescr}
                    </code>
                  ) : (
                    <span className="text-sm text-text-2">n.d.</span>
                  )}
                </dd>
              </div>
              <Field label="sysObjectID" value={r.snmp.sysObjectID} mono />
              <Field label="sysName" value={r.snmp.sysName} />
              <Field label="Interfacce" value={r.snmp.ifCount} />
              <Field label="OS/firmware" value={r.snmp.product ? [r.snmp.product.osFamily, r.snmp.product.osVersion].filter(Boolean).join(' ') || null : null} />
              <div className="grid grid-cols-[86px_1fr] items-baseline gap-2">
                <dt className="text-xs text-text-2">Vendor</dt>
                <dd className="flex min-w-0 flex-wrap items-center gap-1.5">
                  {r.snmp.vendorGuess ? (
                    <>
                      <span className="break-words text-sm">{r.snmp.vendorGuess.vendor}</span>
                      <Badge variant="outline" className="bg-raised/50 text-text-2 border-border">
                        {SNMP_SOURCE_LABELS[r.snmp.vendorGuess.source] ?? r.snmp.vendorGuess.source}
                      </Badge>
                    </>
                  ) : (
                    <span className="text-sm text-text-2">n.d.</span>
                  )}
                </dd>
              </div>
            </dl>
          </section>
        ) : (
          <p className="flex flex-wrap items-center gap-2 text-xs text-text-2">
            <Badge className="bg-raised text-text-2 border-border">SNMP</Badge>
            {r.snmp.error ?? 'non raggiungibile'}
          </p>
        )
      ) : null}

      {/* OUI IEEE */}
      {r.oui ? (
        <section className="space-y-1.5 rounded-lg border border-border/70 p-3" aria-label="Lookup OUI IEEE">
          <h4 className="text-xs font-semibold text-text-2">OUI IEEE</h4>
          <p className="flex flex-wrap items-center gap-2 text-sm">
            <code className="num font-mono text-xs">{r.oui.mac}</code>
            <span className="text-text-2" aria-hidden>→</span>
            <span className="min-w-0 break-words">{r.oui.vendor}</span>
            <Badge variant="outline" className="bg-raised/50 text-text-2 border-border">
              {OUI_CATEGORY_LABELS[r.oui.category] ?? r.oui.category}
            </Badge>
          </p>
        </section>
      ) : null}

      {/* Banner HTTP (v16.8: realm di autenticazione e certificato TLS) */}
      {r.http ? (
        <section className="space-y-2 rounded-lg border border-border/70 p-3" aria-label="Banner HTTP">
          <h4 className="text-xs font-semibold text-text-2">Banner HTTP / TLS</h4>
          <dl className="grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
            <Field label="Server" value={r.http.server} />
            <Field label="Titolo" value={r.http.title} />
            <Field label="Realm" value={r.http.realm} />
            <Field label="Cert. CN" value={r.http.certCn} mono />
          </dl>
        </section>
      ) : null}

      {/* Catena di evidenze (ordinata per peso: ONVIF > SNMP > banner > porte) */}
      <section className="space-y-2 rounded-lg border border-border/70 p-3" aria-label="Catena di evidenze della classificazione">
        <h4 className="text-xs font-semibold text-text-2">Catena di evidenze</h4>
        {r.classification.evidence.length === 0 ? (
          <p className="text-xs text-text-2">Nessuna evidenza raccolta.</p>
        ) : (
          <ol className="space-y-1.5">
            {r.classification.evidence.map((ev, i) => (
              <li key={`${ev.source}-${i}`} className="flex flex-wrap items-center gap-2">
                <span className="num w-4 text-right text-xs text-text-2" aria-hidden>{i + 1}.</span>
                <Badge variant="outline" className="bg-raised/50 text-text-2 border-border">
                  {EVIDENCE_SOURCE_LABELS[ev.source] ?? ev.source}
                </Badge>
                <span className="min-w-0 break-all font-mono text-xs">{ev.value}</span>
              </li>
            ))}
          </ol>
        )}
      </section>
    </div>
  )
}

/* ================================================================
 * D — Coda di adozione: orfani REALI + «da confermare» + sedi
 * ================================================================ */

function AdoptionQueueCard() {
  const queryClient = useQueryClient()
  const queue = useQuery({
    queryKey: ['adoption-queue'],
    queryFn: () => api.adoptionQueue(),
    staleTime: 30_000,
  })
  const q = queue.data?.data
  const orphans = q?.orphans ?? []
  const toConfirm = q?.toConfirm ?? []
  const locations = q?.locations ?? []

  /* Invalidazione dopo l'azione: coda + viste che dipendono
   * dall'assegnazione della sede (dispositivi, sedi). */
  const invalidateAfterAction = () => {
    void queryClient.invalidateQueries({ queryKey: ['adoption-queue'] })
    void queryClient.invalidateQueries({ queryKey: ['adozione'] })
    void queryClient.invalidateQueries({ queryKey: ['devices'] })
    void queryClient.invalidateQueries({ queryKey: ['locations'] })
  }

  const adopt = useMutation({
    mutationFn: (input: { deviceId: string; locationId: string }) =>
      api.adoptionAdopt(input.deviceId, input.locationId),
    onSuccess: (_res, vars) => {
      const locName = locations.find((l) => l.id === vars.locationId)?.name ?? vars.locationId
      toast.success(`Adottato su ${locName}`, {
        description: 'Assegnazione della sede registrata nell\'audit (ADOZIONE_ADOPT): decisione umana, nessuna auto-adozione.',
      })
      invalidateAfterAction()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Adozione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const dismiss = useMutation({
    mutationFn: (deviceId: string) => api.adoptionDismiss(deviceId),
    onSuccess: () => {
      toast.success('Richiesta archiviata', {
        description: 'Archiviazione registrata nell\'audit (ADOZIONE_DISMISS): l\'host resta nell\'inventario, esce solo dalla coda.',
      })
      invalidateAfterAction()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Archiviazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <LogIn className="size-4 text-text-2" aria-hidden />
          Coda di adozione
        </CardTitle>
        <CardDescription>
          Host scoperti senza sede: l&apos;adozione è una decisione umana esplicita
        </CardDescription>
        <CardAction>
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            onClick={() => { void queue.refetch() }}
            disabled={queue.isFetching}
            aria-label="Aggiorna la coda di adozione"
          >
            <RefreshCw className={cn('size-3.5', queue.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-3">
        {queue.isPending ? (
          <LoadingRows rows={4} />
        ) : queue.isError ? (
          <ErrorPanel
            message={errInfo(queue.error).message}
            code={errInfo(queue.error).code}
            onRetry={() => { void queue.refetch() }}
          />
        ) : (
          <>
            {/* KPI reali (nessun numero inventato) */}
            <div className="grid gap-3 sm:grid-cols-2">
              <KpiCard
                label="Orfani senza sede"
                value={orphans.length}
                icon={<MapPin className="size-4" aria-hidden />}
                definition="Host scoperti (evento SYS:NEW_HOST) senza sede assegnata nel DB reale: la decisione di adozione è sempre umana (regola v15 §13.8)."
              />
              <KpiCard
                label="Da confermare"
                value={toConfirm.length}
                icon={<CircleAlert className="size-4" aria-hidden />}
                definition="Richieste di adozione su impianti sensibili (GAP 2): richiedono conferma o archiviazione esplicita dell'operatore."
              />
            </div>

            {orphans.length === 0 ? (
              <EmptyState
                icon={<CircleCheck className="size-10 text-text-2" aria-hidden />}
                title="Coda vuota: nessun orfano da adottare"
                description="Nessun host scoperto senza sede nel DB reale. Quando il motore di scansione registra nuovi apparati (SYS:NEW_HOST) compaiono qui per la decisione dell'operatore."
              />
            ) : (
              <AdoptionTable
                label="Orfani senza sede, in coda di adozione"
                items={orphans}
                locations={locations}
                mode="orphan"
                adoptPendingId={adopt.isPending ? adopt.variables?.deviceId ?? null : null}
                dismissPendingId={dismiss.isPending ? dismiss.variables ?? null : null}
                onAdopt={(deviceId, locationId) => adopt.mutate({ deviceId, locationId })}
                onDismiss={(deviceId) => dismiss.mutate(deviceId)}
              />
            )}

            {/* «Da confermare»: SOLO se presenti (impianti sensibili GAP 2) */}
            {toConfirm.length > 0 ? (
              <section className="space-y-2" aria-label="Richieste di adozione da confermare">
                <h3 className="flex items-center gap-1.5 text-sm font-medium">
                  <CircleAlert className="size-4 text-warn" aria-hidden />
                  Da confermare (<span className="num">{toConfirm.length}</span>)
                </h3>
                <AdoptionTable
                  label="Richieste di adozione da confermare"
                  items={toConfirm}
                  locations={locations}
                  mode="confirm"
                  adoptPendingId={adopt.isPending ? adopt.variables?.deviceId ?? null : null}
                  dismissPendingId={dismiss.isPending ? dismiss.variables ?? null : null}
                  onAdopt={(deviceId, locationId) => adopt.mutate({ deviceId, locationId })}
                  onDismiss={(deviceId) => dismiss.mutate(deviceId)}
                />
              </section>
            ) : null}

            <p className="text-xs text-text-2">
              Gli orfani sono host scoperti (SYS:NEW_HOST) senza sede: la decisione è sempre umana,
              mai automatica (regola v15 §13.8).
            </p>
            {queue.data ? <AsOf ts={queue.data.asOf} prefix="dati aggiornati alle" /> : null}
          </>
        )}
      </CardContent>
    </Card>
  )
}

/* ---------------- Tabella candidati adozione ---------------- */

function AdoptionTable({
  label, items, locations, mode, adoptPendingId, dismissPendingId, onAdopt, onDismiss,
}: {
  label: string
  items: AdoptionCandidate[]
  locations: Array<{ id: string; name: string }>
  mode: 'orphan' | 'confirm'
  adoptPendingId: string | null
  dismissPendingId: string | null
  onAdopt: (deviceId: string, locationId: string) => void
  onDismiss: (deviceId: string) => void
}) {
  return (
    <div
      className="max-h-[26rem] overflow-auto scroll-thin rounded-lg border border-border/70 bg-surface"
      role="region"
      aria-label={label}
      tabIndex={0}
    >
      <Table>
        <TableCaption className="sr-only">
          {label}: hostname, tipo, brand, modello, MAC, IP, firmware, ultima vista e azione
        </TableCaption>
        <TableHeader className="sticky top-0 z-10 bg-surface">
          <TableRow className="hover:bg-transparent">
            <TableHead scope="col" className="min-w-[150px]">Hostname</TableHead>
            <TableHead scope="col" className="w-[130px]">Tipo</TableHead>
            <TableHead scope="col" className="min-w-[100px]">Brand</TableHead>
            <TableHead scope="col" className="min-w-[100px]">Modello</TableHead>
            <TableHead scope="col" className="min-w-[140px]">MAC</TableHead>
            <TableHead scope="col" className="min-w-[110px]">IP</TableHead>
            <TableHead scope="col" className="min-w-[120px]">Firmware</TableHead>
            <TableHead scope="col" className="w-[110px]">Ultima vista</TableHead>
            <TableHead scope="col" className="min-w-[270px]">
              {mode === 'orphan' ? 'Adozione' : 'Azione'}
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((c) => (
            <AdoptionRow
              key={c.id}
              c={c}
              locations={locations}
              mode={mode}
              adoptPending={adoptPendingId === c.id}
              dismissPending={dismissPendingId === c.id}
              onAdopt={onAdopt}
              onDismiss={onDismiss}
            />
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

/* ---------------- Riga candidato (stato sede + conferma locale) ---------------- */

function AdoptionRow({
  c, locations, mode, adoptPending, dismissPending, onAdopt, onDismiss,
}: {
  c: AdoptionCandidate
  locations: Array<{ id: string; name: string }>
  mode: 'orphan' | 'confirm'
  adoptPending: boolean
  dismissPending: boolean
  onAdopt: (deviceId: string, locationId: string) => void
  onDismiss: (deviceId: string) => void
}) {
  const [locationId, setLocationId] = useState('')
  const [confirmOpen, setConfirmOpen] = useState(false)
  const chosenSede = locations.find((l) => l.id === locationId)?.name ?? ''

  return (
    <TableRow>
      <TableCell className="min-w-[150px]">
        <span className="block max-w-[220px] truncate font-medium" title={c.hostname}>{c.hostname}</span>
      </TableCell>
      <TableCell>
        <Badge className="bg-raised text-text-2 border-border" title={c.type ? `Tipo nel DB: ${c.type}` : undefined}>
          {c.type ? typeLabel(c.type) : 'n.d.'}
        </Badge>
      </TableCell>
      <TableCell className="text-sm"><Nd v={c.brand} /></TableCell>
      <TableCell className="text-sm"><Nd v={c.model} /></TableCell>
      <TableCell><Nd v={c.macAddress} mono /></TableCell>
      <TableCell><Nd v={c.ip} mono /></TableCell>
      <TableCell className="max-w-[160px]">
        {c.firmwareVersion ? (
          <span className="block max-w-[160px] truncate font-mono text-xs" title={c.firmwareVersion}>
            {c.firmwareVersion}
          </span>
        ) : (
          <span className="text-sm text-text-2">n.d.</span>
        )}
      </TableCell>
      <TableCell className="text-xs">
        {c.lastSeenAt ? (
          <span title={fmtDateTimeFull(c.lastSeenAt)}>{fmtRelative(c.lastSeenAt)}</span>
        ) : (
          <span className="text-text-2">mai visto</span>
        )}
      </TableCell>
      <TableCell>
        {mode === 'orphan' ? (
          <div className="flex items-center gap-2">
            <Select value={locationId} onValueChange={setLocationId}>
              <SelectTrigger
                className="w-[180px]"
                aria-label={`Sede di adozione per ${c.hostname}`}
                disabled={locations.length === 0}
              >
                <SelectValue placeholder={locations.length === 0 ? 'nessuna sede' : 'Scegli sede…'} />
              </SelectTrigger>
              <SelectContent>
                {locations.map((l) => (
                  <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
              <AlertDialogTrigger asChild>
                <Button
                  size="sm"
                  className="h-8"
                  disabled={!locationId || adoptPending}
                  aria-label={`Adotta ${c.hostname} sulla sede scelta`}
                >
                  {adoptPending
                    ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
                    : <Check className="size-3.5" aria-hidden />}
                  Adotta
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Adotta l&apos;apparato</AlertDialogTitle>
                  <AlertDialogDescription className="text-left leading-relaxed">
                    Adottare <strong className="text-foreground">{c.hostname}</strong> su sede{' '}
                    <strong className="text-foreground">{chosenSede}</strong>? L&apos;azione è
                    registrata nell&apos;audit.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={adoptPending}>Annulla</AlertDialogCancel>
                  <AlertDialogAction
                    disabled={adoptPending}
                    onClick={(e) => {
                      e.preventDefault() // resta aperto finché la mutation non risolve
                      if (!locationId || adoptPending) return
                      onAdopt(c.id, locationId)
                    }}
                  >
                    {adoptPending
                      ? <Loader2 className="size-4 animate-spin" aria-hidden />
                      : <Check className="size-4" aria-hidden />}
                    Adotta
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        ) : (
          <Button
            variant="ghost"
            size="sm"
            className="h-8"
            disabled={dismissPending}
            onClick={() => onDismiss(c.id)}
            aria-label={`Archivia la richiesta di adozione di ${c.hostname}`}
          >
            {dismissPending
              ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
              : <Archive className="size-3.5" aria-hidden />}
            Archivia richiesta
          </Button>
        )}
      </TableCell>
    </TableRow>
  )
}
