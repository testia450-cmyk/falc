/* ================================================================
 * FALCO-OS v16 — Sezione «Utenti e permessi» (16.9 ondata W4)
 * Tab della vista Amministrazione: (A) CRUD utenti REALI del DB
 * (1 utente demo SUPER_ADMIN) con policy password enterprise v15
 * (min 10, quattro classi, lista nera top-100, divieto dati
 * personali — le violazioni arrivano dal server e sono mostrate
 * tali e quali), assegnazioni impianti e guardie oneste (ultimo
 * SUPER_ADMIN, self-delete); (B) matrice RBAC v2 ispezionabile
 * (port fedele da v15 V12-B, fail-closed); (C) sessioni attive:
 * JWT stateless → tabella Session vuota PER COSTRUZIONE, la nota
 * del backend è mostrata verbatim. Mai dati inventati.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Check, Info, KeyRound, Loader2, Minus, Pencil, Plus, RefreshCw,
  ShieldCheck, Trash2, UserRound, Users,
} from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { api, ApiError } from '@/lib/client/api'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtRelative } from '@/lib/client/format'
import type { AdminUserRow, CreateUserInput, UpdateUserInput } from '@/lib/v2/contracts'
import { cn } from '@/lib/utils'

/* ---------------- Costanti sezione ---------------- */

/* Ordine delle colonne della matrice (enum ADMIN_ROLES dei contratti) */
const ROLE_ORDER = ['TECNICO', 'RESPONSABILE_COMUNE', 'SUPER_ADMIN', 'CLIENTE'] as const
type AdminRole = (typeof ROLE_ORDER)[number]

const ADMIN_ROLES: ReadonlyArray<AdminRole> = ROLE_ORDER

/* Badge ruolo (§4.2: colore + testo, mai solo colore) */
const ROLE_BADGE_META: Record<string, string> = {
  SUPER_ADMIN: 'border-primary/40 bg-primary text-primary-foreground',
  RESPONSABILE_COMUNE: 'border-warn/40 bg-warn-soft text-warn',
  TECNICO: 'border-border bg-raised text-text-2',
  CLIENTE: 'border-border text-foreground',
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* Nota: il client API v2 non espone un metodo plants() — l'endpoint
 * /api/v2/plants esiste e risponde con lo stesso envelope. Lettura
 * diretta con identica gestione errori (workaround locale: api.ts
 * non è modificabile da questa ondata). */
interface PlantRow { id: string; name: string; comune: string; isActive: boolean }

async function fetchPlants(): Promise<PlantRow[]> {
  const res = await fetch('/api/v2/plants', { headers: { Accept: 'application/json' } })
  const body = (await res.json()) as {
    ok: boolean
    error?: { code: string; message: string }
    data?: PlantRow[]
  }
  if (!body.ok || !res.ok) {
    throw new ApiError(body.error?.code ?? 'UNKNOWN', body.error?.message ?? `Errore ${res.status}`, res.status)
  }
  return body.data ?? []
}

/* ================================================================
 * Pannello «Utenti e permessi» (onda W4)
 * ================================================================ */

export function UtentiPermessiPanel() {
  return (
    <Tabs defaultValue="utenti">
      <TabsList
        aria-label="Sezioni di amministrazione: utenti, permessi, sessioni"
        className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit"
      >
        <TabsTrigger value="utenti" className="shrink-0">Utenti</TabsTrigger>
        <TabsTrigger value="permessi" className="shrink-0">Permessi</TabsTrigger>
        <TabsTrigger value="sessioni" className="shrink-0">Sessioni</TabsTrigger>
      </TabsList>
      <TabsContent value="utenti" className="mt-4">
        <UtentiSection />
      </TabsContent>
      <TabsContent value="permessi" className="mt-4">
        <PermessiSection />
      </TabsContent>
      <TabsContent value="sessioni" className="mt-4">
        <SessioniSection />
      </TabsContent>
    </Tabs>
  )
}

/* ================================================================
 * 1 — Utenti (CRUD reale, SUPER_ADMIN only)
 * ================================================================ */

function UtentiSection() {
  const queryClient = useQueryClient()

  const users = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => api.adminUsers(),
    staleTime: 30_000,
  })
  const items = users.data?.data.users ?? []

  /* Impianti per le assegnazioni (caricati solo a dialog aperto) */
  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<AdminUserRow | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<AdminUserRow | null>(null)
  const plants = useQuery({
    queryKey: ['plants'],
    queryFn: fetchPlants,
    staleTime: 60_000,
    enabled: createOpen || !!editTarget,
  })
  const plantList = plants.data ?? []

  /* --- Form creazione --- */
  const [cuName, setCuName] = useState('')
  const [cuEmail, setCuEmail] = useState('')
  const [cuPassword, setCuPassword] = useState('')
  const [cuRole, setCuRole] = useState<AdminRole>('TECNICO')
  const [cuPlants, setCuPlants] = useState<string[]>([])

  /* --- Form modifica --- */
  const [euName, setEuName] = useState('')
  const [euEmail, setEuEmail] = useState('')
  const [euRole, setEuRole] = useState<AdminRole>('TECNICO')
  const [euPassword, setEuPassword] = useState('')
  const [euMustChange, setEuMustChange] = useState(false)
  const [euPlants, setEuPlants] = useState<string[]>([])

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['admin-users'] })
  }

  const resetCreateForm = () => {
    setCuName('')
    setCuEmail('')
    setCuPassword('')
    setCuRole('TECNICO')
    setCuPlants([])
  }

  const resetEditForm = () => {
    setEuName('')
    setEuEmail('')
    setEuRole('TECNICO')
    setEuPassword('')
    setEuMustChange(false)
    setEuPlants([])
  }

  const openEdit = (u: AdminUserRow) => {
    setEuName(u.name)
    setEuEmail(u.email)
    setEuRole((ADMIN_ROLES as readonly string[]).includes(u.role) ? (u.role as AdminRole) : 'TECNICO')
    setEuPassword('')
    setEuMustChange(u.mustChangePassword)
    setEuPlants(u.plantIds)
    setEditTarget(u)
  }

  const create = useMutation({
    mutationFn: (input: CreateUserInput) => api.createUser(input),
    onSuccess: (u) => {
      toast.success('Utente creato', {
        description: `${u.email} (${u.role}): hash bcrypt(12) nel DB reale, cambio password obbligatorio al prossimo accesso.`,
      })
      resetCreateForm()
      setCreateOpen(false)
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const update = useMutation({
    mutationFn: (input: { id: string; patch: UpdateUserInput }) => api.updateUser(input.id, input.patch),
    onSuccess: (u) => {
      toast.success('Utente aggiornato', {
        description: `${u.email}: modifiche REALI nel DB (voce di audit USER_UPDATE).`,
      })
      setEditTarget(null)
      resetEditForm()
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Aggiornamento non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteUser(id),
    onSuccess: () => {
      setDeleteTarget(null)
      toast.success('Utente eliminato', {
        description: 'Cancellazione REALE dal DB con voce di audit USER_DELETE.',
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submitCreate = () => {
    const name = cuName.trim()
    const email = cuEmail.trim()
    if (!name || !email || cuPassword.length < 10 || create.isPending) return
    create.mutate({
      name,
      email,
      password: cuPassword,
      role: cuRole,
      plantIds: cuPlants.length > 0 ? cuPlants : undefined,
    })
  }

  const submitUpdate = () => {
    if (!editTarget || update.isPending) return
    const patch: UpdateUserInput = {
      name: euName.trim(),
      email: euEmail.trim(),
      role: euRole,
      mustChangePassword: euMustChange,
      plantIds: euPlants,
    }
    if (euPassword.length >= 10) patch.password = euPassword
    update.mutate({ id: editTarget.id, patch })
  }

  const togglePlant = (
    setter: React.Dispatch<React.SetStateAction<string[]>>,
    id: string,
    checked: boolean,
  ) => {
    setter((prev) => (checked ? [...prev, id] : prev.filter((x) => x !== id)))
  }

  return (
    <div className="grid min-w-0 grid-cols-1 gap-4">
      <Card className="min-w-0 border-border/70 bg-surface">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
            <Users className="size-4 text-text-2" aria-hidden />
            Utenti
            {users.data ? (
              <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
                {fmtNumber(users.data.data.total)} totali
              </Badge>
            ) : null}
          </CardTitle>
          <CardDescription>
            CRUD reale del DB (richiede SUPER_ADMIN): ruoli, cambio password obbligatorio,
            assegnazioni impianti. Le guardie del server (ultimo SUPER_ADMIN, self-delete)
            e la policy password sono mostrate tali e quando rifiutano.
          </CardDescription>
          <CardAction className="flex items-center gap-1.5">
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => { void users.refetch() }}
              disabled={users.isFetching}
              aria-label="Aggiorna l'elenco degli utenti"
            >
              <RefreshCw className={cn('size-3.5', users.isFetching && 'animate-spin')} aria-hidden />
            </Button>
            <Button size="sm" className="h-8" onClick={() => setCreateOpen(true)}>
              <Plus className="size-3.5" aria-hidden /> Nuovo utente
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent className="space-y-3">
          {users.isPending ? (
            <LoadingRows rows={3} />
          ) : users.isError ? (
            /* 403 FORBIDDEN per sessioni non SUPER_ADMIN: messaggio server verbatim */
            <ErrorPanel
              message={errInfo(users.error).message}
              code={errInfo(users.error).code}
              onRetry={() => { void users.refetch() }}
            />
          ) : (
            <>
              {items.length === 0 ? (
                <EmptyState
                  icon={<Users className="size-10" aria-hidden />}
                  title="Nessun utente"
                  description="0 righe User nel database reale: il primo account nasce da «Nuovo utente» (richiede ruolo SUPER_ADMIN)."
                  action={
                    <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                      <Plus className="size-3.5" aria-hidden /> Nuovo utente
                    </Button>
                  }
                />
              ) : (
                <div
                  className="overflow-x-auto rounded-lg border border-border/70"
                  role="region"
                  aria-label="Utenti del sistema, tabella scorribile"
                  tabIndex={0}
                >
                  <Table>
                    <TableCaption className="sr-only">
                      Utenti: nome, email, ruolo, obbligo cambio password, 2FA, impianti assegnati, sessioni persistite e data di creazione
                    </TableCaption>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead scope="col" className="min-w-[140px]">Nome</TableHead>
                        <TableHead scope="col" className="min-w-[180px]">Email</TableHead>
                        <TableHead scope="col" className="min-w-[150px]">Ruolo</TableHead>
                        <TableHead scope="col" className="min-w-[120px]">Stato</TableHead>
                        <TableHead scope="col" className="min-w-[90px]">Impianti</TableHead>
                        <TableHead scope="col" className="min-w-[130px]">Sessioni</TableHead>
                        <TableHead scope="col" className="min-w-[110px]">Creato</TableHead>
                        <TableHead scope="col" className="w-[150px] text-right">Azioni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((u) => (
                        <TableRow key={u.id}>
                          <TableCell>
                            <span className="block max-w-[160px] truncate text-xs font-medium" title={u.name}>{u.name}</span>
                          </TableCell>
                          <TableCell>
                            <span className="block max-w-[220px] truncate text-xs" title={u.email}>{u.email}</span>
                          </TableCell>
                          <TableCell><RoleBadge role={u.role} /></TableCell>
                          <TableCell>
                            <span className="flex flex-wrap gap-1">
                              {u.mustChangePassword ? (
                                <Badge variant="outline" className="border-warn/40 bg-warn-soft font-normal text-warn">cambio password</Badge>
                              ) : null}
                              {u.totpEnabled ? (
                                <Badge variant="outline" className="border-ok/40 bg-ok-soft font-normal text-ok">2FA</Badge>
                              ) : null}
                              {!u.mustChangePassword && !u.totpEnabled ? <span className="text-xs text-text-2">—</span> : null}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="text-xs" title={u.plantIds.length > 0 ? u.plantIds.join(', ') : 'nessuna assegnazione'}>
                              {u.plantIds.length > 0
                                ? <><span className="num font-medium">{fmtNumber(u.plantIds.length)}</span>{u.plantIds.length === 1 ? ' impianto' : ' impianti'}</>
                                : <span className="text-text-2">nessuno</span>}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="text-xs">
                              <span className="num">{fmtNumber(u.sessionCount)}</span>
                              {u.sessionCount === 0 ? <span className="text-text-2"> (JWT stateless)</span> : null}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="num text-xs" title={fmtDateTimeFull(u.createdAt)}>{fmtDateTime(u.createdAt)}</span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8"
                                onClick={() => openEdit(u)}
                                aria-label={`Modifica l'utente ${u.email}`}
                              >
                                <Pencil className="size-3.5" aria-hidden /> Modifica
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-crit-text hover:text-crit-text"
                                onClick={() => setDeleteTarget(u)}
                                aria-label={`Elimina l'utente ${u.email}`}
                              >
                                <Trash2 className="size-3.5" aria-hidden />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
              {users.data ? <AsOf ts={users.data.asOf} prefix="utenti alle" /> : null}
            </>
          )}

          {/* Nota di contesto (onesto: dati del DB reale) */}
          <p className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2" role="note">
            Nel DB reale esiste 1 utente (admin demo SUPER_ADMIN). La policy password enterprise v15 è
            attiva: min 10 caratteri, quattro classi, lista nera top-100, divieto dati personali —
            le violazioni arrivano dal server e sono mostrate tali e quali.
          </p>
        </CardContent>
      </Card>

      {/* --- Dialog: nuovo utente --- */}
      <Dialog
        open={createOpen}
        onOpenChange={(open) => {
          setCreateOpen(open)
          if (!open) resetCreateForm()
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuovo utente</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Creazione REALE nel DB: hash bcrypt(12), cambio password obbligatorio al primo accesso
              e voce di audit USER_CREATE. La policy password è verificata dal server.
            </DialogDescription>
          </DialogHeader>

          <form
            className="grid gap-3"
            onSubmit={(e) => { e.preventDefault(); submitCreate() }}
            noValidate
            aria-label="Form di creazione utente"
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="cu-name" className="text-xs font-medium text-text-2">Nome *</label>
                <Input
                  id="cu-name"
                  value={cuName}
                  maxLength={100}
                  onChange={(e) => setCuName(e.target.value)}
                  placeholder="es. Mario Rossi"
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="cu-email" className="text-xs font-medium text-text-2">Email *</label>
                <Input
                  id="cu-email"
                  type="email"
                  value={cuEmail}
                  maxLength={200}
                  onChange={(e) => setCuEmail(e.target.value)}
                  placeholder="es. mario.rossi@comune.it"
                  aria-required="true"
                  autoComplete="off"
                />
              </div>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="cu-password" className="text-xs font-medium text-text-2">Password *</label>
              <Input
                id="cu-password"
                type="password"
                value={cuPassword}
                maxLength={128}
                onChange={(e) => setCuPassword(e.target.value)}
                placeholder="min 10 caratteri, quattro classi"
                aria-required="true"
                autoComplete="new-password"
              />
              <p className="text-xs text-text-2">
                policy enterprise v15: min 10 caratteri, quattro classi (minuscola, maiuscola, cifra,
                simbolo), lista nera top-100, divieto dati personali (email/nome).
              </p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="cu-role" className="text-xs font-medium text-text-2">Ruolo *</label>
              <Select value={cuRole} onValueChange={(v) => setCuRole(v as AdminRole)}>
                <SelectTrigger id="cu-role" className="w-full" aria-label="Ruolo del nuovo utente">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ADMIN_ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{r}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <p className="text-xs font-medium text-text-2">
                Impianti assegnati (opzionale · <span className="num">{fmtNumber(cuPlants.length)}</span> selezionati)
              </p>
              {plants.isPending ? (
                <LoadingRows rows={2} />
              ) : plants.isError ? (
                <p className="text-xs text-crit-text" role="alert">
                  Impianti non disponibili: {errInfo(plants.error).message}
                </p>
              ) : (
                <PlantCheckList
                  plants={plantList}
                  selected={cuPlants}
                  onToggle={(id, checked) => togglePlant(setCuPlants, id, checked)}
                  idPrefix="cu-plant"
                />
              )}
            </div>
          </form>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setCreateOpen(false); resetCreateForm() }}>
              Annulla
            </Button>
            <Button
              onClick={submitCreate}
              disabled={create.isPending || cuName.trim().length === 0 || cuEmail.trim().length === 0 || cuPassword.length < 10}
            >
              {create.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
              Crea utente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Dialog: modifica utente --- */}
      <Dialog
        open={!!editTarget}
        onOpenChange={(open) => {
          if (!open && !update.isPending) {
            setEditTarget(null)
            resetEditForm()
          }
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Modifica · {editTarget?.email}</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Aggiornamento REALE nel DB (voce di audit USER_UPDATE). Il perimetro impianti è
              sostituito integralmente e in modo atomico. Guardie server: email già registrata
              (409 CONFLICT), ultimo SUPER_ADMIN (INVALID_STATE) — i messaggi sono mostrati tali e quali.
            </DialogDescription>
          </DialogHeader>

          <form
            className="grid gap-3"
            onSubmit={(e) => { e.preventDefault(); submitUpdate() }}
            noValidate
            aria-label="Form di modifica utente"
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <label htmlFor="eu-name" className="text-xs font-medium text-text-2">Nome *</label>
                <Input
                  id="eu-name"
                  value={euName}
                  maxLength={100}
                  onChange={(e) => setEuName(e.target.value)}
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="eu-email" className="text-xs font-medium text-text-2">Email *</label>
                <Input
                  id="eu-email"
                  type="email"
                  value={euEmail}
                  maxLength={200}
                  onChange={(e) => setEuEmail(e.target.value)}
                  aria-required="true"
                  autoComplete="off"
                />
              </div>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="eu-role" className="text-xs font-medium text-text-2">Ruolo</label>
              <Select value={euRole} onValueChange={(v) => setEuRole(v as AdminRole)}>
                <SelectTrigger id="eu-role" className="w-full" aria-label="Ruolo dell'utente">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ADMIN_ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{r}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="eu-password" className="text-xs font-medium text-text-2">Password (opzionale)</label>
              <Input
                id="eu-password"
                type="password"
                value={euPassword}
                maxLength={128}
                onChange={(e) => setEuPassword(e.target.value)}
                placeholder="lascia vuoto per non cambiare"
                autoComplete="new-password"
              />
              <p className="text-xs text-text-2">
                lascia vuoto per non cambiare — policy: min 10, 4 classi, lista nera; il reset invalida
                le sessioni esistenti.
              </p>
            </div>
            <div className="flex items-center gap-2.5">
              <Switch
                id="eu-must"
                checked={euMustChange}
                onCheckedChange={setEuMustChange}
                aria-label="Obbligo cambio password al prossimo accesso"
              />
              <label htmlFor="eu-must" className="text-xs text-text-2">
                cambio password obbligatorio al prossimo accesso
              </label>
            </div>
            <div className="grid gap-1.5">
              <p className="text-xs font-medium text-text-2">
                Impianti assegnati · <span className="num">{fmtNumber(euPlants.length)}</span> selezionati
              </p>
              {plants.isPending ? (
                <LoadingRows rows={2} />
              ) : plants.isError ? (
                <p className="text-xs text-crit-text" role="alert">
                  Impianti non disponibili: {errInfo(plants.error).message}
                </p>
              ) : (
                <PlantCheckList
                  plants={plantList}
                  selected={euPlants}
                  onToggle={(id, checked) => togglePlant(setEuPlants, id, checked)}
                  idPrefix="eu-plant"
                />
              )}
            </div>
          </form>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => { setEditTarget(null); resetEditForm() }}
              disabled={update.isPending}
            >
              Annulla
            </Button>
            <Button
              onClick={submitUpdate}
              disabled={update.isPending || euName.trim().length === 0 || euEmail.trim().length === 0 || (euPassword.length > 0 && euPassword.length < 10)}
            >
              {update.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Pencil className="size-3.5" aria-hidden />}
              Salva modifiche
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Conferma eliminazione (guardie server oneste) --- */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o && !remove.isPending) setDeleteTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare «{deleteTarget?.email ?? ''}»?</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Eliminazione REALE dal DB con voce di audit USER_DELETE. Guardie del server mostrate
              onestamente: non puoi eliminare <strong className="text-foreground">te stesso</strong> e non
              puoi eliminare l&apos;<strong className="text-foreground">ultimo SUPER_ADMIN</strong> — in
              quei casi la risposta INVALID_STATE viene mostrata tale e quale.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {deleteTarget ? (
            <p className="break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2">
              {deleteTarget.name} · {deleteTarget.role} · creato {fmtDateTime(deleteTarget.createdAt)}{' '}
              ({fmtRelative(deleteTarget.createdAt)})
            </p>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={remove.isPending}
              onClick={(e) => {
                e.preventDefault() // resta aperto finché la risposta reale non arriva
                if (!deleteTarget || remove.isPending) return
                remove.mutate(deleteTarget.id)
              }}
            >
              {remove.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

/* ================================================================
 * 2 — Matrice permessi RBAC (v2, ispezionabile)
 * ================================================================ */

function PermessiSection() {
  const perms = useQuery({
    queryKey: ['admin-permissions'],
    queryFn: () => api.adminPermissions(),
    staleTime: 300_000,
  })
  const data = perms.data?.data

  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <ShieldCheck className="size-4 text-text-2" aria-hidden />
          Matrice permessi RBAC
          {data ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              v{data.version} · {fmtNumber(data.catalog.length)} permessi
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          «Chi può fare cosa», dichiarato in un punto ispezionabile: righe per permesso, colonne per
          ruolo. I valori sono quelli del catalogo REALE servito dal backend.
        </CardDescription>
        <CardAction>
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            onClick={() => { void perms.refetch() }}
            disabled={perms.isFetching}
            aria-label="Aggiorna la matrice dei permessi"
          >
            <RefreshCw className={cn('size-3.5', perms.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-3">
        {perms.isPending ? (
          <LoadingRows rows={6} />
        ) : perms.isError ? (
          <ErrorPanel
            message={errInfo(perms.error).message}
            code={errInfo(perms.error).code}
            onRetry={() => { void perms.refetch() }}
          />
        ) : data ? (
          <>
            <div
              className="overflow-x-auto rounded-lg border border-border/70"
              role="region"
              aria-label="Matrice permessi per ruolo, tabella scorribile"
              tabIndex={0}
            >
              <Table>
                <TableCaption className="sr-only">
                  Matrice RBAC: per ogni permesso del catalogo, i ruoli che lo posseggono (spunta verde) o no (trattino)
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="min-w-[200px]">Permesso</TableHead>
                    {ROLE_ORDER.map((r) => (
                      <TableHead key={r} scope="col" className="min-w-[90px] text-center">{r}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.modules.flatMap((m) => [
                    <TableRow key={`mod-${m.module}`} className="hover:bg-transparent">
                      <TableCell colSpan={5} className="bg-raised/40 text-xs font-medium text-text-2">
                        modulo <span className="font-mono">{m.module}</span>
                        <span className="num ml-1.5">({fmtNumber(m.permissions.length)})</span>
                      </TableCell>
                    </TableRow>,
                    ...m.permissions.map((p) => (
                      <TableRow key={p}>
                        <TableCell>
                          <span className="block max-w-[220px] truncate font-mono text-xs" title={p}>{p}</span>
                        </TableCell>
                        {ROLE_ORDER.map((r) => {
                          const has = (data.roles[r] ?? []).includes(p)
                          return (
                            <TableCell key={r} className="text-center">
                              {has ? (
                                <span className="inline-flex text-ok" title={`${r}: permesso concesso`}>
                                  <Check className="size-4" aria-hidden />
                                  <span className="sr-only">concesso</span>
                                </span>
                              ) : (
                                <span className="inline-flex text-text-2" title={`${r}: non concesso`}>
                                  <Minus className="size-4" aria-hidden />
                                  <span className="sr-only">non concesso</span>
                                </span>
                              )}
                            </TableCell>
                          )
                        })}
                      </TableRow>
                    )),
                  ])}
                </TableBody>
              </Table>
            </div>
            <p className="text-xs leading-relaxed text-text-2" role="note">
              Catalogo v{data.version} · {fmtNumber(data.catalog.length)} permessi · matrice portata
              fedele da v15 (V12-B). SUPER_ADMIN = tutti espliciti; fail-closed.
            </p>
            {perms.data ? <AsOf ts={perms.data.asOf} prefix="catalogo alle" /> : null}
          </>
        ) : null}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * 3 — Sessioni attive (JWT stateless: 0 righe per costruzione)
 * ================================================================ */

function SessioniSection() {
  const sessions = useQuery({
    queryKey: ['admin-sessions'],
    queryFn: () => api.adminSessions(),
    staleTime: 60_000,
  })
  const data = sessions.data?.data

  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <UserRound className="size-4 text-text-2" aria-hidden />
          Sessioni attive
          {data ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              {fmtNumber(data.total)} persistite
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Sessioni persistite nel DB: la tabella Session resta vuota per costruzione (JWT stateless),
          la nota del backend lo dichiara invece di mostrare un errore.
        </CardDescription>
        <CardAction>
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            onClick={() => { void sessions.refetch() }}
            disabled={sessions.isFetching}
            aria-label="Aggiorna l'elenco delle sessioni"
          >
            <RefreshCw className={cn('size-3.5', sessions.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-3">
        {sessions.isPending ? (
          <LoadingRows rows={3} />
        ) : sessions.isError ? (
          <ErrorPanel
            message={errInfo(sessions.error).message}
            code={errInfo(sessions.error).code}
            onRetry={() => { void sessions.refetch() }}
          />
        ) : data ? (
          <>
            {/* Nota del backend, verbatim (onestà D2) */}
            <Alert className="border-border/70 bg-raised/40" role="note">
              <Info className="size-4 text-text-2" aria-hidden />
              <AlertTitle className="text-sm font-medium">Come funzionano le sessioni</AlertTitle>
              <AlertDescription className="text-xs">
                <p className="leading-relaxed text-text-2">{data.note}</p>
              </AlertDescription>
            </Alert>

            {data.sessions.length === 0 ? (
              <EmptyState
                icon={<KeyRound className="size-10" aria-hidden />}
                title="0 sessioni persistite (JWT stateless)"
                description="La tabella Session resta vuota per costruzione: l'autenticazione usa token JWT firmati a 12 ore, nulla da elencare qui."
              />
            ) : (
              <div
                className="overflow-x-auto rounded-lg border border-border/70"
                role="region"
                aria-label="Sessioni persistite, tabella scorribile"
                tabIndex={0}
              >
                <Table>
                  <TableCaption className="sr-only">
                    Sessioni persistite nel database: email, ruolo e scadenza
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col" className="min-w-[200px]">Email</TableHead>
                      <TableHead scope="col" className="min-w-[150px]">Ruolo</TableHead>
                      <TableHead scope="col" className="min-w-[140px]">Scadenza</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.sessions.map((s) => (
                      <TableRow key={s.id}>
                        <TableCell>
                          <span className="block max-w-[240px] truncate text-xs" title={s.userEmail}>{s.userEmail}</span>
                        </TableCell>
                        <TableCell><RoleBadge role={s.userRole} /></TableCell>
                        <TableCell>
                          <span className="num text-xs" title={fmtDateTimeFull(s.expires)}>{fmtDateTime(s.expires)}</span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
            {sessions.data ? <AsOf ts={sessions.data.asOf} prefix="sessioni alle" /> : null}
          </>
        ) : null}
      </CardContent>
    </Card>
  )
}

/* ---------------- Helper visuali ---------------- */

function RoleBadge({ role }: { role: string }) {
  const cls = ROLE_BADGE_META[role]
  return (
    <Badge variant="outline" className={cn('num font-normal', cls ?? 'border-border bg-raised text-text-2')} title={`Ruolo ${role}`}>
      {role}
    </Badge>
  )
}

function PlantCheckList({
  plants,
  selected,
  onToggle,
  idPrefix,
}: {
  plants: PlantRow[]
  selected: string[]
  onToggle: (id: string, checked: boolean) => void
  idPrefix: string
}) {
  if (plants.length === 0) {
    return (
      <p className="text-xs text-text-2" role="note">
        Nessun impianto nel DB reale: l&apos;assegnazione resta vuota (nessuna riga Plant).
      </p>
    )
  }
  return (
    <div
      className="grid max-h-40 gap-1 overflow-y-auto scroll-thin rounded-md border border-border/70 bg-raised/30 p-2"
      role="group"
      aria-label="Impianti assegnabili"
    >
      {plants.map((p) => (
        <label
          key={p.id}
          htmlFor={`${idPrefix}-${p.id}`}
          className="flex cursor-pointer items-center gap-2.5 rounded px-1 py-0.5 hover:bg-raised/40"
        >
          <Checkbox
            id={`${idPrefix}-${p.id}`}
            checked={selected.includes(p.id)}
            onCheckedChange={(c) => onToggle(p.id, c === true)}
          />
          <span className="min-w-0 flex-1 truncate text-xs">
            {p.name}
            <span className="text-text-2"> · {p.comune}</span>
          </span>
        </label>
      ))}
    </div>
  )
}
