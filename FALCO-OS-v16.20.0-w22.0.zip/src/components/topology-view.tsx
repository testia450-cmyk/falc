/* ================================================================
 * FALCO-OS v16 — Topologia logica (§6.2, vista «Rete»)
 * Due rappresentazioni sullo STESSO albero /api/v2/topology/graph:
 *
 * · RAGGIERA (16.11 W9, DEFAULT): fan-out a card per sede richiesto
 *   dall'operatore con immagine di riferimento — radice a sinistra,
 *   card sedi impilate a destra, linee tratteggiate colorate per
 *   stato (vedi topology-fanout.tsx);
 * · GRAFO (W8): canvas @xyflow/react con layout ELK (layered, DOWN)
 *   calcolato UNA volta per caricamento dati (+ «Ridisegna»):
 *   nessun re-layout a ogni evento realtime. Zoom semantico: sotto
 *   0.55 i nodi diventano cerchi di stato con etichetta (scrim).
 *
 * Nessun nodo/arco inventato: tutto arriva da api.topologyGraph().
 *
 * 16.10.0 W8 — «la topologia riportata non è quella reale»: le
 * letture SNMP del bridge (FDB/BRIDGE_MIB/DAISY_CHAIN) sono fragili
 * e perfino LLDP/UISP producono una stella piatta. L'albero ora è
 * FILTRABILE per famiglia di fonti (chip sopra il canvas, stato
 * nell'URL ?fonti=…), con riga di onestà sui collegamenti
 * inclusi/esclusi e badge della provenienza della radice. La
 * correzione vera (conferma/correzione/eliminazione/purge) vive nel
 * gestore collegamenti (topology-links-manager.tsx).
 * ================================================================ */

'use client'

import { useCallback, useEffect, useMemo, useRef, useState, type MouseEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  ReactFlow, ReactFlowProvider, Panel, Controls, MiniMap, BaseEdge, EdgeLabelRenderer, getSmoothStepPath, Handle, Position,
  useNodesState, useEdgesState, useReactFlow, useStore,
  type Node, type NodeProps, type Edge, type EdgeProps, type NodeTypes, type EdgeTypes,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import ELK from 'elkjs/lib/elk.bundled.js'
import { Maximize, ZoomIn, ZoomOut, RefreshCw, Loader2, Signal, ArrowDown, ListTree, Unplug, RadioTower, Network, Cable, CircleAlert, CircleCheck, ShieldCheck, TrendingUp, UserPlus } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { api } from '@/lib/client/api'
import { ARP_ADOPTION_TYPES, ARP_ADOPTION_CONNECTION_TYPES, type ArpAdoptionResult, type DiscoveryL2BatchInput, type DiscoveryL2BatchResult, type DiscoveryL2Result } from '@/lib/v2/contracts'
import { useApp } from '@/lib/client/store'
import { DEFAULT_GRAPH_SOURCES } from '@/lib/v2/contracts'
import { useTheme } from 'next-themes'
import { fmtDbm, fmtMbps, fmtNumber, typeLabel, STATUS_META } from '@/lib/client/format'
import { usePalette, statusColor, DARK_PALETTE, type ThemePalette } from '@/lib/client/theme-palette'
import { StatusBadge } from '@/components/status-badge'
import { EmptyState, ErrorPanel } from '@/components/states'
import TopologyFanout from '@/components/topology-fanout'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/lib/utils'

/* ---------------- Tipi (dal contratto API, mai inventati) ---------------- */

export type TopoGraphData = Awaited<ReturnType<typeof api.topologyGraph>>['data']
export type TopoNode = TopoGraphData['nodes'][number]
export type TopoEdge = TopoGraphData['edges'][number]

type FalcoNodeData = { d: TopoNode; epoch: number }
export type FalcoNode = Node<FalcoNodeData, 'falco'>
type FalcoEdgeData = { e: TopoEdge; targetDown: boolean }
export type FalcoEdge = Edge<FalcoEdgeData, 'falco-edge'>

/* ---------------- Famiglie di fonti (16.10 W8 · v16.8 CDP) ---------------- */

/** Filtro del grafo per FAMIGLIA di provenienza dei collegamenti.
 * Default attive: TECHNICIAN + PROTOCOLS (LLDP/CDP/MNDP) + UISP;
 * INFERRED resta spenta: le letture SNMP del bridge che l'operatore ha
 * dichiarato inaffidabili NON entrano nell'albero finché non le accende
 * (v16.8: la «Ricostruzione L2» le propone in automatico quando produce
 * link FDB/DAISY_CHAIN REALI). */
export const SOURCE_FAMILIES = [
  { key: 'TECHNICIAN', members: ['TECHNICIAN'], label: 'Operatore (confermati)', hint: 'verità dichiarata dal tecnico' },
  { key: 'PROTOCOLS', members: ['LLDP', 'CDP', 'MNDP'], label: 'Protocolli (LLDP/CDP/MNDP)', hint: 'dichiarati dai dispositivi' },
  { key: 'UISP', members: ['UISP'], label: 'UISP', hint: 'dichiarati dalla gestione esterna' },
  { key: 'INFERRED', members: ['INFERRED', 'FDB', 'BRIDGE_MIB', 'DAISY_CHAIN', 'FDB_MUTUAL', 'FDB_PAIR', 'STP_DESIGNATED'], label: 'Inferiti (bridge/FDB)', hint: 'letture SNMP del bridge: FDB/Q-BRIDGE, segmenti daisy-chain e correlazione multi-switch (v16.15: FDB_MUTUAL/FDB_PAIR/STP_DESIGNATED)' },
] as const

const DEFAULT_FAMILY_KEYS: readonly string[] = ['TECHNICIAN', 'PROTOCOLS', 'UISP']

/** Chiavi famiglia attive dal valore grezzo dell'URL (?fonti=…).
 * Valori non riconosciuti → default (mai un filtro «rotto»). */
function familyKeysFromStore(raw: string | null | undefined): string[] {
  if (!raw) return [...DEFAULT_FAMILY_KEYS]
  const known = SOURCE_FAMILIES.map((f) => f.key as string)
  const parsed = raw
    .split(',')
    .map((k) => k.trim().toUpperCase())
    .filter((k) => known.includes(k))
  return parsed.length > 0 ? parsed : [...DEFAULT_FAMILY_KEYS]
}

/** Mappa le chiavi famiglia (o null = default) ai membri LINK_SOURCES
 * che il backend accetta su /topology/graph?sources=…. Usata sia dal
 * canvas sia dal pannello dettaglio della vista Rete (stessa query key). */
export function topoSourceMembers(keys: string | null): string[] {
  const families = familyKeysFromStore(keys)
  const members = families.flatMap((k) => {
    const f = SOURCE_FAMILIES.find((x) => x.key === k)
    return f ? [...f.members] : []
  })
  return members.length > 0 ? members : [...DEFAULT_GRAPH_SOURCES]
}

/* ---------------- Costanti di rendering ---------------- */

const NODE_W = 240
const NODE_H = 72
/** Sotto questo zoom il nodo si riduce a cerchio di stato + etichetta */
const MINI_ZOOM = 0.55

/** «Nodo giù» per la colorazione degli archi: mai risponde / non raggiunto */
export function isDownStatus(s: string | undefined): boolean {
  return s === 'OFFLINE' || s === 'UNKNOWN' || s === 'NOT_MONITORED'
}

/** Colore/tratteggio dell'arco per FAMIGLIA DI EVIDENZA (16.10 W8,
 * v16.8: +CDP), priorità: giù > confermato operatore > protocollo >
 * UISP > inferito. La palette segue il tema attivo (chiaro/scuro). */
export function edgeVisual(e: TopoEdge, targetDown: boolean, p: ThemePalette = DARK_PALETTE): { color: string; dash?: string } {
  if (targetDown) return { color: p.crit, dash: '5 4' }
  if (e.manual) return { color: p.ok }
  const ev = (e.evidence ?? '').toUpperCase()
  if (ev.includes('LLDP') || ev.includes('MNDP') || ev.includes('CDP')) return { color: p.controlBorder }
  if (ev.includes('UISP')) return { color: p.info, dash: '6 3' }
  if (ev.includes('FDB') || ev.includes('BRIDGE_MIB') || ev.includes('DAISY_CHAIN') || ev.includes('STP_DESIGNATED')) return { color: p.text2, dash: '2 4' }
  // evidenza ignota/storica (PORT_MAP, WIRELESS, vuota…): tratto principale
  return { color: p.controlBorder }
}

/** Famiglia di fonte di un arco del GRAFO (16.10 W8): il contratto espone
 * solo evidence+manual (NON sourceOfTruth) — la famiglia è derivata con
 * la STESSA priorità di edgeVisual per i badge del pannello dettaglio.
 * Il valore grezzo dell'evidenza resta comunque visibile nella dl. */
export function edgeSourceFamily(e: TopoEdge): string {
  if (e.manual) return 'TECHNICIAN'
  const ev = (e.evidence ?? '').toUpperCase()
  if (ev.includes('LLDP')) return 'LLDP'
  if (ev.includes('CDP')) return 'CDP'
  if (ev.includes('MNDP')) return 'MNDP'
  if (ev.includes('UISP')) return 'UISP'
  if (ev.includes('BRIDGE_MIB')) return 'BRIDGE_MIB'
  if (ev.includes('FDB')) return 'FDB'
  if (ev.includes('STP_DESIGNATED')) return 'STP_DESIGNATED'
  if (ev.includes('DAISY_CHAIN')) return 'DAISY_CHAIN'
  return ev
}

/* ---------------- Layout ELK ---------------- */

const elk = new ELK()

const ELK_OPTIONS: Record<string, string> = {
  'elk.algorithm': 'layered',
  'elk.direction': 'DOWN',
  'elk.layered.spacing.nodeNodeBetweenLayers': '60',
  'elk.spacing.nodeNode': '28',
  'elk.layered.nodePlacement.strategy': 'NETWORK_SIMPLEX',
  'elk.padding': '[40,40,40,40]',
}

/** Ordine di famiglia per il raggruppamento visivo (specchia il TYPE_RANK
 * del backend: l'ordine di inserimento determina i cluster di ELK). */
const TYPE_RANK: Record<string, number> = {
  GATEWAY: 0, ROUTER: 1, FIREWALL: 2, SWITCH: 3,
  AP: 10, STA: 11,
  NVR: 20, CAMERA: 21, LPR: 22,
  SERVER: 30,
}

/** Calcola le posizioni assolute dei nodi (grafo piatto, no compound). */
async function layoutGraph(
  nodes: TopoNode[],
  edges: TopoEdge[],
): Promise<Map<string, { x: number; y: number }>> {
  const graph = {
    id: 'root',
    layoutOptions: ELK_OPTIONS,
    children: nodes.map((n) => ({ id: n.id, width: NODE_W, height: NODE_H })),
    edges: edges.map((e) => ({ id: e.id, sources: [e.source], targets: [e.target] })),
  }
  const result = await elk.layout(graph)
  const positions = new Map<string, { x: number; y: number }>()
  for (const child of result.children ?? []) {
    positions.set(child.id, { x: child.x ?? 0, y: child.y ?? 0 })
  }
  return positions
}

/* ---------------- Nodo custom (zoom semantico) ---------------- */

/* Handle di connessione: xyflow NON aggancia archi a nodi custom senza
 * <Handle> (era il difetto «Couldn't create edge for source handle»). */
const HANDLE_CLS = '!absolute !left-1/2 !h-[7px] !w-[7px] !-translate-x-1/2 !border-0 !bg-transparent !opacity-0 !pointer-events-none'

function NodeHandles() {
  return (
    <>
      <Handle type="target" position={Position.Top} className={HANDLE_CLS} isConnectable={false} />
      <Handle type="source" position={Position.Bottom} className={HANDLE_CLS} isConnectable={false} />
    </>
  )
}

function FalcoNodeCard({ data, selected }: NodeProps<FalcoNode>) {
  const zoom = useStore((s) => s.transform[2])
  const p = usePalette()
  const d = data.d
  const color = statusColor(d.uiStatus, p)
  const statusLabel = STATUS_META[d.uiStatus]?.label ?? d.uiStatus

  /* Zoom ampio: vista mini — cerchio di stato + hostname con scrim */
  if (zoom < MINI_ZOOM) {
    return (
      <div
        className="flex h-full w-full flex-col items-center justify-center gap-1.5"
        title={`${d.hostname} — ${statusLabel}`}
      >
        <NodeHandles />
        <span
          className="size-5 rounded-full border-2"
          style={{ background: color, borderColor: p.markerRing, boxShadow: `0 0 0 1px ${p.controlBorder}55` }}
          aria-hidden
        />
        <span className="scrim-label max-w-full truncate text-[10px] font-medium text-foreground">
          {d.hostname}
        </span>
      </div>
    )
  }

  /* Zoom ravvicinato: card completa */
  const isRadio = d.type === 'AP' || d.type === 'STA'
  return (
    <div
      className={cn(
        'flex h-full w-full items-stretch overflow-hidden rounded-lg border bg-surface text-left shadow-md',
        selected ? 'border-link ring-1 ring-link/60' : 'border-border hover:border-control-border/70',
      )}
      title={`${d.hostname} · ${d.ip || 'n.d.'} · ${statusLabel}`}
    >
      <NodeHandles />
      <span className="w-1 shrink-0" style={{ background: color }} aria-hidden />
      <div className="flex min-w-0 flex-1 flex-col justify-center gap-1 px-3 py-2">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-[13px] font-semibold leading-tight">{d.hostname}</p>
          <StatusBadge status={d.uiStatus} size="xs" className="shrink-0" />
        </div>
        <p className="truncate text-[11px] leading-tight text-text-2">
          {typeLabel(d.type)}{d.model ? ` · ${d.model}` : ''}
        </p>
        <div className="flex items-center gap-2 text-[11px] leading-none text-text-2">
          {isRadio && d.signalDbm != null ? (
            <span className="num inline-flex items-center gap-1">
              <Signal className="size-3" aria-hidden />
              {fmtDbm(d.signalDbm)}
            </span>
          ) : null}
          {d.downstreamCount > 0 ? (
            <span className="num inline-flex items-center gap-0.5 rounded-full border border-border bg-raised/60 px-1.5 py-0.5">
              <ArrowDown className="size-2.5" aria-hidden />
              {d.downstreamCount} a valle
            </span>
          ) : null}
          <span className="num ml-auto shrink-0" title={`Livello nell'albero: ${d.tier}`}>
            T{d.tier}
          </span>
        </div>
      </div>
    </div>
  )
}

/* ---------------- Arco custom (smoothstep + colori + traffico) ---------------- */

function FalcoEdgeView({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, data, selected }: EdgeProps<FalcoEdge>) {
  const zoom = useStore((s) => s.transform[2])
  const p = usePalette()
  if (!data) return null
  const { e, targetDown } = data

  const [path, labelX, labelY] = getSmoothStepPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    borderRadius: 14,
  })
  const v = edgeVisual(e, targetDown, p)
  /* Etichetta traffico: solo a zoom ravvicinato e solo se c'è traffico misurato */
  const showTraffic = zoom > 0.9 && (e.trafficInMbps > 0 || e.trafficOutMbps > 0)

  return (
    <>
      <BaseEdge
        id={id}
        path={path}
        style={{
          stroke: v.color,
          /* il collegamento confermato dall'operatore è più marcato */
          strokeWidth: selected ? 2.6 : e.manual ? 2.5 : 1.7,
          strokeDasharray: v.dash,
        }}
      />
      {showTraffic ? (
        <EdgeLabelRenderer>
          <div
            className="scrim-label nodrag nopan pointer-events-none absolute num whitespace-nowrap text-[10px] font-medium text-foreground"
            style={{ transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)` }}
          >
            ↓ {fmtMbps(e.trafficInMbps)} · ↑ {fmtMbps(e.trafficOutMbps)}
          </div>
        </EdgeLabelRenderer>
      ) : null}
    </>
  )
}

const nodeTypes: NodeTypes = { falco: FalcoNodeCard }
const edgeTypes: EdgeTypes = { 'falco-edge': FalcoEdgeView }

/* ---------------- Toolbar del canvas (dentro il provider di ReactFlow) ---------------- */

function CanvasToolbar({
  layoutPending,
  onRelayout,
  nodeCount,
  edgeCount,
  unreachableCount,
  discardedAutoEdges,
}: {
  layoutPending: boolean
  onRelayout: () => void
  nodeCount: number
  edgeCount: number
  unreachableCount: number
  discardedAutoEdges: number
}) {
  const { fitView, zoomIn, zoomOut } = useReactFlow()
  /* prefers-reduced-motion: niente animazioni di vista */
  const reduceMotion = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    [],
  )

  return (
    <Panel position="top-left" role="toolbar" aria-label="Controlli della topologia" className="flex max-w-[calc(100%_-_64px)] flex-wrap items-center gap-1.5">
      <div className="flex items-center gap-1 rounded-md border border-border bg-surface/95 p-1 shadow-lg backdrop-blur">
        <Button
          type="button" variant="outline" size="sm"
          className="h-7 border-transparent bg-transparent px-2 text-xs hover:bg-raised"
          onClick={() => { void fitView({ padding: 0.12, duration: reduceMotion ? 0 : 250 }) }}
          aria-label="Adatta vista all'intero albero"
          title="Adatta vista"
        >
          <Maximize className="size-3.5" aria-hidden />
          <span className="hidden sm:inline">Adatta vista</span>
        </Button>
        <Button
          type="button" variant="outline" size="sm"
          className="h-7 border-transparent bg-transparent px-2 text-xs hover:bg-raised"
          onClick={() => { void zoomIn({ duration: reduceMotion ? 0 : 200 }) }}
          aria-label="Aumenta zoom"
          title="Zoom +"
        >
          <ZoomIn className="size-3.5" aria-hidden />
        </Button>
        <Button
          type="button" variant="outline" size="sm"
          className="h-7 border-transparent bg-transparent px-2 text-xs hover:bg-raised"
          onClick={() => { void zoomOut({ duration: reduceMotion ? 0 : 200 }) }}
          aria-label="Riduci zoom"
          title="Zoom −"
        >
          <ZoomOut className="size-3.5" aria-hidden />
        </Button>
        <Button
          type="button" variant="outline" size="sm"
          className="h-7 border-transparent bg-transparent px-2 text-xs hover:bg-raised"
          onClick={onRelayout}
          disabled={layoutPending}
          aria-label="Ridisegna layout: ricalcola l'albero con ELK"
          title="Ridisegna layout (ELK)"
        >
          <RefreshCw className={cn('size-3.5', layoutPending && 'animate-spin')} aria-hidden />
          <span className="hidden md:inline">Ridisegna layout</span>
        </Button>
      </div>
      <span
        className="scrim-label num text-[11px] text-foreground"
        title={`Scarti conflitto: ${discardedAutoEdges} archi automatici non rappresentati (conflitto con l'albero confermato)`}
      >
        {nodeCount} nodi · {edgeCount} archi · {unreachableCount} irraggiungibili
      </span>
    </Panel>
  )
}

/* ---------------- Barra fonti + onestà (16.10 W8, SOPRA il canvas) ---------------- */

/** Rappresentazione attiva (16.11 W9): raggiera (default) o grafo ELK. */
export type TopoViewMode = 'raggiera' | 'grafo'

function RootBadge({ rootSource }: { rootSource: 'operator' | 'inferred' | 'none' }) {
  if (rootSource === 'operator') {
    return (
      <Badge variant="outline" className="border-ok/40 bg-ok-soft text-ok" title="Plant.topologyRootDeviceId: la radice batte ogni euristica">
        radice scelta dall’operatore
      </Badge>
    )
  }
  if (rootSource === 'inferred') {
    return (
      <Badge variant="outline" className="border-border bg-raised text-text-2" title="Nessuna radice scelta: il gateway è stato inferito">
        radice inferita (gateway)
      </Badge>
    )
  }
  return (
    <Badge variant="outline" className="border-warn/40 bg-warn-soft text-warn" title="Nessun gateway né radice: l'albero non parte">
      nessuna radice
    </Badge>
  )
}

function SourcesToolbar({
  activeKeys,
  onToggleFamily,
  linkStats,
  rootSource,
  onOpenLinksManager,
  onOpenL2,
  view,
  onViewChange,
}: {
  activeKeys: string[]
  onToggleFamily: (key: string) => void
  linkStats: TopoGraphData['linkStats']
  rootSource: 'operator' | 'inferred' | 'none'
  onOpenLinksManager: (() => void) | undefined
  onOpenL2: () => void
  view: TopoViewMode
  onViewChange: (v: TopoViewMode) => void
}) {
  return (
    <div className="flex shrink-0 flex-col gap-2 rounded-lg border border-border bg-surface/70 p-2.5">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-1.5 overflow-x-auto scroll-thin" role="group" aria-label="Famiglie di fonti dei collegamenti incluse nell'albero">
          {SOURCE_FAMILIES.map((f) => {
            const on = activeKeys.includes(f.key)
            return (
              <button
                key={f.key}
                type="button"
                onClick={() => onToggleFamily(f.key)}
                aria-pressed={on}
                title={f.hint}
                className={cn(
                  'inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1 text-xs font-medium transition-colors',
                  on
                    ? 'border-primary/50 bg-primary/10 text-foreground'
                    : 'border-border bg-surface/60 text-text-2 hover:border-control-border/60 hover:text-foreground',
                )}
              >
                <span
                  className={cn('size-1.5 rounded-full', on ? 'bg-primary' : 'bg-text-2/40')}
                  aria-hidden
                />
                {f.label}
              </button>
            )
          })}
        </div>
        {/* 16.11 W9: cambio rappresentazione (raggiera default / grafo ELK) */}
        <div
          className="flex shrink-0 items-center gap-0.5 rounded-full border border-border bg-surface/60 p-0.5"
          role="group"
          aria-label="Rappresentazione della topologia"
        >
          <button
            type="button"
            onClick={() => onViewChange('raggiera')}
            aria-pressed={view === 'raggiera'}
            title="Raggiera per sede: radice a sinistra, card sedi a destra, linee tratteggiate colorate per stato"
            className={cn(
              'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              view === 'raggiera'
                ? 'bg-primary/10 text-foreground'
                : 'text-text-2 hover:text-foreground',
            )}
          >
            <RadioTower className="size-3.5" aria-hidden />
            Raggiera
          </button>
          <button
            type="button"
            onClick={() => onViewChange('grafo')}
            aria-pressed={view === 'grafo'}
            title="Grafo libero su canvas: layout ELK, zoom semantico, archi cliccabili"
            className={cn(
              'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              view === 'grafo'
                ? 'bg-primary/10 text-foreground'
                : 'text-text-2 hover:text-foreground',
            )}
          >
            <Network className="size-3.5" aria-hidden />
            Grafo
          </button>
        </div>
        {/* v16.8 — ricostruzione L2 della rete in bridge (sonda SNMP LLDP+CDP+FDB) */}
        <Button
          type="button" variant="outline" size="sm"
          className="h-8 shrink-0"
          onClick={onOpenL2}
          title="Sonda SNMP Layer-2 di uno switch: LLDP-MIB + CDP + FDB (BRIDGE-MIB/Q-BRIDGE) → ricostruzione dei collegamenti reali della rete in bridge"
        >
          <Cable className="size-3.5" aria-hidden />
          Ricostruisci L2
        </Button>
        <Button
          type="button" variant="outline" size="sm"
          className="h-8 shrink-0"
          onClick={onOpenLinksManager}
          disabled={!onOpenLinksManager}
          title="Inventario reale dei collegamenti: conferma, correggi, elimina, ripulisci le inferenze"
        >
          <ListTree className="size-3.5" aria-hidden />
          Gestisci collegamenti
        </Button>
      </div>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
        <p className="text-[11px] text-text-2">
          Albero costruito su <span className="num">{linkStats.included}</span> di{' '}
          <span className="num">{linkStats.total}</span> collegamenti ·{' '}
          <span className="num">{linkStats.excludedInferred}</span> inferenze escluse ·{' '}
          <span className="num">{linkStats.confirmedAlwaysIn}</span> confermati sempre inclusi
        </p>
        <RootBadge rootSource={rootSource} />
      </div>
    </div>
  )
}

/* ---------------- Legenda overlay (scrim) ---------------- */

function LineSample({ color, dashed }: { color: string; dashed?: string }) {
  return (
    <svg width="22" height="6" viewBox="0 0 22 6" className="shrink-0" aria-hidden focusable="false">
      <line x1="1" y1="3" x2="21" y2="3" stroke={color} strokeWidth="2.5" strokeDasharray={dashed} strokeLinecap="round" />
    </svg>
  )
}

function DotSample({ color }: { color: string }) {
  return <span className="inline-block size-2 shrink-0 rounded-full" style={{ background: color }} aria-hidden />
}

function TopologyLegend() {
  const p = usePalette()
  return (
    <Panel position="bottom-left">
      <div
        className="scrim-label flex max-w-[560px] flex-wrap items-center gap-x-3 gap-y-1.5 text-[10px] text-foreground"
        role="group"
        aria-label="Legenda: fonti dei collegamenti e stati dei nodi"
      >
        <span className="flex items-center gap-1.5"><LineSample color={p.ok} />confermato dall’operatore</span>
        <span className="flex items-center gap-1.5"><LineSample color={p.controlBorder} />protocollo (LLDP/CDP/MNDP)</span>
        <span className="flex items-center gap-1.5"><LineSample color={p.info} dashed="6 3" />UISP</span>
        <span className="flex items-center gap-1.5"><LineSample color={p.text2} dashed="2 4" />inferito dal bridge — FDB/Q-BRIDGE (escluso di default)</span>
        <span className="flex items-center gap-1.5"><LineSample color={p.crit} dashed="5 4" />giù / non raggiunto</span>
        <span className="mx-0.5 h-3 w-px shrink-0 bg-border" aria-hidden />
        <span className="flex items-center gap-1.5"><DotSample color={p.ok} />online</span>
        <span className="flex items-center gap-1.5"><DotSample color={p.warn} />degradato / sconosciuto</span>
        <span className="flex items-center gap-1.5"><DotSample color={p.crit} />offline / non monitorato</span>
        <span className="flex items-center gap-1.5"><DotSample color={p.info} />manutenzione</span>
      </div>
    </Panel>
  )
}

/* ---------------- v16.8 — Dialog «Ricostruzione L2» ----------------
 * v16.15 W15 — DUE modalità nello stesso dialog (toggle in cima, stile
 * Raggiera/Grafo): «Singolo apparato» = flusso v16.8 INTATTO (sonda su
 * UNO switch, report arricchito STP/VLAN/ARP); «Tutti gli switch» =
 * batch W14: UNA richiesta fino a 12 switch + correlazione multi-switch
 * (link FDB_MUTUAL con porte di ENTRAMBI i lati, direzione da STP,
 * ARP per i MAC non inventariati). Onestà: campi assenti → blocchi
 * nascosti (mai zeri finti). */

/** Tipi di apparato su cui la sonda L2 ha senso (switch/router/gateway;
 *  gli altri restano selezionabili in fondo, onestamente inutili). */
const L2_PREFERRED_TYPES = new Set(['SWITCH', 'GATEWAY', 'ROUTER', 'FIREWALL', 'NVR'])

/** Badge del tipo di link del correlatore batch (W14): avvistamento
 *  reciproco in FDB (FDB_MUTUAL) = forte; coppia unidirezionale
 *  (FDB_PAIR) = media; solo bridge designato STP (STP_DESIGNATED) =
 *  direzione dichiarata dal protocollo. */
const L2_KIND_CLS: Record<'FDB_MUTUAL' | 'FDB_PAIR' | 'STP_DESIGNATED', string> = {
  FDB_MUTUAL: 'bg-ok-soft text-ok border-ok/40',
  FDB_PAIR: 'bg-warn-soft text-warn border-warn/40',
  STP_DESIGNATED: 'bg-info-soft text-info border-info/40',
}

function L2ReconstructDialog({
  open, onOpenChange, nodes,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  nodes: TopoNode[]
}) {
  const queryClient = useQueryClient()
  const set = useApp((s) => s.set)
  const topoSources = useApp((s) => s.topoSources)
  /* v16.15 W15: plant attivo per il batch — la selezione automatica degli
   * switch (SWITCH/GATEWAY/ROUTER/FIREWALL attivi) avviene lato server
   * sull'impianto in uso. */
  const activePlantId = useApp((s) => s.activePlantId)
  /* Modalità: 'singolo' (flusso v16.8, default) | 'batch' (W14, tutti
   * gli switch dell'impianto in una sola richiesta). */
  const [mode, setMode] = useState<'singolo' | 'batch'>('singolo')
  const [deviceId, setDeviceId] = useState<string | null>(null)
  const [communitiesRaw, setCommunitiesRaw] = useState('')

  /* switch/router prima, il resto dopo: ordine di scelta, non giudizio */
  const ordered = useMemo(() => {
    const preferred = nodes.filter((n) => L2_PREFERRED_TYPES.has(n.type?.toUpperCase() ?? ''))
    const others = nodes.filter((n) => !L2_PREFERRED_TYPES.has(n.type?.toUpperCase() ?? ''))
    return [...preferred, ...others].slice(0, 200)
  }, [nodes])

  /* Auto-accensione della famiglia INFERRED dopo una sonda che ha
   * prodotto/scritto link da letture bridge (16.10 W8): l'operatore li
   * vede subito nell'albero rigenerato (può sempre spegnerla coi chip).
   * Fattorizzata in v16.15: la usano il report singolo E quello batch. */
  const enableInferredFamily = (linkCount: number, description: string) => {
    if (linkCount <= 0) return
    if ((topoSources ?? '').toUpperCase().split(',').includes('INFERRED')) return
    const cur = (topoSources ?? 'TECHNICIAN,PROTOCOLS,UISP').split(',').filter(Boolean)
    set({ topoSources: [...cur, 'INFERRED'].join(',') })
    toast.info('Famiglia «Inferiti (bridge/FDB)» accesa', { description })
  }

  const l2 = useMutation({
    mutationFn: (input: { deviceId: string; communities?: string[] }) => api.discoveryL2(input),
    onSuccess: (res) => {
      const created = res.persistence.linksCreated + res.persistence.linksUpdated
      const fdbLinks = res.links.filter((l) => l.sourceOfTruth === 'FDB' || l.sourceOfTruth === 'DAISY_CHAIN').length
      /* se la sonda ha prodotto link FDB, accende la famiglia INFERRED:
       * l'operatore li vede subito (può sempre spegnerla coi chip). */
      enableInferredFamily(
        fdbLinks,
        `${fdbLinks} collegamenti letti dalla FDB dello switch: ora visibili nell'albero (rigenerato).`,
      )
      toast.success(created > 0
        ? `Ricostruiti ${created} collegamenti Layer-2`
        : 'Sonda L2 completata: nessun nuovo collegamento', {
        description: res.reachable
          ? `${res.stats.lldpNeighbors} vicini LLDP · ${res.stats.cdpNeighbors} CDP · ${res.stats.fdbEntries + res.stats.vlanFdbEntries} MAC in FDB`
          : 'SNMP non raggiungibile sull\u2019apparato (verificare community e porta).',
      })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
    },
    onError: (e: unknown) => {
      const err = e as { message?: string; code?: string }
      toast.error('Ricostruzione L2 non riuscita', {
        description: `${err.message ?? 'Errore sconosciuto'}${err.code ? ` (codice ${err.code})` : ''}`,
      })
    },
  })

  /* v16.15 W14 — batch multi-switch: UNA richiesta verso il motore che
   * sonda in parallelo e la correlazione lato server che ricostruisce i
   * link switch↔switch (porte di entrambi i lati) e li persiste. */
  const l2Batch = useMutation({
    mutationFn: (input: DiscoveryL2BatchInput) => api.discoveryL2Batch(input),
    onSuccess: (res) => {
      const created = res.persistence.linksCreated + res.persistence.linksUpdated
      enableInferredFamily(
        created,
        `${created} collegamenti switch\u2194switch scritti dalla correlazione multi-switch: ora visibili nell'albero (rigenerato).`,
      )
      toast.success(created > 0
        ? `Ricostruiti ${created} collegamenti Layer-2 (batch)`
        : 'Scansione batch completata: nessun nuovo collegamento', {
        description: `${res.reachable}/${res.scanned} switch raggiunti · ${res.switchLinks.length} link switch\u2194switch · ${res.persistence.observationsSaved} osservazioni MAC salvate`,
      })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
    },
    onError: (e: unknown) => {
      const err = e as { message?: string; code?: string }
      toast.error('Scansione batch Layer-2 non riuscita', {
        description: `${err.message ?? 'Errore sconosciuto'}${err.code ? ` (codice ${err.code})` : ''}`,
      })
    },
  })

  /* Community aggiuntive (max 8): parsing condiviso dai due flussi. */
  const communities = communitiesRaw
    .split(/[\s,;]+/)
    .map((c) => c.trim())
    .filter((c) => c.length > 0)
    .slice(0, 8)

  const run = () => {
    if (!deviceId) return
    l2.mutate({ deviceId, ...(communities.length > 0 ? { communities } : {}) })
  }

  /* Batch: senza deviceIds la selezione è automatica lato server (gli
   * switch/router/gateway/firewall attivi del plant in uso). */
  const runBatch = () => {
    l2Batch.mutate({ plantId: activePlantId ?? undefined, ...(communities.length > 0 ? { communities } : {}) })
  }

  const res: DiscoveryL2Result | null = l2.data ?? null
  const batchRes: DiscoveryL2BatchResult | null = l2Batch.data ?? null
  const selectedDevice = ordered.find((n) => n.id === deviceId) ?? null
  /* Da chi sono stati visti i candidati ARP (badge → elenco unico). */
  const arpSeenBy = batchRes ? [...new Set(batchRes.arpCandidates.map((c) => c.seenBy))] : []

  /* ============ v16.16 W17-a — adozione candidati ARP ============ */

  /* La decisione è umana: il pulsante «Adotta» appare solo a chi può
   * agire (TECNICO+, come la coda adozione). */
  const { data: session } = useSession()
  const canAdoptArp = !!session?.user?.role && session.user.role !== 'CLIENTE'

  /* MAC già adottati in QUESTA sessione del dialog (feedback locale:
   * la riga si spegne finché l'operatore non riesegue il batch). */
  const [adoptedMacs, setAdoptedMacs] = useState<string[]>([])

  /* Candidato in corso di adozione (il dialog di dichiarazione). */
  const [adoptTarget, setAdoptTarget] = useState<{ mac: string; ip: string; seenBy: string } | null>(null)
  const [adoptHostname, setAdoptHostname] = useState('')
  const [adoptType, setAdoptType] = useState<string>('UNKNOWN')
  const [adoptConnection, setAdoptConnection] = useState<string>('ETHERNET')
  const [adoptLocationId, setAdoptLocationId] = useState<string>('')
  const [adoptNotes, setAdoptNotes] = useState('')

  /* Sedi REALI del plant (stessa fonte della coda adozione): servono
   * alla dichiarazione; caricate solo se ci sono candidati da adottare. */
  const locationsQuery = useQuery({
    queryKey: ['adoption-queue', activePlantId],
    queryFn: () => api.adoptionQueue(activePlantId ?? undefined),
    enabled: canAdoptArp && (batchRes?.arpCandidates.length ?? 0) > 0,
    staleTime: 60_000,
  })
  const adoptLocations = locationsQuery.data?.data?.locations ?? []

  /* Vendor IEEE del MAC in adozione (best-effort: 404 onesto = MAC
   * fuori banca dati, il campo resta vuoto — mai inventato). Serve
   * anche a SUGGERIRE il tipo (categoria OUI), la scelta resta umana. */
  const ouiQuery = useQuery({
    queryKey: ['oui', adoptTarget?.mac],
    queryFn: () => api.discoveryOui(adoptTarget!.mac),
    enabled: !!adoptTarget,
    retry: false,
    staleTime: 5 * 60_000,
  })
  const ouiVendor = ouiQuery.data?.data?.vendor ?? ''

  /* Suggerimento tipo dalla categoria OUI (segnale, non verità). */
  const suggestedType = useMemo(() => {
    const cat = (ouiQuery.data?.data?.category ?? '').toUpperCase()
    if (cat === 'RADIO') return 'AP'
    if (cat === 'CAMERA') return 'CAMERA'
    if (cat === 'SWITCH') return 'SWITCH'
    return ''
  }, [ouiQuery.data?.data?.category])

  /* Apre il dialog di adozione col candidato: hostname suggerito
   * neutro (mai un brand come nome), tipo da confermare. */
  const openAdopt = (c: { mac: string; ip: string; seenBy: string }) => {
    setAdoptTarget(c)
    setAdoptHostname(`nuovo-${c.mac.slice(-5).replace(/:/g, '').toLowerCase()}`)
    setAdoptType('UNKNOWN')
    setAdoptConnection('ETHERNET')
    setAdoptLocationId('')
    setAdoptNotes('')
  }

  const adoptMutation = useMutation({
    mutationFn: (input: {
      mac: string; ip: string; hostname: string; type: (typeof ARP_ADOPTION_TYPES)[number]
      connectionType: (typeof ARP_ADOPTION_CONNECTION_TYPES)[number]
      locationId?: string; notes?: string
    }) => api.adoptArpCandidate(input),
    onSuccess: (created: ArpAdoptionResult) => {
      toast.success(`«${created.hostname}» adottato`, {
        description: `${created.macAddress} · ${created.ip}${created.ouiVendor ? ` · ${created.ouiVendor}` : ''}${created.locationName ? ` · sede ${created.locationName}` : ''} — finestra di assestamento 24 h.`,
      })
      setAdoptedMacs((prev) => [...prev, created.macAddress])
      setAdoptTarget(null)
      /* l'inventario cambia: albero, link, dispositivi e coda adozione */
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
      void queryClient.invalidateQueries({ queryKey: ['devices'] })
      void queryClient.invalidateQueries({ queryKey: ['adoption-queue'] })
    },
    onError: (e: unknown) => {
      const err = e as { message?: string; code?: string }
      toast.error('Adozione non riuscita', {
        description: `${err.message ?? 'Errore sconosciuto'}${err.code ? ` (codice ${err.code})` : ''}`,
      })
    },
  })

  const submitAdopt = () => {
    if (!adoptTarget || !adoptHostname.trim()) return
    adoptMutation.mutate({
      mac: adoptTarget.mac,
      ip: adoptTarget.ip,
      hostname: adoptHostname.trim(),
      type: (ARP_ADOPTION_TYPES as readonly string[]).includes(adoptType)
        ? (adoptType as (typeof ARP_ADOPTION_TYPES)[number])
        : 'UNKNOWN',
      connectionType: (ARP_ADOPTION_CONNECTION_TYPES as readonly string[]).includes(adoptConnection)
        ? (adoptConnection as (typeof ARP_ADOPTION_CONNECTION_TYPES)[number])
        : 'ETHERNET',
      ...(adoptLocationId ? { locationId: adoptLocationId } : {}),
      ...(adoptNotes.trim() ? { notes: adoptNotes.trim() } : {}),
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Cable className="size-4 text-text-2" aria-hidden />
            Ricostruzione Layer-2 · rete in bridge
          </DialogTitle>
          <DialogDescription>
            {mode === 'batch' ? (
              <>
                Sonda SNMP su FINO A 12 switch dell&apos;impianto (SWITCH/GATEWAY/ROUTER/FIREWALL) in una sola
                richiesta, poi correlazione multi-switch: avvistamenti reciproci in FDB (link FDB_MUTUAL con porte
                di ENTRAMBI i lati), direzione dell&apos;albero da Spanning-Tree, ARP per i MAC non inventariati.
                I collegamenti dell&apos;operatore non vengono MAI toccati.
              </>
            ) : (
              <>
                Sonda SNMP su UNO switch dell&apos;inventario: LLDP-MIB + CDP + FDB (BRIDGE-MIB/Q-BRIDGE) + interfacce.
                I collegamenti dell&apos;operatore non vengono MAI toccati; i link inferiti restano confermabili nel gestore.
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {/* v16.15 W15 — selettore modalità (stessi bottoni pill del
              toggle Raggiera/Grafo: aria-pressed, stesso stile) */}
          <div
            className="inline-flex items-center gap-0.5 rounded-full border border-border/70 bg-raised/60 p-0.5"
            role="group"
            aria-label="Modalità della ricostruzione Layer-2"
          >
            <button
              type="button"
              onClick={() => setMode('singolo')}
              aria-pressed={mode === 'singolo'}
              title="Sonda SNMP su UNO switch dell'inventario (flusso storico v16.8)"
              className={cn(
                'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                mode === 'singolo' ? 'bg-primary/10 text-foreground' : 'text-text-2 hover:text-foreground',
              )}
            >
              <Cable className="size-3.5" aria-hidden />
              Singolo apparato
            </button>
            <button
              type="button"
              onClick={() => setMode('batch')}
              aria-pressed={mode === 'batch'}
              title="Sonda SNMP su TUTTI gli switch dell'impianto in una sola richiesta, poi correlazione multi-switch (v16.15)"
              className={cn(
                'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                mode === 'batch' ? 'bg-primary/10 text-foreground' : 'text-text-2 hover:text-foreground',
              )}
            >
              <Network className="size-3.5" aria-hidden />
              Tutti gli switch
            </button>
          </div>

          {/* Selettore apparato (SOLO modalità singola): lista scrollabile (tipi L2 in cima) */}
          {mode === 'singolo' ? (
            <div className="grid gap-1.5">
              <label htmlFor="l2-device" className="text-xs font-medium text-text-2">Apparato da sondare (switch/router/gateway)</label>
            <div
              id="l2-device"
              role="listbox"
              aria-label="Elenco degli apparati dell'inventario"
              className="max-h-44 overflow-y-auto rounded-lg border border-border/70 bg-surface p-1.5"
            >
              {ordered.map((n) => {
                const sel = deviceId === n.id
                const preferred = L2_PREFERRED_TYPES.has(n.type?.toUpperCase() ?? '')
                return (
                  <button
                    key={n.id}
                    type="button"
                    role="option"
                    aria-selected={sel}
                    onClick={() => setDeviceId(n.id)}
                    className={cn(
                      'flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-sm transition-colors',
                      sel ? 'bg-primary/10 text-foreground' : 'text-text-2 hover:bg-raised/60 hover:text-foreground',
                    )}
                  >
                    <span className="num min-w-0 flex-1 truncate">{n.hostname}</span>
                    <span className="num shrink-0 font-mono text-[11px] text-text-3">{n.ip}</span>
                    <Badge variant="outline" className={cn('shrink-0 border-border text-[10px]', preferred ? 'bg-info-soft text-info' : 'bg-raised text-text-2')}>
                      {typeLabel(n.type)}
                    </Badge>
                  </button>
                )
              })}
            </div>
            </div>
          ) : null}

          {/* Community aggiuntive (RIUSATA in entrambe le modalità: per il
              batch viene tentata su OGNI switch, dopo la sua cifrata) */}
          <div className="grid gap-1.5">
            <label htmlFor="l2-communities" className="text-xs font-medium text-text-2">
              Community aggiuntive (opz., max 8)
              <span className="ml-1 font-normal text-text-3" title="Ordine di tentativo: community cifrata del dispositivo → queste → public">ⓘ</span>
            </label>
            <Input
              id="l2-communities"
              value={communitiesRaw}
              onChange={(e) => setCommunitiesRaw(e.target.value)}
              placeholder="opz.: public,miaCommunity"
              aria-label="Community SNMP aggiuntive, separate da virgola"
              autoComplete="off"
            />
          </div>

          {mode === 'singolo' ? (
            <div className="flex items-center gap-2">
              <Button onClick={run} disabled={!deviceId || l2.isPending}>
                {l2.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Cable className="size-3.5" aria-hidden />}
                Sonda lo switch{selectedDevice ? ` · ${selectedDevice.hostname}` : ''}
              </Button>
              <span className="text-xs text-text-2">Lettura ~10-30 s (12 walk SNMP)</span>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-2">
              <Button onClick={runBatch} disabled={l2Batch.isPending}>
                {l2Batch.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Cable className="size-3.5" aria-hidden />}
                Scansiona tutti gli switch
              </Button>
              <span
                className="text-xs text-text-2"
                title="Una sola richiesta: il motore sonda gli switch in parallelo (concorrenza 1-4) e correla i risultati lato server"
              >
                Lettura ~30-120 s (fino a 12 switch × ~20 walk SNMP)
              </span>
            </div>
          )}

          {/* Report onesto della sonda (ogni modalità mostra il SUO report;
              campi assenti → blocchi nascosti, mai zeri finti) */}
          {mode === 'singolo' ? (
            <>
              {l2.isError ? (
                <ErrorPanel
                  message={(l2.error as Error).message}
                  code={(l2.error as { code?: string }).code}
                  onRetry={deviceId ? run : undefined}
                />
              ) : res ? (
                <div className="space-y-2.5 rounded-lg border border-border/70 p-3" aria-live="polite">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    {res.reachable ? (
                      <Badge className="bg-ok-soft text-ok border-ok/40">
                        <CircleCheck className="size-3" aria-hidden />
                        SNMP raggiunto{res.switch.matched ? ` · ${res.switch.matched.community} (${res.switch.matched.version})` : ''}
                      </Badge>
                    ) : (
                      <Badge className="bg-crit-soft text-crit-text border-crit/40">
                        <CircleAlert className="size-3" aria-hidden />
                        SNMP non raggiungibile
                      </Badge>
                    )}
                    {res.switch.sysName ? <span className="num text-xs text-text-2">sysName: {res.switch.sysName}</span> : null}
                  </div>

                  {res.reachable ? (
                    <>
                      <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 sm:grid-cols-4">
                        <div><dt className="text-[11px] text-text-2">Vicini LLDP</dt><dd className="num text-sm font-medium">{fmtNumber(res.stats.lldpNeighbors)}</dd></div>
                        <div><dt className="text-[11px] text-text-2">Vicini CDP</dt><dd className="num text-sm font-medium">{fmtNumber(res.stats.cdpNeighbors)}</dd></div>
                        <div><dt className="text-[11px] text-text-2">MAC in FDB</dt><dd className="num text-sm font-medium">{fmtNumber(res.stats.fdbEntries + res.stats.vlanFdbEntries)}</dd></div>
                        <div><dt className="text-[11px] text-text-2">Osservazioni salvate</dt><dd className="num text-sm font-medium">{fmtNumber(res.persistence.observationsSaved)}</dd></div>
                        {/* v16.15 W15 — tre celle aggiuntive (SOLO se la sonda le ha portate) */}
                        {res.stats.arpEntries != null ? (
                          <div><dt className="text-[11px] text-text-2" title="Voci ipNetToMedia lette dalla tabella ARP dell'apparato">Voci ARP</dt><dd className="num text-sm font-medium">{fmtNumber(res.stats.arpEntries)}</dd></div>
                        ) : null}
                        {res.stats.stpPorts != null ? (
                          <div><dt className="text-[11px] text-text-2" title="Porte con dichiarazione Spanning-Tree (dot1dStp)">Porte STP</dt><dd className="num text-sm font-medium">{fmtNumber(res.stats.stpPorts)}</dd></div>
                        ) : null}
                        {res.stats.vlans != null ? (
                          <div><dt className="text-[11px] text-text-2" title="VLAN dichiarate (Q-BRIDGE dot1qVlan)">VLAN</dt><dd className="num text-sm font-medium">{fmtNumber(res.stats.vlans)}</dd></div>
                        ) : null}
                      </dl>

                      <p className="text-xs text-text-2">
                        Link: <span className="num font-medium text-foreground">{res.persistence.linksCreated}</span> creati ·{' '}
                        <span className="num font-medium text-foreground">{res.persistence.linksUpdated}</span> aggiornati ·{' '}
                        <span className="num">{res.persistence.linksSkippedOperator}</span> dell'operatore (intoccabili)
                        {res.persistence.arpSaved != null || res.persistence.stpSaved != null || res.persistence.vlanSaved != null ? (
                          <>
                            {' '}· <span className="num font-medium text-foreground">{res.persistence.arpSaved ?? 0}</span> ARP ·{' '}
                            <span className="num font-medium text-foreground">{res.persistence.stpSaved ?? 0}</span> porte STP ·{' '}
                            <span className="num font-medium text-foreground">{res.persistence.vlanSaved ?? 0}</span> VLAN
                          </>
                        ) : null}
                      </p>

                      {res.links.length > 0 ? (
                        <ul className="max-h-44 space-y-1 overflow-y-auto text-xs" aria-label="Collegamenti ricostruiti">
                          {res.links.slice(0, 60).map((l) => (
                            <li key={`${l.targetDeviceId}-${l.sourcePort}-${l.sourceOfTruth}`} className="flex flex-wrap items-center gap-1.5">
                              <Badge variant="outline" className={cn(
                                'border-border text-[10px]',
                                l.sourceOfTruth === 'LLDP' || l.sourceOfTruth === 'CDP'
                                  ? 'bg-info-soft text-info'
                                  : l.sourceOfTruth === 'FDB' ? 'bg-warn-soft text-warn' : 'bg-raised text-text-2',
                              )} title={`Fonte: ${l.sourceOfTruth} · evidenza ${l.evidence} · confidenza ${l.confidence}`}>
                                {l.sourceOfTruth}
                              </Badge>
                              {/* v16.15 — l'STP della porta conferma il cavo */}
                              {l.stpCorroborated ? (
                                <Badge
                                  variant="outline"
                                  className="border-ok/40 bg-ok-soft text-ok text-[10px]"
                                  title="Il bridge designato della porta coincide col MAC del dispositivo collegato"
                                >
                                  STP ✓
                                </Badge>
                              ) : null}
                              <span className="num">{l.targetHostname}</span>
                              <span className="text-text-2">su porta</span>
                              <code className="num font-mono text-[11px]">{l.sourcePort || 'n.d.'}</code>
                              {l.targetPort ? <><span className="text-text-2">(remota</span> <code className="num font-mono text-[11px]">{l.targetPort}</code><span className="text-text-2">)</span></> : null}
                              {l.speedMbps > 0 ? <span className="num text-text-3">{l.speedMbps} Mbps</span> : null}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-text-2">Nessun collegamento abbinato all'inventario (vicini non presenti o FDB senza MAC noti).</p>
                      )}

                      {/* v16.15 — riassunto STP dell'apparato (solo se presente) */}
                      {res.stp && res.stp.present ? (
                        <p
                          className="text-xs text-text-2"
                          title="Ogni porta STP dichiara il proprio bridge designato: quando il suo MAC coincide col dispositivo collegato, il link è «corroborato» (chip STP ✓ sopra)"
                        >
                          Spanning Tree attivo (<span className="num">{res.stp.protocol}</span>) · root{' '}
                          <span className="num font-medium text-foreground">{res.stp.rootBridgeMac}</span> ·{' '}
                          <span className="num">{res.stp.corroboratedLinks}</span> link confermati dall'STP
                        </p>
                      ) : null}

                      {/* v16.15 — VLAN dichiarate (chip, porte egress in tooltip) */}
                      {res.vlans && res.vlans.length > 0 ? (
                        <div className="flex flex-wrap items-center gap-1.5 text-xs">
                          <span className="text-text-2">VLAN:</span>
                          {res.vlans.slice(0, 8).map((v) => (
                            <Badge
                              key={v.vlanId}
                              variant="outline"
                              className="border-border bg-raised text-text-2 text-[10px]"
                              title={`Porte egress della VLAN ${v.vlanId}${v.name ? ` «${v.name}»` : ''}: ${v.ports || 'n.d.'}`}
                            >
                              <span className="num">{v.vlanId}</span>{v.name ? <span>{` ${v.name}`}</span> : null}
                            </Badge>
                          ))}
                          {res.vlans.length > 8 ? (
                            <span
                              className="text-text-3"
                              title={res.vlans.slice(8).map((v) => `${v.vlanId}${v.name ? ` ${v.name}` : ''}`).join(', ')}
                            >
                              … e altre <span className="num">{res.vlans.length - 8}</span>
                            </span>
                          ) : null}
                        </div>
                      ) : null}

                      {/* v16.15 — MAC con IP risolto dall'ARP, non in inventario */}
                      {res.unmatchedMacsWithIp && res.unmatchedMacsWithIp.length > 0 ? (
                        <p
                          className="text-xs text-text-2"
                          title={res.unmatchedMacsWithIp.map((m) => `${m.mac} → ${m.ip} (porta ${m.portName})`).join('\n')}
                        >
                          <span className="font-medium">{res.unmatchedMacsWithIp.length}</span> MAC non in inventario con IP
                          risolto dall&apos;ARP:{' '}
                          <span className="num">{res.unmatchedMacsWithIp.slice(0, 6).map((m) => `${m.mac} → ${m.ip}`).join(', ')}</span>
                          {res.unmatchedMacsWithIp.length > 6 ? ' …' : ''} — l&apos;adozione è una scelta umana.
                        </p>
                      ) : null}

                      {res.unmatchedNeighbors.length > 0 ? (
                        <p className="text-xs text-text-2">
                          <span className="font-medium">{res.unmatchedNeighbors.length}</span> vicini dichiarati ({res.unmatchedNeighbors.slice(0, 5).map((n) => `${n.via}: ${n.name}`).join('; ')}
                          {res.unmatchedNeighbors.length > 5 ? '…' : ''}) non presenti nell'inventario — l'adozione è una scelta umana.
                        </p>
                      ) : null}

                      {res.sharedPorts.length > 0 ? (
                        <p className="text-xs text-warn">
                          <span className="font-medium">{res.sharedPorts.length}</span> porte con più dispositivi noti (segmento bridge/daisy-chain):
                          {' '}{res.sharedPorts.slice(0, 3).map((s) => `${s.port} (${s.devices.length} disp.)`).join(', ')}
                          {res.sharedPorts.length > 3 ? '…' : ''}
                        </p>
                      ) : null}

                      {res.warnings.length > 0 ? (
                        <ul className="space-y-0.5 text-[11px] text-text-3" aria-label="Avvisi onesti della sonda">
                          {res.warnings.slice(0, 6).map((w, i) => <li key={i}>· {w}</li>)}
                        </ul>
                      ) : null}
                    </>
                  ) : (
                    <p className="text-xs text-text-2">{res.detail ?? 'Nessuna risposta SNMP: verifica community, porta e versione SNMP del dispositivo.'}</p>
                  )}
                </div>
              ) : null}
            </>
          ) : (
            <>
              {l2Batch.isError ? (
                <ErrorPanel
                  message={(l2Batch.error as Error).message}
                  code={(l2Batch.error as { code?: string }).code}
                  onRetry={runBatch}
                />
              ) : batchRes ? (
                <div className="space-y-2.5 rounded-lg border border-border/70 p-3" aria-live="polite">
                  {/* Riga badge: raggiunti · durata · concorrenza · root STP */}
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
                    <Badge
                      className={cn(
                        batchRes.reachable === 0
                          ? 'bg-crit-soft text-crit-text border-crit/40'
                          : batchRes.reachable < batchRes.scanned
                            ? 'bg-warn-soft text-warn border-warn/40'
                            : 'bg-ok-soft text-ok border-ok/40',
                      )}
                      title={`${batchRes.reachable} raggiunti su ${batchRes.scanned} sondati (post dedup ip:porta e cap 12)`}
                    >
                      {batchRes.reachable === batchRes.scanned ? <CircleCheck className="size-3" aria-hidden /> : <CircleAlert className="size-3" aria-hidden />}
                      <span className="num">{batchRes.reachable}/{batchRes.scanned}</span> switch raggiunti
                    </Badge>
                    <span className="num text-xs text-text-2" title="Durata reale della richiesta batch: sonde in concorrenza + correlazione">
                      {fmtNumber(batchRes.durationMs)} ms
                    </span>
                    <span className="text-xs text-text-2">· concorrenza <span className="num">{batchRes.concurrency}</span></span>
                    {batchRes.rootBridgeMac ? (
                      <span
                        className="num text-xs text-text-2"
                        title="Root bridge «votata»: ogni switch raggiunto dichiara la root che vede (dot1dStpRootBridge); vince il MAC dichiarato dal maggior numero di switch"
                      >
                        root STP: <span className="font-medium text-foreground">{batchRes.rootBridgeMac}</span>{' '}
                        (<span className="num">{batchRes.rootVotes}</span> voti)
                      </span>
                    ) : null}
                  </div>

                  {/* Porte verso la root (dichiarazioni STP reali) */}
                  {batchRes.rootPorts.length > 0 ? (
                    <p className="text-[11px] text-text-2">
                      Porte verso la root:{' '}
                      {batchRes.rootPorts.slice(0, 4).map((rp) => `${rp.hostname} (${rp.portName || `#${rp.portNum}`})`).join(' · ')}
                      {batchRes.rootPorts.length > 4 ? ` … e altre ${batchRes.rootPorts.length - 4}` : ''}
                    </p>
                  ) : null}

                  {/* Link switch↔switch dal correlatore */}
                  {batchRes.switchLinks.length > 0 ? (
                    <div className="space-y-1">
                      <p className="text-[11px] font-medium uppercase tracking-wide text-text-2">
                        Link switch↔switch (<span className="num">{batchRes.switchLinks.length}</span>)
                      </p>
                      <ul className="max-h-56 space-y-1 overflow-y-auto text-xs" aria-label="Collegamenti switch-switch correlati">
                        {batchRes.switchLinks.slice(0, 60).map((l, i) => (
                          <li
                            key={`${l.upstreamDeviceId}-${l.downstreamDeviceId}-${i}`}
                            className="flex flex-wrap items-center gap-1.5"
                            title={[
                              l.detail || null,
                              l.upstreamSpeedMbps > 0 ? `montante ${l.upstreamSpeedMbps} Mbps` : null,
                              l.downstreamSpeedMbps > 0 ? `valle ${l.downstreamSpeedMbps} Mbps` : null,
                            ].filter(Boolean).join(' · ') || undefined}
                          >
                            <Badge
                              variant="outline"
                              className={cn('border-border text-[10px]', L2_KIND_CLS[l.kind])}
                              title={`Fonte: ${l.kind} · evidenza ${l.evidence} · confidenza ${l.confidence}`}
                            >
                              {l.kind}
                            </Badge>
                            <span className="num">
                              {l.upstreamHostname}{' '}
                              (<code className="font-mono text-[11px]">{l.upstreamPort || 'n.d.'}</code>)
                            </span>
                            <span className="text-text-2" aria-hidden>↔</span>
                            <span className="num">
                              {l.downstreamHostname}{' '}
                              (<code className="font-mono text-[11px]">{l.downstreamPort || 'n.d.'}</code>)
                            </span>
                            {l.stpCorroborated ? (
                              <Badge
                                variant="outline"
                                className="border-ok/40 bg-ok-soft text-ok text-[10px]"
                                title="Il bridge designato/con la rootPort conferma la direzione"
                              >
                                STP ✓
                              </Badge>
                            ) : null}
                            <span className="text-[10px] text-text-3" title={`Confidenza della correlazione: ${l.confidence}`}>{l.confidence}</span>
                          </li>
                        ))}
                        {batchRes.switchLinks.length > 60 ? (
                          <li className="text-text-3">… e altri <span className="num">{batchRes.switchLinks.length - 60}</span> link</li>
                        ) : null}
                      </ul>
                    </div>
                  ) : (
                    <p className="text-xs text-text-2">Nessun link switch↔switch dalla correlazione (nessun avvistamento reciproco in FDB né STP designato concorde).</p>
                  )}

                  {/* Esito per apparato: contatori REALI della sonda */}
                  {batchRes.perSwitch.length > 0 ? (
                    <div
                      className="max-h-56 overflow-y-auto overflow-x-auto rounded-lg border border-border/70"
                      role="region"
                      aria-label="Esito della sonda per apparato"
                      tabIndex={0}
                    >
                      <table className="w-full min-w-[430px] text-xs">
                        <caption className="sr-only">
                          Contatori reali della sonda per switch: community che ha risposto, LLDP, CDP, FDB, ARP, STP, VLAN
                        </caption>
                        <thead>
                          <tr className="border-b border-border/70 bg-raised/40">
                            <th scope="col" className="px-2 py-1 text-left text-[11px] font-medium text-text-2">Switch</th>
                            <th scope="col" className="px-2 py-1 text-left text-[11px] font-medium text-text-2" title="Community e versione SNMP che hanno risposto">Community</th>
                            <th scope="col" className="px-1.5 py-1 text-right text-[11px] font-medium text-text-2" title="Vicini LLDP dichiarati">LLDP</th>
                            <th scope="col" className="px-1.5 py-1 text-right text-[11px] font-medium text-text-2" title="Vicini CDP dichiarati">CDP</th>
                            <th scope="col" className="px-1.5 py-1 text-right text-[11px] font-medium text-text-2" title="Voci FDB (BRIDGE-MIB + Q-BRIDGE)">FDB</th>
                            <th scope="col" className="px-1.5 py-1 text-right text-[11px] font-medium text-text-2" title="Voci ARP lette">ARP</th>
                            <th scope="col" className="px-1.5 py-1 text-right text-[11px] font-medium text-text-2" title="Porte con stato STP">STP</th>
                            <th scope="col" className="px-2 py-1 text-right text-[11px] font-medium text-text-2" title="VLAN dichiarate">VLAN</th>
                          </tr>
                        </thead>
                        <tbody>
                          {batchRes.perSwitch.map((s) => (
                            s.reachable ? (
                              <tr key={s.deviceId} className="border-b border-border/40 last:border-0">
                                <td className="px-2 py-1">
                                  <span
                                    className="num block max-w-[170px] truncate font-medium"
                                    title={`${s.hostname} · ${s.ip}${s.sysName ? ` · sysName ${s.sysName}` : ''}`}
                                  >
                                    {s.hostname}
                                  </span>
                                </td>
                                <td className="px-2 py-1">
                                  {s.matched ? (
                                    <span
                                      className="num text-[11px] text-text-2"
                                      title={`Community che ha risposto: ${s.matched.community} (${s.matched.version})`}
                                    >
                                      {s.matched.community} · {s.matched.version}
                                    </span>
                                  ) : (
                                    <span className="text-text-3" title="Raggiunto ma senza community/versione dichiarata">—</span>
                                  )}
                                </td>
                                <td className="num px-1.5 py-1 text-right" title="Vicini LLDP dichiarati">{s.stats.lldpNeighbors}</td>
                                <td className="num px-1.5 py-1 text-right" title="Vicini CDP dichiarati">{s.stats.cdpNeighbors}</td>
                                <td
                                  className="num px-1.5 py-1 text-right"
                                  title={`${s.stats.fdbEntries} BRIDGE-MIB + ${s.stats.vlanFdbEntries} Q-BRIDGE`}
                                >
                                  {s.stats.fdbEntries + s.stats.vlanFdbEntries}
                                </td>
                                <td className="num px-1.5 py-1 text-right" title="Voci ARP lette">{s.stats.arpEntries}</td>
                                <td className="num px-1.5 py-1 text-right" title="Porte con stato STP">{s.stats.stpPorts}</td>
                                <td className="num px-2 py-1 text-right" title="VLAN dichiarate">{s.stats.vlans}</td>
                              </tr>
                            ) : (
                              <tr key={s.deviceId} className="border-b border-border/40 bg-crit-soft/20 last:border-0">
                                <td className="num px-2 py-1 font-medium" title={`${s.hostname} · ${s.ip}`}>{s.hostname}</td>
                                <td className="px-2 py-1" colSpan={7}>
                                  <span className="flex flex-wrap items-center gap-1.5">
                                    <Badge variant="outline" className="bg-crit-soft text-crit-text border-crit/40 text-[10px]">
                                      <CircleAlert className="size-3" aria-hidden />
                                      non raggiunto
                                    </Badge>
                                    {s.warnings.length > 0 ? (
                                      <span className="text-text-2" title={s.warnings.join(' · ')}>{s.warnings[0]}</span>
                                    ) : (
                                      <span className="text-text-3">nessuna risposta SNMP</span>
                                    )}
                                  </span>
                                </td>
                              </tr>
                            )
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : null}

                  {/* MAC con IP noto NON in inventario (candidati adozione) —
                      * v16.16 W17-a: da report passivo a tabella con azione
                      * UMANA «Adotta» (il pulsante crea il dispositivo). */}
                  {batchRes.arpCandidates.length > 0 ? (
                    <div className="rounded-md border border-warn/40 bg-warn-soft/60" role="region" aria-label="Candidati adozione ARP">
                      <p className="border-b border-warn/30 px-2.5 py-1.5 text-xs text-warn" role="note">
                        <span className="font-medium">
                          <span className="num">{batchRes.arpCandidates.length}</span> MAC con IP noto NON in inventario
                        </span>
                        {' '}(visti da {arpSeenBy.slice(0, 3).join(', ')}{arpSeenBy.length > 3 ? '…' : ''}): l&apos;adozione è una scelta umana{canAdoptArp ? '' : ' (richiede ruolo tecnico)'}.
                      </p>
                      <div className="max-h-44 overflow-y-auto scroll-thin">
                        <table className="w-full text-xs">
                          <thead className="sticky top-0 z-[1] bg-raised/95 backdrop-blur-sm">
                            <tr className="border-b border-border/60 text-left text-[10px] uppercase tracking-wide text-text-3">
                              <th scope="col" className="px-2 py-1 font-medium">MAC</th>
                              <th scope="col" className="px-2 py-1 font-medium">IP</th>
                              <th scope="col" className="px-2 py-1 font-medium">Visto da</th>
                              <th scope="col" className="px-2 py-1 text-right font-medium">{canAdoptArp ? 'Azione' : ''}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {batchRes.arpCandidates.map((c) => {
                              const done = adoptedMacs.includes(c.mac)
                              return (
                                <tr key={c.mac} className={cn('border-b border-border/40 last:border-0', done && 'opacity-50')}>
                                  <td className="num px-2 py-1 font-medium">{c.mac}</td>
                                  <td className="num px-2 py-1">{c.ip}</td>
                                  <td className="px-2 py-1 text-text-2" title={`dichiarato dall'ARP di ${c.seenBy}`}>{c.seenBy}</td>
                                  <td className="px-2 py-1 text-right">
                                    {done ? (
                                      <Badge variant="outline" className="bg-ok-soft text-ok-text border-ok/40 text-[10px]">
                                        <CircleCheck className="size-3" aria-hidden />
                                        adottato
                                      </Badge>
                                    ) : canAdoptArp ? (
                                      <Button
                                        type="button"
                                        variant="outline"
                                        size="sm"
                                        className="h-6 gap-1 px-2 text-[11px]"
                                        onClick={() => openAdopt(c)}
                                      >
                                        <UserPlus className="size-3" aria-hidden />
                                        Adotta
                                      </Button>
                                    ) : (
                                      <span className="text-[10px] text-text-3">sola lettura</span>
                                    )}
                                  </td>
                                </tr>
                              )
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : null}

                  {/* Persistenza reale del batch */}
                  <p className="text-xs text-text-2">
                    Link: <span className="num font-medium text-foreground">{batchRes.persistence.linksCreated}</span> creati ·{' '}
                    <span className="num font-medium text-foreground">{batchRes.persistence.linksUpdated}</span> aggiornati ·{' '}
                    <span className="num">{batchRes.persistence.linksSkippedOperator}</span> dell'operatore (intoccabili)
                  </p>
                  <p className="text-xs text-text-2">
                    <span className="num font-medium text-foreground">{batchRes.persistence.observationsSaved}</span> osservazioni MAC ·{' '}
                    <span className="num font-medium text-foreground">{batchRes.persistence.arpSaved}</span> ARP salvate ·{' '}
                    <span className="num font-medium text-foreground">{batchRes.persistence.stpSaved}</span> porte STP ·{' '}
                    <span className="num font-medium text-foreground">{batchRes.persistence.vlanSaved}</span> VLAN
                  </p>

                  {/* Avvisi onesti (le promozioni evidenziate) */}
                  {batchRes.warnings.length > 0 ? (
                    <ul className="space-y-0.5 text-[11px] text-text-3" aria-label="Avvisi onesti del batch">
                      {batchRes.warnings.slice(0, 6).map((w, i) => {
                        const promo = w.toLowerCase().includes('promosso a')
                        return (
                          <li key={i} className={promo ? 'text-ok' : undefined}>
                            {promo ? (
                              <TrendingUp className="mr-1 inline size-3 align-[-2px]" aria-hidden />
                            ) : (
                              '· '
                            )}
                            {w}
                          </li>
                        )
                      })}
                      {batchRes.warnings.length > 6 ? (
                        <li>… e altri <span className="num">{batchRes.warnings.length - 6}</span> avvisi</li>
                      ) : null}
                    </ul>
                  ) : null}
                </div>
              ) : null}
            </>
          )}

          <p className="flex items-start gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2 text-xs text-text-2">
            <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-text-2" aria-hidden />
            <span>
              Verità &gt; inferenza: i link dell'operatore restano intoccabili; i link FDB/daisy-chain sono
              tratteggiati e confermabili dal gestore collegamenti.
            </span>
          </p>
        </div>

        {/* ============ v16.16 W17-a — dialog di adozione candidato ARP ============
            * La dichiarazione UMANA: nome, tipo, collegamento, sede, note.
            * MAC e IP arrivano dal report (evidenza reale), il vendor dal
            * database IEEE — tutto il resto lo decide l'operatore. */}
        <Dialog open={!!adoptTarget} onOpenChange={(o) => { if (!o) setAdoptTarget(null) }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UserPlus className="size-4 text-text-2" aria-hidden />
                Adozione candidato ARP
              </DialogTitle>
              <DialogDescription>
                <span className="num">{adoptTarget?.mac}</span> · <span className="num">{adoptTarget?.ip}</span>
                {adoptTarget?.seenBy ? ` — visto dall'ARP di ${adoptTarget.seenBy}` : ''}.
                La creazione è una tua dichiarazione: nessun campo viene scelto dal sistema.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3">
              {/* Vendor IEEE (evidenza, non scelta) */}
              <p className="text-xs text-text-2" role="note">
                {ouiQuery.isFetching ? (
                  'ricerca vendor IEEE in corso…'
                ) : ouiVendor ? (
                  <>
                    Vendor IEEE: <span className="font-medium text-foreground">{ouiVendor}</span>
                    {suggestedType ? (
                      <> — tipo suggerito <span className="font-medium text-foreground">{suggestedType}</span>{' '}
                        <button
                          type="button"
                          className="underline decoration-dotted underline-offset-2 hover:text-foreground"
                          onClick={() => setAdoptType(suggestedType)}
                        >
                          usa
                        </button>
                      </>
                    ) : null}
                  </>
                ) : (
                  'MAC fuori dal database IEEE (10.679 prefissi): il vendor resta vuoto — non inventato.'
                )}
              </p>

              <div className="space-y-1.5">
                <Label htmlFor="adopt-hostname">Nome apparato *</Label>
                <Input
                  id="adopt-hostname"
                  value={adoptHostname}
                  onChange={(e) => setAdoptHostname(e.target.value)}
                  maxLength={80}
                  placeholder="es. stampante-ufficio-1"
                  autoComplete="off"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5">
                  <Label htmlFor="adopt-type">Tipo *</Label>
                  <Select value={adoptType} onValueChange={setAdoptType}>
                    <SelectTrigger id="adopt-type" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-64">
                      {ARP_ADOPTION_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="adopt-connection">Collegamento</Label>
                  <Select value={adoptConnection} onValueChange={setAdoptConnection}>
                    <SelectTrigger id="adopt-connection" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ARP_ADOPTION_CONNECTION_TYPES.map((c) => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="adopt-location">Sede</Label>
                <Select value={adoptLocationId || undefined} onValueChange={setAdoptLocationId}>
                  <SelectTrigger id="adopt-location" className="w-full">
                    <SelectValue placeholder={adoptLocations.length === 0 ? 'nessuna sede nell’impianto' : 'Senza sede (da assegnare dopo)…'} />
                  </SelectTrigger>
                  <SelectContent>
                    {adoptLocations.map((l) => (
                      <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                    ))}
                    {adoptLocations.length === 0 ? (
                      <p className="px-2 py-1.5 text-xs text-text-3">nessuna sede nell’impianto: l’apparato resta orfano (visibile nella coda adozione)</p>
                    ) : null}
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-text-3">
                  Facoltativa: assegnabile anche dopo dalla coda adozione (gli orfani restano visibili lì).
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="adopt-notes">Note (facoltative)</Label>
                <Textarea
                  id="adopt-notes"
                  value={adoptNotes}
                  onChange={(e) => setAdoptNotes(e.target.value)}
                  maxLength={500}
                  rows={2}
                  placeholder="es. stampante di rete corridoio primo piano"
                />
              </div>

              <p className="rounded-md border border-border/70 bg-raised/40 px-2.5 py-1.5 text-[11px] text-text-2" role="note">
                Finestra di assestamento 24 h (baselineUntil, come l&apos;RMA): nessun allarme finché
                l&apos;apparato non si assesta. Il MAC resta nelle osservazioni ARP/FDB: il join con
                l&apos;inventario si chiude da solo ai prossimi giri.
              </p>
            </div>

            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button type="button" variant="outline" onClick={() => setAdoptTarget(null)} disabled={adoptMutation.isPending}>
                Annulla
              </Button>
              <Button type="button" onClick={submitAdopt} disabled={adoptMutation.isPending || !adoptHostname.trim()}>
                {adoptMutation.isPending ? (
                  <>
                    <Loader2 className="size-4 animate-spin" aria-hidden />
                    Adozione…
                  </>
                ) : (
                  <>
                    <UserPlus className="size-4" aria-hidden />
                    Adotta «{adoptHostname.trim() || '…'}»
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Componente principale ---------------- */

export interface TopologyViewProps {
  /** Notifica la selezione di un arco (null = deselezionato, es. click sullo sfondo) */
  onSelectEdge?: (edgeId: string | null) => void
  /** 16.10 W8: apre il «Gestisci collegamenti» (il dialog è di proprietà
   * della vista Rete, che gli passa i nodi per i selettori). */
  onOpenLinksManager?: () => void
  className?: string
}

export default function TopologyView(props: TopologyViewProps) {
  /* Provider: useReactFlow dev'essere disponibile FUORI dal <ReactFlow>
   * (serve il fitView programmatico post-layout). */
  return (
    <ReactFlowProvider>
      <TopologyViewInner {...props} />
    </ReactFlowProvider>
  )
}

function TopologyViewInner({ onSelectEdge, onOpenLinksManager, className }: TopologyViewProps) {
  const set = useApp((s) => s.set)
  const topologyNode = useApp((s) => s.topologyNode)
  const topoSources = useApp((s) => s.topoSources)
  /* 16.11 W9: rappresentazione attiva (null = raggiera, default) */
  const topoViewRaw = useApp((s) => s.topoView)
  const view: TopoViewMode = topoViewRaw === 'grafo' ? 'grafo' : 'raggiera'
  const setView = useCallback(
    (v: TopoViewMode) => { set({ topoView: v }) },
    [set],
  )
  const p = usePalette()
  /* colorMode SINCRONO col tema dell'app: React Flow aggiunge classe «light»/
   * «dark» al proprio contenitore e il nostro CSS (.light { --surface: #fff… })
   * la intercetta — col default «light» di React Flow il grafo riceveva i token
   * del tema CHIARO anche a tema scuro (bg bianco, contrasti rotti: audit a11y). */
  const { resolvedTheme } = useTheme()
  const colorMode = resolvedTheme === 'light' ? 'light' : 'dark'
  const { fitView, setCenter } = useReactFlow()
  const reduceMotion = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    [],
  )

  /* --- fonti attive (URL ?fonti=…) → membri per la query del grafo --- */
  const activeFamilyKeys = useMemo(() => familyKeysFromStore(topoSources), [topoSources])
  const sources = useMemo(() => topoSourceMembers(topoSources), [topoSources])
  const sourcesKey = sources.join(',')

  const query = useQuery({
    queryKey: ['topology-graph', sourcesKey],
    queryFn: () => api.topologyGraph({ sources }),
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  })
  const data = query.data?.data

  const toggleFamily = useCallback(
    (key: string) => {
      const next = activeFamilyKeys.includes(key)
        ? activeFamilyKeys.filter((k) => k !== key)
        : [...activeFamilyKeys, key]
      /* l'ultima famiglia attiva non si spegne: un albero senza fonti non
       * esiste (il default «nessuna fonte» del server è ambiguo). */
      if (next.length === 0) return
      const canon = SOURCE_FAMILIES.map((f) => f.key as string).filter((k) => next.includes(k))
      const isDefault =
        canon.length === DEFAULT_FAMILY_KEYS.length && DEFAULT_FAMILY_KEYS.every((k) => canon.includes(k))
      set({ topoSources: isDefault ? null : canon.join(',') })
    },
    [activeFamilyKeys, set],
  )

  const [nodes, setNodes, onNodesChange] = useNodesState<FalcoNode>([])
  const [edges, setEdges, onEdgesChange] = useEdgesState<FalcoEdge>([])
  const [positions, setPositions] = useState<Map<string, { x: number; y: number }> | null>(null)
  const [layoutEpoch, setLayoutEpoch] = useState(0)
  const [layoutNonce, setLayoutNonce] = useState(0)
  const [layoutDoneKey, setLayoutDoneKey] = useState<string | null>(null)
  const [layoutError, setLayoutError] = useState<string | null>(null)
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null)
  /* v16.8 — dialog ricostruzione Layer-2 (rete in bridge) */
  const [l2Open, setL2Open] = useState(false)

  /* Ordine di inserimento nel layout (16.10 W8): tier → SEDE (i dispositivi
   * dello stesso sito restano adiacenti: cluster leggibili invece di un
   * nastro sparso) → famiglia (TYPE_RANK) → hostname. Solo ordine di
   * disegno: nessun nodo inventato né spostato nell'albero. */
  const sortedNodes = useMemo(() => {
    if (!data) return []
    return [...data.nodes].sort((a, b) => {
      if (a.tier !== b.tier) return a.tier - b.tier
      const locA = a.locationId ?? ''
      const locB = b.locationId ?? ''
      if (locA !== locB) return locA.localeCompare(locB, 'it')
      const nameA = a.locationName ?? ''
      const nameB = b.locationName ?? ''
      if (nameA !== nameB) return nameA.localeCompare(nameB, 'it')
      const ra = TYPE_RANK[a.type] ?? 90
      const rb = TYPE_RANK[b.type] ?? 90
      if (ra !== rb) return ra - rb
      return a.hostname.localeCompare(b.hostname, 'it')
    })
  }, [data])

  /* Riferimento ai dati correnti (aggiornato negli effetti, mai in render):
   * il layout dipende dalla firma del grafo, non dal riferimento. */
  const dataRef = useRef<{ nodes: TopoNode[]; edges: TopoEdge[]; gatewayId: string | null } | undefined>(undefined)
  useEffect(() => {
    dataRef.current = data ? { nodes: sortedNodes, edges: data.edges, gatewayId: data.gatewayId } : undefined
  }, [data, sortedNodes])

  /* Firma del grafo: il layout si ricalcola SOLO se cambia l'insieme
   * nodi+archi (nuovo caricamento) o su «Ridisegna» — mai a ogni evento. */
  const graphSig = useMemo(() => {
    if (!data) return ''
    return `${data.nodes.map((n) => n.id).sort().join(',')}#${data.edges.map((e) => e.id).sort().join(',')}`
  }, [data])

  const layoutKey = `${graphSig}#${layoutNonce}`
  /* Stato derivato (mai setState sincrono negli effetti): un layout è in
   * corso quando la chiave corrente non è ancora stata completata. */
  const layoutPending = !!data && data.nodes.length > 0 && layoutDoneKey !== layoutKey

  useEffect(() => {
    const current = dataRef.current
    /* 16.11 W9: il layout ELK serve SOLO al grafo (in raggiera sarebbe
     * lavoro sprecato + fitView su un canvas non montato). */
    if (!current || view !== 'grafo') return
    let cancelled = false
    const key = layoutKey
    layoutGraph(current.nodes, current.edges)
      .then((pos) => {
        if (cancelled) return
        setPositions(pos)
        setLayoutEpoch((e) => e + 1)
        setLayoutDoneKey(key)
        setLayoutError(null)
        /* Vista iniziale DOPO il layout: la rete reale è una stella L2
         * larga 163 nodi (audit §1.2): fit-to-all la comprime a zoom 0.15
         * (pallini). Default leggibile: centro sul gateway a zoom 0.75;
         * «Adatta vista» dà la panoramica completa quando serve. */
        window.setTimeout(() => {
          if (cancelled) return
          const gwPos = current.gatewayId ? pos.get(current.gatewayId) : undefined
          if (gwPos) {
            void setCenter(gwPos.x + NODE_W / 2, gwPos.y + NODE_H / 2, {
              zoom: 0.75,
              duration: reduceMotion ? 0 : 300,
            })
          } else {
            void fitView({ padding: 0.12, maxZoom: 0.9, duration: reduceMotion ? 0 : 300 })
          }
        }, 60)
      })
      .catch((err: unknown) => {
        if (cancelled) return
        setLayoutDoneKey(key)
        setLayoutError(err instanceof Error ? err.message : 'Errore di layout')
      })
    return () => { cancelled = true }
  }, [graphSig, layoutNonce, layoutKey, reduceMotion, fitView, setCenter, view])

  /* Sincronizza nodi/archi xyflow con i dati (posizioni conservate se il
   * layout non è cambiato: i drag dell'operatore restano validi). */
  useEffect(() => {
    if (!data || !positions) return
    const statusById = new Map(data.nodes.map((n) => [n.id, n.uiStatus]))
    setNodes((prev) => {
      const prevById = new Map(prev.map((p) => [p.id, p]))
      return sortedNodes.map((n) => {
        const p = prevById.get(n.id)
        const fresh = p && p.data.epoch === layoutEpoch ? p : undefined
        return {
          id: n.id,
          type: 'falco' as const,
          position: fresh ? fresh.position : (positions.get(n.id) ?? { x: 0, y: 0 }),
          data: { d: n, epoch: layoutEpoch },
          width: NODE_W,
          height: NODE_H,
          selected: p?.selected ?? false,
          ariaLabel: `${n.hostname}, ${typeLabel(n.type)}, ${STATUS_META[n.uiStatus]?.label ?? n.uiStatus}, livello ${n.tier}`,
        }
      })
    })
    setEdges((prev) => {
      const prevById = new Map(prev.map((p) => [p.id, p]))
      return data.edges.map((e) => {
        const p = prevById.get(e.id)
        return {
          id: e.id,
          source: e.source,
          target: e.target,
          type: 'falco-edge' as const,
          data: { e, targetDown: isDownStatus(statusById.get(e.target)) },
          selected: p?.selected ?? false,
          ariaLabel: `Collegamento ${e.linkType || 'n.d.'} da nodo a monte verso ${e.target}`,
        }
      })
    })
  }, [data, sortedNodes, positions, layoutEpoch, setNodes, setEdges])

  /* Selezione nodo dallo store (deep link ?node=…) → evidenzia nel canvas */
  useEffect(() => {
    setNodes((ns) =>
      ns.map((n) => (n.selected === (n.id === topologyNode) ? n : { ...n, selected: n.id === topologyNode })),
    )
  }, [topologyNode, setNodes])

  /* Selezione arco interna → evidenzia */
  useEffect(() => {
    setEdges((es) =>
      es.map((e) => (e.selected === (e.id === selectedEdgeId) ? e : { ...e, selected: e.id === selectedEdgeId })),
    )
  }, [selectedEdgeId, setEdges])

  /* Click su nodo: seleziona nello store e apre il quick-look (§6.2).
   * Un solo pushState: topologyNode e deviceId nella stessa patch. */
  const handleNodeClick = useCallback(
    (_: MouseEvent, node: FalcoNode) => {
      set({ topologyNode: node.id, deviceId: node.id })
      setSelectedEdgeId(null)
      onSelectEdge?.(null)
    },
    [set, onSelectEdge],
  )

  /* Click su arco: dettaglio nel pannello destro */
  const handleEdgeClick = useCallback(
    (_: MouseEvent, edge: FalcoEdge) => {
      setSelectedEdgeId(edge.id)
      onSelectEdge?.(edge.id)
    },
    [onSelectEdge],
  )

  /* Click sullo sfondo: deseleziona tutto */
  const handlePaneClick = useCallback(() => {
    set({ topologyNode: null })
    setSelectedEdgeId(null)
    onSelectEdge?.(null)
  }, [set, onSelectEdge])

  const handleRelayout = useCallback(() => {
    setLayoutNonce((n) => n + 1)
  }, [])

  /* ---------------- Stati obbligatori (§4.2) ---------------- */

  if (query.isError) {
    return (
      <ErrorPanel
        className={cn('min-h-[520px]', className)}
        message={(query.error as Error).message}
        code={(query.error as { code?: string }).code}
        onRetry={() => { void query.refetch() }}
      />
    )
  }

  if (query.isLoading) {
    return (
      <div
        className={cn('topo-canvas-bg flex min-h-[520px] flex-col items-center justify-center gap-3 rounded-lg border border-border', className)}
        role="status" aria-busy="true"
      >
        <Loader2 className="size-8 animate-spin text-text-2" aria-hidden />
        <p className="text-sm text-text-2">Calcolo albero…</p>
      </div>
    )
  }

  if (!data || data.nodes.length === 0) {
    return (
      <EmptyState
        className={cn('min-h-[520px]', className)}
        title="Nessun dispositivo in inventario"
        description="L'albero di topologia è vuoto: nessun nodo da rappresentare."
      />
    )
  }

  /* ---------------- Dati caricati: barra fonti SEMPRE visibile + vista ---------------- */

  return (
    <div className={cn('flex w-full flex-col gap-2', view === 'grafo' ? cn('min-h-[520px]', className) : 'min-h-[520px]')}>
      <SourcesToolbar
        activeKeys={activeFamilyKeys}
        onToggleFamily={toggleFamily}
        linkStats={data.linkStats}
        rootSource={data.rootSource}
        onOpenLinksManager={onOpenLinksManager}
        onOpenL2={() => setL2Open(true)}
        view={view}
        onViewChange={setView}
      />

      {/* v16.8 — dialog «Ricostruzione Layer-2» (mount solo quando aperto) */}
      {l2Open ? (
        <L2ReconstructDialog
          open={l2Open}
          onOpenChange={(o) => { if (!o) setL2Open(false) }}
          nodes={data.nodes}
        />
      ) : null}

      {view === 'raggiera' ? (
        /* 16.11 W9: raggiera per sede (altezza naturale: la pagina scorre,
         * la radice resta centrata sulla colonna delle card) */
        <TopologyFanout data={data} onSelectEdge={onSelectEdge} />
      ) : !positions ? (
        <div
          className="topo-canvas-bg flex min-h-[420px] w-full flex-1 flex-col items-center justify-center gap-3 rounded-lg border border-border"
          role="status" aria-busy="true"
        >
          <Loader2 className="size-8 animate-spin text-text-2" aria-hidden />
          <p className="text-sm text-text-2">Calcolo albero…</p>
          <p className="num text-xs text-text-2">layout layered su {data.nodes.length} nodi e {data.edges.length} archi</p>
          {layoutError ? <p className="text-xs text-crit" role="alert">{layoutError}</p> : null}
        </div>
      ) : data.edges.length === 0 ? (
        <div className="topo-canvas-bg flex min-h-[420px] w-full flex-1 items-center justify-center rounded-lg border border-border">
          <EmptyState
            className="m-3 border-0 bg-transparent"
            icon={<Unplug className="size-10" aria-hidden />}
            title="Nessun collegamento dalle fonti selezionate"
            description={
              `${data.linkStats.total} collegamenti in inventario, ${data.linkStats.excludedInferred} esclusi dal filtro. ` +
              'Abilita una famiglia o apri la gestione collegamenti.'
            }
            action={
              onOpenLinksManager ? (
                <Button size="sm" variant="outline" className="h-9" onClick={onOpenLinksManager}>
                  <ListTree className="mr-1 size-3.5" aria-hidden />
                  Apri gestione collegamenti
                </Button>
              ) : undefined
            }
          />
        </div>
      ) : (
        <div
          className="topo-canvas-bg relative min-h-[420px] w-full flex-1 overflow-hidden rounded-lg border border-border"
          role="application"
          aria-label={`Topologia logica della rete: ${data.nodes.length} nodi e ${data.edges.length} collegamenti. Usa i tasti freccia per spostarti tra i nodi e Invio per selezionare.`}
        >
          <ReactFlow
            nodes={nodes}
            edges={edges}
            colorMode={colorMode}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            onNodeClick={handleNodeClick}
            onEdgeClick={handleEdgeClick}
            onPaneClick={handlePaneClick}
            fitView
            fitViewOptions={{ padding: 0.12, maxZoom: 1 }}
            minZoom={0.15}
            maxZoom={2}
            onlyRenderVisibleElements
            nodesFocusable
            edgesFocusable
            nodesConnectable={false}
            deleteKeyCode={null}
            attributionPosition="bottom-center"
          >
            <CanvasToolbar
              layoutPending={layoutPending}
              onRelayout={handleRelayout}
              nodeCount={data.nodes.length}
              edgeCount={data.edges.length}
              unreachableCount={data.unreachableCount}
              discardedAutoEdges={data.discardedAutoEdges}
            />
            <TopologyLegend />
            <Controls position="top-right" className="rounded-md border border-border bg-surface/95 [&_button]:border-border [&_button]:bg-surface [&_button:hover]:bg-raised [&_button]:text-foreground" showInteractive={false} aria-label="Controlli zoom" />
            <MiniMap
              position="bottom-right"
              className="hidden rounded-md border border-border sm:block"
              bgColor={p.bg}
              maskColor={p.minimapMask}
              nodeStrokeColor={p.border}
              nodeStrokeWidth={2}
              nodeColor={(n: FalcoNode) => statusColor(n.data.d.uiStatus, p)}
              pannable
              zoomable
              aria-label="Mini-mappa della topologia"
            />
          </ReactFlow>
          {layoutPending ? (
            <div className="scrim-label pointer-events-none absolute left-1/2 top-4 z-10 flex -translate-x-1/2 items-center gap-2 text-[11px] text-foreground">
              <Loader2 className="size-3.5 animate-spin" aria-hidden />
              Ricalcolo layout…
            </div>
          ) : null}
        </div>
      )}
    </div>
  )
}
