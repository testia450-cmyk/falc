/* ================================================================
 * FALCO-OS v16 — Sezione «Regole evento» (16.7 ondata W3.5)
 * Secondo tab della vista Allarmi: regole evento REALI del DB
 * (modello AlertRule v15.11 R7) — le 10 SYS:* del seed del motore
 * (tarabili nelle sole soglie/tempi/severità, NON eliminabili,
 * NON modificabili nella struttura) + le regole UTENTE (CRUD
 * completo con audit EVENT_POLICY_CREATE/UPDATE/DELETE).
 * Nessun dato inventato: i contatori arrivano da /api/v2/event-
 * policies (systemCount/userCount reali; nel DB egidio 10 SYS e
 * 0 utente → empty state onesto per la sezione utente, non un
 * errore). Onestà (D): il poller di valutazione non è attivo in
 * modalità riproduzione — banner sempre visibile con la spiegazione.
 * Pattern (§4.2): badge icona+testo, stati vuoto/errore/caricamento,
 * «n.d.» per i campi mancanti, tabelle scrollabili con caption
 * accessibile, aria-label, mobile responsive.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  CircleAlert, CircleCheck, CirclePause, Cog, Info, Loader2, OctagonAlert,
  Pencil, Plus, RefreshCw, SlidersHorizontal, Trash2, TriangleAlert, UserRound,
  type LucideIcon,
} from 'lucide-react'

import { KpiCard } from '@/components/kpi-card'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { api, ApiError } from '@/lib/client/api'
import type { EventPolicyRow } from '@/lib/v2/contracts'
import { fmtDateTime, fmtNumber, SEVERITY_META } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Tipi (inferiti dalle firme della API client) ---------------- */

type CreateInput = Parameters<typeof api.createEventPolicy>[0]
type UpdatePatch = Parameters<typeof api.updateEventPolicy>[1]
type Comparison = EventPolicyRow['comparison']
type Severity = EventPolicyRow['severity']
type Metric = CreateInput['metric']

/* ---------------- Costanti sezione ---------------- */

/* Severità: icona + testo (stesso vocabolario della vista Allarmi, §4.2) */
const SEVERITY_ICONS: Record<string, LucideIcon> = {
  CRITICAL: OctagonAlert,
  HIGH: TriangleAlert,
  AVERAGE: CircleAlert,
  WARNING: CircleAlert,
  INFO: Info,
}

/** Metriche del vocabolario del dominio (POLICY_METRICS): etichetta
 * italiana + unità REALE della misura. Nessuna unità inventata: i
 * contatori/flag evento (freqChange, portMoved…) restano senza unità. */
const METRIC_META: Record<string, { label: string; unit: string }> = {
  signalStrength: { label: 'Segnale radio', unit: 'dBm' },
  pingLatency: { label: 'Latenza ping', unit: 'ms' },
  pingJitter: { label: 'Jitter latenza', unit: 'ms' },
  packetLoss: { label: 'Perdita pacchetti', unit: '%' },
  cpuLoad: { label: 'Carico CPU', unit: '%' },
  memoryUsage: { label: 'Uso memoria', unit: '%' },
  temperature: { label: 'Temperatura', unit: '°C' },
  cameraStreamAlive: { label: 'Flusso video attivo', unit: '' },
  cameraRtt: { label: 'RTT flusso video', unit: 'ms' },
  linkQuality: { label: 'Qualità link radio', unit: '%' },
  port_utilization: { label: 'Utilizzazione porta', unit: '%' },
  anomalyScore: { label: 'Punteggio di anomalia', unit: '' },
  freqChange: { label: 'Cambio frequenza radio', unit: '' },
  linkChange: { label: 'Cambio collegamento', unit: '' },
  unknownHost: { label: 'Host sconosciuto in rete', unit: '' },
  portMoved: { label: 'Porta switch spostata', unit: '' },
}

/** Vocabolario OFFERTO alle regole utente (sottoinsieme di
 * POLICY_METRICS). Le metriche dei motori (anomalyScore, freqChange,
 * linkChange, unknownHost, portMoved…) vivono solo nelle SYS:* del
 * seme v15 e non si offrono alle regole utente. */
const USER_METRIC_OPTIONS: Array<{ value: Metric; label: string }> = [
  { value: 'signalStrength', label: 'Segnale radio' },
  { value: 'pingLatency', label: 'Latenza ping' },
  { value: 'pingJitter', label: 'Jitter latenza' },
  { value: 'packetLoss', label: 'Perdita pacchetti' },
  { value: 'cpuLoad', label: 'Carico CPU' },
  { value: 'memoryUsage', label: 'Uso memoria' },
  { value: 'temperature', label: 'Temperatura' },
  { value: 'cameraStreamAlive', label: 'Flusso video attivo' },
  { value: 'cameraRtt', label: 'RTT flusso video' },
  { value: 'linkQuality', label: 'Qualità link radio' },
  { value: 'port_utilization', label: 'Utilizzazione porta' },
]
const USER_METRIC_SET = new Set<string>(USER_METRIC_OPTIONS.map((o) => o.value))

/** Confronti: operatore per la condizione leggibile + etichetta del form. */
const COMPARISON_META: Record<Comparison, { op: string; label: string }> = {
  gt: { op: '>', label: 'maggiore di' },
  lt: { op: '<', label: 'minore di' },
  eq: { op: '=', label: 'uguale a' },
  ne: { op: '≠', label: 'diverso da' },
  between: { op: 'tra', label: 'compreso tra' },
}

const SEVERITY_OPTIONS: Severity[] = ['INFO', 'WARNING', 'AVERAGE', 'HIGH', 'CRITICAL']

/* ---------------- Helpers ---------------- */

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Soglia compatta: interi senza decimali, al massimo 2 decimali con
 * virgola italiana (12.5 → «12,5»). */
function fmtThresholdValue(v: number): string {
  return Number.isInteger(v) ? String(v) : v.toLocaleString('it-IT', { maximumFractionDigits: 2 })
}

/** Condizione leggibile della regola: «> 10 %», «≠ 0», «tra 5 e 20 %».
 * Il nome della metrica è nella colonna accanto (mono): la riga si
 * legge «packetLoss > 10 %». */
function conditionText(metric: string, comparison: Comparison, threshold: number, betweenMax: number | null): string {
  const unit = METRIC_META[metric]?.unit
  const u = unit ? ` ${unit}` : ''
  if (comparison === 'between' && betweenMax != null) {
    return `tra ${fmtThresholdValue(threshold)} e ${fmtThresholdValue(betweenMax)}${u}`
  }
  const op = COMPARISON_META[comparison]?.op ?? comparison
  return `${op} ${fmtThresholdValue(threshold)}${u}`
}

/** Sostenuta per: sustainSeconds leggibile («5 min», «2 min», «immediata»). */
function fmtSustain(sec: number): string {
  if (sec <= 0) return 'immediata'
  if (sec < 60) return `${sec} s`
  if (sec % 3600 === 0) return `${sec / 3600} h`
  if (sec % 60 === 0) return `${sec / 60} min`
  return `${sec} s`
}

/** Minuti leggibili per il cooldown («30 min», «2 h»; 0 → «—»). */
function fmtMinutes(min: number): string {
  if (min <= 0) return '—'
  if (min < 60) return `${min} min`
  if (min % 60 === 0) return `${min / 60} h`
  return `${Math.floor(min / 60)} h ${min % 60} min`
}

/** Parse numero onesto: vuoto → null (campo assente), testo non
 * numerico → NaN (distinto dal vuoto: mai un input scartato in
 * silenzio). Accetta la virgola decimale italiana. */
function parseNum(raw: string): number | null {
  const t = raw.trim()
  if (t === '') return null
  const n = Number(t.replace(',', '.'))
  return Number.isFinite(n) ? n : Number.NaN
}

/** Intero nel range [min, max]: null se valido, messaggio se no. */
function intInRange(v: number, min: number, max: number, what: string): string | null {
  if (!Number.isInteger(v) || v < min || v > max) {
    return `${what} deve essere un intero tra ${min} e ${max}`
  }
  return null
}

/* ================================================================
 * RegoleEventoSection — secondo tab della vista Allarmi
 * ================================================================ */

export default function RegoleEventoSection() {
  const { data: session } = useSession()
  const queryClient = useQueryClient()

  /* Ruolo: il CLIENTE è in sola lettura (l'autorità resta il backend) */
  const role = session?.user?.role
  const canManage = !!role && role !== 'CLIENTE'

  /* --- Dati: regole REALI (SYS prima per systemKey, poi utente) --- */
  const policies = useQuery({
    queryKey: ['event-policies'],
    queryFn: () => api.eventPolicies(),
    staleTime: 30_000,
  })

  const pageData = policies.data?.data
  const items = pageData?.items ?? []
  const systemRows = items.filter((r) => r.systemKey != null)
  const userRows = items.filter((r) => r.systemKey == null)
  const systemCount = pageData?.systemCount
  const userCount = pageData?.userCount
  const asOf = policies.data?.asOf
  const mode = policies.data?.mode

  /* ultima variazione reale delle regole SYS (max updatedAt, onesto) */
  const sysLastChange = systemRows.length > 0
    ? Math.max(...systemRows.map((r) => r.updatedAt))
    : null

  /* --- Dialog (mount condizionato: prefill dai props, niente
   *     setState negli effetti — stesso pattern delle finestre) --- */
  const [tuneTarget, setTuneTarget] = useState<EventPolicyRow | null>(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [editRow, setEditRow] = useState<EventPolicyRow | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<EventPolicyRow | null>(null)

  /* --- Attiva/disattiva (SYS e utente: PATCH {enabled} reale) --- */
  const toggle = useMutation({
    mutationFn: (row: EventPolicyRow) => api.updateEventPolicy(row.id, { enabled: !row.enabled }),
    onSuccess: (row) => {
      toast.success(row.enabled ? 'Regola attivata' : 'Regola disattivata', {
        description: `«${row.name}» — modifica reale nel DB (audit EVENT_POLICY_UPDATE).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['event-policies'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Cambio stato non riuscito', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  /* --- Eliminazione (SOLO regole utente; SYS → 422 SYSTEM_RULE) --- */
  const remove = useMutation({
    mutationFn: (row: EventPolicyRow) => api.deleteEventPolicy(row.id),
    onSuccess: (res, row) => {
      toast.success('Regola eliminata', {
        description: `«${row.name}» rimossa dal DB reale (audit EVENT_POLICY_DELETE).`,
      })
      setDeleteTarget(null)
      void queryClient.invalidateQueries({ queryKey: ['event-policies'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Eliminazione non riuscita', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  return (
    <div>
      {/* D. Banner onestà: il poller non è attivo in riproduzione */}
      {mode != null ? (
        <div
          role="note"
          className="flex items-start gap-2.5 rounded-lg border border-border/70 bg-raised/40 px-3 py-2"
        >
          <Info className="mt-0.5 size-4 shrink-0 text-text-2" aria-hidden />
          <p className="min-w-0 flex-1 text-xs leading-relaxed text-text-2">
            {mode === 'replay'
              ? 'Il motore di valutazione delle regole (poller) non è attivo in modalità riproduzione: le regole sono lette e gestite, la generazione di nuovi allarmi avviene solo con i motori attivi.'
              : 'Il motore di valutazione delle regole (poller) non è attivo: le regole sono lette e gestite, la generazione di nuovi allarmi avviene solo con i motori attivi.'}
          </p>
        </div>
      ) : null}

      {/* A. KPI mini: contatori REALI della pagina (nessun hardcoded) */}
      <div className="grid grid-cols-2 gap-3">
        <div role="status" aria-live="polite">
          <KpiCard
            label="Regole di sistema"
            value={systemCount ?? '…'}
            asOf={asOf}
            definition="Regole SYS:* generate dai motori v15 (alert-engine): controlli standard dell'impianto su anomalia, qualità link, flusso video, topologia e sicurezza. Non eliminabili: solo taratura operativa."
          />
        </div>
        <div role="status" aria-live="polite">
          <KpiCard
            label="Regole utente"
            value={userCount ?? '…'}
            definition="Regole evento create dagli operatori (audit EVENT_POLICY_CREATE): metrica a scelta sul vocabolario del dominio, con soglia, severità, sostenuta, escalation e cooldown. Nascono attive su tutto l'impianto."
          />
        </div>
      </div>
      <p className="mt-2 flex items-start gap-1.5 text-xs text-text-2">
        <Cog className="mt-0.5 size-3.5 shrink-0" aria-hidden />
        Le regole SYS sono generate dai motori v15 e non sono eliminabili: struttura e nome restano del
        motore, la taratura operativa (soglie, tempi, severità) è consentita.
      </p>

      {/* Errore: visibile, con riprova */}
      {policies.isError ? (
        <ErrorPanel
          className="mt-3"
          message={errInfo(policies.error).message}
          code={errInfo(policies.error).code}
          onRetry={() => { void policies.refetch() }}
        />
      ) : null}

      {policies.isPending ? (
        <LoadingRows rows={6} className="mt-4" />
      ) : policies.isError ? null : (
        <>
          {/* B. Regole di sistema (SYS:*) */}
          <section aria-label="Regole di sistema del motore v15" className="mt-5">
            <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
              <div>
                <h3 className="text-sm font-semibold">Regole di sistema</h3>
                <p className="mt-0.5 text-xs text-text-2">
                  <span className="num font-medium text-foreground">{fmtNumber(systemRows.length)}</span>{' '}
                  regole SYS:* del motore v15 — tarabili operative, non eliminabili
                </p>
              </div>
              <div className="flex items-center gap-2">
                {asOf != null ? <AsOf ts={asOf} /> : null}
                <Button
                  variant="outline"
                  className="h-9"
                  onClick={() => { void policies.refetch() }}
                  disabled={policies.isFetching}
                >
                  <RefreshCw className={cn('size-3.5', policies.isFetching && 'animate-spin')} aria-hidden />
                  Aggiorna
                </Button>
              </div>
            </div>

            {systemRows.length === 0 ? (
              <EmptyState
                title="Nessuna regola di sistema nel DB"
                description="Nessuna regola SYS:* per questo impianto: il seme del motore v15 non è ancora stato generato (i controlli standard mancano finché il motore non viene inizializzato)."
              />
            ) : (
              <div
                className={cn(
                  'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
                  policies.isFetching && 'opacity-70',
                )}
                aria-busy={policies.isFetching}
                aria-label="Tabella regole di sistema"
              >
                <Table>
                  <TableCaption className="mt-3 text-xs text-text-2">
                    <span className="num">{fmtNumber(systemRows.length)}</span> regole di sistema reali ·
                    ordine per chiave SYS:* (contratto API)
                    {sysLastChange != null ? <> · ultima variazione {fmtDateTime(sysLastChange)}</> : null}
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col" className="min-w-[280px]">Regola</TableHead>
                      <TableHead scope="col" className="min-w-[130px]">Metrica</TableHead>
                      <TableHead scope="col" className="min-w-[130px]">Condizione</TableHead>
                      <TableHead scope="col" className="w-[120px]">Severità</TableHead>
                      <TableHead scope="col" className="w-[90px]">Cooldown</TableHead>
                      <TableHead scope="col" className="w-[80px]">Attiva</TableHead>
                      <TableHead scope="col" className="w-[130px]">
                        <span className="sr-only">Azioni</span>
                        Azioni
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {systemRows.map((r) => (
                      <SysRuleRow
                        key={r.id}
                        row={r}
                        canManage={canManage}
                        pending={toggle.isPending && toggle.variables?.id === r.id}
                        onToggle={(row) => toggle.mutate(row)}
                        onTune={setTuneTarget}
                      />
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </section>

          {/* C. Regole utente */}
          <section aria-label="Regole utente" className="mt-6">
            <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
              <div>
                <h3 className="text-sm font-semibold">Regole utente</h3>
                <p className="mt-0.5 text-xs text-text-2">
                  <span className="num font-medium text-foreground">{fmtNumber(userRows.length)}</span>{' '}
                  regole create dagli operatori — modificabili ed eliminabili
                </p>
              </div>
              {canManage ? (
                <Button className="h-9" onClick={() => setCreateOpen(true)} aria-haspopup="dialog">
                  <Plus className="size-3.5" aria-hidden />
                  Nuova regola
                </Button>
              ) : null}
            </div>

            {userRows.length === 0 ? (
              <EmptyState
                icon={<SlidersHorizontal className="size-10 text-text-2" aria-hidden />}
                title="Nessuna regola utente"
                description="Nessuna regola utente: le regole di sistema coprono i controlli standard del motore v15. Crea una regola quando serve una soglia o una severità diversa per un caso specifico dell'impianto."
              />
            ) : (
              <div
                className={cn(
                  'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
                  policies.isFetching && 'opacity-70',
                )}
                aria-busy={policies.isFetching}
                aria-label="Tabella regole utente"
              >
                <Table>
                  <TableCaption className="mt-3 text-xs text-text-2">
                    <span className="num">{fmtNumber(userRows.length)}</span> regole utente reali ·
                    create dagli operatori (audit EVENT_POLICY_CREATE)
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col" className="min-w-[280px]">Regola</TableHead>
                      <TableHead scope="col" className="min-w-[130px]">Metrica</TableHead>
                      <TableHead scope="col" className="min-w-[130px]">Condizione</TableHead>
                      <TableHead scope="col" className="w-[120px]">Severità</TableHead>
                      <TableHead scope="col" className="w-[90px]">Cooldown</TableHead>
                      <TableHead scope="col" className="w-[80px]">Attiva</TableHead>
                      <TableHead scope="col" className="w-[190px]">
                        <span className="sr-only">Azioni</span>
                        Azioni
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userRows.map((r) => (
                      <UserRuleRow
                        key={r.id}
                        row={r}
                        canManage={canManage}
                        pending={toggle.isPending && toggle.variables?.id === r.id}
                        onToggle={(row) => toggle.mutate(row)}
                        onEdit={setEditRow}
                        onDelete={setDeleteTarget}
                      />
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </section>
        </>
      )}

      {/* Dialog taratura SYS (mount condizionato: prefill reale) */}
      {tuneTarget ? (
        <SysTuneDialog
          row={tuneTarget}
          open
          onOpenChange={(o) => { if (!o) setTuneTarget(null) }}
        />
      ) : null}

      {/* Dialog regola utente: creazione e modifica condiviso */}
      {createOpen ? (
        <UserRuleDialog
          mode="create"
          open
          onOpenChange={(o) => { if (!o) setCreateOpen(false) }}
        />
      ) : null}
      {editRow ? (
        <UserRuleDialog
          mode="edit"
          row={editRow}
          open
          onOpenChange={(o) => { if (!o) setEditRow(null) }}
        />
      ) : null}

      {/* Conferma eliminazione (solo regole utente) */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !remove.isPending) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Elimina la regola evento</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Confermi l&apos;eliminazione della regola utente{' '}
              <strong className="text-foreground">{deleteTarget ? `«${deleteTarget.name}»` : ''}</strong>?
              L&apos;azione è definitiva, registra una voce di audit (EVENT_POLICY_DELETE) e i controlli
              della regola cessano. Se la regola ha allarmi nello storico l&apos;eliminazione è rifiutata
              per integrità referenziale (errore RULE_IN_USE onesto).
            </AlertDialogDescription>
          </AlertDialogHeader>

          {deleteTarget ? (
            <p className="break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2">
              {conditionText(deleteTarget.metric, deleteTarget.comparison, deleteTarget.threshold, deleteTarget.betweenMax)}
              {' · severità '}
              {SEVERITY_META[deleteTarget.severity]?.label ?? deleteTarget.severity}
              {deleteTarget.description ? ` · ${deleteTarget.description}` : ''}
            </p>
          ) : null}

          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={remove.isPending}
              onClick={(e) => {
                e.preventDefault() // resta aperto finché la risposta reale non arriva
                if (!deleteTarget || remove.isPending) return
                remove.mutate(deleteTarget)
              }}
            >
              {remove.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

/* ---------------- Badge severità (icona + testo, §4.2) ---------------- */

function SeverityBadge({ severity }: { severity: string }) {
  const meta = SEVERITY_META[severity] ?? { label: severity, cls: 'bg-info-soft text-info border-info/40' }
  const Icon = SEVERITY_ICONS[severity] ?? CircleAlert
  return (
    <Badge variant="outline" className={cn('gap-1.5 font-medium whitespace-nowrap', meta.cls)}>
      <Icon className="size-3.5" aria-hidden />
      {meta.label}
    </Badge>
  )
}

/* ---------------- Righe tabella ---------------- */

/** Cella «Regola» condivisa: nome, descrizione reale (title col testo
 * completo) e chiave/origine. */
function RuleNameCell({ row, sys }: { row: EventPolicyRow; sys: boolean }) {
  return (
    <TableCell className="max-w-[340px]">
      <div className="space-y-1">
        <div className="flex flex-wrap items-center gap-2">
          {sys ? (
            <Badge
              variant="outline"
              className="gap-1.5 border-info/40 bg-info-soft font-medium text-info whitespace-nowrap"
              title="Regola generata dal motore v15 (SYS:*): non eliminabile, solo tarabile"
            >
              <Cog className="size-3.5" aria-hidden />
              Sistema
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="gap-1.5 border-border bg-raised font-normal text-text-2 whitespace-nowrap"
              title="Regola creata da un operatore: modificabile ed eliminabile"
            >
              <UserRound className="size-3.5" aria-hidden />
              Utente
            </Badge>
          )}
          {sys && row.systemKey ? (
            <span className="num font-mono text-xs text-text-2">{row.systemKey}</span>
          ) : (
            <span className="num text-xs text-text-2" title={`Ultima modifica ${fmtDateTime(row.updatedAt)}`}>
              agg. {fmtDateTime(row.updatedAt)}
            </span>
          )}
        </div>
        <p className="break-words text-sm font-medium leading-snug">{row.name}</p>
        {row.description ? (
          <p className="line-clamp-2 break-words text-xs leading-snug text-text-2" title={row.description}>
            {row.description}
          </p>
        ) : null}
      </div>
    </TableCell>
  )
}

/** Cella «Condizione» condivisa: confronto+soglia (+ sostenuta reale). */
function ConditionCell({ row }: { row: EventPolicyRow }) {
  return (
    <TableCell>
      <span className="num text-sm">{conditionText(row.metric, row.comparison, row.threshold, row.betweenMax)}</span>
      {row.sustainSeconds > 0 ? (
        <p className="text-xs text-text-2" title={`La condizione deve valere per ${row.sustainSeconds} s consecutive`}>
          sostenuta ≥ {fmtSustain(row.sustainSeconds)}
        </p>
      ) : null}
    </TableCell>
  )
}

/** Cella «Attiva»: Switch inline con PATCH reale (CLIENTE → badge). */
function EnabledCell({ row, canManage, pending, onToggle }: {
  row: EventPolicyRow
  canManage: boolean
  pending: boolean
  onToggle: (row: EventPolicyRow) => void
}) {
  if (!canManage) {
    return (
      <TableCell>
        {row.enabled ? (
          <Badge variant="outline" className="gap-1.5 border-ok/40 bg-ok-soft font-normal text-ok whitespace-nowrap">
            <CircleCheck className="size-3.5" aria-hidden />
            Attiva
          </Badge>
        ) : (
          <Badge variant="outline" className="gap-1.5 border-border bg-raised font-normal text-text-2 whitespace-nowrap">
            <CirclePause className="size-3.5" aria-hidden />
            Sospesa
          </Badge>
        )}
      </TableCell>
    )
  }
  return (
    <TableCell>
      <span className="flex items-center gap-1.5">
        <Switch
          checked={row.enabled}
          disabled={pending}
          onCheckedChange={() => onToggle(row)}
          aria-label={`${row.enabled ? 'Disattiva' : 'Attiva'} la regola ${row.name}`}
        />
        {pending ? <Loader2 className="size-3.5 animate-spin text-text-2" aria-hidden /> : null}
        <span className="sr-only">regola {row.enabled ? 'attiva' : 'sospesa'}</span>
      </span>
    </TableCell>
  )
}

function SysRuleRow({ row, canManage, pending, onToggle, onTune }: {
  row: EventPolicyRow
  canManage: boolean
  pending: boolean
  onToggle: (row: EventPolicyRow) => void
  onTune: (row: EventPolicyRow) => void
}) {
  return (
    <TableRow aria-label={`Regola di sistema ${row.name}`}>
      <RuleNameCell row={row} sys />
      <TableCell><span className="num font-mono text-xs">{row.metric}</span></TableCell>
      <ConditionCell row={row} />
      <TableCell><SeverityBadge severity={row.severity} /></TableCell>
      <TableCell><span className="num text-sm">{fmtMinutes(row.cooldownMinutes)}</span></TableCell>
      <EnabledCell row={row} canManage={canManage} pending={pending} onToggle={onToggle} />
      <TableCell>
        {canManage ? (
          <Button
            variant="outline"
            size="sm"
            className="h-9"
            onClick={() => onTune(row)}
            aria-haspopup="dialog"
            aria-label={`Taratura della regola ${row.name}`}
            title="Soglie, tempi e severità: la struttura resta del motore"
          >
            <SlidersHorizontal className="size-3.5" aria-hidden />
            Taratura
          </Button>
        ) : (
          <span className="text-xs text-dim">sola lettura</span>
        )}
      </TableCell>
    </TableRow>
  )
}

function UserRuleRow({ row, canManage, pending, onToggle, onEdit, onDelete }: {
  row: EventPolicyRow
  canManage: boolean
  pending: boolean
  onToggle: (row: EventPolicyRow) => void
  onEdit: (row: EventPolicyRow) => void
  onDelete: (row: EventPolicyRow) => void
}) {
  return (
    <TableRow aria-label={`Regola utente ${row.name}`}>
      <RuleNameCell row={row} sys={false} />
      <TableCell><span className="num font-mono text-xs">{row.metric}</span></TableCell>
      <ConditionCell row={row} />
      <TableCell><SeverityBadge severity={row.severity} /></TableCell>
      <TableCell><span className="num text-sm">{fmtMinutes(row.cooldownMinutes)}</span></TableCell>
      <EnabledCell row={row} canManage={canManage} pending={pending} onToggle={onToggle} />
      <TableCell>
        {canManage ? (
          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              onClick={() => onEdit(row)}
              aria-haspopup="dialog"
              aria-label={`Modifica la regola ${row.name}`}
            >
              <Pencil className="size-3.5" aria-hidden />
              Modifica
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-9 text-crit hover:bg-crit-soft hover:text-crit-text"
              onClick={() => onDelete(row)}
              aria-label={`Elimina la regola ${row.name}`}
            >
              <Trash2 className="size-3.5" aria-hidden />
              Elimina
            </Button>
          </div>
        ) : (
          <span className="text-xs text-dim">sola lettura</span>
        )}
      </TableCell>
    </TableRow>
  )
}

/* ================================================================
 * Dialog «Taratura» (SOLO regole SYS:*)
 * Campi consentiti dal contratto: threshold, recoveryThreshold,
 * betweenMax (se between), sustainSeconds, severity,
 * escalateAfterMinutes, cooldownMinutes. Struttura, nome, metrica e
 * scope restano del motore.
 * ================================================================ */

function SysTuneDialog({ row, open, onOpenChange }: {
  row: EventPolicyRow
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()

  const unit = METRIC_META[row.metric]?.unit
  const uHint = unit ? ` · ${unit}` : ''

  /* Prefill: valori REALI della riga (null → campo vuoto) */
  const [thresholdRaw, setThresholdRaw] = useState(String(row.threshold))
  const [recoveryRaw, setRecoveryRaw] = useState(row.recoveryThreshold != null ? String(row.recoveryThreshold) : '')
  const [betweenMaxRaw, setBetweenMaxRaw] = useState(row.betweenMax != null ? String(row.betweenMax) : '')
  const [sustainRaw, setSustainRaw] = useState(String(row.sustainSeconds))
  const [severity, setSeverity] = useState<Severity>(row.severity)
  const [escalateRaw, setEscalateRaw] = useState(String(row.escalateAfterMinutes))
  const [cooldownRaw, setCooldownRaw] = useState(String(row.cooldownMinutes))

  const update = useMutation({
    mutationFn: (v: { id: string; patch: UpdatePatch }) => api.updateEventPolicy(v.id, v.patch),
    onSuccess: (updated) => {
      toast.success('Taratura salvata', {
        description: `«${updated.name}» — modifiche reali nel DB (audit EVENT_POLICY_UPDATE con diff dei soli campi cambiati).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['event-policies'] })
      onOpenChange(false)
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Taratura non riuscita', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  const submit = () => {
    /* Validazione onesta lato client (la stessa del contratto server) */
    const threshold = parseNum(thresholdRaw)
    if (threshold == null || Number.isNaN(threshold)) {
      toast.error('Taratura non valida', { description: 'Inserisci un valore numerico valido per la soglia.' })
      return
    }
    const recovery = parseNum(recoveryRaw)
    if (Number.isNaN(recovery)) {
      toast.error('Taratura non valida', { description: 'La soglia di recupero deve essere un numero (oppure vuota = nessuna).' })
      return
    }
    let betweenMax: number | null = null
    if (row.comparison === 'between') {
      const v = parseNum(betweenMaxRaw)
      if (v == null || Number.isNaN(v)) {
        toast.error('Taratura non valida', { description: 'Il confronto «compreso tra» richiede il limite massimo.' })
        return
      }
      if (!(v > threshold)) {
        toast.error('Taratura non valida', { description: 'Il limite massimo deve essere maggiore della soglia.' })
        return
      }
      betweenMax = v
    }
    const sustain = parseNum(sustainRaw)
    if (sustain == null || Number.isNaN(sustain)) {
      toast.error('Taratura non valida', { description: 'Inserisci i secondi di sostenuta (0 = valutazione immediata).' })
      return
    }
    const sustainErr = intInRange(sustain, 0, 86400, 'La sostenuta')
    if (sustainErr) { toast.error('Taratura non valida', { description: sustainErr }); return }
    const escalate = parseNum(escalateRaw)
    if (escalate == null || Number.isNaN(escalate)) {
      toast.error('Taratura non valida', { description: 'Inserisci i minuti di escalation (0 = nessuna).' })
      return
    }
    const escalateErr = intInRange(escalate, 0, 10080, 'L\'escalation')
    if (escalateErr) { toast.error('Taratura non valida', { description: escalateErr }); return }
    const cooldown = parseNum(cooldownRaw)
    if (cooldown == null || Number.isNaN(cooldown)) {
      toast.error('Taratura non valida', { description: 'Inserisci il cooldown in minuti.' })
      return
    }
    const cooldownErr = intInRange(cooldown, 1, 1440, 'Il cooldown')
    if (cooldownErr) { toast.error('Taratura non valida', { description: cooldownErr }); return }

    /* PATCH con SOLO i campi cambiati (il server rifà il diff e
     * risponde NO_CHANGES se la patch non ha effetto reale) */
    const patch: UpdatePatch = {}
    if (threshold !== row.threshold) patch.threshold = threshold
    if (recovery !== row.recoveryThreshold) patch.recoveryThreshold = recovery
    if (betweenMax !== row.betweenMax) patch.betweenMax = betweenMax
    if (sustain !== row.sustainSeconds) patch.sustainSeconds = sustain
    if (severity !== row.severity) patch.severity = severity
    if (escalate !== row.escalateAfterMinutes) patch.escalateAfterMinutes = escalate
    if (cooldown !== row.cooldownMinutes) patch.cooldownMinutes = cooldown
    if (Object.keys(patch).length === 0) {
      toast.error('Nessuna modifica da salvare', {
        description: 'I valori sono identici a quelli attuali della regola: cambia almeno un campo di taratura.',
      })
      return
    }
    update.mutate({ id: row.id, patch })
  }

  const pending = update.isPending
  const between = row.comparison === 'between'

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v && !pending) onOpenChange(false) }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <SlidersHorizontal className="size-4 text-text-2" aria-hidden />
            Taratura regola di sistema
          </DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Taratura operativa della regola <span className="num font-mono">{row.systemKey}</span> —{' '}
            «{row.name}». Lettura attuale:{' '}
            <span className="num">
              {row.metric} {conditionText(row.metric, row.comparison, row.threshold, row.betweenMax)}
            </span>
            , ultima modifica {fmtDateTime(row.updatedAt)}.
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-3" onSubmit={(e) => { e.preventDefault(); submit() }} noValidate>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <label htmlFor="tune-threshold" className="text-xs font-medium text-text-2">
                Soglia (threshold){uHint}
              </label>
              <Input
                id="tune-threshold"
                type="number"
                step="any"
                inputMode="decimal"
                value={thresholdRaw}
                onChange={(e) => setThresholdRaw(e.target.value)}
                className="num"
                aria-required="true"
              />
            </div>
            {between ? (
              <div className="grid gap-1.5">
                <label htmlFor="tune-between-max" className="text-xs font-medium text-text-2">
                  Limite massimo (betweenMax){uHint}
                </label>
                <Input
                  id="tune-between-max"
                  type="number"
                  step="any"
                  inputMode="decimal"
                  value={betweenMaxRaw}
                  onChange={(e) => setBetweenMaxRaw(e.target.value)}
                  className="num"
                  aria-required="true"
                />
              </div>
            ) : null}
            <div className="grid gap-1.5">
              <label htmlFor="tune-recovery" className="text-xs font-medium text-text-2">
                Soglia di recupero (opzionale){uHint}
              </label>
              <Input
                id="tune-recovery"
                type="number"
                step="any"
                inputMode="decimal"
                value={recoveryRaw}
                onChange={(e) => setRecoveryRaw(e.target.value)}
                className="num"
              />
              <p className="text-[11px] text-dim">Vuoto = nessuna soglia di rientro dell&apos;allarme.</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="tune-severity" className="text-xs font-medium text-text-2">Severità</label>
              <Select value={severity} onValueChange={(v) => setSeverity(v as Severity)}>
                <SelectTrigger id="tune-severity" aria-label="Severità della regola"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SEVERITY_OPTIONS.map((s) => (
                    <SelectItem key={s} value={s}>{SEVERITY_META[s]?.label ?? s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="tune-sustain" className="text-xs font-medium text-text-2">Sostenuta per (secondi)</label>
              <Input
                id="tune-sustain"
                type="number"
                min={0}
                max={86400}
                step={1}
                inputMode="numeric"
                value={sustainRaw}
                onChange={(e) => setSustainRaw(e.target.value)}
                className="num"
              />
              <p className="text-[11px] text-dim">0 = valutazione immediata (nessuna finestra).</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="tune-escalate" className="text-xs font-medium text-text-2">Escalation dopo (minuti)</label>
              <Input
                id="tune-escalate"
                type="number"
                min={0}
                max={10080}
                step={1}
                inputMode="numeric"
                value={escalateRaw}
                onChange={(e) => setEscalateRaw(e.target.value)}
                className="num"
              />
              <p className="text-[11px] text-dim">0 = nessuna escalation automatica.</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="tune-cooldown" className="text-xs font-medium text-text-2">Cooldown (minuti)</label>
              <Input
                id="tune-cooldown"
                type="number"
                min={1}
                max={1440}
                step={1}
                inputMode="numeric"
                value={cooldownRaw}
                onChange={(e) => setCooldownRaw(e.target.value)}
                className="num"
                aria-required="true"
              />
              <p className="text-[11px] text-dim">Minuti minimi tra allarmi ripetuti della stessa regola.</p>
            </div>
          </div>

          {/* Nota obbligatoria: campo di taratura operativa */}
          <p className="flex items-start gap-2 rounded-md bg-raised/50 px-3 py-2 text-xs leading-relaxed text-text-2">
            <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
            Campo di taratura operativa: struttura e nome restano del motore. La regola SYS non è
            eliminabile e metrica, confronto, scope e tipi dispositivo non si toccano da qui.
          </p>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="h-11 sm:h-9" onClick={() => onOpenChange(false)} disabled={pending}>
              Annulla
            </Button>
            <Button type="submit" className="h-11 sm:h-9" disabled={pending}>
              {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <SlidersHorizontal className="size-3.5" aria-hidden />}
              {pending ? 'Salvataggio…' : 'Salva taratura'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * Dialog regola UTENTE (creazione + modifica condiviso)
 * Crea: POST con defaults dichiarati del backend (attiva, scope ALL,
 * severity WARNING, sustain 0, escalation 0, cooldown 30).
 * Modifica: PATCH con SOLO i campi cambiati.
 * ================================================================ */

function UserRuleDialog({ mode, row, open, onOpenChange }: {
  mode: 'create' | 'edit'
  row?: EventPolicyRow | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()

  /* Prefill: create → defaults ONESTI del modello (dichiarati dal
   * backend); edit → valori REALI della riga (metrica fuori
   * vocabolario mostrata raw, mai nascosta). */
  const [name, setName] = useState(row?.name ?? '')
  const [description, setDescription] = useState(row?.description ?? '')
  const [metric, setMetric] = useState<Metric>(row != null ? (row.metric as Metric) : 'packetLoss')
  const [comparison, setComparison] = useState<Comparison>(row?.comparison ?? 'gt')
  const [thresholdRaw, setThresholdRaw] = useState(row != null ? String(row.threshold) : '')
  const [betweenMaxRaw, setBetweenMaxRaw] = useState(row?.betweenMax != null ? String(row.betweenMax) : '')
  const [severity, setSeverity] = useState<Severity>(row?.severity ?? 'WARNING')
  const [cooldownRaw, setCooldownRaw] = useState(String(row?.cooldownMinutes ?? 30))
  const [sustainRaw, setSustainRaw] = useState(String(row?.sustainSeconds ?? 0))
  const [escalateRaw, setEscalateRaw] = useState(String(row?.escalateAfterMinutes ?? 0))

  const extraMetric = mode === 'edit' && row != null && !USER_METRIC_SET.has(row.metric) ? row.metric : null
  const between = comparison === 'between'
  const metricUnit = METRIC_META[metric]?.unit
  const uHint = metricUnit ? ` · ${metricUnit}` : ''

  const create = useMutation({
    mutationFn: (input: CreateInput) => api.createEventPolicy(input),
    onSuccess: (created) => {
      toast.success('Regola evento creata', {
        description: `«${created.name}» scritta nel DB reale (audit EVENT_POLICY_CREATE). Nasce attiva su tutto l'impianto.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['event-policies'] })
      onOpenChange(false)
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Creazione non riuscita', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  const update = useMutation({
    mutationFn: (v: { id: string; patch: UpdatePatch }) => api.updateEventPolicy(v.id, v.patch),
    onSuccess: (updated) => {
      toast.success('Regola aggiornata', {
        description: `«${updated.name}» — modifiche reali nel DB (audit EVENT_POLICY_UPDATE con diff dei soli campi cambiati).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['event-policies'] })
      onOpenChange(false)
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Aggiornamento non riuscito', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  const pending = create.isPending || update.isPending

  const submit = () => {
    /* --- Validazione onesta (la stessa del contratto server) --- */
    if (name.trim().length < 3 || name.trim().length > 120) {
      toast.error('Regola non valida', { description: 'Il nome deve avere da 3 a 120 caratteri.' })
      return
    }
    const threshold = parseNum(thresholdRaw)
    if (threshold == null || Number.isNaN(threshold)) {
      toast.error('Regola non valida', { description: 'Inserisci un valore numerico valido per la soglia.' })
      return
    }
    let betweenMax: number | null = null
    if (between) {
      const v = parseNum(betweenMaxRaw)
      if (v == null || Number.isNaN(v)) {
        toast.error('Regola non valida', { description: 'Il confronto «compreso tra» richiede il limite massimo.' })
        return
      }
      if (!(v > threshold)) {
        toast.error('Regola non valida', { description: 'Il limite massimo deve essere maggiore della soglia.' })
        return
      }
      betweenMax = v
    }
    const cooldown = parseNum(cooldownRaw)
    if (cooldown == null || Number.isNaN(cooldown)) {
      toast.error('Regola non valida', { description: 'Inserisci il cooldown in minuti.' })
      return
    }
    const cooldownErr = intInRange(cooldown, 1, 1440, 'Il cooldown')
    if (cooldownErr) { toast.error('Regola non valida', { description: cooldownErr }); return }
    const sustain = parseNum(sustainRaw)
    if (sustain == null || Number.isNaN(sustain)) {
      toast.error('Regola non valida', { description: 'Inserisci i secondi di sostenuta (0 = valutazione immediata).' })
      return
    }
    const sustainErr = intInRange(sustain, 0, 86400, 'La sostenuta')
    if (sustainErr) { toast.error('Regola non valida', { description: sustainErr }); return }
    const escalate = parseNum(escalateRaw)
    if (escalate == null || Number.isNaN(escalate)) {
      toast.error('Regola non valida', { description: 'Inserisci i minuti di escalation (0 = nessuna).' })
      return
    }
    const escalateErr = intInRange(escalate, 0, 10080, 'L\'escalation')
    if (escalateErr) { toast.error('Regola non valida', { description: escalateErr }); return }

    if (mode === 'create') {
      create.mutate({
        name: name.trim(),
        description: description.trim() || undefined,
        metric,
        comparison,
        threshold,
        ...(between && betweenMax != null ? { betweenMax } : {}),
        severity,
        cooldownMinutes: cooldown,
        sustainSeconds: sustain,
        escalateAfterMinutes: escalate,
      })
      return
    }

    /* --- Modifica: PATCH con SOLO i campi cambiati --- */
    if (!row) return
    const patch: UpdatePatch = {}
    if (name.trim() !== row.name) patch.name = name.trim()
    if (description.trim() !== row.description) patch.description = description.trim()
    if (metric !== row.metric) patch.metric = metric
    if (comparison !== row.comparison) patch.comparison = comparison
    if (threshold !== row.threshold) patch.threshold = threshold
    /* tra → altro confronto: il vecchio limite massimo si azzera
     * (mai dati stantii in DB); altro → tra: betweenMax già validato */
    if (betweenMax !== row.betweenMax) patch.betweenMax = between ? betweenMax : null
    if (severity !== row.severity) patch.severity = severity
    if (cooldown !== row.cooldownMinutes) patch.cooldownMinutes = cooldown
    if (sustain !== row.sustainSeconds) patch.sustainSeconds = sustain
    if (escalate !== row.escalateAfterMinutes) patch.escalateAfterMinutes = escalate
    if (Object.keys(patch).length === 0) {
      toast.error('Nessuna modifica da salvare', {
        description: 'I valori sono identici a quelli attuali della regola: cambia almeno un campo.',
      })
      return
    }
    update.mutate({ id: row.id, patch })
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v && !pending) onOpenChange(false) }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? 'Nuova regola evento' : 'Modifica regola evento'}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {mode === 'create'
              ? 'Scrittura REALE nel DB (audit EVENT_POLICY_CREATE). La regola nasce attiva su tutto l\'impianto (scope ALL) con i valori del form.'
              : `Modifica REALE nel DB (audit EVENT_POLICY_UPDATE con diff). Vengono inviati solo i campi cambiati; l'ultima modifica risale al ${fmtDateTime(row?.updatedAt ?? null)}.`}
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-3" onSubmit={(e) => { e.preventDefault(); submit() }} noValidate>
          <div className="grid gap-1.5">
            <label htmlFor="rule-name" className="text-xs font-medium text-text-2">Nome *</label>
            <Input
              id="rule-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="es. Perdita pacchetti alta verso il municipio"
              maxLength={120}
              aria-required="true"
            />
            <p className="text-[11px] text-dim">Univoco per impianto (confronto case-insensitive).</p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="rule-desc" className="text-xs font-medium text-text-2">Descrizione</label>
            <Textarea
              id="rule-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              maxLength={500}
              placeholder="Opzionale: cosa controlla la regola, perché esiste…"
            />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <label htmlFor="rule-metric" className="text-xs font-medium text-text-2">Metrica *</label>
              <Select value={metric} onValueChange={(v) => setMetric(v as Metric)}>
                <SelectTrigger id="rule-metric" aria-label="Metrica della regola"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {extraMetric ? (
                    <SelectItem value={extraMetric}>{extraMetric} (fuori vocabolario)</SelectItem>
                  ) : null}
                  {USER_METRIC_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="rule-comparison" className="text-xs font-medium text-text-2">Confronto *</label>
              <Select value={comparison} onValueChange={(v) => setComparison(v as Comparison)}>
                <SelectTrigger id="rule-comparison" aria-label="Tipo di confronto"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(Object.keys(COMPARISON_META) as Comparison[]).map((c) => (
                    <SelectItem key={c} value={c}>{COMPARISON_META[c].label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <label htmlFor="rule-threshold" className="text-xs font-medium text-text-2">
                Soglia (threshold){uHint} *
              </label>
              <Input
                id="rule-threshold"
                type="number"
                step="any"
                inputMode="decimal"
                value={thresholdRaw}
                onChange={(e) => setThresholdRaw(e.target.value)}
                placeholder="es. 10"
                className="num"
                aria-required="true"
              />
            </div>
            {between ? (
              <div className="grid gap-1.5">
                <label htmlFor="rule-between-max" className="text-xs font-medium text-text-2">
                  Limite massimo (betweenMax){uHint} *
                </label>
                <Input
                  id="rule-between-max"
                  type="number"
                  step="any"
                  inputMode="decimal"
                  value={betweenMaxRaw}
                  onChange={(e) => setBetweenMaxRaw(e.target.value)}
                  placeholder="es. 20"
                  className="num"
                  aria-required="true"
                />
              </div>
            ) : null}
            <div className="grid gap-1.5">
              <label htmlFor="rule-severity" className="text-xs font-medium text-text-2">Severità</label>
              <Select value={severity} onValueChange={(v) => setSeverity(v as Severity)}>
                <SelectTrigger id="rule-severity" aria-label="Severità della regola"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SEVERITY_OPTIONS.map((s) => (
                    <SelectItem key={s} value={s}>{SEVERITY_META[s]?.label ?? s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="rule-cooldown" className="text-xs font-medium text-text-2">Cooldown (minuti) *</label>
              <Input
                id="rule-cooldown"
                type="number"
                min={1}
                max={1440}
                step={1}
                inputMode="numeric"
                value={cooldownRaw}
                onChange={(e) => setCooldownRaw(e.target.value)}
                className="num"
                aria-required="true"
              />
              <p className="text-[11px] text-dim">Minuti minimi tra allarmi ripetuti (1–1440).</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="rule-sustain" className="text-xs font-medium text-text-2">Sostenuta per (secondi)</label>
              <Input
                id="rule-sustain"
                type="number"
                min={0}
                max={86400}
                step={1}
                inputMode="numeric"
                value={sustainRaw}
                onChange={(e) => setSustainRaw(e.target.value)}
                className="num"
              />
              <p className="text-[11px] text-dim">0 = valutazione immediata (0–86400).</p>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="rule-escalate" className="text-xs font-medium text-text-2">Escalation dopo (minuti)</label>
              <Input
                id="rule-escalate"
                type="number"
                min={0}
                max={10080}
                step={1}
                inputMode="numeric"
                value={escalateRaw}
                onChange={(e) => setEscalateRaw(e.target.value)}
                className="num"
              />
              <p className="text-[11px] text-dim">0 = nessuna escalation automatica (0–10080).</p>
            </div>
          </div>

          <p className="flex items-start gap-2 rounded-md bg-raised/50 px-3 py-2 text-xs leading-relaxed text-text-2">
            <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
            La regola nasce attiva su tutto l&apos;impianto (scope ALL): sedi, dispositivi e tipi si
            restringono via API, non da questo form. Il nome è univoco per impianto: un duplicato è
            rifiutato con errore NAME_EXISTS.
          </p>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="h-11 sm:h-9" onClick={() => onOpenChange(false)} disabled={pending}>
              Annulla
            </Button>
            <Button type="submit" className="h-11 sm:h-9" disabled={pending}>
              {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
              {mode === 'create'
                ? (create.isPending ? 'Creazione…' : 'Crea regola')
                : (update.isPending ? 'Salvataggio…' : 'Salva modifiche')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
