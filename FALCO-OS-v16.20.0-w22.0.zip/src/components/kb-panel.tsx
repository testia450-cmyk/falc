/* ================================================================
 * FALCO-OS v16 — Pannello «Knowledge base» (16.9 ondata W4)
 * Articoli ripetibili dell'impianto: nati a mano («Nuovo articolo»)
 * o estratti da un ticket («Da ticket»: titolo «KB: …», corpo
 * Problema/Soluzione). CRUD REALE sul DB — la tabella parte vuota:
 * lo empty state lo dichiara (0 articoli nel database reale), mai
 * righe di esempio inventate.
 * ================================================================ */

'use client'

import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { BookOpen, Loader2, Pencil, Plus, RefreshCw, Search, TicketCheck, Trash2 } from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { api, ApiError, type KbArticleRow } from '@/lib/client/api'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtRelative } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Helper ---------------- */

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** «a,b , c» → ['a','b','c'] (max 10, vuoti scartati) */
function parseTags(raw: string): string[] {
  return raw.split(',').map((t) => t.trim()).filter((t) => t.length > 0).slice(0, 10)
}

/* ================================================================
 * Knowledge base — pannello (renderizzato dalla vista padre in tab)
 * ================================================================ */

export function KbPanel() {
  const queryClient = useQueryClient()

  /* --- Ricerca con debounce ~400 ms (parametro q della API) --- */
  const [search, setSearch] = useState('')
  const [q, setQ] = useState('')
  useEffect(() => {
    const t = setTimeout(() => setQ(search.trim()), 400)
    return () => clearTimeout(t)
  }, [search])

  const kb = useQuery({
    queryKey: ['kb', q],
    queryFn: () => api.kb(q || undefined),
    staleTime: 30_000,
  })
  const items = kb.data?.data.items ?? []
  const total = kb.data?.data.total ?? 0

  /* --- Dialog: nuovo articolo --- */
  const [createOpen, setCreateOpen] = useState(false)
  const [cTitle, setCTitle] = useState('')
  const [cBody, setCBody] = useState('')
  const [cTags, setCTags] = useState('')

  /* --- Dialog: da ticket --- */
  const [ticketOpen, setTicketOpen] = useState(false)
  const [ticketId, setTicketId] = useState('')
  const tickets = useQuery({
    queryKey: ['tickets', 'kb-source', 1, 10],
    queryFn: () => api.tickets({ page: 1, pageSize: 10 }),
    staleTime: 60_000,
    enabled: ticketOpen, /* caricati solo quando serve il selettore */
  })
  const ticketList = tickets.data?.data.items ?? []

  /* --- Dialog: dettaglio / modifica / eliminazione --- */
  const [detail, setDetail] = useState<KbArticleRow | null>(null)
  const [editMode, setEditMode] = useState(false)
  const [eTitle, setETitle] = useState('')
  const [eBody, setEBody] = useState('')
  const [eTags, setETags] = useState('')
  const [deleteTarget, setDeleteTarget] = useState<KbArticleRow | null>(null)

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['kb'] })
  }

  const resetCreateForm = () => {
    setCTitle('')
    setCBody('')
    setCTags('')
  }

  const resetEditForm = () => {
    setETitle('')
    setEBody('')
    setETags('')
    setEditMode(false)
  }

  const openDetail = (a: KbArticleRow) => {
    setDetail(a)
    setETitle(a.title)
    setEBody(a.body)
    setETags(a.tags.join(', '))
    setEditMode(false)
  }

  /* --- Mutazioni (toast per ogni esito, invalidazione ['kb']) --- */

  const create = useMutation({
    mutationFn: (input: { title: string; body: string; tags?: string[] }) => api.createKbArticle(input),
    onSuccess: (row) => {
      toast.success('Articolo creato', {
        description: `«${row.title}»: voce REALE salvata nel DB della knowledge base dell'impianto.`,
      })
      resetCreateForm()
      setCreateOpen(false)
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Creazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const fromTicket = useMutation({
    mutationFn: (id: string) => api.kbFromTicket(id),
    onSuccess: (row) => {
      toast.success('Articolo creato dal ticket', {
        description: `«${row.title}»: problema e soluzione del ticket diventano conoscenza ripetibile.`,
      })
      setTicketId('')
      setTicketOpen(false)
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Creazione da ticket non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const update = useMutation({
    mutationFn: (input: { id: string; title: string; body: string; tags: string[] }) =>
      api.updateKbArticle(input.id, { title: input.title, body: input.body, tags: input.tags }),
    onSuccess: (row) => {
      toast.success('Articolo aggiornato', {
        description: `«${row.title}»: revisione REALE salvata nel DB.`,
      })
      setDetail(row)
      setEditMode(false)
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Aggiornamento non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteKbArticle(id),
    onSuccess: () => {
      toast.success('Articolo eliminato', {
        description: 'Voce rimossa dal DB reale. L\'azione è registrata nell\'audit.',
      })
      setDeleteTarget(null)
      setDetail(null)
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submitCreate = () => {
    const title = cTitle.trim()
    const body = cBody.trim()
    if (title.length < 1 || body.length < 1 || create.isPending) return
    const tags = parseTags(cTags)
    create.mutate(tags.length > 0 ? { title, body, tags } : { title, body })
  }

  const submitUpdate = () => {
    if (!detail) return
    const title = eTitle.trim()
    const body = eBody.trim()
    if (title.length < 1 || body.length < 1 || update.isPending) return
    update.mutate({ id: detail.id, title, body, tags: parseTags(eTags) })
  }

  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <BookOpen className="size-4 text-text-2" aria-hidden />
          Knowledge base
          {kb.data ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              {total} articoli
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Conoscenza ripetibile dell&apos;impianto: articoli scritti a mano o estratti dai ticket
          (Problema/Soluzione). Ricerca sul titolo, corpo e tag.
        </CardDescription>
        <CardAction>
          <Button variant="ghost" size="icon" className="size-8" onClick={() => { void kb.refetch() }} disabled={kb.isFetching} aria-label="Aggiorna la knowledge base">
            <RefreshCw className={cn('size-3.5', kb.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {kb.isPending ? (
          <LoadingRows rows={4} />
        ) : kb.isError ? (
          <ErrorPanel
            message={errInfo(kb.error).message}
            code={errInfo(kb.error).code}
            onRetry={() => { void kb.refetch() }}
          />
        ) : (
          <>
            {/* Ricerca + azioni */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-0 flex-1 sm:max-w-xs">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-text-2" aria-hidden />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Cerca articoli, tag, testo…"
                  className="h-9 pl-8"
                  aria-label="Cerca nella knowledge base"
                  inputMode="search"
                />
              </div>
              <div className="ml-auto flex items-center gap-2">
                <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                  <Plus className="size-3.5" aria-hidden /> Nuovo articolo
                </Button>
                <Button variant="outline" size="sm" className="h-9" onClick={() => { setTicketId(''); setTicketOpen(true) }}>
                  <TicketCheck className="size-3.5" aria-hidden /> Da ticket
                </Button>
              </div>
            </div>

            {items.length === 0 ? (
              q ? (
                <EmptyState
                  icon={<Search className="size-10" aria-hidden />}
                  title="Nessun articolo trovato"
                  description={`Nessuna corrispondenza per «${q}» nella knowledge base (${fmtNumber(total)} articoli nel DB reale). Prova un termine diverso.`}
                />
              ) : (
                <EmptyState
                  icon={<BookOpen className="size-10" aria-hidden />}
                  title="Nessun articolo in knowledge base"
                  description="La knowledge base dell'impianto è vuota: 0 articoli nel database reale. Il primo arriva da «Nuovo articolo» o da un ticket risolto."
                  action={
                    <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)}>
                      <Plus className="size-3.5" aria-hidden /> Nuovo articolo
                    </Button>
                  }
                />
              )
            ) : (
              <div
                className="max-h-[520px] space-y-3 overflow-y-auto scroll-thin pr-1"
                role="region"
                aria-label="Articoli della knowledge base, scorribile"
                tabIndex={0}
              >
                {items.map((a) => (
                  <Card key={a.id} className="relative overflow-hidden border-border/70 bg-raised/40">
                    {/* Pattern overlay: UN solo pulsante a tutta card (a11y, niente annidamenti) */}
                    <button
                      type="button"
                      onClick={() => openDetail(a)}
                      className="absolute inset-0 z-0 cursor-pointer rounded-xl focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ring"
                      aria-label={`Apri l'articolo ${a.title}`}
                    />
                    <CardContent className="relative z-10 pointer-events-none p-4">
                      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                        <p className="min-w-0 truncate text-sm font-medium" title={a.title}>{a.title}</p>
                        <span
                          className="num shrink-0 text-xs text-text-2"
                          title={`creato ${fmtDateTimeFull(a.createdAt)} · aggiornato ${fmtDateTimeFull(a.updatedAt)}`}
                        >
                          {fmtRelative(a.updatedAt)}
                        </span>
                      </div>
                      {a.tags.length > 0 ? (
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {a.tags.map((t) => (
                            <Badge key={t} variant="outline" className="border-border bg-surface font-normal text-text-2">#{t}</Badge>
                          ))}
                        </div>
                      ) : null}
                      <p className="mt-2 line-clamp-3 whitespace-pre-wrap text-xs leading-relaxed text-text-2">{a.body}</p>
                      <p className="mt-2 text-[11px] text-dim">
                        di {a.createdBy}{a.ticketId ? ' · da ticket' : ''}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
            {kb.data ? <AsOf ts={kb.data.asOf} prefix="articoli alle" className="mt-1" /> : null}
          </>
        )}
      </CardContent>

      {/* --- Dialog: nuovo articolo --- */}
      <Dialog
        open={createOpen}
        onOpenChange={(open) => {
          setCreateOpen(open)
          if (!open) resetCreateForm()
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuovo articolo</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Voce REALE della knowledge base: ciò che scrivi qui resta disponibile a
              tutti gli operatori dell&apos;impianto (update e delete possibili dal dettaglio).
            </DialogDescription>
          </DialogHeader>
          <form
            className="grid gap-3"
            onSubmit={(e) => { e.preventDefault(); submitCreate() }}
            noValidate
            aria-label="Form di creazione articolo"
          >
            <div className="grid gap-1.5">
              <label htmlFor="kb-title" className="text-xs font-medium text-text-2">Titolo *</label>
              <Input
                id="kb-title"
                value={cTitle}
                maxLength={200}
                onChange={(e) => setCTitle(e.target.value)}
                placeholder="es. Reset CCQ basso su radio AirMAX"
                aria-required="true"
              />
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="kb-body" className="text-xs font-medium text-text-2">Corpo *</label>
              <Textarea
                id="kb-body"
                value={cBody}
                maxLength={100_000}
                onChange={(e) => setCBody(e.target.value)}
                placeholder="Problema, diagnosi e soluzione passo a passo…"
                className="min-h-40"
                aria-required="true"
              />
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="kb-tags" className="text-xs font-medium text-text-2">Tag</label>
              <Input
                id="kb-tags"
                value={cTags}
                maxLength={700}
                onChange={(e) => setCTags(e.target.value)}
                placeholder="es. radio, ccq, airmax"
              />
              <p className="text-xs text-text-2">separate da virgola, max 10</p>
            </div>
          </form>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setCreateOpen(false); resetCreateForm() }}>
              Annulla
            </Button>
            <Button
              onClick={submitCreate}
              disabled={create.isPending || cTitle.trim().length === 0 || cBody.trim().length === 0}
            >
              {create.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Plus className="size-3.5" aria-hidden />}
              Crea articolo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Dialog: nuovo articolo da ticket --- */}
      <Dialog
        open={ticketOpen}
        onOpenChange={(open) => {
          setTicketOpen(open)
          if (!open) setTicketId('')
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Articolo da ticket</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              Trasforma un ticket esistente in conoscenza ripetibile: il titolo diventa
              «KB: &lt;titolo&gt;» e il corpo riporta Problema e Soluzione (se il ticket è
              stato risolto). Scelta e creazione sono azioni REALI.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-1.5">
            <label htmlFor="kb-ticket" className="text-xs font-medium text-text-2">
              Ticket (primi 10 del DB reale)
            </label>
            <Select value={ticketId} onValueChange={setTicketId}>
              <SelectTrigger
                id="kb-ticket"
                className="w-full"
                disabled={tickets.isPending || ticketList.length === 0}
                aria-label="Ticket da cui creare l'articolo"
              >
                <SelectValue
                  placeholder={tickets.isPending
                    ? 'caricamento ticket…'
                    : ticketList.length === 0 ? 'nessun ticket' : 'Scegli ticket…'}
                />
              </SelectTrigger>
              <SelectContent>
                {ticketList.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.title} · {t.status}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {tickets.isError ? (
              <p className="text-xs text-crit-text" role="alert">
                Ticket non disponibili: {errInfo(tickets.error).message}
              </p>
            ) : null}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setTicketOpen(false); setTicketId('') }}>
              Annulla
            </Button>
            <Button
              onClick={() => { if (ticketId) fromTicket.mutate(ticketId) }}
              disabled={!ticketId || fromTicket.isPending}
            >
              {fromTicket.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <TicketCheck className="size-3.5" aria-hidden />}
              Crea da ticket
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* --- Dialog: dettaglio / modifica / eliminazione articolo --- */}
      <Dialog
        open={!!detail}
        onOpenChange={(open) => {
          if (!open) { setDetail(null); resetEditForm() }
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="pr-6">{editMode ? 'Modifica articolo' : detail?.title}</DialogTitle>
            <DialogDescription className="text-left leading-relaxed">
              {detail ? (
                <span>
                  di {detail.createdBy} · creato {fmtDateTime(detail.createdAt)} · aggiornato {fmtDateTime(detail.updatedAt)}
                  {detail.ticketId ? ' · nato da ticket' : ''}
                </span>
              ) : null}
            </DialogDescription>
          </DialogHeader>

          {detail && !editMode ? (
            <>
              {detail.tags.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {detail.tags.map((t) => (
                    <Badge key={t} variant="outline" className="border-border bg-raised font-normal text-text-2">#{t}</Badge>
                  ))}
                </div>
              ) : null}
              <pre className="whitespace-pre-wrap break-words rounded-md border border-border/70 bg-raised/40 px-3 py-2.5 font-sans text-[13px] leading-relaxed">
                {detail.body}
              </pre>
            </>
          ) : null}

          {detail && editMode ? (
            <form
              className="grid gap-3"
              onSubmit={(e) => { e.preventDefault(); submitUpdate() }}
              noValidate
              aria-label="Form di modifica articolo"
            >
              <div className="grid gap-1.5">
                <label htmlFor="kb-e-title" className="text-xs font-medium text-text-2">Titolo *</label>
                <Input
                  id="kb-e-title"
                  value={eTitle}
                  maxLength={200}
                  onChange={(e) => setETitle(e.target.value)}
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="kb-e-body" className="text-xs font-medium text-text-2">Corpo *</label>
                <Textarea
                  id="kb-e-body"
                  value={eBody}
                  maxLength={100_000}
                  onChange={(e) => setEBody(e.target.value)}
                  className="min-h-40"
                  aria-required="true"
                />
              </div>
              <div className="grid gap-1.5">
                <label htmlFor="kb-e-tags" className="text-xs font-medium text-text-2">Tag</label>
                <Input
                  id="kb-e-tags"
                  value={eTags}
                  maxLength={700}
                  onChange={(e) => setETags(e.target.value)}
                  placeholder="separate da virgola"
                />
              </div>
            </form>
          ) : null}

          <DialogFooter className="sm:justify-between">
            {editMode ? (
              <>
                <Button type="button" variant="outline" onClick={() => { setETitle(detail?.title ?? ''); setEBody(detail?.body ?? ''); setETags(detail?.tags.join(', ') ?? ''); setEditMode(false) }}>
                  Annulla modifica
                </Button>
                <Button
                  onClick={submitUpdate}
                  disabled={update.isPending || eTitle.trim().length === 0 || eBody.trim().length === 0}
                >
                  {update.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Pencil className="size-3.5" aria-hidden />}
                  Salva revisione
                </Button>
              </>
            ) : (
              <>
                <AlertDialog open={deleteTarget?.id === detail?.id} onOpenChange={(o) => { if (!o) setDeleteTarget(null) }}>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="h-9 text-crit-text hover:text-crit-text"
                      onClick={() => setDeleteTarget(detail)}
                      aria-label={`Elimina l'articolo ${detail?.title ?? ''}`}
                    >
                      <Trash2 className="size-3.5" aria-hidden /> Elimina
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Eliminare «{deleteTarget?.title}»?</AlertDialogTitle>
                      <AlertDialogDescription className="text-left leading-relaxed">
                        Cancellazione REALE dal DB: l&apos;articolo non sarà più consultabile
                        dagli operatori. L&apos;azione è registrata nell&apos;audit.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
                      <AlertDialogAction
                        disabled={remove.isPending}
                        onClick={(e) => {
                          e.preventDefault() // resta aperto finché la risposta reale non arriva
                          if (!deleteTarget || remove.isPending) return
                          remove.mutate(deleteTarget.id)
                        }}
                      >
                        {remove.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                        Elimina
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button type="button" onClick={() => setEditMode(true)}>
                  <Pencil className="size-3.5" aria-hidden /> Modifica
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
