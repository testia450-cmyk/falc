/* Login (port dell'autenticazione reale: NextAuth credentials + bcrypt
 * + lockout per-account). Overlay a schermo intero sulla pagina unica. */

'use client'

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { Radio, Loader2, TriangleAlert, Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export function LoginOverlay() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [lockedFor, setLockedFor] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLockedFor(null)
    setLoading(true)
    try {
      const res = await signIn('credentials', {
        email, password, redirect: false,
      })
      if (res?.error) {
        // il provider lancia ACCOUNT_LOCKED:minuti → signIn la maschera
        setError('Credenziali non valide. Dopo 5 tentativi l\'account si blocca per 15 minuti.')
        if (res.error.includes('ACCOUNT_LOCKED')) {
          setError('Account temporaneamente bloccato (troppi tentativi). Riprova più tardi.')
        }
        if (res.error.includes('IP_THROTTLED')) {
          setError('Troppi tentativi da questo indirizzo: accesso rallentato per 5 minuti (protezione anti-spraying W6).')
        }
      } else if (res?.ok) {
        window.location.reload()
      } else {
        setError('Accesso non riuscito. Riprova.')
      }
    } catch {
      setError('Errore di rete durante l\'accesso.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Accesso a FALCO-OS">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6 shadow-2xl">
        <div className="mb-5 flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Radio className="size-5" aria-hidden />
          </div>
          <div>
            <h1 className="text-lg font-semibold leading-tight">FALCO-OS</h1>
            <p className="text-xs text-text-2">Network Operations Center · v16</p>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="login-email">Email</Label>
            <Input
              id="login-email"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="operatore@falco-os.local"
              className="h-10 bg-raised"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="login-password">Password</Label>
            <Input
              id="login-password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-10 bg-raised"
            />
          </div>

          {error ? (
            <p role="alert" className="flex items-start gap-2 rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs text-crit-text">
              <TriangleAlert className="mt-0.5 size-3.5 shrink-0" aria-hidden />
              {error}
            </p>
          ) : null}
          {lockedFor ? (
            <p className="text-xs text-warn">Riprova tra {lockedFor} minuti.</p>
          ) : null}

          <Button type="submit" className="h-10 w-full" disabled={loading || !email || !password}>
            {loading ? <Loader2 className="mr-1.5 size-4 animate-spin" aria-hidden /> : <Lock className="mr-1.5 size-4" aria-hidden />}
            Accedi
          </Button>
        </form>

        <p className="mt-4 text-center text-[11px] leading-relaxed text-text-2">
          Ambiente dimostrativo: database reale dell'impianto importato il 26/10/2026.<br />
          Credenziali demo: <span className="num">admin@falco-os.local · FalcoDemo2026!</span>
        </p>
      </div>
    </div>
  )
}
