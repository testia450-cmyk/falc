/* ================================================================
 * FALCO-OS v16 — Sezione «Impianti» (16.10.0 W8)
 * Tab della vista Amministrazione: CRUD REALE degli impianti del DB
 * (POST richiede RESPONSABILE_COMUNE, DELETE solo SUPER_ADMIN — i
 * rifiuti del server arrivano verbatim nei toast) + import punti
 * KMZ/KML in DUE FASI: «Genera anteprima» (nessuna scrittura, piano
 * con azioni/motivi/proposte) → conferma operatore → «Applica import
 * confermato» (scritture). Nessun numero inventato: tutto da
 * /api/v2/plants e /api/v2/locations/import-kmz. La radice della
 * topologia NON si gestisce qui (vista Topologia); l&apos;impianto
 * ATTIVO si sceglie nel topbar.
 * ================================================================ */

'use client'

import { useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Building2, FileSpreadsheet, FileUp, Loader2, Map, MoreVertical, Pencil, Plus, Trash2,
} from 'lucide-react'

import { EmptyState, ErrorPanel } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { api, ApiError } from '@/lib/client/api'
import type {
  CreatePlantInput, KmzApplyInput, KmzPreview, PlantRow, UpdatePlantInput,
  XlsxPreview, XlsxApplyInput,
} from '@/lib/client/api'
import { fmtDateTime, fmtNumber } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Costanti / tipi locali ---------------- */

const MAX_KMZ_BYTES = 10 * 1024 * 1024

type KmzPoint = KmzPreview['points'][number]
type KmzProposal = KmzPoint['deviceProposals'][number]

/* Azione del piano di import → badge (colore + testo, mai solo colore) */
const KMZ_ACTION_META: Record<KmzPoint['action'], { label: string; cls: string }> = {
  CREATE: { label: 'crea', cls: 'border-ok/40 bg-ok-soft font-normal text-ok' },
  UPDATE_COORDS: { label: 'aggiorna', cls: 'border-warn/40 bg-warn-soft font-normal text-warn' },
  NOOP: { label: 'invariato', cls: 'border-border bg-raised font-normal text-text-2' },
}

/* Confidenza della proposta di associazione dispositivo */
const CONFIDENCE_CLS: Record<KmzProposal['confidence'], string> = {
  ALTA: 'border-ok/40 bg-ok-soft font-normal text-ok',
  MEDIA: 'border-warn/40 bg-warn-soft font-normal text-warn',
  BASSA: 'border-border bg-raised font-normal text-text-2',
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

function fmtBytes(n: number): string {
  return n >= 1024 * 1024
    ? `${(n / 1024 / 1024).toFixed(2)} MB`
    : `${Math.max(1, Math.round(n / 1024))} KB`
}

/* ---------------- Form impianto (creazione/modifica condivisa) ---------------- */

interface PlantFormState {
  name: string
  comune: string
  address: string
  telegramChatId: string
  notes: string
  mapCenterLat: string
  mapCenterLng: string
  mapZoom: string
  pingIntervalSec: string
  outageTimerMinutes: string
  snmpCommunities: string
  isActive: boolean
}

/* Campi vuoti → undefined: il server applica i default v15 (41/14, zoom 14, ping 30 s, timer 5 min) */
const EMPTY_FORM: PlantFormState = {
  name: '',
  comune: '',
  address: '',
  telegramChatId: '',
  notes: '',
  mapCenterLat: '',
  mapCenterLng: '',
  mapZoom: '',
  pingIntervalSec: '',
  outageTimerMinutes: '',
  snmpCommunities: '',
  isActive: true,
}

function plantToForm(p: PlantRow): PlantFormState {
  return {
    name: p.name,
    comune: p.comune,
    address: p.address,
    telegramChatId: p.telegramChatId,
    notes: p.notes,
    mapCenterLat: String(p.mapCenterLat),
    mapCenterLng: String(p.mapCenterLng),
    mapZoom: String(p.mapZoom),
    pingIntervalSec: String(p.pingIntervalSec),
    outageTimerMinutes: String(p.outageTimerMinutes),
    snmpCommunities: p.snmpCommunities,
    isActive: p.isActive,
  }
}

function optNumber(v: string): number | undefined {
  const t = v.trim()
  if (t === '') return undefined
  const n = Number(t)
  return Number.isFinite(n) ? n : undefined
}

function optInt(v: string): number | undefined {
  const n = optNumber(v)
  return n === undefined ? undefined : Math.trunc(n)
}

function formToCreateInput(f: PlantFormState): CreatePlantInput {
  return {
    name: f.name.trim(),
    comune: f.comune.trim(),
    address: f.address.trim() || undefined,
    notes: f.notes.trim() || undefined,
    telegramChatId: f.telegramChatId.trim() || undefined,
    mapCenterLat: optNumber(f.mapCenterLat),
    mapCenterLng: optNumber(f.mapCenterLng),
    mapZoom: optInt(f.mapZoom),
    pingIntervalSec: optInt(f.pingIntervalSec),
    outageTimerMinutes: optInt(f.outageTimerMinutes),
    snmpCommunities: f.snmpCommunities.trim() || undefined,
    isActive: f.isActive,
  }
}

/* In PATCH le stringhe vuote PULISCONO il campo (il server diffa campo
 * per campo): indirizzo/note/telegram/SNMP svuotati vengono inviati tali. */
function formToUpdateInput(f: PlantFormState): UpdatePlantInput {
  return {
    name: f.name.trim(),
    comune: f.comune.trim(),
    address: f.address.trim(),
    notes: f.notes.trim(),
    telegramChatId: f.telegramChatId.trim(),
    mapCenterLat: optNumber(f.mapCenterLat),
    mapCenterLng: optNumber(f.mapCenterLng),
    mapZoom: optInt(f.mapZoom),
    pingIntervalSec: optInt(f.pingIntervalSec),
    outageTimerMinutes: optInt(f.outageTimerMinutes),
    snmpCommunities: f.snmpCommunities.trim(),
    isActive: f.isActive,
  }
}

/* ================================================================
 * Pannello «Impianti»
 * ================================================================ */

export function ImpiantiPanel() {
  const queryClient = useQueryClient()

  const plants = useQuery({
    queryKey: ['plants'],
    queryFn: () => api.plants(),
    staleTime: 30_000,
  })
  const items = plants.data?.data ?? []

  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<PlantRow | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<PlantRow | null>(null)
  const [kmzTarget, setKmzTarget] = useState<PlantRow | null>(null)
  const [xlsxTarget, setXlsxTarget] = useState<PlantRow | null>(null)

  /* Stato del formulario (creazione/modifica condivisa) tenuto QUI:
   * prefill onesto alla apertura (riga reale del DB in edit, vuoto in
   * create) senza effetti — pattern del pannello Utenti e permessi. */
  const [form, setForm] = useState<PlantFormState>(EMPTY_FORM)

  const openCreate = () => {
    setForm(EMPTY_FORM)
    setCreateOpen(true)
  }

  const openEdit = (p: PlantRow) => {
    setForm(plantToForm(p))
    setEditTarget(p)
  }

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['plants'] })
  }

  /* Eliminazione: 409 PLANT_NOT_EMPTY → messaggio server verbatim
   * (contiene i conteggi reali delle righe che bloccano l'atto). */
  const remove = useMutation({
    mutationFn: (p: PlantRow) => api.deletePlant(p.id),
    onSuccess: (_r, p) => {
      setDeleteTarget(null)
      toast.success('Impianto eliminato', {
        description: `${p.name}: riga Plant cancellata dal DB reale (voce di audit PLANT_DELETE).`,
      })
      invalidate()
    },
    onError: (e) => {
      const info = errInfo(e)
      const refused = e instanceof ApiError && (e.code === 'PLANT_NOT_EMPTY' || e.status === 409)
      toast.error(refused ? 'Eliminazione rifiutata' : 'Eliminazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <div className="grid min-w-0 gap-4">
      {/* Riga d'intestazione: titolo, sottotitolo onesto, azione primaria */}
      <div className="flex min-w-0 flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Building2 className="size-4 shrink-0 text-text-2" aria-hidden />
            Impianti
            {plants.data ? (
              <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
                {fmtNumber(items.length)} totali
              </Badge>
            ) : null}
          </h2>
          <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-text-2">
            Ogni impianto è a sé: rete, dispositivi, sedi, credenziali, topologia, canale Telegram e mappa KMZ.
            L&apos;impianto attivo si sceglie nel topbar; qui si gestiscono.
          </p>
        </div>
        <Button size="sm" className="h-9" onClick={openCreate}>
          <Plus className="size-3.5" aria-hidden /> Nuovo impianto
        </Button>
      </div>

      {plants.isPending ? (
        <div className="grid gap-4 md:grid-cols-2" role="status" aria-busy="true">
          <span className="sr-only">Caricamento impianti…</span>
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-72 animate-pulse rounded-xl border border-border/70 bg-raised/40" />
          ))}
        </div>
      ) : plants.isError ? (
        <ErrorPanel
          message={errInfo(plants.error).message}
          code={errInfo(plants.error).code}
          onRetry={() => { void plants.refetch() }}
        />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<Map className="size-10" aria-hidden />}
          title="Nessun impianto"
          description="Crea il primo impianto: dispositivi, sedi e topologia arrivano dopo con l'adozione e l'import KMZ."
          action={
            <Button size="sm" className="h-9" onClick={openCreate}>
              <Plus className="size-3.5" aria-hidden /> Nuovo impianto
            </Button>
          }
        />
      ) : (
        <>
          <div className="grid min-w-0 gap-4 md:grid-cols-2">
            {items.map((p) => (
              <PlantCard
                key={p.id}
                plant={p}
                onEdit={openEdit}
                onImport={setKmzTarget}
                onImportXlsx={setXlsxTarget}
                onDelete={setDeleteTarget}
              />
            ))}
          </div>
          {plants.data ? <AsOf ts={plants.data.asOf} prefix="impianti alle" /> : null}
        </>
      )}

      {/* --- Dialog: nuovo impianto --- */}
      <PlantFormDialog
        mode="create"
        target={null}
        form={form}
        onFormChange={setForm}
        open={createOpen}
        onOpenChange={setCreateOpen}
      />

      {/* --- Dialog: modifica impianto --- */}
      <PlantFormDialog
        mode="edit"
        target={editTarget}
        form={form}
        onFormChange={setForm}
        open={!!editTarget}
        onOpenChange={(o) => { if (!o) setEditTarget(null) }}
      />

      {/* --- Dialog: import punti KMZ/KML (2 fasi) --- */}
      <KmzImportDialog
        plant={kmzTarget}
        open={!!kmzTarget}
        onOpenChange={(o) => { if (!o) setKmzTarget(null) }}
      />

      {/* --- Dialog: import Excel installazione SETI (2 fasi, W11) --- */}
      <XlsxImportDialog
        plant={xlsxTarget}
        open={!!xlsxTarget}
        onOpenChange={(o) => { if (!o) setXlsxTarget(null) }}
      />

      {/* --- Conferma eliminazione (guardia server PLANT_NOT_EMPTY) --- */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o && !remove.isPending) setDeleteTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare l&apos;impianto «{deleteTarget?.name ?? ''}»?</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Atto irreversible. Un impianto con dati reali (sedi, dispositivi, collegamenti, ticket) viene
              RIFIUTATO dal server: questa è una guardia voluta. Richiede ruolo SUPER_ADMIN (403 altrimenti,
              mostrato tale e quale).
            </AlertDialogDescription>
          </AlertDialogHeader>
          {deleteTarget ? (
            <p className="break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2">
              {deleteTarget.comune} · <span className="num">{fmtNumber(deleteTarget.deviceCount)}</span> dispositivi ·{' '}
              <span className="num">{fmtNumber(deleteTarget.locationCount)}</span> sedi ·{' '}
              <span className="num">{fmtNumber(deleteTarget.ticketCount)}</span> ticket · creato{' '}
              <span className="num" title={fmtDateTime(deleteTarget.createdAt)}>{fmtDateTime(deleteTarget.createdAt)}</span>
            </p>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={remove.isPending}
              onClick={(e) => {
                e.preventDefault() // resta aperto finché la risposta reale non arriva
                if (!deleteTarget || remove.isPending) return
                remove.mutate(deleteTarget)
              }}
            >
              {remove.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina impianto
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

/* ================================================================
 * Card impianto (righe compatte: etichetta a sinistra, valore a destra)
 * ================================================================ */

function PlantCard({
  plant,
  onEdit,
  onImport,
  onImportXlsx,
  onDelete,
}: {
  plant: PlantRow
  onEdit: (p: PlantRow) => void
  onImport: (p: PlantRow) => void
  onImportXlsx: (p: PlantRow) => void
  onDelete: (p: PlantRow) => void
}) {
  return (
    <Card className="min-w-0 border-border/70 bg-surface">
      <CardHeader className="pb-3">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm leading-snug">
          <span className="min-w-0 break-words font-semibold">{plant.name}</span>
          {plant.isActive ? (
            <Badge variant="outline" className="border-ok/40 bg-ok-soft font-normal text-ok">Attivo</Badge>
          ) : (
            <Badge variant="outline" className="border-warn/40 bg-warn-soft font-normal text-warn">Disattivato</Badge>
          )}
        </CardTitle>
        <CardAction>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-8"
                aria-label={`Azioni per l'impianto ${plant.name}`}
              >
                <MoreVertical className="size-4" aria-hidden />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem className="gap-2 text-xs" onClick={() => onEdit(plant)}>
                <Pencil className="size-3.5" aria-hidden /> Modifica
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-xs" onClick={() => onImport(plant)}>
                <FileUp className="size-3.5" aria-hidden /> Importa punti KMZ/KML…
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-xs" onClick={() => onImportXlsx(plant)}>
                <FileSpreadsheet className="size-3.5" aria-hidden /> Importa Excel installazione…
              </DropdownMenuItem>
              <DropdownMenuItem variant="destructive" className="gap-2 text-xs" onClick={() => onDelete(plant)}>
                <Trash2 className="size-3.5" aria-hidden /> Elimina impianto…
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardAction>
      </CardHeader>
      <CardContent>
        <dl className="grid gap-x-6 gap-y-2 text-[13px]">
          <InfoRow label="Comune" value={plant.comune || <span className="text-text-2">—</span>} />
          <InfoRow label="Indirizzo" value={plant.address || <span className="text-text-2">—</span>} />
          <InfoRow
            label="Dispositivi"
            value={
              <span className="text-xs">
                <span className="num font-medium">{fmtNumber(plant.deviceCount)}</span>
                {plant.deviceCount === 1 ? ' dispositivo' : ' dispositivi'}
                <span className="text-text-2"> · </span>
                <span className="num font-medium">{fmtNumber(plant.locationCount)}</span>
                {plant.locationCount === 1 ? ' sede' : ' sedi'}
                <span className="text-text-2"> · </span>
                <span className="num font-medium">{fmtNumber(plant.ticketCount)}</span>
                {plant.ticketCount === 1 ? ' ticket' : ' ticket'}
              </span>
            }
          />
          <InfoRow
            label="Canale Telegram"
            value={plant.telegramChatId ? (
              <span className="num block max-w-[180px] truncate" title={plant.telegramChatId}>{plant.telegramChatId}</span>
            ) : (
              <span className="text-xs text-text-2">non configurato</span>
            )}
          />
          <InfoRow
            label="Mappa KMZ"
            value={plant.kmzFile ? (
              <Badge variant="outline" className="border-ok/40 bg-ok-soft font-normal text-ok" title={plant.kmzFile}>caricata</Badge>
            ) : (
              <Badge variant="outline" className="border-border bg-raised font-normal text-text-2">nessuna</Badge>
            )}
          />
          <InfoRow
            label="Radice topologia"
            value={plant.topologyRootHostname ? (
              <span className="block max-w-[180px] truncate" title={plant.topologyRootHostname}>{plant.topologyRootHostname}</span>
            ) : (
              <span className="text-xs text-text-2">inferita dal gateway</span>
            )}
          />
          <InfoRow
            label="Centro mappa"
            value={<span className="num text-xs">{plant.mapCenterLat.toFixed(4)}, {plant.mapCenterLng.toFixed(4)} · zoom {plant.mapZoom}</span>}
          />
          <InfoRow
            label="Monitoraggio"
            value={<span className="num text-xs">ping {plant.pingIntervalSec}s · timer interruzione {plant.outageTimerMinutes}m</span>}
          />
          <InfoRow
            label="Community SNMP"
            value={plant.snmpCommunities ? (
              <span className="block max-w-[180px] truncate text-xs" title={plant.snmpCommunities}>{plant.snmpCommunities}</span>
            ) : (
              <span className="text-text-2">—</span>
            )}
          />
        </dl>
        {plant.notes ? (
          <p className="mt-3 whitespace-pre-line break-words rounded-md bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2">
            {plant.notes}
          </p>
        ) : null}
      </CardContent>
    </Card>
  )
}

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex min-w-0 items-baseline justify-between gap-3">
      <dt className="shrink-0 text-text-2">{label}</dt>
      <dd className="min-w-0 break-words text-right">{value}</dd>
    </div>
  )
}

/* ================================================================
 * Dialog crea/modifica impianto (condivisa, mode 'create' | 'edit')
 * ================================================================ */

function PlantFormDialog({
  mode,
  target,
  form,
  onFormChange,
  open,
  onOpenChange,
}: {
  mode: 'create' | 'edit'
  target: PlantRow | null
  form: PlantFormState
  onFormChange: React.Dispatch<React.SetStateAction<PlantFormState>>
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()

  const set = <K extends keyof PlantFormState>(key: K, value: PlantFormState[K]) => {
    onFormChange((prev) => ({ ...prev, [key]: value }))
  }

  const valid = form.name.trim().length > 0 && form.comune.trim().length > 0
  const fid = mode === 'create' ? 'np' : 'mp'

  const save = useMutation({
    mutationFn: (v: { mode: 'create'; input: CreatePlantInput } | { mode: 'edit'; id: string; patch: UpdatePlantInput }) =>
      v.mode === 'create' ? api.createPlant(v.input) : api.updatePlant(v.id, v.patch),
    onSuccess: (p, v) => {
      toast.success(v.mode === 'create' ? 'Impianto creato' : 'Impianto aggiornato', { description: p.name })
      if (v.mode === 'create') onFormChange(EMPTY_FORM) // reset del formulario in create
      onOpenChange(false)
      void queryClient.invalidateQueries({ queryKey: ['plants'] })
    },
    onError: (e, v) => {
      const info = errInfo(e)
      toast.error(v.mode === 'create' ? 'Creazione non riuscita' : 'Aggiornamento non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const submit = () => {
    if (!valid || save.isPending) return
    if (mode === 'edit') {
      if (!target) return
      save.mutate({ mode: 'edit', id: target.id, patch: formToUpdateInput(form) })
    } else {
      save.mutate({ mode: 'create', input: formToCreateInput(form) })
    }
  }

  const handleOpenChange = (o: boolean) => {
    if (!o && save.isPending) return // niente chiusura a mutazione in volo
    onOpenChange(o)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? 'Nuovo impianto' : `Modifica · ${target?.name ?? ''}`}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {mode === 'create' ? (
              <>
                Creazione REALE nel DB (richiede ruolo RESPONSABILE_COMUNE o superiore): l&apos;impianto nasce
                VUOTO — dispositivi, sedi e topologia arrivano dopo con l&apos;adozione e l&apos;import KMZ.
                Canale Telegram, mappa e parametri di monitoraggio si configurano qui.
              </>
            ) : (
              <>
                Aggiornamento REALE nel DB (voce di audit PLANT_UPDATE con diff campo per campo). La radice
                della topologia si gestisce nella vista Topologia; senza modifiche effettive il server
                risponde NO_CHANGES — mostrato tale e quale.
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <form
          className="grid gap-3"
          onSubmit={(e) => { e.preventDefault(); submit() }}
          noValidate
          aria-label={mode === 'create' ? 'Form di creazione impianto' : 'Form di modifica impianto'}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-name`} className="text-xs font-medium text-text-2">Nome *</Label>
              <Input
                id={`${fid}-name`}
                value={form.name}
                maxLength={120}
                onChange={(e) => set('name', e.target.value)}
                placeholder="es. Illuminazione Villa Comunale"
                aria-required="true"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-comune`} className="text-xs font-medium text-text-2">Comune *</Label>
              <Input
                id={`${fid}-comune`}
                value={form.comune}
                maxLength={120}
                onChange={(e) => set('comune', e.target.value)}
                placeholder="es. San Giovanni"
                aria-required="true"
              />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor={`${fid}-address`} className="text-xs font-medium text-text-2">Indirizzo</Label>
            <Input
              id={`${fid}-address`}
              value={form.address}
              maxLength={300}
              onChange={(e) => set('address', e.target.value)}
              placeholder="es. Piazza Municipio 1"
            />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-telegram`} className="text-xs font-medium text-text-2">Canale Telegram</Label>
              <Input
                id={`${fid}-telegram`}
                value={form.telegramChatId}
                maxLength={100}
                onChange={(e) => set('telegramChatId', e.target.value)}
                placeholder="-1001234567890"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-snmp`} className="text-xs font-medium text-text-2">Community SNMP</Label>
              <Input
                id={`${fid}-snmp`}
                value={form.snmpCommunities}
                maxLength={300}
                onChange={(e) => set('snmpCommunities', e.target.value)}
                placeholder="public,ro-falco"
              />
              <p className="text-xs text-text-2">provate in ordine quando il dispositivo non ne ha una propria</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-lat`} className="text-xs font-medium text-text-2">Centro mappa · lat</Label>
              <Input
                id={`${fid}-lat`}
                type="number"
                step="0.0001"
                value={form.mapCenterLat}
                onChange={(e) => set('mapCenterLat', e.target.value)}
                placeholder="41"
                inputMode="decimal"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-lng`} className="text-xs font-medium text-text-2">Centro mappa · lng</Label>
              <Input
                id={`${fid}-lng`}
                type="number"
                step="0.0001"
                value={form.mapCenterLng}
                onChange={(e) => set('mapCenterLng', e.target.value)}
                placeholder="14"
                inputMode="decimal"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-zoom`} className="text-xs font-medium text-text-2">Zoom mappa</Label>
              <Input
                id={`${fid}-zoom`}
                type="number"
                min={1}
                max={20}
                value={form.mapZoom}
                onChange={(e) => set('mapZoom', e.target.value)}
                placeholder="14"
                inputMode="numeric"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-ping`} className="text-xs font-medium text-text-2">Intervallo ping (s)</Label>
              <Input
                id={`${fid}-ping`}
                type="number"
                min={5}
                max={3600}
                value={form.pingIntervalSec}
                onChange={(e) => set('pingIntervalSec', e.target.value)}
                placeholder="30"
                inputMode="numeric"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor={`${fid}-timer`} className="text-xs font-medium text-text-2">Timer interruzione (min)</Label>
              <Input
                id={`${fid}-timer`}
                type="number"
                min={1}
                max={1440}
                value={form.outageTimerMinutes}
                onChange={(e) => set('outageTimerMinutes', e.target.value)}
                placeholder="5"
                inputMode="numeric"
              />
              <p className="text-xs text-text-2">un dispositivo disconnesso diventa "interruzione" solo dopo questo tempo</p>
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor={`${fid}-notes`} className="text-xs font-medium text-text-2">Note</Label>
            <Textarea
              id={`${fid}-notes`}
              rows={3}
              maxLength={2000}
              value={form.notes}
              onChange={(e) => set('notes', e.target.value)}
              placeholder="contesto, riferimenti, responsabili…"
            />
          </div>

          <div className="flex items-center gap-2.5">
            <Switch
              id={`${fid}-active`}
              checked={form.isActive}
              onCheckedChange={(c) => set('isActive', c)}
              aria-label="Impianto attivo"
            />
            <Label htmlFor={`${fid}-active`} className="cursor-pointer text-xs font-normal text-text-2">Impianto attivo</Label>
          </div>
        </form>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => handleOpenChange(false)} disabled={save.isPending}>
            Annulla
          </Button>
          <Button type="button" onClick={submit} disabled={save.isPending || !valid}>
            {save.isPending
              ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
              : mode === 'create' ? <Plus className="size-3.5" aria-hidden /> : <Pencil className="size-3.5" aria-hidden />}
            {mode === 'create' ? 'Crea impianto' : 'Salva modifiche'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * Dialog import punti KMZ/KML — macchina a stati 'choose' → 'preview'
 * FASE 1 (anteprima): NESSUNA scrittura, piano con azioni/motivi e
 * proposte di associazione dispositivi (ipotesi, MAI pre-spuntate).
 * FASE 2 (apply): solo le righe confermate dall'operatore.
 * ================================================================ */

function KmzImportDialog({
  plant,
  open,
  onOpenChange,
}: {
  plant: PlantRow | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const fileRef = useRef<HTMLInputElement | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<KmzPreview | null>(null)
  const [included, setIncluded] = useState<Record<number, boolean>>({})
  const [proposals, setProposals] = useState<Record<number, string[]>>({})

  const reset = () => {
    setFile(null)
    setPreview(null)
    setIncluded({})
    setProposals({})
    if (fileRef.current) fileRef.current.value = ''
  }

  /* FASE 1 — anteprima (nessuna scrittura) */
  const previewMut = useMutation({
    mutationFn: (v: { plantId: string; file: File }) => api.kmzPreview(v.plantId, v.file),
    onSuccess: (data) => {
      const inc: Record<number, boolean> = {}
      for (const p of data.points) {
        // default onesto: crea/aggiorna sì; NOOP solo se porta proposte
        inc[p.placemarkIndex] = p.action !== 'NOOP' || p.deviceProposals.length > 0
      }
      setIncluded(inc)
      setProposals({}) // proposte MAI pre-spuntate: sono ipotesi
      setPreview(data)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Anteprima non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  /* FASE 2 — apply (solo le righe confermate) */
  const applyMut = useMutation({
    mutationFn: (input: KmzApplyInput) => api.kmzApply(input),
    onSuccess: (r) => {
      toast.success('Import completato', {
        description: `${r.created} punti creati · ${r.updated} coordinate aggiornate · ${r.assigned} dispositivi associati · ${r.noop} invariati${r.linksCreated ? ` · ${r.linksCreated} collegamenti dai percorsi «Linea»` : ''}`,
      })
      void queryClient.invalidateQueries({ queryKey: ['plants'] })
      void queryClient.invalidateQueries({ queryKey: ['locations'] })
      reset()
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Import non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const handleOpenChange = (o: boolean) => {
    if (!o && (previewMut.isPending || applyMut.isPending)) return
    if (!o) reset()
    onOpenChange(o)
  }

  const tooBig = file !== null && file.size > MAX_KMZ_BYTES

  const generatePreview = () => {
    if (!plant || !file || tooBig || previewMut.isPending) return
    previewMut.mutate({ plantId: plant.id, file })
  }

  const includedPoints = preview ? preview.points.filter((p) => included[p.placemarkIndex]) : []
  const checkedAssignments = preview
    ? preview.points.reduce(
      (acc, p) => acc + (included[p.placemarkIndex] ? (proposals[p.placemarkIndex] ?? []).length : 0),
      0,
    )
    : 0

  const submitApply = () => {
    if (!preview || includedPoints.length === 0 || applyMut.isPending) return
    const input: KmzApplyInput = {
      fileId: preview.fileId,
      plantId: preview.plantId,
      points: includedPoints.map((p) => {
        const ids = (proposals[p.placemarkIndex] ?? []).filter((id) =>
          p.deviceProposals.some((d) => d.deviceId === id))
        return {
          placemarkIndex: p.placemarkIndex,
          action: p.action,
          existingLocationId: p.existingLocationId ?? null,
          ...(ids.length > 0 ? { deviceIds: ids } : {}),
        }
      }),
    }
    applyMut.mutate(input)
  }

  const toggleProposal = (placemarkIndex: number, deviceId: string, checked: boolean) => {
    setProposals((prev) => {
      const cur = prev[placemarkIndex] ?? []
      return {
        ...prev,
        [placemarkIndex]: checked ? [...cur, deviceId] : cur.filter((id) => id !== deviceId),
      }
    })
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Importa punti — {plant?.name ?? ''}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {preview ? (
              <>
                Piano dal file <span className="font-medium text-foreground">{preview.fileName}</span>: nessuna
                scrittura finché non confermi. Le proposte di associazione restano ipotesi da verificare a voce.
              </>
            ) : (
              <>
                Carica la mappa KMZ (o KML) dell&apos;impianto: i placemark diventano punti di ripresa (sedi).
                L&apos;anteprima mostra IL PIANO — niente viene scritto finché non confermi. Le proposte di
                associazione dispositivi sono IPOTESI: spunta solo quelle giuste.
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        {preview ? (
          <div className="grid gap-3">
            {/* KPI del piano (dati reali della risposta, nessun calcolo locale) */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <StatBox label="Punti da creare" value={preview.created} accent="ok" />
              <StatBox label="Coordinate da aggiornare" value={preview.updated} accent="warn" />
              <StatBox label="Invariati" value={preview.noop} />
              <StatBox label="Scartati" value={preview.skipped.length} />
            </div>

            {preview.totalDevices > 0 ? (
              <p
                className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2"
                role="note"
              >
                <span className="num font-medium">{fmtNumber(preview.totalDevices)}</span> dispositivi senza punto
                reale nell&apos;impianto: <span className="num font-medium">{fmtNumber(preview.totalDevices - preview.unplacedDevices)}</span>{' '}
                hanno una proposta (spuntala solo se giusta),{' '}
                <span className="num font-medium">{fmtNumber(preview.unplacedDevices)}</span> restano da associare a mano.
              </p>
            ) : null}

            {preview.points.length === 0 ? (
              <EmptyState
                title="Nessun punto nel piano"
                description="Il file non contiene placemark utilizzabili: nessuna scrittura possibile, cambia file."
              />
            ) : (
              <div
                className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70"
                role="region"
                aria-label="Punti del piano di import, tabella scorribile"
                tabIndex={0}
              >
                <Table>
                  <TableCaption className="sr-only">
                    Piano di import: per ogni placemark, inclusione, coordinata, azione proposta (crea, aggiorna,
                    invariato), motivo e dispositivi proposti con confidenza
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col" className="w-[60px]">Includi</TableHead>
                      <TableHead scope="col" className="min-w-[170px]">Punto</TableHead>
                      <TableHead scope="col" className="min-w-[130px]">Coordinate</TableHead>
                      <TableHead scope="col" className="min-w-[90px]">Azione</TableHead>
                      <TableHead scope="col" className="min-w-[180px]">Motivo</TableHead>
                      <TableHead scope="col" className="min-w-[200px]">Dispositivi proposti</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.points.map((p) => {
                      const meta = KMZ_ACTION_META[p.action]
                      const isIncluded = included[p.placemarkIndex] ?? false
                      return (
                        <TableRow key={p.placemarkIndex}>
                          <TableCell className="align-top">
                            <Checkbox
                              checked={isIncluded}
                              onCheckedChange={(c) => setIncluded((prev) => ({ ...prev, [p.placemarkIndex]: c === true }))}
                              aria-label={`Includi il punto ${p.name} nell'import`}
                            />
                          </TableCell>
                          <TableCell className="align-top">
                            <span className="block max-w-[200px] truncate text-xs font-medium" title={p.name}>
                              {p.name || '(senza nome)'}
                            </span>
                            {p.description ? (
                              <span className="mt-0.5 block max-w-[200px] truncate text-[11px] text-text-2" title={p.description}>
                                {p.description}
                              </span>
                            ) : null}
                          </TableCell>
                          <TableCell className="align-top">
                            <span className="num text-xs">{p.lat.toFixed(5)}, {p.lng.toFixed(5)}</span>
                          </TableCell>
                          <TableCell className="align-top">
                            <Badge variant="outline" className={meta.cls}>{meta.label}</Badge>
                          </TableCell>
                          <TableCell className="align-top">
                            <span className="block max-w-[220px] text-xs leading-relaxed text-text-2" title={p.reason}>
                              {p.reason}
                            </span>
                          </TableCell>
                          <TableCell className="align-top">
                            {p.deviceProposals.length === 0 ? (
                              <span className="text-xs text-text-2">—</span>
                            ) : (
                              <div className="grid gap-1.5">
                                {p.deviceProposals.map((d) => {
                                  const cbId = `kmz-prop-${p.placemarkIndex}-${d.deviceId}`
                                  return (
                                    <div key={d.deviceId} className="flex min-w-0 items-center gap-2 text-xs" title={d.basis}>
                                      <Checkbox
                                        id={cbId}
                                        checked={(proposals[p.placemarkIndex] ?? []).includes(d.deviceId)}
                                        onCheckedChange={(c) => toggleProposal(p.placemarkIndex, d.deviceId, c === true)}
                                        disabled={!isIncluded}
                                      />
                                      <label htmlFor={cbId} className="min-w-0 cursor-pointer truncate">
                                        {d.hostname} ({d.ip})
                                      </label>
                                      <Badge variant="outline" className={cn('shrink-0', CONFIDENCE_CLS[d.confidence])}>
                                        {d.confidence}
                                      </Badge>
                                    </div>
                                  )
                                })}
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}

            {/* Placemark scartati (motivi onesti del parser) */}
            {preview.skipped.length > 0 ? (
              <details className="rounded-md border border-border/70 bg-raised/30 px-3 py-2">
                <summary className="cursor-pointer text-xs text-text-2">
                  <span className="num font-medium">{fmtNumber(preview.skipped.length)}</span> placemark scartati
                </summary>
                <ul className="mt-2 grid gap-1">
                  {preview.skipped.map((s, i) => (
                    <li key={`${s.name}-${i}`} className="text-xs leading-relaxed text-text-2">
                      <span className="font-medium text-foreground">{s.name || '(senza nome)'}</span> — {s.reason}
                    </li>
                  ))}
                </ul>
              </details>
            ) : null}

            <p className="text-xs text-text-2">
              <span className="num font-medium">{fmtNumber(includedPoints.length)}</span> di{' '}
              <span className="num font-medium">{fmtNumber(preview.points.length)}</span> punti inclusi
              {checkedAssignments > 0 ? (
                <>
                  {' '}· <span className="num font-medium">{fmtNumber(checkedAssignments)}</span> associazioni
                  dispositivi spuntate
                </>
              ) : null}
              {' '}· nessuna scrittura finché non confermi.
            </p>
          </div>
        ) : (
          <div className="grid gap-3">
            <div className="grid gap-2 rounded-lg border border-dashed border-border bg-raised/30 px-4 py-5">
              <Input
                ref={fileRef}
                type="file"
                accept=".kmz,.kml"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                aria-label="File KMZ o KML della mappa dell'impianto"
                className="cursor-pointer file:cursor-pointer"
              />
              <p className="text-center text-xs text-text-2">massimo 10 MB</p>
            </div>
            {file ? (
              <p className="flex min-w-0 flex-wrap items-baseline gap-x-2 text-xs text-text-2">
                <span className="sr-only">File selezionato:</span>
                <span className="max-w-full truncate font-medium text-foreground" title={file.name}>{file.name}</span>
                <span className="num">{fmtBytes(file.size)}</span>
              </p>
            ) : null}
            {tooBig ? (
              <p className="text-xs text-crit-text" role="alert">
                Il file supera il massimo di 10 MB: scegline uno più leggero.
              </p>
            ) : null}
          </div>
        )}

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => handleOpenChange(false)}
            disabled={previewMut.isPending || applyMut.isPending}
          >
            Annulla
          </Button>
          {preview ? (
            <Button
              type="button"
              onClick={submitApply}
              disabled={includedPoints.length === 0 || applyMut.isPending}
            >
              {applyMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FileUp className="size-3.5" aria-hidden />}
              Applica import confermato
            </Button>
          ) : (
            <Button
              type="button"
              onClick={generatePreview}
              disabled={!file || tooBig || previewMut.isPending}
            >
              {previewMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FileUp className="size-3.5" aria-hidden />}
              Genera anteprima
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Helper ---------------- */

function StatBox({ label, value, accent }: { label: string; value: number; accent?: 'ok' | 'warn' }) {
  return (
    <div className="min-w-0 rounded-md border border-border/70 bg-raised/40 px-3 py-2">
      <p className="truncate text-[11px] leading-tight text-text-2">{label}</p>
      <p className={cn('num mt-1.5 text-lg font-semibold leading-none', accent === 'ok' && 'text-ok', accent === 'warn' && 'text-warn')}>
        {fmtNumber(value)}
      </p>
    </div>
  )
}

/* ================================================================
 * 16.13 W11 — Dialog import Excel installazione SETI (2 fasi)
 * «magari posso caricare excel e kmz in modo che troviamo modo anche
 * per altri impianti di partire già avvantaggiati»:
 *   FASE 1 «Genera anteprima» → piano senza scritture (sezioni →
 *     sedi con confidenza, apparati nuovi/aggiornati, link radio dai
 *     gruppi SSID, proposte di basestation sintetica);
 *   FASE 2 «Applica import confermato» → sedi, apparati (credenziali
 *     CIFRATE lato server), topologia reale.
 * Le proposte sintetiche NON sono mai pre-spuntate (onestà KMZ).
 * ================================================================ */

const MAX_XLSX_BYTES = 15 * 1024 * 1024

type XlsxSectionRow = XlsxPreview['sections'][number]
type XlsxSyntheticRow = XlsxPreview['synthetic'][number]

const XLSX_ACTION_META: Record<XlsxSectionRow['action'], { label: string; cls: string }> = {
  CREATE: { label: 'nuova sede', cls: 'border-ok/40 bg-ok-soft font-normal text-ok' },
  MAP: { label: 'abbinata', cls: 'border-border bg-raised font-normal text-text-2' },
}

function XlsxImportDialog({
  plant,
  open,
  onOpenChange,
}: {
  plant: PlantRow | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()
  const fileRef = useRef<HTMLInputElement | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<XlsxPreview | null>(null)
  const [included, setIncluded] = useState<Record<number, boolean>>({})
  const [overrides, setOverrides] = useState<Record<number, string>>({})
  const [syntheticOn, setSyntheticOn] = useState<Record<number, boolean>>({})
  const [syntheticLoc, setSyntheticLoc] = useState<Record<number, string>>({})
  const [createLinks, setCreateLinks] = useState(true)
  const [createLanLinks, setCreateLanLinks] = useState(true)
  const [purgeAutoLinks, setPurgeAutoLinks] = useState(true)

  /* sedi dell'impianto target per il cambio di abbinamento */
  const locations = useQuery({
    queryKey: ['locations', plant?.id],
    queryFn: () => api.locations(plant?.id),
    enabled: open && !!plant,
  })

  const reset = () => {
    setFile(null)
    setPreview(null)
    setIncluded({})
    setOverrides({})
    setSyntheticOn({})
    setSyntheticLoc({})
    setCreateLinks(true)
    setCreateLanLinks(true)
    setPurgeAutoLinks(true)
    if (fileRef.current) fileRef.current.value = ''
  }

  /* FASE 1 — anteprima (nessuna scrittura) */
  const previewMut = useMutation({
    mutationFn: (v: { plantId: string; file: File }) => api.xlsxPreview(v.plantId, v.file),
    onSuccess: (data) => {
      const inc: Record<number, boolean> = {}
      for (const s of data.sections) {
        inc[s.sectionIndex] = true
      }
      setIncluded(inc)
      setOverrides({})
      setSyntheticOn({}) // proposte sintetiche MAI pre-spuntate
      setSyntheticLoc({})
      setPurgeAutoLinks(data.autoLinkCount > 0)
      setPreview(data)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Anteprima non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  /* FASE 2 — apply (solo le righe confermate) */
  const applyMut = useMutation({
    mutationFn: (input: XlsxApplyInput) => api.xlsxApply(input),
    onSuccess: (r) => {
      toast.success('Import Excel completato', {
        description: `${r.locationsCreated} sedi create · ${r.devicesCreated} apparati nuovi · ${r.devicesUpdated} aggiornati · ${r.linksCreated} collegamenti · ${r.autoLinksPurged > 0 ? `${r.autoLinksPurged} link auto-scoperti sostituiti` : 'nessuna pulizia'}`,
      })
      void queryClient.invalidateQueries({ queryKey: ['plants'] })
      void queryClient.invalidateQueries({ queryKey: ['locations'] })
      void queryClient.invalidateQueries({ queryKey: ['devices'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      reset()
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Import non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  const handleOpenChange = (o: boolean) => {
    if (!o && (previewMut.isPending || applyMut.isPending)) return
    if (!o) reset()
    onOpenChange(o)
  }

  const tooBig = file !== null && file.size > MAX_XLSX_BYTES

  const generatePreview = () => {
    if (!plant || !file || tooBig || previewMut.isPending) return
    previewMut.mutate({ plantId: plant.id, file })
  }

  const includedSections = preview ? preview.sections.filter((s) => included[s.sectionIndex]) : []

  const submitApply = () => {
    if (!preview || !plant || includedSections.length === 0 || applyMut.isPending) return
    const input: XlsxApplyInput = {
      fileId: preview.fileId,
      plantId: preview.plantId,
      sections: includedSections.map((s) => ({
        sectionIndex: s.sectionIndex,
        // l'override dell'operatore vince sul piano; altrimenti la sede
        // proposta dal piano (o la creazione se assente)
        locationId: overrides[s.sectionIndex] ?? s.locationId ?? null,
      })),
      createLinks,
      createLanLinks,
      synthetic: preview.synthetic
        .filter((_, i) => syntheticOn[i])
        .map((s, i) => ({ index: i, locationId: syntheticLoc[i] ?? s.locationId ?? null })),
      purgeAutoLinks,
    }
    applyMut.mutate(input)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto scroll-thin sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>Importa Excel installazione — {plant?.name ?? ''}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {preview ? (
              <>
                Piano dal file <span className="font-medium text-foreground">{preview.fileName}</span>
                {preview.network ? <> · rete <span className="num font-medium">{preview.network}</span></> : null}: nessuna
                scrittura finché non confermi. Le proposte di basestation sintetica restano ipotesi da verificare.
              </>
            ) : (
              <>
                Carica l&apos;Excel di installazione (formato SETI): le sezioni diventano sedi, le righe
                (IP · nome · SSID · credenziali · seriale) diventano apparati, e i gruppi SSID diventano i
                collegamenti radio della topologia reale. Un impianto nuovo parte così già avvantaggiato.
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        {preview ? (
          <div className="grid gap-3">
            {/* KPI del piano */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
              <StatBox label="Sedi da creare" value={preview.stats.locationsCreate} accent="ok" />
              <StatBox label="Sedi abbinate" value={preview.stats.locationsMap} />
              <StatBox label="Apparati nuovi" value={preview.stats.devicesCreate} accent="ok" />
              <StatBox label="Apparati aggiornati" value={preview.stats.devicesUpdate} accent="warn" />
              <StatBox label="Link radio (SSID)" value={preview.stats.links} />
            </div>

            {preview.autoLinkCount > 0 ? (
              <p
                className="rounded-md border border-warn/40 bg-warn-soft px-3 py-2 text-xs leading-relaxed text-warn"
                role="note"
              >
                L&apos;impianto ha <span className="num font-medium">{fmtNumber(preview.autoLinkCount)}</span> collegamenti
                auto-scoperti (LLDP/MNDP/UISP/inferiti). Con l&apos;opzione attiva vengono SOSTITUITI dalla topologia
                reale dell&apos;Excel; i collegamenti confermati a mano non si toccano.
              </p>
            ) : null}

            {preview.unmatchedExisting.length > 0 ? (
              <p
                className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2"
                role="note"
              >
                <span className="num font-medium">{fmtNumber(preview.unmatchedExisting.length)}</span> dispositivi
                dell&apos;impianto non sono nell&apos;Excel: restano dove sono, invariati.
              </p>
            ) : null}

            {preview.lonelySsids.length > 0 ? (
              <p
                className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2"
                role="note"
              >
                SSID con un solo apparato (nessun collegamento derivabile dall&apos;Excel):
                {' '}{preview.lonelySsids.map((l) => `${l.ssid} (${l.ip})`).join(', ')} — collegali a mano nella
                gestione collegamenti, o importa anche il KMZ con i percorsi.
              </p>
            ) : null}

            {/* Opzioni della fase 2 */}
            <div className="grid gap-2 rounded-lg border border-border/70 bg-raised/30 p-3">
              <label className="flex items-start gap-2 text-xs leading-relaxed">
                <Checkbox checked={createLinks} onCheckedChange={(c) => setCreateLinks(c === true)} className="mt-0.5" />
                <span>
                  <span className="font-medium">Crea i collegamenti radio</span> dai gruppi SSID
                  (PTP/AP ↔ stazioni, <span className="num">{fmtNumber(preview.stats.links)}</span> link confermati operatore)
                </span>
              </label>
              <label className="flex items-start gap-2 text-xs leading-relaxed">
                <Checkbox checked={createLanLinks} onCheckedChange={(c) => setCreateLanLinks(c === true)} className="mt-0.5" />
                <span>
                  <span className="font-medium">Raggruppa gli apparati di sede in LAN</span> (radio hub → SW POE →
                  telecamere: tutto entra nell&apos;albero della topologia)
                </span>
              </label>
              {preview.autoLinkCount > 0 ? (
                <label className="flex items-start gap-2 text-xs leading-relaxed">
                  <Checkbox checked={purgeAutoLinks} onCheckedChange={(c) => setPurgeAutoLinks(c === true)} className="mt-0.5" />
                  <span>
                    <span className="font-medium">Sostituisci i collegamenti auto-scoperti</span>
                    (<span className="num">{fmtNumber(preview.autoLinkCount)}</span>: hub sbagliati tipo switch con
                    decine di porte inferite)
                  </span>
                </label>
              ) : null}
            </div>

            {/* Proposte sintetiche (mai pre-spuntate) */}
            {preview.synthetic.length > 0 ? (
              <div className="rounded-lg border border-dashed border-warn/40 bg-warn-soft/40 p-3">
                <p className="mb-2 text-xs font-medium text-warn">Basestation fuori inventario (proposte)</p>
                <div className="grid gap-2">
                  {preview.synthetic.map((s, i) => (
                    <div key={`${s.name}-${i}`} className="grid gap-1.5">
                      <label className="flex items-start gap-2 text-xs leading-relaxed">
                        <Checkbox
                          checked={syntheticOn[i] ?? false}
                          onCheckedChange={(c) => setSyntheticOn((prev) => ({ ...prev, [i]: c === true }))}
                          className="mt-0.5"
                        />
                        <span>
                          <span className="font-medium">{s.name}</span> — stazioni:
                          {' '}{s.stations.map((st) => `${st.name} (${st.section})`).join(' · ')}
                          <span className="block text-[11px] text-text-2">{s.locationBasis}</span>
                        </span>
                      </label>
                      {syntheticOn[i] ? (
                        <Select
                          value={syntheticLoc[i] ?? s.locationId ?? ''}
                          onValueChange={(v) => setSyntheticLoc((prev) => ({ ...prev, [i]: v }))}
                        >
                          <SelectTrigger className="h-8 w-full max-w-[320px] text-xs" aria-label={`Sede per ${s.name}`}>
                            <SelectValue placeholder="Scegli la sede della basestation" />
                          </SelectTrigger>
                          <SelectContent>
                            {(locations.data?.data ?? []).map((l) => (
                              <SelectItem key={l.id} value={l.id} className="text-xs">{l.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {/* Tabella sezioni */}
            <div
              className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70"
              role="region"
              aria-label="Sezioni dell'Excel con abbinamento sedi, tabella scorribile"
              tabIndex={0}
            >
              <Table>
                <TableCaption className="sr-only">
                  Piano di import: per ogni sezione dell'Excel, inclusione, sede proposta o creazione,
                  confidenza del match e apparati
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col" className="w-[60px]">Includi</TableHead>
                    <TableHead scope="col" className="min-w-[180px]">Sezione Excel</TableHead>
                    <TableHead scope="col" className="min-w-[90px]">Apparati</TableHead>
                    <TableHead scope="col" className="min-w-[110px]">Azione</TableHead>
                    <TableHead scope="col" className="min-w-[220px]">Sede / motivo</TableHead>
                    <TableHead scope="col" className="min-w-[170px]">Cambia sede</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {preview.sections.map((s) => {
                    const meta = XLSX_ACTION_META[s.action]
                    const isIncluded = included[s.sectionIndex] ?? false
                    const override = overrides[s.sectionIndex]
                    return (
                      <TableRow key={s.sectionIndex}>
                        <TableCell className="align-top">
                          <Checkbox
                            checked={isIncluded}
                            onCheckedChange={(c) => setIncluded((prev) => ({ ...prev, [s.sectionIndex]: c === true }))}
                            aria-label={`Includi la sezione ${s.sectionName} nell'import`}
                          />
                        </TableCell>
                        <TableCell className="align-top">
                          <span className="block max-w-[220px] truncate text-xs font-medium" title={s.sectionName}>
                            {s.sectionName}
                          </span>
                        </TableCell>
                        <TableCell className="align-top">
                          <span className="num text-xs">{s.devices.length}</span>
                          <span className="block max-w-[140px] truncate text-[11px] text-text-2" title={s.devices.map((d) => `${d.action === 'CREATE' ? '+' : '~'} ${d.name}`).join(', ')}>
                            {s.devices.slice(0, 2).map((d) => d.name).join(', ')}{s.devices.length > 2 ? ` +${s.devices.length - 2}` : ''}
                          </span>
                        </TableCell>
                        <TableCell className="align-top">
                          <Badge variant="outline" className={meta.cls}>{meta.label}</Badge>
                        </TableCell>
                        <TableCell className="align-top">
                          {s.action === 'MAP' && s.locationName ? (
                            <>
                              <span className="block max-w-[200px] truncate text-xs font-medium" title={s.locationName}>
                                {override ? (locations.data?.data ?? []).find((l) => l.id === override)?.name ?? '—' : s.locationName}
                              </span>
                              {s.confidence ? (
                                <span className="text-[11px] text-text-2">
                                  [{s.confidence}] <span title={s.reason}>{s.reason.slice(0, 44)}{s.reason.length > 44 ? '…' : ''}</span>
                                </span>
                              ) : null}
                            </>
                          ) : (
                            <span className="block max-w-[200px] text-xs leading-relaxed text-text-2" title={s.reason}>
                              {s.reason}
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="align-top">
                          <Select
                            value={override ?? ''}
                            onValueChange={(v) => setOverrides((prev) => {
                              const next = { ...prev }
                              if (v === '__create__') delete next[s.sectionIndex]
                              else next[s.sectionIndex] = v
                              return next
                            })}
                            disabled={!isIncluded}
                          >
                            <SelectTrigger className="h-8 w-full max-w-[170px] text-xs" aria-label={`Sede per la sezione ${s.sectionName}`}>
                              <SelectValue placeholder={s.action === 'CREATE' ? 'crea sede nuova' : 'piano'} />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__create__" className="text-xs">— crea sede nuova —</SelectItem>
                              {(locations.data?.data ?? []).map((l) => (
                                <SelectItem key={l.id} value={l.id} className="text-xs">{l.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : (
          <div className="grid gap-3">
            <div className="grid gap-2">
              <Label htmlFor="xlsx-file">File Excel di installazione (.xlsx)</Label>
              <Input
                id="xlsx-file"
                ref={fileRef}
                type="file"
                accept=".xlsx"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                className="text-xs"
              />
              {file ? (
                <p className="text-xs text-text-2">
                  {file.name} · {(file.size / 1024).toFixed(0)} KB
                  {tooBig ? <span className="ml-1 font-medium text-crit">troppo grande (massimo 15 MB)</span> : null}
                </p>
              ) : (
                <p className="text-xs leading-relaxed text-text-2">
                  Formato atteso: righe di testata per la sede (es. «P1 - Via Giuseppe Mazzini», «Comando PL»)
                  seguite dalle righe apparato (IP · nome · SSID · utente · password · seriale).
                  Il foglio «Lic» e le righe di servizio vengono ignorati.
                </p>
              )}
            </div>
          </div>
        )}

        <DialogFooter className="gap-2">
          {preview ? (
            <>
              <Button variant="ghost" size="sm" onClick={reset} disabled={applyMut.isPending}>Cambia file</Button>
              <Button
                size="sm"
                onClick={submitApply}
                disabled={applyMut.isPending || includedSections.length === 0}
              >
                {applyMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FileSpreadsheet className="size-3.5" aria-hidden />}
                Applica import confermato ({includedSections.length} sezioni)
              </Button>
            </>
          ) : (
            <Button
              size="sm"
              onClick={generatePreview}
              disabled={!file || tooBig || previewMut.isPending || !plant}
            >
              {previewMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FileSpreadsheet className="size-3.5" aria-hidden />}
              Genera anteprima
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
