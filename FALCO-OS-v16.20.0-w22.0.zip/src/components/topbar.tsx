/* Topbar (mockup 1): ricerca globale (cmdk, risultati raggruppati §5),
 * campanella con badge allarmi REALI, stato live (realtime), orologio,
 * menu utente. Nessun dato statico: tutto da query/socket. */

'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useSession } from 'next-auth/react'
import { useTheme } from 'next-themes'
import { useIsHydrated } from '@/lib/client/theme-palette'
import { Sidebar } from '@/components/sidebar'
import { PlantSwitcher } from '@/components/plant-switcher'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import {
  Search, Bell, Sun, Moon, Check, HardDrive, HelpCircle, UserRound, Command, Menu, Monitor,
} from 'lucide-react'
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator,
} from '@/components/ui/command'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useApp } from '@/lib/client/store'
import { api } from '@/lib/client/api'
import { subscribeRealtime } from '@/lib/client/socket'
import { typeLabel } from '@/lib/client/format'
import { StatusBadge } from '@/components/status-badge'
import { cn } from '@/lib/utils'

export function Topbar({ onOpenSearch }: { onOpenSearch?: () => void }) {
  const { data: session } = useSession()
  const queryClient = useQueryClient()
  const navigate = useApp((s) => s.navigate)
  const openDevice = useApp((s) => s.openDevice)
  const { resolvedTheme, setTheme } = useTheme()
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [clock, setClock] = useState<string>('')
  const [realtimeUp, setRealtimeUp] = useState<boolean | null>(null)
  const searchRef = useRef(onOpenSearch)

  useEffect(() => { searchRef.current = onOpenSearch }, [onOpenSearch])

  /* Tema: valori coerenti SOLO dopo l'idratazione (il server renderizza
   * sempre scuro: default dell'app — nessun mismatch di idratazione). */
  const isLight = useIsHydrated() && resolvedTheme === 'light'

  /* Navigazione mobile: sotto lg la sidebar è nascosta → menu a sportello
   * (difetto corretto: prima nessuna navigazione tastiera/touch su mobile). */
  const [navOpen, setNavOpen] = useState(false)

  /* meta theme-color coerente col tema attivo (barra del browser) */
  useEffect(() => {
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute('content', isLight ? '#f4f7fb' : '#051224')
  }, [isLight])

  /* Orologio (client-only per evitare mismatch di idratazione) */
  useEffect(() => {
    const update = () => setClock(new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' }))
    update()
    const t = setInterval(update, 1000)
    return () => clearInterval(t)
  }, [])

  /* Realtime: badge di connessione + refetch mirato a ogni tick (nessun polling) */
  useEffect(() => {
    const dispose = subscribeRealtime({
      onConnect: () => setRealtimeUp(true),
      onDisconnect: () => setRealtimeUp(false),
      onTick: () => {
        void queryClient.invalidateQueries({ queryKey: ['noc-summary'] })
        void queryClient.invalidateQueries({ queryKey: ['devices'] })
      },
      onAlarms: () => {
        void queryClient.invalidateQueries({ queryKey: ['alarms'] })
      },
    })
    return dispose
  }, [queryClient])

  /* Allarmi aperti (badge campanella, dato reale) */
  const summary = useQuery({
    queryKey: ['noc-summary'],
    queryFn: () => api.summary(),
    refetchInterval: 120_000,
    staleTime: 60_000,
  })
  const openAlarms = summary.data?.data.alarms.open ?? 0
  const critAlarms = (summary.data?.data.alarms.bySeverity.CRITICAL ?? 0)

  /* Ricerca globale (raggruppata: dispositivi · sedi · allarmi) */
  const search = useQuery({
    queryKey: ['global-search', searchTerm],
    queryFn: () => api.search(searchTerm),
    enabled: searchOpen && searchTerm.trim().length >= 2,
    staleTime: 15_000,
  })

  const searchResults = search.data?.data

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setSearchOpen((v) => !v)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const bellTitle = useMemo(() => {
    const by = summary.data?.data.alarms.bySeverity ?? {}
    return `Allarmi aperti: ${openAlarms} (critici ${by.CRITICAL ?? 0}, alti ${by.HIGH ?? 0})`
  }, [summary.data, openAlarms])

  return (
    <header className="flex h-14 items-center gap-3 border-b border-border bg-surface/60 px-4 backdrop-blur" role="banner">
      {/* Navigazione mobile (sotto lg): sportello con le 8 voci */}
      <div className="lg:hidden">
        <Sheet open={navOpen} onOpenChange={setNavOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-9 text-text-2 hover:text-foreground"
              aria-label="Apri il menu di navigazione"
            >
              <Menu className="size-5" aria-hidden />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[260px] border-border bg-sidebar-bg p-0">
            <SheetTitle className="sr-only">Navigazione principale</SheetTitle>
            <Sidebar onNavigate={() => setNavOpen(false)} />
          </SheetContent>
        </Sheet>
      </div>

      {/* Ricerca (min-w-0+flex-1: si restringe sotto il contenuto su
       * mobile — altrimenti il gruppo azioni esce dal viewport, §regole UI) */}
      <button
        onClick={() => setSearchOpen(true)}
        className="flex h-9 min-w-0 flex-1 items-center gap-2.5 rounded-md border border-control-border/60 bg-raised px-3 text-left text-[13px] text-text-2 transition-colors hover:border-control-border md:max-w-md"
      >
        {/* niente aria-label: il testo visibile (con «…») È il nome accessibile
         * (label-content-name-mismatch WCAG 2.5.3 — audit 16.3) */}
        <Search className="size-4 shrink-0" aria-hidden />
        <span className="truncate">Cerca dispositivi, sedi, IP, MAC, allarmi…</span>
        <kbd className="ml-auto hidden items-center gap-0.5 rounded border border-border bg-surface px-1.5 py-0.5 text-[10px] text-text-2 sm:flex" aria-hidden>
          <Command className="size-2.5" />K
        </kbd>
      </button>

      <div className="ml-auto flex items-center gap-1.5">
        {/* Wallboard (16.2): modalità presentazione per monitor dedicato
         * (sala operazioni / stadio). NON è una nona voce di menu:
         * è un display raggiungibile da qui o da ?view=wallboard. */}
        <Button
          variant="ghost"
          size="icon"
          className="hidden size-9 text-text-2 hover:text-foreground sm:inline-flex"
          onClick={() => navigate('wallboard')}
          aria-label="Apri wallboard per monitor dedicato"
          title="Wallboard per monitor dedicato (sala operazioni)"
        >
          <Monitor className="size-4.5" aria-hidden />
        </Button>

        {/* Tema chiaro/scuro: toggle immediato (D7). Scelta persistita. */}
        <Button
          variant="ghost"
          size="icon"
          className="size-9 text-text-2 hover:text-foreground"
          onClick={() => setTheme(isLight ? 'dark' : 'light')}
          aria-label={isLight ? 'Passa al tema scuro' : 'Passa al tema chiaro'}
          title={isLight ? 'Passa al tema scuro' : 'Passa al tema chiaro'}
        >
          {isLight ? <Moon className="size-4.5" aria-hidden /> : <Sun className="size-4.5" aria-hidden />}
        </Button>

        {/* Live (rispetta prefers-reduced-motion: vedi globals.css).
            Stati onesti: connesso · in connessione · disconnesso. */}
        <span className={cn(
          'mr-1 hidden items-center gap-2 rounded-full border px-2.5 py-1 text-[11px] font-semibold sm:flex',
          realtimeUp === true && 'border-ok/40 bg-ok-soft text-ok',
          realtimeUp === null && 'border-border bg-raised text-text-2',
          realtimeUp === false && 'border-warn/40 bg-warn-soft text-warn',
        )} role="status" aria-live="polite">
          <span className={cn('inline-block size-1.5 rounded-full',
            realtimeUp === true && 'live-dot bg-ok',
            realtimeUp === null && 'bg-text-2',
            realtimeUp === false && 'bg-warn')} aria-hidden />
          {realtimeUp === true ? 'Live' : realtimeUp === null ? 'Connessione…' : 'Realtime disconnesso'}
        </span>

        {/* Campanella allarmi */}
        <Button
          variant="ghost"
          size="icon"
          className="relative size-9 text-text-2 hover:text-foreground"
          onClick={() => navigate('allarmi')}
          aria-label={bellTitle}
          title={bellTitle}
        >
          <Bell className="size-4.5" aria-hidden />
          {openAlarms > 0 ? (
            <Badge className="absolute -right-0.5 -top-0.5 h-4 min-w-4 rounded-full bg-crit-solid px-1 text-[10px] font-semibold text-white num" aria-hidden>
              {openAlarms > 99 ? '99+' : openAlarms}
            </Badge>
          ) : null}
        </Button>

        {/* Stato dati: modalità riproduzione (onestà) */}
        {summary.data?.mode === 'replay' ? (
          <span
            className="hidden items-center gap-1.5 rounded-md border border-info/40 bg-info-soft px-2 py-1 text-[11px] font-medium text-info md:flex"
            title={`Dati reali dell'impianto importati${summary.data.data.pipeline.lastTickAt ? ' · polling riprodotto ogni 30 s' : ''}`}
          >
            <HardDrive className="size-3.5" aria-hidden />
            Riproduzione
          </span>
        ) : null}

        {/* 16.10 W8: selettore impianto attivo (multi-impianto) */}
        <PlantSwitcher />

        <span className="num ml-1 hidden text-[13px] text-text-2 lg:block" aria-label="Ora corrente">{clock}</span>

        {/* Menu utente */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="size-9 rounded-full text-text-2 hover:text-foreground" aria-label="Menu utente">
              <UserRound className="size-4.5" aria-hidden />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuLabel>
              <p className="text-sm font-medium">{session?.user?.name ?? 'Operatore'}</p>
              <p className="text-xs font-normal text-text-2">{session?.user?.email}</p>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="text-[10px] font-semibold uppercase tracking-wider text-dim">
              Aspetto
            </DropdownMenuLabel>
            <DropdownMenuItem className="gap-2 text-xs" onClick={() => setTheme('dark')}>
              <Moon className="size-3.5" aria-hidden /> Tema scuro
              {!isLight ? <Check className="ml-auto size-3.5 text-ok" aria-hidden /> : null}
            </DropdownMenuItem>
            <DropdownMenuItem className="gap-2 text-xs" onClick={() => setTheme('light')}>
              <Sun className="size-3.5" aria-hidden /> Tema chiaro
              {isLight ? <Check className="ml-auto size-3.5 text-ok" aria-hidden /> : null}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="gap-2 text-xs text-text-2">
              <HelpCircle className="size-3.5" aria-hidden /> Guida (W2)
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Command palette */}
      <CommandDialog open={searchOpen} onOpenChange={setSearchOpen}>
        <CommandInput
          placeholder="Cerca dispositivi, sedi, IP, MAC, allarmi…"
          value={searchTerm}
          onValueChange={setSearchTerm}
        />
        <CommandList className="scroll-thin">
          {searchTerm.trim().length < 2 ? (
            <CommandEmpty>Digita almeno 2 caratteri per cercare.</CommandEmpty>
          ) : search.isLoading ? (
            <CommandEmpty>Ricerca in corso…</CommandEmpty>
          ) : !searchResults || (searchResults.devices.length === 0 && searchResults.locations.length === 0 && searchResults.alarms.length === 0) ? (
            <CommandEmpty>Nessun risultato per «{searchTerm}».</CommandEmpty>
          ) : (
            <>
              {searchResults.devices.length > 0 ? (
                <CommandGroup heading="Dispositivi">
                  {searchResults.devices.slice(0, 8).map((d) => (
                    <CommandItem
                      key={d.id}
                      value={`${d.hostname} ${d.ip} ${d.type}`}
                      onSelect={() => { setSearchOpen(false); openDevice(d.id); navigate('dispositivi') }}
                      className="gap-2"
                    >
                      <StatusBadge status={d.uiStatus} size="xs" />
                      <span className="truncate">{d.hostname}</span>
                      <span className="ml-auto truncate text-xs text-text-2 num">{d.ip} · {typeLabel(d.type)}</span>
                    </CommandItem>
                  ))}
                </CommandGroup>
              ) : null}
              {searchResults.locations.length > 0 ? (
                <>
                  <CommandSeparator />
                  <CommandGroup heading="Sedi">
                    {searchResults.locations.slice(0, 6).map((l) => (
                      <CommandItem
                        key={l.id}
                        value={l.name}
                        onSelect={() => { setSearchOpen(false); navigate('rete') }}
                        className="gap-2"
                      >
                        <span className="truncate">{l.name}</span>
                        <span className="ml-auto text-xs text-text-2 num">{l.deviceCount} dispositivi</span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              ) : null}
              {searchResults.alarms.length > 0 ? (
                <>
                  <CommandSeparator />
                  <CommandGroup heading="Allarmi">
                    {searchResults.alarms.slice(0, 5).map((a) => (
                      <CommandItem
                        key={a.id}
                        value={a.message}
                        onSelect={() => { setSearchOpen(false); navigate('allarmi') }}
                        className="gap-2"
                      >
                        <Badge variant="outline" className="shrink-0 border-crit/40 bg-crit-soft text-crit-text">{a.severity}</Badge>
                        <span className="truncate text-xs">{a.message}</span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              ) : null}
            </>
          )}
        </CommandList>
      </CommandDialog>
    </header>
  )
}
