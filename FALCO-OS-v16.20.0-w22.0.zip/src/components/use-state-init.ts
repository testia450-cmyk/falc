'use client'

import { useState } from 'react'

/* Wrapper per usare useState come init-once (idratazione URL). */
export function useStateInit<T>(fn: () => T): T {
  const [v] = useState(fn)
  return v
}
