/* Intestazione di pagina comune: breadcrumb, titolo, sottotitolo,
 * data/ora, badge Live (§3.1-3.2 dei mockup, senza i difetti). */

'use client'

import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage } from '@/components/ui/breadcrumb'
import { VIEW_LABELS, useApp } from '@/lib/client/store'
import { ReplayBadge } from '@/components/stale-indicator'
import { fmtDateTimeFull } from '@/lib/client/format'

export function PageHeader({
  title,
  subtitle,
  section,
  mode,
  importedAt,
  right,
}: {
  title: string
  subtitle?: string
  section?: string
  mode?: 'replay' | 'static'
  importedAt?: number | null
  right?: React.ReactNode
}) {
  const view = useApp((s) => s.view)
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbPage className="text-xs text-text-2">{VIEW_LABELS[view]}</BreadcrumbPage>
            </BreadcrumbItem>
            {section ? <BreadcrumbItem><span className="text-xs text-text-2">{section}</span></BreadcrumbItem> : null}
          </BreadcrumbList>
        </Breadcrumb>
        <h1 className="mt-1 text-xl font-semibold tracking-tight">{title}</h1>
        {subtitle ? <p className="mt-0.5 text-[13px] text-text-2">{subtitle}</p> : null}
        <p className="num mt-1 text-xs text-text-2">{fmtDateTimeFull(Date.now())}</p>
      </div>
      <div className="flex items-center gap-2">
        {mode ? <ReplayBadge mode={mode} importedAt={importedAt} /> : null}
        {right}
      </div>
    </div>
  )
}
