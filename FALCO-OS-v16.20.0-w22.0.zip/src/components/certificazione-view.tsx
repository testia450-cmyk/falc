/* ================================================================
 * FALCO-OS v16 — Sezione «Certificazione» (16.8 ondata W6)
 * Tab 4 della vista Amministrazione: pacchetto di certificazione
 * della console — catena audit sigillata e verificabile
 * crittograficamente, verifica on-demand con ricalcolo completo
 * degli hash, sigillo SUPER_ADMIN persistente (continua la catena
 * v15 del sealer) ed export certificato con digest SHA-256
 * nell'header x-falco-export-sha256.
 * Onestà: ogni numero arriva dalle API reali (audit/chain,
 * audit/chain/verify, audit/seal, audit/export); nessun dato
 * inventato, empty state dichiarati, esiti anche negativi.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Check, Copy, FileJson, FileSpreadsheet, Link2, Loader2, Minus,
  RefreshCw, ShieldCheck, ShieldX, Stamp, TriangleAlert,
} from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { api, ApiError } from '@/lib/client/api'
import { fmtDateTime, fmtDateTimeFull, fmtNumber } from '@/lib/client/format'
import type { AuditChainVerify, AuditSealResult } from '@/lib/v2/contracts'
import { cn } from '@/lib/utils'

/* ---------------- Helper ---------------- */

function errInfo(e: unknown): { message: string; code?: string; status?: number } {
  if (e instanceof ApiError) return { message: e.message, code: e.code, status: e.status }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* Copia negli appunti con esito onesto (toast di successo o errore) */
async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text)
    toast.success('Copiato negli appunti')
  } catch {
    toast.error('Copia non riuscita', {
      description: 'Il browser ha negato l\'accesso agli appunti: copiare manualmente dal tooltip.',
    })
  }
}

/** Hash/digest troncato con ellissi (il valore completo è nel title) */
function truncHash(h: string | null | undefined, n = 18): string {
  if (!h) return 'n.d.'
  return h.length <= n ? h : `${h.slice(0, n)}…`
}

/* ================================================================
 * Sezione Certificazione (tab 4 Amministrazione)
 * ================================================================ */

export default function CertificazioneSection() {
  return (
    <div className="min-w-0 space-y-3">
      {/* Header del tab */}
      <header className="flex flex-wrap items-start gap-3">
        <div className="min-w-0">
          <h2 className="flex flex-wrap items-center gap-2 text-base font-semibold">
            Certificazione (W6)
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2" aria-label="Onda 6 del piano di migrazione">W6</Badge>
          </h2>
          <p className="mt-1 max-w-3xl text-xs leading-relaxed text-text-2">
            Pacchetto di certificazione della console: catena audit sigillata e verificabile
            crittograficamente, export con digest SHA-256. Formula dell&apos;hash portata fedele
            dal sorgente v15.16.0.
          </p>
        </div>
      </header>

      {/* Card 1 a larghezza piena (tabella sigilli); verifica e sigillo
       * affiancate da md; export a larghezza piena (manifest). */}
      <div className="grid min-w-0 grid-cols-1 gap-3 md:grid-cols-2">
        <ChainCard className="md:col-span-2" />
        <VerifyCard />
        <SealCard />
        <ExportCard className="md:col-span-2" />
      </div>
    </div>
  )
}

/* ================================================================
 * Card 1 — Catena audit (a prova di manomissione)
 * ================================================================ */

function ChainCard({ className }: { className?: string }) {
  const chain = useQuery({
    queryKey: ['audit-chain'],
    queryFn: () => api.auditChain(),
    staleTime: 30_000,
  })

  const c = chain.data?.data
  const seals = c?.seals ?? []

  return (
    <Card className={cn('min-w-0 border-border/70 bg-surface', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <Link2 className="size-4 text-text-2" aria-hidden />
          Catena audit (a prova di manomissione)
          {c ? (
            <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
              {fmtNumber(c.seals.length)} sigilli
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Conteggi e sigilli REALI della catena audit del DB: nessun totale simulato.
        </CardDescription>
        <CardAction>
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            onClick={() => { void chain.refetch() }}
            disabled={chain.isFetching}
            aria-label="Aggiorna lo stato della catena audit"
          >
            <RefreshCw className={cn('size-3.5', chain.isFetching && 'animate-spin')} aria-hidden />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        {chain.isPending ? (
          <LoadingRows rows={4} />
        ) : chain.isError ? (
          <ErrorPanel
            message={errInfo(chain.error).message}
            code={errInfo(chain.error).code}
            onRetry={() => { void chain.refetch() }}
          />
        ) : c ? (
          <>
            {/* KPI della catena */}
            <dl className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              <Kpi label="Righe totali" value={fmtNumber(c.totalRows)} hint="righe presenti nel registro audit" />
              <Kpi label="Sigillate" value={fmtNumber(c.sealedRows)} valueCls="text-ok" hint="righe con recordHash in catena" />
              <Kpi label="Non sigillate" value={fmtNumber(c.unsealedRows)} valueCls="text-warn" hint="righe recenti non ancora chiuse in un sigillo" />
              <Kpi label="Primo seq" value={c.firstSeq != null ? fmtNumber(c.firstSeq) : 'n.d.'} hint="chainSeq della prima riga sigillata" />
              <Kpi label="Ultimo seq" value={c.lastSeq != null ? fmtNumber(c.lastSeq) : 'n.d.'} hint="chainSeq dell'ultima riga sigillata" />
              <Kpi label="Sigilli" value={fmtNumber(c.seals.length)} hint="chiusure cumulative della catena" />
            </dl>

            {/* Nota didattica */}
            <p className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2">
              Ogni riga sigillata porta SHA-256 del contenuto concatenato all&apos;hash
              precedente (contratto v12.1.0 V12-F portato fedele): modificare o cancellare
              una riga sigillata rompe la catena.
            </p>

            {/* Elenco sigilli */}
            <div>
              <p className="mb-2 text-xs font-medium text-text-2">
                Sigilli della catena ({fmtNumber(seals.length)})
              </p>
              {seals.length === 0 ? (
                <EmptyState
                  title="Nessun sigillo"
                  description="La catena audit non ha ancora sigilli: nessuna riga è stata sigillata (il sigillo è un'operazione SUPER_ADMIN, scheda a fianco)."
                />
              ) : (
                <div
                  className="max-h-64 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70"
                  role="region"
                  aria-label="Elenco dei sigilli della catena audit, scorribile con le frecce"
                  tabIndex={0}
                >
                  <Table className="min-w-[680px]">
                    <TableCaption className="sr-only">
                      Sigilli della catena audit: numero di sequenza, righe coperte, autore, data/ora, hash finale e collegamento al sigillo precedente
                    </TableCaption>
                    <TableHeader className="sticky top-0 z-10 bg-surface">
                      <TableRow className="hover:bg-transparent">
                        <TableHead scope="col" className="w-[90px]">Seq</TableHead>
                        <TableHead scope="col" className="w-[90px]">Righe</TableHead>
                        <TableHead scope="col" className="w-[160px]">Sigillato da</TableHead>
                        <TableHead scope="col" className="w-[160px]">Quando</TableHead>
                        <TableHead scope="col">Hash</TableHead>
                        <TableHead scope="col" className="w-[90px] text-center">Prev</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {seals.map((s) => (
                        <TableRow key={s.id}>
                          <TableCell className="num text-xs font-medium">{fmtNumber(s.lastSeq)}</TableCell>
                          <TableCell className="num text-xs">{fmtNumber(s.recordCount)}</TableCell>
                          <TableCell>
                            <span className="block max-w-[160px] truncate text-xs" title={s.sealedBy}>{s.sealedBy || 'n.d.'}</span>
                          </TableCell>
                          <TableCell>
                            <span className="num text-xs" title={fmtDateTimeFull(s.sealedAt)}>{fmtDateTime(s.sealedAt)}</span>
                          </TableCell>
                          <TableCell>
                            <span className="num block max-w-[240px] truncate text-xs text-text-2" title={s.lastHash}>
                              {truncHash(s.lastHash)}
                            </span>
                          </TableCell>
                          <TableCell
                            className="text-center"
                            title={s.prevSealId ?? 'Primo sigillo della catena: nessun sigillo precedente'}
                          >
                            {s.prevSealId ? (
                              <Check className="mx-auto size-3.5 text-ok" aria-hidden />
                            ) : (
                              <Minus className="mx-auto size-3.5 text-text-2" aria-hidden />
                            )}
                            <span className="sr-only">{s.prevSealId ? 'collega il sigillo precedente' : 'nessun sigillo precedente'}</span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
              {chain.data ? <AsOf ts={chain.data.asOf} className="mt-2" prefix="stato alle" /> : null}
            </div>
          </>
        ) : null}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * Card 2 — Verifica integrità (on-demand, ricalcolo completo)
 * ================================================================ */

function VerifyCard({ className }: { className?: string }) {
  /* La verifica è on-demand e costosa: l'ultimo esito vive nello
   * stato locale della sessione, NON in useQuery. */
  const [result, setResult] = useState<AuditChainVerify | null>(null)

  const chain = useQuery({
    queryKey: ['audit-chain'],
    queryFn: () => api.auditChain(),
    staleTime: 30_000,
  })
  const sealedRows = chain.data?.data?.sealedRows

  const verify = useMutation({
    mutationFn: () => api.auditChainVerify(),
    onSuccess: (res) => { setResult(res.data) },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Verifica non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card className={cn('min-w-0 border-border/70 bg-surface', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <ShieldCheck className="size-4 text-text-2" aria-hidden />
          Verifica integrità
        </CardTitle>
        <CardDescription>
          Ricalcolo crittografico on-demand di tutta la catena: l&apos;esito resta in questa
          sessione (nessun risultato precalcolato).
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button
          onClick={() => { verify.mutate() }}
          disabled={verify.isPending}
          className="h-9"
        >
          {verify.isPending
            ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden />
            : <ShieldCheck className="mr-1.5 size-3.5" aria-hidden />}
          {verify.isPending ? 'Verifica in corso…' : 'Verifica la catena (ricalcolo completo)'}
        </Button>

        <p className="text-xs text-text-2" role="note">
          La verifica ricalcola tutti gli hash: ~1-2 s
          {sealedRows != null ? ` su ${fmtNumber(sealedRows)} righe` : ' sulla catena sigillata'}.
        </p>

        {result ? (
          <div
            role="status"
            className={cn(
              'space-y-2.5 rounded-lg border px-3 py-3',
              result.verified ? 'border-ok/40 bg-ok-soft' : 'border-crit/40 bg-crit-soft',
            )}
          >
            <div className="flex flex-wrap items-center gap-2">
              <Badge
                variant="outline"
                className={cn('gap-1.5 font-medium', result.verified
                  ? 'border-ok/40 bg-ok-soft text-ok'
                  : 'border-crit/40 bg-crit-soft text-crit-text')}
              >
                {result.verified
                  ? <ShieldCheck className="size-3.5" aria-hidden />
                  : <ShieldX className="size-3.5" aria-hidden />}
                {result.verified ? 'CATENA INTEGRA' : 'CATENA ROTTA'}
              </Badge>
              <span className="text-xs">
                <span className="num font-medium">{fmtNumber(result.sealsVerified)}</span> sigilli
                verificati su <span className="num font-medium">{fmtNumber(result.sealsTotal)}</span> ·{' '}
                <span className="num font-medium">{fmtNumber(result.recordsVerified)}</span> righe
                ricalcolate in <span className="num font-medium">{fmtNumber(result.durationMs)}</span> ms
              </span>
            </div>

            <div className="flex min-w-0 flex-wrap items-center gap-1.5 text-xs">
              <span className="text-text-2">Genesis hash:</span>
              <span className="num block max-w-[220px] truncate text-text-2" title={result.genesisHash}>
                {truncHash(result.genesisHash)}
              </span>
              <CopyButton value={result.genesisHash} label="Copia il genesis hash completo" />
            </div>

            {result.unsealedCount > 0 ? (
              <p className="text-xs text-text-2">
                <span className="num font-medium text-warn">{fmtNumber(result.unsealedCount)}</span>{' '}
                righe non sigillate restano fuori dal calcolo (le più recenti).
              </p>
            ) : null}

            {!result.verified && result.breakages.length > 0 ? (
              <div className="rounded-md border border-crit/40 bg-background/60 p-2">
                <p className="text-xs font-medium text-crit-text">
                  Rotture individuate ({fmtNumber(result.breakages.length)}
                  {result.breakages.length >= 200 ? ', prime 200: tetto diagnostico del contratto' : ''})
                </p>
                <ul className="mt-1.5 max-h-48 space-y-1.5 overflow-y-auto scroll-thin pr-1" role="list">
                  {result.breakages.map((b, i) => (
                    <li key={i} className="text-xs">
                      <span className="flex flex-wrap items-baseline gap-x-2">
                        {b.seq != null ? (
                          <Badge variant="outline" className="num shrink-0 border-crit/40 bg-raised font-normal text-crit-text">
                            seq {fmtNumber(b.seq)}
                          </Badge>
                        ) : null}
                        <span className="break-words">{b.reason}</span>
                      </span>
                      {b.expected || b.actual ? (
                        <span className="num mt-0.5 block break-all text-[11px] text-text-2">
                          {b.expected ? <span className="block max-w-full truncate" title={b.expected}>expected: {truncHash(b.expected)}</span> : null}
                          {b.actual ? <span className="block max-w-full truncate" title={b.actual}>actual: {truncHash(b.actual)}</span> : null}
                        </span>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <AsOf ts={result.checkedAt} prefix="verificata alle" />
          </div>
        ) : (
          <p className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs text-text-2">
            Verifica non ancora eseguita in questa sessione: l&apos;esito (integra o rotta)
            apparirà qui dopo il ricalcolo.
          </p>
        )}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * Card 3 — Sigillo (SUPER_ADMIN, persistente)
 * ================================================================ */

function SealCard({ className }: { className?: string }) {
  const { data: session, status } = useSession()
  const queryClient = useQueryClient()

  const chain = useQuery({
    queryKey: ['audit-chain'],
    queryFn: () => api.auditChain(),
    staleTime: 30_000,
  })
  const unsealed = chain.data?.data?.unsealedRows

  const [confirmOpen, setConfirmOpen] = useState(false)
  const [lastSeal, setLastSeal] = useState<AuditSealResult | null>(null)

  const isSuperAdmin = session?.user?.role === 'SUPER_ADMIN'

  const seal = useMutation({
    mutationFn: () => api.auditSeal(),
    onSuccess: (res) => {
      setLastSeal(res)
      setConfirmOpen(false)
      toast.success('Catena sigillata', {
        description: `${fmtNumber(res.sealedRows)} righe sigillate · ${
          res.remainingUnsealed > 0
            ? `${fmtNumber(res.remainingUnsealed)} ancora non sigillate`
            : 'nessuna riga rimasta non sigillata'
        } · verifica immediata: ${res.verified ? 'integra' : 'ROTTA'}.`,
      })
      /* Il sigillo cambia stato catena e manifest: invalida entrambe */
      void queryClient.invalidateQueries({ queryKey: ['audit-chain'] })
      void queryClient.invalidateQueries({ queryKey: ['audit-export-manifest'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      setConfirmOpen(false)
      if (info.code === 'NOTHING_TO_SEAL') {
        toast.info('Tutto già sigillato', { description: info.message })
      } else if (info.code === 'FORBIDDEN' || info.status === 403) {
        toast.error('Permesso insufficiente', {
          description: `${info.message} (403: il sigillo richiede il ruolo SUPER_ADMIN).`,
        })
      } else {
        toast.error('Sigillo non riuscito', {
          description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
        })
      }
    },
  })

  return (
    <Card className={cn('min-w-0 border-border/70 bg-surface', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Stamp className="size-4 text-text-2" aria-hidden />
          Sigillo (SUPER_ADMIN)
        </CardTitle>
        <CardDescription>
          Chiude le righe non sigillate nella catena (fino a 5.000 per sigillo, più la voce
          di audit del sigillo stesso) continuando dall&apos;ultimo sigillo del sealer v15.
          Operazione persistente e reversibile solo rompendo la catena.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <dl className="grid grid-cols-2 gap-2">
          <Kpi
            label="Righe non sigillate"
            value={unsealed != null ? fmtNumber(unsealed) : 'n.d.'}
            valueCls={unsealed ? 'text-warn' : undefined}
            hint="righe audit correnti fuori da ogni sigillo (le più recenti)"
          />
          <Kpi
            label="Tetto per sigillo"
            value="5.000"
            hint="massimo di righe chiuse da un singolo sigillo, più la voce di audit del sigillo stesso (v15)"
          />
        </dl>

        {status === 'authenticated' && !isSuperAdmin ? (
          <p className="text-xs text-warn" role="note">
            Il tuo ruolo è {session?.user?.role || 'n.d.'}: il server accetta il sigillo solo da
            SUPER_ADMIN (risposta 403 altrimenti).
          </p>
        ) : null}

        <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
          <AlertDialogTrigger asChild>
            <Button disabled={seal.isPending || (unsealed != null && unsealed === 0)} className="h-9">
              <Stamp className="mr-1.5 size-3.5" aria-hidden />
              {unsealed === 0 ? 'Sigilla ora (nulla da sigillare)' : 'Sigilla ora'}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <TriangleAlert className="size-4 text-warn" aria-hidden />
                Sigillare la catena audit?
              </AlertDialogTitle>
              <AlertDialogDescription className="text-left leading-relaxed">
                Operazione persistente: le righe sigillate non potranno più essere modificate o
                cancellate senza rompere la catena (tamper-evidence). Continuare?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={seal.isPending}>Annulla</AlertDialogCancel>
              <AlertDialogAction
                disabled={seal.isPending}
                onClick={(e) => {
                  e.preventDefault() /* resta aperto finché la risposta reale non arriva */
                  if (!seal.isPending) seal.mutate()
                }}
              >
                {seal.isPending
                  ? (
                    <>
                      <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden />
                      Sigillatura in corso…
                    </>
                    )
                  : 'Sì, sigilla ora'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {lastSeal ? (
          <div className="space-y-2.5 rounded-lg border border-border/70 bg-raised/30 px-3 py-3">
            <p className="text-xs font-medium">Esito dell&apos;ultimo sigillo</p>
            <dl className="grid gap-x-8 gap-y-2 text-sm">
              <Row
                label="Sigillo"
                value={<span className="num block max-w-[220px] truncate text-xs" title={lastSeal.sealId}>{truncHash(lastSeal.sealId, 24)}</span>}
              />
              <Row label="Righe sigillate" value={<span className="num font-medium">{fmtNumber(lastSeal.sealedRows)}</span>} />
              <Row label="Ultimo seq" value={<span className="num font-medium">{fmtNumber(lastSeal.lastSeq)}</span>} />
              <Row
                label="Hash finale"
                value={(
                  <span className="flex min-w-0 items-center gap-1.5">
                    <span className="num block max-w-[220px] truncate text-xs text-text-2" title={lastSeal.lastHash}>
                      {truncHash(lastSeal.lastHash)}
                    </span>
                    <CopyButton value={lastSeal.lastHash} label="Copia l'hash finale del sigillo" />
                  </span>
                )}
              />
              <Row
                label="Rimaste non sigillate"
                value={<span className="num font-medium">{fmtNumber(lastSeal.remainingUnsealed)}</span>}
              />
              <Row
                label="Verifica immediata"
                value={(
                  <Badge
                    variant="outline"
                    className={cn('gap-1.5 font-medium', lastSeal.verified
                      ? 'border-ok/40 bg-ok-soft text-ok'
                      : 'border-crit/40 bg-crit-soft text-crit-text')}
                  >
                    {lastSeal.verified
                      ? <ShieldCheck className="size-3.5" aria-hidden />
                      : <ShieldX className="size-3.5" aria-hidden />}
                    {lastSeal.verified ? 'integra' : 'ROTTA'}
                  </Badge>
                )}
              />
              {lastSeal.skipped ? (
                <Row label="Saltato" value={<span className="font-medium text-warn">sì</span>} />
              ) : null}
            </dl>
            <p className="text-xs leading-relaxed text-text-2">{lastSeal.note}</p>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * Card 4 — Export certificato (SHA-256)
 * ================================================================ */

/** Scarica il file certificato (format=csv|json) con fetch diretto e
 * credenziali di sessione. Se l'export completo supera il tetto di
 * 50.000 righe (400 EXPORT_TOO_LARGE) riprova UNA volta con la
 * finestra temporale «ultimi 30 giorni», dichiarandolo nel toast.
 * Il digest SHA-256 del body arriva nell'header x-falco-export-sha256. */
async function downloadCertified(format: 'csv' | 'json'): Promise<void> {
  let res = await fetch(`/api/v2/audit/export?format=${format}`, { credentials: 'same-origin' })
  let narrowed = false

  if (!res.ok) {
    const errBody = (await res.json().catch(() => null)) as { error?: { code?: string; message?: string } } | null
    const code = errBody?.error?.code
    const message = errBody?.error?.message ?? 'Errore sconosciuto durante l\'export'

    if (code === 'EXPORT_TOO_LARGE') {
      /* Restringimento automatico dichiarato: from = adesso - 30 giorni */
      narrowed = true
      const from = Date.now() - 30 * 24 * 3600 * 1000
      res = await fetch(`/api/v2/audit/export?format=${format}&from=${from}`, { credentials: 'same-origin' })
      if (!res.ok) {
        const err2 = (await res.json().catch(() => null)) as { error?: { code?: string; message?: string } } | null
        throw new ApiError(err2?.error?.code ?? code ?? 'EXPORT_FAILED', err2?.error?.message ?? message, res.status)
      }
    } else {
      throw new ApiError(code ?? 'EXPORT_FAILED', message, res.status)
    }
  }

  /* Header di certificazione (il file è scaricato come blob: il nome
   * va preso da content-disposition, con fallback locale) */
  const digest = res.headers.get('x-falco-export-sha256') ?? 'n.d.'
  const rows = res.headers.get('x-falco-export-rows') ?? '0'
  const disposition = res.headers.get('content-disposition') ?? ''
  const filename = /filename="([^"]+)"/.exec(disposition)?.[1]
    ?? `falco-audit-export-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.${format}`

  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)

  const label = format === 'csv' ? 'CSV' : 'JSON'
  toast.success(
    `${label} scaricato${narrowed ? ' (ultimi 30 giorni)' : ''}: ${fmtNumber(Number(rows))} righe · SHA-256 ${truncHash(digest, 12)}`,
    {
      description: narrowed
        ? 'L\'export completo superava il tetto di 50.000 righe: riprovato automaticamente con finestra dagli ultimi 30 giorni. Digest certificato nell\'header x-falco-export-sha256 — verificabile byte-per-byte.'
        : 'Digest certificato nell\'header x-falco-export-sha256 — verificabile byte-per-byte.',
    },
  )
}

function ExportCard({ className }: { className?: string }) {
  const manifestQuery = useQuery({
    queryKey: ['audit-export-manifest'],
    queryFn: () => api.auditExport({ limit: 1 }),
    staleTime: 30_000,
  })
  const m = manifestQuery.data?.data?.manifest

  const download = useMutation({
    mutationFn: (format: 'csv' | 'json') => downloadCertified(format),
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Download non riuscito', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  return (
    <Card className={cn('min-w-0 border-border/70 bg-surface', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <FileSpreadsheet className="size-4 text-text-2" aria-hidden />
          Export certificato (SHA-256)
        </CardTitle>
        <CardDescription>
          File certificato dello storico audit: il digest SHA-256 del contenuto viaggia
          nell&apos;header x-falco-export-sha256 e resta valido byte-per-byte.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={() => { download.mutate('csv') }}
            disabled={download.isPending}
            className="h-9"
          >
            {download.isPending && download.variables === 'csv'
              ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden />
              : <FileSpreadsheet className="mr-1.5 size-3.5" aria-hidden />}
            Scarica CSV certificato
          </Button>
          <Button
            variant="outline"
            onClick={() => { download.mutate('json') }}
            disabled={download.isPending}
            className="h-9"
          >
            {download.isPending && download.variables === 'json'
              ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden />
              : <FileJson className="mr-1.5 size-3.5" aria-hidden />}
            Scarica JSON certificato
          </Button>
        </div>

        <Separator />

        {/* Manifest catena (dati reali dall'export) */}
        <div>
          <p className="mb-2 text-xs font-medium text-text-2">Manifest catena</p>
          {manifestQuery.isPending ? (
            <LoadingRows rows={3} />
          ) : manifestQuery.isError ? (
            <ErrorPanel
              message={errInfo(manifestQuery.error).message}
              code={errInfo(manifestQuery.error).code}
              onRetry={() => { void manifestQuery.refetch() }}
            />
          ) : m ? (
            <div className="space-y-2.5">
              <dl className="grid gap-x-8 gap-y-2.5 text-sm sm:grid-cols-2">
                <Row label="Righe totali" value={<span className="num font-medium">{fmtNumber(m.totalRows)}</span>} />
                <Row label="Sigillate" value={<span className="num font-medium text-ok">{fmtNumber(m.sealedRows)}</span>} />
                <Row label="Non sigillate" value={<span className="num font-medium text-warn">{fmtNumber(m.unsealedRows)}</span>} />
                <Row label="Primo seq" value={<span className="num font-medium">{m.firstSeq != null ? fmtNumber(m.firstSeq) : 'n.d.'}</span>} />
                <Row label="Ultimo seq" value={<span className="num font-medium">{m.lastSeq != null ? fmtNumber(m.lastSeq) : 'n.d.'}</span>} />
              </dl>
              <div className="grid gap-2.5 text-sm">
                <Row
                  label="chainDigest"
                  hint="SHA-256 dei recordHash di tutte le righe sigillate in ordine di chainSeq"
                  value={(
                    <span className="flex min-w-0 items-center gap-1.5">
                      <span className="num block max-w-[240px] truncate text-xs text-text-2" title={m.chainDigest ?? undefined}>
                        {truncHash(m.chainDigest)}
                      </span>
                      {m.chainDigest ? <CopyButton value={m.chainDigest} label="Copia il chainDigest completo" /> : null}
                    </span>
                  )}
                />
                <Row
                  label="exportDigest"
                  hint="SHA-256 canonico delle righe di questo export"
                  value={(
                    <span className="flex min-w-0 items-center gap-1.5">
                      <span className="num block max-w-[240px] truncate text-xs text-text-2" title={m.exportDigest}>
                        {truncHash(m.exportDigest)}
                      </span>
                      <CopyButton value={m.exportDigest} label="Copia l'exportDigest completo" />
                    </span>
                  )}
                />
              </div>
              <p className="text-xs leading-relaxed text-text-2">{m.note}</p>
              {manifestQuery.data ? <AsOf ts={manifestQuery.data.asOf} prefix="manifest alle" /> : null}
            </div>
          ) : null}
        </div>

        <p className="rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs leading-relaxed text-text-2">
          Il file esce con l&apos;header x-falco-export-sha256 = digest SHA-256 del contenuto:
          il destinatario può verificare l&apos;export byte-per-byte (contratto v15 V12-F).
        </p>
      </CardContent>
    </Card>
  )
}

/* ---------------- Micro-componenti ---------------- */

function Kpi({ label, value, hint, valueCls }: { label: string; value: React.ReactNode; hint?: string; valueCls?: string }) {
  return (
    <div className="min-w-0 rounded-md border border-border/70 bg-raised/30 px-3 py-2">
      <dt className="text-xs text-text-2" title={hint}>{label}</dt>
      <dd className={cn('num mt-0.5 text-sm font-semibold', valueCls)}>{value}</dd>
    </div>
  )
}

function Row({ label, value, hint }: { label: string; value: React.ReactNode; hint?: string }) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-3">
      <dt className="w-44 shrink-0 text-[13px] text-text-2" title={hint}>{label}</dt>
      <dd className="min-w-0 break-words">{value}</dd>
    </div>
  )
}

function CopyButton({ value, label }: { value: string; label: string }) {
  return (
    <Button
      variant="ghost"
      size="icon"
      className="size-6 shrink-0"
      aria-label={label}
      title={label}
      onClick={() => { void copyText(value) }}
    >
      <Copy className="size-3" aria-hidden />
    </Button>
  )
}
