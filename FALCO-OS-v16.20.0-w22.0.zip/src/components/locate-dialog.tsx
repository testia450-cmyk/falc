/* ================================================================
 * FALCO-OS v16.18 W20 — Dialog «Dove è collegato?»
 * ================================================================
 * Ricerca per IP, MAC o hostname → la risposta alla domanda dell'
 * operatore: «questa telecamera / questo IP — su quale switch e quale
 * porta è collegata?»
 *  · risoluzione dichiarata passo-passo (IP→ARP→MAC, MAC diretto,
 *    hostname→inventario);
 *  · avvistamenti FDB: switch · porta · ultima volta visto ·
 *    velocità/duplex del link (se noto);
 *  · link di topologia del dispositivo;
 *  · note oneste: la FDB indica dove il MAC è stato APPRESO (dietro
 *    un bridge intermedio vale la porta di uplink); nessun
 *    avvistamento = la sonda L2 non l'ha ancora imparato.
 * Componente CONTROLLATO: il padre decide open/onOpenChange; query
 * iniziale opzionale (es. il MAC della scheda apparato).
 * ================================================================ */

'use client'

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import {
  Cable, CornerDownRight, Eye, Loader2, MapPin, Network, Search, Server,
} from 'lucide-react'

import { api, ApiError } from '@/lib/client/api'
import type { LocateResult } from '@/lib/v2/contracts'
import { fmtDateTime, fmtRelative, typeLabel } from '@/lib/client/format'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'

function errMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message
  if (e instanceof Error) return e.message
  return 'Errore sconosciuto'
}

export function LocateDialog({
  open, onOpenChange, initialQuery, onOpenDevice,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Query pre-compilata (es. MAC o IP della scheda apparato). */
  initialQuery?: string
  /** Se fornito, i risultati con deviceId diventano cliccabili. */
  onOpenDevice?: (deviceId: string) => void
}) {
  const [query, setQuery] = useState('')
  const [pending, setPending] = useState(false)
  const [result, setResult] = useState<LocateResult | null>(null)

  useEffect(() => {
    if (open) {
      setQuery(initialQuery ?? '')
      setResult(null)
    }
  }, [open, initialQuery])

  const run = useCallback(async (q: string) => {
    const needle = q.trim()
    if (needle.length < 2) {
      toast.warning('Scrivi almeno 2 caratteri', { description: 'Cerca per indirizzo IP, MAC (completo) o hostname.' })
      return
    }
    setPending(true)
    try {
      const r = await api.locateDevice(needle)
      setResult(r)
      if (r.sightings.length === 0 && !r.device) {
        toast.info('Nessun riscontro', { description: 'Prova con l\'IP, il MAC completo o l\'hostname esatto.' })
      }
    } catch (e) {
      toast.error('Ricerca non riuscita', { description: errMessage(e) })
    } finally {
      setPending(false)
    }
  }, [])

  // se la finestra si apre con la query iniziale, parte subito
  useEffect(() => {
    if (open && initialQuery && initialQuery.trim().length >= 2 && !result && !pending) {
      void run(initialQuery)
    }
  }, [open, initialQuery])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] w-[min(44rem,94vw)] overflow-hidden p-0 sm:max-w-[44rem]">
        <DialogHeader className="px-5 pt-5 pb-3 sm:px-6">
          <DialogTitle className="flex items-center gap-2 text-base">
            <MapPin className="size-4 text-primary" aria-hidden /> Dove è collegato?
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed">
            Cerca un dispositivo per IP, MAC o hostname: la risposta arriva dalla tabella MAC
            (FDB) degli switch e dai link di topologia — dati REALI letti dalle sonde Layer-2.
          </DialogDescription>
        </DialogHeader>

        <div className="px-5 pb-3 sm:px-6">
          <form
            className="flex gap-2"
            onSubmit={(e) => { e.preventDefault(); void run(query) }}
          >
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-text-3" aria-hidden />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="es. 192.168.88.20 · AA:BB:CC:DD:EE:FF · CAM-1"
                className="h-11 pl-8 sm:h-9"
                autoComplete="off"
                spellCheck={false}
                aria-label="Cerca per IP, MAC o hostname"
              />
            </div>
            <Button type="submit" className="h-11 sm:h-9" disabled={pending}>
              {pending ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden /> : <Search className="mr-1.5 size-3.5" aria-hidden />}
              Cerca
            </Button>
          </form>
        </div>

        <ScrollArea className="max-h-[55vh] border-t bg-canvas/40">
          <div className="space-y-4 px-5 py-4 sm:px-6">
            {pending ? (
              <div className="space-y-2">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-10 w-3/4" />
              </div>
            ) : result ? (
              <>
                {/* --- dispositivo risolto --- */}
                {result.device ? (
                  <div className="rounded-lg border bg-raised/60 p-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Server className="size-4 text-text-3" aria-hidden />
                        <span className="text-sm font-medium">{result.device.hostname}</span>
                        <Badge variant="outline" className="text-[10px]">{typeLabel(result.device.type)}</Badge>
                      </div>
                      {onOpenDevice ? (
                        <Button variant="outline" size="sm" className="h-8" onClick={() => { onOpenDevice(result.device!.id); onOpenChange(false) }}>
                          <Eye className="mr-1 size-3" aria-hidden /> Apri scheda
                        </Button>
                      ) : null}
                    </div>
                    <dl className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-text-2">
                      <div><dt className="inline text-text-3">IP: </dt><dd className="inline num">{result.device.ip || 'n.d.'}</dd></div>
                      <div><dt className="inline text-text-3">MAC: </dt><dd className="inline num">{result.device.macAddress || 'n.d.'}</dd></div>
                      {result.device.locationName ? <div><dt className="inline text-text-3">Sede: </dt><dd className="inline">{result.device.locationName}</dd></div> : null}
                    </dl>
                  </div>
                ) : (
                  <p className="text-xs text-text-2">
                    Nessun dispositivo dell&apos;inventario corrisponde direttamente: il MAC
                    potrebbe appartenere a un apparato non ancora adottato (vedi avvistamenti).
                  </p>
                )}

                {/* --- avvistamenti FDB: LA risposta --- */}
                <section aria-label="Avvistamenti FDB">
                  <h3 className="mb-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-text-2">
                    <Network className="size-3.5" aria-hidden /> Switch · porta · ultima volta visto
                  </h3>
                  {result.sightings.length === 0 ? (
                    <p className="rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2">
                      Nessun avvistamento: la sonda Layer-2 degli switch non ha ancora imparato
                      questo MAC nella propria tabella FDB.
                    </p>
                  ) : (
                    <ul className="space-y-2">
                      {result.sightings.map((s) => (
                        <li key={`${s.switchId}-${s.portName}`} className="rounded-lg border bg-canvas p-3">
                          <div className="flex flex-wrap items-center gap-2">
                            <Cable className="size-4 text-primary" aria-hidden />
                            <button
                              type="button"
                              className="text-sm font-medium underline-offset-2 hover:underline disabled:no-underline disabled:hover:no-underline"
                              disabled={!onOpenDevice}
                              onClick={() => { if (onOpenDevice) { onOpenDevice(s.switchId); onOpenChange(false) } }}
                              title={onOpenDevice ? 'Apri la scheda dello switch' : undefined}
                            >
                              {s.switchHostname}
                            </button>
                            <CornerDownRight className="size-3.5 text-text-3" aria-hidden />
                            <span className="num rounded-md bg-raised px-2 py-0.5 text-xs font-medium">{s.portName || 'porta ?'}</span>
                            {s.speedMbps ? (
                              <span className="num text-[11px] text-text-2">
                                {s.speedMbps} Mbps{s.duplex ? ` · ${s.duplex === 'full' ? 'full-duplex' : 'half-duplex'}` : ''}
                              </span>
                            ) : null}
                          </div>
                          <p className="mt-1 text-[11px] text-text-2">
                            MAC appreso l&apos;ultima volta <span className="num">{fmtDateTime(s.lastSeenAt)}</span>
                            <span className="text-text-3"> ({fmtRelative(s.lastSeenAt)})</span>
                          </p>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>

                {/* --- link di topologia --- */}
                {result.links.length > 0 ? (
                  <section aria-label="Link di topologia">
                    <h3 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-2">Collegamenti di topologia</h3>
                    <ul className="space-y-1.5">
                      {result.links.map((l) => (
                        <li key={l.id} className="rounded-md border bg-canvas px-3 py-2 text-xs">
                          <span className="font-medium">{l.sourceHostname}</span>
                          <span className="text-text-3"> · {l.sourcePort || '?'} → </span>
                          <span className="font-medium">{l.targetHostname}</span>
                          <span className="text-text-3"> · {l.targetPort || '?'}</span>
                          <span className="ml-2 text-[10px] text-text-3">
                            {l.sourceOfTruth}{l.speedMbps ? ` · ${l.speedMbps} Mbps` : ''}{l.duplex ? ` · ${l.duplex}` : ''}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </section>
                ) : null}

                {/* --- percorso di risoluzione (onestà) --- */}
                {result.resolution.length > 0 ? (
                  <section aria-label="Percorso di risoluzione">
                    <h3 className="mb-1.5 text-xs font-medium uppercase tracking-wide text-text-2">Come è stata risolta la ricerca</h3>
                    <ol className="space-y-0.5 text-[11px] text-text-2">
                      {result.resolution.map((r, i) => (
                        <li key={i} className="flex gap-1.5">
                          <span className="num text-text-3">{i + 1}.</span>
                          <span>{r}</span>
                        </li>
                      ))}
                    </ol>
                  </section>
                ) : null}

                {/* --- note oneste --- */}
                {result.notes.length > 0 ? (
                  <p className="rounded-md bg-raised/50 px-3 py-2 text-[11px] leading-relaxed text-text-2">
                    {result.notes.join(' ')}
                  </p>
                ) : null}
              </>
            ) : (
              <p className="py-6 text-center text-xs text-text-2">
                Cerca un IP, un MAC completo o un hostname: la risposta arriva dai dati
                letti DAVVERO dalle sonde Layer-2 degli switch.
              </p>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
