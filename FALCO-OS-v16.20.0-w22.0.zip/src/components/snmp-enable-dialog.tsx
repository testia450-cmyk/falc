/* ================================================================
 * FALCO-OS v16.18 W19 — Dialog «Attivazione SNMP assistita»
 * Finestra a stati (preview → running → esito) sopra le API
 * snmpEnablePlan / snmpEnableExecute / snmpEnableVerify:
 *  · PREVIEW: la ricetta per-vendor con i comandi INTERPOLATI in
 *    chiaro — l'operatore vede PRIMA ciò che verrà eseguito (regola
 *    costituzionale: nessuna azione a sorpresa);
 *  · RUNNING: l'attuatore è in corso (SSH fino a ~15 s);
 *  · ESITO: badge di stato, esito di OGNI passo con l'output integro
 *    dell'apparato, verifica con la sonda (read-only) e riverifica.
 * Onestà: nessun dato inventato, gli stati sono quelli del contratto
 * ('' / ENABLED / ENABLED_UNVERIFIED / FAILED / MANUAL_REQUIRED);
 * le password non vengono MAI mostrate né persistite dalla finestra.
 * Componente CONTROLLATO: il padre decide open/onOpenChange e riceve
 * onDone dopo ogni cambio di stato riuscito (per invalidare le query).
 * ================================================================ */

'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import {
  AlertCircle, CheckCircle2, Globe, KeyRound, ListOrdered, Loader2, RadioTower,
  ShieldCheck, Terminal, XCircle,
} from 'lucide-react'

import { api, ApiError } from '@/lib/client/api'
import type {
  SnmpEnableInput, SnmpEnablePlanInput, SnmpEnablePlanResult, SnmpEnableResult,
  SnmpEnableState, SnmpVerifyResult,
} from '@/lib/v2/contracts'
import { ErrorPanel } from '@/components/states'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

/* ---------------- Vocabolario (token del tema, mai blu/indigo) ---------------- */

type Transport = 'ssh' | 'http-swos' | 'manual' | 'ping-only'

const TRANSPORT_LABELS: Record<Transport, string> = {
  ssh: 'SSH',
  'http-swos': 'API SwOS (HTTP)',
  manual: 'Manuale',
  'ping-only': 'Ping',
}

const RECIPE_CONFIDENCE: Record<string, { label: string; cls: string }> = {
  verified: { label: 'verificata', cls: 'bg-ok-soft text-ok border-ok/40' },
  high: { label: 'documentata', cls: 'bg-raised text-text-2 border-border' },
  medium: { label: 'da confermare', cls: 'bg-warn-soft text-warn border-warn/40' },
}

/** Chip dello stato ATTUALE del dispositivo (da inventario, in preview). */
const CURRENT_STATE_META: Record<string, { label: string; cls: string }> = {
  ENABLED: { label: 'SNMP attivo', cls: 'bg-ok-soft text-ok border-ok/40' },
  ENABLED_UNVERIFIED: { label: 'attivo non verificato', cls: 'bg-warn-soft text-warn border-warn/40' },
  FAILED: { label: 'attivazione fallita', cls: 'bg-crit-soft text-crit-text border-crit/40' },
  MANUAL_REQUIRED: { label: 'da attivare a mano', cls: 'bg-warn-soft text-warn border-warn/40' },
}

/** Badge grande dell'esito (fase RESULT). */
const RESULT_STATE_META: Record<string, { label: string; cls: string }> = {
  ENABLED: { label: 'SNMP ATTIVO e verificato', cls: 'bg-ok-soft text-ok border-ok/40' },
  ENABLED_UNVERIFIED: { label: 'Applicato, sonda non ancora in ascolto', cls: 'bg-warn-soft text-warn border-warn/40' },
  FAILED: { label: 'Attivazione non riuscita', cls: 'bg-crit-soft text-crit-text border-crit/40' },
  MANUAL_REQUIRED: { label: 'Da attivare a mano', cls: 'bg-warn-soft text-warn border-warn/40' },
}

/** Esiti umani per la scheda apparato (device-page). */
export const SNMP_STATE_LABELS: Record<string, string> = {
  '': 'mai tentata',
  ENABLED: 'attivo e verificato',
  ENABLED_UNVERIFIED: 'applicato, non verificato',
  FAILED: 'non riuscita',
  MANUAL_REQUIRED: 'da attivare a mano',
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Porta digitata → numero valido oppure undefined (mai inventata). */
function parsePort(v: string): number | undefined {
  const n = Number.parseInt(v.trim(), 10)
  return Number.isFinite(n) && n >= 1 && n <= 65535 ? n : undefined
}

/* ================================================================
 * SnmpEnableDialog — componente CONTROLLATO
 * ================================================================ */

type Phase = 'preview' | 'running' | 'result'

export function SnmpEnableDialog({
  deviceId, open, onOpenChange, onDone,
}: {
  deviceId: string
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Scatta dopo ogni cambio di stato riuscito (esito o riverifica):
   * il padre invalida le sue query — qui non si sa quali siano. */
  onDone?: () => void
}) {
  const [phase, setPhase] = useState<Phase>('preview')

  /* --- preview (ricetta) --- */
  const [plan, setPlan] = useState<SnmpEnablePlanResult | null>(null)
  const [planPending, setPlanPending] = useState(false)
  const [planError, setPlanError] = useState<unknown>(null)

  /* --- form (community/contact/location: solo ssh / http-swos) --- */
  const [community, setCommunity] = useState('public')
  const [contact, setContact] = useState('FALCO-OS')
  const [location, setLocation] = useState('')
  const formTouchedRef = useRef(false)
  const lastFormRef = useRef({ community: 'public', contact: 'FALCO-OS', location: '' })

  /* --- credenziali per trasporto --- */
  const [credMode, setCredMode] = useState<'saved' | 'other'>('saved')
  const [sshUsername, setSshUsername] = useState('')
  const [sshPassword, setSshPassword] = useState('')
  const [sshPort, setSshPort] = useState('')
  const [swosUsername, setSwosUsername] = useState('admin')
  const [swosPassword, setSwosPassword] = useState('')
  const [swosPort, setSwosPort] = useState('')

  /* --- esito / riverifica --- */
  const [result, setResult] = useState<SnmpEnableResult | null>(null)
  const [execError, setExecError] = useState<unknown>(null)
  const [verify, setVerify] = useState<SnmpVerifyResult | null>(null)
  const [verifyPending, setVerifyPending] = useState(false)
  const [verifyError, setVerifyError] = useState<unknown>(null)

  /* onDone una volta per STATO raggiunto (il ref si azzera a ogni apertura) */
  const lastDoneStateRef = useRef<string | null>(null)
  const onDoneRef = useRef(onDone)
  onDoneRef.current = onDone
  const fireDone = useCallback((state: string) => {
    if (lastDoneStateRef.current === state) return
    lastDoneStateRef.current = state
    onDoneRef.current?.()
  }, [])

  /* --- PREVIEW: lettura della ricetta (nessuna scrittura, nessun
   * contatto con l'apparato). Ripresa con override recipeId e con i
   * valori del form, così i comandi mostrati restano quelli reali. --- */
  const loadPlan = useCallback(async (opts: { recipeId?: string; community?: string; contact?: string; location?: string }) => {
    setPlanPending(true)
    setPlanError(null)
    try {
      const input: SnmpEnablePlanInput = { deviceId }
      if (opts.recipeId) input.recipeId = opts.recipeId
      if (opts.community && opts.community !== 'public') input.community = opts.community
      if (opts.contact && opts.contact !== 'FALCO-OS') input.contact = opts.contact
      if (opts.location) input.location = opts.location
      const res = await api.snmpEnablePlan(input)
      setPlan(res)
      lastFormRef.current = {
        community: opts.community ?? 'public',
        contact: opts.contact ?? 'FALCO-OS',
        location: opts.location ?? '',
      }
    } catch (e) {
      setPlanError(e)
    } finally {
      setPlanPending(false)
    }
  }, [deviceId])

  /* (ri)apertura: reset onesto di TUTTO lo stato e preview nuova */
  useEffect(() => {
    if (!open) return
    setPhase('preview')
    setPlan(null)
    setPlanError(null)
    setPlanPending(false)
    setCommunity('public')
    setContact('FALCO-OS')
    setLocation('')
    setCredMode('saved')
    setSshUsername('')
    setSshPassword('')
    setSshPort('')
    setSwosUsername('admin')
    setSwosPassword('')
    setSwosPort('')
    setResult(null)
    setExecError(null)
    setVerify(null)
    setVerifyError(null)
    setVerifyPending(false)
    formTouchedRef.current = false
    lastFormRef.current = { community: 'public', contact: 'FALCO-OS', location: '' }
    lastDoneStateRef.current = null
    void loadPlan({})
  }, [open, deviceId, loadPlan])

  /* form → preview (debounce 400 ms): ricarica la ricetta interpolata
   * con i valori correnti. Solo ssh/http-swos (gli unici con form) e
   * solo se i valori sono DIVERSI da quelli dell'ultima preview. */
  useEffect(() => {
    if (!open || phase !== 'preview' || plan == null || !formTouchedRef.current) return
    if (plan.recipe.transport !== 'ssh' && plan.recipe.transport !== 'http-swos') return
    const cur = {
      community: community.trim() || 'public',
      contact: contact.trim() || 'FALCO-OS',
      location: location.trim(),
    }
    const last = lastFormRef.current
    if (cur.community === last.community && cur.contact === last.contact && cur.location === last.location) return
    const t = window.setTimeout(() => {
      void loadPlan({ recipeId: plan.recipe.recipeId, ...cur })
    }, 400)
    return () => window.clearTimeout(t)
  }, [open, phase, plan, community, contact, location, loadPlan])

  const transport = plan?.recipe.transport as Transport | undefined

  /* --- cambio ricetta (Select delle alternative): re-fetch con
   * override esplicito + valori correnti del form --- */
  const onRecipeChange = (recipeId: string) => {
    void loadPlan({
      recipeId,
      community: community.trim() || 'public',
      contact: contact.trim() || 'FALCO-OS',
      location: location.trim(),
    })
  }

  /* --- EXECUTE: l'unico punto di contatto con l'apparato --- */
  const runExecute = async () => {
    if (!plan) return
    setPhase('running')
    setExecError(null)
    setVerify(null)
    setVerifyError(null)
    const input: SnmpEnableInput = {
      deviceId,
      recipeId: plan.recipe.recipeId,
      community: community.trim() || 'public',
      contact: contact.trim() || 'FALCO-OS',
      location: location.trim(),
    }
    if (plan.recipe.transport === 'ssh') {
      if (!(credMode === 'saved' && plan.device.hasSavedCredentials)) {
        const sshPortNum = parsePort(sshPort)
        input.ssh = {
          username: sshUsername.trim(),
          password: sshPassword,
          ...(sshPortNum != null ? { port: sshPortNum } : {}),
        }
      }
    } else if (plan.recipe.transport === 'http-swos') {
      const swosPortNum = parsePort(swosPort)
      input.swos = {
        username: swosUsername.trim() || 'admin',
        password: swosPassword,
        ...(swosPortNum != null ? { port: swosPortNum } : {}),
      }
    }
    try {
      const res = await api.snmpEnableExecute(input)
      setResult(res)
      setPhase('result')
      fireDone(res.state)
      if (res.transport === 'ping-only') {
        toast.success('Monitoraggio ping dichiarato', {
          description: 'Nessun comando inviato alla telecamera: conta solo la presenza (online/offline).',
        })
      } else if (res.state === 'ENABLED') {
        toast.success('SNMP attivo e verificato', {
          description: res.verify.sysName ? `Sonda d'accordo: sysName «${res.verify.sysName}».` : 'Sonda d\'accordo sull\'agente.',
        })
      } else if (res.state === 'ENABLED_UNVERIFIED') {
        toast.warning('Comandi applicati, sonda non ancora in ascolto', {
          description: 'L\'agente SNMP può impiegare qualche secondo a partire: premi «Riverifica ora».',
        })
      } else if (res.state === 'FAILED') {
        toast.error('Attivazione non riuscita', {
          description: 'Esito integro dei passi in finestra: nessun dato inventato.',
        })
      } else if (res.state === 'MANUAL_REQUIRED') {
        toast.warning('Da attivare a mano', {
          description: 'Nessuna automazione per questo vendor: le istruzioni restano visibili in scheda.',
        })
      }
    } catch (e) {
      setExecError(e)
      setPhase('result')
      const info = errInfo(e)
      toast.error('Attivazione non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    }
  }

  /* --- RIVERIFICA (ENABLED_UNVERIFIED → ENABLED) --- */
  const runVerify = async () => {
    setVerifyPending(true)
    setVerifyError(null)
    try {
      const res = await api.snmpEnableVerify(deviceId)
      setVerify(res)
      if (res.reachable) {
        toast.success(`SNMP raggiungibile (sysName «${res.sysName ?? 'n.d.'}»)`)
      } else {
        toast.warning('Sonda ancora muta', {
          description: res.error ?? 'L\'agente non risponde ancora: riprova tra qualche secondo.',
        })
      }
      fireDone(res.snmpEnableState)
    } catch (e) {
      setVerifyError(e)
      const info = errInfo(e)
      toast.error('Riverifica non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    } finally {
      setVerifyPending(false)
    }
  }

  const backToPreview = () => {
    setPhase('preview')
    setResult(null)
    setExecError(null)
    setVerify(null)
    setVerifyError(null)
    void loadPlan({
      recipeId: plan?.recipe.recipeId,
      community: community.trim() || 'public',
      contact: contact.trim() || 'FALCO-OS',
      location: location.trim(),
    })
  }

  /* --- abilitazione del pulsante di esecuzione per trasporto --- */
  const canRun = transport === 'ssh'
    ? (credMode === 'saved' && !!plan?.device.hasSavedCredentials)
      || (sshUsername.trim() !== '' && sshPassword !== '')
    : transport === 'http-swos'
      ? swosUsername.trim() !== ''
      : true

  const descr = plan
    ? `${plan.device.hostname} · ${plan.device.ip || 'n.d.'}`
    : 'Pianificazione della ricetta in corso…'

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Attivazione SNMP assistita</DialogTitle>
          <DialogDescription>{descr}</DialogDescription>
        </DialogHeader>

        {phase === 'preview' ? (
          <PlanPhase
            plan={plan}
            planPending={planPending}
            planError={planError}
            onRetry={() => { void loadPlan({ recipeId: plan?.recipe.recipeId }) }}
            onRecipeChange={onRecipeChange}
            community={community}
            contact={contact}
            location={location}
            setCommunity={(v) => { formTouchedRef.current = true; setCommunity(v) }}
            setContact={(v) => { formTouchedRef.current = true; setContact(v) }}
            setLocation={(v) => { formTouchedRef.current = true; setLocation(v) }}
            credMode={credMode}
            setCredMode={setCredMode}
            sshUsername={sshUsername}
            setSshUsername={setSshUsername}
            sshPassword={sshPassword}
            setSshPassword={setSshPassword}
            sshPort={sshPort}
            setSshPort={setSshPort}
            swosUsername={swosUsername}
            setSwosUsername={setSwosUsername}
            swosPassword={swosPassword}
            setSwosPassword={setSwosPassword}
            swosPort={swosPort}
            setSwosPort={setSwosPort}
            canRun={canRun}
            onRun={() => { void runExecute() }}
          />
        ) : phase === 'running' ? (
          <div className="flex flex-col items-center gap-3 rounded-lg border border-border bg-raised/30 px-4 py-10 text-center" role="status" aria-busy="true">
            <Loader2 className="size-7 animate-spin text-text-2" aria-hidden />
            <p className="text-sm font-medium">Attivazione in corso…</p>
            <p className="text-xs text-text-2">
              {transport === 'ssh' ? 'SSH fino a ~15 s: i comandi vengono eseguiti sull\'apparato.' : 'Contatto con il pannello dell\'apparato in corso.'}
            </p>
          </div>
        ) : (
          <ResultPhase
            result={result}
            execError={execError}
            verify={verify}
            verifyPending={verifyPending}
            verifyError={verifyError}
            onVerify={() => { void runVerify() }}
            onBack={backToPreview}
            onClose={() => onOpenChange(false)}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * Fase PREVIEW — ricetta, comandi in chiaro, form e credenziali
 * ================================================================ */

function PlanPhase(p: {
  plan: SnmpEnablePlanResult | null
  planPending: boolean
  planError: unknown
  onRetry: () => void
  onRecipeChange: (recipeId: string) => void
  community: string
  contact: string
  location: string
  setCommunity: (v: string) => void
  setContact: (v: string) => void
  setLocation: (v: string) => void
  credMode: 'saved' | 'other'
  setCredMode: (v: 'saved' | 'other') => void
  sshUsername: string
  setSshUsername: (v: string) => void
  sshPassword: string
  setSshPassword: (v: string) => void
  sshPort: string
  setSshPort: (v: string) => void
  swosUsername: string
  setSwosUsername: (v: string) => void
  swosPassword: string
  setSwosPassword: (v: string) => void
  swosPort: string
  setSwosPort: (v: string) => void
  canRun: boolean
  onRun: () => void
}) {
  /* primo caricamento: scheletro */
  if (!p.plan && p.planPending) {
    return (
      <div className="space-y-3" role="status" aria-busy="true">
        <span className="sr-only">Pianificazione della ricetta in corso…</span>
        <Skeleton className="h-6 w-3/4 rounded-md" />
        <Skeleton className="h-16 w-full rounded-md" />
        <Skeleton className="h-28 w-full rounded-md" />
        <Skeleton className="h-10 w-full rounded-md" />
      </div>
    )
  }

  /* errore di preview: pannello con retry (pattern ErrorPanel) */
  if (!p.plan) {
    const info = errInfo(p.planError)
    return (
      <ErrorPanel
        message={info.message}
        code={info.code}
        onRetry={p.onRetry}
      />
    )
  }

  const r = p.plan.recipe
  const dev = p.plan.device
  const conf = RECIPE_CONFIDENCE[r.confidence] ?? RECIPE_CONFIDENCE.high
  const stateChip = CURRENT_STATE_META[dev.snmpEnableState]
  const alternatives = p.plan.alternatives.some((a) => a.recipeId === r.recipeId)
    ? p.plan.alternatives
    : [{ recipeId: r.recipeId, label: `${r.vendor} ${r.family}`.trim(), transport: r.transport }, ...p.plan.alternatives]
  const isSwos = r.transport === 'http-swos'
  const isSsh = r.transport === 'ssh'

  return (
    <div className={cn('space-y-4', p.planPending && 'pointer-events-none opacity-60 transition-opacity')}>
      {/* Identità del dispositivo + stato attuale (dall'inventario) */}
      <p className="flex flex-wrap items-center gap-x-2 gap-y-1.5 text-xs">
        <span className="font-medium">{dev.hostname}</span>
        <span className="num text-text-2">· {dev.ip || 'n.d.'} · {[dev.brand, dev.model].filter(Boolean).join(' ') || 'n.d.'}</span>
        {stateChip ? (
          <Badge variant="outline" className={stateChip.cls} title={`Stato di attivazione nell'inventario: ${SNMP_STATE_LABELS[dev.snmpEnableState] ?? dev.snmpEnableState}`}>
            {stateChip.label}
          </Badge>
        ) : null}
        {dev.monitorMode === 'ping' ? (
          <Badge variant="outline" className="gap-1 border-border bg-raised text-text-2" title="presenza ICMP: online/offline, nessun valore SNMP">
            <RadioTower className="size-3" aria-hidden /> ping
          </Badge>
        ) : null}
      </p>

      {/* Scheda ricetta: vendor · famiglia · trasporto · confidenza */}
      <section aria-label="Ricetta pianificata" className="space-y-2 rounded-lg border border-border bg-raised/30 p-3">
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-sm font-medium">{r.vendor} · {r.family}</p>
          <Badge variant="outline" className="border-border bg-surface text-text-2" title="Trasporto con cui si applica la ricetta">
            {TRANSPORT_LABELS[r.transport] ?? r.transport}
          </Badge>
          <Badge variant="outline" className={conf.cls} title={`Fonte della ricetta: ${r.source}`}>
            ricetta {conf.label}
          </Badge>
        </div>
        {r.note ? <p className="text-[11px] leading-relaxed text-text-2">{r.note}</p> : null}

        {/* Alternative: tendina con override umano della ricetta */}
        {alternatives.length > 1 ? (
          <div className="space-y-1.5">
            <Label htmlFor="snmp-recipe-select" className="text-xs text-text-2">Ricetta:</Label>
            <Select value={r.recipeId} onValueChange={p.onRecipeChange}>
              <SelectTrigger id="snmp-recipe-select" size="sm" className="h-9 w-full" aria-label="Ricetta da usare per l'attivazione">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {alternatives.map((a) => (
                  <SelectItem key={a.recipeId} value={a.recipeId}>
                    {a.label} · {TRANSPORT_LABELS[a.transport] ?? a.transport}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-text-2">
              Pick automatico: <span className="font-medium text-foreground">{p.plan.picked}</span> — l&apos;override umano ha la precedenza.
            </p>
          </div>
        ) : null}

        {r.webPath ? (
          <p className="flex items-start gap-1.5 text-[11px] text-text-2">
            <Globe className="mt-0.5 size-3.5 shrink-0" aria-hidden />
            <span>Percorso web: <span className="font-medium text-foreground">{r.webPath}</span></span>
          </p>
        ) : null}
      </section>

      {/* Comandi che verranno eseguiti — IN CHIARO, prima della conferma */}
      {r.steps.length > 0 ? (
        <section aria-label="Comandi che verranno eseguiti sull'apparato" className="space-y-2">
          <h4 className="flex items-center gap-1.5 text-xs font-semibold">
            <Terminal className="size-3.5 text-text-2" aria-hidden />
            Comandi che verranno eseguiti sull&apos;apparato:
          </h4>
          <ol className="max-h-64 space-y-2 overflow-y-auto scroll-thin rounded-lg border border-border p-2">
            {r.steps.map((s, i) => (
              <li key={i} className="space-y-1 rounded-md bg-raised/40 p-2">
                <p className="font-mono text-xs break-all leading-relaxed">{s.cmd}</p>
                {s.note ? <p className="text-[11px] leading-relaxed text-text-2">{s.note}</p> : null}
                {s.benign ? (
                  <p className="text-[10px] text-text-2" title={`Pattern tollerato: ${s.benign}`}>
                    esito benigno tollerato
                  </p>
                ) : null}
              </li>
            ))}
          </ol>
        </section>
      ) : null}

      {/* Istruzioni manuali (mai eseguite da FALCO-OS) */}
      {r.manualSteps.length > 0 ? (
        <section aria-label="Istruzioni manuali" className="space-y-2">
          <h4 className="flex items-center gap-1.5 text-xs font-semibold">
            <ListOrdered className="size-3.5 text-text-2" aria-hidden />
            Istruzioni manuali (mai eseguite da FALCO-OS):
          </h4>
          <ol className="list-decimal space-y-1 rounded-lg border border-border bg-raised/30 p-3 pl-8 text-xs leading-relaxed">
            {r.manualSteps.map((m, i) => <li key={i}>{m}</li>)}
          </ol>
        </section>
      ) : null}

      {/* Form + credenziali: solo per i trasporti che contattano l'apparato */}
      {isSsh || isSwos ? (
        <section aria-label="Parametri e credenziali" className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label htmlFor="snmp-community" className="text-xs">Community</Label>
              <Input
                id="snmp-community"
                value={p.community}
                onChange={(e) => p.setCommunity(e.target.value)}
                className="h-9"
                autoComplete="off"
                maxLength={64}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="snmp-contact" className="text-xs">Contact</Label>
              <Input
                id="snmp-contact"
                value={p.contact}
                onChange={(e) => p.setContact(e.target.value)}
                className="h-9"
                autoComplete="off"
                maxLength={64}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="snmp-location" className="text-xs">Location</Label>
              <Input
                id="snmp-location"
                value={p.location}
                onChange={(e) => p.setLocation(e.target.value)}
                className="h-9"
                autoComplete="off"
                maxLength={64}
              />
            </div>
          </div>
          <p className="text-[11px] text-text-2">
            Community di lettura scritta sull&apos;apparato (cifrata su FALCO-OS dopo l&apos;esito).
          </p>

          {/* --- SSH: salvate (decifrate solo lato server) o altre --- */}
          {isSsh ? (
            <div className="space-y-2.5">
              <h4 className="flex items-center gap-1.5 text-xs font-semibold">
                <KeyRound className="size-3.5 text-text-2" aria-hidden /> Credenziali SSH
              </h4>
              {dev.hasSavedCredentials ? (
                <RadioGroup
                  value={p.credMode}
                  onValueChange={(v) => p.setCredMode(v === 'other' ? 'other' : 'saved')}
                  className="gap-2"
                  aria-label="Credenziali SSH da usare"
                >
                  <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-raised p-3 transition-colors has-[button[data-state=checked]]:border-primary">
                    <RadioGroupItem value="saved" className="mt-0.5" />
                    <span className="grid gap-0.5">
                      <span className="text-xs font-medium">
                        Usa le credenziali salvate (utente: {dev.savedUsername || 'n.d.'}…)
                      </span>
                      <span className="text-[11px] leading-snug text-text-2">
                        Password cifrata sul server: decifrata solo per l&apos;esecuzione, mai mostrata.
                      </span>
                    </span>
                  </label>
                  <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-raised p-3 transition-colors has-[button[data-state=checked]]:border-primary">
                    <RadioGroupItem value="other" className="mt-0.5" />
                    <span className="grid gap-0.5">
                      <span className="text-xs font-medium">Altre credenziali</span>
                      <span className="text-[11px] leading-snug text-text-2">Usate per questa sola esecuzione: non vengono persistite.</span>
                    </span>
                  </label>
                </RadioGroup>
              ) : null}
              {p.credMode === 'other' || !dev.hasSavedCredentials ? (
                <div className="grid gap-3 rounded-lg border border-border bg-raised/30 p-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="snmp-ssh-user" className="text-xs">Utente SSH</Label>
                    <Input
                      id="snmp-ssh-user"
                      value={p.sshUsername}
                      onChange={(e) => p.setSshUsername(e.target.value)}
                      className="h-9"
                      autoComplete="off"
                      maxLength={64}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="snmp-ssh-pass" className="text-xs">Password</Label>
                    <Input
                      id="snmp-ssh-pass"
                      type="password"
                      value={p.sshPassword}
                      onChange={(e) => p.setSshPassword(e.target.value)}
                      className="h-9"
                      autoComplete="new-password"
                      maxLength={128}
                    />
                  </div>
                  <div className="space-y-1.5 sm:col-span-2">
                    <Label htmlFor="snmp-ssh-port" className="text-xs">Porta (opzionale)</Label>
                    <Input
                      id="snmp-ssh-port"
                      inputMode="numeric"
                      value={p.sshPort}
                      onChange={(e) => p.setSshPort(e.target.value)}
                      placeholder="porta SSH (default 22)"
                      className="h-9 sm:w-56"
                      autoComplete="off"
                      maxLength={5}
                    />
                  </div>
                </div>
              ) : null}
            </div>
          ) : null}

          {/* --- SwOS: pannello web (digest), password vuota = default tipico --- */}
          {isSwos ? (
            <div className="space-y-2.5">
              <h4 className="flex items-center gap-1.5 text-xs font-semibold">
                <KeyRound className="size-3.5 text-text-2" aria-hidden /> Credenziali pannello SwOS
              </h4>
              <div className="grid gap-3 rounded-lg border border-border bg-raised/30 p-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="snmp-swos-user" className="text-xs">Utente</Label>
                  <Input
                    id="snmp-swos-user"
                    value={p.swosUsername}
                    onChange={(e) => p.setSwosUsername(e.target.value)}
                    className="h-9"
                    autoComplete="off"
                    maxLength={64}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="snmp-swos-pass" className="text-xs">Password</Label>
                  <Input
                    id="snmp-swos-pass"
                    type="password"
                    value={p.swosPassword}
                    onChange={(e) => p.setSwosPassword(e.target.value)}
                    className="h-9"
                    autoComplete="new-password"
                    maxLength={128}
                  />
                  <p className="text-[11px] text-text-2">su SwOS la password vuota è il default tipico</p>
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="snmp-swos-port" className="text-xs">Porta (opzionale)</Label>
                  <Input
                    id="snmp-swos-port"
                    inputMode="numeric"
                    value={p.swosPort}
                    onChange={(e) => p.setSwosPort(e.target.value)}
                    placeholder="porta del pannello web"
                    className="h-9 sm:w-56"
                    autoComplete="off"
                    maxLength={5}
                  />
                  <p className="text-[11px] text-text-2">porta del pannello web (default: porta di gestione dell&apos;apparato)</p>
                </div>
              </div>
            </div>
          ) : null}
        </section>
      ) : null}

      {/* Azione per trasporto + avviso esplicito del contatto */}
      <div className="space-y-2">
        {isSsh || isSwos ? (
          <>
            <Button className="min-h-11 w-full sm:h-10 sm:w-auto" disabled={!p.canRun} onClick={p.onRun}>
              Esegui attivazione
            </Button>
            <p className="text-[11px] leading-relaxed text-text-2">
              I comandi verranno inviati all&apos;apparato <span className="num font-medium text-foreground">{dev.ip || 'n.d.'}</span> dopo questo click — la conferma è esplicita.
            </p>
          </>
        ) : r.transport === 'manual' ? (
          <>
            <Button variant="outline" className="min-h-11 w-full sm:h-10 sm:w-auto" onClick={p.onRun}>
              Segna come manuale
            </Button>
            <p className="text-[11px] leading-relaxed text-text-2">
              Nessun comando verrà inviato: lo stato diventa «da attivare a mano» e le istruzioni restano visibili in scheda.
            </p>
          </>
        ) : (
          <>
            <Button className="min-h-11 w-full sm:h-10 sm:w-auto" onClick={p.onRun}>
              Dichiara monitoraggio ping
            </Button>
            <p className="text-[11px] leading-relaxed text-text-2">
              Nessun comando verrà inviato: la telecamera viene monitorata solo online/offline (presenza).
            </p>
          </>
        )}
      </div>

      {/* Banner onestà: preview read-only, l'attuatore è separato */}
      <p className="flex items-start gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2 text-xs text-text-2">
        <ShieldCheck className="mt-0.5 size-3.5 shrink-0" aria-hidden />
        <span>
          Questa preview è in sola lettura: nessun pacchetto è stato inviato. L&apos;attuatore esegue
          i comandi del vendor SOLO dopo la conferma esplicita.
        </span>
      </p>
    </div>
  )
}

/* ================================================================
 * Fase RESULT — esito integro per passo, verifica e riverifica
 * ================================================================ */

function ResultPhase(p: {
  result: SnmpEnableResult | null
  execError: unknown
  verify: SnmpVerifyResult | null
  verifyPending: boolean
  verifyError: unknown
  onVerify: () => void
  onBack: () => void
  onClose: () => void
}) {
  /* errore dell'attuatore: box + ritorno alla preview */
  if (!p.result) {
    const info = errInfo(p.execError)
    return (
      <div className="space-y-3">
        <ErrorPanel message={info.message} code={info.code} />
        <Button variant="outline" className="min-h-11 w-full sm:h-10 sm:w-auto" onClick={p.onBack}>
          Torna alla preview
        </Button>
      </div>
    )
  }

  const res = p.result
  const shownState: SnmpEnableState = p.verify?.snmpEnableState ?? res.state
  const verifyView = p.verify ?? res.verify
  const isPingOnly = res.transport === 'ping-only'
  const badge = isPingOnly
    ? { label: 'Monitoraggio ping dichiarato', cls: 'bg-info-soft text-info border-info/40' }
    : RESULT_STATE_META[shownState] ?? { label: shownState || 'nessuno stato', cls: 'bg-raised text-text-2 border-border' }
  const canVerify = shownState === 'ENABLED_UNVERIFIED'

  return (
    <div className="space-y-4">
      {/* Badge grande dell'esito persistito */}
      <div className="space-y-1.5">
        <Badge variant="outline" className={cn('px-3 py-1 text-sm', badge.cls)}>{badge.label}</Badge>
        <p className="text-[11px] text-text-2">
          Stato persistito sull&apos;inventario: <span className="font-medium text-foreground">{SNMP_STATE_LABELS[shownState] ?? (shownState || '—')}</span>
          {' · '}ricetta <span className="font-medium text-foreground">{res.recipeId}</span> ({TRANSPORT_LABELS[res.transport] ?? res.transport})
        </p>
      </div>

      {/* Esito di OGNI passo: output integro dell'apparato */}
      {res.steps.length > 0 ? (
        <section aria-label="Esito dei comandi" className="space-y-2">
          <h4 className="flex items-center gap-1.5 text-xs font-semibold">
            <Terminal className="size-3.5 text-text-2" aria-hidden />
            Esito dei comandi ({res.steps.filter((s) => s.ok).length}/{res.steps.length} riusciti):
          </h4>
          <ol className="max-h-64 space-y-2 overflow-y-auto scroll-thin rounded-lg border border-border p-2">
            {res.steps.map((s, i) => {
              const Icon = s.ok ? CheckCircle2 : s.benign ? AlertCircle : XCircle
              const tone = s.ok ? 'text-ok' : s.benign ? 'text-warn' : 'text-crit-text'
              return (
                <li key={i} className="space-y-1 rounded-md bg-raised/40 p-2">
                  <div className="flex items-start gap-2">
                    <Icon className={cn('mt-0.5 size-4 shrink-0', tone)} aria-hidden />
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <p className="font-mono text-xs break-all leading-relaxed">{s.step}</p>
                      {s.note ? <p className="text-[11px] leading-relaxed text-text-2">{s.note}</p> : null}
                      {s.exitCode != null ? (
                        <p className="num text-[10px] text-text-2">exit code {s.exitCode}</p>
                      ) : null}
                    </div>
                    {s.benign ? (
                      <Badge variant="outline" className="h-4 shrink-0 border-warn/40 bg-warn-soft px-1.5 text-[10px] text-warn" title="Fallimento atteso e tollerato dalla ricetta">
                        esito atteso
                      </Badge>
                    ) : null}
                  </div>
                  {s.output ? (
                    <pre className="max-h-32 overflow-y-auto scroll-thin rounded-md bg-muted p-2 font-mono text-[11px] leading-relaxed whitespace-pre-wrap break-all" aria-label="Output integro del passo">
                      {s.output}
                    </pre>
                  ) : null}
                </li>
              )
            })}
          </ol>
        </section>
      ) : null}

      {/* Verifica con la sonda (read-only) — trasporti che contattano */}
      {res.transport === 'ssh' || res.transport === 'http-swos' ? (
        <section
          aria-label="Verifica con la sonda SNMP"
          className={cn(
            'space-y-1 rounded-lg border px-3 py-2 text-xs leading-relaxed',
            verifyView.reachable ? 'border-ok/40 bg-ok-soft text-ok' : 'border-warn/40 bg-warn-soft text-warn',
          )}
        >
          {verifyView.reachable ? (
            <p>
              Sonda SNMP: <span className="font-semibold">RAGGIUNGIBILE</span>
              {verifyView.sysName ? <> · sysName <span className="font-semibold">«{verifyView.sysName}»</span></> : null}
              {verifyView.sysDescr ? <> · <span className="num">{verifyView.sysDescr}</span></> : null}
            </p>
          ) : (
            <p>Sonda: non raggiunge ancora l&apos;agente — i comandi possono essere applicati ma l&apos;agente non è ancora in ascolto.</p>
          )}
          {verifyView.error ? <p className="text-[11px] text-text-2">Errore sonda: {verifyView.error}</p> : null}
          {verifyView.matchedCommunity ? (
            <p className="text-[11px] text-text-2">Community corrispondente confermata dalla sonda.</p>
          ) : null}
        </section>
      ) : null}

      {/* Note leggibili (persistenti anche in scheda) */}
      {res.notes.length > 0 ? (
        <section aria-label="Note dell'esito" className="space-y-1">
          <h4 className="text-xs font-semibold">Note:</h4>
          <ul className="list-disc space-y-0.5 rounded-lg border border-border bg-raised/30 p-2 pl-7 text-[11px] leading-relaxed text-text-2">
            {res.notes.map((n, i) => <li key={i}>{n}</li>)}
          </ul>
        </section>
      ) : null}

      {res.persisted.communitySaved ? (
        <p className="text-[11px] text-text-2">
          Community salvata cifrata su FALCO-OS (le prossime sonde la useranno).
        </p>
      ) : null}

      {/* Riverifica (ENABLED_UNVERIFIED): la sonda può partire dopo qualche secondo */}
      {canVerify ? (
        <div className="space-y-1.5">
          <Button
            variant="outline"
            className="min-h-11 w-full sm:h-10 sm:w-auto"
            disabled={p.verifyPending}
            onClick={p.onVerify}
          >
            {p.verifyPending ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden /> : null}
            Riverifica ora
          </Button>
          <p className="text-[11px] text-text-2">
            L&apos;agente SNMP può impiegare qualche secondo a partire dopo i comandi: riverifica con la community cifrata del dispositivo.
          </p>
        </div>
      ) : null}

      {p.verifyError ? (
        <ErrorPanel message={errInfo(p.verifyError).message} code={errInfo(p.verifyError).code} />
      ) : null}

      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="outline" className="min-h-11 sm:h-10" onClick={p.onBack}>
          Torna alla preview
        </Button>
        <Button className="min-h-11 sm:h-10" onClick={p.onClose}>
          Chiudi
        </Button>
      </div>
    </div>
  )
}
