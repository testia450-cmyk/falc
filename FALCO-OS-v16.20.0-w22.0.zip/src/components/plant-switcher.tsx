/* ================================================================
 * FALCO-OS v16 — Selettore impianto attivo (16.10.0 W8)
 * Multi-impianto: ogni impianto è a sé (rete, dispositivi, sedi,
 * credenziali, topologia, canale telegram, mappa). Lo switcher:
 *   · idrata l'impianto attivo da localStorage al primo mount;
 *   · elenca gli impianti REALI (api.plants()) con conteggio
 *     dispositivi — menu a tendina nel topbar;
 *   · al cambio: setActivePlantId (client API: ogni chiamata v2
 *     porta ?plantId=) + invalidazione di TUTTE le query TanStack
 *     (le viste ricaricano i dati del nuovo impianto);
 *   · un solo impianto → comunque visibile: mostra il contesto
 *     attivo (pratica NOC), nessun dato inventato.
 * ================================================================ */

'use client'

import { useEffect } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Building2, Check, ChevronsUpDown, Loader2 } from 'lucide-react'
import { api, getActivePlantId, setActivePlantId } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'

export function PlantSwitcher() {
  const queryClient = useQueryClient()
  const activePlantId = useApp((s) => s.activePlantId)
  const setActivePlant = useApp((s) => s.setActivePlant)

  /* Idratazione: l'impianto attivo persiste in localStorage. Se era già
   * impostato (ripresa sessione) e le query sono partite col default,
   * invalida TUTTO perché le viste seguano l'impianto salvato. */
  useEffect(() => {
    const stored = getActivePlantId()
    if (stored && stored !== activePlantId) {
      setActivePlantId(stored)
      setActivePlant(stored)
      void queryClient.invalidateQueries()
    }
  }, [activePlantId, setActivePlant, queryClient])

  const plants = useQuery({
    queryKey: ['plants'],
    queryFn: () => api.plants(),
    staleTime: 60_000,
  })

  const rows = plants.data?.data ?? []

  /* Determinismo (bug trovato in verifica e2e): senza una scelta esplicita
   * l'impianto attivo era NULL e ogni chiamata che faceva «activePlantId ??
   * plants[0]» prendeva il primo in ordine alfabetico — dopo la creazione
   * di un impianto nuovo questo CAMBIAVA il bersaglio silenziosamente (il
   * purge contava 0 link sul plant sbagliato). Ora: al primo caricamento
   * l'impianto attivo viene FISSATO al più VECCHIO (createdAt minimo — la
   * STESSA regola del default server in getPlant: stabile, non cambia
   * quando si creano impianti nuovi); se quello salvato non esiste più
   * (eliminato) si torna allo stesso criterio. */
  useEffect(() => {
    if (rows.length === 0) return
    const current = getActivePlantId()
    if (!current || !rows.some((p) => p.id === current)) {
      const fallback = rows.reduce((a, b) => (a.createdAt <= b.createdAt ? a : b))
      setActivePlantId(fallback.id)
      setActivePlant(fallback.id)
      // le query già partite hanno usato il default del server: si
      // rifanno tutte con l'impianto attivo ESPLICITO (coerenza garantita)
      void queryClient.invalidateQueries()
    }
  }, [rows, setActivePlant, queryClient])

  const active = rows.find((p) => p.id === activePlantId) ?? rows[0] ?? null

  const onSelect = (id: string) => {
    if (id === (activePlantId ?? rows[0]?.id)) return
    setActivePlantId(id)
    setActivePlant(id)
    // OGNI vista ricarica i dati del nuovo impianto
    void queryClient.invalidateQueries()
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-9 gap-2 px-2.5 text-text-1 hover:text-foreground"
          aria-label={`Impianto attivo: ${active?.name ?? 'caricamento'}. Cambia impianto`}
        >
          <Building2 className="size-4 shrink-0 text-text-2" aria-hidden />
          <span className="max-w-[5.5rem] truncate text-sm font-medium sm:max-w-[9rem]">{active?.name ?? 'Impianto'}</span>
          {active && active.deviceCount > 0 ? (
            <span className="num hidden text-[11px] text-text-2 md:inline">{active.deviceCount} disp.</span>
          ) : null}
          <ChevronsUpDown className="size-3.5 shrink-0 text-dim" aria-hidden />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="text-[10px] font-semibold uppercase tracking-wider text-dim">
          Impianti gestiti
        </DropdownMenuLabel>
        {plants.isLoading ? (
          <div className="flex items-center gap-2 px-2 py-2 text-xs text-text-2">
            <Loader2 className="size-3.5 animate-spin" aria-hidden /> Caricamento impianti…
          </div>
        ) : rows.length === 0 ? (
          <div className="px-2 py-2 text-xs text-text-2">Nessun impianto accessibile.</div>
        ) : (
          rows.map((p) => {
            const isActive = p.id === (activePlantId ?? rows[0]?.id)
            return (
              <DropdownMenuItem
                key={p.id}
                className="gap-2 text-xs"
                onClick={() => onSelect(p.id)}
                aria-current={isActive ? 'true' : undefined}
              >
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="flex items-center gap-1.5 truncate font-medium">
                    {p.name}
                    {!p.isActive ? <span className="rounded bg-warn/15 px-1 text-[9px] font-semibold text-warn">DISATTIVATO</span> : null}
                  </span>
                  <span className="num truncate text-[10px] text-text-2">
                    {p.deviceCount} dispositivi · {p.locationCount} sedi{p.comune && p.comune !== '—' ? ` · ${p.comune}` : ''}
                  </span>
                </div>
                {isActive ? <Check className="ml-auto size-3.5 shrink-0 text-ok" aria-hidden /> : null}
              </DropdownMenuItem>
            )
          })
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          className={cn('gap-2 text-xs text-text-2')}
          onClick={() => { useApp.getState().navigate('amministrazione') }}
        >
          Gestisci impianti (Amministrazione)
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
