/* Quick-look (§6.3) — sostituisce il pannello destro incomprensibile:
 * UN solo livello, BREVE, mai contenitore di configurazione.
 * 360px fisso su desktop, bottom sheet su mobile. Esc chiude.
 * Deep link: ?device=ID (già nello store).
 * Contenuto: identità → stato+motivo+durata → 3-4 metriche chiave →
 * catena a monte con primo guasto → impatto → max 3 azioni → scheda. */

'use client'

import { useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  X, ArrowUpRight, TriangleAlert, Siren, Router, Signal, Gauge, Video, Network, MapPin, ChevronRight, Radio,
} from 'lucide-react'
import { api } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { StatusBadge } from '@/components/status-badge'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer'
import { useIsMobile } from '@/hooks/use-mobile'
import {
  fmtDbm, fmtPct, fmtUptime, fmtRelative, typeLabel,
} from '@/lib/client/format'
import { cn } from '@/lib/utils'

export function QuickLook() {
  const deviceId = useApp((s) => s.deviceId)
  const deviceTab = useApp((s) => s.deviceTab)
  const openDevice = useApp((s) => s.openDevice)
  const navigate = useApp((s) => s.navigate)
  const isMobile = useIsMobile()

  const ov = useQuery({
    queryKey: ['device-overview', deviceId],
    queryFn: () => api.deviceOverview(deviceId!),
    enabled: !!deviceId,
    staleTime: 30_000,
  })

  /* Esc chiude (§6.3) */
  useEffect(() => {
    if (!deviceId) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !deviceTab) openDevice(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [deviceId, deviceTab, openDevice])

  const close = () => openDevice(null)

  const content = deviceId ? (
    <QuickLookBody deviceId={deviceId } data={ov.data?.data} loading={ov.isLoading} error={ov.error ? String((ov.error as Error).message) : null} />
  ) : null

  if (!deviceId) return null

  if (isMobile) {
    return (
      <Drawer open onOpenChange={(o) => { if (!o) close() }}>
        <DrawerContent className="max-h-[85vh] bg-surface">
          <DrawerHeader className="pb-2">
            <DrawerTitle className="flex items-center justify-between gap-2 text-left">
              <span className="truncate">{ov.data?.data.identity.hostname ?? 'Dispositivo'}</span>
              <Button variant="ghost" size="icon" className="size-8" onClick={close} aria-label="Chiudi (Esc)">
                <X className="size-4" aria-hidden />
              </Button>
            </DrawerTitle>
          </DrawerHeader>
          <div className="max-h-[70vh] overflow-y-auto scroll-thin px-4 pb-6">{content}</div>
        </DrawerContent>
      </Drawer>
    )
  }

  return (
    <Sheet open onOpenChange={(o) => { if (!o) close() }}>
      <SheetContent
        side="right"
        className="w-[360px] sm:w-[360px] bg-surface border-l border-border p-0 flex flex-col"
        onEscapeKeyDown={(e) => { if (!deviceTab) { e.preventDefault(); close() } }}
      >
        <SheetHeader className="border-b border-border pb-3 pr-3">
          <SheetTitle className="flex items-center justify-between gap-2 text-left">
            <span className="truncate text-base">{ov.data?.data.identity.hostname ?? 'Dispositivo'}</span>
            <Button variant="ghost" size="icon" className="size-8 shrink-0" onClick={close} aria-label="Chiudi (Esc)">
              <X className="size-4" aria-hidden />
            </Button>
          </SheetTitle>
        </SheetHeader>
        <div className="flex-1 overflow-y-auto scroll-thin p-4">{content}</div>
      </SheetContent>
    </Sheet>
  )
}

function QuickLookBody({
  deviceId, data, loading, error,
}: {
  deviceId: string
  data: import('@/lib/v2/contracts').DeviceOverview | undefined
  loading: boolean
  error: string | null
}) {
  const openDevice = useApp((s) => s.openDevice)
  const set = useApp((s) => s.set)
  const navigate = useApp((s) => s.navigate)

  if (loading) {
    return (
      <div className="space-y-3" aria-busy="true">
        {[...Array(6)].map((_, i) => <div key={i} className="h-12 animate-pulse rounded-md bg-raised/60" />)}
      </div>
    )
  }
  if (error || !data) {
    return (
      <div role="alert" className="rounded-lg border border-crit/40 bg-crit-soft p-3 text-xs text-crit-text">
        Impossibile caricare il dispositivo: {error ?? 'errore sconosciuto'}
      </div>
    )
  }

  const d = data.identity
  const isRadio = d.type === 'AP' || d.type === 'STA'
  const isCamera = d.type === 'CAMERA' || d.type === 'LPR' || d.type === 'NVR'

  return (
    <div className="space-y-5">
      {/* 1 · Identità */}
      <section aria-label="Identità">
        <div className="flex items-center gap-2">
          <TypeIcon type={d.type} />
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{d.hostname}</p>
            <p className="text-xs text-text-2">{typeLabel(d.type)}{d.model ? ` · ${d.model}` : ''}{d.brand ? ` · ${d.brand}` : ''}</p>
          </div>
        </div>
        <dl className="mt-3 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5 text-xs">
          <dt className="text-text-2">IP</dt>
          <dd className="num truncate">{d.ip || 'n.d.'}</dd>
          <dt className="text-text-2">MAC</dt>
          <dd className="num truncate">{d.macAddress || 'n.d.'}</dd>
          {d.locationName ? (
            <>
              <dt className="text-text-2">Sede</dt>
              <dd className="truncate">{d.locationName}</dd>
            </>
          ) : null}
          {isRadio && d.signalPresent ? (
            <>
              <dt className="text-text-2">Frequenza</dt>
              <dd className="num">{d.currentFrequency ? `${d.currentFrequency} MHz` : 'n.d.'}{d.linkMode ? ` · ${d.linkMode}` : ''}</dd>
            </>
          ) : null}
        </dl>
      </section>

      {/* 2 · Stato con motivo e durata */}
      <section aria-label="Stato">
        <div className="flex items-center justify-between gap-2">
          <StatusBadge status={d.uiStatus} />
          <span className="text-[11px] text-text-2">
            {d.lastSeenAt ? `visto ${fmtRelative(d.lastSeenAt)}` : 'mai visto'}
          </span>
        </div>
        {d.statusReason ? (
          <p className="mt-1.5 flex items-start gap-1.5 rounded-md bg-raised/50 px-2.5 py-2 text-xs leading-relaxed text-text-2">
            <TriangleAlert className="mt-0.5 size-3.5 shrink-0 text-warn" aria-hidden />
            {d.statusReason}
          </p>
        ) : null}
      </section>

      {/* 3 · Metriche chiave (3-4 per tipo) */}
      <section aria-label="Metriche chiave">
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-dim">Metriche chiave</p>
        <div className="grid grid-cols-2 gap-2">
          {isRadio ? (
            <>
              <Metric label="Segnale" value={fmtDbm(d.signalStrength)} icon={<Signal className="size-3.5" aria-hidden />} />
              <Metric label="Qualità link" value={fmtPct(d.linkQuality)} icon={<Gauge className="size-3.5" aria-hidden />} />
            </>
          ) : null}
          {isCamera && data.camera ? (
            <>
              <Metric label="Flusso" value={data.camera.streamAlive === null ? 'n.d.' : data.camera.streamAlive ? 'Attivo' : 'Fermo'} icon={<Video className="size-3.5" aria-hidden />} warn={data.camera.streamAlive === false} />
              <Metric label="RTT" value={data.camera.rttMs != null ? `${Math.round(data.camera.rttMs)} ms` : 'n.d.'} icon={<Gauge className="size-3.5" aria-hidden />} />
            </>
          ) : null}
          <Metric label="Uptime" value={fmtUptime(d.uptimeSeconds)} icon={<Router className="size-3.5" aria-hidden />} />
          <Metric label="CPU" value={d.cpuLoad ? `${d.cpuLoad}%` : 'n.d.'} icon={<Gauge className="size-3.5" aria-hidden />} warn={d.cpuLoad > 90} />
        </div>
      </section>

      {/* 4 · Catena a monte con primo punto guasto (percorso del problema §6.2) */}
      {data.parentChain.length > 1 ? (
        <section aria-label="Catena di collegamento verso il gateway">
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-dim">Catena verso il gateway</p>
          <ol className="space-y-1">
            {data.parentChain.map((n, i) => {
              const isRoot = data.rootCause?.id === n.id
              return (
                <li key={n.id} className={cn('flex items-center gap-2 rounded-md px-2 py-1.5 text-xs', isRoot && 'border border-crit/40 bg-crit-soft')}>
                  {i === 0 ? null : <ChevronRight className="size-3 text-dim" aria-hidden />}
                  <StatusBadge status={n.uiStatus} size="xs" />
                  <button
                    className="truncate text-left hover:text-link hover:underline"
                    onClick={() => openDevice(n.id)}
                    title={n.hostname}
                  >
                    {n.hostname}
                  </button>
                  {isRoot ? <span className="ml-auto shrink-0 text-[10px] font-semibold uppercase text-crit">primo guasto</span> : null}
                </li>
              )
            })}
          </ol>
          {data.rootCause ? (
            <p className="mt-2 flex items-start gap-1.5 rounded-md bg-crit-soft px-2.5 py-2 text-[11px] leading-relaxed text-crit-text">
              <Siren className="mt-0.5 size-3.5 shrink-0" aria-hidden />
              Causa probabile a monte: <strong className="font-semibold">{data.rootCause.hostname}</strong> ({data.rootCause.ip}) non raggiungibile.
            </p>
          ) : null}
        </section>
      ) : null}

      {/* 5 · Impatto (apparati/telecamere a valle) */}
      {data.impact.devicesDownstream > 0 ? (
        <section aria-label="Impatto a valle">
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-dim">Impatto a valle</p>
          <p className="rounded-md bg-raised/50 px-2.5 py-2 text-xs leading-relaxed text-text-2">
            <span className="num font-medium text-foreground">{data.impact.devicesDownstream}</span> dispositivi a valle
            {data.impact.camerasDownstream > 0 ? <> · <span className="num font-medium text-foreground">{data.impact.camerasDownstream}</span> telecamere</> : null}
            {data.impact.offlineDownstream > 0 ? <> · <span className="num font-medium text-crit">{data.impact.offlineDownstream}</span> già offline</> : null}
          </p>
        </section>
      ) : null}

      {/* 6 · Max 3 azioni (W1: sola lettura + apertura) */}
      <section aria-label="Azioni">
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            className="h-9"
            onClick={() => { set({ deviceTab: null }); openDevice(d.id); navigate('dispositivi'); window.dispatchEvent(new CustomEvent('falco:open-device-page')) }}
          >
            <ArrowUpRight className="mr-1 size-3.5" aria-hidden /> Apri scheda completa
          </Button>
          {data.openAlerts.length > 0 ? (
            <Button size="sm" variant="outline" className="h-9" onClick={() => { set({ alarmId: null }); navigate('allarmi') }}>
              <Siren className="mr-1 size-3.5" aria-hidden /> {data.openAlerts.length} allarmi aperti
            </Button>
          ) : null}
          {d.lat != null && d.lng != null ? (
            <Button size="sm" variant="outline" className="h-9" onClick={() => { set({ reteTab: 'mappa' }); navigate('rete') }}>
              <MapPin className="mr-1 size-3.5" aria-hidden /> Vedi sulla mappa
            </Button>
          ) : null}
        </div>
      </section>
    </div>
  )
}

function Metric({ label, value, icon, warn }: { label: string; value: string; icon: React.ReactNode; warn?: boolean }) {
  return (
    <div className={cn('rounded-md border border-border/60 bg-raised/40 px-2.5 py-2', warn && 'border-warn/40 bg-warn-soft')}>
      <p className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-text-2">{icon}{label}</p>
      <p className={cn('mt-0.5 num text-sm font-medium', warn && 'text-warn')}>{value}</p>
    </div>
  )
}

function TypeIcon({ type }: { type: string }) {
  const t = type.toUpperCase()
  const cls = 'flex size-9 shrink-0 items-center justify-center rounded-lg border border-border bg-raised/60 text-text-2'
  if (t === 'CAMERA' || t === 'LPR' || t === 'NVR') return <span className={cls}><Video className="size-4" aria-hidden /></span>
  if (t === 'AP' || t === 'STA') return <span className={cls}><Radio className="size-4" aria-hidden /></span>
  return <span className={cls}><Network className="size-4" aria-hidden /></span>
}
