/* ================================================================
 * FALCO-OS v16 — Vista «Assistente» (16.9 ondata W4)
 * AI operatore della piattaforma: POST /api/v2/assistente con
 * risposta SSE in STREAMING reale (status → delta → done/error).
 * Il contesto è costruito server-side dai dati REALI del plant
 * (dispositivi, allarmi, ticket, link deboli): nessun numero
 * inventato, e la modalità riproduzione è dichiarata. La
 * conversazione vive SOLO nel browser (ultimi 6 turni reinviati
 * come history); ogni domanda lascia una voce di audit
 * ASSISTENTE_QUERY senza il contenuto della risposta.
 * ================================================================ */

'use client'

import { useEffect, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Loader2, Send, Sparkles } from 'lucide-react'

import { PageHeader } from '@/components/page-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { api, v2Url } from '@/lib/client/api'
import { fmtNumber } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Tipi / costanti ---------------- */

interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

const SUGGESTIONS: ReadonlyArray<string> = [
  'Quanti dispositivi ha l\'impianto e quanti allarmi aperti?',
  'Quali sono i link radio più deboli?',
  'Come apro una finestra di manutenzione?',
  'Spiegami la differenza fra RMA e ondata',
]

/** «1,2 s» in locale italiano */
function fmtSecs(ms: number): string {
  return `${(ms / 1000).toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} s`
}

/* ================================================================
 * Vista Assistente
 * ================================================================ */

export function AssistenteView() {
  /* Salute del sistema: badge modalità riproduzione nell'intestazione */
  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    staleTime: 60_000,
    refetchInterval: 60_000,
  })

  /* --- Conversazione (solo stato client) --- */
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [streaming, setStreaming] = useState(false)
  const [statusLine, setStatusLine] = useState<string | null>(null)
  const [meta, setMeta] = useState<{ durationMs: number; contextChars: number } | null>(null)

  const streamingRef = useRef(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  /* Auto-scroll verso il messaggio più recente (anche durante i delta) */
  useEffect(() => {
    const el = scrollRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [messages, statusLine])

  /** Accoda un frammento al messaggio assistente in coda (lo crea se manca). */
  const appendDelta = (delta: string) => {
    setMessages((prev) => {
      if (prev.length === 0 || prev[prev.length - 1].role !== 'assistant') {
        return [...prev, { role: 'assistant', content: delta }]
      }
      const copy = prev.slice()
      copy[copy.length - 1] = { role: 'assistant', content: copy[copy.length - 1].content + delta }
      return copy
    })
  }

  /** Rimuove l'eventuale bubble assistente VUOTA (errore prima del primo delta). */
  const removeTrailingAssistant = () => {
    setMessages((prev) => {
      const last = prev[prev.length - 1]
      if (last && last.role === 'assistant' && last.content === '') return prev.slice(0, -1)
      return prev
    })
  }

  /** Invia la domanda e consuma lo stream SSE (unico raw fetch del client). */
  async function send(messageText: string) {
    const message = messageText.trim()
    if (!message || message.length > 10_000 || streamingRef.current) return

    streamingRef.current = true
    setStreaming(true)
    setStatusLine(null)
    setMeta(null)
    setInput('')

    /* Ultimi 6 turni come history (il contratto li limita a 6) */
    const history = messages.slice(-6).map((m) => ({ role: m.role, content: m.content }))
    setMessages((prev) => [...prev, { role: 'user', content: message }])

    try {
      const res = await fetch(v2Url('/assistente'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, history }),
      })

      /* Risposta non-SSE = errore della busta JSON (401/403/422…): mostro il messaggio reale */
      const ct = res.headers.get('content-type') ?? ''
      if (!res.ok || !ct.startsWith('text/event-stream')) {
        let msg = `Errore ${res.status}`
        try {
          const body = (await res.json()) as { ok?: boolean; error?: { message?: string } }
          msg = body?.error?.message ?? msg
        } catch { /* corpo non JSON */ }
        throw new Error(msg)
      }
      if (!res.body) throw new Error('Risposta senza corpo (stream assente)')

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const frames = buffer.split('\n\n')
        buffer = frames.pop() ?? ''
        for (const frame of frames) {
          if (!frame.trim()) continue
          const ev = /event: (.*)/.exec(frame)?.[1]
          const rawData = /data: (.*)/.exec(frame)?.[1] ?? ''
          const data = rawData.replace(/\\n/g, '\n') // newline escaped server-side
          if (ev === 'status') {
            setStatusLine(data)
          } else if (ev === 'delta') {
            appendDelta(data)
          } else if (ev === 'done') {
            try {
              setMeta(JSON.parse(data) as { durationMs: number; contextChars: number })
            } catch { /* payload non JSON: meta omesso */ }
          } else if (ev === 'error') {
            let msg = 'Errore del model'
            try {
              msg = (JSON.parse(data) as { message?: string }).message ?? msg
            } catch { /* payload non JSON */ }
            throw new Error(msg)
          }
        }
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Errore sconosciuto'
      toast.error('Assistente non disponibile', { description: msg })
      removeTrailingAssistant()
    } finally {
      streamingRef.current = false
      setStreaming(false)
      setStatusLine(null)
    }
  }

  const submit = () => {
    if (!input.trim() || streaming) return
    void send(input)
  }

  const lastMsg = messages[messages.length - 1]
  const waitingFirstDelta = streaming && (messages.length === 0 || lastMsg?.role === 'user')

  return (
    <div className="grid min-w-0 grid-cols-1 gap-4">
      <PageHeader
        title="Assistente"
        subtitle="AI della piattaforma, risponde sul contesto REALE dell'impianto (dispositivi, allarmi, ticket, link deboli). Modalità riproduzione: le esecuzioni SSH/SNMP non girano — l'assistente lo dichiara."
        mode={health.data?.mode}
        importedAt={health.data?.data.replay.importedAt ?? null}
      />

      <Card className="min-w-0 border-border/70 bg-surface">
        <CardHeader className="pb-2">
          <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
            <Sparkles className="size-4 text-text-2" aria-hidden />
            Assistente AI
            <Badge variant="outline" className="border-border bg-raised font-normal text-text-2">streaming SSE</Badge>
          </CardTitle>
          <CardDescription>
            Le risposte arrivano in streaming sul contesto reale del DB; la conversazione resta
            nel browser e vengono reinviati solo gli ultimi 6 turni.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* --- Area conversazione --- */}
          <div
            ref={scrollRef}
            role="log"
            aria-label="Conversazione con l'assistente"
            aria-live="polite"
            className="flex max-h-[calc(100vh-320px)] min-h-[280px] flex-col gap-3 overflow-y-auto scroll-thin rounded-lg border border-border/70 bg-background/40 p-3"
          >
            {messages.length === 0 && !streaming ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-3 py-8 text-center">
                <Sparkles className="size-10 text-text-2" aria-hidden />
                <div>
                  <p className="text-sm font-medium">Chiedi all&apos;assistente dell&apos;impianto</p>
                  <p className="mt-1 max-w-md text-xs text-text-2">
                    Interroga i dati reali del NOC: conteggi dispositivi, allarmi aperti, ticket,
                    link radio deboli. Nessuna domanda o risposta viene salvata come contenuto.
                  </p>
                </div>
                <div className="flex max-w-lg flex-wrap justify-center gap-2">
                  {SUGGESTIONS.map((s) => (
                    <Button
                      key={s}
                      variant="outline"
                      size="sm"
                      className="h-8 rounded-full text-xs font-normal"
                      onClick={() => { void send(s) }}
                    >
                      {s}
                    </Button>
                  ))}
                </div>
              </div>
            ) : null}

            {messages.map((m, i) => {
              const isLast = i === messages.length - 1
              const showMeta = meta != null && !streaming && isLast && m.role === 'assistant'
              return (
                <div key={i} className={cn('flex w-full', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  <div
                    className={cn(
                      'max-w-[85%] rounded-lg px-3.5 py-2.5 text-sm leading-relaxed',
                      m.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'border border-border/70 bg-surface',
                    )}
                  >
                    <p className="whitespace-pre-wrap break-words">
                      {m.content}
                      {streaming && isLast && m.role === 'assistant' ? (
                        <span className="animate-pulse" aria-hidden>▍</span>
                      ) : null}
                    </p>
                    {showMeta && meta ? (
                      <p className="num mt-1.5 text-[11px] text-dim">
                        · {fmtSecs(meta.durationMs)} · contesto {fmtNumber(meta.contextChars)} caratteri
                      </p>
                    ) : null}
                  </div>
                </div>
              )
            })}

            {/* Bubble con solo cursore: stream aperto ma nessun delta ancora arrivato */}
            {waitingFirstDelta ? (
              <div className="flex justify-start">
                <div className="rounded-lg border border-border/70 bg-surface px-3.5 py-2.5 text-sm" aria-hidden>
                  <span className="animate-pulse">▍</span>
                </div>
              </div>
            ) : null}
          </div>

          {/* --- Riga di stato (ultimo evento `status`, con spinner) --- */}
          {streaming ? (
            <div role="status" aria-live="polite" className="flex items-center gap-2 text-xs text-text-2">
              <Loader2 className="size-3.5 animate-spin" aria-hidden />
              {statusLine ?? 'in attesa del model…'}
            </div>
          ) : null}

          {/* --- Input --- */}
          <form
            className="flex items-end gap-2"
            onSubmit={(e) => { e.preventDefault(); submit() }}
            aria-label="Domanda per l'assistente"
          >
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  submit()
                }
              }}
              placeholder="Chiedi qualcosa sull'impianto… (Enter invia · Shift+Enter a capo)"
              maxLength={10_000}
              rows={2}
              className="min-h-10 max-h-44 flex-1 resize-none"
              aria-label="Domanda per l'assistente"
              disabled={streaming}
            />
            <Button type="submit" disabled={streaming || input.trim().length === 0} aria-label="Invia la domanda all'assistente">
              {streaming ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Send className="size-3.5" aria-hidden />}
              Invia
            </Button>
          </form>

          <p className="text-[11px] leading-relaxed text-dim" role="note">
            Ogni domanda lascia una voce di audit ASSISTENTE_QUERY (durata e dimensione contesto — mai il contenuto).
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
