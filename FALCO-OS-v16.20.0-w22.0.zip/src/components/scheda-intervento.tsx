/* ================================================================
 * FALCO-OS v16 — «Scheda intervento» (16.8 W2 residua)
 * Documento stampabile per il tecnico in campo, generato dai dati
 * REALI del ticket (GET /api/v2/tickets/{id}): anteprima in Dialog +
 * stampa/PDF via finestra autonoma del browser (stesso pattern di
 * printSintesi in report-view.tsx: window.open + document.write con
 * HTML autonomo e CSS di stampa — nessun CSS print nel DOM dell'app).
 * Onestà: null → «—» / «non registrata», liste vuote dichiarate con
 * la stringa `honesty` del backend mostrata così com'è; mai dati
 * inventati. Nessuna emoji.
 * ================================================================ */

'use client'

import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  CircleAlert, CircleCheck, CircleDot, CheckCheck, Hourglass, Info, Monitor,
  OctagonAlert, Printer, TriangleAlert, Wrench, type LucideIcon,
} from 'lucide-react'

import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { api, ApiError } from '@/lib/client/api'
import { fmtDateTimeFull, fmtNumber, STATUS_META, typeLabel } from '@/lib/client/format'
import type { TicketDetail } from '@/lib/v2/contracts'
import { cn } from '@/lib/utils'

/* ---------------- Costanti (vocabolari del dominio, mai inventati) ---------------- */

const FALLBACK_META: { label: string; cls: string; Icon: LucideIcon } = {
  label: '', cls: 'bg-raised text-text-2 border-border', Icon: CircleAlert,
}

const TICKET_STATUS_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  OPEN: { label: 'Aperto', cls: 'bg-warn-soft text-warn border-warn/40', Icon: CircleDot },
  IN_PROGRESS: { label: 'In lavorazione', cls: 'bg-info-soft text-info border-info/40', Icon: Hourglass },
  RESOLVED: { label: 'Risolto', cls: 'bg-ok-soft text-ok border-ok/40', Icon: CircleCheck },
  CLOSED: { label: 'Chiuso', cls: 'bg-raised text-text-2 border-border', Icon: CheckCheck },
}

const PRIORITY_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  CRITICAL: { label: 'Critica', cls: 'bg-crit-soft text-crit-text border-crit/40', Icon: OctagonAlert },
  HIGH: { label: 'Alta', cls: 'bg-warn-soft text-warn border-warn/40', Icon: TriangleAlert },
  MEDIUM: { label: 'Media', cls: 'bg-info-soft text-info border-info/40', Icon: CircleAlert },
  LOW: { label: 'Bassa', cls: 'bg-ok-soft text-ok border-ok/40', Icon: Info },
}

const SOURCE_LABELS: Record<string, string> = {
  MANUAL: 'Manuale',
  AUTO: 'Automatica (motore regole)',
  WATCHDOG: 'Watchdog',
}

const NO_SLA = 'nessun target assegnato (D19)'

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* ---------------- Escape HTML (stesso helper di report-view.tsx) ---------------- */

function escapeHtml(v: string): string {
  return v.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

/* ================================================================
 * Stampa / PDF: documento autonomo in nuova scheda (pattern
 * printSintesi): stili inline, nessuna dipendenza dall'app;
 * window.print() apre la finestra «Salva come PDF» del sistema.
 * ================================================================ */

function printScheda(d: TicketDetail) {
  const esc = escapeHtml
  const t = d.ticket
  const generated = new Date().toLocaleString('it-IT')
  const shortId = t.id.slice(0, 8)

  const infoRows: Array<[string, string]> = [
    ['ID ticket', t.id],
    ['Stato', TICKET_STATUS_META[t.status]?.label ?? t.status],
    ['Priorità', PRIORITY_META[t.priority]?.label ?? t.priority],
    ['Sorgente', SOURCE_LABELS[t.source] ?? t.source],
    ['Assegnatario', t.assignedTo || 'n.d.'],
    ['Creato il', fmtDateTimeFull(t.createdAt)],
    ['Prima risposta', t.firstResponseAt != null ? fmtDateTimeFull(t.firstResponseAt) : 'non registrata'],
    ['Risolto', t.resolvedAt != null ? fmtDateTimeFull(t.resolvedAt) : '—'],
    ['Chiuso', t.closedAt != null ? fmtDateTimeFull(t.closedAt) : '—'],
    ['SLA prima risposta', t.slaResponseDueAt != null ? fmtDateTimeFull(t.slaResponseDueAt) : NO_SLA],
    ['SLA risoluzione', t.slaResolutionDueAt != null ? fmtDateTimeFull(t.slaResolutionDueAt) : NO_SLA],
    ['Pause SLA', `${fmtNumber(t.slaPausedMinutes)} min`],
    ['Livello escalation', t.escalationLevel > 0 ? `livello ${fmtNumber(t.escalationLevel)}` : 'nessuna'],
    ['Sede', d.location ? d.location.name : 'n.d.'],
    ['Impianto', d.plant.name],
    ['Dispositivo', d.device
      ? `${d.device.hostname}${d.device.ip ? ` (${d.device.ip})` : ''} — ${typeLabel(d.device.type)}${d.device.brand ? ` ${d.device.brand}` : ''}${d.device.model ? ` ${d.device.model}` : ''} — ${STATUS_META[d.device.status]?.label ?? d.device.status}`
      : 'Nessun dispositivo collegato'],
  ]

  const stepsHtml = t.diagnosticSteps.length > 0
    ? `<ol>${t.diagnosticSteps.map((s) => `<li>${esc(s)}</li>`).join('\n')}</ol>`
    : '<p class="empty">nessun passo registrato</p>'

  const interventionsHtml = d.interventions.length > 0
    ? `<table><thead><tr><th>Azione</th><th>Componente</th><th>Tecnico</th><th>Stato</th><th>Data</th></tr></thead><tbody>${d.interventions.map((i) => `<tr><td>${esc(i.action)}</td><td>${esc(i.component)}</td><td>${esc(i.technicianName)}</td><td>${esc(i.status)}</td><td class="num">${esc(fmtDateTimeFull(i.createdAt))}</td></tr>`).join('\n')}</tbody></table>`
    : `<p class="empty">${esc(d.honesty)}</p>`

  const timelineHtml = d.timeline.length > 0
    ? `<table><thead><tr><th>Azione</th><th>Autore</th><th>Data/ora</th></tr></thead><tbody>${d.timeline.map((e) => `<tr><td>${esc(e.action)}</td><td>${esc(e.actor)}</td><td class="num">${esc(fmtDateTimeFull(e.createdAt))}</td></tr>`).join('\n')}</tbody></table>`
    : '<p class="empty">nessun evento di audit registrato</p>'

  const html = `<!doctype html>
<html lang="it"><head><meta charset="utf-8"/>
<title>Scheda intervento — ${esc(t.title)} — FALCO-OS</title>
<style>
  body { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color:#101826; margin:48px; }
  h1 { font-size:22px; margin:0 0 4px; }
  h2 { font-size:14px; margin:28px 0 8px; text-transform:uppercase; letter-spacing:.05em; color:#5b6472; }
  .sub { color:#5b6472; font-size:13px; margin:0; }
  table { border-collapse:collapse; width:100%; font-size:14px; }
  th, td { border:1px solid #d8dee8; padding:8px 10px; text-align:left; vertical-align:top; }
  th[scope=row] { background:#f1f4f9; width:220px; }
  thead th { background:#f1f4f9; width:auto; }
  p { margin:0 0 8px; white-space:pre-wrap; }
  ol { margin:0 0 8px; padding-left:22px; }
  ol li { margin-bottom:4px; }
  .empty { color:#5b6472; font-style:italic; }
  .foot { margin-top:28px; font-size:11px; color:#5b6472; border-top:1px solid #d8dee8; padding-top:10px; }
  @media print { body { margin:16mm; } h2 { break-after:avoid; } table { break-inside:avoid; } }
</style></head><body>
<h1>Scheda intervento — ${esc(t.title)}</h1>
<p class="sub">Ticket ${esc(shortId)} · ${esc(d.plant.name)}${d.location ? ` · sede ${esc(d.location.name)}` : ''} — generato il ${generated} da FALCO-OS</p>
<h2>Informazioni</h2>
<table><tbody>
${infoRows.map(([k, v]) => `<tr><th scope="row">${esc(k)}</th><td>${esc(v)}</td></tr>`).join('\n')}
</tbody></table>
<h2>Descrizione</h2>
<p>${esc(t.description || 'n.d.')}</p>
<h2>Passi diagnostici</h2>
${stepsHtml}
<h2>Causa radice</h2>
<p>${esc(t.rootCause || 'non ancora compilata')}</p>
<h2>Risoluzione</h2>
<p>${esc(t.resolution || 'non ancora compilata')}</p>
<h2>Registro interventi</h2>
${interventionsHtml}
<p class="sub">Commenti: ${fmtNumber(d.counts.comments)} · Allegati: ${fmtNumber(d.counts.attachments)} · Voci tempo: ${fmtNumber(d.counts.timeEntries)} (dati reali del DB)</p>
<h2>Timeline audit</h2>
${timelineHtml}
<p class="foot">Documento generato dai dati reali del DB · GET /api/v2/tickets/${esc(t.id)} · FALCO-OS v16 · ${generated}.</p>
</body></html>`

  const w = window.open('', '_blank', 'width=900,height=1100')
  if (!w) {
    toast.error('Stampa non riuscita', { description: 'Il browser ha bloccato la finestra di stampa: consenti i popup per questo sito.' })
    return
  }
  w.document.open()
  w.document.write(html)
  w.document.close()
  w.focus()
  w.setTimeout(() => w.print(), 300)
}

/* ================================================================
 * SchedaIntervento — Dialog di anteprima
 * ================================================================ */

export default function SchedaIntervento({
  ticketId, onClose,
}: {
  /** Ticket selezionato (null = dialog chiuso). */
  ticketId: string | null
  onClose: () => void
}) {
  const detail = useQuery({
    queryKey: ['ticket-detail', ticketId],
    queryFn: () => api.ticketDetail(ticketId as string),
    enabled: !!ticketId,
    staleTime: 15_000,
  })

  const d = detail.data?.data
  const asOf = detail.data?.asOf
  const statusMeta = d ? (TICKET_STATUS_META[d.ticket.status] ?? { ...FALLBACK_META, label: d.ticket.status }) : null
  const prioMeta = d ? (PRIORITY_META[d.ticket.priority] ?? { ...FALLBACK_META, label: d.ticket.priority }) : null

  return (
    <Dialog open={!!ticketId} onOpenChange={(o) => { if (!o) onClose() }}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl lg:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wrench className="size-4 shrink-0 text-text-2" aria-hidden />
            Scheda intervento
          </DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Documento stampabile per il tecnico in campo, generato dai dati reali del ticket.
            {asOf ? <AsOf ts={asOf} prefix="· dati alle" className="ml-1" /> : null}
          </DialogDescription>
        </DialogHeader>

        {detail.isPending ? (
          <div className="space-y-3" role="status" aria-busy="true">
            <span className="sr-only">Caricamento scheda intervento…</span>
            <div className="h-6 w-2/3 animate-pulse rounded-md bg-raised/60" />
            <LoadingRows rows={6} />
          </div>
        ) : detail.isError ? (
          <ErrorPanel
            message={errInfo(detail.error).message}
            code={errInfo(detail.error).code}
            onRetry={() => { void detail.refetch() }}
          />
        ) : d && statusMeta && prioMeta ? (
          <div className="space-y-4">
            {/* Intestazione: titolo + badge stato/priorità + id corto */}
            <div>
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge variant="outline" className={cn('gap-1.5 font-medium whitespace-nowrap', statusMeta.cls)}>
                  <statusMeta.Icon className="size-3.5" aria-hidden />
                  {statusMeta.label}
                </Badge>
                <Badge variant="outline" className={cn('gap-1.5 font-medium whitespace-nowrap', prioMeta.cls)}>
                  <prioMeta.Icon className="size-3.5" aria-hidden />
                  {prioMeta.label}
                </Badge>
                <span className="num text-xs text-text-2" title={d.ticket.id}>ticket {d.ticket.id.slice(0, 8)}</span>
              </div>
              <p className="mt-2 break-words text-base font-semibold leading-snug">{d.ticket.title}</p>
              <p className="mt-1 text-xs text-text-2">Sorgente: {SOURCE_LABELS[d.ticket.source] ?? d.ticket.source}</p>
            </div>

            <Separator />

            {/* Griglia info: collassa su mobile (1 colonna → 2 da sm) */}
            <dl className="grid gap-x-6 gap-y-1.5 text-xs sm:grid-cols-2">
              <InfoRow label="Assegnatario" value={d.ticket.assignedTo || 'n.d.'} />
              <InfoRow label="Creato il" value={fmtDateTimeFull(d.ticket.createdAt)} />
              <InfoRow label="Prima risposta" value={d.ticket.firstResponseAt != null ? fmtDateTimeFull(d.ticket.firstResponseAt) : 'non registrata'} />
              <InfoRow label="Risolto" value={d.ticket.resolvedAt != null ? fmtDateTimeFull(d.ticket.resolvedAt) : '—'} />
              <InfoRow label="Chiuso" value={d.ticket.closedAt != null ? fmtDateTimeFull(d.ticket.closedAt) : '—'} />
              <InfoRow label="SLA prima risposta" value={d.ticket.slaResponseDueAt != null ? fmtDateTimeFull(d.ticket.slaResponseDueAt) : NO_SLA} />
              <InfoRow label="SLA risoluzione" value={d.ticket.slaResolutionDueAt != null ? fmtDateTimeFull(d.ticket.slaResolutionDueAt) : NO_SLA} />
              <InfoRow label="Pause SLA" value={`${fmtNumber(d.ticket.slaPausedMinutes)} min`} />
              <InfoRow label="Livello escalation" value={d.ticket.escalationLevel > 0 ? `livello ${fmtNumber(d.ticket.escalationLevel)}` : 'nessuna'} />
              <InfoRow label="Sede / impianto" value={`${d.location ? d.location.name : 'n.d.'} / ${d.plant.name}`} />
            </dl>

            <Separator />

            {/* Dispositivo collegato */}
            <section aria-labelledby="scheda-device">
              <p id="scheda-device" className="text-[10px] font-semibold uppercase tracking-wider text-dim">Dispositivo</p>
              {d.device ? (
                <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                  <span className="inline-flex items-center gap-1.5 font-medium">
                    <Monitor className="size-3.5 shrink-0 text-text-2" aria-hidden />
                    {d.device.hostname}
                  </span>
                  <span className="num text-text-2">{d.device.ip || 'IP n.d.'}</span>
                  <span className="text-text-2">{typeLabel(d.device.type)}</span>
                  <span className="text-text-2">
                    {[d.device.brand, d.device.model].filter(Boolean).join(' ') || 'marca/modello n.d.'}
                  </span>
                  <Badge variant="outline" className="gap-1.5 font-medium whitespace-nowrap">
                    {STATUS_META[d.device.status]?.label ?? d.device.status}
                  </Badge>
                </div>
              ) : (
                <p className="mt-1.5 text-xs text-text-2">Nessun dispositivo collegato</p>
              )}
            </section>

            {/* Descrizione */}
            <section aria-labelledby="scheda-desc">
              <p id="scheda-desc" className="text-[10px] font-semibold uppercase tracking-wider text-dim">Descrizione</p>
              <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-relaxed">{d.ticket.description || 'n.d.'}</p>
            </section>

            {/* Passi diagnostici */}
            <section aria-labelledby="scheda-steps">
              <p id="scheda-steps" className="text-[10px] font-semibold uppercase tracking-wider text-dim">Passi diagnostici</p>
              {d.ticket.diagnosticSteps.length > 0 ? (
                <ol className="mt-1.5 list-decimal space-y-1 pl-5 text-xs leading-relaxed">
                  {d.ticket.diagnosticSteps.map((s, i) => (
                    <li key={i} className="break-words">{s}</li>
                  ))}
                </ol>
              ) : (
                <p className="mt-1.5 text-xs text-text-2">nessun passo registrato</p>
              )}
            </section>

            {/* Causa radice / risoluzione */}
            <section aria-labelledby="scheda-cause">
              <p id="scheda-cause" className="text-[10px] font-semibold uppercase tracking-wider text-dim">Causa radice / risoluzione</p>
              <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-relaxed">{d.ticket.rootCause || 'causa radice non ancora compilata'}</p>
              <p className="mt-2 whitespace-pre-wrap break-words text-xs leading-relaxed">{d.ticket.resolution || 'risoluzione non ancora compilata'}</p>
            </section>

            <Separator />

            {/* Registro interventi: tabella reale o empty state onesto */}
            <section aria-labelledby="scheda-int">
              <p id="scheda-int" className="text-[10px] font-semibold uppercase tracking-wider text-dim">Registro interventi</p>
              {d.interventions.length > 0 ? (
                <div className="mt-1.5 overflow-x-auto rounded-lg border border-border/70">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead scope="col">Azione</TableHead>
                        <TableHead scope="col">Componente</TableHead>
                        <TableHead scope="col">Tecnico</TableHead>
                        <TableHead scope="col">Stato</TableHead>
                        <TableHead scope="col">Data</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {d.interventions.map((i) => (
                        <TableRow key={i.id}>
                          <TableCell className="break-words text-xs">{i.action}</TableCell>
                          <TableCell className="break-words text-xs">{i.component}</TableCell>
                          <TableCell className="break-words text-xs">{i.technicianName}</TableCell>
                          <TableCell className="text-xs">{i.status}</TableCell>
                          <TableCell className="num text-xs text-text-2" title={fmtDateTimeFull(i.createdAt)}>
                            {fmtDateTimeFull(i.createdAt)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="mt-1.5">
                  <EmptyState
                    icon={<Wrench className="size-8" aria-hidden />}
                    title="Nessun intervento registrato"
                    description={d.honesty}
                  />
                </div>
              )}
              <p className="mt-2 text-[11px] text-text-2">
                Commenti: <span className="num">{fmtNumber(d.counts.comments)}</span> · Allegati:{' '}
                <span className="num">{fmtNumber(d.counts.attachments)}</span> · Voci tempo:{' '}
                <span className="num">{fmtNumber(d.counts.timeEntries)}</span> (dati reali del DB)
              </p>
            </section>

            {/* Timeline audit */}
            <section aria-labelledby="scheda-timeline">
              <p id="scheda-timeline" className="text-[10px] font-semibold uppercase tracking-wider text-dim">Timeline audit</p>
              {d.timeline.length > 0 ? (
                <div className="mt-1.5 max-h-48 overflow-y-auto scroll-thin rounded-md border border-border/70 bg-raised/25 px-3 py-2">
                  <ul className="space-y-1.5">
                    {d.timeline.map((e, i) => (
                      <li key={i} className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 text-xs">
                        <span className="font-medium">{e.action}</span>
                        <span className="text-text-2">— {e.actor}</span>
                        <span className="num text-text-2">— {fmtDateTimeFull(e.createdAt)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : (
                <p className="mt-1.5 text-xs text-text-2">nessun evento di audit registrato</p>
              )}
            </section>
          </div>
        ) : null}

        {/* Footer: nota onestà + stampa + chiudi */}
        <div className="mt-1 space-y-3">
          <p className="text-[11px] leading-relaxed text-text-2">
            {d ? d.honesty : 'Dati reali del DB: nessun dato di esempio.'}
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={onClose}>Chiudi</Button>
            <Button onClick={() => { if (d) printScheda(d) }} disabled={!d}>
              <Printer className="size-3.5" aria-hidden />
              Stampa / PDF
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Helper griglia info ---------------- */

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex gap-2 sm:block">
      <dt className="shrink-0 text-text-2">{label}</dt>
      <dd className="num">{value}</dd>
    </div>
  )
}
