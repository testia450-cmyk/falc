/* Grafico traffico 24h (§6.1 + D3): area chart in/out con definizione
 * dichiarata, finestra temporale reale, nessun punto inventato. */

'use client'

import { useQuery } from '@tanstack/react-query'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'
import { api } from '@/lib/client/api'
import { fmtDateTime, fmtMbps } from '@/lib/client/format'
import { usePalette } from '@/lib/client/theme-palette'
import { Info } from 'lucide-react'
import {
  Tooltip as UITooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { Skeleton } from '@/components/ui/skeleton'

export function TrafficChart({ hours = 24 }: { hours?: number }) {
  const p = usePalette()
  const q = useQuery({
    queryKey: ['traffic-series', hours],
    queryFn: () => api.traffic(hours),
    staleTime: 60_000,
  })

  if (q.isLoading) {
    return <div className="h-[220px] space-y-2"><Skeleton className="h-full w-full rounded-lg" /></div>
  }
  if (q.isError || !q.data) {
    return (
      <div role="alert" className="flex h-[220px] items-center justify-center rounded-lg border border-crit/40 bg-crit-soft text-xs text-crit-text">
        Dati di traffico non disponibili: {q.isError ? (q.error as Error).message : 'dati assenti'}
      </div>
    )
  }

  const d = q.data.data
  const dataMap = new Map<number, { t: number; in: number | null; out: number | null }>()
  for (const p of d.inMbps) dataMap.set(p.t, { t: p.t, in: p.v, out: null })
  for (const p of d.outMbps) {
    const cur = dataMap.get(p.t) ?? { t: p.t, in: null, out: null }
    cur.out = p.v
    dataMap.set(p.t, cur)
  }
  const points = [...dataMap.values()].sort((a, b) => a.t - b.t)

  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-2">
        <div className="flex items-baseline gap-3">
          <p className="num text-lg font-semibold">
            {d.lastInMbps != null ? fmtMbps(d.lastInMbps) : 'n.d.'}
          </p>
          <p className="text-xs text-text-2">
            in · <span className="num">{d.lastOutMbps != null ? fmtMbps(d.lastOutMbps) : 'n.d.'}</span> out
          </p>
        </div>
        <TooltipProvider>
          <UITooltip>
            <TooltipTrigger asChild>
              <button className="flex items-center gap-1 text-[11px] text-text-2 hover:text-link" aria-label="Definizione dell'aggregato di traffico">
                <Info className="size-3" aria-hidden /> definizione
              </button>
            </TooltipTrigger>
            <TooltipContent side="left" className="max-w-72 text-[11px] leading-relaxed">
              {d.definition}
            </TooltipContent>
          </UITooltip>
        </TooltipProvider>
      </div>

      {points.length === 0 ? (
        <div className="flex h-[180px] items-center justify-center rounded-lg border border-dashed border-border text-xs text-text-2">
          Nessun campione di traffico nella finestra richiesta (nessun punto inventato).
        </div>
      ) : (
        <div className="h-[200px]" role="img" aria-label="Grafico del traffico di rete nelle ultime 24 ore">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={points} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="gIn" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={p.info} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={p.info} stopOpacity={0.02} />
                </linearGradient>
                <linearGradient id="gOut" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={p.ok} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={p.ok} stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={p.border} strokeDasharray="3 3" vertical={false} />
              <XAxis
                dataKey="t"
                type="number"
                scale="time"
                domain={['dataMin', 'dataMax']}
                tickFormatter={(t: number) => new Date(t).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}
                stroke={p.text2}
                fontSize={10}
                tickLine={false}
                axisLine={{ stroke: p.border }}
                tickMargin={6}
              />
              <YAxis
                width={42}
                stroke={p.text2}
                fontSize={10}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v: number) => `${v}`}
                unit=" Mb/s"
              />
              <Tooltip
                cursor={{ stroke: p.controlBorder, strokeDasharray: '4 4' }}
                contentStyle={{
                  background: p.surface, border: `1px solid ${p.border}`, borderRadius: 8,
                  fontSize: 11, color: p.text, boxShadow: '0 8px 24px rgba(0,0,0,.45)',
                }}
                labelFormatter={(t) => fmtDateTime(Number(t))}
                formatter={((value: unknown, name: unknown) => [
                  value == null ? 'n.d.' : `${value} Mb/s`,
                  name === 'in' ? 'Ingresso (download)' : 'Uscita (upload)',
                ]) as never}
              />
              <Area dataKey="in" type="monotone" stroke={p.info} strokeWidth={1.6} fill="url(#gIn)" connectNulls />
              <Area dataKey="out" type="monotone" stroke={p.ok} strokeWidth={1.6} fill="url(#gOut)" connectNulls />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      <p className="text-[10px] text-text-2">
        {d.coreHostname ? (
          <>Core: <span className="font-medium text-foreground">{d.coreHostname}</span> · ultimo campione {d.lastSampleAt ? fmtDateTime(d.lastSampleAt) : '—'}</>
        ) : 'Nessun core con traffico campionato.'}
      </p>
    </div>
  )
}
