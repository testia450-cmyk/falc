/* Sidebar (mockup 1): logo, voci di navigazione (§5: 8 voci — TUTTE
 * attive su dati reali: le roadmap W2/W3/W4 vivono nelle viste
 * Report/Amministrazione come sezioni oneste, non come pulsanti
 * finti), riquadro stato sistema con versione REALE. */

'use client'

import { useQuery } from '@tanstack/react-query'
import { signOut } from 'next-auth/react'
import {
  LayoutDashboard, Network, MonitorSmartphone, Cctv, BellRing,
  Wrench, MessageSquare, FileText, Settings2, Radio, LogOut, ChevronRight, Rocket,
} from 'lucide-react'
import { useApp, VIEW_LABELS, type ViewId } from '@/lib/client/store'
import { api } from '@/lib/client/api'
import { cn } from '@/lib/utils'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'

const NAV: Array<{ view: ViewId; label: string; icon: React.ElementType }> = [
  { view: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { view: 'setup', label: 'Setup impianto', icon: Rocket },
  { view: 'rete', label: 'Rete', icon: Network },
  { view: 'dispositivi', label: 'Dispositivi', icon: MonitorSmartphone },
  { view: 'telecamere', label: 'Telecamere', icon: Cctv },
  { view: 'allarmi', label: 'Allarmi', icon: BellRing },
  { view: 'operazioni', label: 'Operazioni', icon: Wrench },
  { view: 'assistente', label: 'Assistente', icon: MessageSquare },
  { view: 'report', label: 'Report', icon: FileText },
  { view: 'amministrazione', label: 'Amministrazione', icon: Settings2 },
]

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const view = useApp((s) => s.view)
  const navigate = useApp((s) => s.navigate)
  const router = useRouter()
  const { data: session } = useSession()

  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  })

  const h = health.data?.data
  const realtimeOk = h?.replay.enabled ?? false
  const dbOk = h?.dbReachable ?? false

  return (
    <aside className="flex h-full w-[248px] shrink-0 flex-col border-r border-border bg-sidebar-bg" aria-label="Navigazione principale">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-4">
        <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Radio className="size-5" aria-hidden />
        </div>
        <div>
          <p className="text-[15px] font-semibold leading-tight tracking-tight">FALCO-OS</p>
          <p className="text-[11px] text-text-2">Network Operations Center</p>
        </div>
      </div>

      <nav className="mt-1 flex-1 overflow-y-auto scroll-thin px-2" aria-label="Aree">
        <ul className="space-y-0.5">
          {NAV.map((item) => {
            const active = view === item.view
            return (
              <li key={item.view}>
                <button
                  onClick={() => { navigate(item.view); onNavigate?.() }}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-md px-3 py-2 text-[13px] font-medium transition-colors',
                    active ? 'bg-primary text-primary-foreground' : 'text-text-2 hover:bg-raised hover:text-foreground',
                  )}
                >
                  <item.icon className="size-4 shrink-0" aria-hidden />
                  <span className="truncate">{item.label}</span>
                  {active ? <ChevronRight className="ml-auto size-3.5 opacity-70" aria-hidden /> : null}
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Riquadro stato sistema (versione REALE del build + pipeline reale) */}
      <div className="border-t border-border p-3">
        <p className="px-1 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-dim">Stato sistema</p>
        <div className="rounded-lg bg-raised/60 p-3 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-text-2">Versione</span>
            <span className="num font-medium">{h?.version ?? '…'}</span>
          </div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="text-text-2">Database</span>
            <span className={cn('font-medium', dbOk ? 'text-ok' : 'text-crit')}>{dbOk ? 'Operativo' : 'Non raggiungibile'}</span>
          </div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="text-text-2">Riproduzione</span>
            <span className={cn('font-medium', realtimeOk ? 'text-ok' : 'text-warn')}>{realtimeOk ? 'Attiva' : 'Ferma'}</span>
          </div>
          {h?.replay.lastTickAt ? (
            <div className="mt-1.5 flex items-center justify-between">
              <span className="text-text-2">Ultimo ciclo</span>
              <span className="num text-text-2">
                {new Date(h.replay.lastTickAt).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
          ) : null}
        </div>
        <button
          onClick={() => { void signOut({ callbackUrl: '/' }) }}
          className="mt-2 flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-xs text-text-2 transition-colors hover:bg-raised hover:text-foreground"
        >
          <LogOut className="size-3.5" aria-hidden />
          Esci{session?.user?.name ? ` (${session.user.name})` : ''}
        </button>
      </div>
    </aside>
  )
}
