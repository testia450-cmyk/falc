/* ================================================================
 * FALCO-OS v16 — Gestione collegamenti topologici (16.10.0 W8)
 * L'operatore ha detto che la topologia riportata «non è realmente
 * così» e che le letture SNMP del bridge sono sbagliate: questo è
 * lo strumento per governare l'inventario REALE dei collegamenti
 * (TopologyLink del DB — 892 righe reali, zero confermate):
 *   · KPI e filtri per fonte/confidenza/conferma (stats del server);
 *   · CONFERMA un collegamento → cristallizzazione (verità operatore);
 *   · CORREGGI tipo/porte/velocità/etichetta/note (PATCH con diff);
 *   · ELIMINA lo sbagliato (audit TOPOLOGY_LINK_DELETE);
 *   · RIPULISCI in blocco le inferenze (dry-run onesto → esecuzione);
 *   · NUOVO collegamento manuale (verità dell'operatore, audit).
 * Nessun dato inventato: ogni riga/conto arriva da
 * /api/v2/topology/links. Errori server mostrati VERBATIM.
 * ================================================================ */

'use client'

import { useEffect, useMemo, useState } from 'react'
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Check, ChevronLeft, ChevronRight, Eraser, Loader2, MoreHorizontal, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { api, type CreateTopologyLinkInput, type PurgeLinksInput, type PurgeLinksResult, type TopologyLinkRow, type UpdateTopologyLinkInput } from '@/lib/client/api'
import { LINK_SOURCES, VALID_LINK_TYPES } from '@/lib/v2/contracts'
import { useApp } from '@/lib/client/store'
import { fmtNumber, typeLabel } from '@/lib/client/format'
import type { TopoNode } from '@/components/topology-view'
import { EmptyState, ErrorPanel } from '@/components/states'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { cn } from '@/lib/utils'

/* ---------------- Errori (messaggio server VERBATIM) ---------------- */

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof Error && 'code' in e && typeof (e as { code?: unknown }).code === 'string') {
    return { message: e.message, code: (e as { code: string }).code }
  }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

function errToast(title: string, e: unknown): void {
  const i = errInfo(e)
  toast.error(title, { description: `${i.message}${i.code ? ` (codice ${i.code})` : ''}` })
}

/* ---------------- Costanti di sezione ---------------- */

const PAGE_SIZE = 50

/** Colore del badge per sourceOfTruth (famiglie del §6.2):
 * operatore = verità (ok) · protocolli/UISP = dichiarati (info) ·
 * inferiti = letture SNMP fragili (warn). Valore ignoto → neutro. */
const SOURCE_BADGE_CLS: Record<string, string> = {
  TECHNICIAN: 'border-ok/40 bg-ok-soft text-ok',
  LLDP: 'border-info/40 bg-info-soft text-info',
  MNDP: 'border-info/40 bg-info-soft text-info',
  UISP: 'border-info/40 bg-info-soft text-info',
  INFERRED: 'border-warn/40 bg-warn-soft text-warn',
  FDB: 'border-warn/40 bg-warn-soft text-warn',
  BRIDGE_MIB: 'border-warn/40 bg-warn-soft text-warn',
  DAISY_CHAIN: 'border-warn/40 bg-warn-soft text-warn',
}

function sourceBadgeCls(source: string): string {
  return SOURCE_BADGE_CLS[source] ?? 'border-border bg-raised text-text-2'
}

/** Stati ammessi dal contratto PATCH (UpdateTopologyLinkInput). */
const LINK_STATUS_OPTIONS = ['ACTIVE', 'INACTIVE', 'DEGRADED', 'FAULTY', 'UNKNOWN'] as const

/** Famiglie ripulibili col purge (TECHNICIAN NON è offerto: contratto).
 * Pre-check: solo le inferenze — le letture bridge che l'operatore
 * ha dichiarato inaffidabili. */
const PURGE_FAMILIES = [
  {
    key: 'INFERRED',
    members: ['INFERRED', 'FDB', 'BRIDGE_MIB', 'DAISY_CHAIN'],
    label: 'Inferiti (bridge/FDB)',
    detail: 'INFERRED · FDB · BRIDGE_MIB · DAISY_CHAIN — letture SNMP del bridge',
  },
  {
    key: 'PROTOCOLS',
    members: ['LLDP', 'MNDP'],
    label: 'Protocolli (LLDP/MNDP)',
    detail: 'LLDP · MNDP — dichiarati dai dispositivi',
  },
  {
    key: 'UISP',
    members: ['UISP'],
    label: 'UISP',
    detail: 'UISP — dichiarati dalla gestione esterna',
  },
] as const

const DEFAULT_PURGE_CHECKED: Record<string, boolean> = { INFERRED: true, PROTOCOLS: false, UISP: false }

function linkName(row: { sourceHostname: string | null; sourceLabel: string }): string {
  return row.sourceHostname ?? row.sourceLabel ?? '?'
}
function linkTarget(row: { targetHostname: string | null; targetLabel: string }): string {
  return row.targetHostname ?? row.targetLabel ?? '?'
}

/* ---------------- Badge riutilizzabili (esportati: anche EdgeDetail della vista Rete) ---------------- */

export function SourceBadge({ source }: { source: string }) {
  return (
    <Badge variant="outline" className={cn('font-normal', sourceBadgeCls(source))} title={`fonte: ${source}`}>
      {source || 'n.d.'}
    </Badge>
  )
}

export function ConfidenceBadge({ confidence }: { confidence: string }) {
  if (confidence === 'HIGH') {
    return <Badge variant="outline" className="border-ok/40 bg-ok-soft text-ok">HIGH</Badge>
  }
  if (confidence === 'MEDIUM') {
    return <Badge variant="outline" className="border-warn/40 bg-warn-soft text-warn">MEDIUM</Badge>
  }
  return <Badge variant="outline" className="border-border bg-raised text-text-2">{confidence || '—'}</Badge>
}

/* ---------------- Selettore dispositivo (Command combobox) ---------------- */

function DevicePicker({
  nodes, value, onChange, ariaLabel, placeholder, excludeId,
}: {
  nodes: TopoNode[]
  value: string | null
  onChange: (id: string | null) => void
  ariaLabel: string
  placeholder: string
  excludeId?: string | null
}) {
  const [open, setOpen] = useState(false)
  const selected = nodes.find((n) => n.id === value) ?? null
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button" variant="outline"
          className="h-10 w-full justify-between font-normal"
          aria-label={ariaLabel}
          aria-expanded={open}
          aria-haspopup="listbox"
        >
          {selected ? (
            <>
              <span className="min-w-0 truncate">{selected.hostname}</span>
              <span className="num ml-2 shrink-0 text-xs text-text-2">{selected.ip || 'n.d.'}</span>
            </>
          ) : (
            <span className="truncate text-text-2">{placeholder}</span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[min(92vw,380px)] p-0" align="start">
        <Command>
          <CommandInput placeholder="Cerca hostname, IP, tipo…" />
          <CommandList>
            <CommandEmpty>Nessun dispositivo trovato con questa ricerca.</CommandEmpty>
            <CommandGroup heading={`Nodi reali dell'albero (${fmtNumber(nodes.length)})`}>
              {nodes.map((n) => {
                const excluded = excludeId != null && n.id === excludeId
                return (
                  <CommandItem
                    key={n.id}
                    value={`${n.hostname} ${n.ip} ${typeLabel(n.type)}`}
                    disabled={excluded}
                    onSelect={() => { onChange(n.id); setOpen(false) }}
                    aria-label={`${n.hostname} (${typeLabel(n.type)})${excluded ? ' — già scelto dall’altro capo' : ''}`}
                  >
                    {value === n.id ? <Check className="size-4 shrink-0 text-ok" aria-hidden /> : <span className="size-4 shrink-0" aria-hidden />}
                    <span className="min-w-0 flex-1 truncate">{n.hostname}</span>
                    <span className="ml-2 shrink-0 text-xs text-text-2">{typeLabel(n.type)}</span>
                    <span className="num ml-2 shrink-0 text-xs text-text-2">{n.ip || 'n.d.'}</span>
                  </CommandItem>
                )
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}

/* ---------------- Dialog: crea / correggi collegamento ---------------- */

/** Campi del form (vissuti nel PADRE: prefill/reset negli handler di
 * apertura/chiusura — convenzione utenti-permessi, nessun effetto). */
interface LinkFormFields {
  sourceId: string | null
  targetId: string | null
  linkType: string
  linkStatus: string
  label: string
  sourcePort: string
  targetPort: string
  speedRaw: string
  notes: string
}

const EMPTY_FIELDS: LinkFormFields = {
  sourceId: null, targetId: null, linkType: 'ETHERNET', linkStatus: 'ACTIVE',
  label: '', sourcePort: '', targetPort: '', speedRaw: '', notes: '',
}

/** Prefill dai dati REALI della riga (valori storici fuori vocabolario
 * restano visibili come opzione «(valore storico)», mai alterati di nascosto). */
function fieldsFromRow(row: TopologyLinkRow): LinkFormFields {
  return {
    sourceId: row.sourceDeviceId,
    targetId: row.targetDeviceId,
    linkType: row.linkType || 'ETHERNET',
    linkStatus: (LINK_STATUS_OPTIONS as readonly string[]).includes(row.linkStatus) ? row.linkStatus : 'ACTIVE',
    label: row.label,
    sourcePort: row.sourcePort,
    targetPort: row.targetPort,
    speedRaw: row.speedMbps > 0 ? String(row.speedMbps) : '',
    notes: row.notes,
  }
}

function LinkFormDialog({
  open, onOpenChange, nodes, plantId, editing, fields, setFields,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  nodes: TopoNode[]
  plantId: string | null
  editing: TopologyLinkRow | null
  fields: LinkFormFields
  setFields: React.Dispatch<React.SetStateAction<LinkFormFields>>
}) {
  const queryClient = useQueryClient()
  const isEdit = editing != null
  const [validation, setValidation] = useState<string | null>(null)

  const { sourceId, targetId, linkType, linkStatus, label, sourcePort, targetPort, speedRaw, notes } = fields
  const patch = (p: Partial<LinkFormFields>) => { setFields((prev) => ({ ...prev, ...p })) }

  /* Opzioni tipo: VALID_LINK_TYPES + il valore storico della riga (se
   * fuori vocabolario) per non alterarlo silenziosamente in modifica. */
  const typeOptions = useMemo(() => {
    const list: string[] = [...VALID_LINK_TYPES]
    if (editing && editing.linkType && !list.includes(editing.linkType)) list.unshift(editing.linkType)
    return list
  }, [editing])

  const parsedSpeed = speedRaw.trim() === '' ? null : Number.parseInt(speedRaw.trim(), 10)
  /* Patch con SOLO i campi effettivamente cambiati (stesso principio del
   * diff server): un campo non toccato non viene inviato. */
  const dirtyFields = useMemo(() => {
    if (!editing) return -1
    let n = 0
    if (linkType !== editing.linkType && (VALID_LINK_TYPES as readonly string[]).includes(linkType)) n += 1
    if (linkStatus !== editing.linkStatus) n += 1
    if (label !== editing.label) n += 1
    if (sourcePort !== editing.sourcePort) n += 1
    if (targetPort !== editing.targetPort) n += 1
    if (parsedSpeed != null && parsedSpeed !== editing.speedMbps) n += 1
    if (notes !== editing.notes) n += 1
    return n
  }, [editing, linkType, linkStatus, label, sourcePort, targetPort, parsedSpeed, notes])

  const save = useMutation({
    mutationFn: () => {
      if (isEdit && editing) {
        const patch: UpdateTopologyLinkInput = {}
        if (linkType !== editing.linkType && (VALID_LINK_TYPES as readonly string[]).includes(linkType)) {
          patch.linkType = linkType as UpdateTopologyLinkInput['linkType']
        }
        if (linkStatus !== editing.linkStatus) patch.linkStatus = linkStatus as UpdateTopologyLinkInput['linkStatus']
        if (label !== editing.label) patch.label = label
        if (sourcePort !== editing.sourcePort) patch.sourcePort = sourcePort
        if (targetPort !== editing.targetPort) patch.targetPort = targetPort
        if (parsedSpeed != null && parsedSpeed !== editing.speedMbps) patch.speedMbps = parsedSpeed
        if (notes !== editing.notes) patch.notes = notes
        return api.updateTopologyLink(editing.id, patch)
      }
      const input: CreateTopologyLinkInput = {
        plantId: plantId ?? '',
        sourceDeviceId: sourceId ?? '',
        targetDeviceId: targetId ?? '',
        linkType: linkType as CreateTopologyLinkInput['linkType'],
      }
      if (label.trim()) input.label = label.trim()
      if (sourcePort.trim()) input.sourcePort = sourcePort.trim()
      if (targetPort.trim()) input.targetPort = targetPort.trim()
      if (parsedSpeed != null && Number.isFinite(parsedSpeed)) input.speedMbps = parsedSpeed
      if (notes.trim()) input.notes = notes.trim()
      return api.createTopologyLink(input)
    },
    onSuccess: (row) => {
      toast.success(isEdit ? 'Collegamento corretto' : 'Collegamento creato', {
        description: `«${linkName(row)} → ${linkTarget(row)}» — ${isEdit ? 'modifica reale nel DB (audit TOPOLOGY_LINK_UPDATE)' : 'verità dell’operatore: confermato, HIGH, TECHNICIAN (audit TOPOLOGY_LINK_CREATE)'}.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      onOpenChange(false)
    },
    onError: (err) => { errToast(isEdit ? 'Correzione non riuscita' : 'Creazione non riuscita', err) },
  })

  const submit = () => {
    setValidation(null)
    if (!isEdit) {
      if (!sourceId || !targetId) {
        setValidation('Scegli entrambi i dispositivi (monte e valle).')
        return
      }
      if (sourceId === targetId) {
        setValidation('Sorgente e destinazione devono essere dispositivi diversi.')
        return
      }
    }
    if (isEdit && dirtyFields === 0) {
      setValidation('Nessuna modifica effettiva: cambia almeno un campo.')
      return
    }
    save.mutate()
  }

  const invalidSpeed = speedRaw.trim() !== '' && (parsedSpeed == null || Number.isNaN(parsedSpeed) || parsedSpeed < 0)

  /* Chiusura guidata dagli EVENTI (niente effetti): la validazione si
   * pulisce qui, i campi li resetta/prefilla il padre all'apertura. */
  const handleOpenChange = (o: boolean) => {
    if (!o) setValidation(null)
    if (o || !save.isPending) onOpenChange(o)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] w-[95vw] max-w-2xl overflow-y-auto scroll-thin">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Correggi collegamento' : 'Nuovo collegamento'}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? 'Correggi cablatura e metadati del collegamento reale: ogni campo cambiato finisce nel diff dell’audit (TOPOLOGY_LINK_UPDATE).'
              : 'Il collegamento nasce come verità dell’operatore: confermato, confidenza HIGH, fonte TECHNICIAN (audit TOPOLOGY_LINK_CREATE).'}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 sm:grid-cols-2">
          {isEdit && editing ? (
            <div className="sm:col-span-2 grid gap-2 rounded-md border border-border/70 bg-raised/40 p-3 text-xs">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-text-2">Estremi (non modificabili)</p>
              <p className="truncate font-medium">{linkName(editing)} <span aria-hidden>→</span> {linkTarget(editing)}</p>
              <p className="num truncate text-[10px] text-text-2">{editing.sourceIp} → {editing.targetIp}</p>
            </div>
          ) : (
            <>
              <div className="space-y-1.5">
                <Label>Dispositivo a monte</Label>
                <DevicePicker
                  nodes={nodes}
                  value={sourceId}
                  onChange={(id) => patch({ sourceId: id })}
                  ariaLabel="Dispositivo a monte"
                  placeholder="Cerca il dispositivo a monte…"
                  excludeId={targetId}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Dispositivo a valle</Label>
                <DevicePicker
                  nodes={nodes}
                  value={targetId}
                  onChange={(id) => patch({ targetId: id })}
                  ariaLabel="Dispositivo a valle"
                  placeholder="Cerca il dispositivo a valle…"
                  excludeId={sourceId}
                />
              </div>
            </>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="link-type">Tipo collegamento</Label>
            <Select value={linkType} onValueChange={(v) => patch({ linkType: v })}>
              <SelectTrigger id="link-type" className="w-full" aria-label="Tipo di collegamento">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {typeOptions.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}{!(VALID_LINK_TYPES as readonly string[]).includes(t) ? ' (valore storico)' : ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {isEdit ? (
            <div className="space-y-1.5">
              <Label htmlFor="link-status">Stato</Label>
              <Select value={linkStatus} onValueChange={(v) => patch({ linkStatus: v })}>
                <SelectTrigger id="link-status" className="w-full" aria-label="Stato del collegamento">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LINK_STATUS_OPTIONS.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}

          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="link-label">Etichetta (opzionale)</Label>
            <Input
              id="link-label" value={label} onChange={(e) => patch({ label: e.target.value })}
              maxLength={200} placeholder="es. uplink principale sede municipio"
              aria-label="Etichetta del collegamento"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="link-source-port">Porta a monte (opzionale)</Label>
            <Input
              id="link-source-port" value={sourcePort} onChange={(e) => patch({ sourcePort: e.target.value })}
              maxLength={100} placeholder="es. ether2" className="num"
              aria-label="Porta sul dispositivo a monte"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="link-target-port">Porta a valle (opzionale)</Label>
            <Input
              id="link-target-port" value={targetPort} onChange={(e) => patch({ targetPort: e.target.value })}
              maxLength={100} placeholder="es. sfp1" className="num"
              aria-label="Porta sul dispositivo a valle"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="link-speed">Velocità Mbps (opzionale)</Label>
            <Input
              id="link-speed" value={speedRaw} onChange={(e) => patch({ speedRaw: e.target.value })}
              inputMode="numeric" placeholder="es. 1000" className="num"
              aria-invalid={invalidSpeed || undefined}
              aria-label="Velocità del collegamento in megabit al secondo"
            />
            {invalidSpeed ? <p className="text-xs text-crit" role="alert">Velocità non valida: numero intero ≥ 0.</p> : null}
          </div>

          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="link-notes">Note (opzionale)</Label>
            <Textarea
              id="link-notes" value={notes} onChange={(e) => patch({ notes: e.target.value })}
              maxLength={1000} rows={3} placeholder="contesto, percorso del cavo, fondamento della correzione…"
              aria-label="Note sul collegamento"
            />
          </div>
        </div>

        {validation ? (
          <p className="text-xs text-crit" role="alert">{validation}</p>
        ) : isEdit && dirtyFields === 0 ? (
          <p className="text-xs text-text-2" role="note">Nessun campo cambiato finora.</p>
        ) : null}

        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)} disabled={save.isPending}>
            Annulla
          </Button>
          <Button onClick={submit} disabled={save.isPending || invalidSpeed}>
            {save.isPending ? <Loader2 className="mr-1 size-4 animate-spin" aria-hidden /> : isEdit ? <Pencil className="mr-1 size-4" aria-hidden /> : <Plus className="mr-1 size-4" aria-hidden />}
            {isEdit ? 'Salva correzioni' : 'Crea collegamento'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Dialog: ripulisci inferenze (dry-run → esecuzione) ---------------- */

function PurgeDialog({
  open, onOpenChange, plantId,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  plantId: string | null
}) {
  const queryClient = useQueryClient()
  const [checked, setChecked] = useState<Record<string, boolean>>({ ...DEFAULT_PURGE_CHECKED })
  const [result, setResult] = useState<PurgeLinksResult | null>(null)

  const members = useMemo(
    () => PURGE_FAMILIES.filter((f) => checked[f.key]).flatMap((f) => [...f.members]) as PurgeLinksInput['sources'],
    [checked],
  )

  const dryRun = useMutation({
    mutationFn: () => api.purgeTopologyLinks({ plantId: plantId ?? '', sources: members, dryRun: true }),
    onSuccess: (res) => { setResult(res) },
    onError: (err) => { errToast('Conteggio non riuscito', err) },
  })

  const purgeExec = useMutation({
    mutationFn: () => api.purgeTopologyLinks({ plantId: plantId ?? '', sources: members, dryRun: false }),
    onSuccess: (res) => {
      toast.success(`Inferenze ripulite: ${fmtNumber(res.count)} collegamenti eliminati`, {
        description: 'Eliminazione reale in un’unica transazione (audit TOPOLOGY_LINK_PURGE). I collegamenti confermati e quelli dell’operatore NON sono mai stati toccati.',
      })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      closePurge()
    },
    onError: (err) => { errToast('Pulizia non riuscita', err) },
  })

  /* Reset del perimetro e del dry-run ALLA CHIUSURA (event handler,
   * convenzione del progetto: nessun setState negli effetti) → ogni
   * riapertura parte dal perimetro di default con conteggio da rifare. */
  const resetPurgeState = () => {
    setChecked({ ...DEFAULT_PURGE_CHECKED })
    setResult(null)
    dryRun.reset()
  }

  const closePurge = () => {
    resetPurgeState()
    onOpenChange(false)
  }

  const toggleFamily = (key: string) => {
    setChecked((prev) => ({ ...prev, [key]: !prev[key] }))
    setResult(null) /* perimetro cambiato → il conteggio va rifatto */
    dryRun.reset()
  }

  return (
    <AlertDialog open={open} onOpenChange={(o) => { if (o) onOpenChange(true); else if (!purgeExec.isPending) closePurge() }}>
      <AlertDialogContent className="max-h-[90vh] w-[95vw] max-w-lg overflow-y-auto scroll-thin">
        <AlertDialogHeader>
          <AlertDialogTitle>Ripulisci le inferenze</AlertDialogTitle>
          <AlertDialogDescription>
            Elimina in blocco i collegamenti NON confermati delle fonti scelte. I collegamenti confermati e quelli
            dell’operatore NON vengono mai toccati. Atto tracciato nell’audit.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <fieldset className="space-y-2" aria-label="Fonti da ripulire">
          <legend className="text-xs font-medium text-text-2">Fonti da ripulire (operatore escluso: è verità)</legend>
          {PURGE_FAMILIES.map((f) => (
            <label
              key={f.key}
              className={cn(
                'flex cursor-pointer items-start gap-2.5 rounded-md border px-3 py-2 text-xs transition-colors',
                checked[f.key] ? 'border-warn/40 bg-warn-soft/50' : 'border-border bg-surface hover:bg-raised/50',
              )}
            >
              <Checkbox
                checked={checked[f.key]}
                onCheckedChange={() => toggleFamily(f.key)}
                aria-label={`${f.label}: ${f.detail}`}
                className="mt-0.5"
              />
              <span className="min-w-0">
                <span className="block font-medium">{f.label}</span>
                <span className="block text-text-2">{f.detail}</span>
              </span>
            </label>
          ))}
        </fieldset>

        <div className="flex flex-wrap gap-2">
          <Button
            type="button" variant="outline" size="sm" className="h-9"
            onClick={() => dryRun.mutate()}
            disabled={members.length === 0 || dryRun.isPending || purgeExec.isPending || !plantId}
            aria-label="Conta cosa sparirebbe (dry-run, nessuna scrittura)"
          >
            {dryRun.isPending ? <Loader2 className="mr-1 size-3.5 animate-spin" aria-hidden /> : <Search className="mr-1 size-3.5" aria-hidden />}
            Conta cosa sparirebbe
          </Button>
        </div>

        {result ? (
          <div className="rounded-md border border-border bg-raised/40 p-3 text-xs" role="status" aria-live="polite">
            <p className="font-medium">
              <span className="num">{fmtNumber(result.count)}</span>{' '}
              collegamenti verrebbero eliminati{members.length > 0 ? ` (fonti: ${members.join(', ')})` : ''}.
            </p>
            {result.sample.length > 0 ? (
              <ul className="mt-2 max-h-40 space-y-1 overflow-y-auto scroll-thin">
                {result.sample.map((s, i) => (
                  <li key={i} className="truncate text-[11px] text-text-2" title={`${s.sourceHostname} → ${s.targetHostname} · ${s.sourceOfTruth}`}>
                    {s.sourceHostname} <span aria-hidden>→</span> {s.targetHostname} · <span className="num">{s.sourceOfTruth}</span>
                  </li>
                ))}
              </ul>
            ) : null}
            <p className="mt-1.5 text-[10px] text-dim">
              Dry-run: NESSUNA scrittura. Campione di {result.sample.length} righe sul totale di {fmtNumber(result.count)}.
            </p>
          </div>
        ) : null}

        <AlertDialogFooter>
          <AlertDialogCancel disabled={purgeExec.isPending}>Annulla</AlertDialogCancel>
          <AlertDialogAction
            className="bg-crit-solid text-white hover:bg-crit-solid/90"
            disabled={!result || result.count === 0 || purgeExec.isPending || dryRun.isPending || !plantId}
            onClick={(e) => {
              e.preventDefault() /* resta aperto finché la risposta reale non arriva */
              purgeExec.mutate()
            }}
          >
            {purgeExec.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
            Elimina {result ? fmtNumber(result.count) : '…'} collegamenti
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

/* ---------------- Componente principale ---------------- */

export interface TopologyLinksManagerProps {
  open: boolean
  onOpenChange: (o: boolean) => void
  /** Nodi del grafo corrente (per i selettori del nuovo collegamento). */
  nodes: TopoNode[]
}

export function TopologyLinksManager({ open, onOpenChange, nodes }: TopologyLinksManagerProps) {
  const queryClient = useQueryClient()
  const activePlantId = useApp((s) => s.activePlantId)

  const plants = useQuery({
    queryKey: ['plants'],
    queryFn: () => api.plants(),
    staleTime: 300_000,
    enabled: open,
  })
  const plantId = activePlantId ?? plants.data?.data?.reduce((a, b) => (a.createdAt <= b.createdAt ? a : b))?.id ?? null

  /* --- Filtri (server-side; q con debounce 300 ms) --- */
  const [qInput, setQInput] = useState('')
  const [q, setQ] = useState('')
  const [source, setSource] = useState('all')
  const [confidence, setConfidence] = useState('all')
  const [confirmed, setConfirmed] = useState('all')
  const [page, setPage] = useState(1)

  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim())
      setPage(1)
    }, 300)
    return () => clearTimeout(t)
  }, [qInput])

  const links = useQuery({
    queryKey: ['topology-links', { source, confidence, confirmed, q, page }],
    queryFn: () => api.topologyLinks({
      source: source === 'all' ? undefined : source,
      confidence: confidence === 'all' ? undefined : confidence,
      confirmed: confirmed === 'all' ? undefined : (confirmed as 'true' | 'false'),
      q: q || undefined,
      page,
      pageSize: PAGE_SIZE,
    }),
    placeholderData: keepPreviousData,
    staleTime: 30_000,
    enabled: open,
  })
  const data = links.data?.data
  const rows = data?.links ?? []
  const total = data?.total ?? 0
  const shownPage = data?.page ?? 1
  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE))
  const stats = data?.stats

  /* --- Azioni riga --- */
  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<TopologyLinkRow | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<TopologyLinkRow | null>(null)
  const [purgeOpen, setPurgeOpen] = useState(false)
  /* Campi del form crea/correggi: prefill/reset negli handler (pattern
   * utenti-permessi — mai setState dentro un effetto). */
  const [formFields, setFormFields] = useState<LinkFormFields>(EMPTY_FIELDS)

  const openCreate = () => {
    setFormFields(EMPTY_FIELDS)
    setEditTarget(null)
    setCreateOpen(true)
  }

  const openEdit = (row: TopologyLinkRow) => {
    setFormFields(fieldsFromRow(row))
    setEditTarget(row)
  }

  const confirmLink = useMutation({
    mutationFn: (row: TopologyLinkRow) => api.updateTopologyLink(row.id, { confirmed: true }),
    onSuccess: (updated) => {
      toast.success('Collegamento confermato', {
        description: `«${linkName(updated)} → ${linkTarget(updated)}» — ora è verità dell’operatore (audit TOPOLOGY_LINK_UPDATE, cristallizzazione).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
    },
    onError: (err) => { errToast('Conferma non riuscita', err) },
  })

  const removeLink = useMutation({
    mutationFn: (row: TopologyLinkRow) => api.deleteTopologyLink(row.id),
    onSuccess: (_res, row) => {
      toast.success('Collegamento eliminato', {
        description: `«${linkName(row)} → ${linkTarget(row)}» rimosso dall’inventario reale (audit TOPOLOGY_LINK_DELETE).`,
      })
      setDeleteTarget(null)
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
    },
    onError: (err) => { errToast('Eliminazione non riuscita', err) },
  })

  const rowBusy = (row: TopologyLinkRow): boolean =>
    (confirmLink.isPending && confirmLink.variables?.id === row.id) ||
    (removeLink.isPending && removeLink.variables?.id === row.id)

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="flex max-h-[92vh] w-[95vw] max-w-4xl flex-col gap-4 overflow-y-auto scroll-thin">
          <DialogHeader>
            <DialogTitle>Gestione collegamenti topologici</DialogTitle>
            <DialogDescription>
              Inventario reale dei collegamenti dell’impianto: conferma quelli giusti, correggili, elimina gli
              sbagliati, ripulisci le inferenze in blocco. Ogni atto è tracciato nell’audit.
            </DialogDescription>
          </DialogHeader>

          {/* a) KPI: stats sull'inventario COMPLETO (dal server) */}
          {links.isError ? (
            <ErrorPanel
              message={(links.error as Error).message}
              code={(links.error as { code?: string }).code}
              onRetry={() => { void links.refetch() }}
            />
          ) : (
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-border bg-raised/30 px-3 py-2.5">
              {stats ? (
                <>
                  <span className="flex items-baseline gap-1.5">
                    <span className="num text-2xl font-semibold leading-none">{fmtNumber(stats.total)}</span>
                    <span className="text-xs text-text-2">collegamenti in inventario</span>
                  </span>
                  <span className="flex items-baseline gap-1.5">
                    <span className="num text-lg font-semibold leading-none text-ok">{fmtNumber(stats.confirmed)}</span>
                    <span className="text-xs text-text-2">confermati</span>
                  </span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    {stats.bySource.map((s) => (
                      <Badge key={s.source} variant="outline" className={sourceBadgeCls(s.source)} title={`${s.count} collegamenti con sourceOfTruth ${s.source}`}>
                        <span className="num">{fmtNumber(s.count)}</span> {s.source}
                      </Badge>
                    ))}
                  </span>
                </>
              ) : (
                <div className="flex w-full items-center gap-3" role="status" aria-busy="true">
                  <Skeleton className="h-7 w-24" />
                  <Skeleton className="h-5 w-20" />
                  <Skeleton className="h-5 w-40" />
                </div>
              )}
            </div>
          )}

          {/* b) Filtri */}
          <div className="flex flex-wrap items-center gap-2">
            <Input
              value={qInput}
              onChange={(e) => setQInput(e.target.value)}
              placeholder="Cerca hostname, IP, etichetta, note…"
              aria-label="Ricerca testuale nei collegamenti"
              className="h-9 w-full sm:w-56"
            />
            <Select value={source} onValueChange={(v) => { setSource(v); setPage(1) }}>
              <SelectTrigger className="w-full sm:w-[190px]" aria-label="Filtra per fonte (sourceOfTruth)">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                <SelectItem value="all">Tutte le fonti</SelectItem>
                {LINK_SOURCES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={confidence} onValueChange={(v) => { setConfidence(v); setPage(1) }}>
              <SelectTrigger className="w-full sm:w-[150px]" aria-label="Filtra per confidenza">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Confidenza: tutte</SelectItem>
                <SelectItem value="HIGH">HIGH</SelectItem>
                <SelectItem value="MEDIUM">MEDIUM</SelectItem>
                <SelectItem value="LOW">LOW</SelectItem>
                <SelectItem value="EMPTY">— (vuota)</SelectItem>
              </SelectContent>
            </Select>
            <Select value={confirmed} onValueChange={(v) => { setConfirmed(v); setPage(1) }}>
              <SelectTrigger className="w-full sm:w-[170px]" aria-label="Filtra per conferma dell'operatore">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti</SelectItem>
                <SelectItem value="true">Confermati</SelectItem>
                <SelectItem value="false">Non confermati</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* d) + e) Azioni in blocco */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-text-2">
              {stats ? (
                <>
                  <span className="num font-medium text-foreground">{fmtNumber(stats.confirmed)}</span>
                  {' '}di <span className="num">{fmtNumber(stats.total)}</span> confermati dall’operatore: ogni conferma
                  entra sempre nell’albero, quale che sia il filtro delle fonti.
                </>
              ) : null}
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button" variant="outline" size="sm" className="h-9 border-warn/40 bg-warn-soft text-warn hover:bg-warn-soft/70"
                onClick={() => setPurgeOpen(true)}
                disabled={!plantId}
                title="Eliminazione in blocco delle inferenze NON confermate, con conteggio preventivo"
              >
                <Eraser className="mr-1 size-3.5" aria-hidden />
                Ripulisci inferenze
              </Button>
              <Button
                type="button" size="sm" className="h-9"
                onClick={openCreate}
                disabled={!plantId || nodes.length === 0}
                title={nodes.length === 0 ? 'Nessun nodo del grafo disponibile per i selettori' : 'Crea un collegamento manuale: verità dell’operatore'}
              >
                <Plus className="mr-1 size-3.5" aria-hidden />
                Nuovo collegamento
              </Button>
            </div>
          </div>

          {/* c) Tabella */}
          {links.isLoading ? (
            <div role="status" aria-busy="true" className="space-y-2">
              <span className="sr-only">Caricamento collegamenti…</span>
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full rounded-md" />
              ))}
            </div>
          ) : links.isError ? null /* già ErrorPanel sopra nei KPI */ : rows.length === 0 ? (
            <EmptyState
              title="Nessun collegamento corrisponde ai filtri"
              description={
                total === 0 && !q && source === 'all' && confidence === 'all' && confirmed === 'all'
                  ? 'L’inventario dei collegamenti dell’impianto è vuoto: il primo nasce da «Nuovo collegamento».'
                  : 'Cambia ricerca, fonte, confidenza o stato conferma: l’elenco contiene SOLO collegamenti reali del DB.'
              }
            />
          ) : (
            <div
              className="max-h-96 overflow-auto scroll-thin rounded-lg border border-border"
              role="region"
              aria-label="Tabella collegamenti topologici"
              tabIndex={0}
            >
              <Table>
                <TableCaption>
                  Collegamenti reali dell’inventario · {PAGE_SIZE} righe per pagina · «Conferma» cristallizza come
                  verità dell’operatore · ogni azione è in audit
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead scope="col" className="min-w-[210px]">Collegamento</TableHead>
                    <TableHead scope="col" className="min-w-[110px]">Tipo</TableHead>
                    <TableHead scope="col" className="min-w-[110px]">Fonte</TableHead>
                    <TableHead scope="col" className="min-w-[90px]">Confidenza</TableHead>
                    <TableHead scope="col" className="min-w-[90px]">Confermato</TableHead>
                    <TableHead scope="col" className="min-w-[120px]">Porte</TableHead>
                    <TableHead scope="col" className="min-w-[90px]">Velocità</TableHead>
                    <TableHead scope="col" className="w-[70px] text-right">Azioni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow
                      key={row.id}
                      className={cn('hover:bg-raised/50', rowBusy(row) && 'opacity-60')}
                      aria-label={`Collegamento ${linkName(row)} → ${linkTarget(row)}, fonte ${row.sourceOfTruth}`}
                    >
                      <TableCell>
                        <p className="truncate text-[13px] font-medium" title={`${linkName(row)} → ${linkTarget(row)}`}>
                          {linkName(row)} <span aria-hidden className="text-text-2">→</span> {linkTarget(row)}
                        </p>
                        <p className="num truncate text-[10px] text-text-2" title={`${row.sourceIp} → ${row.targetIp}`}>
                          {row.sourceIp} <span aria-hidden>→</span> {row.targetIp}
                        </p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="border-border bg-raised text-text-2">{row.linkType || 'n.d.'}</Badge>
                      </TableCell>
                      <TableCell><SourceBadge source={row.sourceOfTruth} /></TableCell>
                      <TableCell><ConfidenceBadge confidence={row.confidence} /></TableCell>
                      <TableCell>
                        {row.confirmed ? (
                          <span className="inline-flex items-center gap-1 text-ok" title="Confermato dall'operatore: verità">
                            <Check className="size-3.5" aria-hidden />
                            <span className="sr-only">confermato</span>
                          </span>
                        ) : (
                          <span className="text-dim" title="Bozza non confermata">—</span>
                        )}
                      </TableCell>
                      <TableCell className="num text-text-2">
                        {row.sourcePort || row.targetPort ? (
                          <span title={`${row.sourcePort || '—'} → ${row.targetPort || '—'}`}>
                            {row.sourcePort || '—'} <span aria-hidden>→</span> {row.targetPort || '—'}
                          </span>
                        ) : (
                          <span className="text-dim">—</span>
                        )}
                      </TableCell>
                      <TableCell className="num text-text-2">
                        {row.speedMbps > 0 ? `${fmtNumber(row.speedMbps)} Mbps` : <span className="text-dim">—</span>}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost" size="sm"
                              className="size-8 p-0"
                              aria-label={`Azioni sul collegamento ${linkName(row)} → ${linkTarget(row)}`}
                              disabled={rowBusy(row)}
                            >
                              {rowBusy(row) ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <MoreHorizontal className="size-4" aria-hidden />}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => confirmLink.mutate(row)}
                              disabled={row.confirmed || confirmLink.isPending}
                              title={row.confirmed ? 'Già confermato: è verità dell’operatore' : 'Cristallizza: confirmed=true, fonte TECHNICIAN'}
                            >
                              <Check className="size-4" aria-hidden /> Conferma
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEdit(row)}>
                              <Pencil className="size-4" aria-hidden /> Modifica…
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setDeleteTarget(row)} className="text-crit focus:text-crit">
                              <Trash2 className="size-4" aria-hidden /> Elimina…
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Paginazione reale */}
          {!links.isError && !links.isLoading && total > 0 ? (
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs text-text-2">
                Pagina <span className="num">{shownPage}</span> di <span className="num">{pageCount}</span> ·{' '}
                <span className="num">{fmtNumber(total)}</span> collegamenti con i filtri attuali
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline" size="sm" className="h-9"
                  disabled={shownPage <= 1 || links.isFetching}
                  onClick={() => setPage(shownPage - 1)}
                >
                  <ChevronLeft className="size-3.5" aria-hidden />
                  Precedente
                </Button>
                <Button
                  variant="outline" size="sm" className="h-9"
                  disabled={shownPage >= pageCount || links.isFetching}
                  onClick={() => setPage(shownPage + 1)}
                >
                  Successiva
                  <ChevronRight className="size-3.5" aria-hidden />
                </Button>
              </div>
            </div>
          ) : null}

          <p className="text-[11px] text-dim">
            Ogni riga è un collegamento REALE dell’inventario (TopologyLink del DB): fonte, confidenza, conferma e
            porte sono i campi reali. Le azioni sono consentite al ruolo TECNICO o superiore (il server le fa
            rispettare).
          </p>
        </DialogContent>
      </Dialog>

      {/* Dialog annidati: crea / correggi / purge / elimina */}
      <LinkFormDialog
        open={createOpen || editTarget != null}
        onOpenChange={(o) => { if (!o) { setCreateOpen(false); setEditTarget(null) } }}
        nodes={nodes}
        plantId={plantId}
        editing={editTarget}
        fields={formFields}
        setFields={setFormFields}
      />
      <PurgeDialog open={purgeOpen} onOpenChange={setPurgeOpen} plantId={plantId} />

      <AlertDialog open={deleteTarget != null} onOpenChange={(o) => { if (!o) setDeleteTarget(null) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Elimina collegamento</AlertDialogTitle>
            <AlertDialogDescription>
              Il collegamento {deleteTarget ? `${linkName(deleteTarget)} → ${linkTarget(deleteTarget)}` : ''} verrà
              eliminato dall’inventario.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={removeLink.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={removeLink.isPending}
              onClick={(e) => {
                e.preventDefault() /* resta aperto finché la risposta reale non arriva */
                if (deleteTarget) removeLink.mutate(deleteTarget)
              }}
            >
              {removeLink.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
