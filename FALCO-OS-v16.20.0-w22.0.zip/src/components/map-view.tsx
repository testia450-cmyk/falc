/* Mappa geografica (§6.2): sedi reali con coordinate; marker con
 * scrim + etichetta leggibile (difetto mockup §3.3.4); tile OSM
 * («Mappa») e ArcGIS World Imagery («Satellite»), come il repo v15;
 * attribuzioni VISIBILI (condizioni d'uso); filtri stato; contrasto.
 * v16.17 W18 (pattern UISP): click sul punto → POPUP con nome sede e
 * conteggi stato; prop linkLines per disegnare i collegamenti REALI
 * della topologia tra le sedi sul territorio. */

'use client'

import { useEffect, useMemo, useRef } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTheme } from 'next-themes'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import { api } from '@/lib/client/api'
import { usePalette, useIsHydrated, statusColor } from '@/lib/client/theme-palette'
import { cn } from '@/lib/utils'

/* I colori dei marker seguono il tema attivo (palette JS §4.2):
 * scuro = token mockup, chiaro = token chiari con contrastì verificati. */

export interface MapViewProps {
  height?: string
  provider?: 'osm' | 'sat'
  onProviderChange?: (p: 'osm' | 'sat') => void
  selectedLocationId?: string | null
  onSelectLocation?: (id: string) => void
  filter?: (status: string | null) => boolean
  compact?: boolean
  /** v16.17 W18: collegamenti tra sedi disegnati sul territorio
   * (fonte: topologia reale — radio/LAN/fibra tra sedi DIVERSE).
   * Retta onesta: nessuna curva «decorativa», il dato decide. */
  linkLines?: MapLinkLine[]
}

export interface MapLinkLine {
  from: [number, number]
  to: [number, number]
  color: string
  dashed?: boolean
  weight?: number
  tooltip: string
}

export function MapView({
  height = '100%',
  provider = 'osm',
  onProviderChange,
  selectedLocationId,
  onSelectLocation,
  filter,
  compact = false,
  linkLines = [],
}: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const mapRef = useRef<L.Map | null>(null)
  const markersRef = useRef<L.Marker[]>([])
  const linesRef = useRef<L.Polyline[]>([])
  const tileRef = useRef<L.TileLayer | null>(null)
  /* v16.17 W18: ultima sede il cui popup è stato aperto automaticamente
   * (dalla selezione) — per non riaprirlo sui soli refresh dei dati. */
  const lastPopupIdRef = useRef<string | null>(null)
  const palette = usePalette()
  /* Tile coerenti col tema: scuro → CartoDB dark (estetica NOC dei
   * mockup); chiaro → OpenStreetMap standard. */
  const { resolvedTheme } = useTheme()
  const isLight = useIsHydrated() && resolvedTheme === 'light'

  const locs = useQuery({
    queryKey: ['map-locations'],
    queryFn: () => api.locations(),
    staleTime: 60_000,
  })

  /* 16.13 W11 — centro mappa dell'impianto ATTIVO (era hardcoded su
   * Sant'Egidio): con sedi senza coordinate la mappa parte comunque
   * dal centro reale dell'impianto, non da quello di un altro. */
  const plants = useQuery({
    queryKey: ['plants'],
    queryFn: () => api.plants(),
    staleTime: 60_000,
  })
  const activePlant = useMemo(
    () => (plants.data?.data ?? []).find((p) => p.isActive) ?? null,
    [plants.data],
  )

  const locations = useMemo(() => {
    const all = locs.data?.data ?? []
    return all.filter((l) => l.lat != null && l.lng != null && (!filter || filter(l.worstStatus)))
  }, [locs.data, filter])

  /* Init mappa (una sola volta) */
  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return
    const map = L.map(mapContainer.current, {
      center: [40.759, 14.587],
      zoom: 13,
      zoomControl: !compact,
      attributionControl: true,
      preferCanvas: true,
    })
    mapRef.current = map
    return () => {
      map.remove()
      mapRef.current = null
      markersRef.current = []
      linesRef.current = []
    }
  }, [compact])

  /* Tile layer (provider + tema: scuro → CartoDB dark, chiaro → OSM) */
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    if (tileRef.current) {
      map.removeLayer(tileRef.current)
      tileRef.current = null
    }
    if (provider === 'sat') {
      tileRef.current = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        { maxZoom: 19, attribution: 'Immagini © Esri, Maxar, Earthstar Geographics' },
      )
    } else if (isLight) {
      tileRef.current = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors',
      })
    } else {
      tileRef.current = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
        attribution: '© OpenStreetMap contributors © CARTO',
      })
    }
    tileRef.current.addTo(map)
  }, [provider, isLight])

  /* Linee dei collegamenti tra sedi (v16.17 W18): disegnate SOTTO i
   * marker (pannello «overlayPane» con zIndex basso) così i punti
   * restano cliccabili; tooltip con i due capi e il tipo di link. */
  useEffect(() => {
    const map = mapRef.current
    if (!map || locs.isLoading) return
    for (const line of linesRef.current) map.removeLayer(line)
    linesRef.current = []
    for (const l of linkLines) {
      const line = L.polyline([l.from, l.to], {
        color: l.color,
        weight: l.weight ?? 2,
        opacity: 0.9,
        dashArray: l.dashed ? '5 6' : undefined,
        lineCap: 'round',
        interactive: true,
        bubblingMouseEvents: false,
      })
      line.bindTooltip(escapeHtml(l.tooltip), { sticky: true, className: 'scrim-label', direction: 'top' })
      line.addTo(map)
      linesRef.current.push(line)
    }
  }, [linkLines, locs.isLoading])

  /* Marker (rigenerati quando cambiano le sedi o la selezione) */
  useEffect(() => {
    const map = mapRef.current
    if (!map || locs.isLoading) return

    for (const m of markersRef.current) map.removeLayer(m)
    markersRef.current = []

    const bounds: L.LatLngExpression[] = []
    const markerById = new Map<string, L.Marker>()
    for (const l of locations) {
      const color = statusColor(l.worstStatus, palette)
      const selected = selectedLocationId === l.id
      const icon = L.divIcon({
        className: '',
        html: `
          <div style="display:flex;align-items:center;gap:6px;transform:translate(-11px,-11px);">
            <span style="width:14px;height:14px;border-radius:9999px;background:${color};border:2px solid ${palette.markerRing};box-shadow:0 1px 6px rgba(0,0,0,.6);${selected ? `outline:2px solid ${palette.info};outline-offset:2px;` : ''}"></span>
            ${compact ? '' : `<span class="scrim-label" style="font:600 11px/1.3 var(--font-geist-sans),sans-serif;white-space:nowrap;">${escapeHtml(l.name)} · ${l.devices}</span>`}
          </div>`,
        iconSize: [14, 14],
        iconAnchor: [7, 7],
      })
      const marker = L.marker([l.lat!, l.lng!], {
        icon,
        title: `${l.name} — ${l.devices} dispositivi (online ${l.online}, degradati ${l.degraded}, offline ${l.offline}, sconosciuti ${l.unknown}, non monitorati ${l.notMonitored})`,
        keyboard: true,
        alt: `Sede ${l.name}`,
      })
      /* v16.17 W18 (pattern UISP): il click sul punto apre un popup col
       * NOME della sede e la situazione; chi consuma la mappa riceve
       * comunque l'evento per il pannello completo dei dispositivi. */
      marker.bindPopup(
        `<div style="font:600 13px/1.4 var(--font-geist-sans),sans-serif;">${escapeHtml(l.name)}</div>` +
        `<div style="font:400 11px/1.6 var(--font-geist-sans),sans-serif;opacity:.85">` +
        `<b class="num">${l.devices}</b> dispositivi · <span style="color:${statusColor('ONLINE', palette)}"><b class="num">${l.online}</b> online</span>` +
        (l.offline > 0 ? ` · <span style="color:${statusColor('OFFLINE', palette)}"><b class="num">${l.offline}</b> offline</span>` : '') +
        (l.degraded > 0 ? ` · <span style="color:${statusColor('DEGRADED', palette)}"><b class="num">${l.degraded}</b> degradati</span>` : '') +
        (l.cameraCount > 0 ? `<br/><span>video: <b class="num">${l.cameraCount}</b></span>` : '') +
        `</div>`,
        { closeButton: false, autoPanPadding: [12, 12] },
      )
      marker.on('click', () => { onSelectLocation?.(l.id) })
      marker.addTo(map)
      markersRef.current.push(marker)
      markerById.set(l.id, marker)
      bounds.push([l.lat!, l.lng!])
    }

    /* v16.17 W18: il popup si APRE QUI, dopo la ricostruzione dei marker
     * (la selezione li rigenera: aprire al click di Leaflet verrebbe
     * distrutto dal re-render). Aperto solo quando la selezione CAMBIA —
     * un refresh dati non riapre ciò che l'utente ha chiuso. Vale anche
     * per la selezione dalla lista sedi: stesso diritto, stesso popup. */
    const selectedMarker = selectedLocationId ? markerById.get(selectedLocationId) : null
    if (selectedMarker && lastPopupIdRef.current !== selectedLocationId) {
      selectedMarker.openPopup()
    }
    lastPopupIdRef.current = selectedLocationId ?? null

    if (bounds.length > 0 && !selectedLocationId) {
      map.fitBounds(L.latLngBounds(bounds), { padding: [36, 36], maxZoom: 15 })
    }
  }, [locations, locs.isLoading, selectedLocationId, onSelectLocation, compact])

  /* Centro dell'impianto attivo quando NON ci sono marker (impianto
   * vuoto o sedi senza GPS): la mappa non resta su coordinate altrui */
  useEffect(() => {
    const map = mapRef.current
    if (!map || locations.length > 0) return
    if (activePlant && Number.isFinite(activePlant.mapCenterLat) && Number.isFinite(activePlant.mapCenterLng)) {
      map.setView([activePlant.mapCenterLat, activePlant.mapCenterLng], activePlant.mapZoom || 13, { animate: false })
    }
  }, [activePlant, locations.length])

  /* Focus su sede selezionata */
  useEffect(() => {
    const map = mapRef.current
    if (!map || !selectedLocationId) return
    const l = locations.find((x) => x.id === selectedLocationId)
    if (l?.lat != null && l?.lng != null) map.setView([l.lat, l.lng], Math.max(map.getZoom(), 16), { animate: true })
  }, [selectedLocationId, locations])

  /* Popup informativo: gestito da chi usa la mappa (onSelectLocation) */

  return (
    <div className="relative h-full w-full overflow-hidden rounded-lg border border-border">
      <div ref={mapContainer} className="h-full w-full" style={{ height }} role="application" aria-label="Mappa delle sedi dell'impianto" />
      {/* Selettore tile (tab Mappa/Satellite, mockup 1) */}
      {onProviderChange ? (
        <div className="absolute right-2.5 top-2.5 z-[500] flex overflow-hidden rounded-md border border-border bg-surface/95 shadow-lg" role="tablist" aria-label="Tipo di mappa">
          {(['osm', 'sat'] as const).map((p) => (
            <button
              key={p}
              role="tab"
              aria-selected={provider === p}
              onClick={() => onProviderChange(p)}
              className={cn(
                'px-2.5 py-1.5 text-[11px] font-medium transition-colors',
                provider === p ? 'bg-primary text-primary-foreground' : 'text-text-2 hover:bg-raised hover:text-foreground',
              )}
            >
              {p === 'osm' ? 'Mappa' : 'Satellite'}
            </button>
          ))}
        </div>
      ) : null}
      {/* Legenda stati (colore + testo, mai solo colore) */}
      <div className="scrim-label absolute bottom-2.5 left-2.5 z-[500] flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-foreground" role="group" aria-label="Legenda stati">
        <LegendDot color={statusColor('ONLINE', palette)} label={`Online`} />
        <LegendDot color={statusColor('DEGRADED', palette)} label="Degradati" />
        <LegendDot color={statusColor('OFFLINE', palette)} label="Offline" />
        <LegendDot color={statusColor('NOT_MONITORED', palette)} label="Non monitorati" />
      </div>
      {locs.isLoading ? (
        <div className="absolute inset-0 z-[600] flex items-center justify-center bg-background/70 text-xs text-text-2">Caricamento sedi…</div>
      ) : null}
      {locs.isError ? (
        <div className="absolute inset-x-2.5 top-2.5 z-[600] rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs text-crit-text" role="alert">
          Mappa non disponibile: {(locs.error as Error).message}
        </div>
      ) : null}
    </div>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1">
      <span className="inline-block size-2 rounded-full" style={{ background: color }} aria-hidden />
      {label}
    </span>
  )
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c)
}
