/* ================================================================
 * FALCO-OS v16.20 — instrumentation.ts (W22 «AUTO-RESUME ENTERPRISE»)
 * ================================================================
 * Next.js chiama register() UNA sola volta per processo server, prima
 * di servire qualunque richiesta: è il punto giusto (enterprise) per
 * riattivare i servizi di background.
 *
 * Cosa fa qui:
 *   · AUTO-RESUME del motore di monitoraggio («puller»): ogni impianto
 *     con EngineRuntime.enabled=true (nel DB) viene RIATTIVATO con la
 *     configurazione persistita (intervalSec, radio ogni N). Un riavvio
 *     del server — deploy, crash, aggiornamento — NON spegne più il
 *     monitoraggio degli impianti: al boot riparte da solo.
 *   · L'arresto VOLONTARIO (enabled=false) è RISPETTATO: l'auto-resume
 *     non resuscita ciò che un umano ha fermato.
 *   · Ogni ripresa è AUDIT-ata (attore 'system:auto-resume') e il
 *     motore aggiorna un heartbeat per ciclo su EngineRuntime.
 *
 * Onestà tecnica: il primo avvio attende FALCO_ENGINE_RESUME_DELAY_MS
 * (default 8000 ms) per lasciare al processo il tempo di assestarsi
 * (DB/prisma e discovery-service :3002 su macchine lente); nel frattempo
 * le richieste HTTP sono già servite normalmente.
 * ================================================================ */

export async function register() {
  /* Solo runtime Node (mai edge/build di pruning) */
  if (process.env.NEXT_RUNTIME !== 'nodejs') return
  /* next build non deve avviare motori (nessun server reale) */
  if (process.env.NEXT_PHASE === 'phase-production-build') return

  /* Un solo tentativo per processo: la guardia vive sul globalThis perché
   * register() può essere invocato di nuovo in dev (riavvio a caldo). */
  const g = globalThis as unknown as { __falcoAutoResumeScheduled?: boolean }
  if (g.__falcoAutoResumeScheduled) return
  g.__falcoAutoResumeScheduled = true

  const delayMs = Number(process.env.FALCO_ENGINE_RESUME_DELAY_MS ?? 8000)
  const safeDelay = Number.isFinite(delayMs) && delayMs >= 0 ? Math.min(delayMs, 120_000) : 8000

  const t = setTimeout(() => {
    void (async () => {
      try {
        const { resumeMonitoringEngines } = await import('@/lib/v2/polling-engine')
        const outcome = await resumeMonitoringEngines()
        if (outcome.resumed > 0) {
          console.log(`[falco auto-resume] motore di monitoraggio RIATTIVATO per ${outcome.resumed} impianto/i: ${outcome.plants.join(', ')}`)
        } else {
          console.log('[falco auto-resume] nessun motore da riattivare (nessun impianto con EngineRuntime.enabled=true)')
        }
      } catch (err) {
        /* MAI rompere il boot del server per l'auto-resume */
        console.warn('[falco auto-resume] non riuscito (il server continua normalmente):', err instanceof Error ? err.message : String(err))
      }
    })()
  }, safeDelay)

  /* non trattenere il processo solo per il timer dell'auto-resume */
  if (typeof t.unref === 'function') t.unref()
}
