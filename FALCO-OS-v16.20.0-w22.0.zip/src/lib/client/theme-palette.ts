/* ================================================================
 * FALCO-OS v16 — Palette JS per elementi che NON possono usare le
 * classi token Tailwind: attributi SVG dei grafici recharts, divIcon
 * di Leaflet, MiniMap di xyflow. I valori rispecchiano 1:1 i token di
 * globals.css (fonte visiva unica; duplicazione volontaria e
 * documentata in DESIGN_SYSTEM §4.2 «palette JS»).
 * Tema attivo: scuro (default) e chiaro (richiesta utente, ex W6).
 * ================================================================ */

'use client'

import { useSyncExternalStore } from 'react'
import { useTheme } from 'next-themes'

export interface ThemePalette {
  bg: string
  surface: string
  raised: string
  text: string
  text2: string
  ok: string
  warn: string
  crit: string
  info: string
  border: string
  controlBorder: string
  /** anello esterno dei marker/punti di stato */
  markerRing: string
  /** velo della MiniMap di topologia */
  minimapMask: string
}

export const DARK_PALETTE: ThemePalette = {
  bg: '#051224',
  surface: '#0a1b33',
  raised: '#14263e',
  text: '#f2f6fc',
  text2: '#8fa3bf',
  ok: '#06bf72',
  warn: '#fca830',
  crit: '#f54146',
  info: '#4da3ff',
  border: '#1b3150',
  controlBorder: '#5f7ba0',
  markerRing: 'rgba(5, 18, 36, 0.92)',
  minimapMask: 'rgba(10, 27, 51, 0.78)',
}

export const LIGHT_PALETTE: ThemePalette = {
  bg: '#f4f7fb',
  surface: '#ffffff',
  raised: '#e3e9f2',
  text: '#101826',
  text2: '#46596f',
  ok: '#06875a',
  warn: '#b26a00',
  crit: '#d02a30',
  info: '#0a4fb8',
  border: '#d4dde8',
  controlBorder: '#6b7f99',
  markerRing: 'rgba(255, 255, 255, 0.95)',
  minimapMask: 'rgba(227, 233, 242, 0.82)',
}

const emptySubscribe = () => () => {}

/** Vero SOLO dopo l'idratazione client (snapshot server = false):
 *  pattern React senza setState-in-effect (regola react-hooks v6). */
export function useIsHydrated(): boolean {
  return useSyncExternalStore(emptySubscribe, () => true, () => false)
}

/** Palette corrente: scuro finché il client non ha idratato (default
 *  del server → nessun mismatch di idratazione), poi segue il tema. */
export function usePalette(): ThemePalette {
  const { resolvedTheme } = useTheme()
  const mounted = useIsHydrated()
  return mounted && resolvedTheme === 'light' ? LIGHT_PALETTE : DARK_PALETTE
}

/** Colore di uno stato uiStatus per marker/punti SVG. Mai colore da
 *  solo nelle UI informative: sempre abbinato a icona+testo (§1.4/§9). */
export function statusColor(status: string | null | undefined, p: ThemePalette): string {
  switch (status) {
    case 'ONLINE':
      return p.ok
    case 'DEGRADED':
    case 'UNKNOWN':
      return p.warn
    case 'OFFLINE':
    case 'NOT_MONITORED':
      return p.crit
    case 'MAINTENANCE':
      return p.info
    default:
      return p.warn
  }
}
