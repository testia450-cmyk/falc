/* ================================================================
 * FALCO-OS v16 — Client realtime (socket.io)
 * Collegamento SOLO via gateway: path '/' + query XTransformPort=3001
 * (mai porte nell'URL). Nessun polling aggressivo: i dati vivi
 * arrivano qui; TanStack Query fa refetch mirato su evento.
 * ================================================================ */

'use client'

import { io, type Socket } from 'socket.io-client'

let socket: Socket | null = null

export interface NocTickPayload {
  asOf: number
  devicesOnline: number
  devicesDegraded: number
  devicesUnknown: number
}

/* v16.18.1 (portabilità Windows): fuori dalla sandbox il gateway Caddy non
 * esiste. Se l'operatore imposta NEXT_PUBLIC_REALTIME_URL (es. dev su
 * Windows: http://localhost:3001) il client si collega DIRETTAMENTE al
 * mini-service (CORS permissivo di fabbrica, transport websocket, path '/').
 * Se l'env NON è impostato il comportamento resta quello del gateway
 * (sandbox): stessa origine + XTransformPort in query. Nessuna porta MAI
 * scritta nell'URL del gateway. */
const REALTIME_DIRECT_URL = process.env.NEXT_PUBLIC_REALTIME_URL

export function getSocket(): Socket {
  if (socket && socket.connected) return socket
  if (socket) return socket
  const commonOpts = {
    path: '/',
    transports: ['websocket'],
    reconnection: true,
    reconnectionDelay: 2000,
    reconnectionDelayMax: 10_000,
    timeout: 8000,
  }
  if (REALTIME_DIRECT_URL) {
    socket = io(REALTIME_DIRECT_URL, commonOpts)
  } else {
    /* Regola del gateway: la porta del servizio viaggia nella query
     * XTransformPort (MAI nell'URL). Il path resta '/' così Caddy
     * inoltra a 3001 con lo stesso prefisso.
     * WebSocket SOLO (29/10): con «polling» ogni richiesta EIO colpiva
     * la route «/» di Next sui collegamenti diretti a :3000, forzando
     * la ricompilazione della pagina ogni ~4 s → tempesta di Fast
     * Refresh che azzerava lo stato React delle mutation (dialog esito
     * webhook senza risultato). Il gateway inoltra l'upgrade WS tramite
     * XTransformPort; dove l'upgrade non passa, il canale realtime si
     * degrada onestamente (i dati vivi arrivano comunque da TanStack
     * Query) senza intasare il dev server. */
    socket = io({ ...commonOpts, query: { XTransformPort: '3001' } })
  }
  return socket
}

/** Sottoscrizione con cleanup. Ritorna la funzione di dispose. */
export function subscribeRealtime(handlers: {
  onTick?: (p: NocTickPayload) => void
  onAlarms?: (alarms: Array<{ id: string; severity: string; message: string; deviceId: string | null; openedAt: number }>) => void
  onConnect?: () => void
  onDisconnect?: () => void
}): () => void {
  const s = getSocket()
  const tick = (p: NocTickPayload) => handlers.onTick?.(p)
  const alarms = (a: Array<{ id: string; severity: string; message: string; deviceId: string | null; openedAt: number }>) => handlers.onAlarms?.(a)
  const conn = () => handlers.onConnect?.()
  const disc = () => handlers.onDisconnect?.()
  s.on('noc:tick', tick)
  s.on('alarms:new', alarms)
  s.on('connect', conn)
  s.on('disconnect', disc)
  if (s.connected) handlers.onConnect?.()
  return () => {
    s.off('noc:tick', tick)
    s.off('alarms:new', alarms)
    s.off('connect', conn)
    s.off('disconnect', disc)
  }
}
