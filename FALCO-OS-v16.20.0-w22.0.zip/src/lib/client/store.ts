/* ================================================================
 * FALCO-OS v16 — Stato UI (zustand) sincronizzato con l'URL
 * Deep link (§5): ?view=dispositivi&device=ID&tab=metriche…
 * Lo stato dei filtri vive nell'URL: condivisibile e refresh-sicuro.
 * ================================================================ */

'use client'

import { create } from 'zustand'

export type ViewId = 'dashboard' | 'setup' | 'rete' | 'dispositivi' | 'telecamere' | 'allarmi' | 'operazioni' | 'assistente' | 'report' | 'amministrazione' | 'wallboard'

export const VIEW_LABELS: Record<ViewId, string> = {
  dashboard: 'Dashboard',
  setup: 'Setup impianto',
  rete: 'Rete',
  dispositivi: 'Dispositivi',
  telecamere: 'Telecamere',
  allarmi: 'Allarmi',
  operazioni: 'Operazioni',
  assistente: 'Assistente',
  report: 'Report',
  amministrazione: 'Amministrazione',
  wallboard: 'Wallboard',
}

export interface UrlState {
  view: ViewId
  deviceId: string | null // quick-look / scheda apparato
  deviceTab: string | null
  alarmId: string | null
  topologyNode: string | null
  mapProvider: 'osm' | 'sat' | null
  reteTab: 'topologia' | 'mappa' | 'mac' | 'speed' | null
  /* 16.10 W8: famiglie di fonti dei collegamenti ammesse nell'albero
   * (chiavi comma-separated: TECHNICIAN,PROTOCOLS,UISP,INFERRED).
   * null = famiglie di default (operatore + protocolli + UISP). */
  topoSources: string | null
  /* 16.11 W9: rappresentazione della topologia — «raggiera» (fan-out a
   * card per sede, richiesta operatore con immagine di riferimento) o
   * «grafo» (canvas ELK W8). null = raggiera (default). */
  topoView: 'raggiera' | 'grafo' | null
  /* v16.17 W18: sezione della vista Amministrazione (deep-link
   * ?view=amministrazione&sez=impianti) — serve al tasto «Importa
   * Excel/KMZ» della mappa per arrivare dritto al pannello giusto. */
  adminSez: 'impianti' | 'sistema' | 'integrazioni' | 'oid-custom' | 'certificazione' | 'utenti' | null
  q: string | null
}

const DEFAULT_STATE: UrlState = {
  view: 'dashboard', deviceId: null, deviceTab: null, alarmId: null,
  topologyNode: null, mapProvider: null, reteTab: null, topoSources: null, topoView: null, adminSez: null, q: null,
}

function parseUrl(): UrlState {
  if (typeof window === 'undefined') return DEFAULT_STATE
  const p = new URLSearchParams(window.location.search)
  const view = (p.get('view') ?? 'dashboard') as ViewId
  const valid: ViewId[] = ['dashboard', 'setup', 'rete', 'dispositivi', 'telecamere', 'allarmi', 'operazioni', 'assistente', 'report', 'amministrazione', 'wallboard']
  return {
    view: valid.includes(view) ? view : 'dashboard',
    deviceId: p.get('device'),
    deviceTab: p.get('tab'),
    alarmId: p.get('alarm'),
    topologyNode: p.get('node'),
    mapProvider: (p.get('map') as 'osm' | 'sat' | null),
    reteTab: (p.get('rete') as 'topologia' | 'mappa' | 'mac' | 'speed' | null),
    topoSources: p.get('fonti'),
    topoView: p.get('vista') === 'grafo' ? 'grafo' : p.get('vista') === 'raggiera' ? 'raggiera' : null,
    adminSez: (p.get('sez') as UrlState['adminSez']) ?? null,
    q: p.get('q'),
  }
}

function serialize(s: UrlState): string {
  const p = new URLSearchParams()
  if (s.view !== 'dashboard') p.set('view', s.view)
  if (s.deviceId) p.set('device', s.deviceId)
  if (s.deviceTab) p.set('tab', s.deviceTab)
  if (s.alarmId) p.set('alarm', s.alarmId)
  if (s.topologyNode) p.set('node', s.topologyNode)
  if (s.mapProvider) p.set('map', s.mapProvider)
  if (s.reteTab) p.set('rete', s.reteTab)
  if (s.topoSources) p.set('fonti', s.topoSources)
  if (s.topoView) p.set('vista', s.topoView)
  if (s.adminSez) p.set('sez', s.adminSez)
  if (s.q) p.set('q', s.q)
  const qs = p.toString()
  return qs ? `?${qs}` : window.location.pathname
}

interface AppState extends UrlState {
  hydrate: () => void
  set: (patch: Partial<UrlState>) => void
  openDevice: (id: string | null) => void
  navigate: (view: ViewId) => void
  /* 16.10 W8: impianto ATTIVO (multi-impianto). Vive nel store (non in
   * URL: è una scelta di sessione persistita in localStorage) e viene
   * iniettato dal client API in OGNI chiamata. Il cambio invalida TUTTE
   * le query TanStack (chi lo chiama lo fa). */
  activePlantId: string | null
  setActivePlant: (id: string | null) => void
}

export const useApp = create<AppState>((setState, getState) => ({
  ...DEFAULT_STATE,
  activePlantId: null,
  hydrate: () => {
    const parsed = parseUrl()
    setState({ ...parsed })
    const onPop = () => setState({ ...parseUrl() })
    window.addEventListener('popstate', onPop)
  },
  setActivePlant: (id) => {
    setState({ activePlantId: id })
  },
  set: (patch) => {
    const next = { ...getState(), ...patch }
    setState(patch)
    window.history.pushState(null, '', serialize(next))
  },
  openDevice: (id) => {
    const patch: Partial<UrlState> = id ? { deviceId: id } : { deviceId: null, deviceTab: null }
    const next = { ...getState(), ...patch }
    setState(patch)
    window.history.pushState(null, '', serialize(next))
  },
  navigate: (view) => {
    const patch: Partial<UrlState> = { view }
    const next = { ...getState(), ...patch }
    setState(patch)
    window.history.pushState(null, '', serialize(next))
  },
}))

/* ---------------- Hook di utilità ---------------- */

export function useView(): ViewId {
  return useApp((s) => s.view)
}
