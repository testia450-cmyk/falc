/* ================================================================
 * FALCO-OS v16 — Client API v2 (browser)
 * Tipizzato sui contratti zod. Gestione errori coerente: ogni risposta
 * è { ok, asOf, mode, data } | { ok:false, error }.
 * ================================================================ */

import type {
  NocSummary, DeviceRow, DeviceOverview, WeakLinkRow, AlarmRow, CameraRow,
  StreamRegistryRow, UiStatus, Severity, TicketRow, MaintenanceRow, AuditRow, AdminStats,
  DeviceGroupRow,
  GroupRule,
  AvailabilityRow,
  AvailabilityByLocationRow,
  DevicePortsPage, DevicePortRow, MacInventoryPage, MacInventoryRow,
  DiscoveryHealth, DiscoveryScanResult, VendorProbeResult, VendorBatchResult, DiscoveryL2Result, DiscoveryL2Input, DiscoveryL2BatchInput, DiscoveryL2BatchResult, OuiLookupResult, AdoptionQueue, AdoptionCandidate, ArpAdoptionInput, ArpAdoptionResult,
  SnmpEnablePlanInput, SnmpEnablePlanResult, SnmpEnableInput, SnmpEnableResult, SnmpVerifyResult, PingSweepInput, PingSweepResult,
  RadioTelemetryInput, RadioTelemetryResult, LocateResult,
  SetupScanInput, SetupScanResult, SetupVerifyInput, SetupVerifyResult, SetupAdoptInput, SetupAdoptResult, SetupAlarmsInput, SetupAlarmsResult, SetupSummaryResult,
  EngineInput, EngineStatusRow, SetupEnginePage, SetupEngineActionResult,
  EventPolicyRow, EventPoliciesPage, CreateEventPolicyInput, UpdateEventPolicyInput,
  CustomOidRow, CustomOidsPage, CreateCustomOidInput, UpdateCustomOidInput, CustomOidTestResult,
  ConfigRequestRow, ConfigRequestsPage, CreateConfigRequestInput, ConfigRequestAction,
  BulkConfigRow, BulkConfigPage, CreateBulkConfigInput,
  FirmwareJobRow, FirmwareJobsPage,
  PlaybookRow, PlaybooksPage,
  AutomationTaskRow, AutomationTasksPage,
  IntegrationsPage, IntegrationTestResult,
  WebhookEndpointRow, WebhooksPage, WebhookTestResult,
  TerminalProbeResult,
  SlaReport, TicketDetail, ScheduledReportsPage, ScheduledReportRow,
  AuditExport, AuditChainState, AuditChainVerify, AuditSealResult,
  KbPage, KbArticleRow,
  RmaPlan, RmaExecuteInput,
  WaveRow, WavesPage, CreateWaveInput,
  CveEntryRow, CveCatalog, CveFindingRow, CveFindingsPage, CveScanReport, CveImportInput, CveImportResult,
  SpeedTestRow, SpeedTestsPage, SpeedTestRunInput, SpeedTestRunResult,
  AdminUserRow, AdminUsersPage, CreateUserInput, UpdateUserInput, AdminPermissions, AdminSessions,
  PlantRow, CreatePlantInput, UpdatePlantInput,
  KmzPreview, KmzApplyInput, KmzApplyResult, XlsxPreview, XlsxApplyInput, XlsxApplyResult,
  TopologyLinkRow, TopologyLinksPage, CreateTopologyLinkInput, UpdateTopologyLinkInput, PurgeLinksInput, PurgeLinksResult,
} from '@/lib/v2/contracts'
import type { z } from 'zod'
import type { CreateFirmwareJobInput, CreatePlaybookInput, UpdatePlaybookInput, CreateAutomationTaskInput, UpdateAutomationTaskInput, IntegrationTestInput, CreateWebhookInput, UpdateWebhookInput, CreateScheduledReportInput, UpdateScheduledReportInput, CreateKbInput, UpdateKbInput } from '@/lib/v2/contracts'

export interface ApiEnvelope<T> {
  ok: true
  asOf: number
  mode: 'replay' | 'static'
  data: T
}

export class ApiError extends Error {
  code: string
  status: number
  constructor(code: string, message: string, status: number) {
    super(message)
    this.code = code
    this.status = status
  }
}

async function get<T>(path: string, params?: Record<string, string | number | undefined>, opts?: { noPlant?: boolean }): Promise<ApiEnvelope<T>> {
  const qs = new URLSearchParams()
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== '' && v !== null) qs.set(k, String(v))
    }
  }
  // 16.10 W8: l'impianto ATTIVO viene iniettato in OGNI lettura API che
  // non lo dichiara già — tutte le viste seguono l'impianto scelto
  // dall'operatore (multi-impianto). Le route che non usano plantId lo
  // ignorano (zod strippa le chiavi sconosciute). ECEZIONE (noPlant):
  // le meta-query che elencano TUTTI gli impianti — iniettarvi il plantId
  // attivo le filtrerebbe su quell'impianto, e con un impianto attivo
  // STALE (eliminato) restituirebbero lista vuota SENZA via di recupero.
  if (!opts?.noPlant && activePlantId && !qs.has('plantId')) qs.set('plantId', activePlantId)
  const url = `/api/v2${path}${qs.size > 0 ? `?${qs.toString()}` : ''}`
  const res = await fetch(url, { headers: { Accept: 'application/json' } })
  if (res.status === 401) {
    // sessione scaduta: ricarica per far riapparire il login
    window.location.reload()
    throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401)
  }
  const body = (await res.json()) as { ok: boolean; error?: { code: string; message: string }; asOf?: number; mode?: 'replay' | 'static'; data?: T }
  if (!body.ok || !res.ok) {
    throw new ApiError(body.error?.code ?? 'UNKNOWN', body.error?.message ?? `Errore ${res.status}`, res.status)
  }
  return { ok: true, asOf: body.asOf ?? 0, mode: body.mode ?? 'static', data: body.data as T }
}

/* ---------------- 16.10 W8: impianto attivo (multi-impianto) ----------------
 * Lo stato vive QUI (modulo) + persistenza localStorage: lo switcher della
 * sidebar lo imposta, OGNI chiamata API (lettura via get() e mutazione via
 * v2Url()) lo inietta come ?plantId=. Null = comportamento pre-16.10
 * (l'impianto attivo è il primo: «egidio»). */

let activePlantId: string | null = null

export function setActivePlantId(id: string | null): void {
  activePlantId = id
  try {
    if (id) localStorage.setItem('falco.activePlant', id)
    else localStorage.removeItem('falco.activePlant')
  } catch {
    /* localStorage non disponibile (SSR/private mode): solo memoria */
  }
}

export function getActivePlantId(): string | null {
  if (activePlantId) return activePlantId
  try {
    const stored = localStorage.getItem('falco.activePlant')
    if (stored) activePlantId = stored
  } catch {
    /* ignora */
  }
  return activePlantId
}

/** Costruisce l'URL di una mutazione v2 (o di un fetch SSE raw) con
 *  l'impianto attivo iniettato. Esportata v16.12 W10: anche le viste che
 *  fanno fetch propri (assistente SSE) devono rispettare l'impianto attivo. */
export function v2Url(path: string): string {
  const sep = path.includes('?') ? '&' : '?'
  return activePlantId ? `/api/v2${path}${sep}plantId=${encodeURIComponent(activePlantId)}` : `/api/v2${path}`
}

export interface DeviceFilters {
  type?: string
  status?: string
  family?: 'network' | 'radio' | 'cameras' | 'all'
  q?: string
  /** v16.17 W18: sede esatta — pannello «dispositivi del punto» della mappa */
  locationId?: string
  page?: number
  pageSize?: number
  sort?: string
  dir?: 'asc' | 'desc'
}

export const api = {
  summary: () => get<NocSummary>('/noc/summary'),

  devices: (f: DeviceFilters) =>
    get<{ items: DeviceRow[]; total: number; page: number; pageSize: number; pageCount: number }>('/devices', {
      type: f.type, status: f.status, family: f.family, q: f.q,
      locationId: f.locationId,
      page: f.page, pageSize: f.pageSize, sort: f.sort, dir: f.dir,
    }),

  deviceOverview: (id: string) => get<DeviceOverview>(`/devices/${id}/overview`),

  /* --- 16.5.0 W3-proroga: tab «Porte» (parità v15 G3, solo dati reali DB) --- */

  devicePorts: (id: string) => get<DevicePortsPage>(`/devices/${id}/ports`),

  /* --- 16.5.0 W4 anticipata: inventario MAC (FDB × inventario) --- */

  macInventory: (f: {
    q?: string
    switchId?: string
    scope?: 'all' | 'resolved' | 'unresolved'
    sort?: 'lastSeen' | 'mac' | 'hostname'
    page?: number
    pageSize?: number
  }) =>
    get<MacInventoryPage>('/mac-inventory', {
      q: f.q, switchId: f.switchId, scope: f.scope, sort: f.sort,
      page: f.page, pageSize: f.pageSize,
    }),

  topologyGraph: (opts?: { sources?: string[] }) =>
    get<{
      plantId: string; gatewayId: string | null; rootSource: 'operator' | 'inferred' | 'none'
      sources: string[]
      linkStats: { total: number; included: number; excludedInferred: number; confirmedAlwaysIn: number }
      nodes: Array<{
        id: string; hostname: string; ip: string; type: string; uiStatus: UiStatus
        tier: number; parentId: string | null; locationId: string | null; locationName: string | null
        model: string; signalDbm: number | null; linkQuality: number; downstreamCount: number
      }>
      edges: Array<{
        id: string; source: string; target: string; linkType: string; linkStatus: string
        confidence: string; evidence: string; manual: boolean; speedMbps: number
        trafficInMbps: number; trafficOutMbps: number; label: string
      }>
      blocks: Array<{ level: number; label: string; nodeIds: string[] }>
      discardedAutoEdges: number
      unreachableCount: number
    }>('/topology/graph', { sources: opts?.sources?.join(',') }),

  weakLinks: (limit = 8) => get<WeakLinkRow[]>('/links/weak', { limit }),

  events: (opts: { deviceId?: string; limit?: number; before?: number }) =>
    get<{
      items: Array<{
        id: string; deviceId: string | null; deviceHostname: string | null
        eventType: string; oldValue: string; newValue: string; source: string; createdAt: number
      }>
      nextCursor: number | null
    }>('/events', { deviceId: opts.deviceId, limit: opts.limit, before: opts.before }),

  alarms: (f: { status?: string; severity?: string; deviceId?: string; q?: string; page?: number; pageSize?: number }) =>
    get<{ items: AlarmRow[]; total: number; page: number; pageSize: number; pageCount: number }>('/alarms', f),

  ackAlarm: async (id: string, note?: string): Promise<AlarmRow> => {
    const res = await fetch(v2Url(`/alarms/${id}/ack`), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'ACK_FAILED', body.error?.message ?? 'Errore ACK', res.status)
    return body.data as AlarmRow
  },

  cameras: (f: { q?: string; stream?: 'all' | 'down' | 'unknown' | 'alive'; locationId?: string; page?: number; pageSize?: number }) =>
    get<{ items: CameraRow[]; total: number; page: number; pageSize: number; pageCount: number }>('/cameras', f),

  /* --- 16.3 additivo: registro flussi (onda W2 residua) --- */

  camerasStreams: (f: { q?: string; stream?: 'alive' | 'down' | 'unknown'; locationId?: string; page?: number; pageSize?: number; windowHours?: number }) =>
    get<{
      items: StreamRegistryRow[]; total: number; page: number; pageSize: number; pageCount: number
      windowHours: number // finestra realmente analizzata (dichiarata dal server)
    }>('/cameras/streams', f),

  traffic: (hours = 24) =>
    get<{
      definition: string; coreDeviceId: string | null; coreHostname: string | null
      inMbps: Array<{ t: number; v: number }>; outMbps: Array<{ t: number; v: number }>
      lastInMbps: number | null; lastOutMbps: number | null; lastSampleAt: number | null
    }>('/traffic/series', { hours }),

  search: (q: string) =>
    get<{
      devices: Array<{ id: string; hostname: string; ip: string; type: string; uiStatus: UiStatus }>
      locations: Array<{ id: string; name: string; identifier: string; lat: number | null; lng: number | null; deviceCount: number }>
      alarms: Array<{ id: string; severity: Severity; message: string; deviceId: string | null }>
    }>('/search', { q }),

  locations: (plantId?: string) =>
    get<Array<{
      id: string; name: string; identifier: string; lat: number | null; lng: number | null
      devices: number; online: number; degraded: number; offline: number; unknown: number
      notMonitored: number; worstStatus: UiStatus | null; cameraCount: number
    }>>('/locations', plantId ? { plantId } : undefined),

  systemHealth: () =>
    get<{
      version: string; dbReachable: boolean; realtimeUrl: string
      replay: { enabled: boolean; importedAt: number | null; lastTickAt: number | null; nextTickAt: number | null; intervalSec: number }
      lastDbWrite: number | null
    }>('/system/health'),

  /* --- Operazioni (ticket + finestre di manutenzione) --- */

  tickets: (f: { status?: string; priority?: string; q?: string; page?: number; pageSize?: number }) =>
    get<{
      items: TicketRow[]; total: number; page: number; pageSize: number; pageCount: number
      kpis: { open: number; inProgress: number; resolved7d: number; slaOverdue: number }
    }>('/tickets', f),

  createTicket: async (input: { title: string; description: string; priority: 'CRITICAL' | 'HIGH'; deviceId?: string }): Promise<TicketRow> => {
    const res = await fetch(v2Url('/tickets'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione ticket', res.status)
    return body.data as TicketRow
  },

  updateTicket: async (id: string, patch: { status?: 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED'; resolution?: string; assignedTo?: string; note?: string }): Promise<TicketRow> => {
    const res = await fetch(v2Url(`/tickets/${id}`), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento ticket', res.status)
    return body.data as TicketRow
  },

  maintenance: () => get<{ items: MaintenanceRow[] }>('/maintenance'),

  /* --- 16.3/16.4 additivo W3: gruppi dispositivi (MANUAL e DYNAMIC) --- */

  deviceGroups: () => get<{ items: DeviceGroupRow[]; total: number }>('/device-groups'),

  /* --- 16.4 W2 residua: report disponibilità (serie reali packetLoss);
   *      v16.16 W17-b: with byLocation (raggruppamento per sede) --- */

  availability: (windowHours: number) => get<{
    items: AvailabilityRow[]
    byLocation: AvailabilityByLocationRow[]
    total: number
    windowHours: number
    coverageFrom: number | null
    coverageTo: number | null
    slaTargetsDefined: number
  }>('/reports/availability', { windowHours }),

  createDeviceGroup: async (input: {
    name: string
    description?: string
    color?: string // hex #RRGGBB — dato operatore
    ruleType?: 'MANUAL' | 'DYNAMIC' // assente = MANUAL (retrocompat 16.3)
    rules?: GroupRule // OBBLIGATORIE per DYNAMIC (membership calcolata a runtime)
    deviceIds?: string[] // SOLO MANUAL: membri espliciti alla creazione
  }): Promise<DeviceGroupRow> => {
    const res = await fetch(v2Url('/device-groups'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione gruppo', res.status)
    return body.data as DeviceGroupRow
  },

  updateDeviceGroup: async (id: string, patch: {
    name?: string
    description?: string
    color?: string
    rules?: GroupRule // SOLO gruppi DYNAMIC: sostituzione INTEGRALE della regola
    deviceIds?: string[] // SOLO gruppi MANUAL: sostituzione INTEGRALE della membership
  }): Promise<DeviceGroupRow> => {
    const res = await fetch(v2Url(`/device-groups/${id}`), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento gruppo', res.status)
    return body.data as DeviceGroupRow
  },

  deleteDeviceGroup: async (id: string): Promise<{ id: string; removedScopes: number }> => {
    const res = await fetch(v2Url(`/device-groups/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione gruppo', res.status)
    return body.data as { id: string; removedScopes: number }
  },

  createMaintenance: async (input: {
    name: string; description?: string
    type: 'WITH_DATA' | 'NO_DATA'
    scheduleType: 'ONCE' | 'DAILY' | 'WEEKLY' | 'MONTHLY'
    daysOfWeek?: number[]
    dayOfMonth?: number
    startTime: string; endTime: string
    activeUntil?: number | null
    groupIds?: string[] // 16.3 W3: scope su gruppi reali (nessuno se assente/vuoto)
  }): Promise<MaintenanceRow> => {
    const res = await fetch(v2Url('/maintenance'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione finestra', res.status)
    return body.data as MaintenanceRow
  },

  /* 16.3 W3: PATCH completa — { state } da solo continua a funzionare
   * (retrocompatibile); groupIds = sostituzione integrale degli scope. */
  updateMaintenance: async (id: string, patch: {
    state?: 'ACTIVE' | 'PAUSED'
    name?: string
    description?: string
    type?: 'WITH_DATA' | 'NO_DATA'
    scheduleType?: 'ONCE' | 'DAILY' | 'WEEKLY' | 'MONTHLY'
    daysOfWeek?: number[]
    dayOfMonth?: number
    startTime?: string
    endTime?: string
    activeUntil?: number | null // null = rimuovi la scadenza
    groupIds?: string[]
  }): Promise<MaintenanceRow> => {
    const res = await fetch(v2Url(`/maintenance/${id}`), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento finestra', res.status)
    return body.data as MaintenanceRow
  },

  /* Wrapper 16.2 (pausa/ripresa): delega alla PATCH completa. */
  updateMaintenanceState: (id: string, state: 'ACTIVE' | 'PAUSED') =>
    api.updateMaintenance(id, { state }),

  deleteMaintenance: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/maintenance/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione finestra', res.status)
    return body.data as { id: string }
  },

  /* --- Report / Amministrazione (sola lettura) --- */

  audit: (opts: { action?: string; limit?: number } = {}) =>
    get<{ items: AuditRow[]; total: number; returned: number }>('/audit', { action: opts.action, limit: opts.limit }),

  adminStats: () => get<AdminStats>('/admin/stats'),

  /* --- 16.6 W3.4 — Discovery & Adozione --- */

  /** Stato del motore di scansione (:3002): capacità e database OUI. */
  discoveryHealth: () => get<DiscoveryHealth>('/discovery/health'),

  /** Sweep TCP di un CIDR (max 256 host): solo host VIVI in risposta. */
  discoveryScan: async (input: { cidr: string; ports?: number[]; timeoutMs?: number; maxHosts?: number }): Promise<DiscoveryScanResult> => {
    const res = await fetch(v2Url('/discovery/scan'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SCAN_FAILED', body.error?.message ?? 'Errore scansione', res.status)
    return body.data as DiscoveryScanResult
  },

  /** Sonda combinata su un IP: porte + banner + SNMP + ONVIF + OUI.
   *  v16.8: `communities` — lista tentata in ordine dal motore. */
  discoveryProbe: async (input: {
    ip: string
    snmp?: { community?: string; communities?: string[]; version?: 'v1' | 'v2c' | 'v3' }
    onvif?: { user?: string; pass?: string }
    timeoutMs?: number
  }): Promise<VendorProbeResult> => {
    const res = await fetch(v2Url('/discovery/probe'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'PROBE_FAILED', body.error?.message ?? 'Errore sonda', res.status)
    return body.data as VendorProbeResult
  },

  /** v16.8 — Identificazione di N IP (≤32) in UNA richiesta: il «puller»
   *  fa un solo round-trip verso il motore (sonde in parallelo lato
   *  servizio con concurrency controllata). */
  discoveryVendorBatch: async (input: {
    targets: string[]
    snmp?: { community?: string; communities?: string[]; version?: 'v1' | 'v2c' | 'v3' }
    onvif?: { user?: string; pass?: string }
    timeoutMs?: number
    concurrency?: number
  }): Promise<VendorBatchResult> => {
    const res = await fetch(v2Url('/discovery/vendor-batch'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'BATCH_FAILED', body.error?.message ?? 'Errore identificazione batch', res.status)
    return body.data as VendorBatchResult
  },

  /** v16.8 — Sonda Layer-2 di uno switch del plant: LLDP + CDP + FDB
   *  (BRIDGE-MIB/Q-BRIDGE) → ricostruzione dei collegamenti reali
   *  della rete in bridge. Write SU link inferiti (MAI su quelli
   *  dell'operatore) e su FdbObservation. */
  discoveryL2: async (input: DiscoveryL2Input): Promise<DiscoveryL2Result> => {
    const res = await fetch(v2Url('/discovery/l2'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'L2_FAILED', body.error?.message ?? 'Errore sonda Layer-2', res.status)
    return body.data as DiscoveryL2Result
  },

  /** v16.15 W14 — Sonda Layer-2 BATCH multi-switch (≤12): UNA richiesta
   *  verso il motore, poi la correlazione FDB/STP tra apparati
   *  ricostruisce i link switch↔switch con le porte di ENTRAMBI i
   *  lati. Persiste per ogni switch FDB/ARP/STP/VLAN e i link inferiti
   *  (MAI su quelli dell'operatore). */
  discoveryL2Batch: async (input: DiscoveryL2BatchInput): Promise<DiscoveryL2BatchResult> => {
    const res = await fetch(v2Url('/discovery/l2/batch'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'L2_BATCH_FAILED', body.error?.message ?? 'Errore sonda Layer-2 batch', res.status)
    return body.data as DiscoveryL2BatchResult
  },

  /** MAC → vendor IEEE (10.679 prefissi portati da v15). */
  discoveryOui: (mac: string) => get<OuiLookupResult>('/discovery/oui', { mac }),

  /** v16.16 W17-a: adozione UMANA di un candidato ARP del report batch
   *  (MAC→IP non in inventario) — crea il dispositivo con audit
   *  ADOZIONE_ARP_ADOPT. L'impianto attivo è iniettato da v2Url. */
  adoptArpCandidate: async (input: ArpAdoptionInput): Promise<ArpAdoptionResult> => {
    const res = await fetch(v2Url('/discovery/l2/adopt-arp'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'ARP_ADOPT_FAILED', body.error?.message ?? 'Errore adozione candidato ARP', res.status)
    return body.data as ArpAdoptionResult
  },

  /* --- 16.18 W19 — Attivazione SNMP assistita + monitoraggio ping --- */

  /** PREVIEW: la ricetta per-vendor scelta su marca/modello/tipo del
   *  dispositivo (o override), comandi INTERPOLATI in chiaro. Zero
   *  scritture, zero contatti con l'apparato. TECNICO+. */
  snmpEnablePlan: async (input: SnmpEnablePlanInput): Promise<SnmpEnablePlanResult> => {
    const res = await fetch(v2Url('/discovery/snmp-enable/plan'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'PLAN_FAILED', body.error?.message ?? 'Errore pianificazione attivazione', res.status)
    return body.data as SnmpEnablePlanResult
  },

  /** ESEGUI la ricetta confermata (SSH / API HTTP SwOS — o semplice
   *  dichiarazione per ping-only/manual). Il contatto con l'apparato
   *  avviene SOLO qui. TECNICO+. */
  snmpEnableExecute: async (input: SnmpEnableInput): Promise<SnmpEnableResult> => {
    const res = await fetch(v2Url('/discovery/snmp-enable'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'ENABLE_FAILED', body.error?.message ?? 'Errore attivazione SNMP', res.status)
    return body.data as SnmpEnableResult
  },

  /** Riverifica post-attivazione (ENABLED_UNVERIFIED → ENABLED):
   *  sonda read-only con le community del dispositivo. */
  snmpEnableVerify: async (deviceId: string): Promise<SnmpVerifyResult> => {
    const res = await fetch(v2Url('/discovery/snmp-enable/verify'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId }),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'VERIFY_FAILED', body.error?.message ?? 'Errore riverifica SNMP', res.status)
    return body.data as SnmpVerifyResult
  },

  /** v16.18 W20 — Sonda TELEMETRIA RADIO & SALUTE di un apparato:
   *  CPU/RAM, SSID, segnale, CCQ, frequenza, velocità radio, client
   *  associati, porte ethernet con duplex — con PROVENANCE per campo.
   *  Persiste i campi letti su Device + campioni MetricValue. TECNICO+. */
  radioTelemetry: async (input: RadioTelemetryInput): Promise<RadioTelemetryResult> => {
    const res = await fetch(v2Url('/discovery/radio'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'RADIO_PROBE_FAILED', body.error?.message ?? 'Errore sonda telemetria', res.status)
    return body.data as RadioTelemetryResult
  },

  /** v16.18 W20 — «Dove è collegato?»: IP/MAC/hostname → switch + porta
   *  (avvistamenti FDB) + link di topologia. Lettura pura. */
  locateDevice: async (query: string): Promise<LocateResult> => {
    // FIX w20.1: v2Url può già terminare con «?plantId=…» — il separatore
    // del parametro q va scelto sul risultato, non hardcoded '?'.
    const base = v2Url('/locate')
    const sep = base.includes('?') ? '&' : '?'
    const res = await fetch(`${base}${sep}q=${encodeURIComponent(query)}`)
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'LOCATE_FAILED', body.error?.message ?? 'Errore ricerca collegamento', res.status)
    return body.data as LocateResult
  },

  /** Spazzata ping sui dispositivi monitorMode='ping' del plant attivo
   *  (o UNO per deviceId): campioni pingLatency/packetLoss + stato
   *  online/offline onesto. */
  monitorPingSweep: async (input: PingSweepInput): Promise<PingSweepResult> => {
    const res = await fetch(v2Url('/monitoring/ping'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'PING_SWEEP_FAILED', body.error?.message ?? 'Errore spazzata ping', res.status)
    return body.data as PingSweepResult
  },

  /** Coda adozione: orfani + «da confermare» + sedi del plant. */
  adoptionQueue: (plantId?: string) => get<AdoptionQueue>('/adozione', { plantId }),

  /* --- 16.19 W21 — Wizard «Setup impianto» --- */

  /** FASE 2 — Scansione della rete dell'impianto: sweep TCP +
   *  identificazione batch (SNMP/banner/OUI) + persistenza job +
   *  confronto con l'inventario dichiarato. */
  setupScan: async (input: SetupScanInput): Promise<SetupScanResult> => {
    const res = await fetch(v2Url('/setup/scan'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SETUP_SCAN_FAILED', body.error?.message ?? 'Errore scansione setup', res.status)
    return body.data as SetupScanResult
  },

  /** FASE 3 — Verifica credenziali per OGNI apparato: SNMP
   *  multi-community + login SSH + presenza ping per i TLC. */
  setupVerify: async (input: SetupVerifyInput): Promise<SetupVerifyResult> => {
    const res = await fetch(v2Url('/setup/verify'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SETUP_VERIFY_FAILED', body.error?.message ?? 'Errore verifica credenziali', res.status)
    return body.data as SetupVerifyResult
  },

  /** FASE 4 — Adozione: scrive nel DB i candidati visti non in
   *  inventario (evidenza della scansione) + confronto finale. */
  setupAdopt: async (input: SetupAdoptInput): Promise<SetupAdoptResult> => {
    const res = await fetch(v2Url('/setup/adopt'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SETUP_ADOPT_FAILED', body.error?.message ?? 'Errore adozione candidati', res.status)
    return body.data as SetupAdoptResult
  },

  /** FASE 6 — Allarmi: assicura le regole richieste sul plant e valuta
   *  ORA i dati reali (eventi con dedup). */
  setupAlarms: async (input: SetupAlarmsInput): Promise<SetupAlarmsResult> => {
    const res = await fetch(v2Url('/setup/alarms'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SETUP_ALARMS_FAILED', body.error?.message ?? 'Errore attivazione allarmi', res.status)
    return body.data as SetupAlarmsResult
  },

  /** FASE 7 — Riepilogo finale: verifica globale contata dal DB reale
   *  (import, scan, credenziali, telemetria, topologia, MAC, allarmi,
   *  motori). */
  setupSummary: () => get<SetupSummaryResult>('/setup/summary'),

  /** W21-bis — Motore di monitoraggio continuo: stato VIVO
   *  (cicli, campioni, eventi, notifiche, errori). */
  setupEngineStatus: () => get<SetupEnginePage>('/setup/engine'),

  /** W21-bis — Avvia/arresta il motore per l'impianto attivo
   *  (primo ciclo subito, poi ogni intervalSec). */
  setupEngineAction: async (input: EngineInput): Promise<SetupEngineActionResult> => {
    const res = await fetch(v2Url('/setup/engine'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })
    if (res.status === 401) { window.location.reload(); throw new ApiError('UNAUTHORIZED', 'Sessione scaduta', 401) }
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'ENGINE_FAILED', body.error?.message ?? 'Errore motore monitoraggio', res.status)
    return body.data as SetupEngineActionResult
  },

  /** Azione UMANA di adozione (audit ADOZIONE_ADOPT). */
  adoptionAdopt: async (deviceId: string, locationId: string): Promise<{ id: string; action: string; locationId: string }> => {
    const res = await fetch(v2Url('/adozione'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'adopt', deviceId, locationId }),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'ADOPT_FAILED', body.error?.message ?? 'Errore adozione', res.status)
    return body.data as { id: string; action: string; locationId: string }
  },

  /* --- 16.7 W3.5 — Operazioni evolute --- */

  /** Regole evento: 10 regole SYS reali + regole utente. */
  eventPolicies: () => get<EventPoliciesPage>('/event-policies'),

  createEventPolicy: async (input: CreateEventPolicyInput): Promise<EventPolicyRow> => {
    const res = await fetch(v2Url('/event-policies'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione regola', res.status)
    return body.data as EventPolicyRow
  },

  updateEventPolicy: async (id: string, patch: UpdateEventPolicyInput): Promise<EventPolicyRow> => {
    const res = await fetch(v2Url(`/event-policies/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento regola', res.status)
    return body.data as EventPolicyRow
  },

  deleteEventPolicy: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/event-policies/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione regola', res.status)
    return body.data as { id: string }
  },

  /** OID custom (vuote nel DB reale: empty state onesto). */
  customOids: () => get<CustomOidsPage>('/custom-oids'),

  createCustomOid: async (input: CreateCustomOidInput): Promise<CustomOidRow> => {
    const res = await fetch(v2Url('/custom-oids'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione OID', res.status)
    return body.data as CustomOidRow
  },

  updateCustomOid: async (id: string, patch: UpdateCustomOidInput): Promise<CustomOidRow> => {
    const res = await fetch(v2Url(`/custom-oids/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento OID', res.status)
    return body.data as CustomOidRow
  },

  deleteCustomOid: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/custom-oids/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione OID', res.status)
    return body.data as { id: string }
  },

  /** Test SNMP LIVE di un OID custom (onesto: timeout in sandbox). */
  testCustomOid: async (id: string, deviceId?: string): Promise<CustomOidTestResult> => {
    const res = await fetch(v2Url(`/custom-oids/${id}/test`), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(deviceId ? { deviceId } : {}) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'TEST_FAILED', body.error?.message ?? 'Errore test OID', res.status)
    return body.data as CustomOidTestResult
  },

  /** Richieste di configurazione (guardrail + commit-confirm). */
  configRequests: () => get<ConfigRequestsPage>('/config-requests'),

  createConfigRequest: async (input: CreateConfigRequestInput): Promise<ConfigRequestRow> => {
    const res = await fetch(v2Url('/config-requests'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione richiesta', res.status)
    return body.data as ConfigRequestRow
  },

  configRequestAction: async (id: string, action: ConfigRequestAction): Promise<ConfigRequestRow> => {
    const res = await fetch(v2Url(`/config-requests/${id}/action`), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action }) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'ACTION_FAILED', body.error?.message ?? 'Errore azione richiesta', res.status)
    return body.data as ConfigRequestRow
  },

  /** Bulk config (ondate, v15 R8: max 50 target, dry-run onesto). */
  bulkConfigs: () => get<BulkConfigPage>('/bulk-config'),

  createBulkConfig: async (input: CreateBulkConfigInput): Promise<BulkConfigRow> => {
    const res = await fetch(v2Url('/bulk-config'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione ondata', res.status)
    return body.data as BulkConfigRow
  },

  /** Firmware center (schedulazione onesta, nessuna esecuzione replay). */
  firmwareJobs: () => get<FirmwareJobsPage>('/firmware'),

  createFirmwareJob: async (input: CreateFirmwareJobInput): Promise<FirmwareJobRow> => {
    const res = await fetch(v2Url('/firmware'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore schedulazione upgrade', res.status)
    return body.data as FirmwareJobRow
  },

  cancelFirmwareJob: async (id: string): Promise<FirmwareJobRow> => {
    const res = await fetch(v2Url(`/firmware/${id}/cancel`), { method: 'POST' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CANCEL_FAILED', body.error?.message ?? 'Errore annullamento upgrade', res.status)
    return body.data as FirmwareJobRow
  },

  /** Playbook (CRUD; esecuzione non disponibile in replay). */
  playbooks: () => get<PlaybooksPage>('/playbooks'),

  createPlaybook: async (input: CreatePlaybookInput): Promise<PlaybookRow> => {
    const res = await fetch(v2Url('/playbooks'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione playbook', res.status)
    return body.data as PlaybookRow
  },

  updatePlaybook: async (id: string, patch: UpdatePlaybookInput): Promise<PlaybookRow> => {
    const res = await fetch(v2Url(`/playbooks/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento playbook', res.status)
    return body.data as PlaybookRow
  },

  deletePlaybook: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/playbooks/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione playbook', res.status)
    return body.data as { id: string }
  },

  /** Automation task (CRUD; run non disponibile in replay). */
  automationTasks: () => get<AutomationTasksPage>('/automation-tasks'),

  createAutomationTask: async (input: CreateAutomationTaskInput): Promise<AutomationTaskRow> => {
    const res = await fetch(v2Url('/automation-tasks'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione automazione', res.status)
    return body.data as AutomationTaskRow
  },

  updateAutomationTask: async (id: string, patch: UpdateAutomationTaskInput): Promise<AutomationTaskRow> => {
    const res = await fetch(v2Url(`/automation-tasks/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento automazione', res.status)
    return body.data as AutomationTaskRow
  },

  deleteAutomationTask: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/automation-tasks/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione automazione', res.status)
    return body.data as { id: string }
  },

  /** Terminale SSH: tentativo onesto di porta 22 (mai sessione fittizia). */
  terminalProbe: async (deviceId: string): Promise<TerminalProbeResult> => {
    const res = await fetch(v2Url('/terminal/probe'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ deviceId }) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'PROBE_FAILED', body.error?.message ?? 'Errore sonda terminale', res.status)
    return body.data as TerminalProbeResult
  },

  /* --- 16.7 W7.0 — Integrazioni --- */

  /** Configurazioni integrazione (valori segreti mascherati «***»). */
  integrations: () => get<IntegrationsPage>('/integrations'),

  upsertIntegration: async (input: { key: string; category: string; value: string; isSecret?: boolean; note?: string; enabled?: boolean }): Promise<unknown> => {
    const res = await fetch(v2Url('/integrations'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPSERT_FAILED', body.error?.message ?? 'Errore salvataggio integrazione', res.status)
    return body.data
  },

  deleteIntegration: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/integrations?id=${encodeURIComponent(id)}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione integrazione', res.status)
    return body.data as { id: string }
  },

  /** Test di connessione REALE (in sandbox: esiti onesti, mai inventati). */
  testIntegration: async (input: IntegrationTestInput): Promise<IntegrationTestResult> => {
    const res = await fetch(v2Url('/integrations/test'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'TEST_FAILED', body.error?.message ?? 'Errore test connessione', res.status)
    return body.data as IntegrationTestResult
  },

  /** Endpoint webhook (firma HMAC-SHA256, consegne registrate). */
  webhooks: () => get<WebhooksPage>('/integrations/webhooks'),

  createWebhook: async (input: CreateWebhookInput): Promise<WebhookEndpointRow & { secretOneTime: string | null }> => {
    const res = await fetch(v2Url('/integrations/webhooks'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione webhook', res.status)
    return body.data as WebhookEndpointRow & { secretOneTime: string | null }
  },

  updateWebhook: async (id: string, patch: UpdateWebhookInput): Promise<WebhookEndpointRow> => {
    const res = await fetch(v2Url(`/integrations/webhooks/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento webhook', res.status)
    return body.data as WebhookEndpointRow
  },

  deleteWebhook: async (id: string): Promise<{ id: string }> => {
    const res = await fetch(v2Url(`/integrations/webhooks/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione webhook', res.status)
    return body.data as { id: string }
  },

  /** Consegna di test FIRMATA (verifica HMAC end-to-end). */
  testWebhook: async (id: string): Promise<WebhookTestResult> => {
    const res = await fetch(v2Url(`/integrations/webhooks/${id}/test`), { method: 'POST' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'TEST_FAILED', body.error?.message ?? 'Errore test consegna', res.status)
    return body.data as WebhookTestResult
  },

  /* --- 16.8 W2 — Report SLA, scheda intervento, report schedulati --- */

  /** Report SLA mensile + storico (campi REALI dei ticket, copertura dichiarata). */
  slaReport: (month?: string) => get<SlaReport>('/reports/sla', { month }),

  /** Dati REALI della scheda intervento per un ticket. */
  ticketDetail: (id: string) => get<TicketDetail>(`/tickets/${id}`),

  /** Report pianificati (CRUD; il motore non gira in riproduzione: onestà D2). */
  scheduledReports: () => get<ScheduledReportsPage>('/reports/scheduled'),

  createScheduledReport: async (input: CreateScheduledReportInput): Promise<ScheduledReportsPage> => {
    const res = await fetch(v2Url('/reports/scheduled'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione report pianificato', res.status)
    return body.data as ScheduledReportsPage
  },

  updateScheduledReport: async (id: string, patch: UpdateScheduledReportInput): Promise<ScheduledReportRow> => {
    const res = await fetch(v2Url(`/reports/scheduled/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento report', res.status)
    return body.data as ScheduledReportRow
  },

  deleteScheduledReport: async (id: string): Promise<{ id: string; deleted: boolean; removedArtifacts: number }> => {
    const res = await fetch(v2Url(`/reports/scheduled/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione report', res.status)
    return body.data as { id: string; deleted: boolean; removedArtifacts: number }
  },

  /* --- 16.8 W6 — Certificazione audit (export SHA-256, chain seal) --- */

  /** Export certificato del registro audit (manifest + digest). */
  auditExport: (f: { from?: number; to?: number; limit?: number } = {}) => get<AuditExport>('/audit/export', f),

  /** Stato della catena audit (conteggi + sigilli). */
  auditChain: () => get<AuditChainState>('/audit/chain'),

  /** Verifica crittografica integrale della catena (ricalcolo hash). */
  auditChainVerify: () => get<AuditChainVerify>('/audit/chain/verify'),

  /** Sigillo della catena (SUPER_ADMIN, irreversibile nel tempo). */
  auditSeal: async (): Promise<AuditSealResult> => {
    const res = await fetch(v2Url('/audit/seal'), { method: 'POST' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SEAL_FAILED', body.error?.message ?? 'Errore sigillo catena', res.status)
    return body.data as AuditSealResult
  },

  /** Archiviazione richiesta (solo «da confermare», audit ADOZIONE_DISMISS). */
  adoptionDismiss: async (deviceId: string): Promise<{ id: string; action: string }> => {
    const res = await fetch(v2Url('/adozione'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'dismiss', deviceId }),
    })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DISMISS_FAILED', body.error?.message ?? 'Errore archiviazione', res.status)
    return body.data as { id: string; action: string }
  },

  /* --- 16.9 W4 — Knowledge base --- */

  kb: (q?: string) => get<KbPage>('/kb', { q }),

  createKbArticle: async (input: CreateKbInput): Promise<KbArticleRow> => {
    const res = await fetch(v2Url('/kb'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione articolo', res.status)
    return body.data as KbArticleRow
  },

  updateKbArticle: async (id: string, patch: UpdateKbInput): Promise<KbArticleRow> => {
    const res = await fetch(v2Url(`/kb/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento articolo', res.status)
    return body.data as KbArticleRow
  },

  deleteKbArticle: async (id: string): Promise<{ id: string; deleted: boolean }> => {
    const res = await fetch(v2Url(`/kb/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione articolo', res.status)
    return body.data as { id: string; deleted: boolean }
  },

  kbFromTicket: async (ticketId: string): Promise<KbArticleRow> => {
    const res = await fetch(v2Url('/kb/from-ticket'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticketId }) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione da ticket', res.status)
    return body.data as KbArticleRow
  },

  /* --- 16.9 W4 — RMA guidata --- */

  rmaPlan: (deviceId: string) => get<RmaPlan>('/rma', { deviceId }),

  rmaExecute: async (input: RmaExecuteInput): Promise<{ newDeviceId: string; steps: Array<{ step: string; ok: boolean; detail: string }> }> => {
    const res = await fetch(v2Url('/rma'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'RMA_FAILED', body.error?.message ?? 'Errore esecuzione RMA', res.status)
    return body.data as { newDeviceId: string; steps: Array<{ step: string; ok: boolean; detail: string }> }
  },

  /* --- 16.9 W4 — Ondate --- */

  waves: () => get<WavesPage>('/waves'),

  createWave: async (input: CreateWaveInput): Promise<{ wave: WaveRow | null; preflight: Array<{ deviceId: string; hostname: string; ok: boolean; reason: string }>; batches: Array<{ number: number; deviceIds: string[]; isCanary: boolean }>; scarti: number }> => {
    const res = await fetch(v2Url('/waves'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione ondata', res.status)
    return body.data as { wave: WaveRow | null; preflight: Array<{ deviceId: string; hostname: string; ok: boolean; reason: string }>; batches: Array<{ number: number; deviceIds: string[]; isCanary: boolean }>; scarti: number }
  },

  deleteWave: async (id: string): Promise<{ id: string; deleted: boolean }> => {
    const res = await fetch(v2Url(`/waves/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione ondata', res.status)
    return body.data as { id: string; deleted: boolean }
  },

  /* --- 16.9 W4 — CVE --- */

  cveCatalog: () => get<CveCatalog>('/cve'),

  cveFindings: (status?: string) => get<CveFindingsPage>('/cve/findings', { status }),

  cveScan: async (): Promise<CveScanReport> => {
    const res = await fetch(v2Url('/cve/scan'), { method: 'POST' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'SCAN_FAILED', body.error?.message ?? 'Errore scan CVE', res.status)
    return body.data as CveScanReport
  },

  cveImport: async (input: CveImportInput): Promise<CveImportResult> => {
    const res = await fetch(v2Url('/cve/import'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'IMPORT_FAILED', body.error?.message ?? 'Errore importazione catalogo', res.status)
    return body.data as CveImportResult
  },

  cveFindingPatch: async (id: string, status: 'OPEN' | 'IGNORED' | 'RESOLVED'): Promise<{ id: string; status: string }> => {
    const res = await fetch(v2Url(`/cve/findings/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento finding', res.status)
    return body.data as { id: string; status: string }
  },

  /* --- 16.9 W4 — Speed test iperf3 --- */

  speedTests: (deviceId?: string) => get<SpeedTestsPage>('/speed-tests', { deviceId }),

  runSpeedTest: async (input: SpeedTestRunInput): Promise<SpeedTestRunResult> => {
    const res = await fetch(v2Url('/speed-tests'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'RUN_FAILED', body.error?.message ?? 'Errore speed test', res.status)
    return body.data as SpeedTestRunResult
  },

  /* --- 16.9 W4 — Amministrazione utenti/permessi/sessioni --- */

  adminUsers: () => get<AdminUsersPage>('/admin/users'),

  createUser: async (input: CreateUserInput): Promise<AdminUserRow> => {
    const res = await fetch(v2Url('/admin/users'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione utente', res.status)
    return body.data as AdminUserRow
  },

  updateUser: async (id: string, patch: UpdateUserInput): Promise<AdminUserRow> => {
    const res = await fetch(v2Url(`/admin/users/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento utente', res.status)
    return body.data as AdminUserRow
  },

  deleteUser: async (id: string): Promise<{ id: string; deleted: boolean }> => {
    const res = await fetch(v2Url(`/admin/users/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione utente', res.status)
    return body.data as { id: string; deleted: boolean }
  },

  adminPermissions: () => get<AdminPermissions>('/admin/permissions'),

  adminSessions: () => get<AdminSessions>('/admin/sessions'),

  /* --- 16.10 W8 — Impianti (multi-impianto, CRUD) --- */

  plants: () => get<PlantRow[]>('/plants', undefined, { noPlant: true }),

  createPlant: async (input: CreatePlantInput): Promise<PlantRow> => {
    const res = await fetch(v2Url('/plants'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione impianto', res.status)
    return body.data as PlantRow
  },

  updatePlant: async (id: string, patch: UpdatePlantInput): Promise<PlantRow> => {
    const res = await fetch(v2Url(`/plants/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento impianto', res.status)
    return body.data as PlantRow
  },

  deletePlant: async (id: string): Promise<{ id: string; deleted: boolean }> => {
    const res = await fetch(v2Url(`/plants/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione impianto', res.status)
    return body.data as { id: string; deleted: boolean }
  },

  /* --- 16.10 W8 — Import punti KMZ/KML (2 fasi, preview → conferma) --- */

  kmzPreview: async (plantId: string, file: File): Promise<KmzPreview> => {
    const form = new FormData()
    form.append('file', file)
    form.append('plantId', plantId)
    const res = await fetch(v2Url('/locations/import-kmz/preview'), { method: 'POST', body: form })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'KMZ_PREVIEW_FAILED', body.error?.message ?? 'Errore anteprima KMZ', res.status)
    return body.data as KmzPreview
  },

  kmzApply: async (input: KmzApplyInput): Promise<KmzApplyResult> => {
    const res = await fetch(v2Url('/locations/import-kmz/apply'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'KMZ_APPLY_FAILED', body.error?.message ?? 'Errore conferma import', res.status)
    return body.data as KmzApplyResult
  },

  /* --- 16.13 W11 — Import Excel installazione SETI (2 fasi) --- */

  xlsxPreview: async (plantId: string, file: File): Promise<XlsxPreview> => {
    const form = new FormData()
    form.append('file', file)
    form.append('plantId', plantId)
    const res = await fetch(v2Url('/import/xlsx/preview'), { method: 'POST', body: form })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'XLSX_PREVIEW_FAILED', body.error?.message ?? 'Errore anteprima Excel', res.status)
    return body.data as XlsxPreview
  },

  xlsxApply: async (input: XlsxApplyInput): Promise<XlsxApplyResult> => {
    const res = await fetch(v2Url('/import/xlsx/apply'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'XLSX_APPLY_FAILED', body.error?.message ?? 'Errore conferma import', res.status)
    return body.data as XlsxApplyResult
  },

  /* --- 16.10 W8 — Gestione collegamenti topologici --- */

  topologyLinks: (f: { source?: string; confidence?: string; confirmed?: 'true' | 'false'; q?: string; page?: number; pageSize?: number }) =>
    get<TopologyLinksPage>('/topology/links', f),

  createTopologyLink: async (input: CreateTopologyLinkInput): Promise<TopologyLinkRow> => {
    const res = await fetch(v2Url('/topology/links'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'CREATE_FAILED', body.error?.message ?? 'Errore creazione collegamento', res.status)
    return body.data as TopologyLinkRow
  },

  updateTopologyLink: async (id: string, patch: UpdateTopologyLinkInput): Promise<TopologyLinkRow> => {
    const res = await fetch(v2Url(`/topology/links/${id}`), { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'UPDATE_FAILED', body.error?.message ?? 'Errore aggiornamento collegamento', res.status)
    return body.data as TopologyLinkRow
  },

  deleteTopologyLink: async (id: string): Promise<{ id: string; deleted: boolean }> => {
    const res = await fetch(v2Url(`/topology/links/${id}`), { method: 'DELETE' })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'DELETE_FAILED', body.error?.message ?? 'Errore eliminazione collegamento', res.status)
    return body.data as { id: string; deleted: boolean }
  },

  purgeTopologyLinks: async (input: PurgeLinksInput): Promise<PurgeLinksResult> => {
    const res = await fetch(v2Url('/topology/links/purge'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input) })
    const body = await res.json()
    if (!body.ok) throw new ApiError(body.error?.code ?? 'PURGE_FAILED', body.error?.message ?? 'Errore pulizia inferenze', res.status)
    return body.data as PurgeLinksResult
  },
}

export type { UiStatus, Severity, DeviceRow, DeviceOverview, WeakLinkRow, AlarmRow, CameraRow, StreamRegistryRow, NocSummary, TicketRow, MaintenanceRow, AuditRow, AdminStats, DeviceGroupRow, GroupRule, AvailabilityRow, AvailabilityByLocationRow, DevicePortsPage, DevicePortRow, MacInventoryPage, MacInventoryRow, DiscoveryHealth, DiscoveryScanResult, VendorProbeResult, VendorBatchResult, DiscoveryL2Result, DiscoveryL2Input, OuiLookupResult, AdoptionQueue, AdoptionCandidate, SlaReport, TicketDetail, ScheduledReportsPage, ScheduledReportRow, CreateScheduledReportInput, UpdateScheduledReportInput, AuditExport, AuditChainState, AuditChainVerify, AuditSealResult, KbPage, KbArticleRow, CreateKbInput, UpdateKbInput, RmaPlan, RmaExecuteInput, WaveRow, WavesPage, CreateWaveInput, CveCatalog, CveFindingsPage, CveScanReport, CveImportResult, CveImportInput, SpeedTestsPage, SpeedTestRunResult, SpeedTestRunInput, AdminUsersPage, AdminUserRow, CreateUserInput, UpdateUserInput, AdminPermissions, AdminSessions, PlantRow, CreatePlantInput, UpdatePlantInput, KmzPreview, KmzApplyInput, KmzApplyResult, XlsxPreview, XlsxApplyInput, XlsxApplyResult, TopologyLinkRow, TopologyLinksPage, CreateTopologyLinkInput, UpdateTopologyLinkInput, PurgeLinksInput, PurgeLinksResult }
