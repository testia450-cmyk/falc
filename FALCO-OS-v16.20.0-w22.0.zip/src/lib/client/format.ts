/* ================================================================
 * FALCO-OS v16 — Formattatori (convenzione onesta)
 * «n.d.» quando il dato manca; MAI zero spacciato per misura.
 * ================================================================ */

export function fmtDbm(v: number | null | undefined): string {
  if (v == null || v === 0) return 'n.d.'
  return `${v} dBm`
}

export function fmtPct(v: number | null | undefined): string {
  if (v == null || v === 0) return 'n.d.'
  return `${v}%`
}

export function fmtMbps(v: number | null | undefined): string {
  if (v == null) return 'n.d.'
  return `${v >= 100 ? Math.round(v) : Math.round(v * 100) / 100} Mbps`
}

export function fmtUptime(seconds: number): string {
  if (!seconds || seconds <= 0) return 'n.d.'
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  if (d > 0) return `${d}g ${h}h`
  if (h > 0) return `${h}h ${m}m`
  return `${m}m`
}

export function fmtTime(ts: number | null | undefined): string {
  if (!ts) return '—'
  return new Date(ts).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

export function fmtDateTime(ts: number | null | undefined): string {
  if (!ts) return '—'
  return new Date(ts).toLocaleString('it-IT', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

export function fmtDateTimeFull(ts: number | null | undefined): string {
  if (!ts) return '—'
  return new Date(ts).toLocaleString('it-IT', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  })
}

export function fmtRelative(ts: number | null | undefined, now = Date.now()): string {
  if (!ts) return 'mai'
  const diff = now - ts
  const sec = Math.floor(diff / 1000)
  if (sec < 10) return 'ora'
  if (sec < 60) return `${sec} s fa`
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min} min fa`
  const h = Math.floor(min / 60)
  if (h < 24) return `${h} h fa`
  const d = Math.floor(h / 24)
  return `${d} g fa`
}

export function fmtAgeMinutes(minutes: number): string {
  if (minutes < 60) return `${Math.round(minutes)} min`
  const h = minutes / 60
  if (h < 24) return `${h.toFixed(h < 10 ? 1 : 0)} h`
  return `${Math.floor(h / 24)} g ${Math.floor(h % 24)} h`
}

export function fmtNumber(n: number): string {
  return n.toLocaleString('it-IT')
}

/** Etichette tipo dispositivo (vocabolario del dominio, mai inventate).
 *  v16.8: nuovi tipi riconosciuti dal motore di classificazione. */
export const TYPE_LABELS: Record<string, string> = {
  AP: 'Radio AP', STA: 'Radio Station', CAMERA: 'Telecamera', LPR: 'Telecamera LPR',
  SWITCH: 'Switch', NVR: 'NVR', GATEWAY: 'Gateway', SERVER: 'Server',
  UNKNOWN: 'Da classificare', ONT: 'ONT', ROUTER: 'Router',
  // --- v16.8 ---
  UPS: 'Gruppo di continuità',
  PRINTER: 'Stampante di rete',
  PBX: 'Centralino VoIP',
  PHONE: 'Telefono SIP',
  NAS: 'NAS',
  MODEM: 'Modem/CPE',
  FIREWALL: 'Firewall',
  CLIENT: 'Client',
}

export function typeLabel(t: string): string {
  return TYPE_LABELS[t?.toUpperCase()] ?? t
}

/** Etichette stato (badge: colore + icona + testo, §4.2) */
export const STATUS_META: Record<string, { label: string; cls: string; dot: string }> = {
  ONLINE: { label: 'Online', cls: 'bg-ok-soft text-ok border-ok/40', dot: 'bg-ok' },
  DEGRADED: { label: 'Degradato', cls: 'bg-warn-soft text-warn border-warn/40', dot: 'bg-warn' },
  OFFLINE: { label: 'Offline', cls: 'bg-crit-soft text-crit-text border-crit/40', dot: 'bg-crit' },
  MAINTENANCE: { label: 'Manutenzione', cls: 'bg-info-soft text-info border-info/40', dot: 'bg-info' },
  UNKNOWN: { label: 'Sconosciuto', cls: 'bg-warn-soft text-warn border-warn/40', dot: 'bg-warn' },
  NOT_MONITORED: { label: 'Non monitorato', cls: 'bg-crit-soft text-crit-text border-crit/40', dot: 'bg-crit' },
}

/** Severità allarmi */
export const SEVERITY_META: Record<string, { label: string; cls: string }> = {
  CRITICAL: { label: 'Critico', cls: 'bg-crit-soft text-crit-text border-crit/40' },
  HIGH: { label: 'Alto', cls: 'bg-warn-soft text-warn border-warn/40' },
  AVERAGE: { label: 'Medio', cls: 'bg-info-soft text-info border-info/40' },
  WARNING: { label: 'Attenzione', cls: 'bg-info-soft text-info border-info/40' },
  INFO: { label: 'Info', cls: 'bg-info-soft text-info border-info/40' },
}
