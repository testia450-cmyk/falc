/* ================================================================
 * FALCO-OS v16 — Piano di import punti (KMZ/KML) · porta fedele v15
 * (v11.16, richiesta operatore originale: «import punti con kmz o
 * kml e poi associazione ipotizzata tra punti e dispositivi, la
 * conferma va sempre all'utente, come fa UISP»).
 *
 * L'import NON scrive mai nulla da solo. Produce un PIANO:
 *   · punti del file → azione per ogni punto:
 *       CREATE         (nessun punto corrispondente in anagrafica)
 *       UPDATE_COORDS  (punto esistente matchato, coordinate diverse)
 *       NOOP           (punto esistente, coordinate già uguali)
 *   · proposte dispositivo→punto SOLO per dispositivi senza punto
 *     reale: il motore ipotizza, L'OPERATORE conferma o toglie.
 * Le conferme diventano assegnazioni MANUALI (locationAssignedBy '')
 * → àncore per il motore topologico (che non le tocca mai).
 *
 * MATCHING DISPOSITIVO ↔ PUNTO (deterministico, onesto):
 *   1. ExtendedData diretta: il KML può portare IP/hostname nel
 *      placemark → corrispondenza certa (ALTA);
 *   2. Nome: token significativi (≥4 caratteri) comuni tra hostname
 *      e nome del punto. Contenimento completo → ALTA; ≥2 token
 *      comuni → MEDIA; 1 token → BASSA;
 *   3. Parità di punteggio tra punti DIVERSI per lo stesso
 *      dispositivo → NESSUNA proposta (ambiguo: decide l'operatore).
 * Pure core separato dal I/O (rotte API) → testabile senza database.
 * ================================================================ */

import type { ParsedPlacemark } from './kmz-parser'

/* ---------------- Input / Output ---------------- */

export interface ImportLocationLite {
  id: string
  identifier: string
  name: string
  address: string
  lat: number | null
  lng: number | null
}

export interface ImportDeviceLite {
  id: string
  hostname: string
  ip: string
  type: string
  locationId: string | null
  /** '' | null = manuale · 'AUTO' = motore topologico */
  locationAssignedBy?: string | null
}

export type ProposalConfidence = 'ALTA' | 'MEDIA' | 'BASSA'

export interface DeviceProposal {
  deviceId: string
  hostname: string
  ip: string
  type: string
  confidence: ProposalConfidence
  /** perché lo proponiamo — mostrato all'operatore che conferma */
  basis: string
}

export type PointAction = 'CREATE' | 'UPDATE_COORDS' | 'NOOP'

export interface PointProposal {
  placemarkIndex: number
  name: string
  description: string
  lat: number
  lng: number
  action: PointAction
  existingLocationId: string | null
  existingLocationName: string | null
  identifier: string | null
  reason: string
  deviceProposals: DeviceProposal[]
}

export interface PointImportPlan {
  points: PointProposal[]
  created: number
  updated: number
  noop: number
  skipped: Array<{ name: string; reason: string }>
  /** dispositivi senza punto reale ancora senza proposta */
  unplacedDevices: number
  totalDevices: number
}

/* ---------------- Normalizzazione ---------------- */

const SIGNIFICANT = 4 // lunghezza minima parola significativa

function norm(s: string): string {
  return String(s ?? '')
    .toLowerCase()
    .replaceAll('à', 'a').replaceAll('è', 'e').replaceAll('é', 'e')
    .replaceAll('ì', 'i').replaceAll('ò', 'o').replaceAll('ù', 'u')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
}

function tokens(s: string): string[] {
  return norm(s).split(' ').filter((t) => t.length >= SIGNIFICANT)
}

/** chiavi ExtendedData che identificano un apparato (case-insensitive) */
const ED_DEVICE_KEYS = /(^|_)(ip|host|hostname|device|dispositivo|apparato|mac|name)(_|$)/i

/** derive identificatore leggibile da un nome punto: «Torre Nord» → KMZ-TORRE-NORD */
export function deriveIdentifier(name: string, existingIdentifiers: Set<string>): string {
  const base = `KMZ-${norm(name).replaceAll(' ', '-').toUpperCase().slice(0, 40) || 'PUNTO'}`
  if (!existingIdentifiers.has(base)) return base
  let n = 2
  while (existingIdentifiers.has(`${base}-${n}`)) n += 1
  return `${base}-${n}`
}

/* ---------------- Match punto esistente ---------------- */

interface LocMatch {
  locationId: string
  locationName: string
  matchedBy: 'nome' | 'identificatore' | 'parziale'
}

function matchPlacemarkToLocation(
  pmName: string,
  locations: ImportLocationLite[],
  used: Set<string>,
): LocMatch | null {
  const pmNorm = norm(pmName)
  if (!pmNorm) return null

  /* 1) match esatto: nome o identificatore */
  for (const loc of locations) {
    if (used.has(loc.id)) continue
    if (norm(loc.name) === pmNorm || norm(loc.identifier) === pmNorm) {
      return {
        locationId: loc.id,
        locationName: loc.name,
        matchedBy: norm(loc.identifier) === pmNorm && norm(loc.name) !== pmNorm ? 'identificatore' : 'nome',
      }
    }
  }

  /* 2) match parziale: parole significative in comune */
  const pmWords = tokens(pmName)
  if (pmWords.length === 0) return null
  for (const loc of locations) {
    if (used.has(loc.id)) continue
    const locWords = tokens(loc.name)
    const common = locWords.filter((w) => pmWords.includes(w))
    if (common.length >= 2 || (common.length >= 1 && locWords.length <= 2 && pmWords.length <= 2)) {
      return { locationId: loc.id, locationName: loc.name, matchedBy: 'parziale' }
    }
  }
  return null
}

/* ---------------- Punteggio dispositivo ↔ placemark ---------------- */

interface DeviceScore {
  score: number
  confidence: ProposalConfidence
  basis: string
}

function scoreDevicePlacemark(
  dev: ImportDeviceLite,
  pm: ParsedPlacemark,
): DeviceScore | null {
  /* 1) ExtendedData diretta: certezza */
  for (const [key, value] of Object.entries(pm.extendedData ?? {})) {
    if (!ED_DEVICE_KEYS.test(key)) continue
    const v = norm(value)
    if (!v) continue
    if (norm(dev.ip) === v) {
      return { score: 100, confidence: 'ALTA', basis: `IP nel KML (${key}=${value})` }
    }
    if (norm(dev.hostname) === v) {
      return { score: 95, confidence: 'ALTA', basis: `hostname nel KML (${key}=${value})` }
    }
    if (norm(dev.hostname).includes(v) && v.length >= 4) {
      return { score: 85, confidence: 'ALTA', basis: `nome contiene «${value}» (KML)` }
    }
  }

  /* 2) token in comune hostname ↔ nome punto */
  const devWords = tokens(dev.hostname)
  const pmWords = tokens(pm.name)
  if (devWords.length === 0 || pmWords.length === 0) return null
  const common = pmWords.filter((w) => devWords.includes(w))
  if (common.length === 0) {
    /* prova anche la description (es. «Camere Scuola Media») */
    const descWords = tokens(pm.description)
    const commonDesc = descWords.filter((w) => devWords.includes(w))
    if (commonDesc.length >= 2) {
      return {
        score: 55,
        confidence: 'MEDIA',
        basis: `descrizione KML contiene «${commonDesc.join(' ')}»`,
      }
    }
    return null
  }
  if (common.length === pmWords.length && pmWords.length >= 2) {
    /* tutti i token del punto sono nel hostname: es. «Scuola Media» ⊂ CAM-SCUOLA-MEDIA-1 */
    return { score: 80, confidence: 'ALTA', basis: `nome contiene «${common.join(' ')}»` }
  }
  if (common.length >= 2) {
    return { score: 60, confidence: 'MEDIA', basis: `nome contiene «${common.join(' ')}»` }
  }
  return { score: 30, confidence: 'BASSA', basis: `nome contiene «${common[0]}»` }
}

/* ---------------- Pure core ---------------- */

/**
 * Costruisce il piano di import. NESSUNA scrittura: l'operatore
 * vede, modifica (spunta/toglie dispositivi), conferma; la rotta
 * apply esegue solo ciò che è stato confermato.
 *
 * @param placemarks   placemark validi dal file (parsePointsFile)
 * @param locations    punti esistenti dell'impianto
 * @param devices      dispositivi dell'impianto
 * @param unplacedLocationIds id dei punti «Da posizionare» (UNPLACED):
 *                     i dispositivi lì sopra sono proponibili
 */
export function planPointImport(
  placemarks: ParsedPlacemark[],
  locations: ImportLocationLite[],
  devices: ImportDeviceLite[],
  unplacedLocationIds: string[] = [],
): PointImportPlan {
  const unplaced = new Set(unplacedLocationIds)
  const existingIdentifiers = new Set(locations.map((l) => l.identifier))
  const usedLocations = new Set<string>()

  /* ---- fase 1: piano per ogni placemark ---- */
  const points: PointProposal[] = []
  const skipped: Array<{ name: string; reason: string }> = []
  const seenNames = new Set<string>()

  placemarks.forEach((pm, idx) => {
    const name = pm.name?.trim() ?? ''
    if (!name) {
      skipped.push({ name: `#${idx + 1}`, reason: 'placemark senza nome' })
      return
    }
    const nameKey = norm(name)
    if (seenNames.has(nameKey)) {
      skipped.push({ name, reason: 'duplicato nello stesso file' })
      return
    }
    seenNames.add(nameKey)

    const match = matchPlacemarkToLocation(name, locations, usedLocations)
    let action: PointAction
    let reason: string
    let identifier: string | null = null

    if (match) {
      usedLocations.add(match.locationId)
      const loc = locations.find((l) => l.id === match.locationId)!
      const moved =
        loc.lat == null ||
        loc.lng == null ||
        Math.abs((loc.lat ?? 0) - pm.lat) > 1e-6 ||
        Math.abs((loc.lng ?? 0) - pm.lng) > 1e-6
      action = moved ? 'UPDATE_COORDS' : 'NOOP'
      reason = moved
        ? `punto esistente (${match.matchedBy}: «${loc.name}») — coordinate aggiornate`
        : `punto esistente (${match.matchedBy}: «${loc.name}») — coordinate già uguali`
    } else {
      action = 'CREATE'
      identifier = deriveIdentifier(name, existingIdentifiers)
      existingIdentifiers.add(identifier)
      reason = 'nessun punto corrispondente — verrà creato'
    }

    points.push({
      placemarkIndex: idx,
      name,
      description: pm.description ?? '',
      lat: pm.lat,
      lng: pm.lng,
      action,
      existingLocationId: match?.locationId ?? null,
      existingLocationName: match?.locationName ?? null,
      identifier,
      reason,
      deviceProposals: [],
    })
  })

  /* ---- fase 2: proposte dispositivo → punto ---- */
  /* perimetro proponibile: dispositivi SENZA punto reale */
  const candidates = devices.filter(
    (d) => d.locationId == null || unplaced.has(d.locationId),
  )

  /* punteggio di ogni coppia (dispositivo, placemark-index) */
  const bestByDevice = new Map<string, { idx: number; score: DeviceScore; tie: boolean }>()
  for (const dev of candidates) {
    let bestIdx = -1
    let bestScore: DeviceScore | null = null
    let tie = false
    for (const p of points) {
      const pm = placemarks[p.placemarkIndex]
      const s = scoreDevicePlacemark(dev, pm)
      if (!s) continue
      if (bestScore == null || s.score > bestScore.score) {
        bestIdx = p.placemarkIndex
        bestScore = s
        tie = false
      } else if (s.score === bestScore.score) {
        tie = true
      }
    }
    if (bestScore != null && bestIdx >= 0) {
      bestByDevice.set(dev.id, { idx: bestIdx, score: bestScore, tie })
    }
  }

  for (const dev of candidates) {
    const entry = bestByDevice.get(dev.id)
    if (!entry || entry.tie) continue // ambiguo → l'operatore decide a mano
    const point = points.find((p) => p.placemarkIndex === entry.idx)
    if (!point) continue
    point.deviceProposals.push({
      deviceId: dev.id,
      hostname: dev.hostname,
      ip: dev.ip,
      type: dev.type,
      confidence: entry.score.confidence,
      basis: entry.score.basis,
    })
  }

  /* dispositivi senza punto reale ancora senza proposta */
  const proposedDeviceIds = new Set<string>()
  for (const p of points) {
    for (const dp of p.deviceProposals) proposedDeviceIds.add(dp.deviceId)
  }

  return {
    points,
    created: points.filter((p) => p.action === 'CREATE').length,
    updated: points.filter((p) => p.action === 'UPDATE_COORDS').length,
    noop: points.filter((p) => p.action === 'NOOP').length,
    skipped,
    unplacedDevices: candidates.length - proposedDeviceIds.size,
    totalDevices: candidates.length,
  }
}

/* ---------------- Payload di apply (confermato dall'operatore) ---------------- */

export interface ApplyPointItem {
  placemarkIndex: number
  action: PointAction
  existingLocationId: string | null
  deviceIds: string[]
}

export interface ApplyPointImport {
  fileId: string
  plantId: string
  points: ApplyPointItem[]
}
