/* ================================================================
 * FALCO-OS v16 — METRICHE RADIO (port dal backend v15.16.0)
 * Provenienza: src/lib/radio-metrics.ts:20-54 (repo v15.16.0)
 * Calcolo puro, onesto: input mancante → null, MAI 0 inventato.
 * ================================================================ */

/** SNR = segnale − noise floor (dB). Null se manca uno dei due o è 0
 *  (0 dBm segnale = device mai interrogato, 0 noise = non letto). */
export function computeSnr(signalDbm: number | null | undefined, noiseFloorDbm: number | null | undefined): number | null {
  if (signalDbm == null || noiseFloorDbm == null) return null
  if (signalDbm === 0 || noiseFloorDbm === 0) return null
  return Math.round((signalDbm - noiseFloorDbm) * 10) / 10
}

/** Link mode dedotta: una stazione vista dall'AP = PTP; più di una = PTMP.
 *  Null se il tipo non è radio o non ci sono stazioni. Per le STA il
 *  proprio conteggio non significa nulla (l'unica «stazione» che vedono
 *  è l'AP di uplink): il linkMode della STA si copia dall'AP. */
export function deduceLinkMode(deviceType: string | null | undefined, stationCount: number | null | undefined): 'PTP' | 'PTMP' | null {
  const t = String(deviceType ?? '').toUpperCase()
  const isRadio = t === 'AP' || t === 'BRIDGE' || t === 'REPEATER' || t === 'WIRELESS_CONTROLLER'
  if (!isRadio) return null
  if (stationCount == null || stationCount <= 0) return null
  return stationCount === 1 ? 'PTP' : 'PTMP'
}

/* ================================================================
 * Punteggio di salute radio — port IDENTICO di
 * link-detail.ts:129 computeSignalScore (repo v15.16.0):
 * −50 dBm = 100 excellent · −65 = 80 good · −75 = 60 fair
 * −85 = 30 poor · sotto −90 = critical.
 * ================================================================ */

export type HealthLabel = 'excellent' | 'good' | 'fair' | 'poor' | 'critical'

export function computeSignalScore(signalDbm: number): {
  score: number
  label: HealthLabel
  color: string
} {
  if (signalDbm >= -50) return { score: 100, label: 'excellent', color: '#10b981' }
  if (signalDbm >= -65) return { score: 80, label: 'good', color: '#34d399' }
  if (signalDbm >= -75) return { score: 60, label: 'fair', color: '#f59e0b' }
  if (signalDbm >= -85) return { score: 30, label: 'poor', color: '#f97316' }
  return { score: Math.max(0, 30 + (signalDbm + 85) * 3), label: 'critical', color: '#ef4444' }
}

/** Semantica del segnale per endpoint radio (piano v16 §1.4):
 *  STA = segnale di UPLINK verso il proprio AP (il suo signalStrength
 *  È il link); AP = aggregato per stazione (per l'AP si mostra la
 *  stazione più debole). Questa funzione dice QUALE dBm esporre. */
export function uplinkSignalDbm(device: {
  type: string
  signalStrength: number
  stationSignals?: number[]
}): number | null {
  const t = String(device.type ?? '').toUpperCase()
  if (t === 'STA') {
    // 0 = mai interrogato (convenzione onesta del sistema) → null, mai 0
    return device.signalStrength !== 0 ? device.signalStrength : null
  }
  if (t === 'AP' && device.stationSignals && device.stationSignals.length > 0) {
    const valid = device.stationSignals.filter((s) => s !== 0)
    if (valid.length === 0) return null
    return Math.min(...valid)
  }
  return null
}
