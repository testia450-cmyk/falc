/* ================================================================
 * FALCO-OS v16 — GERARCHIA DI RETE (port dal backend v15.16.0)
 * Provenienza: src/lib/topology-reconstruction.ts:968-1175 (repo v15.16.0)
 *   · TierEdgeInput, NetworkTiers, attachCostOf, UnionFind, pairKey
 *   · computeNetworkTiers (albero unico con componenti manuali
 *     autoritative + aggancio Prim a costo minimo)
 *   · pickGateway (:1187-1225), buildNetworkBlocks (:1235-1263),
 *     TYPE_BLOCK_LABEL (:232), INFRA_TYPES (:162)
 * Regola v16 §6.2: NESSUNA seconda logica di albero nel frontend —
 * il grafo che si vede qui è calcolato da questa funzione portata.
 * ================================================================ */

export interface TierEdgeInput {
  aId: string
  bId: string
  weight: number
  manual?: boolean
  ev?: string
}

export interface NetworkTiers {
  tierOf: Map<string, number>
  parentOf: Map<string, string>
  gatewayId: string | null
  treePairs: Set<string>
  discardedAutoEdges: Array<{ aId: string; bId: string; ev?: string }>
}

export const INFRA_TYPES = new Set([
  'GATEWAY', 'ROUTER', 'FIREWALL', 'SWITCH', 'AP', 'BRIDGE', 'REPEATER',
])

const TYPE_BLOCK_LABEL: Record<string, string> = {
  GATEWAY: 'Gateway / Uplink',
  ROUTER: 'Router',
  FIREWALL: 'Firewall',
  SWITCH: 'Switch',
  AP: 'Radio / Antenne AP',
  STA: 'Radio Station',
  BRIDGE: 'Bridge',
  REPEATER: 'Ripetitori',
  NVR: 'Registratori NVR',
  CAMERA: 'Telecamere',
  LPR: 'Telecamere LPR',
  PRINTER: 'Stampanti',
  SERVER: 'Server',
  CLIENT: 'Client',
  UNKNOWN: 'Da classificare',
}

function pairKey(a: string, b: string): string {
  return a < b ? `${a}::${b}` : `${b}::${a}`
}

function attachCostOf(e: TierEdgeInput): number {
  if (e.ev && TIER_ATTACH_COST[e.ev] !== undefined) return TIER_ATTACH_COST[e.ev]
  return e.weight
}

import { TIER_ATTACH_COST } from './link-rules'

class UnionFind {
  private parent = new Map<string, string>()
  find(x: string): string {
    let root = this.parent.get(x) ?? x
    while (this.parent.has(root)) root = this.parent.get(root) as string
    let cur = x
    while (cur !== root) {
      const next = this.parent.get(cur) ?? root
      this.parent.set(cur, root)
      cur = next
    }
    return root
  }
  union(a: string, b: string): void {
    const ra = this.find(a)
    const rb = this.find(b)
    if (ra === rb) return
    if (ra < rb) this.parent.set(rb, ra)
    else this.parent.set(ra, rb)
  }
}

export interface TiersNode {
  id: string
  type: string
  ip?: string | null
  hostname?: string | null
  model?: string | null
}

export function computeNetworkTiers(
  nodes: TiersNode[],
  edges: TierEdgeInput[],
  options?: { preferredRootId?: string | null },
): NetworkTiers {
  const manualEdges = edges.filter((e) => e.manual && e.aId !== e.bId)
  const autoByPair = new Map<string, TierEdgeInput>()
  for (const e of edges) {
    if (e.manual || e.aId === e.bId) continue
    const key = pairKey(e.aId, e.bId)
    const cur = autoByPair.get(key)
    if (!cur || attachCostOf(e) < attachCostOf(cur)) autoByPair.set(key, e)
  }
  const autoEdges = [...autoByPair.values()]

  const uf = new UnionFind()
  for (const e of manualEdges) uf.union(e.aId, e.bId)
  const manualAdj = new Map<string, string[]>()
  const addManual = (a: string, b: string): void => {
    let arr = manualAdj.get(a)
    if (!arr) { arr = []; manualAdj.set(a, arr) }
    arr.push(b)
  }
  for (const e of manualEdges) {
    addManual(e.aId, e.bId)
    addManual(e.bId, e.aId)
  }

  const discardedAutoEdges: Array<{ aId: string; bId: string; ev?: string }> = []
  const interAuto: TierEdgeInput[] = []
  for (const e of autoEdges) {
    if (uf.find(e.aId) === uf.find(e.bId)) {
      discardedAutoEdges.push({ aId: e.aId, bId: e.bId, ev: e.ev })
    } else {
      interAuto.push(e)
    }
  }

  const adjacency = new Map<string, Array<{ to: string }>>()
  const addAdj = (a: string, b: string): void => {
    let arr = adjacency.get(a)
    if (!arr) { arr = []; adjacency.set(a, arr) }
    arr.push({ to: b })
  }
  for (const e of [...manualEdges, ...autoEdges]) {
    addAdj(e.aId, e.bId)
    addAdj(e.bId, e.aId)
  }
  const chosenRoot = options?.preferredRootId
    ? nodes.find((n) => n.id === options.preferredRootId)?.id ?? null
    : null
  const gatewayId = chosenRoot ?? pickGateway(nodes, adjacency)

  const tierOf = new Map<string, number>()
  const parentOf = new Map<string, string>()
  const treePairs = new Set<string>()

  if (gatewayId) {
    const rootComp = uf.find(gatewayId)
    tierOf.set(gatewayId, 0)
    const compTier = new Map<string, number>()
    compTier.set(rootComp, 0)

    const spreadComponent = (compRoot: string, entry: string, baseTier: number): void => {
      const queue: Array<{ id: string; depth: number }> = [{ id: entry, depth: 0 }]
      const seen = new Set<string>([entry])
      while (queue.length > 0) {
        const { id: cur, depth } = queue.shift() as { id: string; depth: number }
        for (const nb of manualAdj.get(cur) ?? []) {
          if (seen.has(nb) || uf.find(nb) !== compRoot) continue
          seen.add(nb)
          tierOf.set(nb, baseTier + depth + 1)
          parentOf.set(nb, cur)
          treePairs.add(pairKey(cur, nb))
          queue.push({ id: nb, depth: depth + 1 })
        }
      }
    }
    spreadComponent(rootComp, gatewayId, 0)

    const placedComps = new Set<string>([rootComp])
    for (;;) {
      let bestEdge: TierEdgeInput | null = null
      let bestFromComp = ''
      let bestToComp = ''
      let bestKey = ''
      for (const e of interAuto) {
        const ca = uf.find(e.aId)
        const cb = uf.find(e.bId)
        const from = placedComps.has(ca) && !placedComps.has(cb) ? ca : placedComps.has(cb) && !placedComps.has(ca) ? cb : null
        if (from === null) continue
        const to = from === ca ? cb : ca
        const key = pairKey(e.aId, e.bId)
        const cost = attachCostOf(e)
        const bestCost = bestEdge ? attachCostOf(bestEdge) : Number.POSITIVE_INFINITY
        if (!bestEdge || cost < bestCost || (cost === bestCost && key < bestKey)) {
          bestEdge = e
          bestFromComp = from
          bestToComp = to
          bestKey = key
        }
      }
      if (!bestEdge) break
      const entry = uf.find(bestEdge.aId) === bestToComp ? bestEdge.aId : bestEdge.bId
      const other = entry === bestEdge.aId ? bestEdge.bId : bestEdge.aId
      const t = (compTier.get(bestFromComp) ?? 0) + 1
      compTier.set(bestToComp, t)
      placedComps.add(bestToComp)
      tierOf.set(entry, t)
      parentOf.set(entry, other)
      treePairs.add(pairKey(entry, other))
      spreadComponent(bestToComp, entry, t)
    }
  }

  let maxTier = 0
  for (const t of tierOf.values()) if (t > maxTier) maxTier = t
  for (const n of nodes) {
    if (!tierOf.has(n.id)) tierOf.set(n.id, maxTier + 1)
  }

  return { tierOf, parentOf, gatewayId, treePairs, discardedAutoEdges }
}

/** Sceglie la radice: GATEWAY > ROUTER > FIREWALL > infra col massimo grado.
 * Convenzione di rete: il gateway è il MikroTik a x.x.x.1. */
export function pickGateway(
  nodes: TiersNode[],
  adjacency: Map<string, Array<{ to: string }>>,
): string | null {
  const typeRank = (t: string): number => {
    const u = t.toUpperCase()
    if (u === 'GATEWAY') return 0
    if (u === 'ROUTER') return 1
    if (u === 'FIREWALL') return 2
    if (INFRA_TYPES.has(u)) return 3
    return 9
  }
  const isDotOne = (n: TiersNode): boolean => !!n.ip && /\.1$/.test(n.ip)
  const isMikrotikHint = (n: TiersNode): boolean =>
    /mikrotik|routeros|rb\d|crs\d|hAP|hex\b|lhg|sxt|cmap/i.test(`${n.hostname || ''} ${n.model || ''}`)
  interface GwCand { id: string; rank: number; degree: number; dotOne: boolean; mtHint: boolean }
  const better = (a: GwCand, b: GwCand): boolean => {
    if (a.rank !== b.rank) return a.rank < b.rank
    if (a.mtHint !== b.mtHint) return a.mtHint
    if (a.dotOne !== b.dotOne) return a.dotOne
    return a.degree > b.degree
  }
  let best: GwCand | null = null
  for (const n of nodes) {
    const rank = typeRank(n.type)
    if (rank >= 9) continue
    const cand: GwCand = {
      id: n.id,
      rank,
      degree: adjacency.get(n.id)?.length ?? 0,
      dotOne: isDotOne(n),
      mtHint: isDotOne(n) && isMikrotikHint(n),
    }
    if (!best || better(cand, best)) best = cand
  }
  if (best && (best.rank <= 2 || best.degree > 0)) return best.id
  return null
}

/** Raggruppa i nodi per tier con etichetta dal tipo dominante. */
export function buildNetworkBlocks(
  nodes: TiersNode[],
  tierOf: Map<string, number>,
): Array<{ level: number; label: string; nodeIds: string[] }> {
  const byTier = new Map<number, string[]>()
  for (const n of nodes) {
    const t = tierOf.get(n.id) ?? -1
    const arr = byTier.get(t) ?? []
    arr.push(n.id)
    byTier.set(t, arr)
  }
  const blocks: Array<{ level: number; label: string; nodeIds: string[] }> = []
  for (const level of Array.from(byTier.keys()).sort((a, b) => a - b)) {
    const ids = byTier.get(level) ?? []
    const typeCount = new Map<string, number>()
    for (const id of ids) {
      const n = nodes.find((x) => x.id === id)
      const t = (n?.type || 'UNKNOWN').toUpperCase()
      typeCount.set(t, (typeCount.get(t) ?? 0) + 1)
    }
    let dominant = 'UNKNOWN'
    let max = -1
    for (const [t, c] of typeCount) {
      if (c > max) { max = c; dominant = t }
    }
    const label = TYPE_BLOCK_LABEL[dominant] ?? dominant
    blocks.push({ level, label: `${label} (${ids.length})`, nodeIds: ids })
  }
  return blocks
}
