/* ================================================================
 * FALCO-OS v16 — KMZ/KML Parser · porta fedele v15 (v7.4 → v11.32)
 * Parso KMZ (zip di KML) o KML puro ed estraggo placemark con
 * coordinate. La porta mantiene TUTTE le difese del v15:
 *   · zip-bomb: max 200 voci nell'archivio, max 20 MB decompressi
 *     (verificati sul central directory PRIMA di estrarre e di
 *     nuovo dopo, difesa in profondità);
 *   · namespace XML (Google Earth kml/2.2) con getElementsByTagNameNS;
 *   · description Google Earth CDATA ({ "@type":"html", value }) →
 *     non più «[object Object]»;
 *   · validazione coordinate (NaN, range, null-island 0,0).
 * Nessun logger (v16: gli errori tornano onesti alla rotta API).
 * Dipendenze: jszip, linkedom, @tmcw/togeojson (come v15).
 * ================================================================ */

import { kml } from '@tmcw/togeojson'
import JSZip from 'jszip'
import { DOMParser } from 'linkedom'

/* v11.32.0 (F-10) — protezione ZIP-BOMB: un KMZ caricato dagli utenti non
 * può gonfiare la memoria del server. Tetti:
 *   - MAX_KMZ_ENTRIES: voci totali nell'archivio;
 *   - MAX_KML_DECOMPRESSED_BYTES: dimensione DECOMPRESSA della voce KML. */
const MAX_KMZ_ENTRIES = 200
const MAX_KML_DECOMPRESSED_BYTES = 20 * 1024 * 1024 // 20 MB

/** Dimensione decompressa dichiarata dal central directory (se accessibile). */
function declaredUncompressedSize(entry: JSZip.JSZipObject | null | undefined): number | null {
  const data = (entry as unknown as { _data?: { uncompressedSize?: number } | null })?._data
  const n = data?.uncompressedSize
  return typeof n === 'number' && Number.isFinite(n) ? n : null
}

export interface ParsedPlacemark {
  name: string
  description: string // sempre stringa (anche se KML ha CDATA/HTML)
  lat: number
  lng: number
  extendedData: Record<string, string>
}

/** v16.13 (W11) — percorso polilinea KML: ogni placemark LineString
 * è un PERCORSO della rete reale disegnato dall'operatore (es.
 * «Linea 34»: P4 → P3 → Comune). I waypoint consecutivi sono le
 * coppie sede↔sede della topologia fisica. */
export interface KmlPolyline {
  name: string
  /** nome della cartella KML che contiene il placemark (es. «Punti GPS», «OLD») */
  folder: string
  /** waypoint [lat, lng] validati, in ordine di percorso */
  waypoints: Array<{ lat: number; lng: number }>
}

/**
 * v16.13 (W11) — unzip di un KMZ e lettura della stringa KML
 * (con tutte le difese zip-bomb). Condivisa da punti e polilinee.
 */
async function readKmlStringFromKmz(buffer: Buffer): Promise<string> {
  const zip = await JSZip.loadAsync(buffer)
  const kmlFiles: string[] = []
  let entryCount = 0

  zip.forEach((path, entry) => {
    entryCount += 1
    if (path.toLowerCase().endsWith('.kml') && !entry.dir) {
      kmlFiles.push(path)
    }
  })

  // v11.32.0 (F-10): zip-bomb — troppi file nell'archivio → rifiuto netto
  if (entryCount > MAX_KMZ_ENTRIES) {
    throw new Error(`KMZ rifiutato: ${entryCount} voci nell'archivio (massimo ${MAX_KMZ_ENTRIES})`)
  }

  if (kmlFiles.length === 0) {
    throw new Error('Nessun file .kml trovato nel KMZ')
  }

  // Prendo doc.kml o il primo disponibile
  const kmlPath = kmlFiles.find((p) => p.toLowerCase().includes('doc.kml')) || kmlFiles[0]
  const entry = zip.file(kmlPath)

  // v11.32.0 (F-10): zip-bomb — dimensione decompressa DICHIARATA prima di
  // estrarre (central directory), se JSZip la espone
  const declared = declaredUncompressedSize(entry)
  if (declared != null && declared > MAX_KML_DECOMPRESSED_BYTES) {
    throw new Error(`KMZ rifiutato: ${kmlPath} dichiara ${(declared / 1024 / 1024).toFixed(1)} MB decompressi (massimo ${MAX_KML_DECOMPRESSED_BYTES / 1024 / 1024} MB)`)
  }

  const kmlString = await entry?.async('string')
  if (!kmlString) throw new Error(`Impossibile leggere ${kmlPath}`)

  // difesa in profondità: il tetto vale anche se la dichiarazione manca/mente
  if (kmlString.length > MAX_KML_DECOMPRESSED_BYTES) {
    throw new Error(`KMZ rifiutato: ${kmlPath} decompresso oltre ${MAX_KML_DECOMPRESSED_BYTES / 1024 / 1024} MB`)
  }

  return kmlString
}

/**
 * Parse un buffer KMZ e ritorna l'array dei placemark con coordinate.
 */
export async function parseKMZ(buffer: Buffer): Promise<ParsedPlacemark[]> {
  const kmlString = await readKmlStringFromKmz(buffer)
  return parseKMLString(kmlString)
}

/**
 * v11.16 — file .kml puro (stesso percorso del KMZ, senza zip).
 */
export function parseKML(buffer: Buffer): ParsedPlacemark[] {
  const kmlString = buffer.toString('utf-8')
  if (!kmlString.trim()) throw new Error('File KML vuoto')
  return parseKMLString(kmlString)
}

/**
 * v11.16 — dispatcher per nome file: .kmz (zip di KML) o .kml.
 * Usato dall'import punti: l'operatore carica quello che ha.
 */
export async function parsePointsFile(buffer: Buffer, fileName: string): Promise<ParsedPlacemark[]> {
  const clean = fileName.toLowerCase().split('?')[0].split('#')[0].trim()
  if (clean.endsWith('.kmz')) return parseKMZ(buffer)
  if (clean.endsWith('.kml')) return parseKML(buffer)
  throw new Error('Formato non supportato: sono accettati solo file .kmz e .kml')
}

/**
 * v16.13 (W11) — estrae le POLILINEE (placemark LineString) con
 * attribuzione della cartella KML. Parsing DOM diretto (namespace-aware,
 * stesso stile dell'estrazione ExtendedData): togeojson appiattisce le
 * cartelle e qui servono (una «Linea» in «Punti GPS» è la rete ATTUALE,
 * in «OLD» è il percorso storico).
 */
export function parseKmlPolylines(kmlString: string): KmlPolyline[] {
  const parser = new DOMParser()
  const xmlDoc = parser.parseFromString(kmlString, 'text/xml') as unknown as XmlElement
  const parseError = xmlDoc.querySelector('parsererror')
  if (parseError) {
    throw new Error(`XML parse error: ${parseError.textContent}`)
  }

  const nsKml = 'http://www.opengis.net/kml/2.2'
  const foldersNs = xmlDoc.getElementsByTagNameNS(nsKml, 'Folder')
  const foldersNoNs = xmlDoc.getElementsByTagName('Folder')
  const folderElements = foldersNs.length > 0 ? foldersNs : foldersNoNs

  const polylines: KmlPolyline[] = []


  for (const folder of folderElements) {
    const nameEl = folder.getElementsByTagNameNS(nsKml, 'name')[0] || folder.getElementsByTagName('name')[0]
    const folderName = nameEl?.textContent?.trim() || ''

    const pmsNs = folder.getElementsByTagNameNS(nsKml, 'Placemark')
    const pmsNoNs = folder.getElementsByTagName('Placemark')
    const placemarkElements = pmsNs.length > 0 ? pmsNs : pmsNoNs

    for (const pm of placemarkElements) {
      // solo placemark DIRETTI della cartella (i nesting di sottocartelle
      // vengono visitati dalla loro cartella)
      if (pm.parentElement && folderElements.includes(pm.parentElement as never) && pm.parentElement !== folder) {
        continue
      }
      const pmNameEl = pm.getElementsByTagNameNS(nsKml, 'name')[0] || pm.getElementsByTagName('name')[0]
      const pmName = pmNameEl?.textContent?.trim() || ''
      if (!pmName) continue

      // coordinate: sotto LineString o Track (la geometria del percorso)
      const coordEl =
        pm.getElementsByTagNameNS(nsKml, 'LineString')[0]?.getElementsByTagNameNS(nsKml, 'coordinates')[0] ||
        pm.getElementsByTagName('LineString')?.[0]?.getElementsByTagName('coordinates')?.[0] ||
        pm.getElementsByTagNameNS(nsKml, 'coordinates')[0] ||
        pm.getElementsByTagName('coordinates')[0]
      const raw = coordEl?.textContent?.trim() || ''
      if (!raw) continue

      const waypoints: Array<{ lat: number; lng: number }> = []
      for (const token of raw.split(/\s+/)) {
        const parts = token.split(',')
        if (parts.length < 2) continue
        const lng = Number(parts[0])
        const lat = Number(parts[1])
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue
        if (lat < -90 || lat > 90 || lng < -180 || lng > 180) continue
        if (lat === 0 && lng === 0) continue
        waypoints.push({ lat, lng })
      }
      if (waypoints.length < 2) continue

      polylines.push({ name: pmName, folder: folderName, waypoints })
    }
  }

  return polylines
}

/**
 * v16.13 (W11) — punti + polilinee in un colpo solo (il file viene
 * aperto UNA volta: la apply KMZ usa entrambi).
 */
export async function parsePointsFileFull(
  buffer: Buffer,
  fileName: string,
): Promise<{ placemarks: ParsedPlacemark[]; polylines: KmlPolyline[] }> {
  const clean = fileName.toLowerCase().split('?')[0].split('#')[0].trim()
  let kmlString: string
  if (clean.endsWith('.kmz')) {
    kmlString = await readKmlStringFromKmz(buffer)
  } else if (clean.endsWith('.kml')) {
    kmlString = buffer.toString('utf-8')
    if (!kmlString.trim()) throw new Error('File KML vuoto')
  } else {
    throw new Error('Formato non supportato: sono accettati solo file .kmz e .kml')
  }
  return {
    placemarks: parseKMLString(kmlString),
    polylines: parseKmlPolylines(kmlString),
  }
}

/** tipi strutturali minimi per il DOM XML di linkedom (v10.9 Q4) */
interface XmlElement {
  textContent?: string | null
  parentElement?: XmlElement | null
  querySelector(sel: string): { textContent: string | null } | null
  getAttribute?(name: string): string | null
  getElementsByTagName(name: string): XmlElement[]
  getElementsByTagNameNS(ns: string, name: string): XmlElement[]
}

/**
 * v11.16 — cuore del parsing: parsa UNA stringa KML e valida ogni placemark.
 */
export function parseKMLString(kmlString: string): ParsedPlacemark[] {
  // CRITICAL (v7.4): 'application/xml' e NON parseHTML — KML è XML con
  // namespace, il parser HTML non li gestisce («Nessun placemark trovato»).
  let geojson: ReturnType<typeof kml> | undefined
  let xmlDoc: XmlElement
  try {
    const parser = new DOMParser()
    xmlDoc = parser.parseFromString(kmlString, 'text/xml') as unknown as XmlElement
    // Verifica errori di parsing XML
    const parseError = xmlDoc.querySelector('parsererror')
    if (parseError) {
      throw new Error(`XML parse error: ${parseError.textContent}`)
    }
    geojson = kml(xmlDoc as unknown as Document)
  } catch (e) {
    throw new Error(`Errore parsing KML: ${e}`)
  }

  /* CRITICAL 4 fix: ExtendedData da namespace KML che togeojson può mancare.
   * Google Earth usa xmlns="http://www.opengis.net/kml/2.2": i selettori CSS
   * non funzionano con i namespace, getElementsByTagNameNS sì. */
  const extendedDataByPlacemark = new Map<string, Record<string, string>>()
  try {
    const nsKml = 'http://www.opengis.net/kml/2.2'
    const placemarksNs = xmlDoc.getElementsByTagNameNS(nsKml, 'Placemark')
    const placemarksNoNs = xmlDoc.getElementsByTagName('Placemark')
    const placemarkElements = placemarksNs.length > 0 ? placemarksNs : placemarksNoNs

    for (const pm of placemarkElements) {
      const nameEl = pm.getElementsByTagNameNS(nsKml, 'name')[0] || pm.getElementsByTagName('name')[0]
      const pmName = nameEl?.textContent?.trim() || ''
      if (!pmName) continue

      // Estrai ExtendedData/Data elements
      const ed: Record<string, string> = {}
      const dataEls = pm.getElementsByTagNameNS(nsKml, 'Data')
      const dataElsNoNs = pm.getElementsByTagName('Data')
      const allData = dataEls.length > 0 ? dataEls : dataElsNoNs

      for (const dataEl of allData) {
        const key = dataEl.getAttribute?.('name') || ''
        const valueEl = dataEl.getElementsByTagNameNS(nsKml, 'value')[0]
          || dataEl.getElementsByTagName('value')[0]
        const value = valueEl?.textContent?.trim() || ''
        if (key && value) ed[key] = value
      }

      // Estrai SimpleData (SchemaData)
      const sdEls = pm.getElementsByTagNameNS(nsKml, 'SimpleData')
      const sdElsNoNs = pm.getElementsByTagName('SimpleData')
      const allSd = sdEls.length > 0 ? sdEls : sdElsNoNs

      for (const sdEl of allSd) {
        const key = sdEl.getAttribute?.('name') || ''
        const value = sdEl.textContent?.trim() || ''
        if (key && value) ed[key] = value
      }

      if (Object.keys(ed).length > 0) {
        extendedDataByPlacemark.set(pmName, ed)
      }
    }
  } catch {
    // Namespace extraction fallita — non critica, ExtendedData opzionale
  }

  if (!geojson?.features?.length) {
    throw new Error('Nessun placemark trovato nel KML')
  }

  const placemarks: ParsedPlacemark[] = []

  for (const feature of geojson.features) {
    // Geometry union: qui servono le coordinate puntuali del Point
    const coords = (feature.geometry as { coordinates?: number[] } | null)?.coordinates
    if (!coords || coords.length < 2) continue

    const lng = coords[0]
    const lat = coords[1]
    const name = String(feature.properties?.name || '')

    /* KML description: stringa, array, o — caso più comune, Google Earth
     * CDATA — OGGETTO { "@type": "html", "value": "..." } creato da
     * togeojson. v11.16 BUGFIX: String(rawDesc) produceva "[object
     * Object]"; ora estraiamo .value quando c'è. */
    const rawDesc = feature.properties?.description
    let description = ''
    if (typeof rawDesc === 'string') {
      description = rawDesc
    } else if (rawDesc != null && typeof rawDesc === 'object' && 'value' in (rawDesc as Record<string, unknown>)) {
      description = String((rawDesc as { value?: unknown }).value ?? '')
    } else if (rawDesc != null) {
      description = String(rawDesc)
    }

    // Estrai extended data dalle properties togeojson
    const extendedData: Record<string, string> = {}
    const props = feature.properties || {}
    for (const [key, value] of Object.entries(props)) {
      if (!['name', 'description', 'styleUrl', 'styleHash', 'stroke', 'stroke-opacity', 'stroke-width', 'fill', 'fill-opacity'].includes(key)) {
        extendedData[key] = String(value ?? '')
      }
    }

    // Merge ExtendedData dall'estrazione namespace-aware (CRITICAL 4)
    const nsEd = extendedDataByPlacemark.get(name)
    if (nsEd) {
      for (const [k, v] of Object.entries(nsEd)) {
        if (!extendedData[k]) extendedData[k] = v
      }
    }

    // Validazione coordinate: lat [-90,90], lng [-180,180] (check robusto)
    if (typeof lat !== 'number' || typeof lng !== 'number' || Number.isNaN(lat) || Number.isNaN(lng)) {
      continue
    }
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      continue
    }
    // Skip null island (0,0) — di solito coordinate mancanti
    if (lat === 0 && lng === 0) {
      continue
    }

    placemarks.push({ name, description, lat, lng, extendedData })
  }

  return placemarks
}
