/* ================================================================
 * FALCO-OS v16 — STATI DISPOSITIVO (port dal backend v15.16.0)
 * Provenienza: src/lib/monitoring-engine.ts:35,269-283 (repo v15.16.0)
 * Stati normalizzati del sistema: nessuno stato inventato qui.
 * «NOT_MONITORED» è DERIVATO (assenza di schedule di polling attiva),
 * non è una colonna del DB: vedi src/lib/v2/derive.ts
 * ================================================================ */

export type DeviceStatus = 'ONLINE' | 'OFFLINE' | 'DEGRADED' | 'MAINTENANCE' | 'UNKNOWN'

/** Stato derivato per la UI: ai 5 stati del DB si aggiunge NON_MONITORATO
 * (§7.1 del piano v16: assenza di schedule di polling ⇒ non monitorato,
 * distinto da UNKNOWN = monitorato ma dato assente/obsoleto). */
export type UiStatus = DeviceStatus | 'NOT_MONITORED'

/**
 * Determina lo stato DEGRADED — port IDENTICO di
 * monitoring-engine.ts:273 computeDegradedStatus (soglie di sistema):
 * raggiungibile MA segnale < −85 dBm, oppure CPU > 95%, oppure qualità
 * link < 50. Non si toccano le soglie senza evidenza (regola §7.6).
 */
export function computeDegradedStatus(metrics: {
  reachable: boolean
  signalStrength?: number
  cpuLoad?: number
  linkQuality?: number
}): DeviceStatus {
  if (!metrics.reachable) return 'OFFLINE'
  if (metrics.signalStrength !== undefined && metrics.signalStrength < -85) return 'DEGRADED'
  if (metrics.cpuLoad !== undefined && metrics.cpuLoad > 95) return 'DEGRADED'
  if (metrics.linkQuality !== undefined && metrics.linkQuality < 50) return 'DEGRADED'
  return 'ONLINE'
}

/** Soglia di obsolescenza del dato (§2.2 del piano v16): provvisoria,
 * da fissare dopo la baseline (decisione aperta 16.5). Regola: dato più
 * vecchio di max(2× intervallo di polling, 10 min) ⇒ UNKNOWN (mai OFFLINE). */
export function isStale(lastSeenAt: Date | null, pollingIntervalSec: number | null, now = new Date()): boolean {
  if (!lastSeenAt) return true
  const thresholdMs = Math.max((pollingIntervalSec ?? 30) * 2 * 1000, 10 * 60 * 1000)
  return now.getTime() - lastSeenAt.getTime() > thresholdMs
}

/** Motivo dello stato in linguaggio operativo (per badge e quick-look).
 * Deriva SOLO da dati presenti: motivo assente = «non specificato». */
export function statusReason(d: {
  status: string
  stale: boolean
  lastSeenAt: Date | null
  signalStrength: number
  linkQuality: number
  cpuLoad: number
  monitored: boolean
}): string | null {
  if (!d.monitored) return 'Nessuna schedule di polling attiva'
  if (d.status === 'UNKNOWN' || d.stale) {
    return d.lastSeenAt
      ? `Nessun dato dal ${d.lastSeenAt.toLocaleString('it-IT')} (dato obsoleto)`
      : 'Mai visto dal riavvio del monitoraggio (lastSeenAt assente)'
  }
  if (d.status === 'DEGRADED') {
    if (d.signalStrength !== 0 && d.signalStrength < -85) return `Segnale radio ${d.signalStrength} dBm (sotto −85)`
    if (d.cpuLoad > 95) return `CPU ${d.cpuLoad}% (sopra 95%)`
    if (d.linkQuality !== 0 && d.linkQuality < 50) return `Qualità link ${d.linkQuality}% (sotto 50%)`
    return 'Degradato (metrica fuori soglia)'
  }
  if (d.status === 'OFFLINE') return 'Irraggiungibile (ping fallito)'
  if (d.status === 'MAINTENANCE') return 'In finestra di manutenzione'
  return null
}
