/* ================================================================
 * FALCO-OS v16.13 — Collegamenti dai PERCORSI KMZ (W11)
 *
 * Le polilinee «Linea N» del KMZ dell'operatore sono i PERCORSI REALI
 * della rete: le coppie di waypoint consecutivi sono collegamenti
 * sede↔sede. Questa derivazione copre i «buchi» dell'Excel (SSID
 * solitari, ripetitori fuori inventario) con regole d'onesta a due
 * livelli: mai un secondo padre a chi ce l'ha già, mai il gateway
 * come stazione servita. Usata dalla correzione egidio e dall'apply
 * KMZ (dopo l'import Excel i dispositivi esistono e i buchi si
 * chiudono).
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import type { KmlPolyline } from './kmz-parser'

/**
 * Link dai percorsi KMZ: copre i «buchi» dell'Excel (SSID solitari o
 * sedi senza radio in inventario). REGOLA D'ONESTÀ (a due livelli):
 *   1. TARGET = radio STA ancora SENZA padre confermato (la sede che
 *      non ha uplink); SOURCE = hub (AP/PTP) dell'altra sede;
 *   2. altrimenti TARGET = AP ancora senza padre (un ripetitore da
 *      alimentare, es. Basestation @ RIP Stadio); SOURCE = radio
 *      dell'altra sede;
 *   3. altrimenti SKIP (entrambi già collegati: l'Excel/KMZ non
 *      aggiunge nulla — mai un secondo padre a chi ce l'ha già).
 */
export async function deriveKmzGapLinks(
  tx: Prisma.TransactionClient,
  plantId: string,
  polylines: KmlPolyline[],
): Promise<number> {
  const devices = await tx.device.findMany({
    where: { plantId },
    select: { id: true, ip: true, hostname: true, ssid: true, type: true, locationId: true },
  })
  // le sedi con GPS: i waypoint si abbinano per COORDINATE (i nomi
  // Excel e KMZ dello stesso punto differiscono: «RIP 1 Via Mazzini»
  // nell'Excel, «RIP1» nel KMZ — le coordinate no)
  const locRows = await tx.location.findMany({
    where: { plantId },
    select: { id: true, name: true, lat: true, lng: true },
  })
  const geoLocs = locRows.filter((l) => l.lat != null && l.lng != null)

  /** sede più vicina a un waypoint (tolleranza ~100 m in gradi) */
  const findNearest = (lat: number, lng: number) => {
    let best: { id: string; name: string; d: number } | null = null
    for (const l of geoLocs) {
      const d = Math.abs((l.lat ?? 0) - lat) + Math.abs((l.lng ?? 0) - lng)
      if (!best || d < best.d) best = { id: l.id, name: l.name, d }
    }
    return best && best.d < 0.001 ? best : null
  }
  const devicesByLoc = new Map<string, typeof devices>()
  for (const d of devices) {
    if (!d.locationId) continue
    const arr = devicesByLoc.get(d.locationId) ?? []
    arr.push(d)
    devicesByLoc.set(d.locationId, arr)
  }

  const existing = await tx.topologyLink.findMany({
    where: { plantId },
    select: { sourceDeviceId: true, targetDeviceId: true },
  })
  const devById = new Map(devices.map((d) => [d.id, d]))
  const parented = new Set<string>()
  const coveredLocPairs = new Set<string>()
  for (const l of existing) {
    if (l.targetDeviceId) parented.add(l.targetDeviceId)
    const s = l.sourceDeviceId ? devById.get(l.sourceDeviceId)?.locationId : null
    const t = l.targetDeviceId ? devById.get(l.targetDeviceId)?.locationId : null
    if (s && t) {
      coveredLocPairs.add(`${s}|${t}`)
      coveredLocPairs.add(`${t}|${s}`)
    }
  }

  /** radio di una sede: STA/AP con SSID, poi qualsiasi STA/AP, poi il primo */
  const radioOf = (locId: string) => {
    const devs = devicesByLoc.get(locId) ?? []
    return (
      devs.find((d) => d.ssid && (d.type === 'STA' || d.type === 'AP')) ??
      devs.find((d) => d.type === 'STA' || d.type === 'AP') ??
      devs[0] ??
      null
    )
  }
  /** AP/PTP di una sede (l'«hub» quando serve un upstream) */
  const hubOf = (locId: string) => {
    const devs = devicesByLoc.get(locId) ?? []
    return devs.find((d) => d.type === 'AP') ?? devs.find((d) => /^ptp/i.test(d.hostname)) ?? null
  }
  /** STA senza padre di una sede (la sede che cerca l'uplink) */
  const unparentedStaOf = (locId: string) => {
    const devs = devicesByLoc.get(locId) ?? []
    return devs.find((d) => d.type === 'STA' && !parented.has(d.id)) ?? null
  }
  /** AP senza padre di una sede (ripetitore da alimentare) */
  const unparentedApOf = (locId: string) => {
    const devs = devicesByLoc.get(locId) ?? []
    return devs.find((d) => d.type === 'AP' && !parented.has(d.id)) ?? null
  }

  let created = 0

  for (const line of polylines) {
    const stops = line.waypoints.map((w) => findNearest(w.lat, w.lng))
    for (let i = 0; i < stops.length - 1; i++) {
      const a = stops[i]
      const b = stops[i + 1]
      if (!a || !b || a.id === b.id) continue
      const idA = a.id
      const idB = b.id
      if (coveredLocPairs.has(`${idA}|${idB}`)) {
        console.log(`  [KMZ ${line.name}] ${a.name} ↔ ${b.name}: SKIP (sedi già collegate)`)
        continue
      }

      let source: (typeof devices)[number] | null = null
      let target: (typeof devices)[number] | null = null
      let basis = ''

      // regola 1: STA senza padre da una parte, hub dall'altra
      const staA = unparentedStaOf(idA)
      const staB = unparentedStaOf(idB)
      if (staA && !staB) {
        target = staA
        source = hubOf(idB) ?? radioOf(idB)
        basis = `${staA.hostname} senza uplink → hub ${source?.hostname ?? '?'} di ${b.name}`
      } else if (staB && !staA) {
        target = staB
        source = hubOf(idA) ?? radioOf(idA)
        basis = `${staB.hostname} senza uplink → hub ${source?.hostname ?? '?'} di ${a.name}`
      } else if (!staA && !staB) {
        // regola 2: AP senza padre (ripetitore) da una parte
        const apA = unparentedApOf(idA)
        const apB = unparentedApOf(idB)
        if (apA && !apB) {
          target = apA
          source = radioOf(idB)
          basis = `ripetitore ${apA.hostname} da alimentare ← ${source?.hostname ?? '?'} di ${b.name}`
        } else if (apB && !apA) {
          target = apB
          source = radioOf(idA)
          basis = `ripetitore ${apB.hostname} da alimentare ← ${source?.hostname ?? '?'} di ${a.name}`
        }
      }

      if (!source || !target || source.id === target.id) {
        console.log(`  [KMZ ${line.name}] ${a.name} ↔ ${b.name}: SKIP (nessun buco da colmare: ${staA || staB ? 'STA con padre già noto' : 'nessun radio libero'})`)
        continue
      }
      if (source.type === 'GATEWAY' && target.type !== 'UNKNOWN') {
        // il gateway di testa non «serve» stazioni periferiche direttamente
        console.log(`  [KMZ ${line.name}] ${a.name} ↔ ${b.name}: SKIP (il gateway ${source.hostname} non è un hub radio di questa tratta)`)
        continue
      }

      await tx.topologyLink.create({
        data: {
          plantId,
          sourceDeviceId: source.id,
          targetDeviceId: target.id,
          sourceLabel: source.hostname,
          targetLabel: target.hostname,
          linkType: 'RADIO',
          label: line.name,
          frequency: /60/.test(line.name) ? '60 GHz' : '',
          notes: `Percorso KMZ «${line.name}» (cartella ${line.folder}) — sedi ${a.name} ↔ ${b.name}: ${basis}`,
          sourceOfTruth: 'TECHNICIAN',
          confirmed: true,
          linkStatus: 'CONFIRMED',
        },
      })
      parented.add(target.id)
      coveredLocPairs.add(`${idA}|${idB}`)
      coveredLocPairs.add(`${idB}|${idA}`)
      created += 1
      console.log(`  [KMZ ${line.name}] ${a.name} ↔ ${b.name}: ${source.hostname} → ${target.hostname}`)
    }
  }

  /* ---- FIBRA Comando → Via Califano: chiude l'albero dalla radice ---- */
  const routerSeti = devices.find((d) => d.ip === '172.19.150.1')
  const ptpFibra = devices.find((d) => d.ip === '172.19.150.20')
  if (routerSeti && ptpFibra) {
    const routerLoc = routerSeti.locationId
    const fibraLoc = ptpFibra.locationId
    if (
      routerLoc &&
      fibraLoc &&
      routerLoc !== fibraLoc &&
      !coveredLocPairs.has(`${routerLoc}|${fibraLoc}`) &&
      !parented.has(ptpFibra.id)
    ) {
      await tx.topologyLink.create({
        data: {
          plantId,
          sourceDeviceId: routerSeti.id,
          targetDeviceId: ptpFibra.id,
          sourceLabel: routerSeti.hostname,
          targetLabel: ptpFibra.hostname,
          linkType: 'FIBRA',
          label: 'Fibra Comando',
          notes: 'Sezione Excel «OLD Via Califano (Fibra) Fuori Comando»: fibra dal Comando PL al POP di Via Califano',
          sourceOfTruth: 'TECHNICIAN',
          confirmed: true,
          linkStatus: 'CONFIRMED',
        },
      })
      created += 1
      console.log(`  [FIBRA] ${routerSeti.hostname} → ${ptpFibra.hostname}`)
    }
  }

  return created
}