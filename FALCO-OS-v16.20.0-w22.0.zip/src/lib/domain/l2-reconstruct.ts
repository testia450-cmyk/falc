/* ================================================================
 * FALCO-OS v16.8 — RICOSTRUZIONE LAYER-2 (rete in bridge)
 * src/lib/domain/l2-reconstruct.ts
 * ================================================================
 * «Come si ricostruisce la rete GIUSTA quando tutto passa da uno
 * switch in bridge?» — combinando le TRE dichiarazioni che uno switch
 * fa davvero via SNMP, in ordine di affidabilità:
 *
 *   1. LLDP-MIB  — il vicino DICHIARA se stesso per porta (sysName,
 *                  chassisId MAC, porta remota): link HIGH «LLDP»;
 *   2. CDP cache — l'equivalente Cisco (deviceId, devicePort):
 *                  link HIGH «CDP»;
 *   3. FDB       — la tabella MAC APPRESA (dot1dTp/dot1qTp): il MAC
 *                  di un dispositivo noto che compare su UNA porta
 *                  dice dove è collegato: link MEDIUM «FDB_ENDPOINT»;
 *                  più dispositivi noti sulla STESSA porta = segmento
 *                  condiviso (bridge/daisy-chain): link LOW
 *                  «DAISY_CHAIN» — l'onestà di non fingere un cavo
 *                  dedicato dove c'è un segmento.
 *
 * REGOLE D'ORO (coerenti col resto del repo):
 *   · NESSUN dato inventato: un vicino non presente nell'inventario
 *     è riportato come «non abbinato», mai creato come dispositivo;
 *   · i link dell'OPERATORE (TECHNICIAN/confirmed) restano intoccabili:
 *     la ricostruzione aggiorna SOLO i link che ha creato lei stessa
 *     (LLDP/CDP/FDB/DAISY_CHAIN) — verità > inferenza, sempre;
 *   · le osservazioni FDB tornano TUTTE (alimentano l'inventario MAC),
 *     i link solo per dispositivi dell'impianto.
 * ================================================================ */

/* ---------------- Tipi (payload dal mini-service :3002) ---------------- */

export interface L2ProbeLldpNeighbor {
  localPortNum: number
  chassisId: string | null
  chassisIdSubtype: number | null
  sysName: string | null
  sysDesc: string | null
  portId: string | null
  portIdSubtype: number | null
  portDesc: string | null
}

export interface L2ProbeCdpNeighbor {
  ifIndex: number
  deviceId: string | null
  devicePort: string | null
  version: string | null
  platform: string | null
}

export interface L2ProbeInterface {
  ifIndex: number
  descr: string | null
  name: string | null
  ifType: number | null
  adminStatus: number | null
  operStatus: number | null
  speedMbps: number | null
}

/** v16.15 W13 — riga ARP (ipNetToMedia / ipNetToPhysical). */
export interface L2ProbeArpRow {
  ip: string
  mac: string
  ifIndex: number
  type: string
}

/** v16.15 W13 — porta STP (BRIDGE-MIB dot1dStpPortTable). */
export interface L2ProbeStpPort {
  port: number
  state: string
  enable: number | null
  pathCost: number
  designatedBridgeId: string
  designatedBridgeMac: string
  designatedPortNum: number
  designatedRootId: string
}

/** v16.15 W13 — dichiarazione STP dell'apparato sondato. */
export interface L2ProbeStp {
  present: boolean
  protocol: string
  bridgeMac: string
  rootBridgeId: string
  rootBridgeMac: string
  rootPort: number
  ports: L2ProbeStpPort[]
  warnings?: string[]
}

/** v16.15 W13 — VLAN statica dichiarata (Q-BRIDGE). */
export interface L2ProbeVlan {
  vlanId: number
  name: string
  egressPorts: number[]
}

/** v16.15 W13 — PVID per porta bridge. */
export interface L2ProbePortVlan {
  port: number
  pvid: number
}

export interface L2ProbePayload {
  reachable: boolean
  matched?: { community: string; version: string } | null
  sysName?: string | null
  sysDescr?: string | null
  lldp?: L2ProbeLldpNeighbor[]
  cdp?: L2ProbeCdpNeighbor[]
  bridgePorts?: Array<{ port: number; ifIndex: number }>
  fdb?: Array<{ mac: string; port: number }>
  vlanFdb?: Array<{ vlan: number; mac: string; port: number }>
  interfaces?: L2ProbeInterface[]
  /** v16.15 W13 — campi aggiuntivi (assenti = sonda pre-v16.15: onesto). */
  arp?: L2ProbeArpRow[]
  stp?: L2ProbeStp | null
  vlans?: L2ProbeVlan[]
  portVlans?: L2ProbePortVlan[]
  warnings?: string[]
}

/** Dispositivo dell'inventario del plant (solo i campi necessari). */
export interface InventoryDevice {
  id: string
  ip: string
  hostname: string
  macAddress: string
  type: string
}

/* ---------------- Risultato della ricostruzione ---------------- */

export type L2LinkSource = 'LLDP' | 'CDP' | 'FDB' | 'DAISY_CHAIN'

export interface ReconstructedLink {
  /** Dispositivo A MONTE dello switch-side del link (lo switch sondato). */
  switchDeviceId: string
  /** Dispositivo dietro la porta (vicino LLDP/CDP o MAC FDB). */
  targetDeviceId: string
  targetHostname: string
  targetIp: string
  /** Porta dello switch (nome REALE ifName/ifDescr, o «port N»). */
  sourcePort: string
  /** Numero porta bridge (dot1d) della porta sorgente (0 = ignoto). */
  sourcePortNum: number
  /** Porta dichiarata dal vicino (LLDP portDesc/portId, CDP devicePort). */
  targetPort: string
  sourceOfTruth: L2LinkSource
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  evidence: string
  /** Velocità della porta dello switch da IF-MIB (0 = sconosciuta). */
  speedMbps: number
  /** TRUE se l'STP conferma il link: il bridge designato della porta
   *  coincide col MAC del dispositivo collegato (v16.15 W13). */
  stpCorroborated: boolean
  /** Etichetta leggibile per il report. */
  detail: string
}

export interface ReconstructedObservation {
  portName: string
  mac: string
  /** VLAN della riga FDB (0 = FDB classica senza VLAN — v16.15). */
  vlan: number
}

/** MAC visto in FDB/ARP ma NON in inventario, con IP risolto dall'ARP
 *  (v16.15 W13): il ponte onesto verso l'adozione — mai auto-adottato. */
export interface UnmatchedMacWithIp {
  mac: string
  ip: string
  portName: string
}

export interface L2Reconstruction {
  links: ReconstructedLink[]
  observations: ReconstructedObservation[]
  /** Vicini dichiarati (LLDP/CDP) MA assenti dall'inventario: onesti. */
  unmatchedNeighbors: Array<{ via: 'LLDP' | 'CDP'; name: string; port: string | null }>
  /** Porte con più dispositivi noti: segmenti bridge/daisy-chain. */
  sharedPorts: Array<{ port: string; devices: string[] }>
  /** v16.15 W13 — MAC non inventariati con IP risolto dall'ARP. */
  unmatchedMacsWithIp: UnmatchedMacWithIp[]
  /** v16.15 W13 — riassunto STP dell'apparato (null = STP assente). */
  stp: {
    present: boolean
    protocol: string
    bridgeMac: string
    rootBridgeMac: string
    rootPort: number
    /** Numero di link corroborati dall'STP in QUESTA ricostruzione. */
    corroboratedLinks: number
  } | null
  /** v16.15 W13 — VLAN dichiarate dall'apparato (per il report). */
  vlans: Array<{ vlanId: number; name: string; ports: string }>
  /** v16.15 W13 — voci ARP utili (per il report e la persistenza ArpEntry). */
  arp: L2ProbeArpRow[]
  stats: {
    lldpNeighbors: number
    cdpNeighbors: number
    fdbEntries: number
    vlanFdbEntries: number
    arpEntries: number
    stpPorts: number
    vlans: number
    matchedLinks: number
    observations: number
    unmatchedNeighbors: number
    sharedPorts: number
    unmatchedMacsWithIp: number
  }
  warnings: string[]
}

/* ---------------- Utility ---------------- */

/** Normalizza un MAC in AA:BB:CC:DD:EE:FF ('' se non valido). */
export function normalizeMac(raw: string): string {
  const hex = (raw || '').toLowerCase().replace(/[^0-9a-f]/g, '')
  if (hex.length !== 12) return ''
  return hex.match(/.{2}/g)?.join(':').toUpperCase() ?? ''
}

/** Nome host «utilizzabile» per il confronto (case, spazi, .local). */
function comparableName(raw: string): string {
  return raw.trim().toLowerCase().replace(/\.local\.?$/, '')
}

/* ---------------- Ricostruzione ---------------- */

/**
 * Combina LLDP + CDP + FDB + STP + ARP di UNA sonda L2 con l'inventario
 * del plant: produce link inferiti, osservazioni MAC e avvisi onesti.
 * PURE function (nessun DB): la rotta la esegue e decide cosa persistere.
 *
 * v16.15 W13 — due nuove dichiarazioni entrano nel gioco:
 *   · STP: se il bridge DESIGNATO della porta coincide col MAC del
 *     dispositivo collegato, il link è CORROBORATO (l'albero spanning
 *     conferma il cavo); se designa un ALTRO dispositivo noto su una
 *     porta diversa, l'avviso segnala la discordanza (mai correzione
 *     silenziosa: verità > inferenza);
 *   · ARP: i MAC visti in FDB ma NON in inventario vengono risolti in
 *     IP — la lista «unmatchedMacsWithIp» è il ponte onesto verso
 *     l'adozione (nessuna auto-adozione, mai).
 */
export function l2Reconstruct(
  probe: L2ProbePayload,
  inventory: InventoryDevice[],
  switchDevice: InventoryDevice,
): L2Reconstruction {
  const links: ReconstructedLink[] = []
  const warnings: string[] = [...(probe.warnings ?? [])]

  const lldp = probe.lldp ?? []
  const cdp = probe.cdp ?? []
  const fdb = probe.fdb ?? []
  const vlanFdb = probe.vlanFdb ?? []
  const interfaces = probe.interfaces ?? []
  const bridgePorts = probe.bridgePorts ?? []
  const arp = probe.arp ?? []
  const stp = probe.stp ?? null
  const vlans = probe.vlans ?? []

  /* ---- risolutori porta: bridgePort → ifIndex → nome reale ---- */
  const portByIfIndex = new Map<number, L2ProbeInterface>()
  for (const itf of interfaces) portByIfIndex.set(itf.ifIndex, itf)
  const ifIndexByPort = new Map<number, number>()
  for (const bp of bridgePorts) ifIndexByPort.set(bp.port, bp.ifIndex)

  const nameOfInterface = (itf: L2ProbeInterface | undefined): string =>
    itf?.name ?? itf?.descr ?? ''
  const speedOfInterface = (itf: L2ProbeInterface | undefined): number =>
    itf?.speedMbps ?? 0

  /** Nome leggibile della porta bridge N (ifName > ifDescr > «port N»). */
  const portName = (port: number): string => {
    const ifIndex = ifIndexByPort.get(port)
    const itf = ifIndex !== undefined ? portByIfIndex.get(ifIndex) : undefined
    const name = nameOfInterface(itf)
    if (name) return name
    // senza mappatura bridge→ifIndex: cerca un'interfaccia SNMP classica
    // con ifIndex == porta (convenzione di molti switch piccoli)
    const direct = portByIfIndex.get(port)
    const directName = direct ? nameOfInterface(direct) : ''
    return directName || `port ${port}`
  }

  const portSpeed = (port: number): number => {
    const ifIndex = ifIndexByPort.get(port)
    const itf = ifIndex !== undefined ? portByIfIndex.get(ifIndex) : undefined
    return itf ? speedOfInterface(itf) : (portByIfIndex.get(port)?.speedMbps ?? 0)
  }

  /** Porta LLDP locale: lldpRemLocalPortNum segue la numerazione bridge
   *  su molti switch (MikroTik); sui Cisco coincide con ifIndex — si
   *  prova la mappatura bridge e in fallback la ifIndex diretta. */
  const lldpPortName = (localPortNum: number): string => {
    const viaBridge = ifIndexByPort.get(localPortNum)
    if (viaBridge !== undefined) {
      const name = nameOfInterface(portByIfIndex.get(viaBridge))
      if (name) return name
    }
    const direct = nameOfInterface(portByIfIndex.get(localPortNum))
    return direct || `port ${localPortNum}`
  }
  const lldpPortSpeed = (localPortNum: number): number => {
    const viaBridge = ifIndexByPort.get(localPortNum)
    if (viaBridge !== undefined) {
      const s = speedOfInterface(portByIfIndex.get(viaBridge))
      if (s > 0) return s
    }
    return portByIfIndex.get(localPortNum)?.speedMbps ?? 0
  }

  const cdpPortName = (ifIndex: number): string => {
    const name = nameOfInterface(portByIfIndex.get(ifIndex))
    return name || `if${ifIndex}`
  }
  const cdpPortSpeed = (ifIndex: number): number =>
    speedOfInterface(portByIfIndex.get(ifIndex))

  /** IfIndex → numero porta bridge (inverso di dot1dBasePortIfIndex):
 *  serve per correlare le porte CDP (ifIndex) con l'STP (porta bridge). */
  const portByIfIndexNum = new Map<number, number>()
  for (const bp of bridgePorts) portByIfIndexNum.set(bp.ifIndex, bp.port)
  const bridgePortOfIfIndex = (ifIndex: number): number =>
    portByIfIndexNum.get(ifIndex) ?? 0

  /* ---- indice inventario: per hostname e per MAC ---- */
  const byName = new Map<string, InventoryDevice>()
  for (const d of inventory) {
    const key = comparableName(d.hostname)
    if (key) byName.set(key, d)
  }
  const byMac = new Map<string, InventoryDevice>()
  for (const d of inventory) {
    const mac = normalizeMac(d.macAddress)
    if (mac) byMac.set(mac, d)
  }

  /** Trova il dispositivo inventariato corrispondente a un vicino. */
  const findDevice = (name: string | null, mac: string | null): InventoryDevice | null => {
    if (name) {
      const hit = byName.get(comparableName(name))
      if (hit) return hit
    }
    if (mac) {
      const hit = byMac.get(normalizeMac(mac))
      if (hit) return hit
    }
    return null
  }

  const unmatchedNeighbors: L2Reconstruction['unmatchedNeighbors'] = []
  /** DeviceId già collegati con link DIRETTI (LLDP/CDP) in QUESTA
   *  ricostruzione: la FDB non deve duplicare ciò che il vicino ha
   *  già dichiarato di persona. */
  const directlyLinked = new Set<string>()
  const pushLink = (l: ReconstructedLink) => links.push(l)

  /* ---- (1) LLDP: dichiarazione esplicita del vicino ---- */
  for (const nb of lldp) {
    const device = findDevice(nb.sysName, nb.chassisId && nb.chassisIdSubtype === 3 ? nb.chassisId : null)
    if (!device) {
      unmatchedNeighbors.push({
        via: 'LLDP',
        name: nb.sysName ?? nb.chassisId ?? '(senza nome)',
        port: nb.portDesc ?? nb.portId ?? null,
      })
      continue
    }
    if (device.id === switchDevice.id) continue // autodichiarazione
    directlyLinked.add(device.id)
    pushLink({
      switchDeviceId: switchDevice.id,
      targetDeviceId: device.id,
      targetHostname: device.hostname,
      targetIp: device.ip,
      sourcePort: lldpPortName(nb.localPortNum),
      sourcePortNum: nb.localPortNum,
      targetPort: nb.portDesc ?? nb.portId ?? '',
      sourceOfTruth: 'LLDP',
      confidence: 'HIGH',
      evidence: 'LLDP',
      speedMbps: lldpPortSpeed(nb.localPortNum),
      stpCorroborated: false,
      detail: `LLDP: ${nb.sysName ?? device.hostname} su ${lldpPortName(nb.localPortNum)}${nb.portDesc ? ` (porta remota ${nb.portDesc})` : ''}`,
    })
  }

  /* ---- (2) CDP: dichiarazione esplicita del vicino Cisco ---- */
  for (const nb of cdp) {
    // deviceId: hostname, seriale o MAC a seconda del vendor
    const device = findDevice(nb.deviceId, /^[0-9a-f:]{12,17}$/i.test(nb.deviceId ?? '') ? nb.deviceId : null)
    if (!device) {
      unmatchedNeighbors.push({
        via: 'CDP',
        name: nb.deviceId ?? '(senza nome)',
        port: nb.devicePort ?? null,
      })
      continue
    }
    if (device.id === switchDevice.id) continue
    directlyLinked.add(device.id)
    pushLink({
      switchDeviceId: switchDevice.id,
      targetDeviceId: device.id,
      targetHostname: device.hostname,
      targetIp: device.ip,
      sourcePort: cdpPortName(nb.ifIndex),
      sourcePortNum: bridgePortOfIfIndex(nb.ifIndex),
      targetPort: nb.devicePort ?? '',
      sourceOfTruth: 'CDP',
      confidence: 'HIGH',
      evidence: 'CDP',
      speedMbps: cdpPortSpeed(nb.ifIndex),
      stpCorroborated: false,
      detail: `CDP: ${nb.deviceId ?? device.hostname} su ${cdpPortName(nb.ifIndex)}${nb.devicePort ? ` (porta remota ${nb.devicePort})` : ''}`,
    })
  }

  /* ---- (3) FDB: MAC appresi → dove sono collegati i dispositivi noti ---- */
  const observations: ReconstructedObservation[] = []
  const macToPort = new Map<string, number>()
  const ambiguousMacs = new Set<string>()
  for (const row of fdb) {
    const mac = normalizeMac(row.mac)
    if (!mac) continue
    observations.push({ portName: portName(row.port), mac, vlan: 0 })
    const prev = macToPort.get(mac)
    if (prev !== undefined && prev !== row.port) {
      ambiguousMacs.add(mac) // flapping/ Spanning Tree: non decidiamo per lui
    } else {
      macToPort.set(mac, row.port)
    }
  }
  // FDB VLAN-aware come integrazione (solo MAC non già in quella classica)
  let vlanOnly = 0
  for (const row of vlanFdb) {
    const mac = normalizeMac(row.mac)
    if (!mac || macToPort.has(mac)) continue
    macToPort.set(mac, row.port)
    observations.push({ portName: portName(row.port), mac, vlan: row.vlan })
    vlanOnly += 1
  }

  // dispositivi noti per porta (escluso lo switch e i già collegati)
  const devicesByPort = new Map<number, InventoryDevice[]>()
  for (const d of inventory) {
    if (d.id === switchDevice.id) continue
    const mac = normalizeMac(d.macAddress)
    if (!mac) continue
    const port = macToPort.get(mac)
    if (port === undefined) continue
    if (directlyLinked.has(d.id)) continue // già dichiarato dal vicino
    if (ambiguousMacs.has(mac)) {
      warnings.push(`MAC ${mac} (${d.hostname}) appreso su più porte: link FDB NON creato (ambiguo)`)
      continue
    }
    const arr = devicesByPort.get(port) ?? []
    arr.push(d)
    devicesByPort.set(port, arr)
  }

  const sharedPorts: L2Reconstruction['sharedPorts'] = []
  for (const [port, devices] of devicesByPort) {
    const name = portName(port)
    if (devices.length === 1) {
      // UN dispositivo noto su questa porta: collegamento diretto (MEDIO)
      const d = devices[0]
      pushLink({
        switchDeviceId: switchDevice.id,
        targetDeviceId: d.id,
        targetHostname: d.hostname,
        targetIp: d.ip,
        sourcePort: name,
        sourcePortNum: port,
        targetPort: '',
        sourceOfTruth: 'FDB',
        confidence: 'MEDIUM',
        evidence: 'FDB_ENDPOINT',
        speedMbps: portSpeed(port),
        stpCorroborated: false,
        detail: `FDB: ${d.hostname} (${normalizeMac(d.macAddress)}) appreso su ${name}`,
      })
    } else {
      // PIÙ dispositivi noti sulla STESSA porta: segmento in bridge
      sharedPorts.push({ port: name, devices: devices.map((d) => d.hostname) })
      for (const d of devices) {
        pushLink({
          switchDeviceId: switchDevice.id,
          targetDeviceId: d.id,
          targetHostname: d.hostname,
          targetIp: d.ip,
          sourcePort: name,
          sourcePortNum: port,
          targetPort: '',
          sourceOfTruth: 'DAISY_CHAIN',
          confidence: 'LOW',
          evidence: 'DAISY_CHAIN',
          speedMbps: portSpeed(port),
          stpCorroborated: false,
          detail: `Segmento condiviso ${name}: ${d.hostname} tra ${devices.length} dispositivi sulla stessa porta (bridge/daisy-chain)`,
        })
      }
    }
  }
  if (vlanOnly > 0) {
    warnings.push(`${vlanOnly} MAC noti solo via Q-BRIDGE (VLAN-aware)`)
  }

  /* ---- (4) v16.15 W13 — STP: corrobora (o smentisce) i link creati ---- */
  let corroboratedLinks = 0
  if (stp?.present) {
    // MAC inventario per target (per confrontare col designated bridge)
    const macOfDevice = new Map<string, string>()
    for (const d of inventory) {
      const mac = normalizeMac(d.macAddress)
      if (mac) macOfDevice.set(d.id, mac)
    }
    for (const link of links) {
      if (link.sourcePortNum <= 0) continue
      const stpPort = stp.ports.find((p) => p.port === link.sourcePortNum)
      if (!stpPort || !stpPort.designatedBridgeMac) continue
      const targetMac = macOfDevice.get(link.targetDeviceId) ?? ''
      if (targetMac && stpPort.designatedBridgeMac === targetMac) {
        link.stpCorroborated = true
        link.detail += ' · STP conferma (bridge designato)'
        corroboratedLinks += 1
      } else if (targetMac && stpPort.designatedBridgeMac && stpPort.designatedBridgeMac !== normalizeMac(switchDevice.macAddress)) {
        // il designato non è il target e non siamo noi: discordanza onesta
        warnings.push(`STP designa ${stpPort.designatedBridgeMac} sulla porta ${link.sourcePort} ma il link porta a ${link.targetHostname}: da verificare`)
      }
    }
    if (stp.rootPort > 0) {
      const rootPortName = portName(stp.rootPort)
      warnings.push(`root STP raggiunta via porta ${rootPortName} (root bridge ${stp.rootBridgeMac})`)
    } else if (stp.ports.length > 0) {
      warnings.push(`questo apparato È la root bridge STP (${stp.bridgeMac})`)
    }
  }

  /* ---- (5) v16.15 W13 — ARP: IP per i MAC NON in inventario ---- */
  const unmatchedMacsWithIp: UnmatchedMacWithIp[] = []
  if (arp.length > 0) {
    const seen = new Set<string>()
    for (const row of arp) {
      const mac = normalizeMac(row.mac)
      if (!mac || seen.has(mac)) continue
      if (byMac.has(mac)) continue // già in inventario: niente da segnalare
      seen.add(mac)
      const port = macToPort.get(mac)
      unmatchedMacsWithIp.push({
        mac,
        ip: row.ip,
        portName: port !== undefined ? portName(port) : '',
      })
    }
  }

  /* ---- VLAN dichiarate, per il report ---- */
  const vlanReport = vlans.slice(0, 32).map((v) => ({
    vlanId: v.vlanId,
    name: v.name,
    ports: v.egressPorts.map((p) => portName(p)).filter((n) => n !== '').join(', '),
  }))

  return {
    links,
    observations,
    unmatchedNeighbors,
    sharedPorts,
    unmatchedMacsWithIp,
    stp: stp?.present
      ? {
          present: true,
          protocol: stp.protocol,
          bridgeMac: stp.bridgeMac,
          rootBridgeMac: stp.rootBridgeMac,
          rootPort: stp.rootPort,
          corroboratedLinks,
        }
      : null,
    vlans: vlanReport,
    arp: arp.slice(0, 256),
    stats: {
      lldpNeighbors: lldp.length,
      cdpNeighbors: cdp.length,
      fdbEntries: fdb.length,
      vlanFdbEntries: vlanFdb.length,
      arpEntries: arp.length,
      stpPorts: stp?.ports.length ?? 0,
      vlans: vlans.length,
      matchedLinks: links.length,
      observations: observations.length,
      unmatchedNeighbors: unmatchedNeighbors.length,
      sharedPorts: sharedPorts.length,
      unmatchedMacsWithIp: unmatchedMacsWithIp.length,
    },
    warnings,
  }
}
