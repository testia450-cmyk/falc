/* ================================================================
 * FALCO-OS v16.13 — Apply import XLSX «formato SETI» (W11)
 *
 * Esegue il piano CONFERMATO dall'operatore dentro UNA transazione.
 * È la stessa logica per la rotta API (/api/v2/import/xlsx/apply)
 * e per gli script di correzione: una sola verità.
 *
 * ONESTÀ (ereditata dall'import KMZ):
 *   · il piano arriva RI-DERIVATO lato server dal file ri-parsato;
 *   · le conferme sono INDICI + id riverificati, mai payload liberi;
 *   · password CIFRATE con encryptSecret (AES-256-GCM) — se la chiave
 *     manca l'import rifiuta invece di scrivere segreti in chiaro;
 *   · hostname: l'Excel dell'installazione è la volontà dell'operatore
 *     → sovrascrive (e resetta hostnameManuallySet, resta gestito qui);
 *   · purgeAutoLinks: elimina i collegamenti AUTO-SCOPERTI (LLDP/MNDP/
 *     UISP/FDB/BRIDGE_MIB/…, NON quelli TECHNICIAN confermati) quando
 *     l'operatore sceglie la topologia reale dell'Excel.
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import { encryptSecret } from '@/lib/crypto'
import { deriveIdentifier } from './point-import-plan'
import type { XlsxImportPlan } from './xlsx-import-plan'
import type { XlsxSection, XlsxWorkbookSummary } from './xlsx-parser'

/** Famiglie di sorgenti AUTO-SCOPERTI (non confermate dall'operatore). */
export const AUTO_DISCOVERED_SOURCES = [
  'LLDP',
  'MNDP',
  'UISP',
  'FDB',
  'BRIDGE_MIB',
  'DAISY_CHAIN',
  'INFERRED',
] as const

export interface XlsxApplySectionConfirm {
  sectionIndex: number
  /** sede esistente scelta/confermata; assente = crea la sede della sezione */
  locationId?: string | null
}

export interface XlsxApplySyntheticConfirm {
  /** indice nel piano synthetic */
  index: number
  locationId?: string | null
}

export interface XlsxApplyOptions {
  plantId: string
  /** SOLO le sezioni incluse dall'operatore */
  sections: XlsxApplySectionConfirm[]
  createLinks: boolean
  /** raggruppa gli apparati della sede sotto il radio di sede (LAN):
   *  telecamere/NVR/SW entrano nell'albero, non «fuori albero» */
  createLanLinks: boolean
  /** basestation sintetiche confermate */
  synthetic: XlsxApplySyntheticConfirm[]
  purgeAutoLinks: boolean
  /** email per l'audit */
  actor: string
}

export interface XlsxApplyCounts {
  locationsCreated: number
  devicesCreated: number
  devicesUpdated: number
  linksCreated: number
  syntheticCreated: number
  autoLinksPurged: number
}

/**
 * Applica il piano confermato. IL PIANO deve essere quello derivato
 * dal file (ri-parsato) — qui non si ritorna mai ai dati del client.
 */
export async function applyXlsxImport(
  summary: XlsxWorkbookSummary,
  plan: XlsxImportPlan,
  options: XlsxApplyOptions,
  tx: Prisma.TransactionClient,
): Promise<XlsxApplyCounts> {
  const counts: XlsxApplyCounts = {
    locationsCreated: 0,
    devicesCreated: 0,
    devicesUpdated: 0,
    linksCreated: 0,
    syntheticCreated: 0,
    autoLinksPurged: 0,
  }

  const sectionsByIndex = new Map<number, XlsxSection>(summary.sections.map((s) => [s.index, s]))
  const planByIndex = new Map<number, XlsxImportPlan['sections'][number]>(plan.sections.map((s) => [s.sectionIndex, s]))

  /* ---- 0. purge dei collegamenti auto-scoperti (opt-in) ---- */
  if (options.purgeAutoLinks) {
    const purged = await tx.topologyLink.deleteMany({
      where: {
        plantId: options.plantId,
        sourceOfTruth: { in: [...AUTO_DISCOVERED_SOURCES] },
      },
    })
    counts.autoLinksPurged = purged.count
  }

  /* ---- 1. sedi + dispositivi, sezione per sezione ---- */
  const existingLocations = await tx.location.findMany({
    where: { plantId: options.plantId },
    select: { id: true, identifier: true, name: true },
  })
  const existingIdentifiers = new Set(existingLocations.map((l) => l.identifier))
  const ipToDevice = new Map<string, { id: string }>()
  for (const d of await tx.device.findMany({
    where: { plantId: options.plantId },
    select: { id: true, ip: true },
  })) {
    ipToDevice.set(d.ip, d)
  }

  const sectionLocationIds = new Map<number, string>()
  const usedLocationIds = new Set<string>()
  /** gateway della prima sezione che ne ha uno (la «testa» di rete) */
  let gatewayRef: { id: string; hostname: string } | null = null
  /** dispositivi che sono già TARGET di un collegamento (hanno un padre) */
  const parentedTargets = new Set<string>()

  for (const confirm of options.sections) {
    const section = sectionsByIndex.get(confirm.sectionIndex)
    const planSection = planByIndex.get(confirm.sectionIndex)
    if (!section || !planSection) {
      throw Object.assign(new Error(`sezione ${confirm.sectionIndex} fuori range`), { code: 'BAD_BODY' })
    }

    /* ---- sede: override operatore > piano > creazione ---- */
    let locationId: string | null = null
    const overrideId = confirm.locationId ?? null
    if (overrideId) {
      const loc = existingLocations.find((l) => l.id === overrideId)
      if (!loc) {
        throw Object.assign(new Error(`sede ${overrideId} non trovata nell'impianto`), { code: 'BAD_BODY' })
      }
      if (usedLocationIds.has(overrideId) && planSection.locationId !== overrideId) {
        throw Object.assign(new Error(`sede «${loc.name}» già usata da un'altra sezione confermata`), { code: 'BAD_BODY' })
      }
      locationId = overrideId
    } else if (planSection.locationId) {
      if (usedLocationIds.has(planSection.locationId)) {
        // il piano aveva un match ma la sede è già impegnata → sede nuova
        const identifier = deriveIdentifier(section.name, existingIdentifiers)
        existingIdentifiers.add(identifier)
        const created = await tx.location.create({
          data: { plantId: options.plantId, identifier, name: section.name, address: '' },
        })
        locationId = created.id
        counts.locationsCreated += 1
      } else {
        locationId = planSection.locationId
      }
    } else {
      const identifier = deriveIdentifier(section.name, existingIdentifiers)
      existingIdentifiers.add(identifier)
      const created = await tx.location.create({
        data: { plantId: options.plantId, identifier, name: section.name, address: '' },
      })
      locationId = created.id
      counts.locationsCreated += 1
    }
    sectionLocationIds.set(section.index, locationId)
    usedLocationIds.add(locationId)

    /* ---- dispositivi della sezione ---- */
    for (const dev of section.devices) {
      // cifratura onesta: niente chiave → niente import credenziali
      let passwordEnc: string | null = null
      if (dev.password) {
        passwordEnc = encryptSecret(dev.password)
        if (!passwordEnc) {
          throw Object.assign(
            new Error('Chiave DEVICE_CREDENTIALS_KEY non configurata: impossibile cifrare le credenziali dell\'Excel'),
            { code: 'SETUP' },
          )
        }
      }

      const common = {
        hostname: dev.name,
        type: dev.type,
        ssid: dev.ssid,
        username: dev.username,
        connectionType: dev.isPtp ? 'PTP' : 'RADIO',
        locationId,
        locationAssignedBy: '',
      }

      const existing = ipToDevice.get(dev.ip)
      if (existing) {
        await tx.device.update({
          where: { id: existing.id },
          data: {
            ...common,
            hostnameManuallySet: false,
            ...(passwordEnc ? { password: passwordEnc } : {}),
            ...(dev.serial ? { serialNumber: dev.serial } : {}),
            ...(dev.wanIp ? { notes: `IP WAN: ${dev.wanIp}` } : {}),
          },
        })
        counts.devicesUpdated += 1
      } else {
        const created = await tx.device.create({
          data: {
            ...common,
            ip: dev.ip,
            plantId: options.plantId,
            status: 'UNKNOWN',
            ...(passwordEnc ? { password: passwordEnc } : {}),
            ...(dev.serial ? { serialNumber: dev.serial } : {}),
            ...(dev.wanIp ? { notes: `IP WAN: ${dev.wanIp}` } : {}),
          },
        })
        ipToDevice.set(dev.ip, { id: created.id })
        counts.devicesCreated += 1
      }

      // gateway della rete: catturato DOPO l'upsert (su impianto vergine
      // il dispositivo entra in ipToDevice solo a questo punto)
      if (dev.type === 'GATEWAY' && !gatewayRef) {
        const gw = ipToDevice.get(dev.ip)
        if (gw) gatewayRef = { id: gw.id, hostname: dev.name }
      }
    }
  }

  /* ---- 2. collegamenti radio dai gruppi SSID ---- */
  if (options.createLinks) {
    // i link esistenti confermati dall'operatore NON si duplicano
    const existingLinks = await tx.topologyLink.findMany({
      where: { plantId: options.plantId },
      select: { sourceDeviceId: true, targetDeviceId: true, sourceOfTruth: true, label: true },
    })
    const linkKey = (s: string | null, t: string | null) => `${s}→${t}`

    const confirmedKeys = new Set<string>()
    for (const l of existingLinks) {
      if (l.sourceOfTruth === 'TECHNICIAN') confirmedKeys.add(linkKey(l.sourceDeviceId, l.targetDeviceId))
      if (l.targetDeviceId) parentedTargets.add(l.targetDeviceId)
    }

    for (const link of plan.links) {
      const source = ipToDevice.get(link.sourceIp)
      const target = ipToDevice.get(link.targetIp)
      if (!source || !target) continue // dispositivi fuori dalle sezioni confermate
      if (confirmedKeys.has(linkKey(source.id, target.id))) continue
      await tx.topologyLink.create({
        data: {
          plantId: options.plantId,
          sourceDeviceId: source.id,
          targetDeviceId: target.id,
          sourceLabel: link.sourceName,
          targetLabel: link.targetName,
          linkType: 'RADIO',
          frequency: link.frequency,
          label: link.label,
          notes: `Import Excel — ${link.basis}`,
          sourceOfTruth: 'TECHNICIAN',
          confirmed: true,
          linkStatus: 'CONFIRMED',
        },
      })
      confirmedKeys.add(linkKey(source.id, target.id))
      counts.linksCreated += 1
      parentedTargets.add(target.id)
    }
  }

  /* ---- 3. basestation sintetiche confermate ---- */
  for (const confirm of options.synthetic) {
    const syn = plan.synthetic[confirm.index]
    if (!syn) {
      throw Object.assign(new Error(`proposta sintetica ${confirm.index} fuori range`), { code: 'BAD_BODY' })
    }
    const locationId = confirm.locationId ?? syn.locationId ?? null
    if (!locationId) {
      throw Object.assign(new Error(`basestation «${syn.name}»: sede di destinazione richiesta`), { code: 'BAD_BODY' })
    }
    const loc = await tx.location.findUnique({ where: { id: locationId }, select: { id: true, name: true } })
    if (!loc) {
      throw Object.assign(new Error(`sede ${locationId} non trovata`), { code: 'BAD_BODY' })
    }

    // idempotenza: se la basestation esiste già (import precedente),
    // la RIUSA — niente doppioni
    let created = await tx.device.findFirst({
      where: { plantId: options.plantId, hostname: syn.name, locationId },
      select: { id: true },
    })
    if (!created) {
      // IP segnaposto documentale: senza schedule di polling lo stato
      // derivato è NOT_MONITORED (nessun ping, nessun falso allarme)
      created = await tx.device.create({
        data: {
          ip: '0.0.0.0',
          hostname: syn.name,
          type: 'AP',
          ssid: syn.ssid,
          plantId: options.plantId,
          locationId,
          locationAssignedBy: '',
          status: 'UNKNOWN',
          notes: 'Basestation fuori inventario Excel — segnaposto topologico (IP documentale 0.0.0.0, non in polling)',
          connectionType: 'RADIO',
        },
      })
      counts.syntheticCreated += 1
    }

    for (const station of syn.stations) {
      const target = ipToDevice.get(station.ip)
      if (!target) continue
      await tx.topologyLink.create({
        data: {
          plantId: options.plantId,
          sourceDeviceId: created.id,
          targetDeviceId: target.id,
          sourceLabel: syn.name,
          targetLabel: station.name,
          linkType: 'RADIO',
          label: syn.ssid,
          notes: `Import Excel — basestation sintetica (${syn.locationBasis})`,
          sourceOfTruth: 'TECHNICIAN',
          confirmed: true,
          linkStatus: 'CONFIRMED',
        },
      })
      counts.linksCreated += 1
      parentedTargets.add(target.id)
    }
  }

  /* ---- 5. FIBRA dalla sezione «(Fibra)»: chiude l'albero dalla radice ----
   * Nell'Excel SETI reale la sezione «OLD Via Califano (Fibra) Fuori
   * Comando» dichiara la fibra che porta la rete FUORI dal Comando:
   * senza questo collegamento il gateway resta isolato dalle sedi
   * (tutte «irraggiungibili» nella topologia). Regola DICHIARATA nel
   * notes: sezione con «fibra» nel nome → il suo primo apparato senza
   * padre viene collegato al gateway. L'operatore può correggerla in
   * gestione collegamenti. */
  if (gatewayRef) {
    const fibraSection = summary.sections.find((s) => /fibra/i.test(s.name))
    if (fibraSection) {
      const fibraDev = fibraSection.devices.find((d) => {
        const dev = ipToDevice.get(d.ip)
        return dev && dev.id !== gatewayRef!.id && !parentedTargets.has(dev.id)
      })
      if (fibraDev) {
        await tx.topologyLink.create({
          data: {
            plantId: options.plantId,
            sourceDeviceId: gatewayRef.id,
            targetDeviceId: ipToDevice.get(fibraDev.ip)!.id,
            sourceLabel: gatewayRef.hostname,
            targetLabel: fibraDev.name,
            linkType: 'FIBRA',
            label: 'Fibra Comando',
            notes: `Import Excel — sezione «${fibraSection.name}»: fibra dal gateway (${gatewayRef.hostname}) al POP della sezione`,
            sourceOfTruth: 'TECHNICIAN',
            confirmed: true,
            linkStatus: 'CONFIRMED',
          },
        })
        counts.linksCreated += 1
      }
    }
  }

  /* ---- 4. LAN di sede: radio hub → apparati locali ----
   * L'albero della raggiera si costruisce dai collegamenti: senza
   * questi link le telecamere/NVR/SW restano «fuori albero». Il
   * modello fisico reale delle sedi SETI: il radio di sede (ST/PTP)
   * alimenta lo SW POE che alimenta le telecamere. L'hub è il primo
   * STA/AP/GATEWAY della sezione (l'ordine dell'Excel è quello
   * d'installazione: il radio è citato per primo). */
  if (options.createLanLinks) {
    // dispositivi con un padre confermato (già target di un link)
    const parented = new Set<string>()
    const allLinks = await tx.topologyLink.findMany({
      where: { plantId: options.plantId },
      select: { targetDeviceId: true, sourceDeviceId: true },
    })
    for (const l of allLinks) {
      if (l.targetDeviceId) parented.add(l.targetDeviceId)
    }

    const lanKey = (s: string, t: string) => `${s}→${t}`
    const existingLanKeys = new Set<string>()
    for (const l of allLinks) {
      if (l.sourceDeviceId && l.targetDeviceId) existingLanKeys.add(lanKey(l.sourceDeviceId, l.targetDeviceId))
    }

    for (const confirm of options.sections) {
      const section = sectionsByIndex.get(confirm.sectionIndex)
      if (!section || section.devices.length < 2) continue

      // hub: primo STA, poi AP, poi GATEWAY, poi il primo apparato
      const hub =
        section.devices.find((d) => d.type === 'STA') ??
        section.devices.find((d) => d.type === 'AP') ??
        section.devices.find((d) => d.type === 'GATEWAY') ??
        section.devices[0]
      const hubDevice = ipToDevice.get(hub.ip)
      if (!hubDevice) continue

      // SW POE intermedio se presente (catena radio → switch → camere)
      const sw = section.devices.find((d) => d.type === 'SWITCH' && d.ip !== hub.ip)
      const swDevice = sw ? ipToDevice.get(sw.ip) : null

      const makeLan = async (sourceId: string, targetId: string, sourceLabel: string, targetLabel: string) => {
        if (sourceId === targetId) return
        if (existingLanKeys.has(lanKey(sourceId, targetId))) return
        await tx.topologyLink.create({
          data: {
            plantId: options.plantId,
            sourceDeviceId: sourceId,
            targetDeviceId: targetId,
            sourceLabel,
            targetLabel,
            linkType: 'LAN',
            label: 'LAN sede',
            notes: 'Import Excel — collegamento LAN implicito di sede (radio/SW POE → apparati)',
            sourceOfTruth: 'TECHNICIAN',
            confirmed: true,
            linkStatus: 'CONFIRMED',
          },
        })
        existingLanKeys.add(lanKey(sourceId, targetId))
        counts.linksCreated += 1
        parentedTargets.add(targetId)
      }

      // 1) hub → SW POE (il radio di sede alimenta lo switch; se lo SW
      //    è il primo della sezione va collegato QUI, non «pigro»:
      //    il giro precedente lo marcava parented senza dargli il padre
      //    e la catena si spezzava alla prima sede con SW in testa)
      if (swDevice && swDevice.id !== hubDevice.id && !parented.has(swDevice.id)) {
        await makeLan(hubDevice.id, swDevice.id, hub.name, sw!.name)
        parented.add(swDevice.id)
      }
      // 2) ogni altro apparato: SW → apparato (catena POE), senza SW
      //    resta hub → apparato
      for (const dev of section.devices) {
        const target = ipToDevice.get(dev.ip)
        if (!target || target.id === hubDevice.id) continue
        if (swDevice && target.id === swDevice.id) continue
        if (parented.has(target.id)) continue // ha già un padre radio: non serve

        if (swDevice) {
          await makeLan(swDevice.id, target.id, sw!.name, dev.name)
        } else {
          await makeLan(hubDevice.id, target.id, hub.name, dev.name)
        }
        parented.add(target.id)
      }
    }
  }

  return counts
}
