/* ================================================================
 * FALCO-OS v16.15 W14 — CORRELAZIONE L2 MULTI-SWITCH
 * src/lib/domain/l2-correlate.ts
 * ================================================================
 * «Quando SONDE più switch, la rete in bridge si ricompone da sola.»
 *
 * L'algoritmo (ispirato a NetDisco neighbors + OpenNMS Enlinkd,
 * adattato alle regole d'onestà FALCO):
 *
 *   1. AVVISTAMENTO MUTUO — lo switch A ha il MAC bridge di B sulla
 *      porta pA, E B ha il MAC bridge di A sulla porta pB ⇒ cavo reale
 *      A↔B con ENTRAMBE le porte note: link FDB_MUTUAL (HIGH);
 *   2. AVVISTAMENTO SINGOLO — solo A vede il MAC di B (la FDB di B è
 *      vuota o non letta) ⇒ link FDB_PAIR (MEDIUM): B sta dietro pA;
 *   3. DIREZIONE DELL'ALBERO — l'STP la DICE: chi ha la rootPort sulla
 *      porta del link guarda VERSO l'altro (è a valle); in assenza di
 *      STP vale il bridge designato; in assenza di entrambi, il
 *      bridgeId più basso (priorità+MAC) fa da tie-break onesto,
 *      dichiarato nel dettaglio;
 *   4. CORROBORAZIONE — se il bridge designato della porta di B è il
 *      MAC bridge di A, il link FDB_PAIR sale a FDB_MUTUAL: due
 *      dichiarazioni indipendenti concordano;
 *   5. ARP — le voci di TUTTI gli apparati si fondono: i MAC non in
 *      inventario con IP noto diventano candidati all'adozione
 *      (riportati, MAI auto-adottati);
 *   6. ROOT — la root bridge STP dichiarata dalla maggioranza degli
 *      apparati (o il MAC più frequente) orienta il grafo.
 *
 * PURE FUNCTION: nessun DB, nessun dato inventato — ciò che non è
 * dichiarato torna come avviso o come «non abbinato».
 * ================================================================ */

import { normalizeMac, type InventoryDevice, type L2ProbePayload } from './l2-reconstruct'

/* ---------------- Input / Output ---------------- */

/** Uno switch sondato: dispositivo d'inventario + payload della sonda. */
export interface CorrelatorSwitch {
  device: InventoryDevice
  probe: L2ProbePayload
}

export type SwitchLinkKind = 'FDB_MUTUAL' | 'FDB_PAIR' | 'STP_DESIGNATED'

export interface CorrelatedSwitchLink {
  /** Dispositivo A MONTE (upstream, verso la root). */
  upstreamDeviceId: string
  upstreamHostname: string
  upstreamPort: string
  upstreamPortNum: number
  upstreamSpeedMbps: number
  /** Dispositivo a VALLE (downstream). */
  downstreamDeviceId: string
  downstreamHostname: string
  downstreamPort: string
  downstreamPortNum: number
  downstreamSpeedMbps: number
  kind: SwitchLinkKind
  confidence: 'HIGH' | 'MEDIUM'
  evidence: string
  /** TRUE se l'STP concorda con la direzione (designato/rootPort). */
  stpCorroborated: boolean
  detail: string
}

/** MAC non in inventario con IP risolto dall'ARP di UNO degli switch. */
export interface ArpCandidate {
  mac: string
  ip: string
  seenBy: string // hostname dello switch che l'ha dichiarato
}

export interface L2Correlation {
  switchLinks: CorrelatedSwitchLink[]
  /** MAC→IP non inventariati (candidati adozione — scelta umana). */
  arpCandidates: ArpCandidate[]
  /** Root bridge STP come vista dagli apparati (MAC, '' se nessuno dichiara). */
  rootBridgeMac: string
  /** Quanti apparati dichiarano quella root (per l'onestà del report). */
  rootVotes: number
  /** Per ogni switch: porta verso la root STP (se dichiarata). */
  rootPorts: Array<{ deviceId: string; hostname: string; portNum: number; portName: string }>
  warnings: string[]
}

/* ---------------- Utility ---------------- */

/** Vista interna di uno switch: MAC noti (bridge + inventario) e FDB. */
interface SwitchView {
  device: InventoryDevice
  /** MAC bridge dichiarato dall'STP ('' se assente). */
  bridgeMac: string
  /** MAC inventario del dispositivo (può differire dal bridge MAC). */
  deviceMac: string
  /** MAC → porta bridge (dalla FDB, scartati gli ambigui). */
  macToPort: Map<string, number>
  /** Porta bridge → nome ifName. */
  portNames: Map<number, string>
  /** Porta bridge → velocità Mbps. */
  portSpeeds: Map<number, number>
  /** STP: porta bridge → MAC del designato. */
  designatedBy: Map<number, string>
  rootPort: number
  rootBridgeMac: string
}

function portName(view: SwitchView, port: number): string {
  return view.portNames.get(port) ?? `port ${port}`
}

function portSpeed(view: SwitchView, port: number): number {
  return view.portSpeeds.get(port) ?? 0
}

/** Costruisce la vista di uno switch dal payload della sonda. */
function buildView(sw: CorrelatorSwitch, warnings: string[]): SwitchView {
  const probe = sw.probe
  const macToPort = new Map<string, number>()
  const ambiguous = new Set<string>()
  for (const row of probe.fdb ?? []) {
    const mac = normalizeMac(row.mac)
    if (!mac) continue
    const prev = macToPort.get(mac)
    if (prev !== undefined && prev !== row.port) {
      ambiguous.add(mac)
    } else {
      macToPort.set(mac, row.port)
    }
  }
  for (const row of probe.vlanFdb ?? []) {
    const mac = normalizeMac(row.mac)
    if (!mac || macToPort.has(mac)) continue
    const prev = macToPort.get(mac)
    if (prev !== undefined && prev !== row.port) {
      ambiguous.add(mac)
    } else {
      macToPort.set(mac, row.port)
    }
  }
  for (const mac of ambiguous) macToPort.delete(mac)

  // porte: bridge→ifIndex→nome/velocità
  const ifByIndex = new Map<number, { name: string | null; descr: string | null; speed: number }>()
  for (const itf of probe.interfaces ?? []) {
    ifByIndex.set(itf.ifIndex, {
      name: itf.name ?? null,
      descr: itf.descr ?? null,
      speed: itf.speedMbps ?? 0,
    })
  }
  const portNames = new Map<number, string>()
  const portSpeeds = new Map<number, number>()
  for (const bp of probe.bridgePorts ?? []) {
    const itf = ifByIndex.get(bp.ifIndex)
    const name = itf?.name ?? itf?.descr ?? ''
    if (name) portNames.set(bp.port, name)
    if (itf && itf.speed > 0) portSpeeds.set(bp.port, itf.speed)
  }

  // STP
  const stp = probe.stp
  const designatedBy = new Map<number, string>()
  if (stp?.present) {
    for (const p of stp.ports) {
      if (p.designatedBridgeMac) designatedBy.set(p.port, normalizeMac(p.designatedBridgeMac))
    }
  }

  if (ambiguous.size > 0) {
    warnings.push(`${sw.device.hostname}: ${ambiguous.size} MAC su più porte (flapping/STP) esclusi dalla correlazione`)
  }

  return {
    device: sw.device,
    bridgeMac: normalizeMac(stp?.bridgeMac ?? ''),
    deviceMac: normalizeMac(sw.device.macAddress),
    macToPort,
    portNames,
    portSpeeds,
    designatedBy,
    rootPort: stp?.present ? stp.rootPort : 0,
    rootBridgeMac: normalizeMac(stp?.rootBridgeMac ?? ''),
  }
}

/** Cerca la porta su cui «viewer» vede il MAC di «target». */
function portSeeingMac(viewer: SwitchView, target: SwitchView): number | undefined {
  // il MAC bridge (se dichiarato) è la firma dello switch; altrimenti il
  // MAC inventario — e si provano ENTRAMBI (un vendor può esporli diversi)
  const candidates = [target.bridgeMac, target.deviceMac].filter((m) => m !== '')
  for (const mac of candidates) {
    const port = viewer.macToPort.get(mac)
    if (port !== undefined) return port
  }
  return undefined
}

/* ---------------- Correlazione ---------------- */

/**
 * Correla N sonde L2 (switch dell'impianto) con l'inventario COMPLETO
 * del plant: produce i link switch↔switch con porte di ENTRAMBI i lati,
 * la direzione verso la root STP e i candidati ARP. PURE function.
 */
export function l2Correlate(switches: CorrelatorSwitch[], inventory: InventoryDevice[]): L2Correlation {
  const warnings: string[] = []
  const views = switches.map((sw) => buildView(sw, warnings))

  /* ---- root STP votata dalla maggioranza ---- */
  const rootVotes = new Map<string, number>()
  for (const v of views) {
    if (v.rootBridgeMac) {
      rootVotes.set(v.rootBridgeMac, (rootVotes.get(v.rootBridgeMac) ?? 0) + 1)
    }
  }
  let rootBridgeMac = ''
  let rootVotesCount = 0
  for (const [mac, n] of rootVotes) {
    if (n > rootVotesCount || (n === rootVotesCount && mac < rootBridgeMac)) {
      rootBridgeMac = mac
      rootVotesCount = n
    }
  }
  const rootPorts: L2Correlation['rootPorts'] = views
    .filter((v) => v.rootPort > 0)
    .map((v) => ({
      deviceId: v.device.id,
      hostname: v.device.hostname,
      portNum: v.rootPort,
      portName: portName(v, v.rootPort),
    }))

  /* ---- link switch↔switch: mutui e singoli ---- */
  const switchLinks: CorrelatedSwitchLink[] = []
  const pairDone = new Set<string>() // "idA|idB" canonico

  for (let i = 0; i < views.length; i++) {
    for (let j = 0; j < views.length; j++) {
      if (i === j) continue
      const a = views[i] // chi guarda
      const b = views[j] // chi è visto
      const pairKey = [a.device.id, b.device.id].sort().join('|')
      if (pairDone.has(pairKey)) continue

      const pA = portSeeingMac(a, b) // porta di A che vede il MAC di B
      const pB = portSeeingMac(b, a) // porta di B che vede il MAC di A
      if (pA === undefined && pB === undefined) continue

      // corroboration STP: B dichiara il designato della propria porta
      const stpFromB = pB !== undefined ? b.designatedBy.get(pB) : undefined
      const stpFromA = pA !== undefined ? a.designatedBy.get(pA) : undefined
      const bDesignatesA = stpFromB !== undefined && stpFromB !== '' &&
        (stpFromB === a.bridgeMac || stpFromB === a.deviceMac)
      const aDesignatesB = stpFromA !== undefined && stpFromA !== '' &&
        (stpFromA === b.bridgeMac || stpFromA === b.deviceMac)

      /* --- direzione dell'albero: chi è a monte? ---
       * 1. rootPort: chi ha la rootPort sulla porta del link guarda l'altro
       *    (la sua strada per la root passa di lì ⇒ è a valle);
       * 2. designated bridge: se B dichiara A come designato, A è a monte;
       * 3. tie-break: bridgeId — già risolto dall'ordine (a=upstream se
       *    il suo bridgeId è minore); dichiarato nel dettaglio. */
      let upstream = a
      let downstream = b
      let directionSource = 'MAC bridge (tie-break)'
      const bIsDownstreamByRootPort = pB !== undefined && b.rootPort === pB
      const aIsDownstreamByRootPort = pA !== undefined && a.rootPort === pA
      if (bIsDownstreamByRootPort) {
        upstream = a; downstream = b; directionSource = 'rootPort STP'
      } else if (aIsDownstreamByRootPort) {
        upstream = b; downstream = a; directionSource = 'rootPort STP'
      } else if (bDesignatesA) {
        upstream = a; downstream = b; directionSource = 'bridge designato STP'
      } else if (aDesignatesB) {
        upstream = b; downstream = a; directionSource = 'bridge designato STP'
      } else if ((a.bridgeMac || a.deviceMac) > (b.bridgeMac || b.deviceMac)) {
        upstream = b; downstream = a
      }

      // porte dei due lati nella direzione scelta
      const upPort = upstream === a ? pA : pB
      const downPort = upstream === a ? pB : pA

      const mutual = pA !== undefined && pB !== undefined
      const stpCorroborated = bDesignatesA || aDesignatesB ||
        bIsDownstreamByRootPort || aIsDownstreamByRootPort

      const kind: SwitchLinkKind = mutual ? 'FDB_MUTUAL' : 'FDB_PAIR'
      const confidence: 'HIGH' | 'MEDIUM' = mutual ? 'HIGH' : 'MEDIUM'
      const evidence = mutual ? 'FDB_MUTUAL' : 'FDB_PAIR'

      const upName = upPort !== undefined ? portName(upstream, upPort) : ''
      const downName = downPort !== undefined ? portName(downstream, downPort) : ''

      const parts: string[] = []
      if (mutual) {
        parts.push(`avvistamento reciproco: ${upstream.device.hostname} vede ${downstream.device.hostname} su ${upName || 'porta ?'} e viceversa su ${downName || 'porta ?'}`)
      } else {
        const viewer = pA !== undefined ? a : b
        const seen = pA !== undefined ? b : a
        // pB qui è SEMPRE definito: il caso entrambi-undefined è stato
        // scartato dalla guardia in testa alla coppia (as = solo tipi,
        // zero effetto a runtime — fix tsc, nessun cambio di logica)
        const viewerPort = pA !== undefined ? pA : (pB as number)
        parts.push(`${viewer.device.hostname} vede il MAC di ${seen.device.hostname} su ${portName(viewer, viewerPort)} (FDB dell'altro lato muta o non letta)`)
      }
      parts.push(`direzione da ${directionSource}`)
      if (stpCorroborated) parts.push('STP concorda')

      switchLinks.push({
        upstreamDeviceId: upstream.device.id,
        upstreamHostname: upstream.device.hostname,
        upstreamPort: upName,
        upstreamPortNum: upPort ?? 0,
        upstreamSpeedMbps: upPort !== undefined ? portSpeed(upstream, upPort) : 0,
        downstreamDeviceId: downstream.device.id,
        downstreamHostname: downstream.device.hostname,
        downstreamPort: downName,
        downstreamPortNum: downPort ?? 0,
        downstreamSpeedMbps: downPort !== undefined ? portSpeed(downstream, downPort) : 0,
        kind,
        confidence,
        evidence,
        stpCorroborated,
        detail: parts.join(' · '),
      })
      pairDone.add(pairKey)
    }
  }

  /* ---- link STP_DESIGNATED verso apparati NON sondati ----
   *  una porta il cui designato è un dispositivo d'inventario NOTO ma
   *  non tra gli switch sondati (es. un gateway muto su SNMP): la
   *  dichiarazione STP resta l'unica verità — link MEDIUM. */
  const inventoryByMac = new Map<string, InventoryDevice>()
  for (const d of inventory) {
    const mac = normalizeMac(d.macAddress)
    if (mac) inventoryByMac.set(mac, d)
  }
  for (const sw of switches) {
    const bmac = normalizeMac(sw.probe.stp?.bridgeMac ?? '')
    if (bmac && !inventoryByMac.has(bmac)) {
      // il MAC bridge di uno switch sondato può differire dal suo MAC
      // inventario: lo registriamo così che i designati possano
      // puntare correttamente agli switch già sondati
      inventoryByMac.set(bmac, sw.device)
    }
  }
  const probedIds = new Set(switches.map((sw) => sw.device.id))
  const coveredPairs = new Set<string>()
  for (const l of switchLinks) {
    coveredPairs.add([l.upstreamDeviceId, l.downstreamDeviceId].sort().join('|'))
  }
  for (const v of views) {
    for (const [port, designatedMac] of v.designatedBy) {
      if (!designatedMac) continue
      if (designatedMac === v.bridgeMac || designatedMac === v.deviceMac) continue // noi stessi
      const target = inventoryByMac.get(designatedMac)
      if (!target || probedIds.has(target.id)) continue // solo NON sondati
      const pairKey = [v.device.id, target.id].sort().join('|')
      if (coveredPairs.has(pairKey)) continue
      coveredPairs.add(pairKey)
      switchLinks.push({
        upstreamDeviceId: target.id, // il designato è a monte per definizione
        upstreamHostname: target.hostname,
        upstreamPort: '',
        upstreamPortNum: 0,
        upstreamSpeedMbps: 0,
        downstreamDeviceId: v.device.id,
        downstreamHostname: v.device.hostname,
        downstreamPort: portName(v, port),
        downstreamPortNum: port,
        downstreamSpeedMbps: portSpeed(v, port),
        kind: 'STP_DESIGNATED',
        confidence: 'MEDIUM',
        evidence: 'STP_DESIGNATED',
        stpCorroborated: true,
        detail: `STP: ${v.device.hostname} porta ${portName(v, port)} designata dal bridge ${designatedMac} (${target.hostname}) — apparato non sondato via SNMP L2`,
      })
    }
  }

  /* ---- ARP di tutti gli switch: candidati (MAC non in inventario) ---- */
  const inventoryMacs = new Set<string>()
  for (const d of inventory) {
    const mac = normalizeMac(d.macAddress)
    if (mac) inventoryMacs.add(mac)
  }
  for (const sw of switches) {
    const bmac = normalizeMac(sw.probe.stp?.bridgeMac ?? '')
    if (bmac) inventoryMacs.add(bmac) // nemmeno i bridge MAC son candidati
  }
  const arpCandidates: ArpCandidate[] = []
  const seenCandidates = new Set<string>()
  for (const sw of switches) {
    for (const row of sw.probe.arp ?? []) {
      const mac = normalizeMac(row.mac)
      if (!mac || inventoryMacs.has(mac) || seenCandidates.has(mac)) continue
      seenCandidates.add(mac)
      arpCandidates.push({ mac, ip: row.ip, seenBy: sw.device.hostname })
    }
  }

  if (switchLinks.length === 0 && views.length > 1) {
    warnings.push('nessun link switch↔switch correlato (FDB senza MAC bridge reciproci e STP assente)')
  }

  return {
    switchLinks,
    arpCandidates,
    rootBridgeMac,
    rootVotes: rootVotesCount,
    rootPorts,
    warnings,
  }
}
