/* ================================================================
 * FALCO-OS v16.13 — XLSX Parser «formato SETI» (W11)
 *
 * L'operatore carica l'Excel di installazione (es. «Sant Egidio
 * Monte Albino.xlsx») per far partire un impianto già avvantaggiato:
 *   · SEZIONI = sedi (righe senza IP con nome sede: «P1 - Via …»,
 *     «Comando PL», «OLD Cimitero»…);
 *   · RIGHE DISPOSITIVO = IP | nome | SSID/WAN | utente | password |
 *     seriale (le celle vuote sono IP non assegnati → ignorate).
 *
 * Nessuna scrittura qui: il parser è PURO e produce la struttura
 * che il piano (xlsx-import-plan) confronta con il DB. Le difese:
 *   · solo fogli che sembrano rete (celle IPv4 in colonna A);
 *   · tetto dimensioni/celle (file office gonfiati = rifiuto);
 *   · righe «spazzatura» (Rete/Ultimo/sub-righe senza IP) escluse
 *     con motivo, tutto visibile in preview.
 * Dipendenza: xlsx (SheetJS), lato server soltanto.
 * ================================================================ */

import * as XLSX from 'xlsx'

const MAX_XLSX_BYTES = 15 * 1024 * 1024 // 15 MB
const MAX_CELLS = 200_000

/** Una sezione dell'Excel = una sede (impianto) con i suoi apparati. */
export interface XlsxSection {
  index: number
  name: string
  /** riga Excel (1-based) della testata — per i messaggi all'operatore */
  headerRow: number
  devices: XlsxDeviceRow[]
}

/** Una riga dispositivo dell'Excel. */
export interface XlsxDeviceRow {
  ip: string
  name: string
  /** colonna C: SSID del radio-link quando non è un IP WAN */
  ssid: string
  /** colonna C quando è un IP (es. router con WAN 172.150.150.1) */
  wanIp: string
  username: string
  password: string
  serial: string
  /** classificazione dedotta dal nome (AP/STA/SWITCH/…) */
  type: string
  /** PTP esplicito nel nome → connectionType PTP */
  isPtp: boolean
  row: number
}

export interface XlsxWorkbookSummary {
  fileName: string
  sheetName: string
  network: string
  sections: XlsxSection[]
  /** righe scartate con motivo (trasparenza preview) */
  skipped: Array<{ row: number; reason: string }>
}

/* ---------------- normalizzazione e classificazione ---------------- */

const IPV4_RE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/

function isIPv4(s: string): boolean {
  const m = IPV4_RE.exec(s.trim())
  if (!m) return false
  return m.slice(1).every((p) => Number(p) <= 255)
}

function isCidr(s: string): boolean {
  return /^\d{1,3}(\.\d{1,3}){3}\/\d{1,2}$/.test(s.trim())
}

/**
 * Riga senza IP che NON è una sede: riga di servizio dell'Excel
 * («Rete», «Ultimo …») o sub-righe di apparato («Hicentral web»).
 */
const SERVICE_ROW_RE = /^(rete|ultimo|ultima)\b/i
const DEVICEISH_RE =
  /router|nvr|client|proxmox|\bilo\b|server|inquiris|hik?central|\bsw\b|switch|switch|\bst\b|st\s*antenna|st\s*\d|\bptp\b|\bap\b|ap\s*\d|contesto|tlc|telecamera|axis|\bcam\b|\blpr\b|settore|settop|mikrotik|hikvision|dahua|axis|ubicam|vigilate/i

/** Classificazione tipo apparato dal nome (ordine = priorità). */
const TYPE_RULES: Array<{ re: RegExp; type: string }> = [
  { re: /^router\b/i, type: 'GATEWAY' },
  { re: /\bnvr\b/i, type: 'NVR' },
  { re: /^client\b/i, type: 'SERVER' },
  { re: /proxmox|\bilo\b|^server\b|^inquiris|hik?central/i, type: 'SERVER' },
  { re: /^sw[\s_-]|^sw$|switch/i, type: 'SWITCH' },
  { re: /^st[\s_-]|^st$|^st\s*antenna|^st\s*\d/i, type: 'STA' },
  { re: /^ptp\b/i, type: 'AP' },
  { re: /^ap[\s_-]|^ap\d*\b/i, type: 'AP' },
  { re: /\blpr\b/i, type: 'LPR' },
  { re: /contesto|\btlc\b|telecamera|axis|\bcam\b/i, type: 'CAMERA' },
  { re: /settore/i, type: 'AP' },
]

function classifyDevice(name: string): { type: string; isPtp: boolean } {
  const isPtp = /^ptp\b/i.test(name.trim())
  for (const rule of TYPE_RULES) {
    if (rule.re.test(name.trim())) return { type: rule.type, isPtp }
  }
  return { type: 'UNKNOWN', isPtp }
}

/** I seriali Hikvision/template SETI iniziano con sigle tipo «DS-». */
const SERIAL_LIKE_RE = /^[A-Z]{2,4}-/i

function cellText(v: unknown): string {
  if (v == null) return ''
  if (typeof v === 'string') return v.trim()
  if (typeof v === 'number') return String(v)
  return String(v).trim()
}

/* ---------------- parse principale ---------------- */

/**
 * Parso il buffer .xlsx e restituisco il sommario del foglio «rete».
 * Il primo foglio con celle IPv4 in colonna A vince (nella pratica
 * SETI è «Rete Nuova»; «OLD»/«Lic» restano informativi).
 */
export function parseSetiXlsx(buffer: Buffer, fileName: string): XlsxWorkbookSummary {
  if (buffer.length > MAX_XLSX_BYTES) {
    throw new Error(`File troppo grande (${(buffer.length / 1024 / 1024).toFixed(1)} MB, massimo 15 MB)`)
  }
  if (!fileName.toLowerCase().endsWith('.xlsx')) {
    throw new Error('Formato non supportato: è accettato solo .xlsx')
  }

  let wb: XLSX.WorkBook
  try {
    wb = XLSX.read(buffer, { type: 'buffer', cellDates: false })
  } catch {
    throw new Error('File .xlsx illeggibile o corrotto')
  }

  // scegli il foglio «di rete»: il primo con IPv4 in colonna A
  let chosen: { name: string; rows: unknown[][] } | null = null
  for (const sheetName of wb.SheetNames) {
    const ws = wb.Sheets[sheetName]
    if (!ws) continue
    const rows = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, blankrows: true, defval: null })
    let cellCount = 0
    let hasIp = false
    for (const row of rows) {
      cellCount += row.length
      if (!hasIp && row.length > 0 && isIPv4(cellText(row[0]))) hasIp = true
    }
    if (cellCount > MAX_CELLS) {
      throw new Error(`Foglio «${sheetName}» troppo grande (${cellCount} celle, massimo ${MAX_CELLS})`)
    }
    if (hasIp) {
      chosen = { name: sheetName, rows: rows as unknown[][] }
      break
    }
  }
  if (!chosen) {
    throw new Error('Nessun foglio con indirizzi IP trovato: serve l\'Excel di installazione (colonna A = IP)')
  }

  const sections: XlsxSection[] = []
  const skipped: Array<{ row: number; reason: string }> = []
  let network = ''
  let current: XlsxSection | null = null
  let lastDevice: XlsxDeviceRow | null = null

  for (let i = 0; i < chosen.rows.length; i++) {
    const row = chosen.rows[i] ?? []
    const a = cellText(row[0])
    const b = cellText(row[1])
    const c = cellText(row[2])
    const d = cellText(row[3])
    const e = cellText(row[4])
    const f = cellText(row[5])
    const rowNo = i + 1

    // riga totalmente vuota → azzera il «precedente» (le sezioni sono
    // separate da righe vuote: una sub-rig non può agganciarsi oltre)
    if (!a && !b && !c && !d && !e && !f) {
      lastDevice = null
      continue
    }

    // metadati di rete: «Rete | 172.19.150.0/23»
    if (!a && b && isCidr(c)) {
      network = c
      skipped.push({ row: rowNo, reason: `info di rete (${b} ${c})` })
      continue
    }

    // riga di servizio: «Ultimo 172.19.151.199», ecc.
    if (!a && b && SERVICE_ROW_RE.test(b)) {
      skipped.push({ row: rowNo, reason: `riga di servizio («${b}»)` })
      continue
    }

    // riga dispositivo: IPv4 in colonna A
    if (a && isIPv4(a)) {
      const ip = a
      if (!b) {
        // IP senza nome: slot riservato non ancora installato
        skipped.push({ row: rowNo, reason: `IP ${ip} senza nome (slot non assegnato)` })
        lastDevice = null
        continue
      }
      // colonna C: SSID quando NON è un IP (WAN) e non vuota
      const col3IsIp = isIPv4(c)
      const ssid = c && !col3IsIp ? c : ''
      const wanIp = col3IsIp ? c : ''
      // password: colonna E; se vuota, la colonna F quando NON sembra un seriale
      let password = e
      let serial = ''
      if (f) {
        if (SERIAL_LIKE_RE.test(f) || e) serial = f
        else password = password || f
      }
      const { type, isPtp } = classifyDevice(b)
      const dev: XlsxDeviceRow = {
        ip,
        name: b,
        ssid,
        wanIp,
        username: d,
        password,
        serial,
        type,
        isPtp,
        row: rowNo,
      }
      if (current) {
        current.devices.push(dev)
      } else {
        skipped.push({ row: rowNo, reason: `dispositivo «${b}» (${ip}) fuori da una sezione` })
      }
      lastDevice = dev
      continue
    }

    // riga senza IP e con nome: sezione (sede)…
    if (!a && b) {
      // i nomi di SEDE battono le parole da apparato: «P.A 3 … Contesto»,
      // «PA 10 Piazza …», «P:A.1 Stadio», «OLD Cimitero»…
      const looksLikeSite =
        /^p[.:\s]?a[.:\s]?\s*\d/i.test(b) || // P1/P10/PA 10/P.A 2/P:A.1
        /^(old\s+)?(cimitero|parcheggio|scuola|via|piazza|palazz)/i.test(b) ||
        /^(comando|comune|caposportivo|polizia|stadio|rip\b|rip\s*\d|postazione|ripartitore)/i.test(b)
      if (DEVICEISH_RE.test(b) && !looksLikeSite) {
        // …sub-riga di apparato (es. «Hiccentral web»): tracciata, non importata
        const extra = [c, d, e].filter(Boolean).join(' / ')
        skipped.push({ row: rowNo, reason: `sub-riga «${b}»${extra ? ` (${extra})` : ''} — informativa` })
        continue
      }
      current = {
        index: sections.length,
        name: b,
        headerRow: rowNo,
        devices: [],
      }
      sections.push(current)
      lastDevice = null
      continue
    }

    // qualsiasi altra cosa
    if (a || b || c || d || e || f) {
      skipped.push({ row: rowNo, reason: 'riga non riconosciuta' })
    }
  }

  return {
    fileName,
    sheetName: chosen.name,
    network,
    sections: sections.filter((s) => s.devices.length > 0 || s.name.length > 0),
    skipped,
  }
}
