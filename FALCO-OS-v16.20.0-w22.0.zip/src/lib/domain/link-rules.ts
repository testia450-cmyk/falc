/* ================================================================
 * FALCO-OS v16 — REGOLE COLLEGAMENTI (port dal backend v15.16.0)
 * Provenienza: src/lib/topology-link-rules.ts:39-48 (repo v15.16.0)
 * «L'UNICA definizione di collegamento attivo del sistema» —
 * port identico, nessuna logica nuova.
 * ================================================================ */

export const ACTIVE_LINK_STATUSES = ['UP', 'ACTIVE', 'CONFIRMED', 'ON'] as const

export type ActiveLinkStatus = (typeof ACTIVE_LINK_STATUSES)[number]

export function isLinkStatusActive(status: string | null | undefined): boolean {
  if (!status) return false
  const s = status.trim().toUpperCase()
  return (ACTIVE_LINK_STATUSES as readonly string[]).includes(s)
}

/** SOT che rendono un link MANUALE (l'operatore ha l'ultima parola).
 * Provenienza: topology-reconstruction.ts:211 MANUAL_LINK_SOTS. */
export const MANUAL_LINK_SOTS = new Set(['TECHNICIAN', 'MANUAL', 'TREE'])

/** Costo di aggancio delle componenti all'albero (MINORE = migliore).
 * Provenienza: topology-reconstruction.ts:197 TIER_ATTACH_COST. */
export const TIER_ATTACH_COST: Record<string, number> = {
  LLDP: 0.5,
  MNDP: 0.5,
  UISP: 1,
  WIRELESS: 1,
  FDB_PAIR: 1,
  FDB_ENDPOINT: 1.5,
  FDB_MUTUAL: 4,
  FDB_ONEDIR: 8,
}
