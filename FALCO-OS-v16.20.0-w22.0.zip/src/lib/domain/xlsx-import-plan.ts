/* ================================================================
 * FALCO-OS v16.13 — Piano import XLSX «formato SETI» (W11)
 *
 * Confronta il workbook parsato (xlsx-parser) con lo stato attuale
 * dell'impianto e produce un piano CON PREVIEW (nessuna scrittura):
 *   · sezioni → sedi esistenti (match fuzzy con confidenza) o CREATE;
 *   · dispositivi → UPDATE (match per IP) o CREATE;
 *   · collegamenti radio → derivati dai gruppi SSID
 *     (un PTP/AP «master» ↔ le sue stazioni: la direzione è
 *     source=upstream come nel grafo reale);
 *   · basestation fuori inventario → proposta DISPOSITIVO SINTETICO
 *     (mai pre-confermato: l'operatore decide).
 *
 * Il piano è PURO: la rotta apply RI-PARSA il file e RI-DERIVA tutto
 * lato server (il client non decide nulla, come l'import KMZ).
 * ================================================================ */

import type { XlsxDeviceRow, XlsxSection, XlsxWorkbookSummary } from './xlsx-parser'

/* ---------------- tipi del piano ---------------- */

export type PlanConfidence = 'ALTA' | 'MEDIA' | 'BASSA'

export interface PlanDeviceAction {
  ip: string
  name: string
  type: string
  ssid: string
  isPtp: boolean
  hasPassword: boolean
  serial: string
  /** CREATE = nuovo apparato · UPDATE = esiste già (match IP) */
  action: 'CREATE' | 'UPDATE'
  deviceId: string | null
  existingHostname: string | null
  hostnameChanged: boolean
}

export interface PlanSection {
  sectionIndex: number
  sectionName: string
  /** CREATE = nuova sede · MAP = sede esistente confermata */
  action: 'CREATE' | 'MAP'
  locationId: string | null
  locationName: string | null
  confidence: PlanConfidence | null
  reason: string
  devices: PlanDeviceAction[]
}

export interface PlanLink {
  ssid: string
  sourceIp: string
  sourceName: string
  sourceSection: string
  targetIp: string
  targetName: string
  targetSection: string
  /** etichetta del link (default: l'SSID) */
  label: string
  frequency: string
  basis: string
  confidence: PlanConfidence
}

/** Basestation fuori inventario: proposta di apparato sintetico. */
export interface PlanSynthetic {
  name: string
  ssid: string
  /** sede candidata per la basestation (match dal nome SSID) */
  locationId: string | null
  locationName: string | null
  locationBasis: string
  stations: Array<{ ip: string; name: string; section: string }>
}

export interface XlsxImportPlan {
  sections: PlanSection[]
  links: PlanLink[]
  synthetic: PlanSynthetic[]
  /** SSID con un solo apparato: nessun link derivabile (trasparenza) */
  lonelySsids: Array<{ ssid: string; ip: string; name: string }>
  /** dispositivi del DB fuori dall'Excel (restano dove sono) */
  unmatchedExisting: Array<{ deviceId: string; ip: string; hostname: string; locationName: string | null }>
  /** collegamenti auto-scoperti che la apply può eliminare (opt-in) */
  autoLinkCount: number
  stats: {
    devicesCreate: number
    devicesUpdate: number
    locationsCreate: number
    locationsMap: number
    links: number
    synthetic: number
  }
}

export interface PlanLocationRow {
  id: string
  name: string
  identifier: string
}

export interface PlanDeviceRow {
  id: string
  ip: string
  hostname: string
  type: string
  ssid: string
  locationId: string | null
}

export interface PlanXlsxOptions {
  /** sectionIndex → locationId: correzione manuale dell'operatore */
  manualLocationMap?: Record<number, string>
}

/* ---------------- normalizzazione nomi sedi ---------------- */

const STOPWORDS = new Set(['via', 'old'])

function normalizeName(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
}

function squashName(s: string): string {
  return normalizeName(s).replace(/\s+/g, '')
}

function significantTokens(s: string): string[] {
  return normalizeName(s)
    .split(/\s+/)
    .filter((t) => {
      if (STOPWORDS.has(t)) return false
      // i codici sede sono significativi: PA6 ≠ PA7, P1 ≠ P10
      if (/^\d{1,3}$/.test(t)) return true
      return t.length >= 2
    })
}

export interface LocationMatch {
  location: PlanLocationRow
  confidence: PlanConfidence
  reason: string
}

/**
 * Match fuzzy sezione-Excel ↔ sede-esistente. Scoring calibrato sui
 * nomi REALI degli impianti SETI:
 *   · 0.95 squash-exact («OLD Via PEPE» = «OLD Via PEPE»);
 *   · coverage: quanta parte della sezione la sede SPIEGA
 *     («OLD Parcheggio Pulcinella (Atro Palo Difronte)» → «Parcheggio
 *     Pulcinella Altro Palo Difronte» 4/5 token, BATTE «OLD Parcheggio
 *     Pulcinella» 2/5 pur essendo sottoinsieme perfetto);
 *   · 0.8 squash-prefix («RIP1» ⊂ «RIP 1 Via Mazzini»);
 *   · 0.65 prefisso di token ≥ 3 («P.A 7 Via Giacomo Leopardi 2 tlc»
 *     ↔ «P.A 7 Via Giovanni Falcone»: stesso codice PA7, strada
 *     corretta a mano dall'operatore nel KMZ);
 *   · 0.55 sovrapposizione token (rimborso).
 * Pareggio fra due sedi = ambiguità: CREATE con motivo esplicito.
 */
export function matchLocation(
  sectionName: string,
  locations: PlanLocationRow[],
): LocationMatch | null {
  const sq = squashName(sectionName)
  const secSig = significantTokens(sectionName)
  const secTokens = normalizeName(sectionName).split(/\s+/).filter(Boolean)
  const secTokenSet = new Set(secTokens)

  let best: { loc: PlanLocationRow; score: number; reason: string } | null = null
  let tie = false

  for (const loc of locations) {
    const locSq = squashName(loc.name)
    const locSig = significantTokens(loc.name)
    const locTokens = normalizeName(loc.name).split(/\s+/).filter(Boolean)
    let score = 0
    let reason = ''

    // tutte le strategie vengono valutate e vince la migliore: un gate
    // «score===0» avrebbe nascosto il prefisso di token quando la
    // coverage dà già un punteggio basso (caso reale «P.A.1 Campo
    // Sportivo» ↔ «P:A.1 Stadio»: coverage 0.59, prefisso [p a 1] 0.65)
    const candidates: Array<{ score: number; reason: string }> = []

    if (sq === locSq) {
      candidates.push({ score: 0.95, reason: 'nome identico (normalizzato)' })
    }

    if (secSig.length > 0 && locSig.length > 0) {
      // coverage: token della sezione spiegati dalla sede + token della
      // sede presenti nella sezione (bilancia: la sede non deve avere
      // troppi token «extra» che la sezione non ha)
      const locSet = new Set(locSig)
      const common = secSig.filter((t) => locSet.has(t))
      const coverage = common.length / secSig.length
      const locCoverage = common.length / locSig.length
      if (common.length > 0) {
        candidates.push({
          score: Math.min(0.9, 0.35 + 0.5 * coverage + 0.15 * locCoverage),
          reason: `token condivisi ${common.length}/${secSig.length} della sezione (${common.join(' ')})`,
        })
      }
    }

    if (sq.length >= 4 && locSq.length >= 4) {
      const shorter = sq.length <= locSq.length ? sq : locSq
      const longer = sq.length <= locSq.length ? locSq : sq
      if (longer.startsWith(shorter)) {
        candidates.push({
          score: 0.8,
          reason: 'nome compresso prefisso (es. «RIP1» ⊂ «RIP 1 Via Mazzini»)',
        })
      }
    }

    if (secTokens.length >= 3 && locTokens.length >= 3) {
      const n = Math.min(secTokens.length, locTokens.length)
      let equal = 0
      for (let i = 0; i < n; i++) {
        if (secTokens[i] === locTokens[i]) equal += 1
        else break
      }
      if (equal >= 3) {
        candidates.push({
          score: 0.65,
          reason: `primi ${equal} token identici (${secTokens.slice(0, equal).join(' ')})`,
        })
      }
    }

    if (secTokenSet.size >= 3 && locTokens.length >= 2) {
      const common = locTokens.filter((t) => secTokenSet.has(t))
      const union = new Set([...secTokens, ...locTokens]).size
      if (common.length >= 3 && common.length / union >= 0.5) {
        candidates.push({
          score: 0.55,
          reason: `sovrappongono ${common.length} token su ${union}`,
        })
      }
    }

    for (const c of candidates) {
      if (c.score > score) {
        score = c.score
        reason = c.reason
      }
    }

    if (score > 0) {
      if (best && score === best.score) {
        tie = true
      } else if (!best || score > best.score) {
        best = { loc, score, reason }
        tie = false
      }
    }
  }

  if (!best || tie || best.score < 0.6) {
    return null
  }
  const confidence: PlanConfidence = best.score >= 0.85 ? 'ALTA' : best.score >= 0.7 ? 'MEDIA' : 'BASSA'
  return { location: best.loc, confidence, reason: best.reason }
}

/* ---------------- derivazione link dai gruppi SSID ---------------- */

function isMasterDevice(d: XlsxDeviceRow): boolean {
  return /^ptp\b/i.test(d.name) || (d.type === 'AP' && !/^st\b/i.test(d.name))
}

interface DeviceWithSection {
  dev: XlsxDeviceRow
  section: XlsxSection
}

/**
 * Deriva i collegamenti radio dai gruppi SSID: in ogni gruppo un
 * apparato «master» (PTP/AP) è l'estremo upstream e le stazioni sono
 * i downstream. Un gruppo di sole stazioni produce una PROPOSTA di
 * basestation sintetica (mai un link inventato).
 */
export function deriveSsidLinks(
  sections: XlsxSection[],
): { links: PlanLink[]; synthetic: PlanSynthetic[]; lonely: Array<{ ssid: string; ip: string; name: string }> } {
  const all: DeviceWithSection[] = []
  for (const section of sections) {
    for (const dev of section.devices) {
      if (dev.ssid) all.push({ dev, section })
    }
  }

  const groups = new Map<string, DeviceWithSection[]>()
  for (const item of all) {
    const arr = groups.get(item.dev.ssid) ?? []
    arr.push(item)
    groups.set(item.dev.ssid, arr)
  }

  const links: PlanLink[] = []
  const synthetic: PlanSynthetic[] = []
  const lonely: Array<{ ssid: string; ip: string; name: string }> = []

  for (const [ssid, items] of groups) {
    const masters = items.filter((i) => isMasterDevice(i.dev))
    const stations = items.filter((i) => !isMasterDevice(i.dev))

    if (masters.length >= 1 && stations.length >= 1) {
      for (const m of masters) {
        for (const s of stations) {
          const freq = /60\s*ghz/i.test(m.dev.name) || /60\s*ghz/i.test(s.dev.name) ? '60 GHz' : ''
          links.push({
            ssid,
            sourceIp: m.dev.ip,
            sourceName: m.dev.name,
            sourceSection: m.section.name,
            targetIp: s.dev.ip,
            targetName: s.dev.name,
            targetSection: s.section.name,
            label: ssid,
            frequency: freq,
            basis: `SSID «${ssid}»: ${m.dev.name} (PTP/AP) ↔ ${s.dev.name} (stazione)`,
            confidence: 'ALTA',
          })
        }
      }
    } else if (stations.length >= 2 && masters.length === 0) {
      // gruppo di sole stazioni: basestation fuori inventario
      synthetic.push({
        name: `Basestation ${ssid}`,
        ssid,
        locationId: null,
        locationName: null,
        locationBasis: 'da abbinare a una sede (proposta non automatica)',
        stations: stations.map((s) => ({ ip: s.dev.ip, name: s.dev.name, section: s.section.name })),
      })
    } else if (items.length === 1) {
      lonely.push({ ssid, ip: items[0].dev.ip, name: items[0].dev.name })
    }
  }

  return { links, synthetic, lonely }
}

/**
 * Abbina una proposta sintetica a una sede candidata cercando i token
 * del nome SSID nel nome delle sedi (es. LINK_STADIO_BASESTATION →
 * «RIP Stadio»). Preferisce le sedi RIP (ripetitori) quando ci sono.
 */
export function attachSyntheticToLocations(
  synthetic: PlanSynthetic[],
  locations: PlanLocationRow[],
): void {
  const FILLER = new Set(['link', 'basestation', 'base', 'station', 'network', 'rete'])
  for (const syn of synthetic) {
    const tokens = normalizeName(syn.ssid.replace(/_/g, ' '))
      .split(/\s+/)
      .filter((t) => t.length >= 4 && !FILLER.has(t))
    const candidates: Array<{ loc: PlanLocationRow; score: number }> = []
    for (const loc of locations) {
      const locSq = squashName(loc.name)
      for (const token of tokens) {
        if (locSq.includes(token)) {
          const isRip = /^rip\b/i.test(loc.name)
          candidates.push({ loc, score: isRip ? 2 : 1 })
          break
        }
      }
    }
    if (candidates.length > 0) {
      candidates.sort((a, b) => b.score - a.score)
      const top = candidates[0]
      syn.locationId = top.loc.id
      syn.locationName = top.loc.name
      syn.locationBasis = `token «${tokens.join(' ')}» nel nome della sede${top.score >= 2 ? ' (preferita: ripetitore RIP)' : ''}`
    }
  }
}

/* ---------------- piano completo ---------------- */

/**
 * Costruisce il piano di import: NESSUNA scrittura, solo decisioni
 * e motivi leggibili per la preview.
 */
export function planXlsxImport(
  summary: XlsxWorkbookSummary,
  locations: PlanLocationRow[],
  devices: PlanDeviceRow[],
  autoLinkCount = 0,
  options: PlanXlsxOptions = {},
): XlsxImportPlan {
  const devicesByIp = new Map(devices.map((d) => [d.ip, d]))
  const locationsById = new Map(locations.map((l) => [l.id, l]))
  const manual = options.manualLocationMap ?? {}
  const usedLocationIds = new Set<string>()

  const planSections: PlanSection[] = []
  let devicesCreate = 0
  let devicesUpdate = 0
  let locationsCreate = 0
  let locationsMap = 0

  for (const section of summary.sections) {
    // mappa manuale dell'operatore → vince sempre
    const manualId = manual[section.index]
    let action: 'CREATE' | 'MAP' = 'CREATE'
    let locationId: string | null = null
    let locationName: string | null = null
    let confidence: PlanConfidence | null = null
    let reason = ''

    if (manualId) {
      const loc = locationsById.get(manualId)
      if (loc) {
        action = 'MAP'
        locationId = loc.id
        locationName = loc.name
        confidence = 'ALTA'
        reason = 'abbinamento scelto dall\'operatore'
      }
    }

    if (!locationId) {
      const match = matchLocation(section.name, locations)
      if (match && !usedLocationIds.has(match.location.id)) {
        action = 'MAP'
        locationId = match.location.id
        locationName = match.location.name
        confidence = match.confidence
        reason = match.reason
      } else if (match && usedLocationIds.has(match.location.id)) {
        // la sede è già stata usata da un'altra sezione: CREATE separato
        action = 'CREATE'
        reason = `match con «${match.location.name}» già impegnato da un'altra sezione → sede separata`
      } else {
        action = 'CREATE'
        reason = 'nessuna sede esistente corrisponde al nome della sezione'
      }
    }

    if (action === 'MAP' && locationId) usedLocationIds.add(locationId)
    if (action === 'CREATE') locationsCreate += 1
    else locationsMap += 1

    const planDevices: PlanDeviceAction[] = section.devices.map((dev) => {
      const existing = devicesByIp.get(dev.ip)
      if (existing) {
        devicesUpdate += 1
        return {
          ip: dev.ip,
          name: dev.name,
          type: dev.type,
          ssid: dev.ssid,
          isPtp: dev.isPtp,
          hasPassword: dev.password.length > 0,
          serial: dev.serial,
          action: 'UPDATE' as const,
          deviceId: existing.id,
          existingHostname: existing.hostname,
          hostnameChanged: existing.hostname !== dev.name,
        }
      }
      devicesCreate += 1
      return {
        ip: dev.ip,
        name: dev.name,
        type: dev.type,
        ssid: dev.ssid,
        isPtp: dev.isPtp,
        hasPassword: dev.password.length > 0,
        serial: dev.serial,
        action: 'CREATE' as const,
        deviceId: null,
        existingHostname: null,
        hostnameChanged: false,
      }
    })

    planSections.push({
      sectionIndex: section.index,
      sectionName: section.name,
      action,
      locationId,
      locationName,
      confidence,
      reason,
      devices: planDevices,
    })
  }

  const { links, synthetic, lonely } = deriveSsidLinks(summary.sections)
  attachSyntheticToLocations(synthetic, locations)

  const xlsxIps = new Set<string>()
  for (const section of summary.sections) {
    for (const dev of section.devices) xlsxIps.add(dev.ip)
  }
  const unmatchedExisting = devices
    .filter((d) => !xlsxIps.has(d.ip))
    .map((d) => ({
      deviceId: d.id,
      ip: d.ip,
      hostname: d.hostname,
      locationName: d.locationId ? locationsById.get(d.locationId)?.name ?? null : null,
    }))

  return {
    sections: planSections,
    links,
    synthetic,
    lonelySsids: lonely,
    unmatchedExisting,
    autoLinkCount,
    stats: {
      devicesCreate,
      devicesUpdate,
      locationsCreate,
      locationsMap,
      links: links.length,
      synthetic: synthetic.length,
    },
  }
}
