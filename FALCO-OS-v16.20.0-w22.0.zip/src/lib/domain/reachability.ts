/* ================================================================
 * FALCO-OS v16 — RAGGIUNGIBILITÀ / RCA (port dal backend v15.16.0)
 * Provenienza: src/lib/topology-reachability.ts:33-153 (repo v15.16.0)
 * Nucleo PURO (nessuna I/O): BFS multi-sorgente dai gateway sui soli
 * collegamenti ATTIVI (grafo NON diretto), percorso verso il gateway,
 * figli e discendenti (vittime a valle), componenti staccate.
 * Regola v16 §6.2 «percorso del problema»: dal gateway al primo punto
 * non raggiungibile SI usa questa logica (nessuna duplicazione in UI).
 * ================================================================ */

import { isLinkStatusActive } from './link-rules'

export interface ReachNode {
  id: string
  status: string
  type: string
}

export interface ReachLink {
  sourceDeviceId: string | null
  targetDeviceId: string | null
  linkStatus: string
}

export interface ReachabilityMap {
  adjacency: Map<string, string[]>
  gateways: string[]
  pathToGateway: Map<string, string[]>
  children: Map<string, string[]>
  downstream: Map<string, string[]>
  unreachable: string[]
}

export const GATEWAY_DEVICE_TYPES = ['GATEWAY', 'ROUTER']

export function computeReachability(nodes: ReachNode[], links: ReachLink[]): ReachabilityMap {
  const adjacency = new Map<string, string[]>()
  const seen = new Set<string>()

  const linkSeen = new Set<string>()
  for (const l of links) {
    if (!l.sourceDeviceId || !l.targetDeviceId) continue
    if (l.sourceDeviceId === l.targetDeviceId) continue
    if (!isLinkStatusActive(l.linkStatus)) continue
    const key = l.sourceDeviceId < l.targetDeviceId
      ? `${l.sourceDeviceId}|${l.targetDeviceId}`
      : `${l.targetDeviceId}|${l.sourceDeviceId}`
    if (linkSeen.has(key)) continue
    linkSeen.add(key)
    if (!adjacency.has(l.sourceDeviceId)) adjacency.set(l.sourceDeviceId, [])
    if (!adjacency.has(l.targetDeviceId)) adjacency.set(l.targetDeviceId, [])
    if (!seen.has(key)) {
      seen.add(key)
      adjacency.get(l.sourceDeviceId)!.push(l.targetDeviceId)
      adjacency.get(l.targetDeviceId)!.push(l.sourceDeviceId)
    }
  }

  const gateways = nodes.filter((n) => GATEWAY_DEVICE_TYPES.includes(n.type)).map((n) => n.id)

  const pathToGateway = new Map<string, string[]>()
  const children = new Map<string, string[]>()
  const visited = new Set<string>()

  const queue: string[] = [...gateways].sort()
  for (const g of gateways) {
    visited.add(g)
    pathToGateway.set(g, [g])
  }

  while (queue.length > 0) {
    const current = queue.shift() as string
    const neighbors = [...(adjacency.get(current) || [])].sort()
    for (const next of neighbors) {
      if (visited.has(next)) continue
      visited.add(next)
      const path = [...(pathToGateway.get(current) || []), next]
      pathToGateway.set(next, path)
      if (!children.has(current)) children.set(current, [])
      children.get(current)!.push(next)
      queue.push(next)
    }
  }

  const downstream = new Map<string, string[]>()
  for (const [parent, kids] of children) {
    for (const k of kids) {
      const acc = downstream.get(parent) || []
      acc.push(k)
      downstream.set(parent, acc)
    }
  }
  for (;;) {
    let dirty = false
    for (const [parent, kids] of children) {
      const acc = downstream.get(parent) || []
      for (const k of kids) {
        for (const gk of downstream.get(k) || []) {
          if (!acc.includes(gk)) {
            acc.push(gk)
            dirty = true
          }
        }
      }
      if (acc.length > 0) downstream.set(parent, acc)
    }
    if (!dirty) break
  }

  const reachableIds = new Set(pathToGateway.keys())
  const unreachable = nodes.map((n) => n.id).filter((id) => !reachableIds.has(id))

  return { adjacency, gateways, pathToGateway, children, downstream, unreachable }
}

export function getDownstreamIds(map: ReachabilityMap, rootDeviceId: string): string[] {
  return [...(map.downstream.get(rootDeviceId) || [])].sort()
}
