/* ================================================================
 * FALCO-OS v16 — Proxy verso il mini-service discovery (:3002)
 * File NON-route: helper riusato dalle rotte /api/v2/discovery/*.
 * Il servizio implementa i motori PORtati da v15.16.0 (scansione TCP,
 * sonda SNMP v1/v2c/v3, ONVIF, OUI IEEE 10.679 prefissi, sweep UDP
 * Ubiquiti/MNDP/WS-Discovery). Qui: auth a monte, timeout a valle,
 * busta {ok,asOf,mode,data} coerente col resto delle API v2.
 * Onestà: il servizio risponde con ciò che la rete dice DAVVERO
 * (timeout/vuoto = timeout/vuoto); questo proxy non altera MAI i
 * risultati, al massimo li incapsula.
 * ================================================================ */

import { NextResponse } from 'next/server'

/** Porta fissa del mini-service discovery (convenzione mini-services). */
export const DISCOVERY_PORT = 3002
const BASE = `http://127.0.0.1:${DISCOVERY_PORT}`

/** Timeout complessivo di proxy: un filo sopra la guardia interna
 * del servizio (~15 s) per far arrivare il suo errore onesto. */
const PROXY_TIMEOUT_MS = 20_000

export interface ProxyResult {
  ok: boolean
  status: number
  body: unknown
}

/** POST generico verso il servizio discovery. Ritorna SEMPRE un
 * risultato strutturato (mai eccezione): servizio spento → 503
 * SERVICE_DOWN con messaggio operativo in italiano.
 * v16.15 W14 — `opts.timeoutMs` sovrascrive il default 20 s per le
 * rotte con deadline interna LUNGA (batch L2 multi-switch: il servizio
 * lavora fino a 300 s dichiarati); il default resta corto perché un
 * proxy che attende 5 minuti su una sonda singola è un bug, non una
 * feature. */
export async function discoveryPost(
  path: string,
  payload: unknown,
  opts?: { timeoutMs?: number },
): Promise<ProxyResult> {
  let res: Response
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), opts?.timeoutMs ?? PROXY_TIMEOUT_MS)
  try {
    res = await fetch(`${BASE}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: ctrl.signal,
      cache: 'no-store',
    })
  } catch (e) {
    const aborted = e instanceof Error && e.name === 'AbortError'
    return {
      ok: false,
      status: aborted ? 504 : 503,
      body: {
        ok: false,
        error: {
          code: aborted ? 'PROXY_TIMEOUT' : 'SERVICE_DOWN',
          message: aborted
            ? 'Il servizio discovery non ha risposto in tempo (timeout proxy)'
            : 'Servizio discovery non raggiungibile (porta 3002): verificarne l\'avvio',
        },
      },
    }
  } finally {
    clearTimeout(timer)
  }

  let body: unknown = null
  try {
    body = await res.json()
  } catch {
    body = null
  }
  return { ok: res.ok && body != null, status: res.status, body }
}

/** GET generico (usato da /health e /oui). Stesse garanzie del POST. */
export async function discoveryGet(path: string): Promise<ProxyResult> {
  let res: Response
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), PROXY_TIMEOUT_MS)
  try {
    res = await fetch(`${BASE}${path}`, { cache: 'no-store', signal: ctrl.signal })
  } catch (e) {
    const aborted = e instanceof Error && e.name === 'AbortError'
    return {
      ok: false,
      status: aborted ? 504 : 503,
      body: {
        ok: false,
        error: {
          code: aborted ? 'PROXY_TIMEOUT' : 'SERVICE_DOWN',
          message: aborted
            ? 'Il servizio discovery non ha risposto in tempo (timeout proxy)'
            : 'Servizio discovery non raggiungibile (porta 3002): verificarne l\'avvio',
        },
      },
    }
  } finally {
    clearTimeout(timer)
  }

  let body: unknown = null
  try {
    body = await res.json()
  } catch {
    body = null
  }
  return { ok: res.ok && body != null, status: res.status, body }
}

/** Incapsula la risposta del servizio nella busta v2. Il payload del
 * servizio è già validato dai suoi contratti interni (zod a monte nel
 * caller); qui si copre solo il caso servizio-ko. */
export function proxyFail(pr: ProxyResult): NextResponse {
  const b = pr.body as { error?: { code?: string; message?: string } } | null
  return NextResponse.json(
    {
      ok: false as const,
      error: {
        code: b?.error?.code ?? 'DISCOVERY_ERROR',
        message: b?.error?.message ?? `Il servizio discovery ha risposto ${pr.status}`,
      },
    },
    { status: pr.status >= 400 && pr.status <= 599 ? pr.status : 502 },
  )
}
