/* ================================================================
 * FALCO-OS v16 — Catena audit a prova di manomissione (W6)
 * ================================================================
 * PORTA FEDELE da v15.16.0 (src/lib/audit-chain.ts, v12.1.0 V12-F):
 * il sorgente originale è stato recuperato dallo ZIP superstite
 * upload/folder/7da6efe5/FALCO-OS-v15.16.0.zip dopo l'incidente #3
 * e la formula è stata ricavata DAL CODICE ORIGINALE (non reinventata).
 *
 * Contratto dell'hash (PUBBLICO, mai cambiare):
 *   canonical(record) = JSON.stringify([
 *     1,                       // AUDIT_CHAIN_VERSION
 *     record.id,
 *     record.createdAt.toISOString(),
 *     record.action,
 *     record.actor,
 *     record.targetId ?? '',
 *     record.targetLabel ?? '',
 *     record.plantId ?? '',
 *     sha256(record.details),  // details doppiamente hashati
 *   ])
 *   recordHash = SHA256(`${prevHash}|${canonical}`)
 * La catena concatena: prevHash parte dal sigillo precedente (o dalla
 * GENESI = SHA256('FALCO-OS-AUDIT-CHAIN-GENESIS-v1')).
 *
 * Il DB reale egidio ha 47.348 righe GIÀ sigillate dal sealer v15
 * (sigilli SYSTEM del 27/10): il sealer v16 CONTINUA quella catena
 * (startHash = lastSeal.lastHash) e il verificatore la valida PER
 * INTERO — parità reale, non una catena nuova.
 *
 * Sigillo (sealUnsealedAuditRecords, fedele a v15):
 *   · batch = righe con chainSeq=null (createdAt asc, id asc) fino a
 *     maxBatch 5.000 + la voce AUDIT_SEAL_CREATE stessa (creata PRIMA,
 *     in coda al batch — ordine deterministico);
 *   · UNA transazione: update delle righe + AuditSeal {lastSeq,
 *     lastRecordId, lastHash, recordCount, prevSealId, sealedBy};
 *   · se non c'è nulla da sigillare → skipped (422 NOTHING_TO_SEAL
 *     nella route).
 * Verifica (verifyAuditTrailOnDb, fedele a v15): per ogni sigillo
 * conta il range, ricalcola la catena hash-per-hash, controlla
 * lastRecordId/lastHash/recordCount e la spina prevSealId; gli
 * orfani (chainSeq oltre l'ultimo sigillo) sono rotture.
 * ================================================================ */

import { createHash } from 'crypto'
import type { PrismaClient } from '@prisma/client'

export const AUDIT_CHAIN_VERSION = 1
export const AUDIT_CHAIN_GENESIS = sha256hex('FALCO-OS-AUDIT-CHAIN-GENESIS-v1')
export const AUDIT_SEAL_MAX_BATCH = 5_000

export function sha256hex(input: string): string {
  return createHash('sha256').update(input, 'utf8').digest('hex')
}

/* ---------------- Canonical + hash record (v15 byte a byte) ---------------- */

export interface ChainableAuditRecord {
  id: string
  createdAt: Date | string
  action: string
  actor: string
  targetId?: string | null
  targetLabel?: string | null
  plantId?: string | null
  details: string
}

function iso(value: Date | string): string {
  const d = typeof value === 'string' ? new Date(value) : value
  return d.toISOString()
}

/** Serializzazione canonica: JSON di array (escaping garantito da
 * JSON.stringify → nessuna delimiter injection possibile). L'ordine
 * dei campi è fisso e fa parte del contratto dell'hash. */
export function canonicalAuditRecord(rec: ChainableAuditRecord): string {
  return JSON.stringify([
    AUDIT_CHAIN_VERSION,
    rec.id,
    iso(rec.createdAt),
    rec.action,
    rec.actor,
    rec.targetId ?? '',
    rec.targetLabel ?? '',
    rec.plantId ?? '',
    sha256hex(rec.details),
  ])
}

/** hash del record = SHA256(prevHash | canonical). Il prev concatena → catena. */
export function computeRecordHash(prevHash: string, canonical: string): string {
  return sha256hex(`${prevHash}|${canonical}`)
}

export interface ChainStep {
  seq: number
  id: string
  hash: string
}

export interface ChainBuildResult {
  steps: ChainStep[]
  lastHash: string
}

/** Costruisce la catena di `records` partendo da startHash/startSeq.
 * Pura: nessun IO, deterministica, nessun ordine implicito (l'ordine
 * dell'array È l'ordine della catena — a DB è ORDER BY createdAt, id). */
export function buildChain(records: ChainableAuditRecord[], startHash: string, startSeq = 0): ChainBuildResult {
  let prev = startHash
  let seq = startSeq
  const steps: ChainStep[] = []
  for (const rec of records) {
    seq += 1
    const hash = computeRecordHash(prev, canonicalAuditRecord(rec))
    steps.push({ seq, id: rec.id, hash })
    prev = hash
  }
  return { steps, lastHash: prev }
}

/* ---------------- Sealer (fedele v15, update a blocchi) ---------------- */

export interface SealOutcome {
  sealId: string
  sealed: number          // righe sigillate (batch INCLUDING la voce self-audit)
  lastSeq: number
  lastHash: string
  skipped: boolean
  remainingUnsealed: number
}

const CHUNK = 800
const CUID_RE = /^[a-zA-Z0-9_-]{5,64}$/
function esc(v: string): string {
  if (!CUID_RE.test(v)) throw new Error(`VALORE_NON_SICURO_SQL: ${v.slice(0, 20)}`)
  return v
}

export async function sealUnsealedAuditRecords(
  dbx: PrismaClient,
  opts: { sealedBy?: string; trigger?: string; maxBatch?: number } = {},
): Promise<SealOutcome> {
  const sealedBy = opts.sealedBy ?? 'SYSTEM'
  const trigger = opts.trigger ?? 'api'
  const maxBatch = Math.min(opts.maxBatch ?? AUDIT_SEAL_MAX_BATCH, AUDIT_SEAL_MAX_BATCH)

  const lastSeal = await dbx.auditSeal.findFirst({ orderBy: { lastSeq: 'desc' } })
  const startSeq = lastSeal?.lastSeq ?? 0
  const startHash = lastSeal?.lastHash ?? AUDIT_CHAIN_GENESIS

  const pending = await dbx.auditLog.findMany({
    where: { chainSeq: null },
    orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
    take: maxBatch,
    select: {
      id: true, createdAt: true, action: true, actor: true,
      targetId: true, targetLabel: true, plantId: true, details: true,
    },
  })

  if (pending.length === 0) {
    const remainingUnsealed = await dbx.auditLog.count({ where: { chainSeq: null } })
    return { sealId: '', sealed: 0, lastSeq: startSeq, lastHash: startHash, skipped: true, remainingUnsealed }
  }

  /* traccia del sigillo: scritta e POSIZIONATA in coda al batch
   * (createdAt = now ≥ massimo dei pending) → ordine deterministico.
   * (stessa semantica v15: la voce entra nella catena che la crea) */
  const selfAudit = await dbx.auditLog.create({
    data: {
      action: 'AUDIT_SEAL_CREATE',
      actor: sealedBy,
      details: JSON.stringify({ trigger, pending: pending.length }),
    },
  })
  const batch: ChainableAuditRecord[] = [
    ...pending,
    {
      id: selfAudit.id,
      createdAt: selfAudit.createdAt,
      action: selfAudit.action,
      actor: selfAudit.actor,
      targetId: selfAudit.targetId,
      targetLabel: selfAudit.targetLabel,
      plantId: selfAudit.plantId,
      details: selfAudit.details,
    },
  ]

  const { steps, lastHash } = buildChain(batch, startHash, startSeq)
  const lastStep = steps[steps.length - 1]

  const sealId = await dbx.$transaction(async (tx) => {
    /* update a BLOCCHI con CASE (stesso risultato degli update per riga
     * di v15, un order of magnitude più rapido su batch grandi). */
    for (let c = 0; c < batch.length; c += CHUNK) {
      const chunkSteps = steps.slice(c, c + CHUNK)
      const seqCase = chunkSteps.map((p) => `WHEN '${esc(p.id)}' THEN ${p.seq}`).join(' ')
      const hashCase = chunkSteps.map((p) => `WHEN '${esc(p.id)}' THEN '${p.hash}'`).join(' ')
      const ids = chunkSteps.map((p) => `'${esc(p.id)}'`).join(', ')
      await tx.$executeRawUnsafe(
        `UPDATE "AuditLog" SET "chainSeq" = CASE "id" ${seqCase} END, "recordHash" = CASE "id" ${hashCase} END WHERE "id" IN (${ids})`,
      )
    }
    const seal = await tx.auditSeal.create({
      data: {
        lastSeq: lastStep.seq,
        lastRecordId: lastStep.id,
        lastHash,
        recordCount: batch.length,
        prevSealId: lastSeal?.id ?? null,
        sealedBy,
      },
    })
    return seal.id
  })

  const remainingUnsealed = await dbx.auditLog.count({ where: { chainSeq: null } })
  return { sealId, sealed: batch.length, lastSeq: lastStep.seq, lastHash, skipped: false, remainingUnsealed }
}

/* ---------------- Verificatore (fedele v15) ---------------- */

export interface AuditBreakage {
  sealId?: string
  recordId?: string
  seq?: number
  reason: string
  expected?: string
  actual?: string
}

export interface AuditVerificationReport {
  ok: boolean
  genesisHash: string
  sealsTotal: number
  sealsVerified: number
  recordsSealed: number
  recordsVerified: number
  unsealedCount: number
  breakages: AuditBreakage[]
  durationMs: number
}

type SealedRow = {
  id: string
  createdAt: Date
  action: string
  actor: string
  targetId: string | null
  targetLabel: string | null
  plantId: string | null
  details: string
  chainSeq: number | null
  recordHash: string | null
}

export async function verifyAuditTrailOnDb(dbx: PrismaClient): Promise<AuditVerificationReport> {
  const t0 = Date.now()
  const seals = await dbx.auditSeal.findMany({ orderBy: { lastSeq: 'asc' } })
  const unsealedCount = await dbx.auditLog.count({ where: { chainSeq: null } })

  const breakages: AuditBreakage[] = []
  let prevHash = AUDIT_CHAIN_GENESIS
  let prevSealId: string | null = null
  let prevLastSeq = 0
  let recordsVerified = 0
  let sealsVerified = 0
  let recordsSealed = 0

  for (const seal of seals) {
    if (seal.prevSealId !== null && seal.prevSealId !== prevSealId) {
      breakages.push({ sealId: seal.id, reason: 'SEAL_CHAIN_BROKEN', expected: prevSealId ?? '', actual: seal.prevSealId })
    }

    const expectedCount = seal.lastSeq - prevLastSeq
    const actualCount = await dbx.auditLog.count({
      where: { chainSeq: { gt: prevLastSeq, lte: seal.lastSeq } },
    })
    if (actualCount !== seal.recordCount || seal.recordCount !== expectedCount) {
      breakages.push({
        sealId: seal.id, reason: 'MISSING_RECORD',
        expected: `${expectedCount} attesi (dichiarati ${seal.recordCount})`, actual: `${actualCount} presenti`,
      })
    }
    recordsSealed += actualCount

    if (actualCount === expectedCount && seal.recordCount === expectedCount) {
      const range = await dbx.auditLog.findMany({
        where: { chainSeq: { gt: prevLastSeq, lte: seal.lastSeq } },
        orderBy: { chainSeq: 'asc' },
        select: {
          id: true, createdAt: true, action: true, actor: true,
          targetId: true, targetLabel: true, plantId: true, details: true,
          chainSeq: true, recordHash: true,
        },
      })
      let lastIdSeen: string | null = null
      let rangeHash = prevHash
      for (const r of range as SealedRow[]) {
        if (typeof r.recordHash !== 'string' || r.recordHash.length === 0) {
          breakages.push({ sealId: seal.id, recordId: r.id, seq: r.chainSeq ?? undefined, reason: 'RECORD_HASH_MISSING' })
          continue
        }
        const computed = computeRecordHash(rangeHash, canonicalAuditRecord(r))
        if (computed !== r.recordHash) {
          breakages.push({
            sealId: seal.id, recordId: r.id, seq: r.chainSeq ?? undefined,
            reason: 'RECORD_HASH_MISMATCH', expected: computed, actual: r.recordHash,
          })
          rangeHash = r.recordHash
        } else {
          rangeHash = computed
        }
        recordsVerified += 1
        lastIdSeen = r.id
      }
      if (lastIdSeen !== null && lastIdSeen !== seal.lastRecordId) {
        breakages.push({ sealId: seal.id, reason: 'LAST_RECORD_MISMATCH', expected: seal.lastRecordId, actual: lastIdSeen })
      }
      if (rangeHash !== seal.lastHash) {
        breakages.push({ sealId: seal.id, reason: 'SEAL_HASH_MISMATCH', expected: seal.lastHash, actual: rangeHash })
      } else {
        sealsVerified += 1
      }
      prevHash = rangeHash
    } else {
      // range compromesso: si prosegue dalla hash dichiarata per verificare
      // comunque i sigilli successivi (diagnostica completa, non stop alla prima)
      prevHash = seal.lastHash
    }

    prevSealId = seal.id
    prevLastSeq = seal.lastSeq
  }

  // orfani: seq oltre l'ultimo sigillo ma già hashati
  const lastSeq = seals.length > 0 ? seals[seals.length - 1].lastSeq : 0
  const orphans = await dbx.auditLog.findMany({
    where: { chainSeq: { gt: lastSeq } },
    select: { id: true, chainSeq: true },
    take: 100,
  })
  for (const o of orphans) {
    breakages.push({ recordId: o.id, seq: o.chainSeq ?? undefined, reason: 'ORPHAN_SEALED_RECORD' })
  }

  return {
    ok: breakages.length === 0,
    genesisHash: AUDIT_CHAIN_GENESIS,
    sealsTotal: seals.length,
    sealsVerified,
    recordsSealed,
    recordsVerified,
    unsealedCount,
    breakages,
    durationMs: Date.now() - t0,
  }
}

/* ---------------- Export certificato (v15, CSV RFC 4180) ---------------- */

export const CSV_COLUMNS = [
  'chainSeq', 'createdAt', 'action', 'actor', 'targetId', 'targetLabel', 'plantId', 'recordHash', 'details',
] as const

function csvEscape(v: string): string {
  if (/[",\r\n]/.test(v)) return `"${v.replace(/"/g, '""')}"`
  return v
}

/** CSV deterministico (RFC 4180, UTF-8 senza BOM, CRLF) — v15 byte a byte. */
export function buildAuditExportCsv(records: SealedRow[]): string {
  const lines: string[] = [CSV_COLUMNS.join(',')]
  for (const r of records) {
    lines.push([
      r.chainSeq === null ? '' : String(r.chainSeq),
      iso(r.createdAt),
      csvEscape(r.action),
      csvEscape(r.actor),
      csvEscape(r.targetId ?? ''),
      csvEscape(r.targetLabel ?? ''),
      csvEscape(r.plantId ?? ''),
      r.recordHash ?? '',
      csvEscape(r.details),
    ].join(','))
  }
  return lines.join('\r\n') + '\r\n'
}

/** JSON deterministico: campi fissi, ordine record dato dal caller. */
export function buildAuditExportJson(records: SealedRow[], meta: { generatedAt: string; filterSummary: Record<string, unknown> }): string {
  return JSON.stringify({
    format: 'falco-os-audit-export',
    formatVersion: 1,
    chainVersion: AUDIT_CHAIN_VERSION,
    genesisHash: AUDIT_CHAIN_GENESIS,
    generatedAt: meta.generatedAt,
    filterSummary: meta.filterSummary,
    records: records.map((r) => ({
      chainSeq: r.chainSeq ?? null,
      createdAt: iso(r.createdAt),
      action: r.action,
      actor: r.actor,
      targetId: r.targetId ?? null,
      targetLabel: r.targetLabel ?? null,
      plantId: r.plantId ?? null,
      recordHash: r.recordHash ?? null,
      details: r.details,
    })),
  })
}

/** Digest della catena intera per il manifest (SHA-256 dei recordHash
 * sigillati in ordine di seq): utile sintesi certificativa in UI. */
export function computeChainDigest(rows: Array<{ recordHash: string | null }>): string | null {
  const hashes = rows.filter((r) => r.recordHash).map((r) => r.recordHash as string)
  if (!hashes.length) return null
  return createHash('sha256').update(hashes.join('\n'), 'utf8').digest('hex')
}
