/* ================================================================
 * FALCO-OS v16 — Derivazione dati (lette dal DB reale, zero invenzioni)
 * Regole oneste implementate qui (§2 del piano):
 *  · uiStatus: DB status (ONLINE/DEGRADED/…) + derivazioni documentate:
 *    NOT_MONITORED (nessuna schedule attiva) e UNKNOWN (dato assente o
 *    obsoleto oltre soglia) — MAI «offline» per mancanza di dato.
 *  · signalStrength 0 = «non letto» → signalPresent=false (convenzione
 *    onesta del sistema, vedi radio-metrics.ts:25).
 *  · Segreti: allowlist colonne — password, snmpCommunityEnc e
 *    passwordHash non vengono MAI selezionati (vedi DEVICE_COLUMNS).
 * ================================================================ */

import { db } from '@/lib/db'
import { isStale, statusReason, type UiStatus } from '@/lib/domain/status'
import { computeSignalScore, uplinkSignalDbm } from '@/lib/domain/radio'
import type { DeviceRow } from '@/lib/v2/contracts'

/* ---------------- Selezione colonne (allowlist, senza segreti) ---------------- */

export const DEVICE_COLUMNS = {
  id: true, ip: true, hostname: true, type: true, status: true, falcoState: true,
  disconnectedSince: true, outageSince: true, connectionType: true, lastSeenAt: true,
  uptimeSeconds: true, currentFrequency: true, currentChannel: true, radioMode: true,
  linkMode: true, currentChannelWidth: true, brand: true, model: true, antennaType: true,
  signalStrength: true, linkQuality: true, firmwareVersion: true, serialNumber: true,
  cpuLoad: true, ramTotal: true, ramUsed: true, ssid: true, macAddress: true,
  locationId: true, parentId: true, credentialState: true, lastAuthMethod: true,
  rtspStream: true, decommissionedAt: true, createdAt: true, updatedAt: true,
  // v16.18 W19 — attivazione SNMP assistita + modalità di monitoraggio
  snmpEnableState: true, snmpEnableMethod: true, snmpEnableNote: true,
  snmpEnableAt: true, monitorMode: true,
} as const

export interface PlantLite {
  id: string
  name: string
  comune: string
  pingIntervalSec: number
  mapCenterLat: number
  mapCenterLng: number
  mapZoom: number
  topologyRootDeviceId: string | null
  /** v16.19 W21: letti dalle rotte setup (adopt: conferma richiesta se
   * SENSIBILE; verify: CSV delle community dell'impianto). */
  criticalityLevel: string
  snmpCommunities: string
}

export async function getPlant(plantId?: string): Promise<PlantLite | null> {
  const where = plantId ? { id: plantId } : undefined
  return db.plant.findFirst({
    where,
    // 16.10: default DETERMINISTICO = il primo impianto CREATO (il più
    // vecchio): stabile — la creazione di nuovi impianti NON cambia il
    // default (con orderBy name un impianto nuovo «A…» se lo sarebbe
    // portato via silenziosamente, trovato in verifica). Il selettore
    // lato client usa la STESSA regola come fallback.
    orderBy: { createdAt: 'asc' },
    select: {
      id: true, name: true, comune: true, pingIntervalSec: true,
      mapCenterLat: true, mapCenterLng: true, mapZoom: true, topologyRootDeviceId: true,
      criticalityLevel: true, snmpCommunities: true,
    },
  })
}

export async function listPlants() {
  return db.plant.findMany({
    select: {
      id: true, name: true, comune: true, isActive: true,
      mapCenterLat: true, mapCenterLng: true, mapZoom: true,
      // 16.10: riga impianto completa per la gestione (CRUD + KMZ + root)
      address: true, notes: true, telegramChatId: true, kmzFile: true,
      pingIntervalSec: true, outageTimerMinutes: true, snmpCommunities: true,
      topologyRootDeviceId: true, createdAt: true,
    },
    orderBy: { name: 'asc' },
  })
}

/* ---------------- Stato monitorato ---------------- */

export interface MonitoredMap {
  byDevice: Map<string, { intervalSec: number }>
  enabledCount: number
}

export async function getMonitoredMap(plantId: string): Promise<MonitoredMap> {
  const schedules = await db.pollingSchedule.findMany({
    where: { plantId, enabled: true, deviceId: { not: null } },
    select: { deviceId: true, intervalSec: true, cadenceSec: true },
  })
  const byDevice = new Map<string, { intervalSec: number }>()
  for (const s of schedules) {
    if (!s.deviceId) continue
    const interval = s.cadenceSec && s.cadenceSec > 0 ? s.cadenceSec : s.intervalSec
    const cur = byDevice.get(s.deviceId)
    if (!cur || interval < cur.intervalSec) byDevice.set(s.deviceId, { intervalSec: interval })
  }
  return { byDevice, enabledCount: schedules.length }
}

/** Stato UI derivato (§7.1-7.2). Vigore: MAI OFFLINE per dato mancante. */
export function deriveUiStatus(d: {
  status: string
  monitored: boolean
  stale: boolean
}): UiStatus {
  if (!d.monitored) return 'NOT_MONITORED'
  if (d.stale) return 'UNKNOWN'
  const s = d.status?.toUpperCase?.()
  if (s === 'ONLINE' || s === 'DEGRADED' || s === 'OFFLINE' || s === 'MAINTENANCE' || s === 'UNKNOWN') return s
  return 'UNKNOWN'
}

/* ---------------- Riga dispositivo (DTO condiviso) ---------------- */

type DeviceRecord = {
  id: string; ip: string; hostname: string; type: string; status: string
  connectionType: string; lastSeenAt: Date | null; uptimeSeconds: number
  brand: string; model: string; antennaType: string; signalStrength: number
  linkQuality: number; radioMode: string; linkMode: string; currentFrequency: string
  ssid: string; macAddress: string; firmwareVersion: string; cpuLoad: number
  // v16.18 W20 — RAM live (KB): additivo, assente nei record storici
  ramTotal?: number
  ramUsed?: number
  locationId: string | null; location?: { name: string; lat: number | null; lng: number | null } | null
  // v16.18 W19 — additivi: assenti nei payload storici → '' / 'full'
  snmpEnableState?: string
  monitorMode?: string
}

export function toDeviceRow(d: DeviceRecord, ctx: {
  monitored: MonitoredMap
  plantId: string
  now: Date
}): DeviceRow {
  const mon = ctx.monitored.byDevice.get(d.id)
  const monitored = !!mon
  const stale = isStale(d.lastSeenAt, mon?.intervalSec ?? null, ctx.now)
  const uiStatus = deriveUiStatus({ status: d.status, monitored, stale })
  return {
    id: d.id,
    hostname: d.hostname || d.ip,
    ip: d.ip,
    type: d.type?.toUpperCase() || 'UNKNOWN',
    connectionType: d.connectionType || '',
    uiStatus,
    dbStatus: d.status || 'UNKNOWN',
    statusReason: statusReason({
      status: d.status, stale, lastSeenAt: d.lastSeenAt,
      signalStrength: d.signalStrength, linkQuality: d.linkQuality, cpuLoad: d.cpuLoad, monitored,
    }),
    brand: d.brand || '',
    model: d.model || '',
    antennaType: d.antennaType || '',
    signalStrength: d.signalStrength ?? 0,
    signalPresent: d.signalStrength !== 0,
    linkQuality: d.linkQuality ?? 0,
    radioMode: d.radioMode || '',
    linkMode: d.linkMode || '',
    currentFrequency: d.currentFrequency || '',
    ssid: d.ssid || '',
    macAddress: d.macAddress || '',
    firmwareVersion: d.firmwareVersion || '',
    uptimeSeconds: d.uptimeSeconds ?? 0,
    cpuLoad: d.cpuLoad ?? 0,
    // v16.18 W20 — RAM live (KB; 0 = mai letta: onesto, non «mezzo GB»)
    ramTotal: d.ramTotal ?? 0,
    ramUsed: d.ramUsed ?? 0,
    lastSeenAt: d.lastSeenAt ? d.lastSeenAt.getTime() : null,
    stale,
    monitored,
    locationId: d.locationId,
    locationName: d.location?.name ?? null,
    lat: d.location?.lat ?? null,
    lng: d.location?.lng ?? null,
    plantId: ctx.plantId,
    // v16.18 W19 — additivi (payload storici senza campi → default onesti)
    snmpEnableState: (d.snmpEnableState ?? '') as DeviceRow['snmpEnableState'],
    monitorMode: (d.monitorMode ?? 'full') as DeviceRow['monitorMode'],
  }
}

export async function loadDeviceRows(plantId: string): Promise<{ rows: DeviceRow[]; byId: Map<string, DeviceRow>; monitored: MonitoredMap; asOf: number; now: Date }> {
  // Scope v16.12 (W10) «impianti a se stanti»: ogni dispositivo ha un
  // plantId DIRETTO (proprietà esplicita, backfill W10: da sede, orfani
  // da AlertEvent). I 30 orfani (host scoperti) appartengono al loro
  // impianto e NON appaiono più negli altri: prima l'OR locationId:null
  // li mostrava in OGNI impianto — inaccettabile col multi-impianto reale.
  const [devices, monitored] = await Promise.all([
    db.device.findMany({
      where: { plantId, decommissionedAt: null },
      select: { ...DEVICE_COLUMNS, location: { select: { name: true, lat: true, lng: true } } },
      orderBy: { hostname: 'asc' },
    }),
    getMonitoredMap(plantId),
  ])
  const now = new Date()
  let asOf = 0
  const rows = devices.map((d) => {
    const row = toDeviceRow(d as unknown as DeviceRecord, { monitored, plantId, now })
    if (row.lastSeenAt && row.lastSeenAt > asOf) asOf = row.lastSeenAt
    return row
  })
  return { rows, byId: new Map(rows.map((r) => [r.id, r])), monitored, asOf: asOf || now.getTime(), now }
}

/* ---------------- Stato flusso telecamere (metrica reale) ---------------- */

export interface CameraStreamMap {
  byDevice: Map<string, { alive: boolean; at: number; rttMs: number | null }>
}

/** Ultimo campione cameraStreamAlive/cameraRtt per dispositivo (SQL finestra). */
export async function getCameraStreamMap(plantId: string): Promise<CameraStreamMap> {
  const rows = await db.$queryRaw<Array<{ deviceId: string; metric: string; value: number; timestamp: number }>>`
    SELECT deviceId, metric, value, timestamp FROM (
      SELECT deviceId, metric, value, timestamp,
             ROW_NUMBER() OVER (PARTITION BY deviceId, metric ORDER BY timestamp DESC) AS rn
      FROM MetricValue
      WHERE metric IN ('cameraStreamAlive', 'cameraRtt') AND plantId = ${plantId}
    ) WHERE rn = 1`
  const byDevice = new Map<string, { alive: boolean; at: number; rttMs: number | null }>()
  for (const r of rows) {
    const cur = byDevice.get(r.deviceId) ?? { alive: false, at: 0, rttMs: null }
    if (r.metric === 'cameraStreamAlive') {
      cur.alive = r.value === 1
      cur.at = Number(r.timestamp)
    } else {
      cur.rttMs = r.value
    }
    byDevice.set(r.deviceId, cur)
  }
  return { byDevice }
}

/* ---------------- Link wireless deboli (semantica uplink §1.4) ---------------- */

export interface WeakLinkRow {
  deviceId: string
  hostname: string
  ip: string
  type: string
  uiStatus: UiStatus
  signalDbm: number
  health: 'excellent' | 'good' | 'fair' | 'poor' | 'critical'
  score: number
  linkQuality: number
  frequency: string
  ssid: string
  uplinkApHostname: string | null
  locationName: string | null
  lastSeenAt: number | null
}

/** «Link più deboli»: per STA il segnale È il link di uplink; per AP
 *  la stazione più debole (se esposta). Solo valori presenti (mai 0). */
export function computeWeakLinks(rows: DeviceRow[], opts: {
  parentOf: Map<string, string>
  limit: number
}): WeakLinkRow[] {
  const byId = new Map(rows.map((r) => [r.id, r]))
  const out: WeakLinkRow[] = []
  for (const r of rows) {
    if (r.type !== 'STA' && r.type !== 'AP') continue
    const signal = uplinkSignalDbm({
      type: r.type,
      signalStrength: r.signalStrength,
      stationSignals: [], // stazioni per AP: derivate dal grafo in chiama se serve
    })
    if (signal == null) continue
    const parent = opts.parentOf.get(r.id)
    const parentRow = parent ? byId.get(parent) : undefined
    const hs = computeSignalScore(signal)
    out.push({
      deviceId: r.id,
      hostname: r.hostname,
      ip: r.ip,
      type: r.type,
      uiStatus: r.uiStatus,
      signalDbm: signal,
      health: hs.label,
      score: hs.score,
      linkQuality: r.linkQuality,
      frequency: r.currentFrequency,
      ssid: r.ssid,
      uplinkApHostname: parentRow?.hostname ?? null,
      locationName: r.locationName,
      lastSeenAt: r.lastSeenAt,
    })
  }
  out.sort((a, b) => a.signalDbm - b.signalDbm)
  return out.slice(0, opts.limit)
}

/** Per un AP: segnali delle stazioni figlie nel grafo (per aggregato). */
export function stationSignalsOf(ap: DeviceRow, rows: DeviceRow[], childrenOf: Map<string, string[]>): number[] {
  const kids = childrenOf.get(ap.id) ?? []
  const byId = new Map(rows.map((r) => [r.id, r]))
  return kids
    .map((id) => byId.get(id))
    .filter((k): k is DeviceRow => !!k && (k.type === 'STA' || k.type === 'CAMERA' || k.type === 'LPR'))
    .map((k) => k.signalStrength)
    .filter((s) => s !== 0)
}

/* ---------------- Modalità riproduzione (heartbeat del mini-service) ---------------- */

export interface ReplayState {
  enabled: boolean
  importedAt: number | null
  lastTickAt: number | null
  nextTickAt: number | null
  intervalSec: number
}

import { readFile } from 'fs/promises'
import { join } from 'path'

/** Percorsi del heartbeat in ordine di preferenza (v16.18.1, portabilità
 * Windows): env esplicito REALTIME_STATE_PATH (es. installazioni spostate
 * o standalone) oppure la posizione standard relativa alla root del
 * progetto (process.cwd() del dev server = root). In dev il secondo
 * coincide col vecchio path assoluto della sandbox. */
function realtimeStateCandidates(): string[] {
  const envPath = process.env.REALTIME_STATE_PATH
  return envPath
    ? [envPath]
    : [join(process.cwd(), 'mini-services', 'realtime-service', 'state.json')]
}

/** Heartbeat su file scritto dal mini-service realtime (porta 3001).
 *  replay attivo ⇔ file recente entro 2 intervalli. Onesto per costruzione. */
export async function getReplayState(): Promise<ReplayState> {
  for (const candidate of realtimeStateCandidates()) {
    try {
      const raw = await readFile(candidate, 'utf8')
      const s = JSON.parse(raw) as { importedAt?: number; lastTickAt?: number; nextTickAt?: number; intervalSec?: number }
      const intervalSec = s.intervalSec ?? 30
      const lastTickAt = s.lastTickAt ?? null
      const fresh = lastTickAt != null && Date.now() - lastTickAt < intervalSec * 2 * 1000
      return {
        enabled: fresh,
        importedAt: s.importedAt ?? null,
        lastTickAt,
        nextTickAt: s.nextTickAt ?? null,
        intervalSec,
      }
    } catch {
      /* candidato non leggibile: prova il prossimo (onesto: static) */
    }
  }
  return { enabled: false, importedAt: null, lastTickAt: null, nextTickAt: null, intervalSec: 30 }
}

export function apiMode(replay: ReplayState): 'replay' | 'static' {
  return replay.enabled ? 'replay' : 'static'
}

/* ---------------- Versione reale del build ---------------- */

// import STATICO del package.json: il require() dinamico con path ERRATO
// («../../../../package.json» puntava fuori progetto → Module not found e
// versione 0.0.0 di fallback: disonesto) non è inoltre risolvibile dal
// bundler. Import statico col percorso GIUSTO (3 livelli): funziona
// identico in dev, build e runtime Bun.
import pkgJson from '../../../package.json'

let cachedVersion: string | null = null
export function appVersion(): string {
  if (cachedVersion) return cachedVersion
  cachedVersion = pkgJson.version ?? '0.0.0'
  return cachedVersion
}
