/* ================================================================
 * FALCO-OS v16 — CONTRATTI API v2 (zod, additivi — §8 del piano)
 * Fonte unica di verità per rotte e frontend. API_CONTRATTI.md viene
 * GENERATO da questi schemi (mai scritto a mano).
 * Convenzioni: ogni risposta porta `asOf` (data dell'ultimo dato) e,
 * quando pertinente, `mode` ('replay' | 'static') per la regola di
 * onestà §2.1 (dato reale vs riprodotto).
 * ================================================================ */

import { z } from 'zod'

/* ---------------- Tipi di dominio ---------------- */

export const UiStatusSchema = z.enum([
  'ONLINE', 'DEGRADED', 'OFFLINE', 'MAINTENANCE', 'UNKNOWN', 'NOT_MONITORED',
])
export type UiStatus = z.infer<typeof UiStatusSchema>

export const SeveritySchema = z.enum(['INFO', 'WARNING', 'AVERAGE', 'HIGH', 'CRITICAL'])
export type Severity = z.infer<typeof SeveritySchema>

export const AlertStatusSchema = z.enum(['OPEN', 'ACK', 'ESCALATED', 'CLOSED', 'SUPPRESSED'])

export const DeviceTypeSchema = z.enum([
  'AP', 'STA', 'CAMERA', 'LPR', 'SWITCH', 'NVR', 'GATEWAY', 'SERVER', 'UNKNOWN', 'ONT', 'ROUTER',
])

/* ---------------- Busta comune ---------------- */

export const ApiEnvelopeSchema = z.object({
  ok: z.literal(true),
  asOf: z.number().int(), // epoch ms del dato più recente usato per la risposta
  mode: z.enum(['replay', 'static']), // replay = ambiente riproduzione dichiarato
})
export const ApiErrorSchema = z.object({
  ok: z.literal(false),
  error: z.object({
    code: z.string(),
    message: z.string(),
    details: z.unknown().optional(),
  }),
})

/* ---------------- /api/v2/noc/summary ---------------- */

export const NocSummaryQuerySchema = z.object({
  plantId: z.string().optional(),
})

export const NocSummaryDataSchema = z.object({
  plant: z.object({
    id: z.string(),
    name: z.string(),
    comune: z.string(),
    pingIntervalSec: z.number().int(),
    mapCenterLat: z.number(),
    mapCenterLng: z.number(),
    mapZoom: z.number().int(),
  }),
  devices: z.object({
    total: z.number().int(),
    byState: z.object({
      online: z.number().int(),
      degraded: z.number().int(),
      offline: z.number().int(),
      maintenance: z.number().int(),
      unknown: z.number().int(),
      notMonitored: z.number().int(),
    }),
    byType: z.record(z.string(), z.number().int()),
  }),
  cameras: z.object({
    total: z.number().int(),
    online: z.number().int(),
    degraded: z.number().int(),
    offline: z.number().int(),
    unknown: z.number().int(),
    streamDown: z.number().int(), // cameraStreamAlive=0 all'ultimo campione
    streamUnknown: z.number().int(), // mai campionato
  }),
  wirelessLinks: z.object({
    total: z.number().int(),
    active: z.number().int(),
    degraded: z.number().int(), // endpoint DEGRADED
    weak: z.number().int(), // segnale uplink ≤ −75 dBm
    unknown: z.number().int(),
  }),
  alarms: z.object({
    open: z.number().int(),
    bySeverity: z.record(z.string(), z.number().int()),
    suppressed: z.number().int(),
    oldestOpenMinutes: z.number().nullable(),
  }),
  coverage: z.object({
    certain: z.number().int(),
    uncertain: z.number().int(),
    unknown: z.number().int(),
    coveragePct: z.number(),
    goalPct: z.number(),
    goalMet: z.boolean(),
  }).nullable(),
  pipeline: z.object({
    realtimeConnected: z.boolean(),
    lastTickAt: z.number().nullable(), // ultimo tick del servizio riproduzione
    dbReachable: z.boolean(),
    version: z.string(),
  }),
  recentEvents: z.array(z.object({
    id: z.string(),
    deviceId: z.string().nullable(),
    deviceHostname: z.string().nullable(),
    eventType: z.string(),
    oldValue: z.string(),
    newValue: z.string(),
    source: z.string(),
    createdAt: z.number().int(),
  })),
})
export const NocSummarySchema = ApiEnvelopeSchema.extend({ data: NocSummaryDataSchema })
export type NocSummary = z.infer<typeof NocSummaryDataSchema>

/* ---------------- /api/v2/devices ---------------- */

/* ---------------- Vocabolari attivazione SNMP (v16.18 W19) ----------------
 * Definiti PRIMA del primo uso (DeviceRowSchema/Overview): gli stati
 * persistenti dell'attivazione assistita e le modalità di monitoraggio
 * dichiarate — allineati 1:1 alle colonne Device del Prisma. */

/** Stati di attivazione SNMP sul Device: '' mai tentata · ENABLED
 *  comandi applicati E verificati con la sonda · ENABLED_UNVERIFIED
 *  applicati ma agente non ancora in ascolto · FAILED non applicati ·
 *  MANUAL_REQUIRED nessuna automazione (istruzioni manuali in UI). */
export const SNMP_ENABLE_STATES = ['', 'ENABLED', 'ENABLED_UNVERIFIED', 'FAILED', 'MANUAL_REQUIRED'] as const
export type SnmpEnableState = (typeof SNMP_ENABLE_STATES)[number]

/** Modalità di monitoraggio: full = SNMP/poller completo · ping =
 *  sola presenza ICMP (telecamere: l'operatore ha dichiarato che conta
 *  online/offline, non i valori). */
export const MONITOR_MODES = ['full', 'ping'] as const
export type MonitorMode = (typeof MONITOR_MODES)[number]

export const DevicesQuerySchema = z.object({
  plantId: z.string().optional(),
  type: z.string().optional(), // CSV di tipi
  status: z.string().optional(), // CSV di stati (UI, incl. NOT_MONITORED)
  q: z.string().optional(), // hostname/ip/mac/modello
  // v16.17 W18: filtro per sede — serve al pannello «dispositivi del punto»
  // della mappa (pattern UISP). Additivo: chi non lo passa non lo nota.
  locationId: z.string().optional(),
  family: z.enum(['network', 'radio', 'cameras', 'all']).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
  sort: z.enum(['hostname', 'ip', 'type', 'status', 'signal', 'lastSeen', 'uptime']).default('hostname'),
  dir: z.enum(['asc', 'desc']).default('asc'),
})

export const DeviceRowSchema = z.object({
  id: z.string(),
  hostname: z.string(),
  ip: z.string(),
  type: z.string(),
  connectionType: z.string(),
  uiStatus: UiStatusSchema,
  dbStatus: z.string(), // stato grezzo del DB (regola: il frontend non ridefinisce)
  statusReason: z.string().nullable(),
  brand: z.string(),
  model: z.string(),
  antennaType: z.string(),
  signalStrength: z.number().int(), // dBm (0 = non letto → signalPresent=false)
  signalPresent: z.boolean(),
  linkQuality: z.number().int(),
  radioMode: z.string(),
  linkMode: z.string(),
  currentFrequency: z.string(),
  ssid: z.string(),
  macAddress: z.string(),
  firmwareVersion: z.string(),
  uptimeSeconds: z.number().int(),
  cpuLoad: z.number().int(),
  // v16.18 W20 — RAM live (KB): additivo con default onesto per i
  // payload storici (0 = mai letto dalla telemetria).
  ramTotal: z.number().int().default(0),
  ramUsed: z.number().int().default(0),
  lastSeenAt: z.number().int().nullable(),
  stale: z.boolean(),
  monitored: z.boolean(),
  locationId: z.string().nullable(),
  locationName: z.string().nullable(),
  lat: z.number().nullable(),
  lng: z.number().nullable(),
  plantId: z.string(),
  // v16.18 W19 — attivazione SNMP assistita (additivo: .default() per
  // payload storici; le liste mostrano il badge solo se diverso da '').
  snmpEnableState: z.enum(SNMP_ENABLE_STATES).default(''),
  // v16.18 W19 — modalità di monitoraggio dichiarata ('ping' = telecamere).
  monitorMode: z.enum(MONITOR_MODES).default('full'),
})
export type DeviceRow = z.infer<typeof DeviceRowSchema>

export const DevicesPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(DeviceRowSchema),
    total: z.number().int(),
    page: z.number().int(),
    pageSize: z.number().int(),
    pageCount: z.number().int(),
  }),
})

/* ---------------- /api/v2/devices/:id/overview ---------------- */

export const MetricSampleSchema = z.object({
  metric: z.string(),
  value: z.number(),
  unit: z.string().nullable(),
  timestamp: z.number().int(),
})

export const DeviceOverviewDataSchema = z.object({
    identity: DeviceRowSchema,
    /* v16.18 W19 — dettaglio attivazione SNMP (per la scheda: metodo,
     * ultima nota leggibile, ultimo tentativo). La identity porta già
     * snmpEnableState/monitorMode per i badge delle liste. */
    snmpActivation: z.object({
      state: z.enum(SNMP_ENABLE_STATES),
      method: z.string(),
      note: z.string(),
      at: z.number().int().nullable(),
    }),
    parentChain: z.array(z.object({ // dal dispositivo al gateway (percorso del problema)
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
      uiStatus: UiStatusSchema,
    })),
    rootCause: z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
    }).nullable(), // primo punto non raggiungibile a monte (OFFLINE), port rca-engine
    impact: z.object({
      devicesDownstream: z.number().int(),
      camerasDownstream: z.number().int(),
      offlineDownstream: z.number().int(),
    }),
    keyMetrics: z.array(MetricSampleSchema), // ultime letture per tipo apparato
    camera: z.object({
      streamAlive: z.boolean().nullable(), // null = mai campionato
      lastStreamCheck: z.number().int().nullable(),
      rttMs: z.number().nullable(),
    }).nullable(),
    stations: z.array(z.object({ // per AP: stazioni agganciate
      id: z.string(),
      hostname: z.string(),
      signalStrength: z.number().nullable(),
      linkQuality: z.number().int(),
      uiStatus: UiStatusSchema,
    })),
    uplinkAp: z.object({
      id: z.string(),
      hostname: z.string(),
      signalStrength: z.number().nullable(),
    }).nullable(), // per STA: il proprio AP di uplink
    links: z.array(z.object({
      id: z.string(),
      peerId: z.string().nullable(),
      peerHostname: z.string(),
      linkType: z.string(),
      linkStatus: z.string(),
      confidence: z.string(),
      evidence: z.string(),
      speedMbps: z.number().int(),
      trafficInMbps: z.number(),
      trafficOutMbps: z.number(),
      trafficUpdatedAt: z.number().int().nullable(),
      direction: z.enum(['upstream', 'downstream']),
    })),
    recentEvents: z.array(z.object({
      id: z.string(),
      eventType: z.string(),
      oldValue: z.string(),
      newValue: z.string(),
      source: z.string(),
      createdAt: z.number().int(),
    })),
    openAlerts: z.array(z.object({
      id: z.string(),
      severity: SeveritySchema,
      message: z.string(),
      openedAt: z.number().int(),
      occurrenceCount: z.number().int(),
      status: z.string(),
    })),
    series: z.array(z.object({ // finestra 24h, metriche chiave
      metric: z.string(),
      points: z.array(z.object({ t: z.number().int(), v: z.number() })),
    })),
})
export const DeviceOverviewSchema = ApiEnvelopeSchema.extend({ data: DeviceOverviewDataSchema })
export type DeviceOverview = z.infer<typeof DeviceOverviewDataSchema>

/* ---------------- /api/v2/topology/graph ---------------- */

export const TopologyGraphQuerySchema = z.object({
  plantId: z.string().optional(),
  /* 16.10: FONTE dei collegamenti da usare per costruire l'albero.
   * Comma-separated tra LINK_SOURCES. Default: TECHNICIAN,LLDP,MNDP,UISP
   * (esclude le inferenze FDB/BRIDGE_MIB/DAISY_CHAIN/INFERRED — le letture
   * SNMP del bridge che l'operatore ha dichiarato inaffidabili).
   * I link CONFERMATI dall'operatore entrano SEMPRE (verità > filtro). */
  sources: z.string().max(200).optional(),
})

export const TopologyGraphSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    plantId: z.string(),
    gatewayId: z.string().nullable(),
    rootSource: z.enum(['operator', 'inferred', 'none']), // Plant.topologyRootDeviceId vs inferenza
    sources: z.array(z.string()), // fonti USATE per questo grafo (dopo risoluzione default)
    linkStats: z.object({ // onestà: cosa è dentro e cosa è fuori
      total: z.number().int(),
      included: z.number().int(),
      excludedInferred: z.number().int(),
      confirmedAlwaysIn: z.number().int(),
    }),
    nodes: z.array(z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
      uiStatus: UiStatusSchema,
      tier: z.number().int(),
      parentId: z.string().nullable(),
      locationId: z.string().nullable(),
      locationName: z.string().nullable(),
      model: z.string(),
      signalDbm: z.number().nullable(),
      linkQuality: z.number().int(),
      downstreamCount: z.number().int(),
    })),
    edges: z.array(z.object({ // SOLO l'albero di computeNetworkTiers
      id: z.string(),
      source: z.string(), // upstream
      target: z.string(), // downstream (semantica repo: source=upstream)
      linkType: z.string(),
      linkStatus: z.string(),
      confidence: z.string(),
      evidence: z.string(),
      manual: z.boolean(),
      speedMbps: z.number().int(),
      trafficInMbps: z.number(),
      trafficOutMbps: z.number(),
      label: z.string(),
    })),
    blocks: z.array(z.object({
      level: z.number().int(),
      label: z.string(),
      nodeIds: z.array(z.string()),
    })),
    discardedAutoEdges: z.number().int(),
    unreachableCount: z.number().int(),
  }),
})

/* ---------------- /api/v2/links/weak ---------------- */

export const WeakLinksQuerySchema = z.object({
  plantId: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(50).default(8),
})

/** Tipo dell'item di /links/weak (specchio dello schema qui sotto) */
export interface WeakLinkRow {
  deviceId: string
  hostname: string
  ip: string
  type: string
  uiStatus: UiStatus
  signalDbm: number
  health: 'excellent' | 'good' | 'fair' | 'poor' | 'critical'
  score: number
  linkQuality: number
  frequency: string
  ssid: string
  uplinkApHostname: string | null
  locationName: string | null
  lastSeenAt: number | null
}

export const WeakLinksSchema = ApiEnvelopeSchema.extend({
  data: z.array(z.object({
    deviceId: z.string(),
    hostname: z.string(),
    ip: z.string(),
    type: z.string(),
    uiStatus: UiStatusSchema,
    signalDbm: z.number(),
    health: z.enum(['excellent', 'good', 'fair', 'poor', 'critical']),
    score: z.number().int(),
    linkQuality: z.number().int(),
    frequency: z.string(),
    ssid: z.string(),
    uplinkApHostname: z.string().nullable(),
    locationName: z.string().nullable(),
    lastSeenAt: z.number().int().nullable(),
  })),
})

/* ---------------- /api/v2/events ---------------- */

export const EventsQuerySchema = z.object({
  plantId: z.string().optional(),
  deviceId: z.string().optional(),
  limit: z.coerce.number().int().min(5).max(100).default(25),
  before: z.coerce.number().int().optional(), // cursore (createdAt epoch ms)
})

export const EventsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(z.object({
      id: z.string(),
      deviceId: z.string().nullable(),
      deviceHostname: z.string().nullable(),
      eventType: z.string(),
      oldValue: z.string(),
      newValue: z.string(),
      source: z.string(),
      createdAt: z.number().int(),
    })),
    nextCursor: z.number().int().nullable(),
  }),
})

/* ---------------- /api/v2/alarms ---------------- */

export const AlarmsQuerySchema = z.object({
  plantId: z.string().optional(),
  status: z.string().optional(), // CSV OPEN,ACK,CLOSED,SUPPRESSED,ESCALATED
  severity: z.string().optional(), // CSV
  deviceId: z.string().optional(),
  q: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(100).default(25),
})

export const AlarmRowSchema = z.object({
  id: z.string(),
  ruleId: z.string(),
  ruleName: z.string().nullable(),
  severity: SeveritySchema,
  status: AlertStatusSchema,
  message: z.string(),
  occurrenceCount: z.number().int(),
  openedAt: z.number().int(),
  acknowledgedAt: z.number().int().nullable(),
  acknowledgedBy: z.string().nullable(),
  closedAt: z.number().int().nullable(),
  escalatedAt: z.number().int().nullable(),
  deviceId: z.string().nullable(),
  deviceHostname: z.string().nullable(),
  deviceIp: z.string().nullable(),
  deviceUiStatus: UiStatusSchema.nullable(),
  suppressedByRootCause: z.boolean(), // dedotto dal messaggio [SOPPRESSO: causa radice …]
  rootCauseHostname: z.string().nullable(),
  ageMinutes: z.number(),
})
export type AlarmRow = z.infer<typeof AlarmRowSchema>

export const AlarmsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(AlarmRowSchema),
    total: z.number().int(),
    page: z.number().int(),
    pageSize: z.number().int(),
    pageCount: z.number().int(),
  }),
})

export const AckAlarmBodySchema = z.object({
  note: z.string().max(500).optional(),
})

/* ---------------- /api/v2/cameras ---------------- */

export const CamerasQuerySchema = z.object({
  plantId: z.string().optional(),
  q: z.string().optional(),
  stream: z.enum(['all', 'down', 'unknown', 'alive']).default('all'),
  locationId: z.string().optional(), // 16.3 additivo: filtro sede (CSV di id Location — cuid minuscoli, case-sensitive)
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
})

export const CameraRowSchema = DeviceRowSchema.extend({
  streamAlive: z.boolean().nullable(),
  lastStreamCheck: z.number().int().nullable(),
  rttMs: z.number().nullable(),
  nvrHostname: z.string().nullable(),
  rtspStream: z.string(), // path (senza credenziali) — il campo è già senza segreti nel DB reale? verificato: rtspStream non contiene credenziali in questo DB; mascherato comunque lato API se contiene '@'
})
export type CameraRow = z.infer<typeof CameraRowSchema>

export const CamerasPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(CameraRowSchema),
    total: z.number().int(),
    page: z.number().int(),
    pageSize: z.number().int(),
    pageCount: z.number().int(),
  }),
})

/* ---------------- /api/v2/traffic/series ---------------- */

export const TrafficQuerySchema = z.object({
  plantId: z.string().optional(),
  hours: z.coerce.number().int().min(1).max(48).default(24),
})

export const TrafficSeriesSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    definition: z.string(), // definizione dell'aggregato (decisione D3) — mostrata in UI
    coreDeviceId: z.string().nullable(),
    coreHostname: z.string().nullable(),
    inMbps: z.array(z.object({ t: z.number().int(), v: z.number() })),
    outMbps: z.array(z.object({ t: z.number().int(), v: z.number() })),
    lastInMbps: z.number().nullable(),
    lastOutMbps: z.number().nullable(),
    lastSampleAt: z.number().int().nullable(),
  }),
})

/* ---------------- /api/v2/search ---------------- */

export const SearchQuerySchema = z.object({
  q: z.string().min(2),
  plantId: z.string().optional(),
})

export const SearchResultsSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    devices: z.array(z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
      uiStatus: UiStatusSchema,
    })),
    locations: z.array(z.object({
      id: z.string(),
      name: z.string(),
      identifier: z.string(),
      lat: z.number().nullable(),
      lng: z.number().nullable(),
      deviceCount: z.number().int(),
    })),
    alarms: z.array(z.object({
      id: z.string(),
      severity: SeveritySchema,
      message: z.string(),
      deviceId: z.string().nullable(),
    })),
  }),
})

/* ---------------- /api/v2/plants e /api/v2/system/health ---------------- */

/** Riga impianto completa (16.10: prima solo id/nome/comune/isActive/mappa).
 * Definita QUI perché PlantsSchema (sotto) la usa; il resto dei contratti
 * impianti (create/update) sta nella sezione 16.10 in fondo. */
export const PlantRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  comune: z.string(),
  address: z.string(),
  notes: z.string(),
  telegramChatId: z.string(),
  kmzFile: z.string(), // nome file importato (vuoto = mai importato)
  isActive: z.boolean(),
  mapCenterLat: z.number(),
  mapCenterLng: z.number(),
  mapZoom: z.number().int(),
  pingIntervalSec: z.number().int(),
  outageTimerMinutes: z.number().int(),
  snmpCommunities: z.string(),
  topologyRootDeviceId: z.string().nullable(),
  topologyRootHostname: z.string().nullable(), // null = inferenza automatica
  deviceCount: z.number().int(),
  locationCount: z.number().int(),
  ticketCount: z.number().int(),
  createdAt: z.number().int(),
})
export type PlantRow = z.infer<typeof PlantRowSchema>

export const PlantsSchema = ApiEnvelopeSchema.extend({
  data: z.array(PlantRowSchema),
})

export const PlantsQuerySchema = z.object({
  plantId: z.string().optional(), // se presente: solo quell'impianto
})

export const SystemHealthSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    version: z.string(), // versione reale del build (package.json)
    dbReachable: z.boolean(),
    realtimeUrl: z.string(), // path socket (con XTransformPort, mai porta nel body… il valore è relativo)
    replay: z.object({
      enabled: z.boolean(),
      importedAt: z.number().int().nullable(), // quando il DB reale è stato importato
      lastTickAt: z.number().int().nullable(),
      nextTickAt: z.number().int().nullable(),
      intervalSec: z.number().int(),
    }),
    lastDbWrite: z.number().int().nullable(),
  }),
})

/* ---------------- /api/v2/locations (mappa) ---------------- */

export const MapLocationsQuerySchema = z.object({
  plantId: z.string().optional(),
})

export const MapLocationsSchema = ApiEnvelopeSchema.extend({
  data: z.array(z.object({
    id: z.string(),
    name: z.string(),
    identifier: z.string(),
    lat: z.number().nullable(),
    lng: z.number().nullable(),
    devices: z.number().int(),
    online: z.number().int(),
    degraded: z.number().int(),
    offline: z.number().int(),
    unknown: z.number().int(),
    notMonitored: z.number().int(),
    worstStatus: UiStatusSchema.nullable(),
    cameraCount: z.number().int(),
  })),
})

/* ================================================================
 * /api/v2/tickets — Ticket ITSM reali del DB (workflow v8/v9)
 * Stati REALI distinti nel DB al 16.1: OPEN (71). Il workflow del
 * motore v8 introduce IN_PROGRESS/RESOLVED/CLOSED via PATCH: le
 * transizioni sono validate server-side (§B.3). Priorità reali
 * distinte: CRITICAL, HIGH (verifica bun:sqlite readonly).
 * ================================================================ */

export const TicketsQuerySchema = z.object({
  plantId: z.string().optional(),
  status: z.string().optional(), // CSV OPEN,IN_PROGRESS,RESOLVED,CLOSED
  priority: z.string().optional(), // CSV CRITICAL,HIGH
  q: z.string().optional(), // contains su title/description/assignedTo
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(100).default(25),
})

export const TicketRowSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  status: z.string(), // grezzo del DB (il frontend non ridefinisce gli stati)
  priority: z.string(),
  source: z.string(),
  plantId: z.string(),
  device: z.object({ id: z.string(), hostname: z.string(), ip: z.string() }).nullable(), // incluso SOLO se deviceId
  locationName: z.string().nullable(),
  assignedTo: z.string(), // "" = nessuno → la UI mostra «n.d.»
  rootCause: z.string(), // "" = non ancora diagnosticata (campo reale del modello)
  resolution: z.string(), // "" = non ancora risolto
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
  resolvedAt: z.number().int().nullable(),
  closedAt: z.number().int().nullable(),
  slaResolutionDueAt: z.number().int().nullable(),
  escalationLevel: z.number().int(),
  interventionsCount: z.number().int(),
  commentsCount: z.number().int(),
})
export type TicketRow = z.infer<typeof TicketRowSchema>

/** KPI globali dell'impianto (NON filtrati dai filtri utente): la
 *  striscia KPI della vista resta reale anche con filtri attivi. */
export const TicketKpisSchema = z.object({
  open: z.number().int(),
  inProgress: z.number().int(),
  resolved7d: z.number().int(), // resolvedAt ≥ now − 7 giorni
  slaOverdue: z.number().int(), // status OPEN|IN_PROGRESS con slaResolutionDueAt < now
})

export const TicketsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(TicketRowSchema),
    total: z.number().int(),
    page: z.number().int(),
    pageSize: z.number().int(),
    pageCount: z.number().int(),
    kpis: TicketKpisSchema,
  }),
})

/** Creazione: priorità = valori REALI distinti nel DB (CRITICAL|HIGH,
 *  verifica 16.1); title min 5, description min 10 (il campo è NOT NULL
 *  nel modello: un ticket senza descrizione non sarebbe onesto). */
export const CreateTicketInputSchema = z.object({
  title: z.string().trim().min(5).max(200),
  description: z.string().trim().min(10).max(5000),
  priority: z.enum(['CRITICAL', 'HIGH']),
  deviceId: z.string().optional(), // se presente: plantId/locationId ereditati dal device
})

/** Aggiornamento = SOLO transizioni di stato validate (route PATCH):
 *  status è di fatto obbligatorio (la route risponde 422 se manca);
 *  `note` NON finisce in campi inesistenti: vive solo nei details dell'audit. */
export const UpdateTicketInputSchema = z.object({
  status: z.enum(['IN_PROGRESS', 'RESOLVED', 'CLOSED']).optional(),
  resolution: z.string().trim().max(2000).optional(),
  assignedTo: z.string().trim().max(200).optional(),
  note: z.string().trim().max(500).optional(),
})

/* ---------------- /api/v2/maintenance (finestre reali) ---------------- */

export const MaintenanceQuerySchema = z.object({
  plantId: z.string().optional(),
})

export const MaintenanceRowSchema = z.object({
  id: z.string(),
  plantId: z.string(),
  name: z.string(),
  description: z.string(),
  type: z.string(), // WITH_DATA | NO_DATA (grezzo; label in UI)
  scheduleType: z.string(), // ONCE | DAILY | WEEKLY | MONTHLY
  daysOfWeek: z.array(z.number().int()), // parse JSON "[1..7]", 1 = lunedì
  dayOfMonth: z.number().int(),
  startTime: z.string(), // HH:mm
  endTime: z.string(), // HH:mm (wrap mezzanotte consentito dal modello)
  activeSince: z.number().int(),
  activeUntil: z.number().int().nullable(), // null = senza scadenza
  state: z.string(), // ACTIVE | PAUSED
  scopesCount: z.number().int(), // gruppi di dispositivi collegati (MaintenanceWindowGroup)
  // 16.3 additivo W3: nomi dei gruppi usati come scope (vuoto = intero
  // impianto). Il campo è ADDITIVO: le risposte delle rotte esistenti
  // continuano a validare (scopes: [] quando nessun gruppo).
  scopes: z.array(z.object({
    groupId: z.string(),
    name: z.string(),
  })),
})
export type MaintenanceRow = z.infer<typeof MaintenanceRowSchema>

export const MaintenancePageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(MaintenanceRowSchema),
  }),
})

/* --- Input creazione finestra di manutenzione (16.2 — inizio W3) ---
 * Campi REALI del modello MaintenanceWindow. Le regole seguono il
 * modello: daysOfWeek JSON "[1..7]" (1 = lunedì) per WEEKLY,
 * dayOfMonth 1..31 per MONTHLY, HH:mm (wrap mezzanotte CONSENTITO dal
 * modello: solo orari identici inizio=fine sono rifiutati, durata
 * nulla). Lo scope per gruppi (MaintenanceWindowGroup) NON è
 * selezionabile qui: nel DB reale DeviceGroup è vuoto (0 righe) —
 * nessun gruppo finto. activeUntil epoch ms null = senza scadenza.
 * 16.3 additivo W3: groupIds OPZIONALE — scope su gruppi REALI del
 * plant (la rotta rifiuta id inesistenti con 422); [] o assente =
 * nessuno scope (finestra valida per l'intero impianto). */
export const CreateMaintenanceInputSchema = z.object({
  name: z.string().trim().min(3, 'Nome troppo corto (minimo 3 caratteri)').max(120, 'Nome troppo lungo (massimo 120 caratteri)'),
  description: z.string().max(2000, 'Descrizione troppo lunga (massimo 2000 caratteri)').default(''),
  type: z.enum(['WITH_DATA', 'NO_DATA']),
  scheduleType: z.enum(['ONCE', 'DAILY', 'WEEKLY', 'MONTHLY']),
  daysOfWeek: z.array(z.number().int().min(1).max(7)).max(7).default([]),
  dayOfMonth: z.number().int().min(1).max(31).default(1),
  startTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Formato atteso HH:mm'),
  endTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Formato atteso HH:mm'),
  activeUntil: z.number().int().nullable().default(null),
  // 16.3 additivo W3: scope per gruppi (max 100, deduplicati lato server)
  groupIds: z.array(z.string().min(1)).max(100, 'Massimo 100 gruppi per richiesta').optional(),
})
  .refine((v) => v.scheduleType !== 'WEEKLY' || v.daysOfWeek.length > 0, {
    path: ['daysOfWeek'],
    message: 'Con periodicità settimanale serve almeno un giorno',
  })
  .refine((v) => v.scheduleType === 'WEEKLY' || v.daysOfWeek.length === 0, {
    path: ['daysOfWeek'],
    message: 'I giorni si applicano solo alla periodicità settimanale',
  })
  .refine((v) => v.startTime !== v.endTime, {
    path: ['endTime'],
    message: 'Orario di fine identico a quello di inizio (durata nulla)',
  })
export type CreateMaintenanceInput = z.infer<typeof CreateMaintenanceInputSchema>

/** PATCH /api/v2/maintenance/{id}: modifica della finestra (16.3 W3).
 *  RETROCOMPATIBILE: { state } da solo continua a funzionare come in
 *  16.2 (pausa/ripresa con audit MAINTENANCE_STATE). Tutti i campi
 *  sono opzionali MA almeno uno deve esserci (refine); la validazione
 *  semantica (orari, giorni WEEKLY, activeUntil futuro) avviene sulla
 *  COMBINAZIONE con la finestra ESISTENTE nella rotta. activeUntil:
 *  null = rimuovi la scadenza. groupIds = sostituzione integrale degli
 *  scope (nessun gruppo = finestra sull'intero impianto). */
export const UpdateMaintenanceInputSchema = z.object({
  state: z.enum(['ACTIVE', 'PAUSED']).optional(),
  name: z.string().trim().min(3, 'Nome troppo corto (minimo 3 caratteri)').max(120, 'Nome troppo lungo (massimo 120 caratteri)').optional(),
  description: z.string().max(2000, 'Descrizione troppo lunga (massimo 2000 caratteri)').optional(),
  type: z.enum(['WITH_DATA', 'NO_DATA']).optional(),
  scheduleType: z.enum(['ONCE', 'DAILY', 'WEEKLY', 'MONTHLY']).optional(),
  daysOfWeek: z.array(z.number().int().min(1).max(7)).max(7).optional(),
  dayOfMonth: z.number().int().min(1).max(31).optional(),
  startTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Formato atteso HH:mm').optional(),
  endTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Formato atteso HH:mm').optional(),
  activeUntil: z.number().int().nullable().optional(), // null = rimuovi la scadenza
  groupIds: z.array(z.string().min(1)).max(100, 'Massimo 100 gruppi per richiesta').optional(),
}).refine(
  (v) => Object.values(v).some((x) => x !== undefined),
  { message: 'Specificare almeno un campo da aggiornare (state, name, description, type, scheduleType, daysOfWeek, dayOfMonth, startTime, endTime, activeUntil o groupIds)' },
)
export type UpdateMaintenanceInput = z.infer<typeof UpdateMaintenanceInputSchema>

/** Risposta di DELETE /api/v2/maintenance/{id}: id eliminato (audit
 *  MAINTENANCE_DELETE; gli Intervention collegati restano con
 *  maintenanceWindowId → null, schema onDelete: SetNull). */
export const MaintenanceDeletedSchema = z.object({ id: z.string() })
export type MaintenanceDeleted = z.infer<typeof MaintenanceDeletedSchema>


/* ---------------- /api/v2/audit (registro, sola lettura) ----------------
 * I `details` NON vengono MAI esposti: possono contenere payload di
 * azioni SYSTEM (e la nota dell'operatore è già visibile nella UI
 * allarmi). Solo i campi elencati qui sotto lasciano il server. */

export const AuditQuerySchema = z.object({
  action: z.string().optional(), // prefix match (startsWith)
  limit: z.coerce.number().int().min(1).max(200).default(50),
})

export const AuditRowSchema = z.object({
  id: z.string(),
  action: z.string(),
  actor: z.string(),
  targetLabel: z.string().nullable(),
  createdAt: z.number().int(),
})
export type AuditRow = z.infer<typeof AuditRowSchema>

export const AuditPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(AuditRowSchema),
    total: z.number().int(), // righe che soddisfano il filtro (badge onesto in UI)
    returned: z.number().int(), // righe effettivamente restituite (≤ limit)
  }),
})

/* ---------------- /api/v2/admin/stats (conteggi reali) ---------------- */

export const AdminStatsQuerySchema = z.object({
  plantId: z.string().optional(),
})

export const AdminStatsSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    devices: z.number().int(), // stesso scope del /noc/summary (incl. 30 mai assegnati)
    locations: z.number().int(),
    plants: z.number().int(),
    alertsOpen: z.number().int(), // status != CLOSED (stessa definizione del summary)
    alertsSuppressed: z.number().int(),
    ticketsByStatus: z.record(z.string(), z.number().int()),
    ticketsTotal: z.number().int(),
    maintenanceWindows: z.number().int(),
    auditLogEntries: z.number().int(), // registro globale (non per impianto)
    metricSamples: z.number().int(),
    pollingSchedules: z.number().int(),
    coveragePct: z.number().nullable(), // ultimo snapshot reale (56,1%); null = nessuno snapshot
  }),
})
export type AdminStats = z.infer<typeof AdminStatsSchema>['data']

/* ================================================================
 * /api/v2/cameras/streams — 16.3 additivo (onda W2 residua)
 * «Registro flussi»: per ogni apparato video (convenzione CAMERA/LPR/NVR)
 * la serie REALE di cameraStreamAlive sulla finestra analizzata.
 * Onestà (§2): uptime calcolato SOLO sui campioni presenti — zero
 * campioni → null («n.d.» in UI), MAI 0% per mancanza di dato; il valore
 * 0% compare solo quando i campioni esistono e sono tutti flusso fermo
 * (misura reale). lastChange = ultima TRANSIZIONE di valore osservata
 * nella finestra: null = nessuna transizione o zero campioni.
 * windowHours nella risposta dichiara la finestra EFFETTIVAMENTE
 * caricata: se la serie richiesta supera ~120.000 campioni la rotta
 * serve la finestra ridotta dichiarata (48h) — vedi commento in
 * src/app/api/v2/cameras/streams/route.ts.
 * ================================================================ */

export const CamerasStreamsQuerySchema = z.object({
  plantId: z.string().optional(),
  q: z.string().optional(), // contains su hostname/ip/locationName
  stream: z.enum(['alive', 'down', 'unknown']).optional(), // assente = tutti (stessa semantica di /cameras)
  locationId: z.string().optional(), // 16.3 additivo: filtro sede (CSV di id Location — cuid minuscoli, case-sensitive)
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(25),
  windowHours: z.coerce.number().int().min(24).max(168).default(168),
})

export const StreamRegistryRowSchema = z.object({
  deviceId: z.string(),
  hostname: z.string(),
  type: z.string(), // CAMERA | LPR | NVR (vocabolario del dominio, non inventato)
  locationId: z.string().nullable(), // null = apparato non associato a sede
  locationName: z.string().nullable(),
  streamAlive: z.boolean().nullable(), // null = mai campionato nella finestra analizzata
  lastCheck: z.number().int().nullable(), // epoch ms dell'ultimo campione nella finestra
  lastChange: z.number().int().nullable(), // epoch ms dell'ultima transizione di valore osservata nella finestra
  samples: z.number().int(), // campioni cameraStreamAlive nella finestra
  uptime24h: z.number().min(0).max(100).nullable(), // % campioni value>0 nelle ultime 24h; null = zero campioni nelle 24h
  uptime7d: z.number().min(0).max(100).nullable(), // % campioni value>0 sulla finestra completa; null = zero campioni
  rttMs: z.number().nullable(), // ultimo cameraRtt reale (se campionato)
})
export type StreamRegistryRow = z.infer<typeof StreamRegistryRowSchema>

export const CamerasStreamsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(StreamRegistryRowSchema),
    total: z.number().int(),
    page: z.number().int(),
    pageSize: z.number().int(),
    pageCount: z.number().int(),
    windowHours: z.number().int(), // finestra realmente analizzata (può essere < di quella richiesta: dichiarata, mai mascherata)
  }),
})

/* ================================================================
 * /api/v2/device-groups — 16.3 additivo W3 (gruppi dispositivi)
 * I gruppi dispositivi sono entità GESTITE DALL'OPERATORE (come i
 * ticket): crearli NON è inventare dati — ma il DB reale parte da
 * 0 gruppi (probe bun:sqlite readonly del 17-b: DeviceGroup=0,
 * DeviceGroupMember=0) e la UI lo dichiara onestamente.
 * 16.4 W3: gruppi MANUAL (membri espliciti in DeviceGroupMember) e
 * gruppi DYNAMIC (ruleJson valutata a RUNTIME sullo stato REALE
 * dei dispositivi: la membership NON viene salvata — è il risultato
 * della regola, ricalcolata a ogni lettura; se un dispositivo
 * cambia sede/stato/tipo entra o esce da solo). Regola = AND fra
 * criteri, OR fra i valori di un criterio; criteri supportati (tutti
 * campi REALI del modello Device): deviceTypes, statuses,
 * connectionTypes, locationIds. I valori di types/statuses/
 * connectionTypes sono validati contro i valori DISTINTI presenti
 * nell'impianto (422 con offensori: niente regole su valori fantasma),
 * i locationIds contro le sedi reali del plant.
 * Nessuna paginazione: i gruppi di un impianto sono poche decine,
 * la risposta è per intero (items + total).
 * ================================================================ */

export const DeviceGroupsQuerySchema = z.object({
  plantId: z.string().optional(),
})

/** Criteri di una regola DYNAMIC (salvata in DeviceGroup.ruleJson):
 *  AND fra i criteri presenti, OR fra i valori di ciascun criterio.
 *  Almeno UN criterio richiesto (refine) — una regola vuota non ha
 *  senso (varrebbe «tutti i dispositivi», ingannevole come gruppo). */
export const GroupRuleSchema = z.object({
  deviceTypes: z.array(z.string().trim().min(1).max(40)).min(1).max(20, 'Massimo 20 tipi per criterio').optional(),
  statuses: z.array(z.string().trim().min(1).max(40)).min(1).max(20, 'Massimo 20 stati per criterio').optional(),
  connectionTypes: z.array(z.string().trim().min(1).max(40)).min(1).max(20, 'Massimo 20 connessioni per criterio').optional(),
  locationIds: z.array(z.string().min(1)).min(1).max(100, 'Massimo 100 sedi per criterio').optional(),
}).refine(
  (v) => (v.deviceTypes?.length ?? 0) + (v.statuses?.length ?? 0) + (v.connectionTypes?.length ?? 0) + (v.locationIds?.length ?? 0) > 0,
  { message: 'La regola richiede almeno un criterio (deviceTypes, statuses, connectionTypes o locationIds)' },
)
export type GroupRule = z.infer<typeof GroupRuleSchema>

export const DeviceGroupMemberRowSchema = z.object({
  id: z.string(),
  hostname: z.string(),
  type: z.string(), // vocabolario del dominio (AP, CAMERA, SWITCH…), grezzo dal DB
  locationName: z.string().nullable(), // null = dispositivo senza sede (host scoperto)
})
export type DeviceGroupMemberRow = z.infer<typeof DeviceGroupMemberRowSchema>

/** Cap onesto sui membri in risposta: oltre 500 il gruppo serve i
 *  PRIMI 500 membri (memberCount resta il totale REALE del DB). */
export const DEVICE_GROUP_MEMBERS_CAP = 500

export const DeviceGroupRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(), // "" = nessuna descrizione
  color: z.string(), // hex #RRGGBB — DATO dell'operatore salvato nel DB, esce così com'è
  ruleType: z.enum(['MANUAL', 'DYNAMIC']), // 16.4: DYNAMIC = membership calcolata a runtime dalla regola
  rules: GroupRuleSchema.nullable(), // la regola DYNAMIC salvata (null per i MANUAL)
  memberCount: z.number().int(), // totale REALE (MANUAL: righe DeviceGroupMember; DYNAMIC: dispositivi che soddisfano la regola ADESSO)
  members: z.array(DeviceGroupMemberRowSchema), // primi DEVICE_GROUP_MEMBERS_CAP, ordinati per hostname
})
export type DeviceGroupRow = z.infer<typeof DeviceGroupRowSchema>

export const DeviceGroupsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(DeviceGroupRowSchema), // ordinati per name asc
    total: z.number().int(), // 0 = nessun gruppo nel DB reale (onesto, non errore)
  }),
})

/** Creazione gruppo: name univoco per impianto (la rotta rifiuta i
 *  duplicati con 422 GROUP_EXISTS); ruleType opzionale (default
 *  MANUAL, retrocompatibile); MANUAL → deviceIds opzionali
 *  (esistenti e nello scope dell'impianto, altrimenti 422 con lista
 *  id offensori; deduplicati lato server); DYNAMIC → rules
 *  OBBLIGATORIE e deviceIds VIETATI (membership calcolata, non
 *  salvata: fornire entrambi è contraddittorio → 422). */
export const CreateDeviceGroupInputSchema = z.object({
  name: z.string().trim().min(2, 'Nome troppo corto (minimo 2 caratteri)').max(80, 'Nome troppo lungo (massimo 80 caratteri)'),
  description: z.string().max(500, 'Descrizione troppo lunga (massimo 500 caratteri)').optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Colore atteso in formato #RRGGBB').optional(),
  ruleType: z.enum(['MANUAL', 'DYNAMIC']).optional(), // assente = MANUAL (retrocompat 16.3)
  rules: GroupRuleSchema.optional(), // richiesto se ruleType DYNAMIC, vietato se MANUAL
  deviceIds: z.array(z.string().min(1)).max(500, 'Massimo 500 dispositivi per richiesta').optional(), // deduplicati lato server
}).refine(
  (v) => {
    const dynamic = v.ruleType === 'DYNAMIC'
    if (dynamic) return v.rules !== undefined && v.deviceIds === undefined
    return v.rules === undefined // MANUAL (esplicito o default): niente regole
  },
  {
    message: 'Gruppo DYNAMIC: «rules» è obbligatorio e «deviceIds» è vietato (membership calcolata); gruppo MANUAL: «rules» non è accettato',
    path: ['ruleType'],
  },
)
export type CreateDeviceGroupInput = z.infer<typeof CreateDeviceGroupInputSchema>

/** Aggiornamento: almeno un campo richiesto (refine). deviceIds
 *  presente = SOSTITUZIONE INTEGRALE della membership (non un
 *  add/remove incrementale): semantiche distinte dichiarate, nessun
 *  input ignorato in silenzio. rules = SOSTITUZIONE INTEGRALE della
 *  regola DYNAMIC (solo su gruppi DYNAMIC: su un MANUAL → 422
 *  RULE_TYPE; deviceIds su un DYNAMIC → 422 RULE_TYPE). ruleType è
 *  IMMUTABILE dopo la creazione (il tipo di membership non si
 *  converte: semantica dichiarata, la rotta lo rifiuta esplicitamente
 *  con 422 RULE_TYPE_IMMUTABLE — il campo non è nemmeno in questo
 *  schema, il check è sul corpo grezzo nella rotta). */
export const UpdateDeviceGroupInputSchema = z.object({
  name: z.string().trim().min(2, 'Nome troppo corto (minimo 2 caratteri)').max(80, 'Nome troppo lungo (massimo 80 caratteri)').optional(),
  description: z.string().max(500, 'Descrizione troppo lunga (massimo 500 caratteri)').optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Colore atteso in formato #RRGGBB').optional(),
  rules: GroupRuleSchema.optional(),
  deviceIds: z.array(z.string().min(1)).max(500, 'Massimo 500 dispositivi per richiesta').optional(),
}).refine(
  (v) => v.name !== undefined || v.description !== undefined || v.color !== undefined || v.rules !== undefined || v.deviceIds !== undefined,
  { message: 'Specificare almeno un campo da aggiornare (name, description, color, rules o deviceIds)' },
)
export type UpdateDeviceGroupInput = z.infer<typeof UpdateDeviceGroupInputSchema>

/** Risposta di DELETE /api/v2/device-groups/{id}: removedScopes =
 *  finestre di manutenzione che usavano il gruppo come scope e che
 *  NON vengono eliminate (perdono solo questo scope, cascade dello
 *  schema su MaintenanceWindowGroup). */
export const DeviceGroupDeletedSchema = z.object({
  id: z.string(),
  removedScopes: z.number().int(),
})
export type DeviceGroupDeleted = z.infer<typeof DeviceGroupDeletedSchema>

/* ================================================================
 * /api/v2/reports/availability — 16.4 W2 residua (report disponibilità)
 * Disponibilità di rete calcolata dalla serie REALE «packetLoss»
 * (perdita pacchetti misurata dal poller reale: disponibilità =
 * 100 − perdita media). Il DB reale (impianto «egidio»): 51.438
 * campioni su 170 dispositivi dal 23/10 17:00 al 26/10 10:36 — la
 * serie è CONGELATA alla fine del prelievo reale: oltre quella data
 * nessun campione → disponibilità «n.d.» (mai 100% inventato). La
 * finestra richiesta è DICHIARATA insieme alla copertura effettiva
 * (primo/ultimo campione trovato NELLA finestra, globale e per riga).
 * pingLatency è riportata come statistiche supplementari (media/max
 * ms) ma NON è fonte di disponibilità: la sua presenza dipende dalla
 * rotazione del replay, non dalla raggiungibilità.
 * SLA: SLADefinition = 0 righe nel DB reale → slaTargetsDeclared=0
 * e NESSUNA soglia di conformità applicata/inventata (i colori della
 * UI restano neutri).
 * Registri video: l'uptime dei flussi cameraStreamAlive vive nel
 * registro flussi (GET /cameras/streams) — NON duplicato qui.
 * ================================================================ */

export const AvailabilityQuerySchema = z.object({
  windowHours: z.coerce.number().int().min(24, 'Finestra minima 24 ore').max(168, 'Finestra massima 168 ore').default(48),
  plantId: z.string().optional(),
})

export const AvailabilityRowSchema = z.object({
  deviceId: z.string(),
  hostname: z.string(),
  type: z.string(), // vocabolario del dominio, grezzo dal DB
  dbStatus: z.string(), // stato raggiungibilità REALE del DB (il frontend non ridefinisce)
  locationId: z.string().nullable(), // v16.16 W17-b: chiave del raggruppamento per sede
  locationName: z.string().nullable(), // null = host senza sede
  /* --- packetLoss: FONTE della disponibilità --- */
  lossSamples: z.number().int(), // campioni nella finestra (0 = nessuno → n.d.)
  lossAvgPct: z.number().nullable(), // perdita media % (null = nessun campione)
  lossMaxPct: z.number().nullable(), // picco di perdita % (null = nessun campione)
  availabilityPct: z.number().nullable(), // 100 − lossAvgPct, arrotondato al centesimo (null = n.d. onesto)
  firstSampleAt: z.number().int().nullable(), // primo campione packetLoss nella finestra (epoch ms)
  lastSampleAt: z.number().int().nullable(), // ultimo campione packetLoss nella finestra (epoch ms)
  /* --- pingLatency: supplementare, NON disponibilità --- */
  pingSamples: z.number().int(),
  pingAvgMs: z.number().nullable(),
  pingMaxMs: z.number().nullable(),
})
export type AvailabilityRow = z.infer<typeof AvailabilityRowSchema>

/** v16.16 W17-b — riga del raggruppamento PER SEDE della disponibilità
 *  (la roadmap W2 dichiarava «report disponibilità per sede»): media
 *  sulle SOLE righe con campioni (senza dati → contati a parte, mai
 *  zero né cento inventati), peggiore/peggio con hostname, copertura
 *  per sede. Ordinamento: peggior disponibilità prima, «senza sede»
 *  ultima (scelta di lettura, non di giudizio). */
export const AvailabilityByLocationRowSchema = z.object({
  locationId: z.string().nullable(), // null = apparati senza sede (host scoperti non adottati)
  locationName: z.string().nullable(),
  devices: z.number().int(), // apparati attivi della sede nello scope
  withData: z.number().int(), // di cui con campioni packetLoss nella finestra
  withoutData: z.number().int(), // n.d. onesto (mai conteggiati nella media)
  availabilityAvgPct: z.number().nullable(), // media delle righe CON dati (null = nessun dato in sede)
  availabilityMinPct: z.number().nullable(), // disponibilità del peggiore apparato con dati
  worstHostname: z.string().nullable(), // chi è il peggiore (null = nessun dato)
  lossSamples: z.number().int(), // campioni totali della sede nella finestra
  coverageFrom: z.number().int().nullable(), // primo campione della sede (epoch ms)
  coverageTo: z.number().int().nullable(), // ultimo campione della sede
})
export type AvailabilityByLocationRow = z.infer<typeof AvailabilityByLocationRowSchema>

export const AvailabilityReportSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(AvailabilityRowSchema), // tutti i dispositivi attivi dello scope, hostname asc
    byLocation: z.array(AvailabilityByLocationRowSchema), // v16.16 W17-b: raggruppamento per sede (null = senza sede, ultima)
    total: z.number().int(),
    windowHours: z.number().int(), // finestra RICHIESTA (dichiarata)
    coverageFrom: z.number().int().nullable(), // primo campione packetLoss effettivo nella finestra (globale; null = nessun campione)
    coverageTo: z.number().int().nullable(), // ultimo campione effettivo: la serie REALE finisce qui
    slaTargetsDefined: z.number().int(), // 0 nel DB reale: nessun obiettivo SLA, nessuna soglia inventata
  }),
})

/* ================================================================
 * /api/v2/devices/[id]/ports — 16.5.0 W3-proroga (tab «Porte»)
 * Tabella per porta «cosa c'è su ogni porta» (parità v15 G3) costruita
 * SOLO da tre fonti REALI del DB (union: nessuna porta inventata):
 *   1. TopologyLink — collegato a (hostname/IP/type dell'altro capo),
 *      evidenza/confidenza della ricostruzione, speedMbps/duplex che
 *      sono dati del LINK (velocità negoziata STORICA, non lettura live);
 *   2. FdbObservation — MAC appresi per porta (nel DB reale il MAC è
 *      normalizzato SENZA separatori, es. «f8ce07585136»; il DB reale
 *      arriva al 26/10 09:50 — serie congelata, dichiarata nel summary);
 *   3. serie MetricValue «port_utilization:<nomePorta>» — ultimo
 *      campione + copertura REALE della serie (come il report
 *      disponibilità: la copertura si dichiara, non si inventa);
 *   4. StpObservation (v16.15 W13): stato/designato per porta come
 *      letto dalla sonda L2 (BRIDGE-MIB dot1dStp) — decora le porte
 *      già note dalle fonti 1-3, NON ne aggiunge (nessuna porta nuova).
 * Risoluzione MAC→inventario: confronto con Device.macAddress e
 * Device.extraMacs (JSON array) normalizzati (minuscole, senza
 * separatori). NON risolto → hostname null (UI: «non in inventario»).
 * DECISIONE D20: nessun database OUI/vendor (il motore OUI di v15 non
 * è stato portato) → il produttore del MAC NON è esposto («n.d.»).
 * DECISIONE UPLINK: una porta è uplink quando il peer del TopologyLink
 * è un apparato INFRA secondo la STESSA classificazione dei tier
 * (src/lib/domain/tiers.ts, INFRA_TYPES — la stessa usata da
 * shared.ts buildPlantTiers): GATEWAY, ROUTER, FIREWALL, SWITCH, AP,
 * BRIDGE, REPEATER. Le STA restano escluse (endpoint di rete, non
 * trasporto: differenza dichiarata rispetto a v15 che includeva STA).
 * Onestà: stato live della porta, velocità CORRENTE e PoE richiedono
 * lettura SNMP (modalità riproduzione: NON disponibili — la UI lo
 * dichiara); connectedTo viene SOLO da TopologyLink (mai dedotto dai
 * MAC: nessuna inferenza non richiesta).
 * ================================================================ */

/** Massimo di MAC elencati per porta: il conteggio REALE è macsSeen,
 *  l'elenco è troncato (dichiarato in UI e contratto). */
export const PORT_MACS_SHOWN = 20

export const PortMacEntrySchema = z.object({
  mac: z.string(), // MAC RAW dalla FDB (nel DB reale: minuscolo, senza separatori)
  display: z.string(), // forma AA:BB:CC:DD:EE:FF per la UI (raw se non normalizzabile)
  resolved: z.boolean(), // riconosciuto nell'inventario (macAddress o extraMacs)
  hostname: z.string().nullable(), // null = non in inventario (UI: «non in inventario»)
  deviceId: z.string().nullable(),
  deviceType: z.string().nullable(),
  lastSeenAt: z.number().int(), // ultima osservazione FDB di questo MAC su questa porta
})
export type PortMacEntry = z.infer<typeof PortMacEntrySchema>

export const PortConnectedToSchema = z.object({
  deviceId: z.string(),
  hostname: z.string(),
  type: z.string(),
  ip: z.string().nullable(),
})

export const DevicePortRowSchema = z.object({
  portName: z.string(),
  macsSeen: z.number().int(), // osservazioni FDB sulla porta (0 = nessuna)
  connectedTo: PortConnectedToSchema.nullable(), // SOLO da TopologyLink (null = nessun collegamento noto)
  evidence: z.string().nullable(), // fonte che ha prodotto il collegamento (null = nessun link)
  confidence: z.string().nullable(), // HIGH/MEDIUM/LOW (vuoto = link storici non classificati)
  speedMbps: z.number().int(), // dato del LINK (negoziata storicamente); 0 = sconosciuta
  duplex: z.string(), // '' = sconosciuto (EtherLike-MIB in v15: richiede SNMP live)
  utilization: z.object({ last: z.number(), at: z.number().int() }).nullable(), // ultimo campione della serie port_utilization:<porta> (null = serie assente)
  uplink: z.boolean(), // peer INFRA secondo INFRA_TYPES (decisione D20, vedi header)
  macs: z.array(PortMacEntrySchema), // prime PORT_MACS_SHOWN per ultima osservazione
  // v16.15 W13: dichiarazione STP della porta (BRIDGE-MIB dot1dStp) — null = mai letta
  stp: z.object({ portState: z.string(), designatedBridgeMac: z.string(), isRootPort: z.boolean() }).nullable().optional(),
})
export type DevicePortRow = z.infer<typeof DevicePortRowSchema>

export const DevicePortsSummarySchema = z.object({
  totalPorts: z.number().int(), // union delle porte reali delle tre fonti
  portsWithMacs: z.number().int(),
  macsTotal: z.number().int(), // osservazioni FDB totali dello switch
  resolvedCount: z.number().int(), // MAC riconosciuti nell'inventario (su tutte le osservazioni)
  unattachedMacs: z.number().int(), // osservazioni MAC su porte senza collegamento noto
  windowDeclared: z.object({
    fdbLastSeenAt: z.number().int().nullable(), // ultima osservazione FDB reale (null = nessuna)
    utilCoverage: z.object({ from: z.number().int(), to: z.number().int() }).nullable(), // copertura REALE della serie utilizzazione (null = nessun campione)
  }),
})

export const DevicePortsSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    ports: z.array(DevicePortRowSchema), // uplink prima, poi macsSeen desc, poi nome porta
    summary: DevicePortsSummarySchema,
  }),
})
export type DevicePortsPage = z.infer<typeof DevicePortsSchema>['data']

/* ================================================================
 * /api/v2/mac-inventory — 16.5.0 (W4 anticipata: MAC inventory, FDB ×
 * inventario). Ogni riga è UNA osservazione FDB reale (nel DB
 * dell'impianto «egidio»: 3.307 righe su 20 apparati, congelata al
 * 26/10 09:50 — la nota di copertura è dichiarata in UI col summary).
 * Il summary è GLOBALE (sull'intero dataset, PRIMA dei filtri: è la
 * verità dell'inventario MAC, i filtri cambiano l'elenco non la
 * realtà del dato). Risoluzione come /devices/{id}/ports: confronto
 * normalizzato con Device.macAddress + extraMacs; nessun OUI.
 * v16.15 W13: ogni riga porta anche l'eventuale IP risolto dalla
 * tabella ARP del plant (join per MAC, calcolata SOLO sulle righe
 * della pagina corrente: mai l'intera ArpEntry in memoria).
 * ================================================================ */

export const MacInventoryQuerySchema = z.object({
  plantId: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10, 'pageSize minimo 10').max(200, 'pageSize massimo 200').default(25),
  q: z.string().optional(), // ricerca su MAC o hostname risolto
  switchId: z.string().optional(), // filtra per apparato che ha visto il MAC
  scope: z.enum(['all', 'resolved', 'unresolved']).default('all'),
  sort: z.enum(['lastSeen', 'mac', 'hostname']).default('lastSeen'),
})

export const MacInventoryRowSchema = z.object({
  mac: z.string(), // raw dal DB
  macDisplay: z.string(), // forma AA:BB:CC:DD:EE:FF per la UI
  switchId: z.string(), // apparato che ha appreso il MAC (FDB source)
  switchHostname: z.string(),
  portName: z.string(),
  lastSeenAt: z.number().int(),
  resolved: z.boolean(),
  hostname: z.string().nullable(), // null = non in inventario
  deviceId: z.string().nullable(), // per aprire la scheda del dispositivo risolto
  deviceType: z.string().nullable(),
  // v16.15 W13: IP risolto dalla tabella ARP del plant (join per MAC) — '' se mai visto
  arpIp: z.string().nullable().default(''),
})
export type MacInventoryRow = z.infer<typeof MacInventoryRowSchema>

export const MacInventoryPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(MacInventoryRowSchema),
    total: z.number().int(), // conteggio DOPO i filtri (paginazione reale)
    page: z.number().int(),
    pageSize: z.number().int(),
    pageCount: z.number().int(),
    switches: z.array(z.object({ id: z.string(), hostname: z.string() })), // apparati con osservazioni FDB (filtro)
    summary: z.object({
      resolvedCount: z.number().int(), // GLOBALE: osservazioni riconosciute nell'inventario
      unresolvedCount: z.number().int(), // GLOBALE: osservazioni non in inventario
      lastSeenMax: z.number().int().nullable(), // ultima osservazione reale (serie congelata: dichiarata in UI)
    }),
  }),
})
export type MacInventoryPage = z.infer<typeof MacInventoryPageSchema>['data']

/* ================================================================
 * 16.6 W3.4 — DISCOVERY & ADOZIONE (mini-service :3002)
 * Contratti del motore di scansione portato da v15 (scansione TCP,
 * sonda SNMP v1/v2c/v3, ONVIF GetDeviceInformation, OUI IEEE,
 * discovery UDP Ubiquiti/MNDP/WS-Discovery) e della coda adozione
 * (orfani senza sede + host «da confermare»): la decisione resta
 * SEMPRE umana, nessuna auto-adozione (regola v15 §13.8).
 * ================================================================ */

/** Risposta del servizio discovery (proxy pass-through verificato). */
export const DiscoveryHealthSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    service: z.string(),
    uptimeSec: z.number().int(),
    version: z.string(),
    capabilities: z.array(z.string()), // es. tcp-scan, snmp-v2c-v3, onvif, oui…
    oui: z.object({ total: z.number().int(), brands: z.number().int() }),
  }),
})
export type DiscoveryHealth = z.infer<typeof DiscoveryHealthSchema>['data']

export const ScanHostSchema = z.object({
  ip: z.string(),
  alive: z.literal(true),
  latencyMs: z.number().int(),
  /** v16.8: host che ha risposto solo alla seconda passata del ping. */
  secondPass: z.boolean().optional(),
  openPorts: z.array(z.object({ port: z.number().int(), state: z.string() })),
})
export type ScanHost = z.infer<typeof ScanHostSchema>

/** Input scansione: CIDR fino a /24 (256 host), porte del set v15.
 *  v16.8: `adaptive` attiva la seconda passata di ping sugli host muti. */
export const DiscoveryScanInputSchema = z.object({
  cidr: z.string().trim().regex(/^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\/(3[0-2]|[12]?\d)$/, 'Atteso un CIDR IPv4 (es. 192.168.1.0/24)'),
  ports: z.array(z.number().int().min(1).max(65535)).max(64, 'Massimo 64 porte per scansione').optional(), // assente = set v15
  timeoutMs: z.number().int().min(100).max(3000).optional(),
  maxHosts: z.number().int().min(1).max(256).optional(),
  adaptive: z.boolean().optional(),
}).refine((v) => v.ports === undefined || new Set(v.ports).size === v.ports.length, {
  message: 'Porte duplicate nella richiesta', path: ['ports'],
})
export type DiscoveryScanInput = z.infer<typeof DiscoveryScanInputSchema>

export const DiscoveryScanResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    cidr: z.string(),
    adaptive: z.boolean().optional(),
    durationMs: z.number().int(),
    hosts: z.array(ScanHostSchema), // SOLO host vivi (nessuno = rete muta: onesto)
    summary: z.object({
      scanned: z.number().int(),
      up: z.number().int(),
      withOpenPorts: z.number().int(),
      slowHosts: z.number().int().optional(),
    }),
  }),
})
export type DiscoveryScanResult = z.infer<typeof DiscoveryScanResultSchema>['data']

/** Sonda combinata: evidenze fuse ONVIF > SNMP > banner > porte.
 *  v16.8: `communities` (lista tentata in ordine dal servizio) e campo
 *  `adaptive` della scansione a due passate. */
export const VendorProbeInputSchema = z.object({
  ip: z.string().trim().regex(/^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/, 'Atteso un indirizzo IPv4'),
  snmp: z.object({
    community: z.string().min(1).max(64).optional(),
    /** v16.8: fino a 8 community tentate in ordine. */
    communities: z.array(z.string().min(1).max(64)).max(8, 'Massimo 8 community per sonda').optional(),
    version: z.enum(['v1', 'v2c', 'v3']).optional(),
  }).optional(),
  onvif: z.object({ user: z.string().max(64).optional(), pass: z.string().max(128).optional() }).optional(),
  timeoutMs: z.number().int().min(300).max(5000).optional(),
})
export type VendorProbeInput = z.infer<typeof VendorProbeInputSchema>

export const VendorProbeResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    ip: z.string(),
    alive: z.boolean(),
    latencyMs: z.number().int().nullable(),
    /** v16.8: true se la risposta è arrivata alla seconda passata (host lento). */
    slowHost: z.boolean().optional(),
    openPorts: z.array(z.object({ port: z.number().int(), state: z.string() })),
    http: z.object({
      server: z.string().nullable(),
      title: z.string().nullable(),
      realm: z.string().optional().nullable(),
      certCn: z.string().optional().nullable(),
      certIssuer: z.string().optional().nullable(),
    }).nullable(),
    snmp: z.object({
      reachable: z.boolean(),
      /** v16.8: community+versione che ha risposto. */
      matched: z.object({ community: z.string(), version: z.string() }).optional().nullable(),
      sysDescr: z.string().optional().nullable(),
      sysObjectID: z.string().optional().nullable(),
      sysName: z.string().optional().nullable(),
      ifCount: z.number().int().optional().nullable(),
      vendorGuess: z.object({ vendor: z.string(), source: z.string() }).optional().nullable(),
      /** v16.8: identità prodotto dal sysDescr (os/modello/versione). */
      product: z.object({
        osFamily: z.string().nullable(),
        osVersion: z.string().nullable(),
        model: z.string().nullable(),
        source: z.string(),
      }).optional().nullable(),
      error: z.string().optional(),
    }).nullable(),
    onvif: z.object({
      reachable: z.boolean(),
      manufacturer: z.string().optional().nullable(),
      model: z.string().optional().nullable(),
      firmwareVersion: z.string().optional().nullable(),
      serialNumber: z.string().optional().nullable(),
      hardwareId: z.string().optional().nullable(),
      error: z.string().optional(),
    }).nullable(),
    oui: z.object({ mac: z.string(), vendor: z.string(), category: z.string() }).nullable(),
    classification: z.object({
      type: z.string(), // vocabolario v15+v16.8 (CAMERA, LPR, NVR, SWITCH, GATEWAY, AP, UPS, PRINTER, PBX, PHONE, NAS, MODEM, SERVER…)
      brand: z.string().nullable(),
      model: z.string().nullable(),
      confidence: z.enum(['high', 'medium', 'low']),
      /** v16.8: identità dichiarata dall'apparato. */
      os: z.string().nullable().optional(),
      osVersion: z.string().nullable().optional(),
      firmwareVersion: z.string().nullable().optional(),
      evidence: z.array(z.object({ source: z.string(), value: z.string() })),
    }),
  }),
})
export type VendorProbeResult = z.infer<typeof VendorProbeResultSchema>['data']

/** Lookup OUI puro (MAC → vendor IEEE). */
export const OuiLookupResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    mac: z.string(),
    prefix: z.string(),
    vendor: z.string(),
    category: z.string(), // RADIO, CAMERA, SWITCH, GENERIC… (triage v15)
    blockType: z.string(), // MA-L 24 bit · MA-M 28 · MA-S 36
  }),
})
export type OuiLookupResult = z.infer<typeof OuiLookupResultSchema>['data']

/* ---------------- v16.8 — Identificazione batch ---------------- */

/** Identificazione di N IP in UNA richiesta (il «puller» fa UN solo
 *  round-trip verso il mini-service invece di N fetch sequenziali). */
export const VendorBatchInputSchema = z.object({
  targets: z.array(z.string().trim().regex(/^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/, 'Attesi indirizzi IPv4')).min(1, 'Almeno un IP').max(32, 'Massimo 32 target per batch'),
  snmp: z.object({
    community: z.string().min(1).max(64).optional(),
    communities: z.array(z.string().min(1).max(64)).max(8).optional(),
    version: z.enum(['v1', 'v2c', 'v3']).optional(),
  }).optional(),
  onvif: z.object({ user: z.string().max(64).optional(), pass: z.string().max(128).optional() }).optional(),
  timeoutMs: z.number().int().min(300).max(4000).optional(),
  concurrency: z.number().int().min(1).max(16).optional(),
}).refine((v) => new Set(v.targets).size === v.targets.length, {
  message: 'IP duplicati nella richiesta', path: ['targets'],
})
export type VendorBatchInput = z.infer<typeof VendorBatchInputSchema>

export const VendorBatchResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    concurrency: z.number().int(),
    durationMs: z.number().int(),
    total: z.number().int(),
    alive: z.number().int(),
    classified: z.number().int(),
    results: z.array(VendorProbeResultSchema.shape.data),
  }),
})
export type VendorBatchResult = z.infer<typeof VendorBatchResultSchema>['data']

/* ---------------- v16.8 — Sonda Layer-2 e ricostruzione bridge ---------------- */

/** Sonda L2 di UN apparato del plant (switch/router): LLDP+CDP+FDB+
 *  interfacce → ricostruzione link + persistenza osservazioni MAC.
 *  Le community aggiuntive vengono tentate DOPO quella cifrata del
 *  dispositivo (che resta la prima). */
export const DiscoveryL2InputSchema = z.object({
  plantId: z.string().optional(),
  deviceId: z.string().min(1, 'Il dispositivo switch da sondare è obbligatorio'),
  communities: z.array(z.string().min(1).max(64)).max(8, 'Massimo 8 community aggiuntive').optional(),
  timeoutMs: z.number().int().min(300).max(8000).optional(),
})
export type DiscoveryL2Input = z.infer<typeof DiscoveryL2InputSchema>

export const L2ReconstructedLinkSchema = z.object({
  switchDeviceId: z.string(),
  targetDeviceId: z.string(),
  targetHostname: z.string(),
  targetIp: z.string(),
  sourcePort: z.string(),
  /** v16.15 — numero porta bridge (dot1d) della porta sorgente
   *  (0 = ignoto): il correlatore multi-switch lo usa per l'abbinamento
   *  con l'STP. Default: le risposte PRE-v16.15 non lo portano. */
  sourcePortNum: z.number().int().default(0),
  targetPort: z.string(),
  sourceOfTruth: z.enum(['LLDP', 'CDP', 'FDB', 'DAISY_CHAIN']),
  confidence: z.enum(['HIGH', 'MEDIUM', 'LOW']),
  evidence: z.string(),
  speedMbps: z.number().int(),
  /** v16.18 W20 — duplex della porta dello switch (dot3StatsDuplexStatus,
   *  EtherLike-MIB): null = MIB assente o unknown. Default retrocompat. */
  duplex: z.enum(['full', 'half']).nullable().default(null),
  /** v16.15 — TRUE se il bridge designato STP della porta coincide col
   *  MAC del dispositivo collegato (l'albero spanning conferma il cavo). */
  stpCorroborated: z.boolean().default(false),
  detail: z.string(),
})

export const DiscoveryL2ResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    switch: z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      sysName: z.string().nullable(),
      matched: z.object({ community: z.string(), version: z.string() }).nullable(),
    }),
    reachable: z.boolean(),
    error: z.string().optional(),
    detail: z.string().optional(),
    links: z.array(L2ReconstructedLinkSchema),
    unmatchedNeighbors: z.array(z.object({ via: z.enum(['LLDP', 'CDP']), name: z.string(), port: z.string().nullable() })),
    sharedPorts: z.array(z.object({ port: z.string(), devices: z.array(z.string()) })),
    /* --- v16.15 W13 — blocchi opzionali RETROCOMPATIBILI: le risposte
     *     pre-v16.15 restano valide così come sono (additivo, §8). --- */
    /** MAC visti in FDB/ARP ma NON in inventario, con IP risolto
     *  dall'ARP: il ponte onesto verso l'adozione (mai auto-adottati). */
    unmatchedMacsWithIp: z.array(z.object({
      mac: z.string(),
      ip: z.string(),
      portName: z.string(),
    })).optional(),
    /** Riassunto STP dell'apparato (null = STP assente/muto). */
    stp: z.object({
      present: z.boolean(),
      protocol: z.string(),
      bridgeMac: z.string(),
      rootBridgeMac: z.string(),
      rootPort: z.number().int(),
      corroboratedLinks: z.number().int(),
    }).nullable().optional(),
    /** VLAN dichiarate (Q-BRIDGE) con porte egress risolte in nomi. */
    vlans: z.array(z.object({
      vlanId: z.number().int(),
      name: z.string(),
      ports: z.string(), // CSV di nomi porta (solo report)
    })).optional(),
    /** Voci ARP utili (report tagliato a 32 righe: la persistenza è
     *  un'altra cosa — vedi persistence.arpSaved e stats.arpEntries). */
    arp: z.array(z.object({
      ip: z.string(),
      mac: z.string(),
      ifIndex: z.number().int(),
      type: z.string(), // dynamic | static | other
    })).optional(),
    warnings: z.array(z.string()),
    persistence: z.object({
      linksCreated: z.number().int(),
      linksUpdated: z.number().int(),
      linksSkippedOperator: z.number().int(),
      observationsSaved: z.number().int(),
      /* v16.15 — contatori dei tre nuovi dataset (opzionali: le
       * risposte pre-v16.15 non li portano). */
      arpSaved: z.number().int().optional(),
      stpSaved: z.number().int().optional(),
      vlanSaved: z.number().int().optional(),
    }),
    stats: z.object({
      lldpNeighbors: z.number().int(),
      cdpNeighbors: z.number().int(),
      fdbEntries: z.number().int(),
      vlanFdbEntries: z.number().int(),
      matchedLinks: z.number().int(),
      observations: z.number().int(),
      unmatchedNeighbors: z.number().int(),
      sharedPorts: z.number().int(),
      /* v16.15 — contatori dei nuovi dataset (opzionali: additivo). */
      arpEntries: z.number().int().optional(),
      stpPorts: z.number().int().optional(),
      vlans: z.number().int().optional(),
      unmatchedMacsWithIp: z.number().int().optional(),
    }),
  }),
})
export type DiscoveryL2Result = z.infer<typeof DiscoveryL2ResultSchema>['data']

/* ---------------- v16.15 W14 — Sonda L2 BATCH multi-switch ---------------- */

/** Batch L2 (≤12 apparati): UNA richiesta verso il mini-service che
 *  sonda in parallelo (concurrency 1-4) TUTTI gli switch dell'impianto
 *  o una selezione esplicita; la rotta correla le sonde (l2Correlate)
 *  e persiste ARP/STP/VLAN per ognuno. Se `deviceIds` è assente la
 *  selezione è automatica (SWITCH/GATEWAY/ROUTER/FIREWALL attivi). */
export const DiscoveryL2BatchInputSchema = z.object({
  plantId: z.string().optional(),
  deviceIds: z.array(z.string().min(1, 'Il deviceId non può essere vuoto')).min(1, 'Almeno un apparato per il batch').max(12, 'Massimo 12 apparati per batch L2').optional(),
  communities: z.array(z.string().min(1).max(64)).max(8, 'Massimo 8 community aggiuntive').optional(),
  concurrency: z.number().int().min(1).max(4).optional(),
  timeoutMs: z.number().int().min(300).max(8000).optional(),
})
export type DiscoveryL2BatchInput = z.infer<typeof DiscoveryL2BatchInputSchema>

/** Link switch↔switch del correlatore (l2-correlate): ENTRAMBE le
 *  porte note per gli avvistamenti mutui, direzione verso la root STP,
 *  fonte (FDB_MUTUAL/FDB_PAIR/STP_DESIGNATED) e corroboration STP. */
export const CorrelatedSwitchLinkSchema = z.object({
  /** Dispositivo A MONTE (upstream, verso la root). */
  upstreamDeviceId: z.string(),
  upstreamHostname: z.string(),
  upstreamPort: z.string(),
  upstreamPortNum: z.number().int(),
  upstreamSpeedMbps: z.number().int(),
  /** Dispositivo a VALLE (downstream). */
  downstreamDeviceId: z.string(),
  downstreamHostname: z.string(),
  downstreamPort: z.string(),
  downstreamPortNum: z.number().int(),
  downstreamSpeedMbps: z.number().int(),
  kind: z.enum(['FDB_MUTUAL', 'FDB_PAIR', 'STP_DESIGNATED']),
  confidence: z.enum(['HIGH', 'MEDIUM']),
  evidence: z.string(),
  /** TRUE se l'STP concorda con la direzione (designato/rootPort). */
  stpCorroborated: z.boolean(),
  detail: z.string(),
})
export type CorrelatedSwitchLink = z.infer<typeof CorrelatedSwitchLinkSchema>

/** Esito per apparato del batch: contatori VERI della sonda (gli
 *  stessi del report singolo) + avvisi onesti per switch. */
export const L2BatchSwitchResultSchema = z.object({
  deviceId: z.string(),
  hostname: z.string(),
  ip: z.string(),
  reachable: z.boolean(),
  matched: z.object({ community: z.string(), version: z.string() }).nullable(),
  sysName: z.string().nullable(),
  stats: z.object({
    lldpNeighbors: z.number().int(),
    cdpNeighbors: z.number().int(),
    fdbEntries: z.number().int(),
    vlanFdbEntries: z.number().int(),
    arpEntries: z.number().int(),
    stpPorts: z.number().int(),
    vlans: z.number().int(),
    matchedLinks: z.number().int(),
    unmatchedNeighbors: z.number().int(),
    sharedPorts: z.number().int(),
    unmatchedMacsWithIp: z.number().int(),
    observations: z.number().int(),
  }),
  warnings: z.array(z.string()),
})
export type L2BatchSwitchResult = z.infer<typeof L2BatchSwitchResultSchema>

export const DiscoveryL2BatchResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    /** Apparati realmente sondati (post dedup ip:porta e cap 12). */
    scanned: z.number().int(),
    reachable: z.number().int(),
    concurrency: z.number().int(),
    durationMs: z.number().int(),
    /** Link switch↔switch dal correlatore (report COMPLETO: la
     *  persistenza può saltare le coppie già coperte da LLDP/CDP). */
    switchLinks: z.array(CorrelatedSwitchLinkSchema),
    /** Root bridge STP votata dalla maggioranza ('' = nessuno dichiara). */
    rootBridgeMac: z.string(),
    rootVotes: z.number().int(),
    rootPorts: z.array(z.object({
      deviceId: z.string(),
      hostname: z.string(),
      portNum: z.number().int(),
      portName: z.string(),
    })),
    /** MAC→IP non inventariati visti dall'ARP degli switch sondati
     *  (candidati adozione — la scelta resta UMANA). */
    arpCandidates: z.array(z.object({
      mac: z.string(),
      ip: z.string(),
      seenBy: z.string(),
    })),
    perSwitch: z.array(L2BatchSwitchResultSchema),
    persistence: z.object({
      linksCreated: z.number().int(),
      linksUpdated: z.number().int(),
      linksSkippedOperator: z.number().int(),
      observationsSaved: z.number().int(),
      arpSaved: z.number().int(),
      stpSaved: z.number().int(),
      vlanSaved: z.number().int(),
    }),
    warnings: z.array(z.string()),
  }),
})
export type DiscoveryL2BatchResult = z.infer<typeof DiscoveryL2BatchResultSchema>['data']

/* ---------------- Adozione candidato ARP (v16.16 W17-a) ---------------- */

/** Vocabolario tipi per l'adozione di un candidato ARP: l'enum Device
 *  + i tipi endpoint del mondo reale portati dal classificatore v16.8
 *  (UPS, PRINTER, PBX, PHONE, NAS, MODEM) + FIREWALL (L2 batch). */
export const ARP_ADOPTION_TYPES = [
  'AP', 'STA', 'CAMERA', 'LPR', 'SWITCH', 'NVR', 'GATEWAY', 'SERVER', 'UNKNOWN', 'ONT', 'ROUTER',
  'FIREWALL', 'UPS', 'PRINTER', 'PBX', 'PHONE', 'NAS', 'MODEM',
] as const

/** Connection types accettate (vocabolario link consolidato): la scelta
 *  è una DICHIARAZIONE dell'operatore, non un'inferenza del sistema. */
export const ARP_ADOPTION_CONNECTION_TYPES = ['ETHERNET', 'RADIO', 'FIBRA', 'UTP_COPPER', 'WIRELESS_BRIDGE'] as const

/** POST /api/v2/discovery/l2/adopt-arp — crea il dispositivo da un
 *  MAC→IP visto dall'ARP di uno switch e NON ancora in inventario.
 *  La decisione è UMANA (il report li elenca come candidati): il corpo
 *  porta la dichiarazione dell'operatore, il server verifica che il
 *  MAC sia ancora libero e l'IP non confligga. */
export const ArpAdoptionInputSchema = z.object({
  /** MAC del candidato come riportato dal report batch (normalizzato
   *  AA:BB:CC:DD:EE:FF — il server ri-normalizza e rifiuta il resto). */
  mac: z.string().trim().regex(/^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$|^([0-9A-Fa-f]{12})$/, 'Atteso un MAC (es. AA:BB:CC:DD:EE:FF)'),
  ip: z.string().trim().regex(/^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/, 'Atteso un indirizzo IPv4'),
  hostname: z.string().trim().min(1, 'Il nome è obbligatorio').max(80, 'Massimo 80 caratteri'),
  type: z.enum(ARP_ADOPTION_TYPES),
  connectionType: z.enum(ARP_ADOPTION_CONNECTION_TYPES).default('ETHERNET'),
  locationId: z.string().min(1).optional(),
  notes: z.string().trim().max(500, 'Massimo 500 caratteri').optional(),
})
export type ArpAdoptionInput = z.infer<typeof ArpAdoptionInputSchema>

export const ArpAdoptionResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    id: z.string(),
    hostname: z.string(),
    ip: z.string(),
    macAddress: z.string(),
    type: z.string(),
    brand: z.string(),
    connectionType: z.string(),
    locationId: z.string().nullable(),
    locationName: z.string().nullable(),
    baselineUntil: z.string().nullable(),
    /** Da dove viene l'EVIDENZA reale del MAC nel DB (righe scritte
     *  dalle sonde): ARP = ArpEntry, FDB = FdbObservation, REPORT =
     *  solo il report batch in memoria (riga mai persistita, es. cap). */
    evidence: z.enum(['ARP', 'FDB', 'REPORT']),
    /** Hostname dello switch che ha visto il MAC (dalla riga di
     *  evidenza; null se nessuna riga). */
    seenBy: z.string().nullable(),
    /** Vendor IEEE dal database OUI (10.679 prefissi), '' se lookup
     *  non disponibile: mai inventato. */
    ouiVendor: z.string(),
  }),
})
export type ArpAdoptionResult = z.infer<typeof ArpAdoptionResultSchema>['data']

/* ================================================================
 * v16.18 W19 — ATTIVAZIONE SNMP ASSISTITA + MONITORAGGIO PING
 * ================================================================
 * «Una volta identificato il prodotto e il modello esatto, provare
 * dopo conferma l'attivazione SNMP» (decisione operatore 31/10/2026).
 * TRE attori separati, come sempre in v16:
 *   · la SONDA resta in SOLA LETTURA (mai SET SNMP);
 *   · l'ATTUATORE esegue una RICETTA per-vendor (SSH o API HTTP SwOS)
 *     SOLO dopo conferma umana esplicita: la finestra mostra i comandi
 *     IN CHIARO prima dell'esecuzione;
 *   · la DICHIARAZIONE (ping-only per le telecamere, MANUAL_REQUIRED
 *     per i vendor senza CLI) NON tocca MAI il dispositivo.
 * Stati persistenti sul Device (schema Prisma): '' mai tentata ·
 * ENABLED applicata E verificata con la sonda · ENABLED_UNVERIFIED
 * applicata ma agente non ancora in ascolto · FAILED non applicata ·
 * MANUAL_REQUIRED nessuna automazione possibile (fare a mano).
 * ================================================================ */

/* I vocabolari SNMP_ENABLE_STATES / MONITOR_MODES sono definiti in
 * testa al file (prima del primo uso in DeviceRowSchema). */

/** Trasporti delle ricette (catalogo del mini-service :3002). */
export const RECIPE_TRANSPORTS = ['ssh', 'http-swos', 'manual', 'ping-only'] as const
export type RecipeTransport = (typeof RECIPE_TRANSPORTS)[number]

/** Passo di ricetta così come l'operatore lo vede nella preview. */
export const SnmpRecipeStepSchema = z.object({
  cmd: z.string(),
  note: z.string().nullable(),
  fatal: z.boolean(),
  benign: z.string().nullable(),
})

/** Ricetta pianificata (comandi GIA' interpolati con community/
 *  contact/location): preview a zero scritture. */
export const SnmpRecipePlanSchema = z.object({
  recipeId: z.string(),
  vendor: z.string(),
  family: z.string(),
  transport: z.enum(RECIPE_TRANSPORTS),
  confidence: z.enum(['verified', 'high', 'medium']),
  source: z.string(),
  note: z.string(),
  webPath: z.string().nullable(),
  steps: z.array(SnmpRecipeStepSchema),
  manualSteps: z.array(z.string()),
})
export type SnmpRecipePlan = z.infer<typeof SnmpRecipePlanSchema>

/** POST /api/v2/discovery/snmp-enable/plan — la PREVIEW per un
 *  dispositivo: ricetta scelta su marca/modello/tipo DELL'INVENTARIO
 *  (o override umano) + comandi interpolati + alternative a tendina.
 * Nessuna scrittura, nessun contatto con l'apparato. */
export const SnmpEnablePlanInputSchema = z.object({
  deviceId: z.string().min(1),
  /** Override esplicito dell'operatore (es. CRS con SwOS invece di
   *  RouterOS): se assente/ignoto si usa il pick automatico. */
  recipeId: z.string().trim().optional(),
  community: z.string().trim().max(64).optional(),
  contact: z.string().trim().max(64).optional(),
  location: z.string().trim().max(64).optional(),
})
export type SnmpEnablePlanInput = z.infer<typeof SnmpEnablePlanInputSchema>

export const SnmpEnablePlanResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    /** Identità del dispositivo così com'è nell'inventario (evidenza
     *  da cui parte il pick: marca/modello/tipo DECHIARATI). */
    device: z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
      brand: z.string(),
      model: z.string(),
      snmpPort: z.number().int(),
      snmpEnableState: z.enum(SNMP_ENABLE_STATES),
      monitorMode: z.enum(MONITOR_MODES),
      /** Credenziali SSH cifrate presenti sul dispositivo? (username
       *  + password: il NOME utente non è un segreto e si mostra; la
       *  password MAI — l'operatore può usarla senza riscriverla). */
      hasSavedCredentials: z.boolean(),
      savedUsername: z.string(),
    }),
    picked: z.string(),
    /** true = ricetta «presenza ICMP» (telecamere): nessuna azione
     *  sull'apparato, solo la dichiarazione monitorMode='ping'. */
    pingOnly: z.boolean(),
    recipe: SnmpRecipePlanSchema,
    alternatives: z.array(z.object({
      recipeId: z.string(),
      label: z.string(),
      transport: z.string(),
    })),
  }),
})
export type SnmpEnablePlanResult = z.infer<typeof SnmpEnablePlanResultSchema>['data']

/** POST /api/v2/discovery/snmp-enable — ESEGUI la ricetta confermata.
 *  Il contatto con l'apparato avviene SONO qui e SOLO per i trasporti
 *  ssh/http-swos; le ricette manual/ping-only sono DICHIARAZIONI
 *  (MANUAL_REQUIRED / monitorMode='ping') senza alcun contatto. */
export const SnmpEnableInputSchema = z.object({
  deviceId: z.string().min(1),
  recipeId: z.string().trim().min(1, 'recipeId richiesto (dalla preview)'),
  community: z.string().trim().min(1, 'La community è obbligatoria').max(64).default('public'),
  contact: z.string().trim().max(64).default('FALCO-OS'),
  location: z.string().trim().max(64).default(''),
  /** Porta SNMP per la verifica finale (default: quella del device). */
  snmpPort: z.number().int().min(1).max(65535).optional(),
  /** Credenziali SSH fornite NELLA FINESTRA: se assenti si usano quelle
   *  CIFRATE del dispositivo; se fornite NON vengono persistite. */
  ssh: z.object({
    port: z.number().int().min(1).max(65535).optional(),
    username: z.string().trim().min(1, 'Utente SSH richiesto').max(64),
    password: z.string().min(1, 'Password SSH richiesta').max(128),
  }).optional(),
  /** SwOS: credenziali del pannello web (digest). Password vuota =
   *  default tipico SwOS (l'operatore la conferma in finestra). */
  swos: z.object({
    port: z.number().int().min(1).max(65535).optional(),
    username: z.string().trim().min(1).max(64).default('admin'),
    password: z.string().max(128).default(''),
  }).optional(),
})
export type SnmpEnableInput = z.infer<typeof SnmpEnableInputSchema>

/** Esito di UN passo dell'attuazione (output integro, mai tagliato
 *  oltre il clamp del servizio: onestà su ciò che l'apparato ha detto). */
export const SnmpEnableStepResultSchema = z.object({
  step: z.string(),
  note: z.string().nullable(),
  ok: z.boolean(),
  exitCode: z.number().int().nullable(),
  output: z.string(),
  benign: z.boolean(),
})

export const SnmpEnableResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    recipeId: z.string(),
    transport: z.enum(RECIPE_TRANSPORTS),
    applied: z.boolean(),
    steps: z.array(SnmpEnableStepResultSchema),
    verify: z.object({
      reachable: z.boolean(),
      matchedCommunity: z.string().nullable(),
      sysName: z.string().nullable(),
      sysDescr: z.string().nullable(),
      error: z.string().nullable(),
    }),
    state: z.enum(SNMP_ENABLE_STATES),
    notes: z.array(z.string()),
    /** Effetti PERSISTITI sul Device (ciò che la UI mostrerà da qui
     *  in poi: stato + metodo + modalità di monitoraggio). */
    persisted: z.object({
      snmpEnableState: z.enum(SNMP_ENABLE_STATES),
      snmpEnableMethod: z.string(),
      monitorMode: z.enum(MONITOR_MODES),
      communitySaved: z.boolean(), // community CIFRATA salvata sul device (se ENABLED)
    }),
  }),
})
export type SnmpEnableResult = z.infer<typeof SnmpEnableResultSchema>['data']

/** POST /api/v2/discovery/snmp-enable/verify — riverifica post-
 *  abilitazione (ENABLED_UNVERIFIED: l'agente può impiegare secondi
 *  a partire). Sonda read-only con la community CIFRATA del device. */
export const SnmpVerifyResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    deviceId: z.string(),
    reachable: z.boolean(),
    matchedCommunity: z.string().nullable(),
    sysName: z.string().nullable(),
    sysDescr: z.string().nullable(),
    error: z.string().nullable(),
    snmpEnableState: z.enum(SNMP_ENABLE_STATES),
  }),
})
export type SnmpVerifyResult = z.infer<typeof SnmpVerifyResultSchema>['data']

/** POST /api/v2/monitoring/ping — spazzata di presenza sui dispositivi
 *  in modalità ping-only (telecamere): la sonda TCP-adattiva del
 *  servizio discovery misura vivo/latenza, i campioni packetLoss/
 *  pingLatency vengono scritti (storico), lo stato aggiornato con
 *  onestà. È il «poller» dichiarato della modalità ping. */
export const PingSweepInputSchema = z.object({
  /** Singolo apparato; assente = TUTTI i ping-mode del plant attivo. */
  deviceId: z.string().min(1).optional(),
})
export type PingSweepInput = z.infer<typeof PingSweepInputSchema>

export const PingSweepResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    swept: z.number().int(),
    alive: z.number().int(),
    durationMs: z.number().int(),
    results: z.array(z.object({
      deviceId: z.string(),
      hostname: z.string(),
      ip: z.string(),
      port: z.number().int(),
      alive: z.boolean(),
      latencyMs: z.number().nullable(),
      dbStatus: z.string(), // stato PRIMA dello sweep (onestà del confronto)
      newStatus: z.string(), // stato DOPO (ONLINE/OFFLINE)
      samplesWritten: z.number().int(),
    })),
  }),
})
export type PingSweepResult = z.infer<typeof PingSweepResultSchema>['data']

/* ---------------- Coda adozione (portata da v15 §13.8) ---------------- */

export const AdoptionCandidateSchema = z.object({
  id: z.string(),
  hostname: z.string(),
  type: z.string(), // grezzo dal DB (UNKNOWN finché non classificato)
  brand: z.string().nullable(),
  model: z.string().nullable(),
  macAddress: z.string().nullable(),
  ip: z.string().nullable(),
  firmwareVersion: z.string().nullable(),
  lastSeenAt: z.number().int().nullable(), // null = mai visto (onesto: «mai visto»)
  status: z.string(),
  requiresConfirmation: z.boolean(),
})
export type AdoptionCandidate = z.infer<typeof AdoptionCandidateSchema>

export const AdoptionQueueSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    orphans: z.array(AdoptionCandidateSchema), // senza sede (locationId null) — scope impianto
    toConfirm: z.array(AdoptionCandidateSchema), // requiresConfirmation=true (impianti sensibili GAP 2)
    locations: z.array(z.object({ id: z.string(), name: z.string() })), // sedi reali per la scelta
  }),
})
export type AdoptionQueue = z.infer<typeof AdoptionQueueSchema>['data']

/** Azione di adozione: SEMPRE umana. adopt assegna la sede; dismiss
 * (solo per «da confermare») archivia la richiesta senza toccare il
 * dispositivo. Entrambe scrivono audit ADOZIONE_*. */
export const AdoptionActionSchema = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('adopt'),
    deviceId: z.string().min(1),
    locationId: z.string().min(1),
  }),
  z.object({
    action: z.literal('dismiss'),
    deviceId: z.string().min(1),
  }),
])
export type AdoptionAction = z.infer<typeof AdoptionActionSchema>

/* ================================================================
 * 16.7 W3.5+W7.0 — OPERAZIONI EVOLUTE + INTEGRAZIONI
 * Contratti per: regole evento (AlertRule, 10 SYS reali + utente),
 * OID custom (+ test SNMP live), richieste configurazione con
 * guardrail/commit-confirm, bulk-config dry-run, firmware job,
 * playbook, automation task, configurazioni integrazione cifrate
 * AES-256-GCM, webhook con firma HMAC-SHA256 e consegna reale.
 * Onestà: tabelle vuote = empty state; esecuzione SSH/poller NON
 * disponibile in replay → dry-run dichiarato o 422 REPLAY_NOEXEC.
 * ================================================================ */

/* ---------------- Vocabolari documentati (dal v15) ---------------- */

export const POLICY_METRICS = [
  'anomalyScore', 'cameraStreamAlive', 'cameraRtt', 'freqChange', 'linkChange',
  'unknownHost', 'packetLoss', 'pingJitter', 'pingLatency', 'portMoved',
  'port_utilization', 'signalStrength', 'linkQuality', 'cpuLoad',
  'memoryUsage', 'temperature', 'reachable',
] as const
export const POLICY_COMPARISONS = ['gt', 'lt', 'eq', 'ne', 'between'] as const
export const POLICY_SCOPES = ['ALL', 'SITE', 'DEVICE', 'LINK'] as const
export const POLICY_SEVERITIES = ['INFO', 'WARNING', 'AVERAGE', 'HIGH', 'CRITICAL'] as const
export const EXECUTORS = ['SSH', 'SIMULATED'] as const

/** Pattern DISTRUTTIVI vietati nei comandi (guardrail v15): la
 * richiesta viene RIFIUTATA alla creazione, mai silenziata. */
export const FORBIDDEN_COMMAND_PATTERNS: Array<{ re: RegExp; label: string }> = [
  { re: /rm\s+-rf/i, label: 'cancellazione ricorsiva (rm -rf)' },
  { re: /erase\s+flash/i, label: 'cancellazione flash' },
  { re: /factory[-\s]?reset/i, label: 'reset di fabbrica' },
  { re: /^format\s/im, label: 'formattazione' },
  { re: /shutdown/i, label: 'spegnimento' },
  { re: /dd\s+if=/i, label: 'scrittura raw disco (dd)' },
]
export const CONFIG_MAX_COMMANDS = 50
export const BULK_MAX_TARGETS = 50 // v15 R8: tetto dispositivi per ondata
export const BULK_MAX_COMMANDS = 30

/* ---------------- Regole evento (event-policies) ---------------- */

export const EventPolicyRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  enabled: z.boolean(),
  systemKey: z.string().nullable(), // SYS:* = regola di sistema (NON eliminabile)
  metric: z.string(),
  deviceTypes: z.array(z.string()), // [] = tutti i tipi
  scopeType: z.enum(POLICY_SCOPES),
  scopeIds: z.array(z.string()),
  comparison: z.enum(POLICY_COMPARISONS),
  threshold: z.number(),
  recoveryThreshold: z.number().nullable(),
  betweenMax: z.number().nullable(),
  sustainSeconds: z.number().int(),
  severity: z.enum(POLICY_SEVERITIES),
  escalateAfterMinutes: z.number().int(),
  cooldownMinutes: z.number().int(),
  maintenanceStart: z.string(), // "" = nessuna finestra
  maintenanceEnd: z.string(),
  maintenanceDays: z.array(z.number().int()),
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type EventPolicyRow = z.infer<typeof EventPolicyRowSchema>

export const EventPoliciesPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(EventPolicyRowSchema), // SYS prima (per systemKey), poi utente per name
    total: z.number().int(),
    systemCount: z.number().int(), // regole SYS reali (10 nel DB egidio)
    userCount: z.number().int(),
  }),
})
export type EventPoliciesPage = z.infer<typeof EventPoliciesPageSchema>['data']

export const CreateEventPolicyInputSchema = z.object({
  name: z.string().trim().min(3, 'Nome troppo corto (minimo 3 caratteri)').max(120, 'Nome troppo lungo (massimo 120)'),
  description: z.string().max(500).optional(),
  metric: z.enum(POLICY_METRICS, { message: 'Metrica non valida (vocabolario del dominio)' }),
  deviceTypes: z.array(z.string().min(1)).max(20).optional(), // validati contro i tipi REALI dell'inventario
  scopeType: z.enum(POLICY_SCOPES).optional(), // default ALL
  scopeIds: z.array(z.string().min(1)).max(200).optional(), // validati contro sedi/dispositivi REALI
  comparison: z.enum(POLICY_COMPARISONS),
  threshold: z.number().finite(),
  recoveryThreshold: z.number().finite().nullable().optional(),
  betweenMax: z.number().finite().nullable().optional(), // OBBLIGATORIO se comparison=between
  sustainSeconds: z.number().int().min(0).max(86400).optional(),
  severity: z.enum(POLICY_SEVERITIES).optional(),
  escalateAfterMinutes: z.number().int().min(0).max(10080).optional(),
  cooldownMinutes: z.number().int().min(1).max(1440).optional(),
}).refine((v) => v.comparison !== 'between' || v.betweenMax != null, {
  message: 'Il confronto «between» richiede betweenMax', path: ['betweenMax'],
}).refine((v) => v.comparison !== 'between' || (v.betweenMax != null && v.betweenMax > v.threshold), {
  message: 'betweenMax deve essere maggiore di threshold', path: ['betweenMax'],
})
export type CreateEventPolicyInput = z.infer<typeof CreateEventPolicyInputSchema>

/** SYS: tuning operativo (enabled/soglie/cooldown/severità) MAI
 * struttura o cancellazione; utente: tutto tranne systemKey. */
export const UpdateEventPolicyInputSchema = z.object({
  enabled: z.boolean().optional(),
  name: z.string().trim().min(3).max(120).optional(),
  description: z.string().max(500).optional(),
  metric: z.enum(POLICY_METRICS).optional(),
  deviceTypes: z.array(z.string().min(1)).max(20).optional(),
  scopeType: z.enum(POLICY_SCOPES).optional(),
  scopeIds: z.array(z.string().min(1)).max(200).optional(),
  comparison: z.enum(POLICY_COMPARISONS).optional(),
  threshold: z.number().finite().optional(),
  recoveryThreshold: z.number().finite().nullable().optional(),
  betweenMax: z.number().finite().nullable().optional(),
  sustainSeconds: z.number().int().min(0).max(86400).optional(),
  severity: z.enum(POLICY_SEVERITIES).optional(),
  escalateAfterMinutes: z.number().int().min(0).max(10080).optional(),
  cooldownMinutes: z.number().int().min(1).max(1440).optional(),
})

/* ---------------- OID custom ---------------- */

export const CustomOidRowSchema = z.object({
  id: z.string(),
  name: z.string(), // univoco, es. "ccq.athena"
  oid: z.string(),
  unit: z.string(),
  scale: z.number(),
  dataType: z.enum(['FLOAT', 'INT', 'COUNTER']),
  intervalSec: z.number().int(),
  description: z.string(),
  enabled: z.boolean(),
  appliedCount: z.number().int(), // statistiche oneste: 0 nel replay
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type CustomOidRow = z.infer<typeof CustomOidRowSchema>

export const CustomOidsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(CustomOidRowSchema), // per name asc
    total: z.number().int(), // 0 = nessun OID custom (onesto)
  }),
})
export type CustomOidsPage = z.infer<typeof CustomOidsPageSchema>['data']

export const CreateCustomOidInputSchema = z.object({
  name: z.string().trim().regex(/^[a-z0-9][a-z0-9._-]*$/i, 'Nome tecnico atteso (lettere, cifre, . _ -)').min(2).max(64),
  oid: z.string().trim().regex(/^(\d{1,5}(\.\d{1,5})+|\.?\d+(\.\d+)+)$/, 'OID numerico atteso (es. 1.3.6.1.4.1.41112.1.4)'),
  unit: z.string().max(16).optional(),
  scale: z.number().finite().optional(),
  dataType: z.enum(['FLOAT', 'INT', 'COUNTER']).optional(),
  intervalSec: z.number().int().min(30).max(86400).optional(),
  description: z.string().max(300).optional(),
  enabled: z.boolean().optional(),
})
export type CreateCustomOidInput = z.infer<typeof CreateCustomOidInputSchema>

export const UpdateCustomOidInputSchema = CreateCustomOidInputSchema.partial().omit({ name: true })

/** Test SNMP LIVE di un OID custom su un dispositivo REALE
 * dell'inventario (via mini-service discovery :3002): in sandbox
 * l'IP dell'impianto è irraggiungibile → timeout ONESTO. */
export const CustomOidTestResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    deviceId: z.string(),
    hostname: z.string(),
    ip: z.string().nullable(),
    oid: z.string(),
    reachable: z.boolean(),
    rawValue: z.string().nullable(), // valore grezzo del varbind
    numericValue: z.number().nullable(), // × scale; null se non numerico
    error: z.string().nullable(), // 'timeout' | 'errore' | descrizione
    durationMs: z.number().int(),
    note: z.string(), // dichiarazione: community legacy in chiaro o 'public'
  }),
})
export type CustomOidTestResult = z.infer<typeof CustomOidTestResultSchema>['data']

/* ---------------- Richieste di configurazione ---------------- */

export const ConfigRequestRowSchema = z.object({
  id: z.string(),
  deviceId: z.string(),
  deviceHostname: z.string(),
  deviceType: z.string(),
  title: z.string(),
  commands: z.array(z.string()),
  rollback: z.array(z.string()),
  executor: z.enum(EXECUTORS),
  status: z.string(), // vocabolario di stato, grezzo dal DB
  confirmMinutes: z.number().int(),
  confirmBy: z.number().int().nullable(),
  requestedBy: z.string(),
  approvedBy: z.string().nullable(),
  appliedAt: z.number().int().nullable(),
  output: z.string(), // output onesto («dry-run: nessun comando inviato»)
  note: z.string(),
  safety: z.object({ checked: z.number().int(), forbidden: z.array(z.string()), maxCommands: z.number().int(), dryRunOnly: z.boolean() }),
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type ConfigRequestRow = z.infer<typeof ConfigRequestRowSchema>

export const ConfigRequestsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(ConfigRequestRowSchema), // stato aperto prima, poi createdAt desc
    total: z.number().int(), // 0 = nessuna richiesta (onesto)
  }),
})
export type ConfigRequestsPage = z.infer<typeof ConfigRequestsPageSchema>['data']

export const CreateConfigRequestInputSchema = z.object({
  deviceId: z.string().min(1),
  title: z.string().trim().min(3, 'Titolo troppo corto').max(120),
  commands: z.array(z.string().trim().min(1).max(500)).min(1, 'Almeno un comando').max(CONFIG_MAX_COMMANDS),
  rollback: z.array(z.string().trim().min(1).max(500)).max(CONFIG_MAX_COMMANDS).optional(),
  executor: z.enum(EXECUTORS).optional(), // default SIMULATED in replay
  confirmMinutes: z.number().int().min(0).max(120).optional(), // 0 = senza finestra
  note: z.string().max(300).optional(),
})
export type CreateConfigRequestInput = z.infer<typeof CreateConfigRequestInputSchema>

/** Azioni sulla macchina a stati (validate dal backend):
 * approve PENDING→APPROVED · reject PENDING|APPROVED→REJECTED ·
 * apply APPROVED→APPLIED (SOLO executor SIMULATED: dry-run onesto;
 * SSH → 422 REPLAY_NOEXEC) · confirm APPLIED→CONFIRMED ·
 * rollback APPLIED|CONFIRMED→ROLLED_BACK (dry-run dichiarato). */
export const ConfigRequestActionSchema = z.enum(['approve', 'reject', 'apply', 'confirm', 'rollback'])
export type ConfigRequestAction = z.infer<typeof ConfigRequestActionSchema>

/* ---------------- Bulk config (ondate, v15 R8) ---------------- */

export const BulkConfigRowSchema = z.object({
  id: z.string(),
  title: z.string(),
  commands: z.array(z.string()),
  targetCount: z.number().int(),
  targetHostnames: z.array(z.string()), // primi 20 per la riga (cap dichiarato)
  executor: z.enum(EXECUTORS),
  status: z.string(),
  safety: z.object({ checked: z.number().int(), forbidden: z.array(z.string()), maxTargets: z.number().int(), maxCommands: z.number().int(), dryRunOnly: z.boolean() }),
  results: z.array(z.object({
    deviceId: z.string(),
    hostname: z.string(),
    ok: z.boolean(),
    simulated: z.boolean(),
    error: z.string().nullable(),
    durationMs: z.number().int(),
  })),
  requestedBy: z.string(),
  startedAt: z.number().int().nullable(),
  completedAt: z.number().int().nullable(),
  createdAt: z.number().int(),
})
export type BulkConfigRow = z.infer<typeof BulkConfigRowSchema>

export const BulkConfigPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(BulkConfigRowSchema),
    total: z.number().int(),
  }),
})
export type BulkConfigPage = z.infer<typeof BulkConfigPageSchema>['data']

export const CreateBulkConfigInputSchema = z.object({
  title: z.string().trim().min(3).max(120),
  commands: z.array(z.string().trim().min(1).max(500)).min(1).max(BULK_MAX_COMMANDS),
  deviceIds: z.array(z.string().min(1)).min(1, 'Almeno un dispositivo target').max(BULK_MAX_TARGETS),
  executor: z.enum(EXECUTORS).optional(), // default SIMULATED
})
export type CreateBulkConfigInput = z.infer<typeof CreateBulkConfigInputSchema>

/* ---------------- Firmware center ---------------- */

export const FirmwareJobRowSchema = z.object({
  id: z.string(),
  deviceId: z.string(),
  deviceHostname: z.string(),
  deviceType: z.string(),
  deviceFirmware: z.string(), // attuale dal DB ("" = n.d.)
  targetFirmware: z.string(),
  executor: z.enum(EXECUTORS),
  scheduledAt: z.number().int(),
  confirmMinutes: z.number().int(),
  status: z.string(), // SCHEDULED | RUNNING | APPLIED | CONFIRMED | ROLLED_BACK | FAILED | CANCELED
  output: z.string(),
  error: z.string(),
  requestedBy: z.string(),
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type FirmwareJobRow = z.infer<typeof FirmwareJobRowSchema>

export const FirmwareJobsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(FirmwareJobRowSchema), // createdAt desc
    total: z.number().int(),
  }),
})
export type FirmwareJobsPage = z.infer<typeof FirmwareJobsPageSchema>['data']

export const CreateFirmwareJobInputSchema = z.object({
  deviceId: z.string().min(1),
  targetFirmware: z.string().trim().min(1, 'Versione di destinazione richiesta').max(80),
  commands: z.array(z.string().trim().min(1).max(500)).max(CONFIG_MAX_COMMANDS).optional(),
  executor: z.enum(EXECUTORS).optional(),
  scheduledAt: z.number().int().min(0).optional(), // epoch ms; assente = ora
  confirmMinutes: z.number().int().min(1).max(120).optional(),
})

/* ---------------- Playbook ---------------- */

export const PlaybookStepRowSchema = z.object({
  id: z.string(),
  stepOrder: z.number().int(),
  name: z.string(),
  action: z.string(), // vocabolario azioni (check | command | webhook | wait…)
  params: z.string(), // JSON grezzo, "" = nessuno
})
export const PlaybookRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  triggerRule: z.string(), // "" = manuale
  enabled: z.boolean(),
  runCount: z.number().int(),
  lastRunAt: z.number().int().nullable(),
  createdBy: z.string(),
  steps: z.array(PlaybookStepRowSchema), // per stepOrder
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type PlaybookRow = z.infer<typeof PlaybookRowSchema>

export const PLAYBOOK_ACTIONS = ['check_status', 'check_metric', 'send_command', 'open_ticket', 'notify', 'wait'] as const

export const PlaybooksPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(PlaybookRowSchema),
    total: z.number().int(),
  }),
})
export type PlaybooksPage = z.infer<typeof PlaybooksPageSchema>['data']

export const CreatePlaybookInputSchema = z.object({
  name: z.string().trim().min(3).max(120),
  description: z.string().max(500).optional(),
  triggerRule: z.string().max(200).optional(), // id regola evento o pattern
  enabled: z.boolean().optional(),
  steps: z.array(z.object({
    name: z.string().trim().min(1).max(80),
    action: z.enum(PLAYBOOK_ACTIONS),
    params: z.string().max(500).optional(), // JSON libero validato solo come testo
  })).min(1, 'Almeno un passo').max(30),
})

export const UpdatePlaybookInputSchema = CreatePlaybookInputSchema.partial()

/* ---------------- Automation task ---------------- */

export const AutomationTaskRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  targetCount: z.number().int(),
  targetHostnames: z.array(z.string()), // primi 20 (cap dichiarato)
  category: z.string(),
  commands: z.array(z.string()),
  executor: z.enum(EXECUTORS),
  intervalSec: z.number().int(),
  confirmMinutes: z.number().int(),
  enabled: z.boolean(),
  guardrailMaxDevices: z.number().int(),
  runCount: z.number().int(), // 0 onesto: mai eseguito in replay
  lastRunAt: z.number().int().nullable(),
  lastError: z.string(),
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type AutomationTaskRow = z.infer<typeof AutomationTaskRowSchema>

export const AutomationTasksPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(AutomationTaskRowSchema),
    total: z.number().int(),
  }),
})
export type AutomationTasksPage = z.infer<typeof AutomationTasksPageSchema>['data']

export const CreateAutomationTaskInputSchema = z.object({
  name: z.string().trim().min(3).max(120),
  description: z.string().max(500).optional(),
  deviceIds: z.array(z.string().min(1)).max(BULK_MAX_TARGETS).optional(),
  category: z.string().trim().max(60).optional(), // template CLI o 'custom'
  commands: z.array(z.string().trim().min(1).max(500)).min(1).max(BULK_MAX_COMMANDS),
  executor: z.enum(EXECUTORS).optional(),
  intervalSec: z.number().int().min(60).max(86400).optional(),
  confirmMinutes: z.number().int().min(0).max(120).optional(),
  guardrailMaxDevices: z.number().int().min(1).max(50).optional(),
  enabled: z.boolean().optional(),
})

export const UpdateAutomationTaskInputSchema = CreateAutomationTaskInputSchema.partial()

/* ---------------- Integrazioni (W7) ---------------- */

export const INTEGRATION_CATEGORIES = [
  'email', 'telegram', 'osticket', 'grafana', 'checkmk', 'cnmaestro',
  'unifi', 'splashtop', 'ldap', 'prometheus', 'ollama', 'backup', 'general',
] as const

export const IntegrationConfigRowSchema = z.object({
  id: z.string(),
  key: z.string(), // es. smtp.host, telegram.botToken
  category: z.string(),
  value: z.string(), // REALE solo se isSecret=false; altrimenti "***" (mai il segreto)
  isSecret: z.boolean(),
  enabled: z.boolean(),
  note: z.string(),
  updatedBy: z.string(),
  updatedAt: z.number().int(),
  hasValue: z.boolean(), // true = valore salvato (anche se mascherato)
})
export type IntegrationConfigRow = z.infer<typeof IntegrationConfigRowSchema>

export const IntegrationsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    configs: z.array(IntegrationConfigRowSchema), // per category, key
    webhooks: z.array(z.string()), // placeholder vedi /integrations/webhooks
    totalConfigs: z.number().int(),
    categories: z.array(z.string()), // categorie con almeno 1 config
  }),
})
export type IntegrationsPage = z.infer<typeof IntegrationsPageSchema>['data']

export const UpsertIntegrationInputSchema = z.object({
  key: z.string().trim().regex(/^[a-z][a-z0-9]*(\.[a-zA-Z0-9_-]+)+(:[A-Za-z0-9_.-]+)?$/, 'Chiave attesa tipo «smtp.host» o «telegram.botToken:PLANT-X»').min(3).max(120),
  category: z.enum(INTEGRATION_CATEGORIES),
  value: z.string().min(1, 'Valore richiesto').max(2000),
  isSecret: z.boolean().optional(),
  note: z.string().max(300).optional(),
  enabled: z.boolean().optional(),
})
export type UpsertIntegrationInput = z.infer<typeof UpsertIntegrationInputSchema>

/** Esito onesto del test di connessione: in sandbox le destinazioni
 * esterne NON sono raggiungibili → network error DICHIARATO (mai
 * «test superato» inventato). */
export const IntegrationTestResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    kind: z.enum(['http', 'tcp', 'telegram', 'webhook']),
    target: z.string(), // host:port o URL (mai il segreto)
    reachable: z.boolean(),
    statusCode: z.number().int().nullable(),
    latencyMs: z.number().int(),
    detail: z.string(), // esito/errore onesto
  }),
})
export type IntegrationTestResult = z.infer<typeof IntegrationTestResultSchema>['data']

export const IntegrationTestInputSchema = z.object({
  kind: z.enum(['http', 'tcp', 'telegram', 'webhook']),
  url: z.string().trim().max(500).optional(), // http
  host: z.string().trim().max(200).optional(), // tcp
  port: z.number().int().min(1).max(65535).optional(), // tcp
  token: z.string().max(200).optional(), // telegram bot token (NON salvato: solo test)
  timeoutMs: z.number().int().min(1000).max(10000).optional(),
}).refine((v) => v.kind !== 'http' || (v.url != null && /^https?:\/\//.test(v.url)), {
  message: 'URL http(s) richiesto per il test http', path: ['url'],
}).refine((v) => v.kind !== 'tcp' || (v.host != null && v.port != null), {
  message: 'Host e porta richiesti per il test tcp', path: ['host'],
}).refine((v) => v.kind !== 'telegram' || (v.token != null && v.token.length > 10), {
  message: 'Token del bot richiesto per il test telegram', path: ['token'],
})

/* ---------------- Webhook (firma HMAC + consegna reale) ---------------- */

export const WebhookDeliveryRowSchema = z.object({
  id: z.string(),
  endpointId: z.string(),
  eventType: z.string(),
  status: z.string(), // DELIVERED | DEAD | PENDING | RETRYING
  attempts: z.number().int(),
  lastStatusCode: z.number().int().nullable(),
  lastError: z.string(),
  latencyMs: z.number().int(),
  deliveredAt: z.number().int().nullable(),
  createdAt: z.number().int(),
})
export type WebhookDeliveryRow = z.infer<typeof WebhookDeliveryRowSchema>

export const WebhookEndpointRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  url: z.string(),
  events: z.array(z.string()), // [] = tutti
  plantId: z.string().nullable(),
  active: z.boolean(),
  description: z.string(),
  hasSecret: z.boolean(), // true = segreto HMAC salvato (mai esposto)
  lastDeliveryAt: z.number().int().nullable(),
  lastStatus: z.string(),
  deliveries: z.array(WebhookDeliveryRowSchema), // ultime 10 per endpoint
  deliveriesTotal: z.number().int(),
})
export type WebhookEndpointRow = z.infer<typeof WebhookEndpointRowSchema>

export const WebhooksPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(WebhookEndpointRowSchema),
    total: z.number().int(),
  }),
})
export type WebhooksPage = z.infer<typeof WebhooksPageSchema>['data']

export const CreateWebhookInputSchema = z.object({
  name: z.string().trim().min(2).max(80),
  url: z.string().trim().url('URL valido richiesto').max(500).refine((u) => /^https?:\/\//.test(u), 'http(s) richiesto'),
  secret: z.string().min(16, 'Segreto HMAC minimo 16 caratteri').max(200).optional(), // assente = generato
  events: z.array(z.string().trim().min(1).max(60)).max(30).optional(),
  plantId: z.string().min(1).nullable().optional(),
  description: z.string().max(300).optional(),
})
export type CreateWebhookInput = z.infer<typeof CreateWebhookInputSchema>

export const UpdateWebhookInputSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  url: z.string().trim().url().max(500).optional(),
  active: z.boolean().optional(),
  events: z.array(z.string().trim().min(1).max(60)).max(30).optional(),
  description: z.string().max(300).optional(),
})

/** Test di consegna REALE con firma HMAC-SHA256 (header
 * X-Falco-Signature: t=<epoch>,v1=<hex di HMAC(t '.' body)>):
 * il destinatario locale /api/hooks/test-receiver verifica e risponde,
 * la risposta include la verifica crittografica della firma. */
export const WebhookTestResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    deliveryId: z.string(),
    delivered: z.boolean(),
    statusCode: z.number().int().nullable(),
    latencyMs: z.number().int(),
    signature: z.string(), // header inviato (t=…,v1=… — pubblico per costruzione)
    signatureVerified: z.boolean(), // verifica crittografica lato ricevente
    detail: z.string(),
  }),
})
export type WebhookTestResult = z.infer<typeof WebhookTestResultSchema>['data']

/* ---------------- Terminale SSH (tentativo onesto) ---------------- */

export const TerminalProbeResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    deviceId: z.string(),
    hostname: z.string(),
    ip: z.string().nullable(),
    sshPortOpen: z.boolean(),
    reachable: z.boolean(),
    latencyMs: z.number().int().nullable(),
    detail: z.string(), // esito onesto del tentativo TCP sulla porta 22
    sessionOpened: z.boolean(), // false in sandbox: MAI sessione fittizia
  }),
})
export type TerminalProbeResult = z.infer<typeof TerminalProbeResultSchema>['data']

/* Tipi update (16.7): esportati per il client */
export type UpdateEventPolicyInput = z.infer<typeof UpdateEventPolicyInputSchema>
export type UpdateCustomOidInput = z.infer<typeof UpdateCustomOidInputSchema>
export type CreateFirmwareJobInput = z.infer<typeof CreateFirmwareJobInputSchema>
export type CreatePlaybookInput = z.infer<typeof CreatePlaybookInputSchema>
export type UpdatePlaybookInput = z.infer<typeof UpdatePlaybookInputSchema>
export type CreateAutomationTaskInput = z.infer<typeof CreateAutomationTaskInputSchema>
export type UpdateAutomationTaskInput = z.infer<typeof UpdateAutomationTaskInputSchema>
export type IntegrationTestInput = z.infer<typeof IntegrationTestInputSchema>
export type UpdateWebhookInput = z.infer<typeof UpdateWebhookInputSchema>

/* ================================================================
 * 16.8 W2+W6 — REPORT SLA, SCHEDA INTERVENTO, REPORT SCHEDULATI,
 * CERTIFICAZIONE AUDIT (export SHA-256, chain seal, verifica)
 * ================================================================
 * Regole d'onorezza invariate: solo campi REALI del DB; la copertura
 * dei campi SLA (firstResponseAt 0/74 nel DB reale, slaDueAt 0/74,
 * SLADefinition 0 — D19) è DICHIARATA nel payload, mai mascherata.
 * ================================================================ */

/* ---------------- Report SLA mensile + storico (W2) ---------------- */

export const SlaReportQuerySchema = z.object({
  month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'Formato mese: YYYY-MM').optional(),
  plantId: z.string().min(1).optional(),
})
export type SlaReportQuery = z.infer<typeof SlaReportQuerySchema>

export const SlaMonthHistorySchema = z.object({
  month: z.string(),
  created: z.number().int(),
  closed: z.number().int(),
  responseMeasured: z.number().int(),
  resolutionMeasured: z.number().int(),
  responseInSla: z.number().int(),
  resolutionInSla: z.number().int(),
})
export type SlaMonthHistory = z.infer<typeof SlaMonthHistorySchema>

export const SlaReportSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    month: z.string(),
    windowFrom: z.number().int(),
    windowTo: z.number().int(),
    tickets: z.object({
      total: z.number().int(),
      created: z.number().int(),
      closed: z.number().int(),
      byStatus: z.array(z.object({ status: z.string(), count: z.number().int() })),
      byPriority: z.array(z.object({ priority: z.string(), count: z.number().int() })),
      bySource: z.array(z.object({ source: z.string(), count: z.number().int() })),
    }),
    responseTime: z.object({
      measured: z.number().int(),
      coverage: z.string(), // dichiarazione onesta: «X di Y ticket della coorte hanno firstResponseAt»
      medianMin: z.number().nullable(),
      avgMin: z.number().nullable(),
      minMin: z.number().nullable(),
      maxMin: z.number().nullable(),
    }),
    resolutionTime: z.object({
      measured: z.number().int(),
      coverage: z.string(),
      medianMin: z.number().nullable(),
      avgMin: z.number().nullable(),
      minMin: z.number().nullable(),
      maxMin: z.number().nullable(),
      pausedMinutesTotal: z.number().int(),
    }),
    slaCompliance: z.object({
      response: z.object({ evaluated: z.number().int(), inSla: z.number().int(), late: z.number().int() }),
      resolution: z.object({ evaluated: z.number().int(), inSla: z.number().int(), late: z.number().int() }),
      slaDefinitions: z.number().int(),
      note: z.string(), // D19: nessuna SLADefinition nel DB reale
    }),
    escalation: z.object({
      maxLevel: z.number().int(),
      ticketsEscalated: z.number().int(),
    }),
    months: z.array(z.string()), // mesi con ticket reali (selettore storico)
    history: z.array(SlaMonthHistorySchema), // report SLA storico (W2)
  }),
})
export type SlaReport = z.infer<typeof SlaReportSchema>['data']

/* ---------------- Scheda intervento (W2) ---------------- */

export const TicketDetailSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    ticket: z.object({
      id: z.string(),
      title: z.string(),
      description: z.string(),
      status: z.string(),
      priority: z.string(),
      source: z.string(),
      createdAt: z.number().int(),
      updatedAt: z.number().int(),
      assignedTo: z.string(),
      assignedAt: z.number().int().nullable(),
      firstResponseAt: z.number().int().nullable(),
      resolvedAt: z.number().int().nullable(),
      closedAt: z.number().int().nullable(),
      slaResponseDueAt: z.number().int().nullable(),
      slaResolutionDueAt: z.number().int().nullable(),
      slaPausedMinutes: z.number().int(),
      escalationLevel: z.number().int(),
      rootCause: z.string(),
      resolution: z.string(),
      diagnosticSteps: z.array(z.string()),
    }),
    device: z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string().nullable(),
      type: z.string(),
      brand: z.string().nullable(),
      model: z.string().nullable(),
      status: z.string(),
    }).nullable(),
    location: z.object({ id: z.string(), name: z.string() }).nullable(),
    plant: z.object({ id: z.string(), name: z.string() }),
    interventions: z.array(z.object({
      id: z.string(),
      action: z.string(),
      component: z.string(),
      description: z.string(),
      technicianName: z.string(),
      status: z.string(),
      createdAt: z.number().int(),
    })),
    timeline: z.array(z.object({
      action: z.string(),
      actor: z.string(),
      createdAt: z.number().int(),
    })),
    counts: z.object({ comments: z.number().int(), attachments: z.number().int(), timeEntries: z.number().int() }),
    honesty: z.string(), // dichiarazione replay: interventi/commenti reali = 0 nel DB egidio
  }),
})
export type TicketDetail = z.infer<typeof TicketDetailSchema>['data']

/* ---------------- Report schedulati PDF (W2) ---------------- */

export const SCHEDULED_FREQUENCIES = ['HOURLY', 'DAILY', 'WEEKLY', 'MONTHLY'] as const
export const SCHEDULED_CHANNELS = ['EMAIL', 'TELEGRAM', 'PDF'] as const
export const SCHEDULED_SECTIONS = ['devices', 'tickets', 'sla', 'metrics', 'alarms', 'availability'] as const

export const CreateScheduledReportInputSchema = z.object({
  name: z.string().trim().min(2).max(80),
  frequency: z.enum(SCHEDULED_FREQUENCIES),
  hour: z.number().int().min(0).max(23),
  dayOfWeek: z.number().int().min(0).max(6).optional(),
  dayOfMonth: z.number().int().min(1).max(31).optional(),
  channels: z.array(z.enum(SCHEDULED_CHANNELS)).min(1, 'Almeno un canale'),
  recipients: z.array(z.string().trim().email('Indirizzo e-mail valido').max(120)).max(20, 'Massimo 20 destinatari'),
  includeSections: z.array(z.enum(SCHEDULED_SECTIONS)).min(1, 'Almeno una sezione'),
  enabled: z.boolean().optional(),
  plantId: z.string().min(1).optional(),
})
export type CreateScheduledReportInput = z.infer<typeof CreateScheduledReportInputSchema>

export const UpdateScheduledReportInputSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  frequency: z.enum(SCHEDULED_FREQUENCIES).optional(),
  hour: z.number().int().min(0).max(23).optional(),
  dayOfWeek: z.number().int().min(0).max(6).optional(),
  dayOfMonth: z.number().int().min(1).max(31).optional(),
  channels: z.array(z.enum(SCHEDULED_CHANNELS)).min(1).optional(),
  recipients: z.array(z.string().trim().email().max(120)).max(20).optional(),
  includeSections: z.array(z.enum(SCHEDULED_SECTIONS)).min(1).optional(),
  enabled: z.boolean().optional(),
}).refine((v) => Object.keys(v).length > 0, 'Almeno un campo')
export type UpdateScheduledReportInput = z.infer<typeof UpdateScheduledReportInputSchema>

export const ScheduledReportRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  frequency: z.string(),
  hour: z.number().int(),
  dayOfWeek: z.number().int().nullable(),
  dayOfMonth: z.number().int().nullable(),
  channels: z.array(z.string()),
  recipients: z.array(z.string()),
  includeSections: z.array(z.string()),
  enabled: z.boolean(),
  lastRunAt: z.number().int().nullable(),
  lastStatus: z.string(),
  nextRunAt: z.number().int().nullable(),
  runCount: z.number().int(),
  artifactsCount: z.number().int(),
  createdAt: z.number().int(),
})
export type ScheduledReportRow = z.infer<typeof ScheduledReportRowSchema>

export const ScheduledReportsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(ScheduledReportRowSchema),
    total: z.number().int(),
    honesty: z.string(), // D2: il motore di schedulazione non gira in riproduzione
  }),
})
export type ScheduledReportsPage = z.infer<typeof ScheduledReportsPageSchema>['data']

export const ScheduledReportDeletedSchema = ApiEnvelopeSchema.extend({
  data: z.object({ id: z.string(), deleted: z.boolean(), removedArtifacts: z.number().int() }),
})

/* ---------------- Certificazione audit (W6) ---------------- */

export const AuditExportQuerySchema = z.object({
  from: z.coerce.number().int().min(0).optional(),
  to: z.coerce.number().int().min(0).optional(),
  limit: z.coerce.number().int().min(1).max(5000).optional(), // envelope: default 200 (bordo dichiarato)
  format: z.enum(['csv', 'json']).optional(), // assente = envelope JSON con manifest (per l'UI)
  action: z.string().trim().min(1).max(60).optional(), // filtro prefisso (come la vista audit)
})
export type AuditExportQuery = z.infer<typeof AuditExportQuerySchema>

export const AuditExportRowSchema = z.object({
  id: z.string(),
  action: z.string(),
  actor: z.string(),
  targetId: z.string().nullable(),
  targetLabel: z.string().nullable(),
  plantId: z.string().nullable(),
  createdAt: z.number().int(),
  chainSeq: z.number().int().nullable(),
  recordHash: z.string().nullable(),
})
export type AuditExportRow = z.infer<typeof AuditExportRowSchema>

export const AuditExportSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    filters: z.object({ from: z.number().int().nullable(), to: z.number().int().nullable(), limit: z.number().int() }),
    totalMatching: z.number().int(),
    returned: z.number().int(),
    truncated: z.boolean(),
    rows: z.array(AuditExportRowSchema),
    manifest: z.object({
      totalRows: z.number().int(),
      sealedRows: z.number().int(),
      unsealedRows: z.number().int(),
      firstSeq: z.number().int().nullable(),
      lastSeq: z.number().int().nullable(),
      /** SHA-256 della catena INTERA (tutti i recordHash sigillati in ordine
       * di chainSeq, concatenati con «\n») — null se nessuna riga sigillata. */
      chainDigest: z.string().nullable(),
      /** SHA-256 della serializzazione canonica delle righe esportate
       * (certifica l'export stesso, verificabile ricalcolando lato client). */
      exportDigest: z.string(),
      note: z.string(),
    }),
  }),
})
export type AuditExport = z.infer<typeof AuditExportSchema>['data']

export const AuditChainStateSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    totalRows: z.number().int(),
    sealedRows: z.number().int(),
    unsealedRows: z.number().int(),
    firstSeq: z.number().int().nullable(),
    lastSeq: z.number().int().nullable(),
    seals: z.array(z.object({
      id: z.string(),
      lastSeq: z.number().int(),
      lastRecordId: z.string(),
      lastHash: z.string(),
      recordCount: z.number().int(),
      prevSealId: z.string().nullable(),
      sealedBy: z.string(),
      sealedAt: z.number().int(),
    })),
  }),
})
export type AuditChainState = z.infer<typeof AuditChainStateSchema>['data']

export const AuditSealResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    sealId: z.string(),
    sealedRows: z.number().int(), // batch incluso la voce AUDIT_SEAL_CREATE
    lastSeq: z.number().int(),
    lastHash: z.string(),
    skipped: z.boolean(),
    remainingUnsealed: z.number().int(),
    verified: z.boolean(), // verifica immediata post-sigillo (fedele v15)
    note: z.string(),
  }),
})
export type AuditSealResult = z.infer<typeof AuditSealResultSchema>['data']

export const AuditChainVerifySchema = ApiEnvelopeSchema.extend({
  data: z.object({
    verified: z.boolean(),
    genesisHash: z.string(),
    sealsTotal: z.number().int(),
    sealsVerified: z.number().int(),
    recordsSealed: z.number().int(),
    recordsVerified: z.number().int(),
    unsealedCount: z.number().int(),
    breakages: z.array(z.object({
      sealId: z.string().optional(),
      recordId: z.string().optional(),
      seq: z.number().int().optional(),
      reason: z.string(),
      expected: z.string().optional(),
      actual: z.string().optional(),
    })).max(200), // prime 200 rotture (diagnostica completa v15, bounded per l'UI)
    durationMs: z.number().int(),
    checkedAt: z.number().int(),
  }),
})
export type AuditChainVerify = z.infer<typeof AuditChainVerifySchema>['data']

export const SealedEventRowSchema = z.object({
  id: z.string(),
  action: z.string(),
  actor: z.string(),
  targetId: z.string().nullable(),
  targetLabel: z.string().nullable(),
  plantId: z.string().nullable(),
  details: z.string(),
  createdAt: z.string(), // ISO per il calcolo del recordHash
  chainSeq: z.number().int().nullable(),
  recordHash: z.string().nullable(),
})
export type SealedEventRow = z.infer<typeof SealedEventRowSchema>

/* ================================================================
 * W4 (16.9.0) — Knowledge base, RMA guidata, ondate, CVE, speed
 * test, assistente AI, amministrazione completa (utenti/permessi/
 * sessioni). Modelli Prisma v15 già importati (KnowledgeBase,
 * DeviceReplacement, ConfigWave/Item, CveEntry/Pattern/Finding,
 * SpeedTest, User/PlantAssignment/Session) — tutte a 0 righe nel DB
 * reale: gli empty state sono dichiarati e onesti.
 * ================================================================ */

/* ---------------- 16.9 · /api/v2/kb — Knowledge base ---------------- */

export const KbQuerySchema = z.object({
  q: z.string().max(200).optional(), // ricerca contains su titolo/corpo
  plantId: z.string().optional(),
})
export const KbArticleRowSchema = z.object({
  id: z.string(),
  plantId: z.string().nullable(),
  title: z.string(),
  body: z.string(),
  tags: z.array(z.string()).max(10), // parse difensivo del JSON v15
  ticketId: z.string().nullable(), // articolo nato da un ticket (conoscenza ripetibile)
  createdBy: z.string(),
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
})
export type KbPage = z.infer<typeof KbPageSchema>['data']
export type CreateKbInput = z.infer<typeof CreateKbInputSchema>
export type UpdateKbInput = z.infer<typeof UpdateKbInputSchema>

export const KbPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(KbArticleRowSchema),
    total: z.number().int(),
  }),
})
export type KbArticleRow = z.infer<typeof KbArticleRowSchema>

export const CreateKbInputSchema = z.object({
  title: z.string().min(1).max(200),
  body: z.string().min(1).max(100_000),
  tags: z.array(z.string().max(60)).max(10).optional(),
})
export const UpdateKbInputSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  body: z.string().min(1).max(100_000).optional(),
  tags: z.array(z.string().max(60)).max(10).optional(),
}).refine((v) => v.title !== undefined || v.body !== undefined || v.tags !== undefined, {
  message: 'Almeno uno fra title, body, tags è richiesto',
})
export const KbFromTicketInputSchema = z.object({
  ticketId: z.string().min(1),
})
export const KbDeletedSchema = ApiEnvelopeSchema.extend({
  data: z.object({ deleted: z.literal(true), id: z.string() }),
})

/* ---------------- 16.9 · /api/v2/rma — Sostituzione guasto ---------- */

export const RmaQuerySchema = z.object({
  deviceId: z.string().min(1),
})
export const RmaPlanSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    deviceId: z.string(),
    hostname: z.string(),
    plantId: z.string(),
    impact: z.object({
      downstreamVictims: z.number().int(),
      victims: z.array(z.object({
        id: z.string(), hostname: z.string(), ip: z.string(),
        type: z.string(), status: z.string(),
      })).max(50),
    }),
    portable: z.object({
      credentials: z.array(z.string()), // campi portabili (cifrati AES tal quali)
      locationId: z.string().nullable(),
      pointIdentifier: z.string().nullable(),
      notes: z.boolean(),
      groupIds: z.array(z.string()),
      confirmedLinks: z.number().int(),
    }),
    genealogy: z.array(z.object({
      oldDeviceId: z.string(), newDeviceId: z.string(), at: z.number().int(),
    })),
    warnings: z.array(z.string()),
  }),
})
export type RmaPlan = z.infer<typeof RmaPlanSchema>['data']

export type RmaExecuteInput = z.infer<typeof RmaExecuteInputSchema>

export const RmaExecuteInputSchema = z.object({
  oldDeviceId: z.string().min(1),
  reason: z.string().max(500).optional(),
  replacement: z.object({
    hostname: z.string().min(1).max(200),
    ip: z.string().min(7).max(45),
    type: z.enum(['AP', 'STA', 'CAMERA', 'LPR', 'SWITCH', 'NVR', 'GATEWAY', 'ONT']),
    brand: z.string().max(100).optional(),
    model: z.string().max(100).optional(),
    macAddress: z.string().max(50).optional(),
    port: z.number().int().min(1).max(65_535).optional(),
    connectionType: z.string().max(50).optional(),
  }),
})
export const RmaExecuteResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    newDeviceId: z.string(),
    steps: z.array(z.object({
      step: z.string(), ok: z.boolean(), detail: z.string(),
    })),
  }),
})

/* ---------------- 16.9 · /api/v2/waves — Ondate ---------------------- */

export const WaveRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  kind: z.string(), // CONFIG | FIRMWARE
  action: z.string(),
  status: z.string(), // DRAFT | READY | RUNNING | STOPPED | COMPLETED
  batchSize: z.number().int(),
  canarySize: z.number().int(),
  stopOnFirstFailure: z.boolean(),
  dryRun: z.boolean(),
  createdBy: z.string(),
  createdAt: z.number().int(),
  preflight: z.array(z.object({
    deviceId: z.string(), hostname: z.string(), ok: z.boolean(), reason: z.string(),
  })).nullable(),
  counts: z.object({
    total: z.number().int(),
    canary: z.number().int(),
    applied: z.number().int(),
    failed: z.number().int(),
    skipped: z.number().int(),
    pending: z.number().int(),
  }),
})
export const WavesPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    items: z.array(WaveRowSchema),
    total: z.number().int(),
    executionAvailable: z.literal(false), // onestà D2: il motore non gira in riproduzione
  }),
})
export type WaveRow = z.infer<typeof WaveRowSchema>
export type WavesPage = z.infer<typeof WavesPageSchema>['data']

export type CreateWaveInput = z.infer<typeof CreateWaveInputSchema>

export const CreateWaveInputSchema = z.object({
  name: z.string().min(1).max(200),
  kind: z.enum(['CONFIG', 'FIRMWARE']).default('CONFIG'),
  action: z.string().max(100).optional(),
  deviceIds: z.array(z.string().min(1)).min(1).max(500),
  batchSize: z.number().int().min(1).max(50).optional(),
  canarySize: z.number().int().min(1).max(10).optional(),
  stopOnFirstFailure: z.boolean().optional(),
  dryRun: z.boolean().optional(),
})
export const WaveDeletedSchema = ApiEnvelopeSchema.extend({
  data: z.object({ deleted: z.literal(true), id: z.string() }),
})

/* ---------------- 16.9 · /api/v2/cve — Vulnerabilità ----------------- */

export const CVE_SEVERITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'] as const
export const CVE_FINDING_STATUSES = ['OPEN', 'IGNORED', 'RESOLVED'] as const

export const CveEntryRowSchema = z.object({
  id: z.string(),
  cveId: z.string(),
  title: z.string(),
  description: z.string(),
  severity: z.string(),
  cvss: z.number(),
  reference: z.string(),
  publishedAt: z.number().int().nullable(),
  patterns: z.array(z.object({
    vendorPattern: z.string(),
    modelPattern: z.string(),
    firmwareMin: z.string(),
    firmwareMax: z.string(),
  })).max(20),
})
export type CveCatalog = z.infer<typeof CveCatalogSchema>['data']
export type CveFindingsPage = z.infer<typeof CveFindingsPageSchema>['data']
export type CveScanReport = z.infer<typeof CveScanReportSchema>['data']
export type CveImportInput = z.infer<typeof CveImportInputSchema>
export type CveImportResult = z.infer<typeof CveImportResultSchema>['data']

export const CveCatalogSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    entries: z.array(CveEntryRowSchema),
    total: z.number().int(),
    demoCatalogAvailable: z.number().int(), // voci dimostrative importabili (12)
  }),
})
export type CveEntryRow = z.infer<typeof CveEntryRowSchema>

export const CveFindingRowSchema = z.object({
  id: z.string(),
  deviceId: z.string(),
  hostname: z.string(),
  ip: z.string(),
  brand: z.string(),
  model: z.string(),
  firmwareVersion: z.string(),
  cveId: z.string(),
  title: z.string(),
  severity: z.string(),
  cvss: z.number(),
  reference: z.string(),
  status: z.string(),
  firstSeenAt: z.number().int(),
  lastSeenAt: z.number().int(),
  firmwareAtFind: z.string(),
})
export const CveFindingsQuerySchema = z.object({
  status: z.enum(CVE_FINDING_STATUSES).optional(),
})
export const CveFindingsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    findings: z.array(CveFindingRowSchema),
    counts: z.object({
      OPEN: z.number().int(),
      IGNORED: z.number().int(),
      RESOLVED: z.number().int(),
    }),
  }),
})
export type CveFindingRow = z.infer<typeof CveFindingRowSchema>

export const CveScanReportSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    scanned: z.number().int(),
    findings: z.number().int(),
    newFindings: z.number().int(),
    autoResolved: z.number().int(),
    summary: z.object({
      total: z.number().int(),
      critical: z.number().int(),
      high: z.number().int(),
      medium: z.number().int(),
      low: z.number().int(),
    }),
    errors: z.array(z.string()).max(20),
  }),
})

export const CveImportInputSchema = z.object({
  demo: z.boolean().optional(), // importa il catalogo dimostrativo v15 (12 voci)
  entries: z.array(z.object({
    cveId: z.string().regex(/^CVE-\d{4}-\d{4,}$/),
    title: z.string().max(300).default(''),
    description: z.string().max(2000).default(''),
    severity: z.enum(CVE_SEVERITIES).default('MEDIUM'),
    cvss: z.number().min(0).max(10).default(0),
    publishedAt: z.string().optional(),
    reference: z.string().max(500).default(''),
    patterns: z.array(z.object({
      vendorPattern: z.string().max(120).default('*'),
      modelPattern: z.string().max(120).default('*'),
      firmwareMin: z.string().max(40).default(''),
      firmwareMax: z.string().max(40).default(''),
    })).min(1).max(20),
  })).max(200).optional(),
}).refine((v) => v.demo === true || (v.entries && v.entries.length > 0), {
  message: 'Richiesto demo:true oppure entries non vuote',
})
export const CveImportResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    imported: z.number().int(),
    errors: z.array(z.string()).max(200),
  }),
})

export const CveFindingPatchSchema = z.object({
  status: z.enum(CVE_FINDING_STATUSES),
  note: z.string().max(300).optional(),
})

/* ---------------- 16.9 · /api/v2/speed-tests — iperf3 ---------------- */

export const SpeedTestRowSchema = z.object({
  id: z.string(),
  deviceId: z.string(),
  deviceHostname: z.string(),
  deviceIp: z.string(),
  mode: z.string(), // TCP | UDP
  direction: z.string(), // DOWN | UP
  host: z.string(),
  port: z.number().int(),
  durationSec: z.number().int(),
  executor: z.string(), // IPERF3 | SIMULATED (marcato, mai spacciato)
  ok: z.boolean(),
  bandwidthMbps: z.number(),
  retransmits: z.number().int(),
  jitterMs: z.number(),
  lossPercent: z.number(),
  error: z.string(),
  createdAt: z.number().int(),
})
export type SpeedTestsPage = z.infer<typeof SpeedTestsPageSchema>['data']
export type SpeedTestRunInput = z.infer<typeof SpeedTestRunInputSchema>
export type SpeedTestRunResult = z.infer<typeof SpeedTestRunResultSchema>['data']

export const SpeedTestsPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    tests: z.array(SpeedTestRowSchema),
    stats: z.object({
      total: z.number().int(),
      real: z.number().int(),
      simulated: z.number().int(),
      avgMbps: z.number(),
      maxMbps: z.number(),
      lastRealAt: z.number().int().nullable(),
    }),
  }),
})
export type SpeedTestRow = z.infer<typeof SpeedTestRowSchema>

export const SpeedTestsQuerySchema = z.object({
  deviceId: z.string().optional(),
})
export const SpeedTestRunInputSchema = z.object({
  deviceId: z.string().min(1),
  host: z.string().max(200).optional(),
  port: z.number().int().min(1).max(65_535).default(5201),
  durationSec: z.number().int().min(1).max(60).default(10),
  mode: z.enum(['TCP', 'UDP']).default('TCP'),
  direction: z.enum(['UP', 'DOWN']).default('DOWN'),
  executor: z.enum(['IPERF3', 'SIMULATED']).default('IPERF3'),
})
export const SpeedTestRunResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    testId: z.string().nullable(), // null quando il binario manca (nessuna riga scritta)
    ok: z.boolean(),
    executor: z.string(),
    bandwidthMbps: z.number(),
    retransmits: z.number().int(),
    jitterMs: z.number(),
    lossPercent: z.number(),
    error: z.string(),
  }),
})

/* ---------------- 16.9 · /api/v2/assistente — AI operatore ----------- */
/* Risposta = stream SSE (text/event-stream), NON la busta JSON:
 * evento `status` (fase preparazione contesto), `delta` (frammenti del
 * model in streaming reale), `done` {durationMs, contextChars}, `error`.
 * Il contesto è costituito da dati REALI del plant (conteggi, stati,
 * allarmi aperti, ticket, link deboli) — nessun dato inventato. */

export const AssistenteInputSchema = z.object({
  message: z.string().min(1).max(10_000),
  history: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string().min(1).max(10_000),
  })).max(6).optional(),
})

/* ---------------- 16.9 · /api/v2/admin/users|permissions|sessions ---- */

export const ADMIN_ROLES = ['TECNICO', 'RESPONSABILE_COMUNE', 'SUPER_ADMIN', 'CLIENTE'] as const

export const AdminUserRowSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string(),
  role: z.string(),
  mustChangePassword: z.boolean(),
  totpEnabled: z.boolean(),
  createdAt: z.number().int(),
  updatedAt: z.number().int(),
  plantIds: z.array(z.string()),
  sessionCount: z.number().int(),
})
export type AdminUsersPage = z.infer<typeof AdminUsersPageSchema>['data']
export type CreateUserInput = z.infer<typeof CreateUserInputSchema>
export type UpdateUserInput = z.infer<typeof UpdateUserInputSchema>
export type AdminPermissions = z.infer<typeof AdminPermissionsSchema>['data']
export type AdminSessions = z.infer<typeof AdminSessionsSchema>['data']

export const AdminUsersPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    users: z.array(AdminUserRowSchema),
    total: z.number().int(),
  }),
})
export type AdminUserRow = z.infer<typeof AdminUserRowSchema>

export const CreateUserInputSchema = z.object({
  name: z.string().min(1).max(100),
  email: z.string().email().max(200),
  password: z.string().min(10).max(128), // policy completa lato route
  role: z.enum(ADMIN_ROLES).default('TECNICO'),
  plantIds: z.array(z.string().min(1)).max(50).optional(),
})
export const UpdateUserInputSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  email: z.string().email().max(200).optional(),
  password: z.string().min(10).max(128).optional(),
  role: z.enum(ADMIN_ROLES).optional(),
  mustChangePassword: z.boolean().optional(),
  plantIds: z.array(z.string().min(1)).max(50).optional(),
}).refine((v) => Object.keys(v).some((k) => v[k as keyof typeof v] !== undefined), {
  message: 'Almeno un campo è richiesto',
})
export const UserDeletedSchema = ApiEnvelopeSchema.extend({
  data: z.object({ deleted: z.literal(true), id: z.string() }),
})

export const AdminPermissionsSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    version: z.number().int(),
    catalog: z.array(z.string()),
    modules: z.array(z.object({
      module: z.string(),
      permissions: z.array(z.string()),
    })),
    roles: z.record(z.string(), z.array(z.string())),
  }),
})

export const AdminSessionsSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    total: z.number().int(),
    sessions: z.array(z.object({
      id: z.string(),
      userEmail: z.string(),
      userRole: z.string(),
      expires: z.number().int(),
    })),
    note: z.string(), // onestà: JWT stateless → tabella Session vuota
  }),
})

/* ================================================================
 * 16.10.0 — W8: MULTI-IMPIANTO · IMPORT KMZ · TOPOLOGIA RIVISTA
 * ================================================================
 * Tre domande nuove (richiesta operatore 30/10):
 *   1. «Come aggiungo un altro impianto?» → CRUD impianti reali
 *      (v15: POST /plants RESPONSABILE_COMUNE+), selettore impianto
 *      attivo nel client, perimetro dati per impianto.
 *   2. «Posso caricare la mappa KMZ dell'impianto?» → import punti
 *      KMZ/KML a DUE FASI (preview piano → conferma operatore →
 *      apply), porta fedele v11.16: il client non decide nulla.
 *   3. «La topologia riportata è sbagliata» + «trova una
 *      rappresentazione migliore» → gestione MANUALE dei
 *      collegamenti (conferma/correzione/eliminazione/purge delle
 *      inferenze), radice scelta dall'operatore, grafo filtrabile
 *      per FONTE del collegamento (operatore/protocolli/UISP/inferiti).
 * ================================================================ */

/* ---------------- /api/v2/plants (CRUD completo) ---------------- */

export const CreatePlantInputSchema = z.object({
  name: z.string().min(1, 'Il nome è obbligatorio').max(120),
  comune: z.string().min(1, 'Il comune è obbligatorio').max(120),
  address: z.string().max(300).optional(),
  notes: z.string().max(2000).optional(),
  telegramChatId: z.string().max(100).optional(),
  mapCenterLat: z.number().min(-90).max(90).optional(),
  mapCenterLng: z.number().min(-180).max(180).optional(),
  mapZoom: z.number().int().min(1).max(20).optional(),
  pingIntervalSec: z.number().int().min(5).max(3600).optional(),
  outageTimerMinutes: z.number().int().min(1).max(1440).optional(),
  snmpCommunities: z.string().max(300).optional(),
  isActive: z.boolean().optional(),
})
export type CreatePlantInput = z.infer<typeof CreatePlantInputSchema>

export const UpdatePlantInputSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  comune: z.string().min(1).max(120).optional(),
  address: z.string().max(300).optional(),
  notes: z.string().max(2000).optional(),
  telegramChatId: z.string().max(100).optional(),
  mapCenterLat: z.number().min(-90).max(90).optional(),
  mapCenterLng: z.number().min(-180).max(180).optional(),
  mapZoom: z.number().int().min(1).max(20).optional(),
  pingIntervalSec: z.number().int().min(5).max(3600).optional(),
  outageTimerMinutes: z.number().int().min(1).max(1440).optional(),
  snmpCommunities: z.string().max(300).optional(),
  isActive: z.boolean().optional(),
  // v11.27: la radice SCELTA dall'operatore batte ogni euristica.
  // null = torna all'inferenza automatica. Il dispositivo deve
  // appartenere ALL'IMPIANTO (verificato lato route).
  topologyRootDeviceId: z.string().min(1).nullable().optional(),
}).refine((v) => Object.keys(v).some((k) => v[k as keyof typeof v] !== undefined), {
  message: 'Almeno un campo è richiesto',
})
export type UpdatePlantInput = z.infer<typeof UpdatePlantInputSchema>

export const PlantDeletedSchema = ApiEnvelopeSchema.extend({
  data: z.object({ deleted: z.literal(true), id: z.string() }),
})

/* ---------------- /api/v2/locations/import-kmz (2 fasi) ---------------- */

/** Piano di import: NESSUNA scrittura in preview (porta v11.16). */
export const KmzPreviewSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    fileId: z.string(), // opaco: il file resta sul server, la apply lo RIAPRE
    fileName: z.string(),
    plantId: z.string(),
    points: z.array(z.object({
      placemarkIndex: z.number().int(),
      name: z.string(),
      description: z.string(),
      lat: z.number(),
      lng: z.number(),
      action: z.enum(['CREATE', 'UPDATE_COORDS', 'NOOP']),
      existingLocationId: z.string().nullable(),
      existingLocationName: z.string().nullable(),
      identifier: z.string().nullable(),
      reason: z.string(),
      deviceProposals: z.array(z.object({
        deviceId: z.string(),
        hostname: z.string(),
        ip: z.string(),
        type: z.string(),
        confidence: z.enum(['ALTA', 'MEDIA', 'BASSA']),
        basis: z.string(),
      })),
    })),
    created: z.number().int(),
    updated: z.number().int(),
    noop: z.number().int(),
    skipped: z.array(z.object({ name: z.string(), reason: z.string() })),
    unplacedDevices: z.number().int(),
    totalDevices: z.number().int(),
  }),
})
export type KmzPreview = z.infer<typeof KmzPreviewSchema>['data']

export const KmzApplyInputSchema = z.object({
  fileId: z.string().min(1),
  plantId: z.string().min(1),
  points: z.array(z.object({
    placemarkIndex: z.number().int().min(0),
    action: z.enum(['CREATE', 'UPDATE_COORDS', 'NOOP']),
    existingLocationId: z.string().min(1).nullable().optional(),
    deviceIds: z.array(z.string().min(1)).optional(),
  })).min(1, 'Almeno un punto confermato è richiesto'),
})
export type KmzApplyInput = z.infer<typeof KmzApplyInputSchema>

export const KmzApplyResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    created: z.number().int(),
    updated: z.number().int(),
    assigned: z.number().int(),
    noop: z.number().int(),
    /** v16.13 W11: collegamenti derivati dai percorsi «Linea» del KMZ
     * (buchi non coperti dall'Excel); opzionale per retrocompatibilità. */
    linksCreated: z.number().int().optional(),
    plantKmzFile: z.string(),
  }),
})
export type KmzApplyResult = z.infer<typeof KmzApplyResultSchema>['data']

/* ---------------- /api/v2/import/xlsx (2 fasi, W11) ----------------
 * «magari posso caricare excel e kmz in modo che troviamo modo anche
 * per altri impianti di partire già avvantaggiati» (operatore, 30/10):
 * l'Excel di installazione SETI (sezioni = sedi, righe = apparati con
 * IP/nome/SSID/credenziali) avvia un impianto con inventario E
 * topologia reale (link radio dai gruppi SSID + LAN di sede). */

export const XlsxPreviewSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    fileId: z.string(), // opaco: la apply RIAPRE il file temporaneo
    fileName: z.string(),
    plantId: z.string(),
    sheetName: z.string(),
    network: z.string(),
    sections: z.array(z.object({
      sectionIndex: z.number().int(),
      sectionName: z.string(),
      action: z.enum(['CREATE', 'MAP']),
      locationId: z.string().nullable(),
      locationName: z.string().nullable(),
      confidence: z.enum(['ALTA', 'MEDIA', 'BASSA']).nullable(),
      reason: z.string(),
      devices: z.array(z.object({
        ip: z.string(),
        name: z.string(),
        type: z.string(),
        ssid: z.string(),
        isPtp: z.boolean(),
        hasPassword: z.boolean(),
        serial: z.string(),
        action: z.enum(['CREATE', 'UPDATE']),
        deviceId: z.string().nullable(),
        existingHostname: z.string().nullable(),
        hostnameChanged: z.boolean(),
      })),
    })),
    links: z.array(z.object({
      ssid: z.string(),
      sourceIp: z.string(),
      sourceName: z.string(),
      sourceSection: z.string(),
      targetIp: z.string(),
      targetName: z.string(),
      targetSection: z.string(),
      label: z.string(),
      frequency: z.string(),
      basis: z.string(),
      confidence: z.enum(['ALTA', 'MEDIA', 'BASSA']),
    })),
    synthetic: z.array(z.object({
      name: z.string(),
      ssid: z.string(),
      locationId: z.string().nullable(),
      locationName: z.string().nullable(),
      locationBasis: z.string(),
      stations: z.array(z.object({ ip: z.string(), name: z.string(), section: z.string() })),
    })),
    lonelySsids: z.array(z.object({ ssid: z.string(), ip: z.string(), name: z.string() })),
    unmatchedExisting: z.array(z.object({
      deviceId: z.string(),
      ip: z.string(),
      hostname: z.string(),
      locationName: z.string().nullable(),
    })),
    autoLinkCount: z.number().int(),
    stats: z.object({
      devicesCreate: z.number().int(),
      devicesUpdate: z.number().int(),
      locationsCreate: z.number().int(),
      locationsMap: z.number().int(),
      links: z.number().int(),
      synthetic: z.number().int(),
    }),
  }),
})
export type XlsxPreview = z.infer<typeof XlsxPreviewSchema>['data']

export const XlsxApplyInputSchema = z.object({
  fileId: z.string().min(1),
  plantId: z.string().min(1),
  /** SOLO le sezioni incluse dall'operatore (indici + sede scelta) */
  sections: z.array(z.object({
    sectionIndex: z.number().int().min(0),
    locationId: z.string().min(1).nullable().optional(),
  })).min(1, 'Almeno una sezione confermata è richiesta'),
  createLinks: z.boolean(),
  createLanLinks: z.boolean(),
  /** basestation sintetiche confermate (indici del piano) */
  synthetic: z.array(z.object({
    index: z.number().int().min(0),
    locationId: z.string().min(1).nullable().optional(),
  })),
  purgeAutoLinks: z.boolean(),
})
export type XlsxApplyInput = z.infer<typeof XlsxApplyInputSchema>

export const XlsxApplyResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    locationsCreated: z.number().int(),
    devicesCreated: z.number().int(),
    devicesUpdated: z.number().int(),
    linksCreated: z.number().int(),
    syntheticCreated: z.number().int(),
    autoLinksPurged: z.number().int(),
  }),
})
export type XlsxApplyResult = z.infer<typeof XlsxApplyResultSchema>['data']

/* ---------------- /api/v2/topology/links (gestione manuale) ---------------- */

export const VALID_LINK_TYPES = ['RADIO', 'FIBRA', 'UTP_COPPER', 'FIBRA_SINGLEMODE', 'FIBRA_MULTIMODE', 'WIRELESS_BRIDGE', 'POE_SWITCH', 'ETHERNET'] as const
/** Fonti dei collegamenti, in FAMIGLIE (per il filtro del grafo):
 *  OPERATORE (verità) · PROTOCOLLI (LLDP/MNDP dichiarati dai dispositivi) ·
 *  UISP (dichiarato dalla gestione esterna) · INFERITI (FDB/BRIDGE_MIB/
 *  DAISY_CHAIN/INFERRED: letture SNMP del bridge — le più fragili). */
/** Fonti ammesse come sourceOfTruth sui link (vocabolario del grafo e del
 *  purge). v16.15 W14: +FDB_MUTUAL/FDB_PAIR/STP_DESIGNATED — le evidenze
 *  della correlazione multi-switch (avvistamento reciproco con porte di
 *  entrambi i lati, coppia unidirezionale, solo bridge designato STP):
 *  il vocabolario v15 le conosceva già (link-rules TIER_ATTACH_COST),
 *  il grafo v16 le escludeva per omissione. */
export const LINK_SOURCES = ['TECHNICIAN', 'LLDP', 'CDP', 'MNDP', 'UISP', 'INFERRED', 'FDB', 'BRIDGE_MIB', 'DAISY_CHAIN', 'FDB_MUTUAL', 'FDB_PAIR', 'STP_DESIGNATED'] as const
export type LinkSource = (typeof LINK_SOURCES)[number]
export const DEFAULT_GRAPH_SOURCES: LinkSource[] = ['TECHNICIAN', 'LLDP', 'MNDP', 'UISP']

export const TopologyLinkRowSchema = z.object({
  id: z.string(),
  sourceDeviceId: z.string().nullable(),
  sourceHostname: z.string().nullable(),
  sourceIp: z.string(),
  sourceType: z.string(),
  targetDeviceId: z.string().nullable(),
  targetHostname: z.string().nullable(),
  targetIp: z.string(),
  targetType: z.string(),
  sourceLabel: z.string(),
  targetLabel: z.string(),
  linkType: z.string(),
  linkStatus: z.string(),
  confidence: z.string(),
  evidence: z.string(),
  sourceOfTruth: z.string(),
  confirmed: z.boolean(),
  sourcePort: z.string(),
  targetPort: z.string(),
  speedMbps: z.number().int(),
  duplex: z.string(),
  trafficInMbps: z.number(),
  trafficOutMbps: z.number(),
  label: z.string(),
  notes: z.string(),
  updatedAt: z.number().int(),
})
export type TopologyLinkRow = z.infer<typeof TopologyLinkRowSchema>

export const TopologyLinksQuerySchema = z.object({
  plantId: z.string().optional(),
  source: z.string().optional(), // filtro per sourceOfTruth (LINK_SOURCES)
  confidence: z.enum(['HIGH', 'MEDIUM', 'LOW', 'EMPTY']).optional(),
  confirmed: z.enum(['true', 'false']).optional(),
  q: z.string().max(120).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(10).max(200).default(50),
})

export const TopologyLinksPageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    links: z.array(TopologyLinkRowSchema),
    total: z.number().int(),
    page: z.number().int(),
    pageSize: z.number().int(),
    stats: z.object({
      total: z.number().int(),
      confirmed: z.number().int(),
      bySource: z.array(z.object({ source: z.string(), count: z.number().int() })),
      byConfidence: z.array(z.object({ confidence: z.string(), count: z.number().int() })),
    }),
  }),
})
export type TopologyLinksPage = z.infer<typeof TopologyLinksPageSchema>['data']

export const CreateTopologyLinkInputSchema = z.object({
  plantId: z.string().min(1),
  sourceDeviceId: z.string().min(1, 'Il dispositivo sorgente è obbligatorio'),
  targetDeviceId: z.string().min(1, 'Il dispositivo destinazione è obbligatorio'),
  linkType: z.enum(VALID_LINK_TYPES).default('ETHERNET'),
  label: z.string().max(200).optional(),
  notes: z.string().max(1000).optional(),
  sourcePort: z.string().max(100).optional(),
  targetPort: z.string().max(100).optional(),
  speedMbps: z.number().int().min(0).max(100000).optional(),
}).refine((v) => v.sourceDeviceId !== v.targetDeviceId, {
  message: 'Sorgente e destinazione devono essere dispositivi diversi',
})
export type CreateTopologyLinkInput = z.infer<typeof CreateTopologyLinkInputSchema>

export const UpdateTopologyLinkInputSchema = z.object({
  linkType: z.enum(VALID_LINK_TYPES).optional(),
  label: z.string().max(200).optional(),
  notes: z.string().max(1000).optional(),
  sourcePort: z.string().max(100).optional(),
  targetPort: z.string().max(100).optional(),
  speedMbps: z.number().int().min(0).max(100000).optional(),
  linkStatus: z.enum(['ACTIVE', 'INACTIVE', 'DEGRADED', 'FAULTY', 'UNKNOWN']).optional(),
  /** «Conferma» (cristallizzazione v15): il link diventa verità
   *  dell'OPERATORE — confirmed=true e sourceOfTruth=TECHNICIAN. */
  confirmed: z.boolean().optional(),
}).refine((v) => Object.keys(v).some((k) => v[k as keyof typeof v] !== undefined), {
  message: 'Almeno un campo è richiesto',
})
export type UpdateTopologyLinkInput = z.infer<typeof UpdateTopologyLinkInputSchema>

export const TopologyLinkDeletedSchema = ApiEnvelopeSchema.extend({
  data: z.object({ deleted: z.literal(true), id: z.string() }),
})

/** Purge delle inferenze: MAI su link confermati o dell'operatore.
 *  dryRun=true → solo il conteggio onesto, NESSUNA scrittura. */
export const PurgeLinksInputSchema = z.object({
  plantId: z.string().min(1),
  sources: z.array(z.enum(LINK_SOURCES)).min(1, 'Almeno una fonte da ripulire').refine(
    (v) => !v.includes('TECHNICIAN'),
    { message: 'TECHNICIAN non è ripulibile: i collegamenti dell\'operatore sono verità' },
  ),
  dryRun: z.boolean().default(true),
})
export type PurgeLinksInput = z.infer<typeof PurgeLinksInputSchema>

export const PurgeLinksResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    dryRun: z.boolean(),
    count: z.number().int(),
    sample: z.array(z.object({
      sourceHostname: z.string(),
      targetHostname: z.string(),
      sourceOfTruth: z.string(),
    })),
  }),
})
export type PurgeLinksResult = z.infer<typeof PurgeLinksResultSchema>['data']

/* ================================================================
 * v16.18 W20 — TELEMETRIA RADIO & SALUTE + «DOVE È COLLEGATO»
 * ================================================================ */

/* ---------------- POST /api/v2/discovery/radio ---------------- */

export const RadioTelemetryInputSchema = z.object({
  plantId: z.string().optional(),
  deviceId: z.string().min(1, 'Il dispositivo da sondare è obbligatorio'),
  communities: z.array(z.string().min(1).max(64)).max(8, 'Massimo 8 community aggiuntive').optional(),
  timeoutMs: z.number().int().min(300).max(8000).optional(),
})
export type RadioTelemetryInput = z.infer<typeof RadioTelemetryInputSchema>

/** Una radio dichiarata dall'apparato (stat table MikroTik / firma airMAX). */
export const RadioInterfaceSchema = z.object({
  index: z.number().int(),
  ssid: z.string().nullable(),
  band: z.string().nullable(),
  frequencyMhz: z.number().int().nullable(),
  signalDbm: z.number().int().nullable(),
  noiseFloorDbm: z.number().int().nullable(),
  snrDb: z.number().int().nullable(),
  txRateMbps: z.number().int().nullable(),
  rxRateMbps: z.number().int().nullable(),
  ccqPercent: z.number().int().nullable(),
})

/** Un client radio visto dall'AP (registration table). */
export const RadioClientSchema = z.object({
  mac: z.string().nullable(),
  signalDbm: z.number().int().nullable(),
  txRateMbps: z.number().int().nullable(),
  rxRateMbps: z.number().int().nullable(),
  lastIp: z.string().nullable(),
})

/** Porta ETHERNET dell'apparato: velocità e duplex negoziali. */
export const RadioPortSchema = z.object({
  ifIndex: z.number().int(),
  name: z.string().nullable(),
  speedMbps: z.number().int().nullable(),
  duplex: z.enum(['full', 'half']).nullable(),
})

/** Provenance: QUALE OID ha risposto per QUALE campo (l'operatore può
 *  verificare sul campo — la sonda non inventa mai la fonte). */
export const RadioProvenanceSchema = z.object({
  field: z.string(),
  oid: z.string(),
  label: z.string(),
  confidence: z.enum(['verified', 'high', 'medium']),
})

export const RadioTelemetryResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    device: z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
    }),
    reachable: z.boolean(),
    sysName: z.string().nullable(),
    sysDescr: z.string().nullable(),
    matched: z.object({ community: z.string(), version: z.string() }).nullable(),
    error: z.string().nullable(),
    detail: z.string().nullable(),
    health: z.object({
      cpuLoadPct: z.number().int().nullable(),
      ramUsedKb: z.number().int().nullable(),
      ramTotalKb: z.number().int().nullable(),
      provenance: z.array(RadioProvenanceSchema),
    }),
    radios: z.array(RadioInterfaceSchema),
    clients: z.array(RadioClientSchema),
    ports: z.array(RadioPortSchema),
    provenance: z.array(RadioProvenanceSchema),
    /** Modalità radio DEDOTTA dalla telemetria reale: client>0 → AP
     *  (linkMode PTP se 1 client, PTMP se più); segnale senza client → STA. */
    derived: z.object({
      radioMode: z.enum(['ap', 'sta', '']).nullable(),
      linkMode: z.enum(['PTP', 'PTMP', '']).nullable(),
      note: z.string(),
    }),
    /** Campi PERSISTITI sul Device (ciò che la UI mostrerà da qui in poi). */
    persisted: z.object({
      cpuLoad: z.boolean(),
      ram: z.boolean(),
      ssid: z.boolean(),
      signalStrength: z.boolean(),
      linkQuality: z.boolean(),
      currentFrequency: z.boolean(),
      radioMode: z.boolean(),
      uptimeSeconds: z.boolean(),
      metricsSaved: z.number().int(),
      snmpEnableState: z.string(),
    }),
    warnings: z.array(z.string()),
    notes: z.array(z.string()),
  }),
})
export type RadioTelemetryResult = z.infer<typeof RadioTelemetryResultSchema>['data']

/* ---------------- GET /api/v2/locate (dove è collegato) ---------------- */

export const LocateQuerySchema = z.object({
  q: z.string().trim().min(2, 'Cerca per IP, MAC o hostname (minimo 2 caratteri)').max(100),
  plantId: z.string().optional(),
})
export type LocateQuery = z.infer<typeof LocateQuerySchema>

/** Un avvistamento: lo switch X ha imparato il MAC sulla porta Y. */
export const LocateSightingSchema = z.object({
  switchId: z.string(),
  switchHostname: z.string(),
  switchType: z.string(),
  portName: z.string(),
  lastSeenAt: z.number().int(),
  /** Velocità/duplex del link verso quella porta (se il link esiste). */
  speedMbps: z.number().int().nullable(),
  duplex: z.enum(['full', 'half']).nullable(),
})

export const LocateResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    query: z.string(),
    /** MAC normalizzato usato per la ricerca (null se la query non era
     *  risolvibile a MAC). */
    resolvedMac: z.string().nullable(),
    /** IP risolto (dalla query o dall'ARP del MAC). */
    resolvedIp: z.string().nullable(),
    /** Il dispositivo dell'inventario corrispondente (se esiste). */
    device: z.object({
      id: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
      uiStatus: z.string(),
      macAddress: z.string(),
      locationName: z.string().nullable(),
    }).nullable(),
    /** Come è stata risolta la ricerca (onestà sul percorso). */
    resolution: z.array(z.string()),
    sightings: z.array(LocateSightingSchema),
    /** Link di topologia che coinvolgono il dispositivo (uplink). */
    links: z.array(z.object({
      id: z.string(),
      sourceHostname: z.string(),
      targetHostname: z.string(),
      sourcePort: z.string(),
      targetPort: z.string(),
      sourceOfTruth: z.string(),
      confidence: z.string(),
      speedMbps: z.number().int(),
      duplex: z.enum(['full', 'half']).nullable(),
    })),
    notes: z.array(z.string()),
  }),
})
export type LocateResult = z.infer<typeof LocateResultSchema>['data']

/* ================================================================
 * W21 — WIZARD «SETUP IMPIANTO» (fasi: scansione → credenziali →
 * adozione → allarmi → riepilogo). I contratti qui sotto coprono
 * le rotte /api/v2/setup/*: ogni fase dichiara cosa ha FATTO davvero
 * (persistenze, sonde, conteggi) — mai promesse, solo evidenze.
 * ================================================================ */

/* ---------------- POST /api/v2/setup/scan ---------------- */

export const SetupScanInputSchema = z.object({
  plantId: z.string().optional(),
  cidr: z.string().trim().min(7).max(43),
  /** Porte TCP aggiuntive per lo sweep (es. 2222, 8081 in laboratorio). */
  ports: z.array(z.number().int().min(1).max(65535)).max(64).optional(),
  /** Community SNMP da tentare nell'identificazione (max 8). */
  communities: z.array(z.string().trim().min(1).max(64)).max(8).optional(),
  /** Porta SNMP dell'agente quando NON è quella standard 161. */
  snmpPort: z.number().int().min(1).max(65535).optional(),
  /** Porta TCP del pannello web quando NON è 80/8080 (banner HTTP). */
  httpPort: z.number().int().min(1).max(65535).optional(),
  timeoutMs: z.number().int().min(200).max(4000).optional(),
})
export type SetupScanInput = z.infer<typeof SetupScanInputSchema>

/** Un candidato visto in rete: evidenza GREZZA della sonda + stato inventario. */
export const SetupCandidateSchema = z.object({
  ip: z.string(),
  alive: z.boolean(),
  latencyMs: z.number().nullable(),
  openPorts: z.array(z.number().int()),
  snmp: z.object({
    reachable: z.boolean(),
    matchedCommunity: z.string().nullable(),
    sysName: z.string().nullable(),
    sysDescr: z.string().nullable(),
    mac: z.string().nullable(),
    vendor: z.string().nullable(),
    model: z.string().nullable(),
    osFamily: z.string().nullable(),
    snmpPort: z.number().int(),
  }),
  http: z.object({ server: z.string().nullable(), title: z.string().nullable() }).nullable(),
  classification: z.object({
    type: z.string(),
    brand: z.string().nullable(),
    model: z.string().nullable(),
    confidence: z.string(),
    evidenceCount: z.number().int(),
  }),
  /** Il dispositivo di inventario con lo stesso IP (se esiste). */
  inInventory: z.boolean(),
  deviceId: z.string().nullable(),
  deviceHostname: z.string().nullable(),
  /** Suggerimento onesto per l'adozione (tipo + modalità monitoraggio). */
  suggestedType: z.string(),
  suggestedMonitorMode: z.enum(['full', 'ping']),
  suggestionReason: z.string(),
})
export type SetupCandidate = z.infer<typeof SetupCandidateSchema>

export const SetupScanResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    jobId: z.string(),
    cidr: z.string(),
    scanned: z.number().int(),
    up: z.number().int(),
    durationMs: z.number().int(),
    identified: z.number().int(),
    candidates: z.array(SetupCandidateSchema),
    comparison: z.object({
      confirmed: z.number().int(), // in inventario E visti
      missing: z.number().int(), // in inventario, NON visti
      newSeen: z.number().int(), // visti, NON in inventario
      missingIps: z.array(z.string()),
    }),
    warnings: z.array(z.string()),
  }),
})
export type SetupScanResult = z.infer<typeof SetupScanResultSchema>['data']

/* ---------------- POST /api/v2/setup/verify ---------------- */

export const SetupVerifyInputSchema = z.object({
  plantId: z.string().optional(),
  /** Porta SNMP di default per gli apparati senza porta dichiarata
   *  (quella dichiarata nella fase scansione del wizard). */
  snmpPort: z.number().int().min(1).max(65535).optional(),
  /** Porta SSH di default (laboratori/NAT; default: quella dell'apparato
   *  o 22). Al successo viene salvata sul dispositivo. */
  sshPort: z.number().int().min(1).max(65535).optional(),
  /** Porta TCP di gestione per i TLC in ping-only quando quella
   *  dichiarata (default 80) non è quella vista in scansione. */
  httpPort: z.number().int().min(1).max(65535).optional(),
})
export type SetupVerifyInput = z.infer<typeof SetupVerifyInputSchema>

export const SetupVerifyDeviceRowSchema = z.object({
  deviceId: z.string(),
  hostname: z.string(),
  ip: z.string(),
  type: z.string(),
  monitorMode: z.enum(['full', 'ping']),
  snmp: z.object({
    tried: z.boolean(),
    reachable: z.boolean(),
    matchedCommunity: z.string().nullable(),
    sysName: z.string().nullable(),
    error: z.string().nullable(),
  }),
  ssh: z.object({
    tried: z.boolean(),
    authenticated: z.boolean().nullish(),
    error: z.string().nullish(),
  }),
  ping: z.object({
    tried: z.boolean(),
    alive: z.boolean().nullish(),
    latencyMs: z.number().nullable(),
  }),
  credentialState: z.string(),
  credentialReason: z.string(),
  macRead: z.string().nullable(),
  communitySaved: z.boolean(),
})
export type SetupVerifyDeviceRow = z.infer<typeof SetupVerifyDeviceRowSchema>

export const SetupVerifyResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    devices: z.array(SetupVerifyDeviceRowSchema),
    summary: z.object({
      total: z.number().int(),
      snmpOk: z.number().int(),
      snmpMute: z.number().int(),
      sshOk: z.number().int(),
      sshFailed: z.number().int(),
      pingAlive: z.number().int(),
      pingMute: z.number().int(),
      credentialsOk: z.number().int(),
      credentialsWrong: z.number().int(),
      credentialsMissing: z.number().int(),
      credentialsUnknown: z.number().int(),
    }),
    durationMs: z.number().int(),
    warnings: z.array(z.string()),
  }),
})
export type SetupVerifyResult = z.infer<typeof SetupVerifyResultSchema>['data']

/* ---------------- POST /api/v2/setup/adopt ---------------- */

export const SetupAdoptInputSchema = z.object({
  plantId: z.string().optional(),
  /** Job di scansione da usare (default: l'ultimo COMPLETED del plant). */
  jobId: z.string().optional(),
  /** Override per singolo candidato (per IP): tipo e modalità monitoraggio. */
  overrides: z.array(z.object({
    ip: z.string(),
    type: z.string().optional(),
    monitorMode: z.enum(['full', 'ping']).optional(),
  })).max(64).optional(),
  /** IP da NON adottare (es. host d'infrastruttura). */
  skipIps: z.array(z.string()).max(64).optional(),
  /** Nome dell'autore della decisione (audit). */
  note: z.string().max(200).optional(),
})
export type SetupAdoptInput = z.infer<typeof SetupAdoptInputSchema>

export const SetupAdoptResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    created: z.array(z.object({
      deviceId: z.string(),
      hostname: z.string(),
      ip: z.string(),
      type: z.string(),
      monitorMode: z.string(),
      macAddress: z.string(),
      brand: z.string(),
      snmpEnabled: z.boolean(),
      baselineUntil: z.number().int().nullable(),
    })),
    skipped: z.array(z.object({ ip: z.string(), reason: z.string() })),
    orphansAfter: z.number().int(),
    comparison: z.object({
      confirmed: z.number().int(),
      missing: z.number().int(),
      newSeen: z.number().int(),
      adoptedNow: z.number().int(),
      missingIps: z.array(z.string()),
    }),
    warnings: z.array(z.string()),
  }),
})
export type SetupAdoptResult = z.infer<typeof SetupAdoptResultSchema>['data']

/* ---------------- POST /api/v2/setup/alarms ---------------- */

export const SetupAlarmsInputSchema = z.object({
  plantId: z.string().optional(),
  signalThresholdDbm: z.number().int().min(-100).max(-40).optional(),
})
export type SetupAlarmsInput = z.infer<typeof SetupAlarmsInputSchema>

export const SetupAlarmsResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    rules: z.array(z.object({
      systemKey: z.string(),
      name: z.string(),
      enabled: z.boolean(),
      metric: z.string(),
      threshold: z.number().nullable(),
      severity: z.string(),
      justCreated: z.boolean(),
    })),
    events: z.array(z.object({
      eventId: z.string(),
      systemKey: z.string(),
      severity: z.string(),
      deviceId: z.string().nullable(),
      deviceHostname: z.string().nullable(),
      message: z.string(),
      deduplicated: z.boolean(),
    })),
    evaluated: z.object({
      devicesChecked: z.number().int(),
      signalLow: z.number().int(),
      offline: z.number().int(),
      orphansNew: z.number().int(),
      topologyLinksFresh: z.number().int(),
      portStateBaseline: z.number().int(),
    }),
    honestNotes: z.array(z.string()),
  }),
})
export type SetupAlarmsResult = z.infer<typeof SetupAlarmsResultSchema>['data']

/* ---------------- GET /api/v2/setup/summary ---------------- */

export const SetupSummaryResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    plant: z.object({
      id: z.string(),
      name: z.string(),
      comune: z.string(),
      criticalityLevel: z.string(),
      kmzFile: z.string(),
      createdAt: z.number().int(),
    }),
    importPhase: z.object({
      locations: z.number().int(),
      devicesInInventory: z.number().int(),
      devicesByType: z.array(z.object({ type: z.string(), count: z.number().int() })),
      devicesWithSshCredentials: z.number().int(),
    }),
    scanPhase: z.object({
      lastJob: z.object({
        id: z.string(),
        subnet: z.string(),
        status: z.string(),
        hostsScanned: z.number().int(),
        devicesFound: z.number().int(),
        startedAt: z.number().int(),
        finishedAt: z.number().int().nullable(),
      }).nullable(),
      candidatesSeen: z.number().int(),
      candidatesInInventory: z.number().int(),
      candidatesNew: z.number().int(),
    }),
    verifyPhase: z.object({
      credentialsOk: z.number().int(),
      credentialsWrong: z.number().int(),
      credentialsMissing: z.number().int(),
      credentialsUnknown: z.number().int(),
      snmpEnabled: z.number().int(),
      pingMode: z.number().int(),
    }),
    telemetryPhase: z.object({
      radioProbed: z.number().int(),
      l2Probed: z.number().int(),
      pingSwept: z.number().int(),
      metricSamples2h: z.number().int(),
      radioMetrics2h: z.number().int(),
      pingMetrics2h: z.number().int(),
      trafficMetrics2h: z.number().int(),
      devicesSeen2h: z.number().int(),
      devicesOnline: z.number().int(),
      devicesOffline: z.number().int(),
    }),
    topologyPhase: z.object({
      links: z.number().int(),
      linksByEvidence: z.array(z.object({ evidence: z.string(), count: z.number().int() })),
      fdbObservations: z.number().int(),
      arpEntries: z.number().int(),
      stpObservations: z.number().int(),
      vlans: z.number().int(),
      macKnownInInventory: z.number().int(),
      macSeenNotInInventory: z.number().int(),
      vendorUnknown: z.number().int(),
      vendorUnknownDevices: z.array(z.object({ hostname: z.string(), ip: z.string(), macAddress: z.string() })),
    }),
    alarmsPhase: z.object({
      rulesEnabled: z.number().int(),
      rulesTotal: z.number().int(),
      eventsOpen: z.number().int(),
      eventsBySeverity: z.array(z.object({ severity: z.string(), count: z.number().int() })),
    }),
    engines: z.object({
      discoveryService: z.object({
        reachable: z.boolean(),
        version: z.string().nullable(),
        uptimeSec: z.number().nullable(),
        capabilities: z.number().int().nullable(),
        ouiPrefixes: z.number().int().nullable(),
      }),
      realtimeService: z.object({
        mode: z.string(),
        lastTickAt: z.number().int().nullable(),
        intervalSec: z.number().int().nullable(),
      }),
      /** v16.19 W21-bis: il «puller» continuo (presenza + SNMP + radio +
       *  valutazione allarmi + notifiche) — running=false quando fermo.
       *  v16.20 W22: startedVia (chi ha avviato la sessione) + autoResume
       *  (configurazione persistita: al riavvio del server riparte da solo). */
      monitoringEngine: z.object({
        running: z.boolean(),
        busy: z.boolean(),
        startedVia: z.string().nullable(),
        autoResume: z.boolean(),
        intervalSec: z.number().int().nullable(),
        radioEvery: z.number().int().nullable(),
        cycles: z.number().int(),
        lastCycleAt: z.number().int().nullable(),
        lastCycleDurationMs: z.number().int().nullable(),
        metricsWritten: z.number().int(),
        eventsOpened: z.number().int(),
        eventsClosed: z.number().int(),
        notificationsSent: z.number().int(),
        notificationsSkipped: z.number().int(),
        errors: z.array(z.string()),
      }),
      dbReachable: z.boolean(),
      apiReachable: z.boolean(),
    }),
    honestNotes: z.array(z.string()),
  }),
})
export type SetupSummaryResult = z.infer<typeof SetupSummaryResultSchema>['data']

/* ---------------- GET/POST /api/v2/setup/engine (W21-bis + W22 auto-resume) ---------------- */

export const EngineStatusRowSchema = z.object({
  plantId: z.string(),
  plantName: z.string(),
  running: z.boolean(),
  busy: z.boolean(),
  intervalSec: z.number().int(),
  radioEvery: z.number().int(),
  /** v16.20 W22: chi ha avviato QUESTA sessione del motore. */
  startedVia: z.enum(['WIZARD', 'AUTO_RESUME', 'API']),
  startedAt: z.number().int(),
  cycles: z.number().int(),
  lastCycleAt: z.number().int().nullable(),
  lastCycleDurationMs: z.number().int().nullable(),
  metricsWritten: z.number().int(),
  eventsOpened: z.number().int(),
  eventsClosed: z.number().int(),
  notificationsSent: z.number().int(),
  notificationsFailed: z.number().int(),
  notificationsSkipped: z.number().int(),
  pingSweeps: z.number().int(),
  snmpProbes: z.number().int(),
  radioProbes: z.number().int(),
  errors: z.array(z.string()),
})
export type EngineStatusRow = z.infer<typeof EngineStatusRowSchema>

/** v16.20 W22 — riga EngineRuntime persistita (osservabilità dal DB):
 *  anche un motore NON in memoria è visibile (enabled, heartbeat, via). */
export const EngineRuntimeInfoSchema = z.object({
  plantId: z.string(),
  plantName: z.string(),
  enabled: z.boolean(),
  intervalSec: z.number().int(),
  radioEveryNCycles: z.number().int(),
  startedVia: z.string(),
  lastStartedAt: z.number().int().nullable(),
  lastHeartbeatAt: z.number().int().nullable(),
  lastStoppedAt: z.number().int().nullable(),
  stopReason: z.string(),
  cycles: z.number().int(),
  totalCycles: z.number().int(),
  lastError: z.string(),
})
export type EngineRuntimeInfo = z.infer<typeof EngineRuntimeInfoSchema>

export const EngineInputSchema = z.object({
  action: z.enum(['start', 'stop']),
  plantId: z.string().optional(),
  intervalSec: z.number().int().min(5).max(3600).optional(),
  radioEvery: z.number().int().min(1).max(60).optional(),
})
export type EngineInput = z.infer<typeof EngineInputSchema>

export const SetupEnginePageSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    engines: z.array(EngineStatusRowSchema),
    /** v16.20 W22: motori PERSISTITI (dal DB) — auto-resume enterprise. */
    runtimes: z.array(EngineRuntimeInfoSchema),
    honestNotes: z.array(z.string()),
  }),
})
export type SetupEnginePage = z.infer<typeof SetupEnginePageSchema>['data']

export const SetupEngineActionResultSchema = ApiEnvelopeSchema.extend({
  data: z.object({
    action: z.enum(['start', 'stop']),
    stopped: z.boolean().optional(),
    engine: EngineStatusRowSchema.optional(),
    engines: z.array(EngineStatusRowSchema),
  }),
})
export type SetupEngineActionResult = z.infer<typeof SetupEngineActionResultSchema>['data']



