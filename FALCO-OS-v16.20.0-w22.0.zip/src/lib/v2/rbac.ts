/* ================================================================
 * FALCO-OS v16.9.0 (W4) — RBAC v2: catalogo permessi (port statico
 * fedele da v15.16.0 src/lib/rbac.ts, parte dichiarativa).
 * «Chi può fare cosa», dichiarato in UN punto ispezionabile invece
 * che sparso nelle rotte con check per-ruolo hard-coded.
 *  · i 4 ruoli (TECNICO / RESPONSABILE_COMUNE / SUPER_ADMIN / CLIENTE)
 *    restano la sola fonte di identità (enum Prisma Role);
 *  · SUPER_ADMIN = tutti i permessi ESPliciti (nessun '*');
 *  · fail-closed: permesso non in catalogo → negato per costruzione.
 * Le rotte v16 applicano hasRole() (gerarchia ROLE_RANK in auth.ts);
 * questa matrice è la DOCUMENTAZIONE ispezionabile dal SUPER_ADMIN
 * (GET /api/v2/admin/permissions) — come v12.0.0 V12-B.
 * ================================================================ */

export const PERMISSIONS = [
  // operativo
  'dashboard:read',
  'devices:read',
  'devices:write',
  'devices:delete',
  'tickets:read',
  'tickets:write',
  'alerts:read',
  'alerts:write',
  'interventions:read',
  'interventions:write',
  'topology:read',
  'topology:write',
  // anagrafica e governance
  'plants:read',
  'plants:write',
  'provisioning:read',
  'provisioning:write',
  'reports:read',
  'reports:write',
  'kb:read',
  'kb:write',
  'audit:read',
  // amministrazione
  'admin:read',
  'admin:write',
  'users:read',
  'users:write',
  'credentials:read',
  'credentials:write',
  'api-tokens:manage',
  'system:read',
  // v12 — integrazioni outbound
  'webhooks:read',
  'webhooks:write',
  'webhooks:delete',
  // v12.1 — compliance & accountability (catena audit + sessioni):
  // perimetro GLOBALE per definizione → solo SUPER_ADMIN in matrice
  'audit:seal',
  'audit:verify',
  'sessions:read',
  'sessions:revoke',
] as const

export type Permission = (typeof PERMISSIONS)[number]

export const ALL_ROLES = ['TECNICO', 'RESPONSABILE_COMUNE', 'SUPER_ADMIN', 'CLIENTE'] as const

/* Matrice ruolo → permessi (comportamento reale v15/v16):
 * TECNICO: operativo completo sugli impianti assegnati.
 * RESPONSABILE_COMUNE: TECNICO + visibilità amministrativa in LETTURA.
 * SUPER_ADMIN: tutto (esplicito).
 * CLIENTE (v13.3): sola lettura del proprio impianto. */

const TECNICO_PERMISSIONS: readonly Permission[] = [
  'dashboard:read',
  'devices:read',
  'devices:write',
  'devices:delete',
  'tickets:read',
  'tickets:write',
  'alerts:read',
  'alerts:write',
  'interventions:read',
  'interventions:write',
  'topology:read',
  'topology:write',
  'plants:read',
  'provisioning:read',
  'provisioning:write',
  'reports:read',
  'reports:write',
  'kb:read',
  'kb:write',
  'audit:read',
  'api-tokens:manage',
]

const RESPONSABILE_PERMISSIONS: readonly Permission[] = [
  ...TECNICO_PERMISSIONS,
  'admin:read',
  'system:read',
]

const CLIENTE_PERMISSIONS: readonly Permission[] = [
  'dashboard:read',
  'devices:read',
  'tickets:read',
  'alerts:read',
  'reports:read',
]

const ROLE_PERMISSIONS: Record<string, readonly Permission[]> = {
  TECNICO: TECNICO_PERMISSIONS,
  RESPONSABILE_COMUNE: RESPONSABILE_PERMISSIONS,
  SUPER_ADMIN: PERMISSIONS,
  CLIENTE: CLIENTE_PERMISSIONS,
}

/** Permessi effettivi del ruolo, ordinati come nel catalogo. */
export function permissionsForRole(role: string): readonly Permission[] {
  return ROLE_PERMISSIONS[role] ?? []
}

/** Matrice completa (per API admin / UI ispezione compliance). */
export function roleMatrix(): Record<string, readonly Permission[]> {
  return {
    TECNICO: permissionsForRole('TECNICO'),
    RESPONSABILE_COMUNE: permissionsForRole('RESPONSABILE_COMUNE'),
    SUPER_ADMIN: permissionsForRole('SUPER_ADMIN'),
    CLIENTE: permissionsForRole('CLIENTE'),
  }
}

/** Raggruppamento catalogo per modulo (per la UI admin). */
export function permissionModules(): { module: string; permissions: string[] }[] {
  const grouped = new Map<string, string[]>()
  for (const p of PERMISSIONS) {
    const [mod] = p.split(':')
    const list = grouped.get(mod) ?? []
    list.push(p)
    grouped.set(mod, list)
  }
  return [...grouped.entries()].map(([module, permissions]) => ({ module, permissions }))
}

/** Check booleano (stessa semantica v15; SUPER_ADMIN sempre vero). */
export function hasPermission(role: string, permission: Permission): boolean {
  if (role === 'SUPER_ADMIN') return true
  return permissionsForRole(role).includes(permission)
}

/* ================================================================
 * Password policy enterprise (port ridotto da v15 password-policy.ts
 * V12-H, config default senza env): min 10, quattro classi, lista
 * nera top-100, divieto dati personali (localpart email e nome ≥ 3).
 * PurA: nessuna dipendenza da db/logger.
 * ================================================================ */

const COMMON_PASSWORDS: ReadonlySet<string> = new Set([
  '123456', 'password', '123456789', '12345678', '12345', 'qwerty', '1234567',
  '111111', '1234567890', '123123', 'abc123', '1234', 'password1', 'iloveyou',
  '000000', 'qwerty123', 'zaq12wsx', 'dragon', 'sunshine', 'princess', 'letmein',
  '654321', 'monkey', '27653', '1qaz2wsx', '123321', 'qwertyuiop', 'superman',
  'asdfghjkl', 'admin', 'admin123', 'root', 'toor', 'pass', 'test', 'guest',
  'info', 'oracle', 'postgres', 'changeme', 'welcome', 'welcome1', 'p@ssw0rd',
  'passw0rd', 'password123', 'password!', 'secret', 'master', 'monkey123',
  'dragon123', 'football', 'baseball', 'soccer', 'hockey', 'letmein123',
  'login', 'webmaster', 'hello', 'hello123', 'freedom', 'whatever', 'qazwsx',
  'trustno1', 'batman', 'shadow', 'michael', 'jennifer', 'jordan', 'harley',
  'ranger', 'hunter', 'buster', 'soccer123', 'andrew', 'tigger', 'charlie',
  'robert', 'thomas', 'hockey123', 'george', 'asshole', 'computer', 'matrix',
  'silver', 'william', 'jordan23', 'falcon', 'flower', 'hannah', 'chocolate',
  'samsung', 'google', 'apple', 'minecraft', 'pokemon', 'starwars', 'winter',
  'summer', 'spring', 'autumn',
])

export interface PasswordPolicyResult {
  ok: boolean
  violations: Array<{ rule: string; message: string }>
}

/** Validazione PURA della policy (default v15 senza override env). */
export function validatePasswordPolicy(
  password: string,
  personal: { email?: string | null; name?: string | null },
): PasswordPolicyResult {
  const violations: Array<{ rule: string; message: string }> = []
  const p = String(password ?? '')
  if (p.length < 10) violations.push({ rule: 'minLength', message: 'almeno 10 caratteri' })
  if (p.length > 128) violations.push({ rule: 'maxLength', message: 'al massimo 128 caratteri' })
  if (!/[a-z]/.test(p)) violations.push({ rule: 'lowercase', message: 'almeno una minuscola' })
  if (!/[A-Z]/.test(p)) violations.push({ rule: 'uppercase', message: 'almeno una maiuscola' })
  if (!/[0-9]/.test(p)) violations.push({ rule: 'digit', message: 'almeno una cifra' })
  if (!/[^a-zA-Z0-9]/.test(p)) violations.push({ rule: 'symbol', message: 'almeno un simbolo' })
  const alpha = p.toLowerCase().replace(/[^a-z0-9]/g, '')
  if (COMMON_PASSWORDS.has(alpha)) {
    violations.push({ rule: 'blacklist', message: 'password troppo comune (lista nera pubblica)' })
  }
  const local = (personal.email ?? '').split('@')[0]?.toLowerCase() ?? ''
  if (local.length >= 3 && p.toLowerCase().includes(local)) {
    violations.push({ rule: 'personalEmail', message: 'contiene la propria email' })
  }
  const name = (personal.name ?? '').toLowerCase().replace(/\s+/g, '')
  if (name.length >= 3 && p.toLowerCase().includes(name)) {
    violations.push({ rule: 'personalName', message: 'contiene il proprio nome' })
  }
  return { ok: violations.length === 0, violations }
}
