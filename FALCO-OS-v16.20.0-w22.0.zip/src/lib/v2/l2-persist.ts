/* ================================================================
 * FALCO-OS v16.15 W14 — Persistenza sonda L2 (helper NON-route)
 * src/lib/v2/l2-persist.ts
 * ================================================================
 * «La sonda dichiara, la rotta decide cosa scrivere.» Qui vivono le
 * SCRITTURE condivise da /api/v2/discovery/l2 (singolo) e
 * /api/v2/discovery/l2/batch (multi-switch): una fonte sola di verità
 * per le regole che non ammettono copie:
 *
 *   · cap ONESTI dichiarati (512 osservazioni, 256 ARP, 128 porte STP,
 *     32 VLAN): chi chiama conta ciò che è stato scritto DAVVERO e lo
 *     dichiara nel report — mai contatori ottimistici;
 *   · una riga malformata NON blocca la sonda (try per riga, l'esito
 *     si vede nei contatori);
 *   · REGOLA D'ORO (v16.8, invariata): i link dell'OPERATORE
 *     (confirmed o sourceOfTruth TECHNICIAN) restano INTOCCABILI —
 *     la ricostruzione aggiorna SOLO i link che ha creato lei stessa;
 *   · NESSUN dato inventato: MAC non validi scartati, porte senza
 *     nome dichiarate «port N», velocità 0 = sconosciuta.
 * ================================================================ */

import { db } from '@/lib/db'
import {
  normalizeMac,
  type L2ProbeArpRow,
  type L2ProbePayload,
  type L2ProbeStpPort,
  type ReconstructedObservation,
} from '@/lib/domain/l2-reconstruct'

/* ---------------- Cap onesti (dichiarati, mai silenziosi) ---------------- */

/** Osservazioni MAC persistite per sonda singola (v16.8, invariato). */
export const MAX_PERSISTED_OBSERVATIONS = 512
/** Righe ARP persistite per sonda (il dominio le taglia già a 256). */
export const MAX_PERSISTED_ARP_ROWS = 256
/** Porte STP persistite per sonda. */
export const MAX_PERSISTED_STP_PORTS = 128
/** VLAN persistite per sonda (il dominio le taglia già a 32). */
export const MAX_PERSISTED_VLANS = 32

/* ---------------- Risoluzione nomi porta ---------------- */

/** Risolutore del nome REALE di una porta bridge N: bridgePort →
 *  ifIndex → ifName/ifDescr, con fallback «port N» — la STESSA
 *  risoluzione di l2-reconstruct.portName() (fonte unica: il codice
 *  è gemello, NON importato, perché lì è closure interna della
 *  ricostruzione; qui serve alle StpObservation). */
export function portNameResolver(probe: L2ProbePayload): (port: number) => string {
  const portByIfIndex = new Map<number, { name: string | null; descr: string | null }>()
  for (const itf of probe.interfaces ?? []) {
    portByIfIndex.set(itf.ifIndex, { name: itf.name, descr: itf.descr })
  }
  const ifIndexByPort = new Map<number, number>()
  for (const bp of probe.bridgePorts ?? []) ifIndexByPort.set(bp.port, bp.ifIndex)
  const nameOf = (itf: { name: string | null; descr: string | null } | undefined): string =>
    itf?.name ?? itf?.descr ?? ''
  return (port: number): string => {
    const ifIndex = ifIndexByPort.get(port)
    const name = ifIndex !== undefined ? nameOf(portByIfIndex.get(ifIndex)) : ''
    if (name) return name
    // senza mappatura bridge→ifIndex: convenzione di molti switch piccoli
    // (ifIndex == porta bridge) — stessa fallback di l2-reconstruct
    const directName = nameOf(portByIfIndex.get(port))
    return directName || `port ${port}`
  }
}

/* ---------------- (1) FdbObservation ---------------- */

/** Upsert delle osservazioni MAC su {deviceId, portName, mac} con
 *  BUDGET residuo: la sonda singola passa 512, il batch passa il cap
 *  TOTALE meno ciò che ha già scritto sugli switch precedenti (una
 *  sola finestra onesta per tutta l'esecuzione). Ritorna le righe
 *  scritte DAVVERO. */
export async function persistFdbObservations(params: {
  plantId: string
  deviceId: string
  observations: ReconstructedObservation[]
  budget: number
}): Promise<number> {
  const cap = Math.max(0, Math.min(params.budget, MAX_PERSISTED_OBSERVATIONS))
  let saved = 0
  for (const obs of params.observations.slice(0, cap)) {
    const mac = normalizeMac(obs.mac)
    if (!mac) continue
    try {
      await db.fdbObservation.upsert({
        where: { deviceId_portName_mac: { deviceId: params.deviceId, portName: obs.portName, mac } },
        create: { plantId: params.plantId, deviceId: params.deviceId, portName: obs.portName, mac },
        update: { lastSeenAt: new Date() },
      })
      saved += 1
    } catch {
      /* una riga malformata non blocca la sonda: onesto a fine report */
    }
  }
  return saved
}

/* ---------------- (2) ArpEntry ---------------- */

/** Upsert delle voci ARP su {ip, deviceId}: la tabella ipNetToMedia
 *  dell'apparato sondato. Il vendor NON si tocca in update (se un
 *  arricchimento precedente l'ha valorizzato, resta — la sonda non
 *  sa dire il vendor). Ritorna le righe scritte DAVVERO. */
export async function persistArpEntries(params: {
  plantId: string
  deviceId: string
  arp: L2ProbeArpRow[]
}): Promise<number> {
  let saved = 0
  for (const row of params.arp.slice(0, MAX_PERSISTED_ARP_ROWS)) {
    const mac = normalizeMac(row.mac)
    if (!mac) continue
    const ifIndex = String(row.ifIndex)
    const entryType = row.type === 'static' ? 'static' : 'dynamic'
    try {
      await db.arpEntry.upsert({
        where: { ip_deviceId: { ip: row.ip, deviceId: params.deviceId } },
        create: {
          ip: row.ip,
          deviceId: params.deviceId,
          plantId: params.plantId,
          mac,
          vendor: '',
          ifIndex,
          entryType,
          lastSeen: new Date(),
        },
        update: {
          plantId: params.plantId,
          mac,
          ifIndex,
          entryType,
          lastSeen: new Date(),
        },
      })
      saved += 1
    } catch {
      /* riga malformata: il contatore dichiara la verità */
    }
  }
  return saved
}

/* ---------------- (3) StpObservation ---------------- */

/** Upsert delle dichiarazioni STP per porta bridge su {deviceId,
 *  portNum}: CHI è il bridge designato del segmento, lo stato della
 *  porta e la strada per la root. Alimenta il correlatore multi-switch
 *  (W14) e la vista diagnostica. Ritorna le righe scritte DAVVERO. */
export async function persistStpObservations(params: {
  plantId: string
  deviceId: string
  probe: L2ProbePayload
}): Promise<number> {
  const stp = params.probe.stp
  if (!stp?.present || !stp.ports) return 0
  const nameOf = portNameResolver(params.probe)
  const ports: L2ProbeStpPort[] = stp.ports.slice(0, MAX_PERSISTED_STP_PORTS)
  let saved = 0
  for (const p of ports) {
    try {
      const data = {
        portName: nameOf(p.port),
        portState: p.state,
        designatedBridgeId: p.designatedBridgeId,
        designatedBridgeMac: p.designatedBridgeMac,
        designatedPortNum: p.designatedPortNum,
        pathCost: p.pathCost,
        isRootPort: stp.rootPort === p.port,
        rootBridgeId: stp.rootBridgeId,
        stpProtocol: stp.protocol,
        lastSeenAt: new Date(),
      }
      await db.stpObservation.upsert({
        where: { deviceId_portNum: { deviceId: params.deviceId, portNum: p.port } },
        create: { plantId: params.plantId, deviceId: params.deviceId, portNum: p.port, ...data },
        update: data,
      })
      saved += 1
    } catch {
      /* una porta malformata non blocca la sonda */
    }
  }
  return saved
}

/* ---------------- (4) VlanInventory ---------------- */

/** Upsert delle VLAN dichiarate su {deviceId, vlanId}: nome e CSV
 *  delle porte egress (già risolte in nomi dal dominio). Ritorna le
 *  righe scritte DAVVERO. */
export async function persistVlanInventory(params: {
  plantId: string
  deviceId: string
  vlans: Array<{ vlanId: number; name: string; ports: string }>
}): Promise<number> {
  let saved = 0
  for (const v of params.vlans.slice(0, MAX_PERSISTED_VLANS)) {
    try {
      const data = { name: v.name, ports: v.ports, lastSeenAt: new Date() }
      await db.vlanInventory.upsert({
        where: { deviceId_vlanId: { deviceId: params.deviceId, vlanId: v.vlanId } },
        create: { plantId: params.plantId, deviceId: params.deviceId, vlanId: v.vlanId, ...data },
        update: data,
      })
      saved += 1
    } catch {
      /* una VLAN malformata non blocca la sonda */
    }
  }
  return saved
}

/* ---------------- (5) TopologyLink inferito ---------------- */

/** Esito della scrittura di UN link inferito: il chiamante somma i
 *  contatori onesti del report. 'error' NON si conta nei tre: è la
 *  riga che non si è potuta scrivere (già dichiarata com'è). */
export type InferredLinkOutcome = 'created' | 'updated' | 'skipped-operator' | 'error'

/** Campi del link inferito che la rotta vuole scrivere (endpoint
 *  LLDP/CDP/FDB o switch↔switch dal correlatore). */
export interface InferredLinkWrite {
  plantId: string
  sourceDeviceId: string
  targetDeviceId: string
  sourcePort: string
  targetPort: string
  sourceOfTruth: string
  confidence: string
  evidence: string
  /** Velocità negozziata (0 = sconosciuta: in update NON si tocca). */
  speedMbps: number
  /** Etichetta di provenienza (la rotta dichiara versione e dettaglio). */
  notes: string
}

/** Scrive UN link inferito con la regola d'oro v16.8 INVIOLATA:
 *   · link esistente confirmed o TECHNICIAN → SKIPPATO (operatore);
 *   · link inferito precedente della STESSA coppia → AGGIORNATO con
 *     la lettura più fresca (direzione normalizzata source→target
 *     come la vuole l'inferenza corrente);
 *   · nessun link → CREATO (confirmed: false, mai).
 * Una riga che non si persiste non invalida la sonda ('error'). */
export async function persistInferredLink(w: InferredLinkWrite): Promise<InferredLinkOutcome> {
  try {
    const existing = await db.topologyLink.findFirst({
      where: {
        plantId: w.plantId,
        OR: [
          { sourceDeviceId: w.sourceDeviceId, targetDeviceId: w.targetDeviceId },
          { sourceDeviceId: w.targetDeviceId, targetDeviceId: w.sourceDeviceId },
        ],
      },
      orderBy: [{ confirmed: 'desc' }, { updatedAt: 'desc' }],
    })
    if (existing) {
      // verità dell'operatore: intoccabile (regola d'oro)
      if (existing.confirmed || existing.sourceOfTruth === 'TECHNICIAN') return 'skipped-operator'
      // link inferito precedente: AGGIORNA con la lettura più fresca
      await db.topologyLink.update({
        where: { id: existing.id },
        data: {
          sourceDeviceId: w.sourceDeviceId,
          targetDeviceId: w.targetDeviceId,
          sourceOfTruth: w.sourceOfTruth,
          confidence: w.confidence,
          evidence: w.evidence,
          sourcePort: w.sourcePort,
          targetPort: w.targetPort,
          ...(w.speedMbps > 0 ? { speedMbps: w.speedMbps } : {}),
          linkType: existing.linkType || 'ETHERNET',
          linkStatus: 'ACTIVE',
          notes: w.notes.slice(0, 1000),
        },
      })
      return 'updated'
    }
    await db.topologyLink.create({
      data: {
        plantId: w.plantId,
        sourceDeviceId: w.sourceDeviceId,
        targetDeviceId: w.targetDeviceId,
        linkType: 'ETHERNET',
        linkStatus: 'ACTIVE',
        sourceOfTruth: w.sourceOfTruth,
        confidence: w.confidence,
        evidence: w.evidence,
        sourcePort: w.sourcePort,
        targetPort: w.targetPort,
        speedMbps: w.speedMbps,
        confirmed: false,
        notes: w.notes.slice(0, 1000),
      },
    })
    return 'created'
  } catch {
    /* un link che non si persiste non invalida la sonda: il report
     * resta onesto (il conteggio dice cosa è successo davvero) */
    return 'error'
  }
}

/** Somma un esito nei contatori del report (helper piccolo, chiamato
 *  in ciclo dalle rotte: tiene i tre contatori allineati). */
export function countLinkOutcome(
  outcome: InferredLinkOutcome,
  counters: { linksCreated: number; linksUpdated: number; linksSkippedOperator: number },
): void {
  if (outcome === 'created') counters.linksCreated += 1
  else if (outcome === 'updated') counters.linksUpdated += 1
  else if (outcome === 'skipped-operator') counters.linksSkippedOperator += 1
}
