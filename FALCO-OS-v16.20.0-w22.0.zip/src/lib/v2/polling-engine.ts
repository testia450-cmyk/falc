/* ================================================================
 * FALCO-OS v16.19 — Motore di monitoraggio continuo (W21-bis)
 * ================================================================
 * Il «puller» che l'operatore ha chiesto: dopo il setup, la telemetria
 * PARTE DA SOLA a ogni ciclo e gli allarmi vengono valutati sui dati
 * freschi — non solo una volta alla chiusura del wizard.
 *
 * COSA FA OGNI CICLO (per impianto, intervallo configurabile):
 *   1. PRESENZA: spazzata ping TCP-adattiva sui dispositivi ping-only
 *      (TLC) → campioni pingLatency/packetLoss + transizione di stato
 *      con ISTERESI 2 giù / 2 su (v15.11 R7, decisione 31: un
 *      micro-riavvio non genera allarme);
 *   2. SNMP LIVENESS: sonda SNMP leggera sugli apparati full →
 *      lastSeenAt/uptime + stessa isteresi;
 *   3. RADIO (ogni N cicli): sonda telemetria radio su AP/STA →
 *      SSID/segnale/CCQ/CPU/RAM persistiti su Device + MetricValue;
 *   4. ALLARMI: valutazione delle regole del plant sui dati appena
 *      raccolti → eventi APERTI/CHIUSI con dedup (stesso tag =
 *      conta, non duplica); le regole valutate dal motore sono quelle
 *      con dati freschi a ogni tick: LOW_SIGNAL, DEVICE_DOWN,
 *      NEW_HOST, TOPOLOGY_CHANGE (PORT_STATE_CHANGE serve un sondaggio
 *      L2: resta del wizard on-demand — dichiarato);
 *   5. NOTIFICHE: ogni NUOVO evento aperto → Telegram se
 *      l'integrazione telegram.botToken è configurata e l'impianto ha
 *      un chat id; l'esito (SENT/FAILED/SKIPPED) è SCRITTO in
 *      NotificationLog — mai silenzioso;
 *   6. POLLING SCHEDULE: le righe per dispositivo vengono mantenute
 *      vive (lastPolledAt/lastStatus) — il modello v15 finalmente
 *      usato, così il NOC sa CHI è monitorato e quando.
 *
 * ONESTÀ (i limiti veri, dichiarati e visibili):
 *   · v16.20 W22 — AUTO-RESUME ENTERPRISE: la configurazione del motore
 *     (enabled/intervalSec/radioEvery) è PERSISTITA nella tabella
 *     EngineRuntime e src/instrumentation.ts la RIATTIVA da sola a ogni
 *     avvio del processo server: il downtime del server NON spegne più
 *     il monitoraggio. L'arresto VOLONTARIO (enabled=false) è rispettato;
 *   · la valutazione PORT_STATE_CHANGE e NEW_DEVICE_SEEN richiede
 *     sonde L2/scansioni: restano on-demand dal wizard;
 *   · ogni errore di ciclo finisce nei contatori (errors) e nella riga
 *     EngineRuntime (lastError), MAI nascosto.
 * ================================================================ */

import { db } from '@/lib/db'
import { decryptSecret } from '@/lib/crypto'
import { discoveryPost } from '@/lib/v2/discovery-proxy'

/* ---------------- Config ---------------- */

const MIN_INTERVAL_SEC = 5
const MAX_INTERVAL_SEC = 3600
const DEFAULT_INTERVAL_SEC = 30
const DEFAULT_RADIO_EVERY = 3
const MAX_PING_TARGETS = 64
const SNMP_TIMEOUT_MS = 2000
const RADIO_TIMEOUT_MS = 30_000
const PING_TIMEOUT_MS = 25_000
const TELEGRAM_TIMEOUT_MS = 6000
/** Isteresi v15.11 R7 (decisione 31): transizione solo a streak maturo. */
const STREAK_TO_TRANSITION = 2

/* ---------------- Stato per impianto ---------------- */

interface EngineCounters {
  cycles: number
  metricsWritten: number
  eventsOpened: number
  eventsClosed: number
  notificationsSent: number
  notificationsFailed: number
  notificationsSkipped: number
  radioProbes: number
  pingSweeps: number
  snmpProbes: number
  errors: string[]
}

interface PlantEngine {
  plantId: string
  plantName: string
  intervalSec: number
  radioEvery: number
  startedVia: 'WIZARD' | 'AUTO_RESUME' | 'API'
  startedAt: number
  timer: ReturnType<typeof setInterval> | null
  running: boolean
  /** in-flight: il ciclo corrente è ancora in corsa (guardia anti-sovrapposizione). */
  busy: boolean
  lastCycleAt: number | null
  lastCycleDurationMs: number | null
  counters: EngineCounters
}

interface EnginesGlobal {
  engines: Map<string, PlantEngine>
  cleanupRegistered: boolean
  /** v16.20 W22: l'auto-resume di instrumentation.ts parte UNA volta per processo. */
  resumeAttempted: boolean
}

const g = globalThis as unknown as { __falcoMonitoringEngines?: EnginesGlobal }
const enginesGlobal: EnginesGlobal = g.__falcoMonitoringEngines ?? { engines: new Map(), cleanupRegistered: false, resumeAttempted: false }
g.__falcoMonitoringEngines = enginesGlobal

function pushError(e: PlantEngine, msg: string) {
  e.counters.errors.push(`[${new Date().toISOString()}] ${msg}`)
  if (e.counters.errors.length > 20) e.counters.errors.splice(0, e.counters.errors.length - 20)
}

const clamp = (v: number, min: number, max: number, fallback: number) => {
  const n = Number(v)
  if (!Number.isFinite(n)) return fallback
  return Math.min(max, Math.max(min, Math.round(n)))
}

/* ---------------- Persistenza di un esito presenza ---------------- */

interface DeviceLite {
  id: string
  hostname: string
  ip: string
  type: string
  monitorMode: string
  status: string
  falcoState: string
  downStreak: number
  upStreak: number
  port: number
  snmpPort: number
  snmpCommunityEnc: string
  snmpVersion: string
  signalStrength: number
  locationId: string | null
  lastSeenAt: Date | null
}

/** Transizione di stato con isteresi 2/2 (mai valutato → prima valutazione vince). */
function transitionState(d: DeviceLite, alive: boolean): { status: string; falcoState: string; changes: Record<string, unknown> } {
  const up = alive ? d.upStreak + 1 : 0
  const down = alive ? 0 : d.downStreak + 1
  const neverAssessed = d.falcoState === '' || d.falcoState == null
  let status = d.status
  let falcoState = d.falcoState
  const changes: Record<string, unknown> = { upStreak: up, downStreak: down }

  if (alive && (neverAssessed || (d.status !== 'ONLINE' && up >= STREAK_TO_TRANSITION))) {
    status = 'ONLINE'
    falcoState = 'online'
    changes.status = status
    changes.falcoState = falcoState
    if (d.status === 'OFFLINE') changes.disconnectedSince = null
  } else if (!alive && (neverAssessed || (d.status !== 'OFFLINE' && down >= STREAK_TO_TRANSITION))) {
    status = 'OFFLINE'
    falcoState = 'disconnesso'
    changes.status = status
    changes.falcoState = falcoState
    if (d.status !== 'OFFLINE') changes.disconnectedSince = new Date()
  }
  return { status, falcoState, changes }
}

/* ---------------- Notifiche Telegram ---------------- */

interface NotifyOutcome {
  channel: 'TELEGRAM'
  target: string
  status: 'SENT' | 'FAILED' | 'SKIPPED'
  error: string
}

async function notifyTelegram(plantId: string, botToken: string | null, chatId: string | null, text: string): Promise<NotifyOutcome> {
  if (!botToken) return { channel: 'TELEGRAM', target: chatId ?? '—', status: 'SKIPPED', error: 'integrazione telegram.botToken non configurata' }
  if (!chatId) return { channel: 'TELEGRAM', target: '—', status: 'SKIPPED', error: 'nessun chat id per l\'impianto (Plant.telegramChatId)' }
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), TELEGRAM_TIMEOUT_MS)
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text }),
      signal: ac.signal,
      cache: 'no-store',
    })
    const ok = res.ok
    const detail = ok ? '' : `HTTP ${res.status} da api.telegram.org`
    return { channel: 'TELEGRAM', target: chatId, status: ok ? 'SENT' : 'FAILED', error: detail }
  } catch (e) {
    const aborted = e instanceof Error && e.name === 'AbortError'
    return { channel: 'TELEGRAM', target: chatId, status: 'FAILED', error: aborted ? 'timeout' : (e instanceof Error ? e.message.slice(0, 200) : 'errore') }
  } finally {
    clearTimeout(t)
  }
}

/* ---------------- Eventi allarme (con dedup + chiusura) ---------------- */

async function raiseOrCountEvent(input: {
  ruleId: string
  plantId: string
  deviceId: string | null
  severity: string
  currentValue: string
  message: string
  dedupTag: string
}): Promise<'opened' | 'deduplicated' | 'failed'> {
  try {
    const existing = await db.alertEvent.findFirst({
      where: { ruleId: input.ruleId, status: 'OPEN', dedupTag: input.dedupTag },
      select: { id: true },
    })
    if (existing) {
      await db.alertEvent.update({
        where: { id: existing.id },
        data: { occurrenceCount: { increment: 1 }, currentValue: input.currentValue, message: input.message, updatedAt: new Date() },
      })
      return 'deduplicated'
    }
    await db.alertEvent.create({
      data: {
        ruleId: input.ruleId,
        plantId: input.plantId,
        deviceId: input.deviceId,
        severity: input.severity,
        status: 'OPEN',
        currentValue: input.currentValue,
        message: input.message,
        dedupTag: input.dedupTag,
      },
    })
    return 'opened'
  } catch {
    return 'failed'
  }
}

async function closeEventsIfAny(ruleId: string, dedupTag: string, closedNote: string): Promise<number> {
  try {
    const open = await db.alertEvent.findMany({ where: { ruleId, status: 'OPEN', dedupTag }, select: { id: true } })
    if (open.length === 0) return 0
    await db.alertEvent.updateMany({
      where: { id: { in: open.map((x) => x.id) } },
      data: { status: 'CLOSED', closedAt: new Date(), updatedAt: new Date() },
    })
    void closedNote
    return open.length
  } catch {
    return 0
  }
}

/* ---------------- Un ciclo di monitoraggio ---------------- */

async function runCycle(e: PlantEngine) {
  const t0 = Date.now()
  e.busy = true
  try {
    /* --- contesto impianto (riga completa: chat id + community CSV) --- */
    const plant = await db.plant.findUnique({
      where: { id: e.plantId },
      select: { name: true, telegramChatId: true, snmpCommunities: true },
    })
    if (!plant) {
      pushError(e, 'impianto non più esistente: il motore si ferma')
      void stopMonitoringEngine(e.plantId, 'impianto rimosso')
      return
    }
    const plantCommunities = (plant.snmpCommunities ?? '').split(',').map((s) => s.trim()).filter(Boolean)

    /* --- dispositivi attivi --- */
    const devices = (await db.device.findMany({
      where: { plantId: e.plantId, decommissionedAt: null },
      select: {
        id: true, hostname: true, ip: true, type: true, monitorMode: true,
        status: true, falcoState: true, downStreak: true, upStreak: true,
        port: true, snmpPort: true, snmpCommunityEnc: true, snmpVersion: true,
        signalStrength: true, locationId: true, lastSeenAt: true,
      },
      orderBy: { hostname: 'asc' },
    })) as unknown as DeviceLite[]

    if (devices.length === 0) {
      e.lastCycleAt = Date.now()
      e.lastCycleDurationMs = Date.now() - t0
      return
    }

    const isRadioCycle = e.counters.cycles % Math.max(1, e.radioEvery) === 0

    /* ============ (1) presenza: dispositivi ping-only ============ */
    const pingTargets = devices.filter((d) => d.monitorMode === 'ping').slice(0, MAX_PING_TARGETS)
    e.counters.pingSweeps++
    const pingByIp = new Map<string, { alive: boolean; latencyMs: number }>()
    if (pingTargets.length > 0) {
      const pr = await discoveryPost('/probe/ping', {
        targets: pingTargets.map((d) => ({ ip: d.ip, port: d.port || 80 })),
        timeoutMs: 1500,
      }, { timeoutMs: PING_TIMEOUT_MS })
      if (pr.ok) {
        const res = (pr.body as { result?: { results?: Array<{ ip: string; alive: boolean; latencyMs: number }> } }).result
        for (const r of res?.results ?? []) pingByIp.set(r.ip, { alive: r.alive, latencyMs: r.latencyMs })
      } else {
        pushError(e, `spazzata ping non riuscita (${(pr.body as { error?: { code?: string } })?.error?.code ?? 'errore'})`)
      }
    }

    const now = new Date()
    const offlineNow: string[] = []
    for (const d of pingTargets) {
      const hit = pingByIp.get(d.ip)
      if (!hit) continue // difensivo: assente = non valutato questo giro
      const tr = transitionState(d, hit.alive)
      const metrics: Array<{ deviceId: string; plantId: string; metric: string; value: number; unit: string; timestamp: Date }> = []
      if (hit.alive) {
        metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'pingLatency', value: hit.latencyMs, unit: 'ms', timestamp: now })
        metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'packetLoss', value: 0, unit: '%', timestamp: now })
      } else {
        metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'packetLoss', value: 100, unit: '%', timestamp: now })
      }
      try {
        await db.device.update({
          where: { id: d.id },
          data: { ...tr.changes, ...(hit.alive ? { lastSeenAt: now } : {}) },
        })
        if (metrics.length > 0) {
          await db.metricValue.createMany({ data: metrics })
          e.counters.metricsWritten += metrics.length
        }
      } catch (err) {
        pushError(e, `${d.hostname}: persistenza presenza non riuscita (${err instanceof Error ? err.message.slice(0, 80) : 'errore'})`)
      }
      if (tr.status === 'OFFLINE') offlineNow.push(d.id)
    }

    /* ============ (2) SNMP liveness sugli apparati full ============ */
    /* Paralleli a blocchi (4): i muti col timeout pieno non allungano
     * più il ciclo in sequenza — un impianto da 40 apparati resta nei
     * tempi del blocco, non della somma. */
    const fullTargets = devices.filter((d) => d.monitorMode !== 'ping')
    const probeChunk = async <T, R>(items: T[], size: number, fn: (item: T) => Promise<R>): Promise<R[]> => {
      const out: R[] = []
      for (let i = 0; i < items.length; i += size) {
        const chunk = items.slice(i, i + size)
        out.push(...(await Promise.all(chunk.map(fn))))
      }
      return out
    }
    const snmpResults = await probeChunk(fullTargets, 4, async (d) => {
      const communities: string[] = []
      const enc = decryptSecret(d.snmpCommunityEnc)
      if (enc) communities.push(enc)
      for (const c of plantCommunities) if (!communities.includes(c)) communities.push(c)
      if (!communities.includes('public')) communities.push('public')
      const version = d.snmpVersion === 'v1' || d.snmpVersion === 'v3' ? d.snmpVersion : 'v2c'
      const port = d.snmpPort || 161

      let alive = false
      let uptimeTicks: number | null = null
      const pr = await discoveryPost('/probe/snmp', {
        ip: d.ip, port, version, communities, timeoutMs: SNMP_TIMEOUT_MS,
      }, { timeoutMs: 10_000 })
      if (pr.ok) {
        const r = (pr.body as { result?: { reachable?: boolean; uptimeTicks?: number | null } }).result
        alive = r?.reachable === true
        uptimeTicks = r?.uptimeTicks ?? null
      }
      return { d, alive, uptimeTicks }
    })
    e.counters.snmpProbes += snmpResults.length
    for (const { d, alive, uptimeTicks } of snmpResults) {
      const tr = transitionState(d, alive)
      try {
        await db.device.update({
          where: { id: d.id },
          data: {
            ...tr.changes,
            ...(alive ? { lastSeenAt: now, ...(uptimeTicks != null && uptimeTicks > 0 ? { uptimeSeconds: Math.round(uptimeTicks / 100) } : {}) } : {}),
          },
        })
      } catch (err) {
        pushError(e, `${d.hostname}: persistenza SNMP non riuscita (${err instanceof Error ? err.message.slice(0, 80) : 'errore'})`)
      }
      if (tr.status === 'OFFLINE') offlineNow.push(d.id)
    }

    /* ============ (3) telemetria radio (ogni N cicli) ============ */
    if (isRadioCycle) {
      const radioTargets = fullTargets.filter((d) => ['AP', 'STA', 'GATEWAY'].includes(d.type))
      const radioResults = await probeChunk(radioTargets, 2, async (d) => {
        const communities: string[] = []
        const enc = decryptSecret(d.snmpCommunityEnc)
        if (enc) communities.push(enc)
        for (const c of plantCommunities) if (!communities.includes(c)) communities.push(c)
        if (!communities.includes('public')) communities.push('public')
        const pr = await discoveryPost('/probe/radio', {
          ip: d.ip, port: d.snmpPort || 161,
          version: d.snmpVersion === 'v1' || d.snmpVersion === 'v3' ? d.snmpVersion : 'v2c',
          communities, timeoutMs: SNMP_TIMEOUT_MS, walkTimeoutMs: 1500,
        }, { timeoutMs: RADIO_TIMEOUT_MS })
        return { d, probe: pr.ok ? ((pr.body as { result?: Record<string, unknown> }).result ?? null) : null }
      })
      e.counters.radioProbes += radioResults.length
      for (const { d, probe } of radioResults) {
        if (!probe || probe.reachable !== true) continue

        const radios = (probe.radios ?? []) as Array<{ ssid?: string | null; signalDbm?: number | null; ccqPercent?: number | null; frequencyMhz?: number | null; txRateMbps?: number | null }>
        const clients = (probe.clients ?? []) as unknown[]
        const health = (probe.health ?? {}) as { cpuLoadPct?: number | null; ramUsedKb?: number | null; ramTotalKb?: number | null }
        const main = radios.find((r) => r.ssid || r.signalDbm != null) ?? radios[0] ?? null

        const update: Record<string, unknown> = { lastSeenAt: new Date() }
        const metrics: Array<{ deviceId: string; plantId: string; metric: string; value: number; unit: string; timestamp: Date }> = []
        if (health.cpuLoadPct != null) { update.cpuLoad = health.cpuLoadPct; metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'cpuLoad', value: health.cpuLoadPct, unit: '%', timestamp: now }) }
        if (health.ramUsedKb != null && health.ramTotalKb != null && health.ramTotalKb > 0) {
          update.ramUsed = health.ramUsedKb
          update.ramTotal = health.ramTotalKb
          metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'memoryUsage', value: Math.round((health.ramUsedKb / health.ramTotalKb) * 100), unit: '%', timestamp: now })
        }
        if (main?.ssid) update.ssid = main.ssid
        if (main?.signalDbm != null) { update.signalStrength = main.signalDbm; metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'signalStrength', value: main.signalDbm, unit: 'dBm', timestamp: now }) }
        if (main?.ccqPercent != null) { update.linkQuality = main.ccqPercent; metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'linkQuality', value: main.ccqPercent, unit: '%', timestamp: now }) }
        if (main?.frequencyMhz != null) update.currentFrequency = String(main.frequencyMhz)
        if (clients.length > 0) {
          update.radioMode = 'ap'
          update.linkMode = clients.length === 1 ? 'PTP' : 'PTMP'
          metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'radioClients', value: clients.length, unit: 'n', timestamp: now })
        } else if (main?.signalDbm != null) {
          update.radioMode = 'sta'
        }
        if (main?.txRateMbps != null) metrics.push({ deviceId: d.id, plantId: e.plantId, metric: 'radioTxRate', value: main.txRateMbps, unit: 'Mbps', timestamp: now })

        try {
          await db.device.update({ where: { id: d.id }, data: update })
          if (metrics.length > 0) {
            await db.metricValue.createMany({ data: metrics })
            e.counters.metricsWritten += metrics.length
          }
        } catch (err) {
          pushError(e, `${d.hostname}: persistenza radio non riuscita (${err instanceof Error ? err.message.slice(0, 80) : 'errore'})`)
        }
      }
    }

    /* ============ (4) valutazione allarmi sui dati freschi ============ */
    const rules = await db.alertRule.findMany({
      where: { plantId: e.plantId, enabled: true },
      select: { id: true, systemKey: true, metric: true, threshold: true, deviceTypes: true, severity: true },
    })
    const devicesFresh = (await db.device.findMany({
      where: { plantId: e.plantId, decommissionedAt: null },
      select: { id: true, hostname: true, type: true, status: true, signalStrength: true, locationId: true, lastSeenAt: true },
      orderBy: { hostname: 'asc' },
    })) as Array<{ id: string; hostname: string; type: string; status: string; signalStrength: number; locationId: string | null; lastSeenAt: Date | null }>

    /* contesto notifiche (letto UNA volta per ciclo) */
    let botToken: string | null = null
    try {
      const cfg = await db.integrationConfig.findUnique({ where: { key: 'telegram.botToken' }, select: { value: true, enabled: true } })
      if (cfg?.enabled) botToken = decryptSecret(cfg.value) ?? null
    } catch { /* integrazioni non leggibili: notifiche SKIPPED */ }
    let chatId: string | null = (plant.telegramChatId ?? '').trim() || null

    const notify = async (text: string) => {
      const outcome = await notifyTelegram(e.plantId, botToken, chatId, text)
      try {
        await db.notificationLog.create({
          data: {
            plantId: e.plantId,
            channel: outcome.channel,
            target: outcome.target,
            subject: 'Allarme FALCO-OS',
            body: text.slice(0, 2000),
            status: outcome.status,
            error: outcome.error.slice(0, 500),
          },
        })
      } catch { /* il log è best-effort: l'evento conta di più */ }
      if (outcome.status === 'SENT') e.counters.notificationsSent++
      else if (outcome.status === 'FAILED') e.counters.notificationsFailed++
      else e.counters.notificationsSkipped++
    }

    /* (a) SYS:LOW_SIGNAL — solo antenne con un segnale DAVVERO letto */
    const lowSignalRule = rules.find((r) => r.systemKey === 'SYS:LOW_SIGNAL')
    if (lowSignalRule) {
      let types: string[] = []
      try { types = JSON.parse(lowSignalRule.deviceTypes || '[]') } catch { types = [] }
      const offenders = devicesFresh.filter((d) => (types.length === 0 || types.includes(d.type)) && d.signalStrength !== 0 && d.signalStrength <= (lowSignalRule.threshold ?? -75))
      const offendersIds = new Set(offenders.map((o) => o.id))
      for (const d of offenders) {
        const outcome = await raiseOrCountEvent({
          ruleId: lowSignalRule.id, plantId: e.plantId, deviceId: d.id, severity: lowSignalRule.severity,
          currentValue: `${d.signalStrength} dBm`,
          message: `Segnale scarso: ${d.hostname} dichiara ${d.signalStrength} dBm (soglia ${lowSignalRule.threshold} dBm) — verificare allineamento/LOS`,
          dedupTag: `sys:SYS:LOW_SIGNAL:${d.id}`,
        })
        if (outcome === 'opened') {
          e.counters.eventsOpened++
          await notify(`⚠️ ${lowSignalRule.severity} · ${plant.name}\nSegnale scarso: ${d.hostname} (${d.signalStrength} dBm, soglia ${lowSignalRule.threshold})`)
        }
      }
      /* chiusura per chi è tornato sopra soglia (o senza segnale letto) */
      for (const d of devicesFresh.filter((x) => !offendersIds.has(x.id) && (x.type === 'AP' || x.type === 'STA'))) {
        e.counters.eventsClosed += await closeEventsIfAny(lowSignalRule.id, `sys:SYS:LOW_SIGNAL:${d.id}`, `${d.hostname} tornato sopra soglia`)
      }
    }

    /* (b) SYS:DEVICE_DOWN — stato OFFLINE reale (dopo isteresi) */
    const downRule = rules.find((r) => r.systemKey === 'SYS:DEVICE_DOWN')
    if (downRule) {
      const offlineDevices = devicesFresh.filter((d) => d.status === 'OFFLINE')
      const offlineIds = new Set(offlineDevices.map((o) => o.id))
      for (const d of offlineDevices) {
        const outcome = await raiseOrCountEvent({
          ruleId: downRule.id, plantId: e.plantId, deviceId: d.id, severity: downRule.severity,
          currentValue: 'OFFLINE',
          message: `${d.hostname} (${d.type}) risulta OFFLINE — nessuna risposta al tick di monitoraggio (isteresi 2 cicli superata)`,
          dedupTag: `sys:SYS:DEVICE_DOWN:${d.id}`,
        })
        if (outcome === 'opened') {
          e.counters.eventsOpened++
          await notify(`🚨 ${downRule.severity} · ${plant.name}\n${d.hostname} è OFFLINE (nessuna risposta al monitoraggio).`)
        }
      }
      for (const d of devicesFresh.filter((x) => !offlineIds.has(x.id))) {
        e.counters.eventsClosed += await closeEventsIfAny(downRule.id, `sys:SYS:DEVICE_DOWN:${d.id}`, `${d.hostname} di nuovo raggiungibile`)
      }
    }

    /* (c) SYS:NEW_HOST — orfani visti di recente */
    const newHostRule = rules.find((r) => r.systemKey === 'SYS:NEW_HOST')
    if (newHostRule) {
      const orphans = devicesFresh.filter((d) => d.locationId == null && d.lastSeenAt != null && Date.now() - d.lastSeenAt.getTime() < 24 * 3600 * 1000)
      if (orphans.length > (newHostRule.threshold ?? 0)) {
        const outcome = await raiseOrCountEvent({
          ruleId: newHostRule.id, plantId: e.plantId, deviceId: null, severity: newHostRule.severity,
          currentValue: `${orphans.length} orfani`,
          message: `${orphans.length} apparati visti e NON adottati (${orphans.map((o) => o.hostname).slice(0, 5).join(', ')}${orphans.length > 5 ? '…' : ''}) — assegnare la sede dalla coda adozione`,
          dedupTag: 'sys:SYS:NEW_HOST:plant',
        })
        if (outcome === 'opened') {
          e.counters.eventsOpened++
          await notify(`ℹ️ ${plant.name}\n${orphans.length} apparati rilevati e non adottati.`)
        }
      } else {
        e.counters.eventsClosed += await closeEventsIfAny(newHostRule.id, 'sys:SYS:NEW_HOST:plant', 'orfani risolti')
      }
    }

    /* (d) SYS:TOPOLOGY_CHANGE — numero di link diverso dalla baseline */
    const topoRule = rules.find((r) => r.systemKey === 'SYS:TOPOLOGY_CHANGE')
    if (topoRule) {
      const linkCount = await db.topologyLink.count({ where: { plantId: e.plantId } })
      if (linkCount !== (topoRule.threshold ?? linkCount)) {
        const outcome = await raiseOrCountEvent({
          ruleId: topoRule.id, plantId: e.plantId, deviceId: null, severity: topoRule.severity,
          currentValue: `${linkCount} link`,
          message: `La rete ha cambiato alberatura: ${linkCount} link contro baseline ${topoRule.threshold} — verificare la vista Rete`,
          dedupTag: 'sys:SYS:TOPOLOGY_CHANGE:plant',
        })
        if (outcome === 'opened') {
          e.counters.eventsOpened++
          await notify(`🔀 ${plant.name}\nTopologia cambiata: ${linkCount} link (baseline ${topoRule.threshold}).`)
        }
      } else {
        e.counters.eventsClosed += await closeEventsIfAny(topoRule.id, 'sys:SYS:TOPOLOGY_CHANGE:plant', 'topologia tornata alla baseline')
      }
    }

    /* ============ (5) PollingSchedule tenute vive ============ */
    try {
      const groups: Array<{ deviceId: string | null; group: string; tier: string; interval: number }> = []
      groups.push({ deviceId: null, group: 'PRESENCE', tier: 'T2', interval: e.intervalSec })
      groups.push({ deviceId: null, group: 'SNMP_LIVENESS', tier: 'T1', interval: e.intervalSec })
      if (e.radioEvery > 0) groups.push({ deviceId: null, group: 'RADIO', tier: 'T1', interval: e.intervalSec * e.radioEvery })
      for (const g of groups) {
        const existing = await db.pollingSchedule.findFirst({
          where: { plantId: e.plantId, deviceId: null, metricGroup: g.group },
          select: { id: true },
        })
        if (existing) {
          await db.pollingSchedule.update({
            where: { id: existing.id },
            data: { enabled: true, intervalSec: g.interval, tier: g.tier, lastPolledAt: now, lastStatus: 'OK', name: `engine:${g.group.toLowerCase()}` },
          })
        } else {
          await db.pollingSchedule.create({
            data: {
              plantId: e.plantId, deviceId: null, name: `engine:${g.group.toLowerCase()}`,
              metricGroup: g.group, intervalSec: g.interval, enabled: true, tier: g.tier,
              lastPolledAt: now, lastStatus: 'OK',
            },
          })
        }
      }
    } catch (err) {
      pushError(e, `PollingSchedule non aggiornate (${err instanceof Error ? err.message.slice(0, 80) : 'errore'})`)
    }
  } catch (err) {
    pushError(e, `ciclo interrotto: ${err instanceof Error ? err.message.slice(0, 120) : String(err)}`)
  } finally {
    e.counters.cycles++
    e.lastCycleAt = Date.now()
    e.lastCycleDurationMs = Date.now() - t0
    e.busy = false
    /* v16.20 W22 — HEARTBEAT PERSISTITO: la riga EngineRuntime dice al NOC
     * «il motore è vivo» anche leggendo il DB (non solo la memoria). Il
     * totalCycles storico cresce su tutte le sessioni — mai perso. */
    try {
      await db.engineRuntime.update({
        where: { plantId: e.plantId },
        data: {
          lastHeartbeatAt: new Date(),
          cycles: e.counters.cycles,
          metricsWritten: e.counters.metricsWritten,
          eventsOpened: e.counters.eventsOpened,
          eventsClosed: e.counters.eventsClosed,
          lastCycleMs: e.lastCycleDurationMs ?? null,
          lastError: e.counters.errors.length > 0 ? e.counters.errors[e.counters.errors.length - 1].slice(0, 300) : '',
          totalCycles: { increment: 1 },
        },
      })
    } catch {
      /* heartbeat best-effort: il ciclo NON fallisce se il DB rallenta */
    }
  }
}

/* ---------------- API del motore ---------------- */

export interface EngineStatusRow {
  plantId: string
  plantName: string
  running: boolean
  busy: boolean
  intervalSec: number
  radioEvery: number
  startedVia: 'WIZARD' | 'AUTO_RESUME' | 'API'
  startedAt: number
  cycles: number
  lastCycleAt: number | null
  lastCycleDurationMs: number | null
  metricsWritten: number
  eventsOpened: number
  eventsClosed: number
  notificationsSent: number
  notificationsFailed: number
  notificationsSkipped: number
  pingSweeps: number
  snmpProbes: number
  radioProbes: number
  errors: string[]
}

function toRow(e: PlantEngine): EngineStatusRow {
  return {
    plantId: e.plantId,
    plantName: e.plantName,
    running: e.running,
    busy: e.busy,
    intervalSec: e.intervalSec,
    radioEvery: e.radioEvery,
    startedVia: e.startedVia,
    startedAt: e.startedAt,
    cycles: e.counters.cycles,
    lastCycleAt: e.lastCycleAt,
    lastCycleDurationMs: e.lastCycleDurationMs,
    metricsWritten: e.counters.metricsWritten,
    eventsOpened: e.counters.eventsOpened,
    eventsClosed: e.counters.eventsClosed,
    notificationsSent: e.counters.notificationsSent,
    notificationsFailed: e.counters.notificationsFailed,
    notificationsSkipped: e.counters.notificationsSkipped,
    pingSweeps: e.counters.pingSweeps,
    snmpProbes: e.counters.snmpProbes,
    radioProbes: e.counters.radioProbes,
    errors: e.counters.errors.slice(-5),
  }
}

export function monitoringEngineStatus(): EngineStatusRow[] {
  return [...enginesGlobal.engines.values()].map(toRow)
}

export function monitoringEngineStatusFor(plantId: string): EngineStatusRow | null {
  const e = enginesGlobal.engines.get(plantId)
  return e ? toRow(e) : null
}

export async function startMonitoringEngine(input: { plantId: string; intervalSec?: number; radioEvery?: number; via?: 'WIZARD' | 'AUTO_RESUME' | 'API' }): Promise<EngineStatusRow | { error: string }> {
  const plant = await db.plant.findUnique({
    where: { id: input.plantId },
    select: { name: true, pingIntervalSec: true },
  })
  if (!plant) return { error: 'impianto non trovato' }

  /* stop preventivo di un'istanza precedente (riavvio pulito) */
  const previous = enginesGlobal.engines.get(input.plantId)
  if (previous?.timer) clearInterval(previous.timer)

  const intervalSec = clamp(input.intervalSec ?? plant.pingIntervalSec ?? DEFAULT_INTERVAL_SEC, MIN_INTERVAL_SEC, MAX_INTERVAL_SEC, DEFAULT_INTERVAL_SEC)
  const radioEvery = clamp(input.radioEvery ?? DEFAULT_RADIO_EVERY, 1, 60, DEFAULT_RADIO_EVERY)
  const via = input.via ?? 'API'

  const e: PlantEngine = {
    plantId: input.plantId,
    plantName: plant.name,
    intervalSec,
    radioEvery,
    startedVia: via,
    startedAt: Date.now(),
    timer: null,
    running: true,
    busy: false,
    lastCycleAt: null,
    lastCycleDurationMs: null,
    counters: {
      cycles: 0, metricsWritten: 0, eventsOpened: 0, eventsClosed: 0,
      notificationsSent: 0, notificationsFailed: 0, notificationsSkipped: 0,
      radioProbes: 0, pingSweeps: 0, snmpProbes: 0, errors: [],
    },
  }
  enginesGlobal.engines.set(input.plantId, e)

  /* v16.20 W22 — PERSISTENZA (auto-resume enterprise): la configurazione
   * vive nel DB; al riavvio del processo instrumentation.ts RIATTIVA da
   * sola i motori con enabled=true. L'arresto volontario NON tocca la
   * riga (la fa stopMonitoringEngine) — qui siamo un (ri)avvio. */
  try {
    await db.engineRuntime.upsert({
      where: { plantId: input.plantId },
      create: {
        plantId: input.plantId,
        enabled: true,
        intervalSec,
        radioEveryNCycles: radioEvery,
        startedVia: via,
        lastStartedAt: new Date(),
        cycles: 0,
        metricsWritten: 0,
        eventsOpened: 0,
        eventsClosed: 0,
        lastError: '',
      },
      update: {
        enabled: true,
        intervalSec,
        radioEveryNCycles: radioEvery,
        startedVia: via,
        lastStartedAt: new Date(),
        cycles: 0,
        metricsWritten: 0,
        eventsOpened: 0,
        eventsClosed: 0,
        lastError: '',
      },
    })
  } catch {
    /* persistenza best-effort: il motore parte anche se il DB rallenta */
  }

  /* primo ciclo subito (i dati arrivano subito, non dopo un intervallo) */
  void runCycle(e)
  e.timer = setInterval(() => {
    if (e.busy) {
      pushError(e, `ciclo saltato: il precedente era ancora in corsa (${e.lastCycleDurationMs ?? '?'} ms)`)
      return
    }
    void runCycle(e)
  }, intervalSec * 1000)

  return toRow(e)
}

export async function stopMonitoringEngine(plantId: string, reason = 'arresto richiesto'): Promise<EngineStatusRow | null> {
  const e = enginesGlobal.engines.get(plantId)
  if (!e) return null
  if (e.timer) clearInterval(e.timer)
  e.timer = null
  e.running = false
  enginesGlobal.engines.delete(plantId)
  /* v16.20 W22 — arresto VOLONTARIO: enabled=false, così l'auto-resume
   * del prossimo avvio LO RISPETTA (non resuscita ciò che un umano ha
   * fermato — onestà enterprise, mai sorprese). */
  try {
    await db.engineRuntime.update({
      where: { plantId },
      data: { enabled: false, lastStoppedAt: new Date(), stopReason: reason.slice(0, 200) },
    })
  } catch {
    /* best-effort */
  }
  return toRow(e)
}

/* ================================================================
 * v16.20.0 W22 — AUTO-RESUME ENTERPRISE
 * ================================================================
 * Chiamato da src/instrumentation.ts a ogni AVVIO del processo server:
 * riattiva da sola ogni motore con EngineRuntime.enabled=true usando la
 * CONFIGURAZIONE PERSISTITA (intervalSec/radioEvery). L'arresto
 * volontario (enabled=false) è rispettato. Ogni ripresa è AUDIT-ata
 * (attore 'system:auto-resume') — mai silenziosa. */
export async function resumeMonitoringEngines(): Promise<{ resumed: number; skipped: number; plants: string[] }> {
  if (enginesGlobal.resumeAttempted) return { resumed: 0, skipped: 0, plants: [] }
  enginesGlobal.resumeAttempted = true

  let rows: Array<{ plantId: string; intervalSec: number; radioEveryNCycles: number; plant: { name: string } }> = []
  try {
    rows = await db.engineRuntime.findMany({
      where: { enabled: true },
      select: { plantId: true, intervalSec: true, radioEveryNCycles: true, plant: { select: { name: true } } },
    })
  } catch {
    return { resumed: 0, skipped: 0, plants: [] }
  }

  const plants: string[] = []
  let resumed = 0
  let skipped = 0
  for (const row of rows) {
    /* già vivo in questo processo (riavvio a caldo): non duplicare MAI */
    if (enginesGlobal.engines.has(row.plantId)) {
      skipped++
      continue
    }
    const started = await startMonitoringEngine({
      plantId: row.plantId,
      intervalSec: row.intervalSec,
      radioEvery: row.radioEveryNCycles,
      via: 'AUTO_RESUME',
    })
    if ('error' in started) {
      skipped++
      continue
    }
    resumed++
    plants.push(row.plant?.name ?? row.plantId)
    await db.auditLog.create({
      data: {
        action: 'ENGINE_AUTO_RESUME',
        actor: 'system:auto-resume',
        targetId: row.plantId,
        targetLabel: `motore monitoraggio: auto-resume (avvio server) — ${row.plant?.name ?? row.plantId}`,
        plantId: row.plantId,
        details: JSON.stringify({
          action: 'auto-resume',
          intervalSec: row.intervalSec,
          radioEvery: row.radioEveryNCycles,
          note: 'v16.20 W22: configurazione persistita in EngineRuntime, riattivata all\u2019avvio del processo server',
        }),
      },
    }).catch(() => { /* audit best-effort */ })
  }
  return { resumed, skipped, plants }
}

/** v16.20 W22 — righe EngineRuntime per l'osservabilità (GET /setup/engine
 *  e riepilogo fase 7): anche i motori NON in memoria sono visibili dal DB. */
export async function engineRuntimeRows(): Promise<Array<{
  plantId: string
  plantName: string
  enabled: boolean
  intervalSec: number
  radioEveryNCycles: number
  startedVia: string
  lastStartedAt: number | null
  lastHeartbeatAt: number | null
  lastStoppedAt: number | null
  stopReason: string
  cycles: number
  totalCycles: number
  lastError: string
}>> {
  try {
    const rows = await db.engineRuntime.findMany({
      select: {
        plantId: true, enabled: true, intervalSec: true, radioEveryNCycles: true,
        startedVia: true, lastStartedAt: true, lastHeartbeatAt: true, lastStoppedAt: true,
        stopReason: true, cycles: true, totalCycles: true, lastError: true,
        plant: { select: { name: true } },
      },
      orderBy: { updatedAt: 'desc' },
    })
    return rows.map((r) => ({
      plantId: r.plantId,
      plantName: r.plant?.name ?? r.plantId,
      enabled: r.enabled,
      intervalSec: r.intervalSec,
      radioEveryNCycles: r.radioEveryNCycles,
      startedVia: r.startedVia,
      lastStartedAt: r.lastStartedAt?.getTime() ?? null,
      lastHeartbeatAt: r.lastHeartbeatAt?.getTime() ?? null,
      lastStoppedAt: r.lastStoppedAt?.getTime() ?? null,
      stopReason: r.stopReason,
      cycles: r.cycles,
      totalCycles: r.totalCycles,
      lastError: r.lastError,
    }))
  } catch {
    return []
  }
}

/* dev: libera i timer della valutazione precedente (pattern bun --hot/next dev) */
if (!enginesGlobal.cleanupRegistered) {
  enginesGlobal.cleanupRegistered = true
  const prev = (globalThis as unknown as { __falcoMonitoringEngineCleanup?: () => void }).__falcoMonitoringEngineCleanup
  if (prev) {
    try { prev() } catch { /* già liberati */ }
  }
  ;(globalThis as unknown as { __falcoMonitoringEngineCleanup?: () => void }).__falcoMonitoringEngineCleanup = () => {
    for (const e of enginesGlobal.engines.values()) {
      if (e.timer) clearInterval(e.timer)
    }
    enginesGlobal.engines.clear()
  }
}
