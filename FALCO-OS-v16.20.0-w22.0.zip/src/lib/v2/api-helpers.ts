/* ================================================================
 * FALCO-OS v16 — Helper API v2
 * Busta risposta coerente (ok/error), autenticazione, parsing zod.
 * Nessun segreto esce mai da qui: le query usano allowlist di colonne.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import type { ZodType } from 'zod'
import { authOptions } from '@/lib/auth'

export function ok<T>(data: T, asOf: number, mode: 'replay' | 'static' = 'replay') {
  /* W6 hardening: le risposte API v2 non vengono MAI messe in cache
   * (dati operativi sensibili del NOC, anche in errori intermedi). */
  const res = NextResponse.json({ ok: true as const, asOf, mode, data })
  res.headers.set('Cache-Control', 'no-store')
  return res
}

export function fail(code: string, message: string, status: number, details?: unknown) {
  const res = NextResponse.json({ ok: false as const, error: { code, message, details } }, { status })
  res.headers.set('Cache-Control', 'no-store')
  return res
}

/** Guard di autenticazione per le rotte v2: sessione NextAuth richiesta.
 * (Autorità permessi: backend — il frontend non ridefinisce regole.) */
export async function requireSession(): Promise<
  { ok: true; session: { user: { id?: string; name?: string | null; email?: string | null; role?: string } } } |
  { ok: false; response: NextResponse }
> {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return { ok: false, response: fail('UNAUTHORIZED', 'Autenticazione richiesta', 401) }
  }
  return { ok: true, session: session as unknown as { user: { id?: string; name?: string | null; email?: string | null; role?: string } } }
}

/** Parsing query string con schema zod; errore 422 con dettagli. */
export function parseQuery<T>(schema: ZodType<T>, url: URL): { ok: true; value: T } | { ok: false; response: NextResponse } {
  const params: Record<string, string> = {}
  url.searchParams.forEach((v, k) => { params[k] = v })
  const parsed = schema.safeParse(params)
  if (!parsed.success) {
    return {
      ok: false,
      response: fail('BAD_QUERY', 'Parametri non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message }))),
    }
  }
  return { ok: true, value: parsed.data }
}

export function csv(v: string | undefined | null): string[] {
  if (!v) return []
  return v.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean)
}
