/* ================================================================
 * FALCO-OS v16 — Autenticazione (port dal backend v15.16.0)
 * Provenienza: src/lib/auth.ts (repo v15.16.0) — NextAuth v4
 * Credentials + JWT + bcryptjs + lockout per-account (5 tentativi /
 * 15 min, backoff lineare). LDAP non importato: LdapConfig = 0 righe
 * nel DB reale. Ruoli: TECNICO, RESPONSABILE_COMUNE, SUPER_ADMIN, CLIENTE.
 * Il backend resta l'autorità su permessi e transizioni (regola §2.3).
 * ================================================================ */

import type { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'

const LOGIN_WINDOW_MS = 15 * 60 * 1000
const LOGIN_MAX_ATTEMPTS = 5
const LOGIN_LOCKOUT_MS = 15 * 60 * 1000
const loginAttempts = new Map<string, { count: number; firstAt: number; lockedUntil: number }>()

/* ---- W6 hardening: throttle PER-IP (difesa dallo spraying di many
 * ---- account, che il solo lockout per-email non ferma). Soglia alta
 * ---- (30 fallimenti / 15 min) per non colpire utenti legittimi dietro
 * ---- proxy condivisi; blocco 5 minuti; in-memory: si azzera al restart
 * ---- (dichiarato). Il conteggio registra SOLO i fallimenti. */
const IP_WINDOW_MS = 15 * 60 * 1000
const IP_MAX_FAILURES = 30
const IP_THROTTLE_MS = 5 * 60 * 1000
const ipAttempts = new Map<string, { count: number; firstAt: number; throttledUntil: number }>()

function clientIp(headers: Headers | Record<string, unknown> | undefined | null): string {
  const pick = (k: string): string | null => {
    if (!headers) return null
    if (typeof (headers as Headers).get === 'function') return (headers as Headers).get(k)
    const v = (headers as Record<string, unknown>)[k]
    return typeof v === 'string' ? v : null
  }
  const xff = pick('x-forwarded-for')
  if (xff) return xff.split(',')[0].trim() || 'direct'
  return pick('x-real-ip') ?? 'direct'
}

function isIpThrottled(ip: string): number {
  const e = ipAttempts.get(ip)
  if (!e) return 0
  if (e.throttledUntil > Date.now()) return e.throttledUntil - Date.now()
  return 0
}

function recordIpFailure(ip: string): boolean {
  /* ritorna true SE QUESTO fallimento ha INGAGGIATO il throttle
   * (per la voce di audit, una sola volta per blocco) */
  const now = Date.now()
  const e = ipAttempts.get(ip)
  if (!e || now - e.firstAt > IP_WINDOW_MS) {
    ipAttempts.set(ip, { count: 1, firstAt: now, throttledUntil: 0 })
    return false
  }
  e.count++
  if (e.count >= IP_MAX_FAILURES && e.throttledUntil < now) {
    e.throttledUntil = now + IP_THROTTLE_MS
    return true
  }
  return false
}

function isLoginLocked(emailLower: string): number {
  const e = loginAttempts.get(emailLower)
  if (!e) return 0
  if (e.lockedUntil > Date.now()) return e.lockedUntil - Date.now()
  return 0
}

function recordLoginFailure(emailLower: string): boolean {
  /* ritorna true SE QUESTO fallimento ha INGAGGIATO il lockout
   * (per la voce di audit, una sola volta per blocco) */
  const now = Date.now()
  const e = loginAttempts.get(emailLower)
  if (!e || now - e.firstAt > LOGIN_WINDOW_MS) {
    loginAttempts.set(emailLower, { count: 1, firstAt: now, lockedUntil: 0 })
    return false
  }
  e.count++
  if (e.count >= LOGIN_MAX_ATTEMPTS && e.lockedUntil < now) {
    const over = Math.floor((e.count - LOGIN_MAX_ATTEMPTS) / 5)
    e.lockedUntil = now + LOGIN_LOCKOUT_MS + over * LOGIN_LOCKOUT_MS
    return true
  }
  return false
}

function recordLoginSuccess(emailLower: string): void {
  loginAttempts.delete(emailLower)
}

setInterval(() => {
  const now = Date.now()
  for (const [k, v] of loginAttempts) {
    if (v.lockedUntil < now && now - v.firstAt > LOGIN_WINDOW_MS) loginAttempts.delete(k)
  }
}, 10 * 60 * 1000).unref?.()

export const authOptions: NextAuthOptions = {
  session: { strategy: 'jwt', maxAge: 12 * 60 * 60 },
  pages: { signIn: '/' }, // login integrato nella pagina unica (overlay)
  providers: [
    CredentialsProvider({
      name: 'Credenziali FALCO-OS',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials, req) {
        const email = credentials?.email?.trim().toLowerCase()
        const password = credentials?.password
        if (!email || !password) return null

        /* W6: throttle per-IP prima del confronto credenziali. */
        const ip = clientIp(req?.headers)
        const ipMs = isIpThrottled(ip)
        if (ipMs > 0) {
          throw new Error(`IP_THROTTLED:${Math.ceil(ipMs / 1000)}`)
        }

        const lockMs = isLoginLocked(email)
        if (lockMs > 0) {
          throw new Error(`ACCOUNT_LOCKED:${Math.ceil(lockMs / 60000)}`)
        }

        const user = await db.user.findUnique({ where: { email } })
        // hash bcrypt reale del DB (demo: reimpostato all'import, vedi D1)
        if (!user || !user.passwordHash || !bcrypt.compareSync(password, user.passwordHash)) {
          const wasLocked = recordLoginFailure(email)
          const ipEngaged = recordIpFailure(ip)
          /* Audit ONESTO dei blocchi (righe BOUNDED: solo quando il
           * blocco si INGAGGIA, mai una riga per fallimento — evita il
           * log-flood da brute force). Nessun segreto nei details. */
          if (wasLocked) {
            await db.auditLog.create({ data: {
              action: 'LOGIN_LOCKED', actor: email, targetId: null,
              targetLabel: `account bloccato per ${LOGIN_LOCKOUT_MS / 60000} min (${LOGIN_MAX_ATTEMPTS} tentativi)`,
              details: JSON.stringify({ email, ip, windowMin: LOGIN_WINDOW_MS / 60000 }),
            } }).catch(() => undefined)
          }
          if (ipEngaged) {
            await db.auditLog.create({ data: {
              action: 'LOGIN_IP_THROTTLED', actor: 'SYSTEM', targetId: null,
              targetLabel: `IP ${ip} rallentato per ${IP_THROTTLE_MS / 60000} min`,
              details: JSON.stringify({ ip, failures: IP_MAX_FAILURES, windowMin: IP_WINDOW_MS / 60000 }),
            } }).catch(() => undefined)
          }
          return null
        }
        recordLoginSuccess(email)
        ipAttempts.delete(ip)
        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = (user as { id: string }).id
        token.role = (user as { role: string }).role
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string | undefined
        session.user.role = token.role as string | undefined
      }
      return session
    },
  },
}

/** Gerarchia ruoli (CLIENTE = sola lettura portale, come nel repo). */
export const ROLE_RANK: Record<string, number> = {
  CLIENTE: 0,
  TECNICO: 1,
  RESPONSABILE_COMUNE: 2,
  SUPER_ADMIN: 3,
}

export function hasRole(role: string | undefined | null, min: keyof typeof ROLE_RANK): boolean {
  if (!role) return false
  return (ROLE_RANK[role] ?? -1) >= (ROLE_RANK[min] ?? 99)
}
