/* ================================================================
 * FALCO-OS v16 — Cifratura credenziali/integrazioni (porta v15)
 * AES-256-GCM: IV 12 byte + authTag 16 byte, output base64
 * "iv.tag.ciphertext". Chiave master da env DEVICE_CREDENTIALS_KEY
 * (64 hex = 32 byte) — MAI nel DB, MAI in git.
 * Se la chiave manca: encrypt/decrypt rifiutano con errore esplicito
 * (nessun fallback a testo in chiaro — onestà di sicurezza).
 * ================================================================ */

import { createCipheriv, createDecipheriv, createHmac, randomBytes } from 'crypto'

const KEY_HEX_LEN = 64 // 32 byte = AES-256

function masterKey(): Buffer | null {
  const hex = process.env.DEVICE_CREDENTIALS_KEY
  if (!hex || !/^[0-9a-fA-F]{64}$/.test(hex)) return null
  return Buffer.from(hex, 'hex')
}

/** Cifra un segreto. Ritorna null se la chiave master non è
 * configurata (il chiamante deve rifiutare l'operazione). */
export function encryptSecret(plain: string): string | null {
  const key = masterKey()
  if (!key) return null
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, iv)
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()])
  const tag = cipher.getAuthTag()
  return `${iv.toString('base64')}.${tag.toString('base64')}.${enc.toString('base64')}`
}

/** Decifra un segreto cifrato con encryptSecret. Errori → null
 * (chiave rotata o dato corrotto: mai eccezione al chiamante). */
export function decryptSecret(payload: string): string | null {
  const key = masterKey()
  if (!key) return null
  const parts = payload.split('.')
  if (parts.length !== 3) return null
  try {
    const [iv, tag, data] = parts.map((p) => Buffer.from(p, 'base64'))
    const decipher = createDecipheriv('aes-256-gcm', key, iv)
    decipher.setAuthTag(tag)
    const dec = Buffer.concat([decipher.update(data), decipher.final()])
    return dec.toString('utf8')
  } catch {
    return null
  }
}

export function hasMasterKey(): boolean {
  return masterKey() !== null
}

/** Firma HMAC-SHA256 stile webhook (t=epoch, v1=hex): usata dai
 * webhook per firmare i payload (schema X-Falco-Signature). */
export function hmacSign(secret: string, timestamp: number, body: string): string {
  return createHmac('sha256', secret).update(`${timestamp}.${body}`).digest('hex')
}
