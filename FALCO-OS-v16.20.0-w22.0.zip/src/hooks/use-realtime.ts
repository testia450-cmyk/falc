'use client'

// FALCO-OS — hook realtime: WebSocket nativo verso il servizio :3001 via gateway.
// URL: ws(s)://<host>/?XTransformPort=3001 (path "/", query XTransformPort — regola gateway).

import { useEffect, useRef, useState, useCallback } from 'react'

export type RealtimeKpis = {
  devices: { total: number; online: number; degraded: number; offline: number; maintenance: number; unknown: number; unmonitored: number }
  cameras: { total: number; up: number; down: number; unknown: number }
  links: { total: number; active: number; degraded: number; standby: number; unknown: number }
  alarms: { open: number; acknowledged: number; critical: number; high: number }
  ticketsOpen: number
  maintenanceActive: number
  coveragePct: number
  asOf?: string
}

export type RealtimeState = {
  connected: boolean
  tick: number | null
  lastTickAt: string | null
  kpis: RealtimeKpis | null
  lastError: string | null
}

export function useRealtime(): RealtimeState & { reconnect: () => void } {
  const [state, setState] = useState<RealtimeState>({
    connected: false, tick: null, lastTickAt: null, kpis: null, lastError: null,
  })
  const wsRef = useRef<WebSocket | null>(null)
  const retryRef = useRef(0)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const manualRef = useRef(false)

  const connect = useCallback(() => {
    if (typeof window === 'undefined') return
    try {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
      const url = `${proto}//${window.location.host}/?XTransformPort=3001`
      const ws = new WebSocket(url)
      wsRef.current = ws

      ws.onopen = () => {
        retryRef.current = 0
        setState(s => ({ ...s, connected: true, lastError: null }))
      }
      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data as string) as { type: string; at?: string; tick?: number; kpis?: RealtimeKpis | null }
          if (msg.type === 'snapshot' || msg.type === 'tick') {
            setState(s => ({
              ...s,
              connected: true,
              tick: typeof msg.tick === 'number' ? msg.tick : s.tick,
              lastTickAt: msg.at ?? s.lastTickAt,
              kpis: msg.kpis ?? s.kpis,
            }))
          }
        } catch {
          // messaggio non JSON: ignorato
        }
      }
      ws.onerror = () => {
        setState(s => ({ ...s, lastError: 'Errore di connessione realtime.' }))
      }
      ws.onclose = () => {
        setState(s => ({ ...s, connected: false }))
        if (manualRef.current) return
        const delay = Math.min(15000, 1000 * 2 ** Math.min(retryRef.current, 4))
        retryRef.current += 1
        timerRef.current = setTimeout(connect, delay)
      }
    } catch (e) {
      setState(s => ({ ...s, lastError: (e as Error).message }))
    }
  }, [])

  useEffect(() => {
    manualRef.current = false
    connect()
    return () => {
      manualRef.current = true
      if (timerRef.current) clearTimeout(timerRef.current)
      wsRef.current?.close()
    }
  }, [connect])

  const reconnect = useCallback(() => {
    retryRef.current = 0
    wsRef.current?.close()
    connect()
  }, [connect])

  return { ...state, reconnect }
}
