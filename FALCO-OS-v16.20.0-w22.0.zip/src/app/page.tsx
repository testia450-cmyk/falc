/* FALCO-OS v16 — NOC (unica pagina visibile: navigazione a stato URL)
 * Deep link: ?view=…&device=…&tab=…&rete=… (store sincronizzato). */

'use client'

import dynamic from 'next/dynamic'
import { useApp } from '@/lib/client/store'
import { AppShell } from '@/components/app-shell'
import { QuickLook } from '@/components/quick-look'

/* Le viste pesanti (mappa Leaflet, grafo xyflow) sono caricate lazy per
 * non bloccare il primo render della dashboard. */
const DashboardView = dynamic(() => import('@/views/dashboard-view'), {
  loading: () => <div className="space-y-4"><div className="h-24 animate-pulse rounded-lg bg-surface" /><div className="h-96 animate-pulse rounded-lg bg-surface" /></div>,
})
/* Vista «Setup impianto» (16.19 W21): wizard a fasi per mettere in
 * pista un impianto NUOVO dall'inizio alla fine (import → scansione →
 * credenziali → adozione → telemetria → allarmi → riepilogo). */
const SetupView = dynamic(() => import('@/views/setup-view'), {
  loading: () => <div className="space-y-3">{[...Array(6)].map((_, i) => <div key={i} className="h-16 animate-pulse rounded-md bg-surface" />)}</div>,
})
const ReteView = dynamic(() => import('@/views/rete-view'), {
  loading: () => <div className="h-[70vh] animate-pulse rounded-lg bg-surface" />,
})
const DispositiviView = dynamic(() => import('@/views/dispositivi-view'), {
  loading: () => <div className="space-y-3">{[...Array(8)].map((_, i) => <div key={i} className="h-10 animate-pulse rounded-md bg-surface" />)}</div>,
})
const TelecamereView = dynamic(() => import('@/views/telecamere-view'), {
  loading: () => <div className="space-y-3">{[...Array(6)].map((_, i) => <div key={i} className="h-10 animate-pulse rounded-md bg-surface" />)}</div>,
})
const AllarmiView = dynamic(() => import('@/views/allarmi-view'), {
  loading: () => <div className="space-y-3">{[...Array(8)].map((_, i) => <div key={i} className="h-10 animate-pulse rounded-md bg-surface" />)}</div>,
})
const OperazioniView = dynamic(() => import('@/views/operazioni-view'), {
  loading: () => <div className="space-y-3">{[...Array(8)].map((_, i) => <div key={i} className="h-10 animate-pulse rounded-md bg-surface" />)}</div>,
})
/* Vista «Assistente» (16.9 W4): chat AI con stream SSE — export con nome. */
const AssistenteView = dynamic(() => import('@/components/assistente-view').then((m) => m.AssistenteView), {
  loading: () => <div className="space-y-3">{[...Array(6)].map((_, i) => <div key={i} className="h-16 animate-pulse rounded-md bg-surface" />)}</div>,
})
const ReportView = dynamic(() => import('@/views/report-view'), {
  loading: () => <div className="space-y-3">{[...Array(6)].map((_, i) => <div key={i} className="h-16 animate-pulse rounded-md bg-surface" />)}</div>,
})
const AmministrazioneView = dynamic(() => import('@/views/amministrazione-view'), {
  loading: () => <div className="grid gap-4 lg:grid-cols-2">{[...Array(6)].map((_, i) => <div key={i} className="h-40 animate-pulse rounded-lg bg-surface" />)}</div>,
})
const WallboardView = dynamic(() => import('@/views/wallboard-view'), {
  loading: () => <div className="fixed inset-0 z-50 animate-pulse bg-background" aria-label="Caricamento wallboard" />,
})

export default function Home() {
  const view = useApp((s) => s.view)

  return (
    <AppShell>
      {view === 'dashboard' ? <DashboardView /> : null}
      {view === 'setup' ? <SetupView /> : null}
      {view === 'rete' ? <ReteView /> : null}
      {view === 'dispositivi' ? <DispositiviView /> : null}
      {view === 'telecamere' ? <TelecamereView /> : null}
      {view === 'allarmi' ? <AllarmiView /> : null}
      {view === 'operazioni' ? <OperazioniView /> : null}
      {view === 'assistente' ? <AssistenteView /> : null}
      {view === 'report' ? <ReportView /> : null}
      {view === 'amministrazione' ? <AmministrazioneView /> : null}
      {/* Wallboard (16.2): vista «TV» per monitor dedicato — overlay a
       * tutto schermo sopra la shell (Esc esce, deep link ?view=wallboard). */}
      {view === 'wallboard' ? <WallboardView /> : null}
      {/* Quick-look globale (deep link ?device=ID): NELLA vista Dispositivi
       * non si sovrappone alla scheda apparato completa che la sostituisce. */}
      {view !== 'dispositivi' ? <QuickLook /> : null}
    </AppShell>
  )
}
