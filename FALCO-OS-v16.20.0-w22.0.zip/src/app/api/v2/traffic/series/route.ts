/* ================================================================
 * /api/v2/traffic/series — GET
 * Domanda a cui risponde (§6.1): «Quanto traffico sta passando nel
 * cuore della rete?» — aggregato D3 (DEFINITO qui, dichiarato nella
 * risposta, nessuna ambiguità):
 *  1. «core di distribuzione» = dispositivo SWITCH o GATEWAY con
 *     tier ≤ 2 nell'albero (computeNetworkTiers) che ha il maggior
 *     VOLUME di traffico reale (somma dei campioni port_traffic_in+out)
 *     nella finestra richiesta — non il maggior numero di campioni:
 *     uno switch può essere campionato spesso e portare ~zero traffico
 *     (caso reale: SW Tetto Comune, 4766 campioni, ~15 Mbps cumulati)
 *  2. serie: bucket da 5 MINUTI sul core (GROUP BY, divisione intera
 *     su ms), v = media Mbps del bucket (il poller scrive già Mbps);
 *  3. lastIn/OutMbps: ultimo campione reale del core NELLA finestra;
 *     lastSampleAt = timestamp del più recente dei due;
 *  4. senza dati: arrays vuoti e lastX null (nessun punto inventato);
 *     la stringa `definition` dichiara esattamente questa definizione
 *     (in italiano, con hostname del core) per l'onestà in UI (§2.1).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { TrafficQuerySchema, TrafficSeriesSchema } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, getPlantLinks, buildPlantTiers, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const CORE_TYPES = ['SWITCH', 'GATEWAY']
const MAX_TIER = 2

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(TrafficQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const [{ rows, asOf: rowsAsOf }, links] = await Promise.all([
    loadDeviceRows(p.id),
    getPlantLinks(p.id),
  ])
  const tiers = buildPlantTiers(rows, links, p.topologyRootDeviceId)

  const now = Date.now()
  const sinceMs = now - q.value.hours * 3600 * 1000

  /* --- Volume di traffico REALE per device nella finestra (SUM value) --- */
  const vols = await db.$queryRaw<Array<{ deviceId: string; vol: number; n: number }>>`
    SELECT deviceId, SUM(value) AS vol, COUNT(*) AS n
    FROM MetricValue
    WHERE plantId = ${p.id} AND metric IN ('port_traffic_in', 'port_traffic_out') AND timestamp >= ${sinceMs}
    GROUP BY deviceId`
  const volByDevice = new Map(vols.map((c) => [c.deviceId, { vol: Number(c.vol), n: Number(c.n) }]))

  /* --- Core = SWITCH/GATEWAY tier ≤ 2 col maggior VOLUME reale --- */
  let core: { id: string; hostname: string; vol: number; samples: number } | null = null
  for (const r of rows) {
    if (!CORE_TYPES.includes(r.type)) continue
    const tier = tiers.tierOf.get(r.id)
    if (tier == null || tier > MAX_TIER) continue
    const v = volByDevice.get(r.id)
    if (!v || v.vol <= 0) continue
    if (!core || v.vol > core.vol) core = { id: r.id, hostname: r.hostname, vol: v.vol, samples: v.n }
  }

  if (!core) {
    const data = {
      definition: `Nessun core di distribuzione (switch/gateway di tier ≤ ${MAX_TIER}) con campioni port_traffic_in/out nelle ultime ${q.value.hours} ore: nessun dato da mostrare, nessun punto inventato.`,
      coreDeviceId: null,
      coreHostname: null,
      inMbps: [],
      outMbps: [],
      lastInMbps: null,
      lastOutMbps: null,
      lastSampleAt: null,
    }
    const mode = apiMode(replay)
    const asOf = rowsAsOf || now
    const body = { ok: true as const, asOf, mode, data }
    devValidate(TrafficSeriesSchema, body)
    return ok(data, asOf, mode)
  }

  /* --- Bucket 5 minuti sul core (GROUP BY, divisione intera su ms) --- */
  const buckets = await db.$queryRaw<Array<{ metric: string; bucket: number; v: number }>>`
    SELECT metric, (timestamp / 300000) * 300000 AS bucket, AVG(value) AS v
    FROM MetricValue
    WHERE deviceId = ${core.id} AND metric IN ('port_traffic_in', 'port_traffic_out') AND timestamp >= ${sinceMs}
    GROUP BY metric, bucket
    ORDER BY bucket ASC`
  const inMbps: Array<{ t: number; v: number }> = []
  const outMbps: Array<{ t: number; v: number }> = []
  for (const b of buckets) {
    const point = { t: Number(b.bucket), v: Math.round(Number(b.v) * 100) / 100 }
    if (b.metric === 'port_traffic_in') inMbps.push(point)
    else if (b.metric === 'port_traffic_out') outMbps.push(point)
  }

  /* --- Ultimi campioni reali nella finestra (SQL finestra) --- */
  const lasts = await db.$queryRaw<Array<{ metric: string; value: number; timestamp: Date }>>`
    SELECT metric, value, timestamp FROM (
      SELECT metric, value, timestamp,
             ROW_NUMBER() OVER (PARTITION BY metric ORDER BY timestamp DESC) AS rn
      FROM MetricValue
      WHERE deviceId = ${core.id} AND metric IN ('port_traffic_in', 'port_traffic_out') AND timestamp >= ${sinceMs}
    ) WHERE rn = 1`
  const lastInMbps = lasts.find((l) => l.metric === 'port_traffic_in')?.value ?? null
  const lastOutMbps = lasts.find((l) => l.metric === 'port_traffic_out')?.value ?? null
  const lastSampleAt = lasts.length ? Math.max(...lasts.map((l) => l.timestamp.getTime())) : null

  const data = {
    definition: `Traffico aggregato sul core di distribuzione «${core.hostname}»: switch/gateway di tier ≤ ${MAX_TIER} dell'albero di rete con il maggior VOLUME di traffico reale (somma port_traffic_in+out = ${Math.round(core.vol)} Mbps cumulati, ${core.samples} campioni) nelle ultime ${q.value.hours} ore. Serie a bucket di 5 minuti: ogni punto è la MEDIA Mbps del bucket (unità reale del poller: Mbps). Valori lastIn/lastOut = ultimo campione reale nella finestra.`,
    coreDeviceId: core.id,
    coreHostname: core.hostname,
    inMbps,
    outMbps,
    lastInMbps,
    lastOutMbps,
    lastSampleAt,
  }

  const asOf = maxOf(lastSampleAt, rowsAsOf) || now
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(TrafficSeriesSchema, body)
  return ok(data, asOf, mode)
}
