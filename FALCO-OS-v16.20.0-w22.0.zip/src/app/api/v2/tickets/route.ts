/* ================================================================
 * /api/v2/tickets — GET (elenco) + POST (creazione)
 * Domanda a cui risponde (§6.7 Operazioni): «Quali ticket sono aperti,
 * in lavorazione o risolti, con quale priorità e SLA?»
 *  · GET: filtri status/priority (CSV), testo q (contains su
 *    title/description/assignedTo), paginazione server-side
 *    (default 25, max 100); ordinamento updatedAt DESC fisso;
 *    la risposta include i KPI GLOBALI dell'impianto (non filtrati)
 *    per la striscia KPI della vista: open, inProgress, resolved7d,
 *    slaOverdue — calcolati con where separato sul plant;
 *  · POST: crea un ticket REALE (source "MANUAL", status "OPEN",
 *    assignedTo = email di sessione); se deviceId presente, plantId e
 *    locationId vengono ereditati dal device (plant di default per i
 *    dispositivi scoperti senza sede); audit TICKET_CREATE in
 *    TRANSAZIONE con la create; risponde 201 con la riga creata.
 * Stati/priorità REALI distinti verificati sul DB (16.1): OPEN;
 * CRITICAL, HIGH. Valori ignoti restano stringa grezza (mai crash).
 * Nessun campo credenziale selezionato (allowlist TICKET_INCLUDE).
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery, csv } from '@/lib/v2/api-helpers'
import { TicketsQuerySchema, TicketsPageSchema, CreateTicketInputSchema, TicketRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { resolvePlant, devValidate, maxOf, TICKET_INCLUDE, toTicketRow, ticketCountsMap } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(TicketsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const now = new Date()

  /* --- Filtri utente --- */
  const statusFilter = csv(q.value.status)
  const priorityFilter = csv(q.value.priority)
  const where: Prisma.TicketWhereInput = { plantId: p.id }
  if (statusFilter.length) where.status = { in: statusFilter }
  if (priorityFilter.length) where.priority = { in: priorityFilter }
  if (q.value.q) {
    where.OR = [
      { title: { contains: q.value.q } },
      { description: { contains: q.value.q } },
      { assignedTo: { contains: q.value.q } },
    ]
  }

  /* --- Pagina + KPI globali (where SOLO plant, senza filtri utente) --- */
  const [total, pageRows, kpis] = await Promise.all([
    db.ticket.count({ where }),
    db.ticket.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      include: TICKET_INCLUDE,
      skip: (q.value.page - 1) * q.value.pageSize,
      take: q.value.pageSize,
    }),
    (async () => {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000)
      const [open, inProgress, resolved7d, slaOverdue] = await Promise.all([
        db.ticket.count({ where: { plantId: p.id, status: 'OPEN' } }),
        db.ticket.count({ where: { plantId: p.id, status: 'IN_PROGRESS' } }),
        db.ticket.count({ where: { plantId: p.id, resolvedAt: { gte: weekAgo } } }),
        db.ticket.count({
          where: {
            plantId: p.id,
            status: { in: ['OPEN', 'IN_PROGRESS'] },
            slaResolutionDueAt: { lt: now },
          },
        }),
      ])
      return { open, inProgress, resolved7d, slaOverdue }
    })(),
  ])

  const counts = await ticketCountsMap(pageRows.map((r) => r.id))
  const items = pageRows.map((r) => toTicketRow(r, counts.get(r.id) ?? { interventions: 0, comments: 0 }))

  const data = {
    items,
    total,
    page: q.value.page,
    pageSize: q.value.pageSize,
    pageCount: Math.max(1, Math.ceil(total / q.value.pageSize)),
    kpis,
  }

  const asOf = maxOf(...pageRows.map((r) => r.updatedAt.getTime())) || Date.now()
  const mode = apiMode(replay)
  devValidate(TicketsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { title, description, priority, deviceId? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { title, description, priority, deviceId? })', 422)
  }
  const parsed = CreateTicketInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response

  /* --- Dispositivo opzionale: eredita plantId/locationId --- */
  let device: {
    id: string
    hostname: string
    ip: string
    locationId: string | null
    location: { plantId: string; name: string } | null
  } | null = null
  if (input.deviceId) {
    device = await db.device.findUnique({
      where: { id: input.deviceId },
      select: {
        id: true, hostname: true, ip: true, locationId: true,
        location: { select: { plantId: true, name: true } },
      },
    })
    if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)
  }
  /* Dispositivi scoperti senza sede: restano dell'impianto risolto
   * (stesso scope OR del /noc/summary), locationId resta null. */
  const plantId = device?.location?.plantId ?? plant.plant.id
  const locationId = device?.locationId ?? null

  const now = new Date()
  const email = session.session.user.email ?? 'sconosciuto'

  /* --- Create + audit in transazione interattiva --- */
  const created = await db.$transaction(async (tx) => {
    const t = await tx.ticket.create({
      data: {
        title: input.title,
        description: input.description,
        priority: input.priority,
        status: 'OPEN',
        source: 'MANUAL',
        plantId,
        locationId,
        deviceId: device?.id ?? null,
        assignedTo: email,
        assignedAt: now,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'TICKET_CREATE',
        actor: email,
        targetId: t.id,
        targetLabel: t.title.slice(0, 80),
        plantId: t.plantId,
        details: JSON.stringify({
          ticketId: t.id,
          title: t.title,
          deviceId: input.deviceId ?? null,
        }),
      },
    })
    return t
  })

  /* --- Riga di risposta (relazioni incluse) --- */
  const row = await db.ticket.findUnique({ where: { id: created.id }, include: TICKET_INCLUDE })
  if (!row) return fail('CREATE_FAILED', 'Ticket creato ma non rileggibile', 500)

  const data = toTicketRow(row, { interventions: 0, comments: 0 })
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(TicketRowSchema, data) // risposta singola: valida la riga nella busta
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
