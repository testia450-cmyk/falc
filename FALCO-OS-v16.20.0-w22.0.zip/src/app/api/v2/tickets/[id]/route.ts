/* ================================================================
 * /api/v2/tickets/[id] — GET (scheda intervento, 16.8 W2) + PATCH (transizioni di stato validate)
 * Macchina a stati del workflow ticket v8 (il DB reale ha solo OPEN:
 * le transizioni NASCONO da qui, nessuno stato inventato):
 *   OPEN → IN_PROGRESS  «presa in carico» (assegna se non assegnato)
 *   OPEN → CLOSED       chiusura diretta (resolution opzionale)
 *   IN_PROGRESS → RESOLVED  (richiede resolution NON vuota)
 *   RESOLVED → CLOSED   chiusura definitiva
 * Ogni salto illegale → 422 INVALID_TRANSITION con messaggio esplicito
 * (mai silenzio, mai dati persi in silenzio).
 *  · body: { status, resolution?, assignedTo?, note? } — la nota libera
 *    NON finisce in campi inesistenti: vive SOLO nei details dell'audit
 *    (TICKET_STATUS_CHANGE, in TRANSAZIONE con l'update);
 *  · timestamp scritti quando previsto: assignedAt (presa in carico),
 *    resolvedAt (RESOLVED), closedAt (CLOSED); updatedAt è di Prisma;
 *  · risponde la TicketRow aggiornata (con conteggi ricalcolati).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateTicketInputSchema, TicketRowSchema, TicketDetailSchema } from '@/lib/v2/contracts'
import { hasRole } from '@/lib/auth'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate, TICKET_INCLUDE, toTicketRow, ticketCountsMap } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Transizioni LEGALI del workflow (motivo in italiano per i messaggi). */
const LEGAL: Record<string, Record<string, string>> = {
  OPEN: { IN_PROGRESS: 'presa in carico', CLOSED: 'chiusura diretta' },
  IN_PROGRESS: { RESOLVED: 'risoluzione' },
  RESOLVED: { CLOSED: 'chiusura' },
}

function legalList(from: string): string {
  const targets = Object.keys(LEGAL[from] ?? {})
  return targets.length ? `${from} → ${targets.join(' / ')}` : `nessuna transizione da ${from}`
}

/* ----------------------------------------------------------------
 * GET — dati REALI per la «scheda intervento» (W2 residua): il
 * documento stampabile per il tecnico in campo. Nessun campo
 * inventato: interventi e commenti escono col conteggio REALE del
 * DB (0 nel plant egidio: dichiarato in `honesty`), la timeline è
 * il registro audit REALE filtrato per targetId = ticket.
 * diagnosticSteps è JSON nel DB: parse difensivo (array di stringhe,
 * altro → []), rootCause/resolution testi grezzi.
 * ---------------------------------------------------------------- */
export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const { id } = await ctx.params
  const t = await db.ticket.findUnique({
    where: { id },
    include: {
      device: { select: { id: true, hostname: true, ip: true, type: true, brand: true, model: true, status: true } },
      location: { select: { id: true, name: true } },
      plant: { select: { id: true, name: true } },
    },
  })
  if (!t) return fail('NOT_FOUND', 'Ticket non trovato', 404)

  const [interventions, timeline, comments, attachments, timeEntries] = await Promise.all([
    db.intervention.findMany({
      where: { ticketId: id },
      orderBy: { createdAt: 'asc' },
      select: { id: true, action: true, component: true, description: true, technicianName: true, status: true, createdAt: true },
    }),
    db.auditLog.findMany({
      where: { targetId: id },
      orderBy: { createdAt: 'asc' },
      select: { action: true, actor: true, createdAt: true },
      take: 100,
    }),
    db.ticketComment.count({ where: { ticketId: id } }),
    db.ticketAttachment.count({ where: { ticketId: id } }),
    db.ticketTimeEntry.count({ where: { ticketId: id } }),
  ])

  let diagnosticSteps: string[] = []
  try {
    const parsed = JSON.parse(t.diagnosticSteps)
    if (Array.isArray(parsed)) diagnosticSteps = parsed.map(String).slice(0, 50)
  } catch { /* campo non JSON: resta [] (parse difensivo) */ }

  const data = {
    ticket: {
      id: t.id,
      title: t.title,
      description: t.description,
      status: t.status,
      priority: t.priority,
      source: t.source,
      createdAt: t.createdAt.getTime(),
      updatedAt: t.updatedAt.getTime(),
      assignedTo: t.assignedTo,
      assignedAt: t.assignedAt?.getTime() ?? null,
      firstResponseAt: t.firstResponseAt?.getTime() ?? null,
      resolvedAt: t.resolvedAt?.getTime() ?? null,
      closedAt: t.closedAt?.getTime() ?? null,
      slaResponseDueAt: t.slaResponseDueAt?.getTime() ?? null,
      slaResolutionDueAt: t.slaResolutionDueAt?.getTime() ?? null,
      slaPausedMinutes: t.slaPausedMinutes,
      escalationLevel: t.escalationLevel,
      rootCause: t.rootCause,
      resolution: t.resolution,
      diagnosticSteps,
    },
    device: t.device
      ? {
          id: t.device.id,
          hostname: t.device.hostname,
          ip: t.device.ip,
          type: t.device.type,
          brand: t.device.brand,
          model: t.device.model,
          status: t.device.status,
        }
      : null,
    location: t.location ? { id: t.location.id, name: t.location.name } : null,
    plant: { id: t.plant.id, name: t.plant.name },
    interventions: interventions.map((i) => ({
      id: i.id,
      action: i.action,
      component: i.component,
      description: i.description,
      technicianName: i.technicianName,
      status: i.status,
      createdAt: i.createdAt.getTime(),
    })),
    timeline: timeline.map((a) => ({ action: a.action, actor: a.actor, createdAt: a.createdAt.getTime() })),
    counts: { comments, attachments, timeEntries },
    honesty: `Registro interventi REALE del DB: ${interventions.length} righe collegate a questo ticket; commenti ${comments}, allegati ${attachments}, righe ore ${timeEntries}. In modalità riproduzione nessun dato viene aggiunto: la scheda stampa esattamente ciò che esiste.`,
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(TicketDetailSchema, { ok: true as const, asOf: t.updatedAt.getTime(), mode, data })
  return ok(data, t.updatedAt.getTime(), mode)
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  /* --- Corpo JSON { status, resolution?, assignedTo?, note? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { status, resolution?, assignedTo?, note? })', 422)
  }
  const parsed = UpdateTicketInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const body = parsed.data

  /* --- Ticket esistente? --- */
  const ticket = await db.ticket.findUnique({ where: { id }, include: TICKET_INCLUDE })
  if (!ticket) return fail('NOT_FOUND', 'Ticket non trovato', 404)

  const to = body.status
  if (!to) {
    return fail('BAD_BODY', 'Nessuna transizione richiesta: il campo "status" è obbligatorio nel PATCH (transizioni validate)', 422)
  }
  if (!(LEGAL[ticket.status] ?? {})[to]) {
    return fail('INVALID_TRANSITION', `Transizione non consentita: ${ticket.status} → ${to}. Consentite: ${legalList(ticket.status)}.`, 422)
  }

  const resolution = body.resolution?.trim() ?? ''
  const assignedTo = body.assignedTo?.trim() ?? ''

  /* --- Regole per transizione (check PRIMA di scrivere) --- */
  if (to === 'IN_PROGRESS' && resolution) {
    return fail('BAD_BODY', 'La risoluzione si imposta con la transizione verso RESOLVED o CLOSED, non con la presa in carico', 422)
  }
  if (to === 'RESOLVED' && !resolution) {
    return fail('RESOLUTION_REQUIRED', 'La transizione verso RESOLVED richiede una risoluzione non vuota (campo "resolution")', 422)
  }

  const now = new Date()
  const email = session.session.user.email ?? 'sconosciuto'

  /* --- Dati dell'update per transizione --- */
  const data: Prisma.TicketUpdateInput = { status: to }
  if (to === 'IN_PROGRESS') {
    // presa in carico: il body può riassegnare, altrimenti resta il
    // titolare esistente, altrimenti l'operatore che agisce (email sessione)
    data.assignedTo = assignedTo || ticket.assignedTo || email
    data.assignedAt = now
  }
  if (to === 'RESOLVED') {
    data.resolution = resolution
    data.resolvedAt = now
    if (assignedTo) data.assignedTo = assignedTo
  }
  if (to === 'CLOSED') {
    if (resolution) data.resolution = resolution // chiusura diretta da OPEN: opzionale ma salvata
    if (assignedTo) data.assignedTo = assignedTo
    data.closedAt = now
  }

  /* --- Update + audit in transazione interattiva --- */
  const updated = await db.$transaction(async (tx) => {
    const t = await tx.ticket.update({ where: { id }, data, include: TICKET_INCLUDE })
    await tx.auditLog.create({
      data: {
        action: 'TICKET_STATUS_CHANGE',
        actor: email,
        targetId: t.id,
        targetLabel: t.title.slice(0, 80),
        plantId: t.plantId,
        details: JSON.stringify({
          ticketId: t.id,
          from: ticket.status,
          to,
          note: body.note?.trim() || null, // nota libera: SOLO audit, mai campi inesistenti
          resolution: typeof data.resolution === 'string' && data.resolution ? data.resolution : null,
        }),
      },
    })
    return t
  })

  /* --- Riga aggiornata con conteggi ricalcolati --- */
  const counts = await ticketCountsMap([updated.id])
  const data2 = toTicketRow(updated, counts.get(updated.id) ?? { interventions: 0, comments: 0 })
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(TicketRowSchema, data2)
  return ok(data2, now.getTime(), mode)
}
