/* ================================================================
 * FALCO-OS v16 — API v2 · helper condivisi ondata W3.5 (operazioni
 * evolute, 16.7 §16.7)
 * File NON-route (Next ignora i file che non si chiamano route.ts):
 * stessa natura di shared.ts (dedicato alle onde 16.2-16.4), ma per
 * le rotte di questa ondata: event-policies, custom-oids,
 * config-requests, bulk-config, firmware, playbooks, automation-tasks.
 * Qui NIENTE logica di dominio nuova: solo parse difensivi dei campi
 * JSON-string del modello v15 (mai crash su dati storici corrotti),
 * il guardrail comandi portato da v15 e i serializzatori riga→contratto
 * (epoch ms, vocabolari castati, valori vuoti onesti).
 * ================================================================ */

import type { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { fail } from '@/lib/v2/api-helpers'
import { parseDaysOfWeek } from '@/app/api/v2/shared'
import {
  FORBIDDEN_COMMAND_PATTERNS, CONFIG_MAX_COMMANDS, BULK_MAX_TARGETS, BULK_MAX_COMMANDS,
  type EventPolicyRow, type CustomOidRow, type ConfigRequestRow, type BulkConfigRow,
  type FirmwareJobRow, type PlaybookRow, type AutomationTaskRow,
} from '@/lib/v2/contracts'

/* ---------------- Parse difensivo campi JSON-string ---------------- */

/** Campo JSON-string che contiene un array di stringhe (deviceTypes,
 *  scopeIds, commandsJson, rollbackJson, targetsJson…): JSON corrotto,
 *  vuoto o non-array → [] (un dato storico corrotto non deve rompere
 *  la lettura dell'elenco — stesso patto di parseDaysOfWeek). */
export function parseJsonStringArray(raw: string): string[] {
  try {
    const v: unknown = JSON.parse(raw || '[]')
    if (!Array.isArray(v)) return []
    return v.filter((s): s is string => typeof s === 'string')
  } catch {
    return []
  }
}

/** Hostname dei dispositivi indicati → mappa id→hostname (una query
 *  per tutto l'elenco caricato). I device mancanti restano assenti:
 *  la riga esce con meno hostname, mai con hostname inventati. */
export async function hostnameMapByIds(ids: string[]): Promise<Map<string, string>> {
  const uniq = Array.from(new Set(ids))
  if (uniq.length === 0) return new Map()
  const rows = await db.device.findMany({
    where: { id: { in: uniq } },
    select: { id: true, hostname: true },
  })
  return new Map(rows.map((r) => [r.id, r.hostname]))
}

/* ---------------- Guardrail comandi (portato da v15) ---------------- */

/** Hit del guardrail v15: ogni comando è matchato contro i pattern
 *  DISTRUTTIVI vietati (FORBIDDEN_COMMAND_PATTERNS). Restituisce le
 *  coppie {label, command} violante — il chiamante rifiuta con 422. */
export function forbiddenCommandHits(commands: string[]): Array<{ label: string; command: string }> {
  const hits: Array<{ label: string; command: string }> = []
  for (const cmd of commands) {
    for (const p of FORBIDDEN_COMMAND_PATTERNS) {
      if (p.re.test(cmd)) hits.push({ label: p.label, command: cmd })
    }
  }
  return hits
}

/** 422 coerente per tutte le rotte che applicano il guardrail: la
 *  richiesta è RIFIUTATA alla creazione, mai silenziata (v15). I label
 *  dei pattern violati viaggiano nei details. */
export function guardrailReject(hits: Array<{ label: string; command: string }>): NextResponse {
  const labels = Array.from(new Set(hits.map((h) => h.label)))
  return fail(
    'FORBIDDEN_COMMAND',
    `Comando vietato dal guardrail di sicurezza (v15): ${labels.join(' · ')}. La richiesta viene rifiutata alla creazione, mai silenziata.`,
    422,
    hits.map((h) => ({ path: 'commands', label: h.label, command: h.command.slice(0, 80) })),
  )
}

/* ---------------- AlertRule → EventPolicyRow ---------------- */

/** Serializza una regola evento (AlertRule v15) nella riga del
 *  contratto: epoch ms, deviceTypes/scopeIds/maintenanceDays parsati
 *  dai JSON-string del modello, vocabolari castati (il DB reale è
 *  allineato al vocabolario — devVerify lo certifica in dev). */
export function toEventPolicyRow(r: {
  id: string; name: string; description: string; enabled: boolean; systemKey: string | null
  metric: string; deviceTypes: string; scopeType: string; scopeIds: string; comparison: string
  threshold: number; recoveryThreshold: number | null; betweenMax: number | null; sustainSeconds: number
  severity: string; escalateAfterMinutes: number; cooldownMinutes: number
  maintenanceStart: string; maintenanceEnd: string; maintenanceDays: string
  createdAt: Date; updatedAt: Date
}): EventPolicyRow {
  return {
    id: r.id,
    name: r.name,
    description: r.description,
    enabled: r.enabled,
    systemKey: r.systemKey,
    metric: r.metric,
    deviceTypes: parseJsonStringArray(r.deviceTypes),
    scopeType: r.scopeType as EventPolicyRow['scopeType'],
    scopeIds: parseJsonStringArray(r.scopeIds),
    comparison: r.comparison as EventPolicyRow['comparison'],
    threshold: r.threshold,
    recoveryThreshold: r.recoveryThreshold,
    betweenMax: r.betweenMax,
    sustainSeconds: r.sustainSeconds,
    severity: r.severity as EventPolicyRow['severity'],
    escalateAfterMinutes: r.escalateAfterMinutes,
    cooldownMinutes: r.cooldownMinutes,
    maintenanceStart: r.maintenanceStart,
    maintenanceEnd: r.maintenanceEnd,
    maintenanceDays: parseDaysOfWeek(r.maintenanceDays),
    createdAt: r.createdAt.getTime(),
    updatedAt: r.updatedAt.getTime(),
  }
}

/* ---------------- CustomOid → CustomOidRow ---------------- */

export function toCustomOidRow(o: {
  id: string; name: string; oid: string; unit: string; scale: number
  dataType: string; intervalSec: number; description: string; enabled: boolean
  appliedCount: number; createdAt: Date; updatedAt: Date
}): CustomOidRow {
  return {
    id: o.id,
    name: o.name,
    oid: o.oid,
    unit: o.unit,
    scale: o.scale,
    dataType: o.dataType as CustomOidRow['dataType'],
    intervalSec: o.intervalSec,
    description: o.description,
    enabled: o.enabled,
    appliedCount: o.appliedCount, // 0 nel replay: statistiche oneste
    createdAt: o.createdAt.getTime(),
    updatedAt: o.updatedAt.getTime(),
  }
}

/* ---------------- ConfigChangeRequest → ConfigRequestRow ---------------- */

/** Include minimo per ConfigRequestRow: device (hostname/type per la
 *  riga + plantId della sede per l'audit delle azioni). Nessuna
 *  colonna credenziale selezionata. */
export const CONFIG_REQUEST_INCLUDE = {
  device: { select: { hostname: true, type: true, location: { select: { plantId: true } } } },
} as const

export type ConfigRequestWithDevice = Prisma.ConfigChangeRequestGetPayload<{
  include: typeof CONFIG_REQUEST_INCLUDE
}>

/** Ricostruisce il blocco safety dal safetyJson salvato alla creazione
 *  (parse difensivo: campi assenti/illeggibili → default onesti). */
function parseConfigSafety(raw: string): ConfigRequestRow['safety'] {
  const fallback: ConfigRequestRow['safety'] = {
    checked: 0,
    forbidden: [],
    maxCommands: CONFIG_MAX_COMMANDS,
    dryRunOnly: true, // replay: nessuna esecuzione reale, dichiarato
  }
  try {
    const v: unknown = JSON.parse(raw || '{}')
    if (v === null || typeof v !== 'object' || Array.isArray(v)) return fallback
    const o = v as Record<string, unknown>
    return {
      checked: typeof o.checked === 'number' && Number.isInteger(o.checked) ? o.checked : fallback.checked,
      forbidden: Array.isArray(o.forbidden) ? o.forbidden.filter((s): s is string => typeof s === 'string') : fallback.forbidden,
      maxCommands: typeof o.maxCommands === 'number' && Number.isInteger(o.maxCommands) ? o.maxCommands : fallback.maxCommands,
      dryRunOnly: typeof o.dryRunOnly === 'boolean' ? o.dryRunOnly : fallback.dryRunOnly,
    }
  } catch {
    return fallback
  }
}

export function toConfigRequestRow(r: ConfigRequestWithDevice): ConfigRequestRow {
  return {
    id: r.id,
    deviceId: r.deviceId,
    deviceHostname: r.device?.hostname ?? '',
    deviceType: r.device?.type ?? 'UNKNOWN',
    title: r.title,
    commands: parseJsonStringArray(r.commandsJson),
    rollback: parseJsonStringArray(r.rollbackJson),
    executor: r.executor as ConfigRequestRow['executor'],
    status: r.status,
    confirmMinutes: r.confirmMinutes,
    confirmBy: r.confirmBy?.getTime() ?? null,
    requestedBy: r.requestedById,
    approvedBy: r.approvedById,
    appliedAt: r.appliedAt?.getTime() ?? null,
    output: r.output,
    note: r.note,
    safety: parseConfigSafety(r.safetyJson),
    createdAt: r.createdAt.getTime(),
    updatedAt: r.updatedAt.getTime(),
  }
}

/* ---------------- BulkConfigChange → BulkConfigRow ---------------- */

function parseBulkSafety(raw: string): BulkConfigRow['safety'] {
  const fallback: BulkConfigRow['safety'] = {
    checked: 0,
    forbidden: [],
    maxTargets: BULK_MAX_TARGETS,
    maxCommands: BULK_MAX_COMMANDS,
    dryRunOnly: true,
  }
  try {
    const v: unknown = JSON.parse(raw || '{}')
    if (v === null || typeof v !== 'object' || Array.isArray(v)) return fallback
    const o = v as Record<string, unknown>
    return {
      checked: typeof o.checked === 'number' && Number.isInteger(o.checked) ? o.checked : fallback.checked,
      forbidden: Array.isArray(o.forbidden) ? o.forbidden.filter((s): s is string => typeof s === 'string') : fallback.forbidden,
      maxTargets: typeof o.maxTargets === 'number' && Number.isInteger(o.maxTargets) ? o.maxTargets : fallback.maxTargets,
      maxCommands: typeof o.maxCommands === 'number' && Number.isInteger(o.maxCommands) ? o.maxCommands : fallback.maxCommands,
      dryRunOnly: typeof o.dryRunOnly === 'boolean' ? o.dryRunOnly : fallback.dryRunOnly,
    }
  } catch {
    return fallback
  }
}

/** Risultati per target dal resultsJson (parse difensivo: voci
 *  illeggibili escono con i default onesti, mai crash). */
function parseBulkResults(raw: string): BulkConfigRow['results'] {
  try {
    const v: unknown = JSON.parse(raw || '[]')
    if (!Array.isArray(v)) return []
    return v
      .filter((e): e is Record<string, unknown> => e !== null && typeof e === 'object' && !Array.isArray(e))
      .map((e) => ({
        deviceId: typeof e.deviceId === 'string' ? e.deviceId : '',
        hostname: typeof e.hostname === 'string' ? e.hostname : '',
        ok: e.ok === true,
        simulated: e.simulated === true,
        error: typeof e.error === 'string' ? e.error : null,
        durationMs: typeof e.durationMs === 'number' && Number.isInteger(e.durationMs) ? e.durationMs : 0,
      }))
  } catch {
    return []
  }
}

export function toBulkConfigRow(
  w: {
    id: string; title: string; commandsJson: string; deviceIdsJson: string
    executor: string; status: string; safetyJson: string; resultsJson: string
    requestedById: string; startedAt: Date | null; completedAt: Date | null; createdAt: Date
  },
  hostnames: Map<string, string>,
): BulkConfigRow {
  const ids = parseJsonStringArray(w.deviceIdsJson)
  const shown = ids
    .map((id) => hostnames.get(id))
    .filter((h): h is string => h != null)
    .slice(0, 20) // cap dichiarato nel contratto (primi 20)
  return {
    id: w.id,
    title: w.title,
    commands: parseJsonStringArray(w.commandsJson),
    targetCount: ids.length, // totale REALE, il cap vale solo per l'elenco
    targetHostnames: shown,
    executor: w.executor as BulkConfigRow['executor'],
    status: w.status,
    safety: parseBulkSafety(w.safetyJson),
    results: parseBulkResults(w.resultsJson),
    requestedBy: w.requestedById,
    startedAt: w.startedAt?.getTime() ?? null,
    completedAt: w.completedAt?.getTime() ?? null,
    createdAt: w.createdAt.getTime(),
  }
}

/* ---------------- FirmwareUpgradeJob → FirmwareJobRow ---------------- */

/** Include minimo per FirmwareJobRow: device con firmware ATTUALE
 *  ("" = n.d. in UI) e plantId della sede (per l'audit). Nessuna
 *  colonna credenziale selezionata. */
export const FIRMWARE_INCLUDE = {
  device: { select: { hostname: true, type: true, firmwareVersion: true, location: { select: { plantId: true } } } },
} as const

export type FirmwareJobWithDevice = Prisma.FirmwareUpgradeJobGetPayload<{
  include: typeof FIRMWARE_INCLUDE
}>

export function toFirmwareJobRow(j: FirmwareJobWithDevice): FirmwareJobRow {
  return {
    id: j.id,
    deviceId: j.deviceId,
    deviceHostname: j.device?.hostname ?? '',
    deviceType: j.device?.type ?? 'UNKNOWN',
    deviceFirmware: j.device?.firmwareVersion ?? '', // "" = n.d. (label in UI)
    targetFirmware: j.targetFirmware,
    executor: j.executor as FirmwareJobRow['executor'],
    scheduledAt: j.scheduledAt.getTime(),
    confirmMinutes: j.confirmMinutes,
    status: j.status,
    output: j.output,
    error: j.error,
    requestedBy: j.requestedById,
    createdAt: j.createdAt.getTime(),
    updatedAt: j.updatedAt.getTime(),
  }
}

/* ---------------- Playbook → PlaybookRow ---------------- */

/** Include steps ordinate per stepOrder (colonna «order» del modello
 *  v15; il contratto la espone come stepOrder). */
export const PLAYBOOK_INCLUDE = {
  steps: { orderBy: { order: 'asc' } },
} as const

export type PlaybookWithSteps = Prisma.PlaybookGetPayload<{
  include: typeof PLAYBOOK_INCLUDE
}>

/** Mappatura dichiarata fra il vocabolario del contratto W3.5 e le
 *  colonne del modello v15: step.name → PlaybookStep.description
 *  (il modello non ha una colonna name per il passo), step.action →
 *  actionType, params resta JSON grezzo ("" = nessuno). */
export function toPlaybookRow(p: PlaybookWithSteps): PlaybookRow {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    triggerRule: p.triggerRule,
    enabled: p.enabled,
    runCount: p.runCount, // 0 onesto: nessuna esecuzione in replay
    lastRunAt: p.lastRunAt?.getTime() ?? null,
    createdBy: p.createdBy,
    steps: p.steps.map((s) => ({
      id: s.id,
      stepOrder: s.order,
      name: s.description,
      action: s.actionType,
      params: s.params,
    })),
    createdAt: p.createdAt.getTime(),
    updatedAt: p.updatedAt.getTime(),
  }
}

/* ---------------- AutomationTask → AutomationTaskRow ---------------- */

export function toAutomationTaskRow(
  t: {
    id: string; name: string; description: string; targetsJson: string; category: string
    commandsJson: string; executor: string; intervalSec: number; confirmMinutes: number
    enabled: boolean; guardrailMaxDevices: number; runCount: number
    lastRunAt: Date | null; lastError: string; createdAt: Date; updatedAt: Date
  },
  hostnames: Map<string, string>,
): AutomationTaskRow {
  const ids = parseJsonStringArray(t.targetsJson)
  const shown = ids
    .map((id) => hostnames.get(id))
    .filter((h): h is string => h != null)
    .slice(0, 20) // cap dichiarato nel contratto (primi 20)
  return {
    id: t.id,
    name: t.name,
    description: t.description,
    targetCount: ids.length,
    targetHostnames: shown,
    category: t.category,
    commands: parseJsonStringArray(t.commandsJson),
    executor: t.executor as AutomationTaskRow['executor'],
    intervalSec: t.intervalSec,
    confirmMinutes: t.confirmMinutes,
    enabled: t.enabled,
    guardrailMaxDevices: t.guardrailMaxDevices,
    runCount: t.runCount, // 0 onesto: mai eseguito in replay
    lastRunAt: t.lastRunAt?.getTime() ?? null,
    lastError: t.lastError,
    createdAt: t.createdAt.getTime(),
    updatedAt: t.updatedAt.getTime(),
  }
}
