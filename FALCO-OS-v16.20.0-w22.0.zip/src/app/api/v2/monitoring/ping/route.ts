/* ================================================================
 * /api/v2/monitoring/ping — POST (v16.18 W19)
 * ================================================================
 * Il «poller» della modalità ping-only (telecamere): «se è una
 * telecamera non mi interessa avere i valori, ma solo ping se è
 * stato online e offline» (decisione operatore 31/10/2026).
 *
 * COSA FA:
 *   · seleziona i dispositivi del plant in monitorMode='ping'
 *     (o UNO per deviceId) — dismessi esclusi;
 *   · chiede la sonda di PRESENZA del mini-service :3002 (ping
 *     TCP-adattivo sulla porta di gestione, v16.8: due passate);
 *   · scrive i CAMPIONI reali: pingLatency (ms) e packetLoss (0/100)
 *     → la storia online/offline vive nelle MetricValue, che
 *     alimentano già Report → disponibilità e la scheda apparato;
 *   · aggiorna lo stato del dispositivo con onestà: ONLINE con
 *     lastSeenAt, OFFLINE con disconnectedSince (se non già segnato);
 *   · audit MONITOR_PING_SWEEP con la sola sintesi.
 *
 * ONESTÀ (il contratto di sempre):
 *   · un apparato muto resta muto: alive=false, loss=100, OFFLINE —
 *     NESSUN dato inventato;
 *   · «ping» qui è la sonda TCP-adattiva di v16.8 (porte standard +
 *     porta di gestione dell'apparato): in ambiente sandbox raggiunge
 *     la rete del server demo, in produzione l'impianto;
 *   · RBAC: TECNICO+ (è un'azione di monitoraggio attiva).
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { PingSweepInputSchema, PingSweepResultSchema, type PingSweepResult } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Cap difensivo: la sonda del servizio accetta fino a 64 target. */
const SWEEP_CAP = 64

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo un tecnico può lanciare la spazzata ping', 403)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  let raw: unknown = {}
  try {
    const text = await req.text()
    if (text.trim() !== '') raw = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = PingSweepInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri della spazzata non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Selezione ONETA: ping-mode del plant (o il singolo richiesto).
   * Un deviceId fuori plant → NOT_FOUND (perimetro impianto intatto). */
  const devices = input.deviceId
    ? await db.device.findMany({
        where: { id: input.deviceId, plantId: p.id, decommissionedAt: null, monitorMode: 'ping' },
        select: { id: true, hostname: true, ip: true, port: true, status: true },
      })
    : await db.device.findMany({
        where: { plantId: p.id, decommissionedAt: null, monitorMode: 'ping' },
        select: { id: true, hostname: true, ip: true, port: true, status: true },
        orderBy: { hostname: 'asc' },
        take: SWEEP_CAP,
      })

  if (input.deviceId && devices.length === 0) {
    /* Onestà: o non esiste, o non è di questo impianto, o non è in
     * modalità ping — la risposta distingue i due casi reali. */
    const any = await db.device.findFirst({ where: { id: input.deviceId, plantId: p.id }, select: { monitorMode: true, decommissionedAt: true } })
    if (!any) return fail('NOT_FOUND', 'Dispositivo non trovato nell\'impianto attivo', 404)
    if (any.decommissionedAt) return fail('DECOMMISSIONED', 'Dispositivo dismesso: escluso dal monitoraggio', 422)
    return fail('NOT_PING_MODE', 'Il dispositivo non è in modalità ping (monitorMode=full): dichiararlo dalla finestra di attivazione SNMP', 422)
  }

  if (devices.length === 0) {
    /* Nessuno in modalità ping: lista vuota onesta (non è un errore). */
    const data: PingSweepResult = { swept: 0, alive: 0, durationMs: 0, results: [] }
    const replay = await getReplayState()
    return ok(data, Date.now(), apiMode(replay))
  }

  const pr = await discoveryPost('/probe/ping', {
    targets: devices.map((d) => ({ ip: d.ip, port: d.port })),
    timeoutMs: 1500,
  }, { timeoutMs: 25_000 })
  if (!pr.ok) return proxyFail(pr)

  const swept = (pr.body as { result?: { results?: Array<{ ip: string; alive: boolean; latencyMs: number; openPorts: number[]; secondPass?: boolean }>; durationMs?: number } }).result
  if (!swept || !Array.isArray(swept.results)) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza i risultati della sonda' } } })
  }

  const byIp = new Map<string, { alive: boolean; latencyMs: number }>()
  for (const r of swept.results) byIp.set(r.ip, { alive: r.alive, latencyMs: r.latencyMs })

  const now = new Date()
  const results: PingSweepResult['results'] = []
  let aliveCount = 0

  for (const d of devices) {
    const r = byIp.get(d.ip) ?? { alive: false, latencyMs: 0 } // difensivo: assente = muto
    const dbStatus = d.status
    let newStatus = dbStatus

    if (r.alive) {
      aliveCount++
      newStatus = 'ONLINE'
      /* Campioni REALI: latenza e perdita 0 (risposta arrivata). */
      await db.metricValue.createMany({
        data: [
          { deviceId: d.id, plantId: p.id, metric: 'pingLatency', value: r.latencyMs, unit: 'ms', timestamp: now },
          { deviceId: d.id, plantId: p.id, metric: 'packetLoss', value: 0, unit: '%', timestamp: now },
        ],
      }).catch(() => { /* il campione è best-effort: lo stato conta di più */ })
      await db.device.update({
        where: { id: d.id },
        data: {
          status: 'ONLINE',
          falcoState: 'online',
          lastSeenAt: now,
          ...(dbStatus === 'OFFLINE' || d.status === 'OFFLINE' ? { disconnectedSince: null } : {}),
        },
      }).catch(() => { /* difensivo */ })
    } else {
      newStatus = 'OFFLINE'
      /* Campione REALE: perdita 100% (nessuna risposta). */
      await db.metricValue.create({
        data: { deviceId: d.id, plantId: p.id, metric: 'packetLoss', value: 100, unit: '%', timestamp: now },
      }).catch(() => { /* best-effort */ })
      await db.device.update({
        where: { id: d.id },
        data: {
          status: 'OFFLINE',
          falcoState: 'disconnesso',
          ...(dbStatus !== 'OFFLINE' ? { disconnectedSince: now } : {}),
        },
      }).catch(() => { /* difensivo */ })
    }

    results.push({
      deviceId: d.id,
      hostname: d.hostname,
      ip: d.ip,
      port: d.port,
      alive: r.alive,
      latencyMs: r.alive ? r.latencyMs : null,
      dbStatus,
      newStatus,
      samplesWritten: r.alive ? 2 : 1,
    })
  }

  await db.auditLog.create({
    data: {
      action: 'MONITOR_PING_SWEEP',
      actor: session.session.user.email ?? 'sconosciuto',
      plantId: p.id,
      targetId: null,
      targetLabel: `spazzata ping ${results.length} apparati`,
      details: JSON.stringify({
        plantId: p.id,
        swept: results.length,
        alive: aliveCount,
        durationMs: swept.durationMs ?? 0,
        single: input.deviceId ?? null,
      }),
    },
  }).catch(() => { /* audit best-effort: i campioni sono già scritti */ })

  const data: PingSweepResult = {
    swept: results.length,
    alive: aliveCount,
    durationMs: swept.durationMs ?? 0,
    results,
  }
  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(PingSweepResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
