/* ================================================================
 * /api/v2/speed-tests — GET (storico+statistiche) + POST (run)
 * 16.9.0 W4 — port fedele da v11.9 G6 (lib/network/speedtest.ts).
 * Concetto GroundControl: lancia iperf3 e persistisce banda/
 * retransmit/jitter/loss. PARTE PURA: parse dell'output JSON di
 * iperf3 (--json). ESECUTORE: spawn con runner iniettabile; binario
 * assente → 501 ONESTO (nessuna riga scritta, mai fingere un test).
 * Executor SIMULATED dichiarato per demo/E2E: riga MARCATA, misure
 * a zero, mai spacciata per reale (onestà sulle misure).
 *  · GET: storico per deviceId (o tutto l'impianto), take 200,
 *    statistiche REALI vs SIMULATE separate (v15: solo i test ok con
 *    executor IPERF3 entrano nelle medie);
 *  · POST (role ≥ RESPONSABILE_COMUNE): IPERF3 → 201 con risultato
 *    reale | 501 EXECUTOR_DOWN | 502 con esito fallito registrato;
 *    SIMULATED → 201 marcato.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { spawn } from 'child_process'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { SpeedTestsQuerySchema, SpeedTestsPageSchema, SpeedTestRunInputSchema, SpeedTestRunResultSchema, SpeedTestRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/* ---------------- Parte pura (port v15 speedtest.ts) ---------------- */

export interface SpeedTestResult {
  ok: boolean
  bandwidthMbps: number
  retransmits: number
  jitterMs: number
  lossPercent: number
  error: string
  raw: string
}

/** Parse PURO dell'output JSON iperf3 (end.sum per TCP; sum/sum_received per reverse). */
export function parseIperfJson(raw: string): SpeedTestResult {
  const base: SpeedTestResult = { ok: false, bandwidthMbps: 0, retransmits: 0, jitterMs: 0, lossPercent: 0, error: '', raw: raw.slice(0, 10_000) }
  let json: Record<string, unknown>
  try {
    json = JSON.parse(raw) as Record<string, unknown>
  } catch {
    return { ...base, error: 'output iperf3 non JSON' }
  }
  const err = typeof json.error === 'string' ? json.error : ''
  const end = json.end as Record<string, unknown> | undefined
  if (err || !end) {
    return { ...base, error: err || 'sezione "end" assente' }
  }
  const sumSent = end.sum_sent as Record<string, unknown> | undefined
  const sum = (end.sum as Record<string, unknown> | undefined)
    ?? (end.sum_received as Record<string, unknown> | undefined)
    ?? sumSent
  if (!sum) return { ...base, error: 'sezione "sum" assente' }
  const bps = Number(sum.bits_per_second ?? 0)
  const retransmits = Number(sum.retransmits ?? sumSent?.retransmits ?? 0)
  const jitterMs = Number(sum.jitter_ms ?? 0)
  const lost = Number(sum.lost ?? 0)
  const packets = Number(sum.packets ?? 0)
  const lossPercent = packets > 0 ? (lost / packets) * 100 : 0
  return {
    ok: true,
    bandwidthMbps: Math.round((bps / 1_000_000) * 100) / 100,
    retransmits: Number.isFinite(retransmits) ? retransmits : 0,
    jitterMs: Number.isFinite(jitterMs) ? Math.round(jitterMs * 100) / 100 : 0,
    lossPercent: Math.round(lossPercent * 100) / 100,
    error: '',
    raw: raw.slice(0, 10_000),
  }
}

/** Costruisce gli argomenti iperf3 (PURO, testabile). */
export function iperfArgs(opts: { host: string; port: number; durationSec: number; mode: 'TCP' | 'UDP'; direction: 'UP' | 'DOWN' }): string[] {
  const args = ['-c', opts.host, '-p', String(opts.port), '-t', String(opts.durationSec), '-J']
  if (opts.mode === 'UDP') args.push('-u', '-b', '0')
  if (opts.direction === 'DOWN') args.push('-R')
  return args
}

type CommandRunner = (cmd: string, args: string[], timeoutMs: number) => Promise<{ code: number; stdout: string; stderr: string }>

export const spawnRunner: CommandRunner = (cmd, args, timeoutMs) => new Promise((resolve) => {
  const child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] })
  let stdout = ''
  let stderr = ''
  const timer = setTimeout(() => {
    child.kill('SIGKILL')
    resolve({ code: 124, stdout, stderr: `${stderr}\n[timeout dopo ${timeoutMs}ms]` })
  }, timeoutMs)
  child.stdout?.on('data', (d: Buffer) => { stdout += String(d) })
  child.stderr?.on('data', (d: Buffer) => { stderr += String(d) })
  child.on('error', (err: Error) => {
    clearTimeout(timer)
    resolve({ code: 127, stdout, stderr: err.message })
  })
  child.on('close', (code: number | null) => {
    clearTimeout(timer)
    resolve({ code: code ?? 1, stdout, stderr })
  })
})

/** Statistiche storiche (media/max banda sui test ok REALI soltanto). */
function speedStats(tests: Array<{ ok: boolean; executor: string; bandwidthMbps: number; createdAt: Date }>) {
  const real = tests.filter((t) => t.ok && t.executor === 'IPERF3')
  const avg = real.length > 0 ? real.reduce((s, t) => s + t.bandwidthMbps, 0) / real.length : 0
  return {
    total: tests.length,
    real: real.length,
    simulated: tests.filter((t) => t.executor === 'SIMULATED').length,
    avgMbps: Math.round(avg * 100) / 100,
    maxMbps: real.reduce((m, t) => Math.max(m, t.bandwidthMbps), 0),
    lastRealAt: real.length > 0 ? real[0].createdAt.getTime() : null,
  }
}

/* ---------------- GET: storico + statistiche ---------------- */

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(SpeedTestsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const tests = await db.speedTest.findMany({
    where: q.value.deviceId ? { deviceId: q.value.deviceId } : {},
    include: { device: { select: { hostname: true, ip: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })

  const data = {
    tests: tests.map((t) => ({
      id: t.id,
      deviceId: t.deviceId,
      deviceHostname: t.device.hostname,
      deviceIp: t.device.ip,
      mode: t.mode,
      direction: t.direction,
      host: t.host,
      port: t.port,
      durationSec: t.durationSec,
      executor: t.executor,
      ok: t.ok,
      bandwidthMbps: t.bandwidthMbps,
      retransmits: t.retransmits,
      jitterMs: t.jitterMs,
      lossPercent: t.lossPercent,
      error: t.error,
      createdAt: t.createdAt.getTime(),
    })),
    stats: speedStats(tests.map((t) => ({ ok: t.ok, executor: t.executor, bandwidthMbps: t.bandwidthMbps, createdAt: t.createdAt }))),
  }
  const asOf = maxOf(...tests.map((t) => t.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(SpeedTestsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ---------------- POST: esecuzione ---------------- */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'RESPONSABILE_COMUNE')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo RESPONSABILE_COMUNE o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = SpeedTestRunInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const device = await db.device.findUnique({ where: { id: input.deviceId } })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)
  const host = input.host || device.ip
  if (!host) return fail('BAD_BODY', 'host richiesto (il dispositivo non ha IP)', 422)
  const durationSec = Math.min(Math.max(input.durationSec, 1), 60)

  const email = session.session.user.email ?? 'sconosciuto'
  const userId = session.session.user.id ?? email
  let result: SpeedTestResult

  if (input.executor === 'SIMULATED') {
    /* SIMULATO onesto: mai spacciato per misura reale */
    result = {
      ok: true, bandwidthMbps: 0, retransmits: 0, jitterMs: 0, lossPercent: 0, error: '',
      raw: `[FALCO SIMULATO] speed test NON eseguito verso ${host} (executor=SIMULATED)`,
    }
  } else {
    const args = iperfArgs({ host, port: input.port, durationSec, mode: input.mode, direction: input.direction })
    const proc = await spawnRunner('iperf3', args, (durationSec + 15) * 1000)
    if (proc.code === 127) {
      /* binario assente → 501 ONESTO, NESSUNA riga scritta */
      const message = `iperf3 non disponibile sul server: ${proc.stderr.trim() || 'binario assente'}`
      await db.auditLog.create({
        data: {
          action: 'SPEED_TEST_RUN',
          actor: email,
          targetId: device.id,
          targetLabel: device.hostname,
          details: JSON.stringify({
            deviceId: input.deviceId, host, executor: 'IPERF3', ok: false,
            error: 'EXECUTOR_DOWN', note: message,
          }),
        },
      })
      return fail('EXECUTOR_DOWN', message, 501)
    }
    result = parseIperfJson(proc.stdout || proc.stderr)
    if (proc.code !== 0 && !result.ok) {
      result.error = proc.stderr.trim().slice(0, 300) || result.error
    }
  }

  const test = await db.$transaction(async (tx) => {
    const t = await tx.speedTest.create({
      data: {
        deviceId: input.deviceId,
        mode: input.mode,
        direction: input.direction,
        host,
        port: input.port,
        durationSec,
        executor: input.executor,
        ok: result.ok,
        bandwidthMbps: result.bandwidthMbps,
        retransmits: result.retransmits,
        jitterMs: result.jitterMs,
        lossPercent: result.lossPercent,
        error: result.error.slice(0, 500),
        output: result.raw,
        ranById: userId,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'SPEED_TEST_RUN',
        actor: email,
        targetId: t.id,
        targetLabel: `${device.hostname} → ${host}`,
        details: JSON.stringify({
          deviceId: input.deviceId, host, mode: input.mode,
          direction: input.direction, executor: input.executor,
          ok: result.ok, bandwidthMbps: result.bandwidthMbps,
          error: result.error.slice(0, 200),
        }),
      },
    })
    return t
  })

  /* 201 con esito onesto nel payload: il test SIMULATO o il test reale
   * REGISTRATO (anche fallito — la riga esiste, ok:false dichiarato). */
  const data = {
    testId: test.id,
    ok: result.ok,
    executor: input.executor,
    bandwidthMbps: result.bandwidthMbps,
    retransmits: result.retransmits,
    jitterMs: result.jitterMs,
    lossPercent: result.lossPercent,
    error: result.error,
  }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(SpeedTestRunResultSchema, { ok: true as const, asOf: test.createdAt.getTime(), mode, data })
  return NextResponse.json({ ok: true as const, asOf: test.createdAt.getTime(), mode, data }, { status: 201 })
}
