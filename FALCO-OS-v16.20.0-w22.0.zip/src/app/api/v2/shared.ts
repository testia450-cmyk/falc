/* ================================================================
 * FALCO-OS v16 — API v2 · helper condivisi tra le rotte
 * File NON-route (Next ignora i file che non si chiamano route.ts):
 * qui vivono solo utility di composizione riusate da più endpoint.
 * Nessuna logica di dominio NUOVA: tutto delega ai motori portati
 * (tiers/reachability/link-rules/radio) e ai derive di src/lib/v2.
 * ================================================================ */

import type { NextResponse } from 'next/server'
import type { ZodType } from 'zod'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { fail } from '@/lib/v2/api-helpers'
import {
  getPlant, computeWeakLinks, stationSignalsOf,
  type PlantLite, type WeakLinkRow,
} from '@/lib/v2/derive'
import type { DeviceRow, TicketRow, MaintenanceRow, DeviceGroupRow, GroupRule } from '@/lib/v2/contracts'
import { DEVICE_GROUP_MEMBERS_CAP, GroupRuleSchema } from '@/lib/v2/contracts'
import { computeNetworkTiers, type NetworkTiers, type TierEdgeInput } from '@/lib/domain/tiers'
import { computeReachability, type ReachabilityMap } from '@/lib/domain/reachability'
import { MANUAL_LINK_SOTS, TIER_ATTACH_COST } from '@/lib/domain/link-rules'
import { computeSignalScore, uplinkSignalDbm } from '@/lib/domain/radio'

/* ---------------- Validazione contratto (solo dev) ---------------- */

/** In produzione zero costo; in dev garantisce che ogni risposta
 *  rispetti LO schema zod del contratto (regola §8). */
export function devValidate<T>(schema: ZodType<T>, payload: unknown): void {
  if (process.env.NODE_ENV === 'production') return
  schema.parse(payload)
}

/* ---------------- Costanti documentate ---------------- */

/** Famiglie di dispositivi (documentate nel piano §7): la STESSA
 *  definizione è usata da /devices, /cameras, /noc/summary e
 *  /locations per coerenza tra endpoint. */
export const FAMILY_TYPES: Record<'network' | 'radio' | 'cameras', string[]> = {
  network: ['SWITCH', 'GATEWAY', 'ROUTER', 'SERVER'],
  radio: ['AP', 'STA'],
  cameras: ['CAMERA', 'LPR', 'NVR'], // «apparati video»: telecamere + registratori
}
export const VIDEO_TYPES = FAMILY_TYPES.cameras

/** Rango di severità allarmi (ordine di gravità, per l'ordinamento). */
export const SEVERITY_RANK: Record<string, number> = {
  INFO: 1, WARNING: 2, AVERAGE: 3, HIGH: 4, CRITICAL: 5,
}

/** Gerarchia «worst» degli stati UI (mocks §3.3, definita QUI una volta
 *  sola e documentata): OFFLINE > DEGRADED > UNKNOWN > NOT_MONITORED >
 *  MAINTENANCE > ONLINE. MAINTENANCE è uno stato INTENZIONALE (non un
 *  guasto): peggiore di ONLINE ma migliore di UNKNOWN/NOT_MONITORED.
 *  Usata da /locations (worstStatus) e dall'ordinamento per stato. */
export const UI_WORST_ORDER = [
  'OFFLINE', 'DEGRADED', 'UNKNOWN', 'NOT_MONITORED', 'MAINTENANCE', 'ONLINE',
] as const
export function uiWorstRank(status: string): number {
  const i = (UI_WORST_ORDER as readonly string[]).indexOf(status)
  return i === -1 ? 99 : i
}

/* ---------------- Utility piccole ---------------- */

export function maxOf(...vals: Array<number | null | undefined>): number {
  let m = 0
  for (const v of vals) if (typeof v === 'number' && v > m) m = v
  return m
}

/** Maschera le credenziali in uno URL rtsp://user:pass@host/… →
 *  rtsp://***:***@host/… (il DB reale non le contiene: mascherato
 *  comunque, difesa in profondità — regola «nessun segreto in risposta»). */
export function maskRtsp(url: string): string {
  if (!url || !url.includes('@')) return url
  return url.replace(/:\/\/[^@/]+@/, '://***:***@')
}

/** Risolve l'impianto dalla query (default: il primo) o 404 in italiano. */
export async function resolvePlant(
  plantId?: string,
): Promise<{ ok: true; plant: PlantLite } | { ok: false; response: NextResponse }> {
  const plant = await getPlant(plantId)
  if (!plant) return { ok: false, response: fail('NOT_FOUND', 'Impianto non trovato', 404) }
  return { ok: true, plant }
}

/* ---------------- Caricamento collegamenti impianto ---------------- */

export interface PlantLinkRow {
  id: string
  sourceDeviceId: string | null
  targetDeviceId: string | null
  sourceLabel: string
  targetLabel: string
  linkType: string
  linkStatus: string
  confidence: string
  evidence: string
  sourceOfTruth: string
  confirmed: boolean
  speedMbps: number
  trafficInMbps: number
  trafficOutMbps: number
  trafficUpdatedAt: Date | null
  label: string
}

export const LINK_COLUMNS = {
  id: true, sourceDeviceId: true, targetDeviceId: true, sourceLabel: true, targetLabel: true,
  linkType: true, linkStatus: true, confidence: true, evidence: true, sourceOfTruth: true,
  confirmed: true, speedMbps: true, trafficInMbps: true, trafficOutMbps: true,
  trafficUpdatedAt: true, label: true,
} as const

export async function getPlantLinks(plantId: string): Promise<PlantLinkRow[]> {
  return db.topologyLink.findMany({
    where: { plantId },
    select: LINK_COLUMNS,
  }) as unknown as Promise<PlantLinkRow[]>
}

/** TierEdgeInput da ogni link (task §6.2): link con endpoint null o
 *  auto-referenziali scartati; manuale ⇔ SOT in MANUAL_LINK_SOTS o
 *  conferma del tecnico; evidenza solo se ha un costo di aggancio. */
export function toTierEdges(links: PlantLinkRow[]): TierEdgeInput[] {
  const out: TierEdgeInput[] = []
  for (const l of links) {
    if (!l.sourceDeviceId || !l.targetDeviceId) continue
    if (l.sourceDeviceId === l.targetDeviceId) continue
    out.push({
      aId: l.sourceDeviceId,
      bId: l.targetDeviceId,
      weight: 1,
      manual: MANUAL_LINK_SOTS.has(l.sourceOfTruth) || l.confirmed === true,
      ev: l.evidence && TIER_ATTACH_COST[l.evidence] !== undefined ? l.evidence : undefined,
    })
  }
  return out
}

/** Albero unico dell'impianto (un'unica logica: computeNetworkTiers). */
export function buildPlantTiers(
  rows: DeviceRow[],
  links: PlantLinkRow[],
  preferredRootId: string | null,
): NetworkTiers {
  return computeNetworkTiers(
    rows.map((r) => ({ id: r.id, type: r.type, ip: r.ip, hostname: r.hostname, model: r.model })),
    toTierEdges(links),
    { preferredRootId },
  )
}

/** Mappa di raggiungibilità sui soli link ATTIVI (BFS dai gateway). */
export function buildPlantReachability(rows: DeviceRow[], links: PlantLinkRow[]): ReachabilityMap {
  return computeReachability(
    rows.map((r) => ({ id: r.id, status: r.dbStatus, type: r.type })),
    links.map((l) => ({
      sourceDeviceId: l.sourceDeviceId,
      targetDeviceId: l.targetDeviceId,
      linkStatus: l.linkStatus,
    })),
  )
}

/* ---------------- Link radio deboli (STA + AP) ---------------- */

/** Link deboli dell'impianto: per le STA il segnale È il link di uplink
 *  (computeWeakLinks); per gli AP si espone la stazione figlia più
 *  debole (uplinkSignalDbm con stationSignalsOf dal grafo attivo).
 *  Per un AP «uplinkApHostname» è il parente a monte nell'ALBERO
 *  (non è ess stesso): scelta documentata, nessun dato inventato. */
export function computeWeakLinkRows(
  rows: DeviceRow[],
  tiers: NetworkTiers,
  reach: ReachabilityMap,
): WeakLinkRow[] {
  const byId = new Map(rows.map((r) => [r.id, r]))
  const staRows = computeWeakLinks(rows, { parentOf: tiers.parentOf, limit: rows.length })
  const apRows: WeakLinkRow[] = []
  for (const r of rows) {
    if (r.type !== 'AP') continue
    const signals = stationSignalsOf(r, rows, reach.children)
    const signal = uplinkSignalDbm({ type: 'AP', signalStrength: r.signalStrength, stationSignals: signals })
    if (signal == null) continue
    const parent = tiers.parentOf.get(r.id)
    const parentRow = parent ? byId.get(parent) : undefined
    const hs = computeSignalScore(signal)
    apRows.push({
      deviceId: r.id,
      hostname: r.hostname,
      ip: r.ip,
      type: r.type,
      uiStatus: r.uiStatus,
      signalDbm: signal,
      health: hs.label,
      score: hs.score,
      linkQuality: r.linkQuality,
      frequency: r.currentFrequency,
      ssid: r.ssid,
      uplinkApHostname: parentRow?.hostname ?? null,
      locationName: r.locationName,
      lastSeenAt: r.lastSeenAt,
    })
  }
  return [...staRows, ...apRows].sort((a, b) => a.signalDbm - b.signalDbm)
}

/* ---------------- MaintenanceWindow → riga contratto ---------------- */

/** Serializza una finestra di manutenzione nella riga del contratto
 *  (epoch ms; daysOfWeek è JSON "[1..7]" nel modello → array). Il parse
 *  dei giorni è difensivo (mai crash su JSON corrotto): stesso
 *  comportamento della GET /maintenance.
 *  16.3 additivo W3: terzo parametro OPZIONALE scopes (elenco gruppi
 *  con nome); assente → scopes: [] (retrocompatibile per le rotte
 *  16.2, lo schema MaintenanceRowSchema ora include scopes: []). */
export function parseDaysOfWeek(raw: string): number[] {
  try {
    const v: unknown = JSON.parse(raw || '[]')
    if (!Array.isArray(v)) return []
    return v.filter((n): n is number => typeof n === 'number' && Number.isInteger(n))
  } catch {
    return []
  }
}

export type WindowScope = { groupId: string; name: string }

export function toMaintenanceRow(
  w: {
    id: string; plantId: string; name: string; description: string
    type: string; scheduleType: string; daysOfWeek: string
    dayOfMonth: number; startTime: string; endTime: string
    activeSince: Date; activeUntil: Date | null; state: string
  },
  scopesCount: number,
  scopes?: WindowScope[],
): MaintenanceRow {
  return {
    id: w.id,
    plantId: w.plantId,
    name: w.name,
    description: w.description,
    type: w.type,
    scheduleType: w.scheduleType,
    daysOfWeek: parseDaysOfWeek(w.daysOfWeek),
    dayOfMonth: w.dayOfMonth,
    startTime: w.startTime,
    endTime: w.endTime,
    activeSince: w.activeSince.getTime(),
    activeUntil: w.activeUntil?.getTime() ?? null,
    state: w.state,
    scopesCount,
    scopes: scopes ?? [],
  }
}

/** Scope (gruppi) delle finestre indicate, con NOME del gruppo:
 *  query separata su MaintenanceWindowGroup → group {id, name} per le
 *  sole finestre caricate (mai su tutto lo storico). */
export async function loadWindowScopes(
  windowIds: string[],
): Promise<Map<string, WindowScope[]>> {
  const map = new Map<string, WindowScope[]>()
  for (const id of windowIds) map.set(id, [])
  if (windowIds.length === 0) return map
  const rows = await db.maintenanceWindowGroup.findMany({
    where: { windowId: { in: windowIds } },
    select: { windowId: true, groupId: true, group: { select: { name: true } } },
    orderBy: { groupId: 'asc' },
  })
  for (const r of rows) {
    map.get(r.windowId)?.push({ groupId: r.groupId, name: r.group.name })
  }
  return map
}

/** Gruppi REALI del plant per id indicati → mappa id→name (per la
 *  validazione degli scope: gli id mancanti sono gli offensori). */
export async function loadPlantGroupsByIds(
  plantId: string,
  ids: string[],
): Promise<Map<string, string>> {
  const map = new Map<string, string>()
  if (ids.length === 0) return map
  const rows = await db.deviceGroup.findMany({
    where: { id: { in: ids }, plantId },
    select: { id: true, name: true },
  })
  for (const r of rows) map.set(r.id, r.name)
  return map
}

/* ---------------- DeviceGroup → riga contratto (16.3 W3) ---------------- */

/** Include per DeviceGroupRow: membri con dispositivo (allowlist: mai
 *  colonne credenziali) e sede. Ordinamento per hostname in JS (la
 *  relazione to-many non è ordinabile per campo del dispositivo in
 *  Prisma in modo portabile). I membri sono significativi SOLO per i
 *  gruppi MANUAL: per i DYNAMIC la membership è calcolata da
 *  computeDynamicGroupMembers (ruleJson) e passata a toDeviceGroupRow. */
export const DEVICE_GROUP_INCLUDE = {
  members: {
    include: {
      device: {
        select: { id: true, hostname: true, type: true, location: { select: { name: true } } },
      },
    },
  },
} as const

/** Parse SICURO di ruleJson (campo grezzo del DB): restituisce la
 *  regola validata o null (MANUAL, JSON malformato o regola vuota —
 *  mai un'eccezione: un dato storico corrotto non deve rompere la
 *  lettura dell'elenco, la riga esce come MANUAL con rules null e
 *  la membership salvata, che per i MANUAL è l'autorità). */
export function parseGroupRule(ruleJson: string): GroupRule | null {
  if (!ruleJson || ruleJson.trim() === '' || ruleJson.trim() === '{}') return null
  try {
    const raw: unknown = JSON.parse(ruleJson)
    const parsed = GroupRuleSchema.safeParse(raw)
    return parsed.success ? parsed.data : null
  } catch {
    return null
  }
}

/** Membership di un gruppo DYNAMIC: dispositivi REALI dell'impianto
 *  (plantId diretto v16.12 W10 + decommissionedAt null) che
 *  soddisfano la regola (AND fra criteri, OR fra i valori). La
 *  membership NON è salvata da nessuna parte: è il risultato della
 *  regola sullo stato ATTUALE — ricalcolata a ogni chiamata. */
export async function computeDynamicGroupMembers(
  plantId: string,
  rules: GroupRule,
): Promise<{ members: DeviceGroupRow['members']; total: number }> {
  const where: Prisma.DeviceWhereInput = {
    plantId,
    decommissionedAt: null,
    ...(rules.deviceTypes ? { type: { in: Array.from(new Set(rules.deviceTypes)) } } : {}),
    ...(rules.statuses ? { status: { in: Array.from(new Set(rules.statuses)) } } : {}),
    ...(rules.connectionTypes ? { connectionType: { in: Array.from(new Set(rules.connectionTypes)) } } : {}),
    ...(rules.locationIds ? { locationId: { in: Array.from(new Set(rules.locationIds)) } } : {}),
  }
  const devices = await db.device.findMany({
    where,
    select: { id: true, hostname: true, type: true, location: { select: { name: true } } },
  })
  const sorted = [...devices].sort((a, b) => a.hostname.localeCompare(b.hostname, 'it'))
  return {
    members: sorted.slice(0, DEVICE_GROUP_MEMBERS_CAP).map((d) => ({
      id: d.id,
      hostname: d.hostname,
      type: d.type,
      locationName: d.location?.name ?? null,
    })),
    total: devices.length,
  }
}

/** Validazione dei valori di una regola DYNAMIC contro i dati REALI
 *  del plant: types/statuses/connectionTypes contro i valori DISTINTI
 *  dei dispositivi attivi, locationIds contro le sedi del plant.
 *  Restituisce gli offensori per criterio (per il 422 con dettagli):
 *  niente regole su valori fantasma — onestà del dato. */
export async function validateGroupRuleValues(
  plantId: string,
  rules: GroupRule,
): Promise<{
  unknownTypes: string[]
  unknownStatuses: string[]
  unknownConnectionTypes: string[]
  unknownLocationIds: string[]
}> {
  const [types, statuses, connectionTypes, locations] = await Promise.all([
    rules.deviceTypes
      ? db.device.findMany({
          where: { plantId, decommissionedAt: null },
          select: { type: true }, distinct: ['type'],
        }).then((rs) => new Set(rs.map((r) => r.type)))
      : Promise.resolve(new Set<string>()),
    rules.statuses
      ? db.device.findMany({
          where: { plantId, decommissionedAt: null },
          select: { status: true }, distinct: ['status'],
        }).then((rs) => new Set(rs.map((r) => r.status)))
      : Promise.resolve(new Set<string>()),
    rules.connectionTypes
      ? db.device.findMany({
          where: { plantId, decommissionedAt: null },
          select: { connectionType: true }, distinct: ['connectionType'],
        }).then((rs) => new Set(rs.map((r) => r.connectionType)))
      : Promise.resolve(new Set<string>()),
    rules.locationIds
      ? db.location.findMany({ where: { plantId }, select: { id: true } })
          .then((rs) => new Set(rs.map((r) => r.id)))
      : Promise.resolve(new Set<string>()),
  ])
  return {
    unknownTypes: (rules.deviceTypes ?? []).filter((v) => !types.has(v)),
    unknownStatuses: (rules.statuses ?? []).filter((v) => !statuses.has(v)),
    unknownConnectionTypes: (rules.connectionTypes ?? []).filter((v) => !connectionTypes.has(v)),
    unknownLocationIds: (rules.locationIds ?? []).filter((v) => !locations.has(v)),
  }
}

/** Serializza un gruppo nella riga del contratto. MANUAL: membri dalla
 *  relazione inclusa (memberCount = righe DeviceGroupMember). DYNAMIC:
 *  membri dal calcolo computeDynamicGroupMembers passato in `computed`
 *  (memberCount = totale calcolato ADESSO — cambia da lettura a
 *  lettura se i dispositivi cambiano stato/sede/tipo). Colore: dato
 *  operatore grezzo. */
export function toDeviceGroupRow(
  g: {
    id: string; name: string; description: string; color: string
    ruleType: string; ruleJson: string
    members: Array<{
      device: {
        id: string; hostname: string; type: string
        location: { name: string } | null
      }
    }>
  },
  computed?: { members: DeviceGroupRow['members']; total: number },
): DeviceGroupRow {
  const dynamic = g.ruleType === 'DYNAMIC'
  if (dynamic) {
    const rules = parseGroupRule(g.ruleJson)
    const members = computed ?? { members: [], total: 0 } // defensivo: il chiamante DEVE passare il calcolo
    return {
      id: g.id,
      name: g.name,
      description: g.description,
      color: g.color,
      ruleType: 'DYNAMIC',
      rules,
      memberCount: members.total,
      members: members.members,
    }
  }
  const sorted = [...g.members].sort((a, b) =>
    a.device.hostname.localeCompare(b.device.hostname, 'it'))
  const shown = sorted.slice(0, DEVICE_GROUP_MEMBERS_CAP)
  return {
    id: g.id,
    name: g.name,
    description: g.description,
    color: g.color,
    ruleType: 'MANUAL',
    rules: null,
    memberCount: g.members.length,
    members: shown.map((m) => ({
      id: m.device.id,
      hostname: m.device.hostname,
      type: m.device.type,
      locationName: m.device.location?.name ?? null,
    })),
  }
}

/** Validazione deviceIds per la membership dei gruppi: restituisce gli
 *  id OFFENSORI (inesistenti, dismessi o di ALTRO impianto).
 *  Scope v16.12 W10: plantId diretto + decommissionedAt null —
 *  un dispositivo di un altro impianto NON è selezionabile. */
export async function offendingDeviceIds(
  plantId: string,
  ids: string[],
): Promise<string[]> {
  if (ids.length === 0) return []
  const found = await db.device.findMany({
    where: {
      id: { in: ids },
      plantId,
      decommissionedAt: null,
    },
    select: { id: true },
  })
  const foundSet = new Set(found.map((f) => f.id))
  return ids.filter((id) => !foundSet.has(id))
}

/* ---------------- Ticket → riga contratto (riuso 3 route) ---------------- */

/** Include minimo per TicketRow: device (SOLO se deviceId) e location.
 *  Nessuna colonna credenziale (username/password/rtspStream mai toccate). */
export const TICKET_INCLUDE = {
  device: { select: { id: true, hostname: true, ip: true } },
  location: { select: { name: true } },
} as const

export type TicketWithRefs = Prisma.TicketGetPayload<{ include: typeof TICKET_INCLUDE }>

/** Serializza un ticket del DB nella riga del contratto (epoch ms).
 *  rootCause/resolution sono campi REALI del modello ("" = assente). */
export function toTicketRow(
  t: TicketWithRefs,
  counts: { interventions: number; comments: number },
): TicketRow {
  return {
    id: t.id,
    title: t.title,
    description: t.description,
    status: t.status,
    priority: t.priority,
    source: t.source,
    plantId: t.plantId,
    device: t.device ? { id: t.device.id, hostname: t.device.hostname, ip: t.device.ip } : null,
    locationName: t.location?.name ?? null,
    assignedTo: t.assignedTo,
    rootCause: t.rootCause,
    resolution: t.resolution,
    createdAt: t.createdAt.getTime(),
    updatedAt: t.updatedAt.getTime(),
    resolvedAt: t.resolvedAt?.getTime() ?? null,
    closedAt: t.closedAt?.getTime() ?? null,
    slaResolutionDueAt: t.slaResolutionDueAt?.getTime() ?? null,
    escalationLevel: t.escalationLevel,
    interventionsCount: counts.interventions,
    commentsCount: counts.comments,
  }
}

/** Conteggi interventi e commenti per i ticket indicati (groupBy sui
 *  soli id richiesti: mai conteggi su tutto lo storico). */
export async function ticketCountsMap(
  ids: string[],
): Promise<Map<string, { interventions: number; comments: number }>> {
  const map = new Map<string, { interventions: number; comments: number }>()
  if (ids.length === 0) return map
  for (const id of ids) map.set(id, { interventions: 0, comments: 0 })
  const [intGroups, comGroups] = await Promise.all([
    db.intervention.groupBy({ by: ['ticketId'], _count: { _all: true }, where: { ticketId: { in: ids } } }),
    db.ticketComment.groupBy({ by: ['ticketId'], _count: { _all: true }, where: { ticketId: { in: ids } } }),
  ])
  for (const g of intGroups) {
    if (g.ticketId == null) continue // relazione opzionale: il where già esclude null
    map.get(g.ticketId)!.interventions = g._count._all
  }
  for (const g of comGroups) {
    if (g.ticketId == null) continue
    map.get(g.ticketId)!.comments = g._count._all
  }
  return map
}
