/* ================================================================
 * /api/v2/plants/[id] — PATCH (modifica) + DELETE — 16.10.0 W8
 *
 * PATCH (role ≥ RESPONSABILE_COMUNE, parità v15):
 *   · whitelist campi gestibili (nome, comune, indirizzo, note,
 *     telegram, mappa centro/zoom, ping, timer interruzione,
 *     community SNMP, isActive);
 *   · topologyRootDeviceId (v11.27): la radice SCELTA dall'operatore
 *     batte ogni euristica sui nomi location. Il dispositivo deve
 *     appartenere ALL'IMPIANTO (404 altrimenti); null esplicito =
 *     torna all'inferenza automatica;
 *   · 422 NO_CHANGES se il payload non cambia nulla;
 *   · audit PLANT_UPDATE con diff dei campi.
 *
 * DELETE (SUPER_ADMIN only — guardia più stretta della v15 perché
 * l'atto è distruttivo e irreversibile):
 *   · 404 se l'impianto non esiste;
 *   · 409 PLANT_NOT_EMPTY se contiene dati REALI (sedi, dispositivi,
 *     collegamenti, ticket, finestre manutenzione, KB): l'impianto
 *     «egidio» con 200 dispositivi NON è cancellabile per errore;
 *   · audit PLANT_DELETE.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdatePlantInputSchema, PlantRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'RESPONSABILE_COMUNE')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo RESPONSABILE_COMUNE o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.plant.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = UpdatePlantInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* --- radice topologica: il dispositivo deve stare nell'impianto --- */
  if (input.topologyRootDeviceId) {
    const root = await db.device.findFirst({
      where: { id: input.topologyRootDeviceId, plantId: id }, // v16.12 W10: proprietà diretta
      select: { id: true, hostname: true },
    })
    if (!root) {
      return fail('NOT_FOUND', 'Radice non valida: il dispositivo non esiste o non appartiene a questo impianto', 404)
    }
  }

  /* --- diff onesto (audit) --- */
  const diff: Record<string, { from: unknown; to: unknown }> = {}
  const scalar: Array<[string, unknown]> = [
    ['name', input.name], ['comune', input.comune], ['address', input.address],
    ['notes', input.notes], ['telegramChatId', input.telegramChatId],
    ['mapCenterLat', input.mapCenterLat], ['mapCenterLng', input.mapCenterLng],
    ['mapZoom', input.mapZoom], ['pingIntervalSec', input.pingIntervalSec],
    ['outageTimerMinutes', input.outageTimerMinutes],
    ['snmpCommunities', input.snmpCommunities], ['isActive', input.isActive],
    ['topologyRootDeviceId', input.topologyRootDeviceId],
  ]
  for (const [k, v] of scalar) {
    if (v === undefined) continue
    const from = (existing as unknown as Record<string, unknown>)[k]
    if (from !== v) diff[k] = { from, to: v }
  }
  if (Object.keys(diff).length === 0) {
    return fail('NO_CHANGES', 'Nessuna modifica effettiva nel payload', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const updated = await db.$transaction(async (tx) => {
    const plant = await tx.plant.update({
      where: { id },
      data: {
        ...(input.name !== undefined && input.name !== existing.name ? { name: input.name } : {}),
        ...(input.comune !== undefined && input.comune !== existing.comune ? { comune: input.comune } : {}),
        ...(input.address !== undefined && input.address !== existing.address ? { address: input.address } : {}),
        ...(input.notes !== undefined && input.notes !== existing.notes ? { notes: input.notes } : {}),
        ...(input.telegramChatId !== undefined && input.telegramChatId !== existing.telegramChatId ? { telegramChatId: input.telegramChatId } : {}),
        ...(input.mapCenterLat !== undefined && input.mapCenterLat !== existing.mapCenterLat ? { mapCenterLat: input.mapCenterLat } : {}),
        ...(input.mapCenterLng !== undefined && input.mapCenterLng !== existing.mapCenterLng ? { mapCenterLng: input.mapCenterLng } : {}),
        ...(input.mapZoom !== undefined && input.mapZoom !== existing.mapZoom ? { mapZoom: input.mapZoom } : {}),
        ...(input.pingIntervalSec !== undefined && input.pingIntervalSec !== existing.pingIntervalSec ? { pingIntervalSec: input.pingIntervalSec } : {}),
        ...(input.outageTimerMinutes !== undefined && input.outageTimerMinutes !== existing.outageTimerMinutes ? { outageTimerMinutes: input.outageTimerMinutes } : {}),
        ...(input.snmpCommunities !== undefined && input.snmpCommunities !== existing.snmpCommunities ? { snmpCommunities: input.snmpCommunities } : {}),
        ...(input.isActive !== undefined && input.isActive !== existing.isActive ? { isActive: input.isActive } : {}),
        ...(input.topologyRootDeviceId !== undefined && input.topologyRootDeviceId !== existing.topologyRootDeviceId ? { topologyRootDeviceId: input.topologyRootDeviceId } : {}),
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'PLANT_UPDATE',
        actor: email,
        targetId: plant.id,
        targetLabel: plant.name,
        plantId: plant.id,
        details: JSON.stringify({ fields: Object.keys(diff), diff }),
      },
    })
    return plant
  })

  const rootHostname = updated.topologyRootDeviceId
    ? (await db.device.findUnique({ where: { id: updated.topologyRootDeviceId }, select: { hostname: true } }))?.hostname ?? null
    : null
  const [deviceCount, locationCount, ticketCount] = await Promise.all([
    db.device.count({ where: { plantId: id, decommissionedAt: null } }), // v16.12 W10: proprietà diretta
    db.location.count({ where: { plantId: id } }),
    db.ticket.count({ where: { plantId: id } }),
  ])
  const data = {
    id: updated.id,
    name: updated.name,
    comune: updated.comune,
    address: updated.address,
    notes: updated.notes,
    telegramChatId: updated.telegramChatId,
    kmzFile: updated.kmzFile,
    isActive: updated.isActive,
    mapCenterLat: updated.mapCenterLat,
    mapCenterLng: updated.mapCenterLng,
    mapZoom: updated.mapZoom,
    pingIntervalSec: updated.pingIntervalSec,
    outageTimerMinutes: updated.outageTimerMinutes,
    snmpCommunities: updated.snmpCommunities,
    topologyRootDeviceId: updated.topologyRootDeviceId ?? null,
    topologyRootHostname: rootHostname,
    deviceCount,
    locationCount,
    ticketCount,
    createdAt: updated.createdAt.getTime(),
  }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(PlantRowSchema, data)
  return ok(data, Date.now(), mode)
}

/* ================================================================ */

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Eliminare un impianto è irreversible: richiesto ruolo SUPER_ADMIN', 403)
  }

  const { id } = await ctx.params
  const existing = await db.plant.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* --- guardia onesta: un impianto con dati reali NON si elimina --- */
  const [locations, devices, links, tickets, maintenance, kb] = await Promise.all([
    db.location.count({ where: { plantId: id } }),
    db.device.count({ where: { plantId: id } }), // v16.12 W10: proprietà diretta (FK RESTRICT)
    db.topologyLink.count({ where: { plantId: id } }),
    db.ticket.count({ where: { plantId: id } }),
    db.maintenanceWindow.count({ where: { plantId: id } }),
    db.knowledgeBase.count({ where: { plantId: id } }),
  ])
  const occupied = locations + devices + links + tickets + maintenance + kb
  if (occupied > 0) {
    return fail(
      'PLANT_NOT_EMPTY',
      `Impianto non eliminabile: contiene dati reali (sedi ${locations}, dispositivi ${devices}, collegamenti ${links}, ticket ${tickets}, manutenzioni ${maintenance}, articoli KB ${kb}). Sposta o elimina i dati prima, oppure mantieni l'impianto disattivato (isActive=false).`,
      409,
    )
  }

  const email = session.session.user.email ?? 'sconosciuto'
  await db.$transaction(async (tx) => {
    // impianto vuoto: restano solo le assegnazioni utente e l'audit
    await tx.plantAssignment.deleteMany({ where: { plantId: id } })
    await tx.plant.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'PLANT_DELETE',
        actor: email,
        targetId: id,
        targetLabel: existing.name,
        plantId: '',
        details: JSON.stringify({ name: existing.name, comune: existing.comune, wasEmpty: true }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  const data = { deleted: true as const, id }
  return ok(data, Date.now(), mode)
}
