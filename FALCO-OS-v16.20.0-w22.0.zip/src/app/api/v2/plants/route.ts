/* ================================================================
 * /api/v2/plants — GET (elenco) + POST (creazione) — 16.10.0 W8
 *
 * GET (§6.1, «Quali impianti gestisco?») — riga estesa 16.10:
 *   · tutti i campi gestibili (comune, indirizzo, note, telegram,
 *     mappa, ping, timer interruzione, community SNMP, KMZ);
 *   · topologyRootDeviceId + hostname della radice scelta
 *     (null = inferenza automatica, v11.27);
 *   · conteggi REALI (dispositivi/sedi/ticket per impianto);
 *   · perimetro: chi non è SUPER_ADMIN vede SOLO gli impianti
 *     assegnati (PlantAssignment, parità v15) — l'admin li vede tutti.
 * Nessun campo credenziale selezionato.
 *
 * POST (16.10, parità v15 /api/plants): creare un impianto è un atto
 * amministrativo — richiede RESPONSABILE_COMUNE o superiore (v15
 * F-11). Campi con default v15 (mappa 41/14/zoom 14, ping 30 s,
 * timer interruzione 5 min). Audit PLANT_CREATE. In riproduzione il
 * nuovo impianto nasce VUOTO (nessun job/poller registrato: il
 * motore non gira — onestà D2 dichiarata nella risposta contratto).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { PlantsSchema, PlantsQuerySchema, CreatePlantInputSchema, PlantRowSchema } from '@/lib/v2/contracts'
import { listPlants, getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { hasRole } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(PlantsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const replay = await getReplayState()
  const isSuper = hasRole(session.session.user.role, 'SUPER_ADMIN')

  const [plants, counts, locations, tickets, lastWrite, assignments] = await Promise.all([
    listPlants(),
    db.device.groupBy({
      by: ['plantId'], // v16.12 W10: conteggio per impianto di PROPRIETÀ
      where: { decommissionedAt: null },
      _count: { _all: true },
    }),
    db.location.findMany({ select: { id: true, plantId: true } }),
    db.ticket.groupBy({ by: ['plantId'], _count: { _all: true } }),
    db.device.aggregate({ _max: { updatedAt: true } }),
    // perimetro v15: assegnazioni dell'utente (per non SUPER_ADMIN)
    isSuper ? Promise.resolve([]) : db.plantAssignment.findMany({
      where: { userId: session.session.user.id ?? '' },
      select: { plantId: true },
    }),
  ])

  /* v16.12 W10: conteggi per plantId DIRETTO — i dispositivi senza sede
   * (orfani) appartengono al loro impianto e contano per quello; prima
   * passavano da locationId e risultavano «fuori da ogni impianto». */
  const deviceCountByPlant = new Map<string, number>()
  for (const c of counts) {
    deviceCountByPlant.set(c.plantId, (deviceCountByPlant.get(c.plantId) ?? 0) + c._count._all)
  }
  const ticketCountByPlant = new Map<string, number>()
  for (const t of tickets) {
    ticketCountByPlant.set(t.plantId, (ticketCountByPlant.get(t.plantId) ?? 0) + t._count._all)
  }
  const locationCountByPlant = new Map<string, number>()
  for (const l of locations) {
    locationCountByPlant.set(l.plantId, (locationCountByPlant.get(l.plantId) ?? 0) + 1)
  }

  // perimetro: non SUPER_ADMIN → solo gli impianti assegnati;
  // ?plantId → solo quell'impianto (parità v15 GET /plants?plantId=)
  const allowed = new Set(assignments.map((a) => a.plantId))
  let visible = isSuper ? plants : plants.filter((p) => allowed.has(p.id))
  if (q.value.plantId) visible = visible.filter((p) => p.id === q.value.plantId)

  // hostname della radice scelta (una sola query sui dispositivi radice)
  const rootIds = visible.map((p) => p.topologyRootDeviceId).filter((v): v is string => v != null)
  const rootDevices = rootIds.length > 0
    ? await db.device.findMany({ where: { id: { in: rootIds } }, select: { id: true, hostname: true } })
    : []
  const rootHostname = new Map(rootDevices.map((d) => [d.id, d.hostname]))

  const data = visible.map((p) => ({
    id: p.id,
    name: p.name,
    comune: p.comune,
    address: p.address ?? '',
    notes: p.notes ?? '',
    telegramChatId: p.telegramChatId ?? '',
    kmzFile: p.kmzFile ?? '',
    isActive: p.isActive,
    mapCenterLat: p.mapCenterLat,
    mapCenterLng: p.mapCenterLng,
    mapZoom: p.mapZoom,
    pingIntervalSec: p.pingIntervalSec,
    outageTimerMinutes: p.outageTimerMinutes,
    snmpCommunities: p.snmpCommunities ?? '',
    topologyRootDeviceId: p.topologyRootDeviceId ?? null,
    topologyRootHostname: p.topologyRootDeviceId ? rootHostname.get(p.topologyRootDeviceId) ?? null : null,
    deviceCount: deviceCountByPlant.get(p.id) ?? 0,
    locationCount: locationCountByPlant.get(p.id) ?? 0,
    ticketCount: ticketCountByPlant.get(p.id) ?? 0,
    createdAt: p.createdAt instanceof Date ? p.createdAt.getTime() : Date.parse(String(p.createdAt)) || 0,
  }))

  const asOf = lastWrite._max.updatedAt?.getTime() || Date.now()
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(PlantsSchema, body)
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'RESPONSABILE_COMUNE')) {
    return fail('FORBIDDEN', 'Creare un impianto è un atto amministrativo: richiesto ruolo RESPONSABILE_COMUNE o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { name, comune, … })', 422)
  }
  const parsed = CreatePlantInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const email = session.session.user.email ?? 'sconosciuto'
  const created = await db.$transaction(async (tx) => {
    const plant = await tx.plant.create({
      data: {
        name: input.name,
        comune: input.comune,
        address: input.address ?? '',
        notes: input.notes ?? '',
        telegramChatId: input.telegramChatId ?? '',
        mapCenterLat: input.mapCenterLat ?? 41.0,
        mapCenterLng: input.mapCenterLng ?? 14.0,
        mapZoom: input.mapZoom ?? 14,
        pingIntervalSec: input.pingIntervalSec ?? 30,
        outageTimerMinutes: input.outageTimerMinutes ?? 5,
        snmpCommunities: input.snmpCommunities ?? '',
        isActive: input.isActive ?? true,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'PLANT_CREATE',
        actor: email,
        targetId: plant.id,
        targetLabel: plant.name,
        plantId: plant.id,
        details: JSON.stringify({
          name: plant.name,
          comune: plant.comune,
          address: plant.address,
          note: 'impianto creato vuoto: nessun job/poller registrato in riproduzione (D2)',
        }),
      },
    })
    return plant
  })

  const data = {
    id: created.id,
    name: created.name,
    comune: created.comune,
    address: created.address,
    notes: created.notes,
    telegramChatId: created.telegramChatId,
    kmzFile: created.kmzFile,
    isActive: created.isActive,
    mapCenterLat: created.mapCenterLat,
    mapCenterLng: created.mapCenterLng,
    mapZoom: created.mapZoom,
    pingIntervalSec: created.pingIntervalSec,
    outageTimerMinutes: created.outageTimerMinutes,
    snmpCommunities: created.snmpCommunities,
    topologyRootDeviceId: null,
    topologyRootHostname: null,
    deviceCount: 0,
    locationCount: 0,
    ticketCount: 0,
    createdAt: created.createdAt.getTime(),
  }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(PlantRowSchema, data)
  return ok(data, Date.now(), mode)
}
