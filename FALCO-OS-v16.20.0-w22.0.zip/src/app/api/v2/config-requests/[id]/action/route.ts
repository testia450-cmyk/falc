/* ================================================================
 * /api/v2/config-requests/{id}/action — POST {action} (16.7 W3.5)
 * Macchina a stati commit-confirm v11.8 S1, portata com'era (il DB
 * reale ha 0 richieste: gli stati NASCONO da qui, nessuno inventato):
 *   approve  PENDING → APPROVED         (approvedById = email)
 *   reject   PENDING|APPROVED → REJECTED
 *   apply    APPROVED → APPLIED         (SOLO executor SIMULATED:
 *            output DRY-RUN dichiarato, NESSUN comando inviato in
 *            riproduzione; SSH → 422 REPLAY_NOEXEC)
 *   confirm  APPLIED → CONFIRMED        (finestra commit-confirm
 *            scaduta → 422 WINDOW_EXPIRED: eseguire rollback)
 *   rollback APPLIED|CONFIRMED → ROLLED_BACK (dry-run dichiarato)
 * Ogni salto illegale → 422 INVALID_TRANSITION con lo stato attuale
 * (mai silenzio, mai stato inventato).
 *  · body {action} (accettato anche la stringa nuda: "approve");
 *  · 404 per richiesta o device inesistente;
 *  · ogni transizione scrive la riga E l'audit CONFIG_REQUEST_* in
 *    TRANSAZIONE (action/from→to/dettagli onesti);
 *  · risposta: la riga aggiornata (ConfigRequestRowSchema).
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { ConfigRequestActionSchema, ConfigRequestRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { toConfigRequestRow, CONFIG_REQUEST_INCLUDE } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  /* --- Corpo {action} (accettata anche la stringa nuda) --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { action: approve | reject | apply | confirm | rollback })', 422)
  }
  const actionRaw = rawBody !== null && typeof rawBody === 'object' && !Array.isArray(rawBody)
    && 'action' in (rawBody as Record<string, unknown>)
    ? (rawBody as { action: unknown }).action
    : rawBody
  const parsed = ConfigRequestActionSchema.safeParse(actionRaw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Azione non valida: atteso approve | reject | apply | confirm | rollback', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const action = parsed.data

  const request = await db.configChangeRequest.findUnique({
    where: { id },
    include: CONFIG_REQUEST_INCLUDE,
  })
  if (!request) return fail('NOT_FOUND', 'Richiesta di configurazione non trovata', 404)

  /* --- Transizione richiesta: valida PRIMA di scrivere --- */
  const from = request.status
  const invalid = (allowed: string): ReturnType<typeof fail> =>
    fail('INVALID_TRANSITION', `Transizione non consentita: ${from} → ${action}. Consentite da ${from}: ${allowed}.`, 422)

  const now = new Date()
  const email = session.session.user.email ?? 'sconosciuto'

  /* Dati della transizione (status + campi di contorno + audit) */
  let data: Prisma.ConfigChangeRequestUpdateInput
  let auditAction: string
  let auditDetails: Record<string, unknown>

  switch (action) {
    case 'approve': {
      if (from !== 'PENDING') return invalid('approve, reject')
      data = { status: 'APPROVED', approvedById: email }
      auditAction = 'CONFIG_REQUEST_APPROVE'
      auditDetails = {
        requestId: request.id, title: request.title, deviceId: request.deviceId,
        from: 'PENDING', to: 'APPROVED', approvedBy: email,
      }
      break
    }
    case 'reject': {
      if (from !== 'PENDING' && from !== 'APPROVED') return invalid(from === 'REJECTED' ? 'nessuna (già respinta)' : 'approve, reject')
      data = { status: 'REJECTED' }
      auditAction = 'CONFIG_REQUEST_REJECT'
      auditDetails = {
        requestId: request.id, title: request.title, deviceId: request.deviceId,
        from, to: 'REJECTED', by: email,
      }
      break
    }
    case 'apply': {
      if (from !== 'APPROVED') return invalid('apply, reject')
      /* Esecuzione reale SSH: NON disponibile in modalità riproduzione
       * (nessun poller attivo) → rifiuto onesto, mai un output finto. */
      if (request.executor === 'SSH') {
        return fail('REPLAY_NOEXEC', 'esecuzione SSH non disponibile in modalità riproduzione (nessun poller attivo): usare executor SIMULATED', 422)
      }
      const confirmBy = request.confirmMinutes > 0
        ? new Date(now.getTime() + request.confirmMinutes * 60000)
        : null // 0 = senza finestra commit-confirm
      data = {
        status: 'APPLIED',
        appliedAt: now,
        output: 'DRY-RUN (SIMULATED): comandi convalidati, NESSUN comando inviato al dispositivo (modalità riproduzione)',
        confirmBy,
      }
      auditAction = 'CONFIG_REQUEST_APPLY'
      auditDetails = {
        requestId: request.id, title: request.title, deviceId: request.deviceId,
        from: 'APPROVED', to: 'APPLIED', executor: request.executor,
        dryRun: true, // DICHIARATO: nessun comando inviato in replay
        appliedAt: now.getTime(),
        confirmBy: confirmBy?.getTime() ?? null,
        confirmMinutes: request.confirmMinutes,
      }
      break
    }
    case 'confirm': {
      if (from !== 'APPLIED') return invalid('confirm, rollback')
      /* Finestra commit-confirm scaduta: la conferma non è più valida,
       * la strada onesta è il rollback (v15 S1). */
      if (request.confirmBy != null && request.confirmBy.getTime() < now.getTime()) {
        return fail('WINDOW_EXPIRED', 'finestra commit-confirm scaduta: eseguire rollback', 422)
      }
      data = { status: 'CONFIRMED' }
      auditAction = 'CONFIG_REQUEST_CONFIRM'
      auditDetails = {
        requestId: request.id, title: request.title, deviceId: request.deviceId,
        from: 'APPLIED', to: 'CONFIRMED', by: email,
        confirmBy: request.confirmBy?.getTime() ?? null,
      }
      break
    }
    case 'rollback': {
      if (from !== 'APPLIED' && from !== 'CONFIRMED') return invalid(from === 'PENDING' || from === 'APPROVED' ? 'apply, reject' : 'nessuna')
      const rollbackNote = 'DRY-ROLLBACK: nessun comando inviato (modalità riproduzione)'
      data = {
        status: 'ROLLED_BACK',
        output: request.output ? `${request.output} · ${rollbackNote}` : rollbackNote,
      }
      auditAction = 'CONFIG_REQUEST_ROLLBACK'
      auditDetails = {
        requestId: request.id, title: request.title, deviceId: request.deviceId,
        from, to: 'ROLLED_BACK', by: email, dryRun: true, // DICHIARATO
      }
      break
    }
  }

  /* --- Update + audit in transazione interattiva --- */
  const updated = await db.$transaction(async (tx) => {
    const r = await tx.configChangeRequest.update({
      where: { id: request.id },
      data,
      include: CONFIG_REQUEST_INCLUDE,
    })
    await tx.auditLog.create({
      data: {
        action: auditAction,
        actor: email,
        targetId: r.id,
        targetLabel: r.title.slice(0, 80),
        /* il modello ConfigChangeRequest non ha plantId: l'impianto è
         * quello della sede del device target (null se senza sede) */
        plantId: r.device?.location?.plantId ?? null,
        details: JSON.stringify(auditDetails),
      },
    })
    return r
  })

  const data2 = toConfigRequestRow(updated)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(ConfigRequestRowSchema, data2)
  return ok(data2, now.getTime(), mode)
}
