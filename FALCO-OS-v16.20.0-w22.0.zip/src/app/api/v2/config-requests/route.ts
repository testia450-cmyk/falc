/* ================================================================
 * /api/v2/config-requests — GET (elenco) + POST (creazione, 16.7 W3.5)
 * Richieste di modifica configurazione REALI del DB (modello
 * ConfigChangeRequest v11.8 S1: pipeline commit-confirm con
 * guardrail). DB reale: 0 richieste → total 0 (onesto, non errore).
 *  · GET: elenco con device in join (hostname/type per la riga);
 *    stati APERTI (PENDING/APPROVED/APPLIED) prima, poi createdAt
 *    desc — la precedenza non è esprimibile in orderBy SQL e nasce da
 *    un sort STABILE in JS. commandsJson/rollbackJson/safetyJson sono
 *    JSON-string nel modello → parse difensivo; safety ricostruito
 *    {checked, forbidden, maxCommands, dryRunOnly} con default onesti.
 *  · POST (role ≥ TECNICO): device REALE nello scope del plant
 *    (404); GUARDRAIL v15: ogni comando matchato contro
 *    FORBIDDEN_COMMAND_PATTERNS → 422 FORBIDDEN_COMMAND con i label
 *    dei pattern violati nei details (rifiuto alla creazione, mai
 *    silenziato). executor default 'SIMULATED' (SSH si può anche
 *    salvare, ma apply lo rifiuta con REPLAY_NOEXEC). Crea status
 *    PENDING, safetyJson {checked, forbidden: [], maxCommands:
 *    CONFIG_MAX_COMMANDS, dryRunOnly: executor==='SIMULATED'},
 *    requestedById = email di sessione. Audit CONFIG_REQUEST_CREATE
 *    in TRANSAZIONE (title/deviceId/commands count/executor/
 *    confirmMinutes). 201 con la riga.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  ConfigRequestsPageSchema, ConfigRequestRowSchema, CreateConfigRequestInputSchema, CONFIG_MAX_COMMANDS,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant, maxOf } from '@/app/api/v2/shared'
import {
  toConfigRequestRow, CONFIG_REQUEST_INCLUDE, forbiddenCommandHits, guardrailReject,
} from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

/** Stati APERTI della macchina a stati (in cima all'elenco). */
const OPEN_STATUSES = new Set(['PENDING', 'APPROVED', 'APPLIED'])

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const requests = await db.configChangeRequest.findMany({
    where: { device: { plantId: p.id } }, // v16.12 W10: scope per plantId diretto
    include: CONFIG_REQUEST_INCLUDE,
    orderBy: { createdAt: 'desc' },
  })

  /* Stati aperti prima, poi il resto (createdAt desc dentro ogni
   * gruppo): sort STABILE in JS — la precedenza non è un orderBy SQL. */
  const sorted = [...requests].sort((a, b) => {
    const ao = OPEN_STATUSES.has(a.status) ? 0 : 1
    const bo = OPEN_STATUSES.has(b.status) ? 0 : 1
    return ao - bo
  })

  const data = {
    items: sorted.map(toConfigRequestRow),
    total: requests.length, // 0 = nessuna richiesta (onesto)
  }

  const asOf = maxOf(...requests.map((r) => r.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(ConfigRequestsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { deviceId, title, commands, rollback?, … } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con deviceId, title, commands)', 422)
  }
  const parsed = CreateConfigRequestInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- Device REALE nello scope del plant (404, non 422: il target
   *      indicato è l'entità che non esiste, come i ticket). --- */
  const device = await db.device.findFirst({
    where: {
      id: input.deviceId,
      plantId: p.id, // v16.12 W10: scope per plantId diretto
      decommissionedAt: null,
    },
    select: { id: true, hostname: true },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato (o fuori dallo scope dell\'impianto, o dismesso)', 404)

  /* --- Guardrail v15: comandi DISTRUTTIVI vietati alla creazione --- */
  const hits = forbiddenCommandHits(input.commands)
  if (hits.length > 0) return guardrailReject(hits)

  const executor = input.executor ?? 'SIMULATED' // replay: dry-run di default
  const confirmMinutes = input.confirmMinutes ?? 10 // default del modello v15
  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + audit in transazione; safetyJson congela il report
   *      del guardrail AL MOMENTO della creazione (v15 S1). --- */
  const created = await db.$transaction(async (tx) => {
    const r = await tx.configChangeRequest.create({
      data: {
        deviceId: device.id,
        title: input.title,
        commandsJson: JSON.stringify(input.commands),
        rollbackJson: JSON.stringify(input.rollback ?? []),
        executor,
        status: 'PENDING',
        safetyJson: JSON.stringify({
          checked: input.commands.length,
          forbidden: [], // qui ci arrivano solo richieste PULITE: gli hit sono stati rifiutati
          maxCommands: CONFIG_MAX_COMMANDS,
          dryRunOnly: executor === 'SIMULATED',
        }),
        confirmMinutes,
        requestedById: email,
        note: input.note ?? '',
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'CONFIG_REQUEST_CREATE',
        actor: email,
        targetId: r.id,
        targetLabel: r.title.slice(0, 80),
        plantId: p.id,
        details: JSON.stringify({
          requestId: r.id,
          title: r.title,
          deviceId: device.id,
          deviceHostname: device.hostname,
          commands: input.commands.length,
          rollback: (input.rollback ?? []).length,
          executor,
          confirmMinutes,
        }),
      },
    })
    return r
  })

  /* Riga di risposta con la join del device */
  const row = await db.configChangeRequest.findUnique({
    where: { id: created.id },
    include: CONFIG_REQUEST_INCLUDE,
  })
  if (!row) return fail('CREATE_FAILED', 'Richiesta creata ma non rileggibile', 500)

  const data = toConfigRequestRow(row)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(ConfigRequestRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
