/* ================================================================
 * /api/v2/audit/chain — GET (16.8, W6: stato della catena)
 * Stato REALE della catena audit: conteggi totali/sigillate/non
 * sigillate + i sigilli (AuditSeal) in ordine di lastSeq con la
 * spina prevSealId. Sola lettura: nessuna scrittura.
 * La VERIFICA crittografica vive in /api/v2/audit/chain/verify.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession } from '@/lib/v2/api-helpers'
import { AuditChainStateSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const [totalRows, sealedRows, agg, seals] = await Promise.all([
    db.auditLog.count(),
    db.auditLog.count({ where: { recordHash: { not: null } } }),
    db.auditLog.aggregate({ _min: { chainSeq: true }, _max: { chainSeq: true } }),
    db.auditSeal.findMany({ orderBy: { lastSeq: 'asc' } }),
  ])

  const data = {
    totalRows,
    sealedRows,
    unsealedRows: totalRows - sealedRows,
    firstSeq: agg._min.chainSeq ?? null,
    lastSeq: agg._max.chainSeq ?? null,
    seals: seals.map((s) => ({
      id: s.id,
      lastSeq: s.lastSeq,
      lastRecordId: s.lastRecordId,
      lastHash: s.lastHash,
      recordCount: s.recordCount,
      prevSealId: s.prevSealId,
      sealedBy: s.sealedBy,
      sealedAt: s.sealedAt.getTime(),
    })),
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AuditChainStateSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
