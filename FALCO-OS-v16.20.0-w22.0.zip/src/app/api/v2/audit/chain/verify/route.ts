/* ================================================================
 * /api/v2/audit/chain/verify — GET (16.8, W6: verifica integrità)
 * Verificatore v12.1.0 V12-F PORTATO FEDELE da v15.16.0: per ogni
 * sigillo conta il range, ricalcola la catena hash-per-hash (formula
 * pubblica del contratto), controlla lastRecordId/lastHash/
 * recordCount e la spina prevSealId; gli orfani sono rotture.
 * Sola lettura: NESSUNA scrittura.
 * Nel DB reale egidio verifica le 47.348 righe sigillate dal sealer
 * v15 (27/10) — durata tipica ~1-3 s, dichiarata in durationMs.
 * Diagnostica completa (non stop alla prima rottura), prime 200
 * rotture nel payload.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession } from '@/lib/v2/api-helpers'
import { AuditChainVerifySchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate } from '@/app/api/v2/shared'
import { verifyAuditTrailOnDb } from '@/lib/v2/audit-chain'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const report = await verifyAuditTrailOnDb(db)

  const data = {
    verified: report.ok,
    genesisHash: report.genesisHash,
    sealsTotal: report.sealsTotal,
    sealsVerified: report.sealsVerified,
    recordsSealed: report.recordsSealed,
    recordsVerified: report.recordsVerified,
    unsealedCount: report.unsealedCount,
    breakages: report.breakages.slice(0, 200),
    durationMs: report.durationMs,
    checkedAt: Date.now(),
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AuditChainVerifySchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
