/* ================================================================
 * /api/v2/audit/export — GET (16.8, W6: export certificato SHA-256)
 * Export CERTIFICATO dello storico audit — contratto v15.16.0
 * (GET /api/audit/export, V12-F) portato fedele:
 *  · format=csv (default file): CSV RFC 4180, UTF-8 senza BOM, CRLF,
 *    colonne v15 (chainSeq, createdAt ISO, action, actor, targetId,
 *    targetLabel, plantId, recordHash, details);
 *  · format=json: JSON deterministico v15 (format falco-os-audit-export
 *    v1, genesisHash, filterSummary, records);
 *  · NESSUN format → envelope JSON v2 con manifest per l'UI
 *    Certificazione: righe + totali catena + chainDigest (SHA-256 dei
 *    recordHash sigillati in ordine di seq) + exportDigest;
 *  · HEADER DI CERTIFICAZIONE (file): x-falco-export-sha256 = digest
 *    SHA-256 del BODY (evidenza portabile: il destinatario verifica
 *    byte-per-byte), x-falco-export-rows, content-disposition
 *    attachment falco-audit-export-<stamp>.<format>;
 *  · filtri from/to (epoch ms) + action (prefisso, come la vista);
 *    ordine deterministico (createdAt, id) = ordine di sigillatura;
 *  · tetto file: 50.000 righe (v15): oltre → 400 onesto con
 *    suggerimento di restringere il periodo;
 *  · audit AUDIT_EXPORT {format, rows, digest, filters} (mai i dati).
 * Il registro è GLOBALE (nessun filtro per impianto: le righe SYSTEM
 * non hanno plantId — scelta documentata della vista audit).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { AuditExportQuerySchema, AuditExportSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { computeChainDigest, buildAuditExportCsv, buildAuditExportJson, sha256hex } from '@/lib/v2/audit-chain'

export const dynamic = 'force-dynamic'

const FILE_MAX_ROWS = 50_000

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(AuditExportQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const where = {
    ...(q.value.from != null || q.value.to != null
      ? { createdAt: { ...(q.value.from != null ? { gte: new Date(q.value.from) } : {}), ...(q.value.to != null ? { lte: new Date(q.value.to) } : {}) } }
      : {}),
    ...(q.value.action ? { action: { startsWith: q.value.action } } : {}),
  }

  const email = session.session.user.email ?? 'sconosciuto'

  /* ---------------- FILE certificato (v15) ---------------- */
  if (q.value.format === 'csv' || q.value.format === 'json') {
    const total = await db.auditLog.count({ where })
    if (total > FILE_MAX_ROWS) {
      return fail('EXPORT_TOO_LARGE', `Export troppo grande: ${total} righe > tetto ${FILE_MAX_ROWS}. Restringere il periodo (from/to) o i filtri.`, 400)
    }
    const records = await db.auditLog.findMany({
      where,
      orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
      select: {
        id: true, createdAt: true, action: true, actor: true,
        targetId: true, targetLabel: true, plantId: true, details: true,
        chainSeq: true, recordHash: true,
      },
    })

    const filterSummary: Record<string, unknown> = {
      ...(q.value.action ? { action: q.value.action } : {}),
      ...(q.value.from != null ? { from: q.value.from } : {}),
      ...(q.value.to != null ? { to: q.value.to } : {}),
    }
    const body = q.value.format === 'json'
      ? buildAuditExportJson(records, { generatedAt: new Date().toISOString(), filterSummary })
      : buildAuditExportCsv(records)
    const digest = sha256hex(body)

    /* audit con il DIGEST del body prodotto (stessa tracciabilità v15) */
    await db.auditLog.create({
      data: {
        action: 'AUDIT_EXPORT',
        actor: email,
        targetLabel: `export ${q.value.format} · ${records.length} righe`,
        details: JSON.stringify({ format: q.value.format, rows: records.length, digest, filters: filterSummary }),
      },
    })

    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
    const res = new Response(body, {
      status: 200,
      headers: {
        'content-type': q.value.format === 'json' ? 'application/json; charset=utf-8' : 'text/csv; charset=utf-8',
        'content-disposition': `attachment; filename="falco-audit-export-${stamp}.${q.value.format}"`,
        'x-falco-export-sha256': digest,
        'x-falco-export-rows': String(records.length),
        'x-falco-export-format': q.value.format,
        'cache-control': 'no-store',
      },
    })
    return res
  }

  /* ---------------- Envelope JSON con manifest (per l'UI) ---------------- */
  const limit = q.value.limit ?? 200

  const [rows, totalMatching, totalRows, sealedRows, agg] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      select: { id: true, action: true, actor: true, targetId: true, targetLabel: true, plantId: true, createdAt: true, chainSeq: true, recordHash: true },
    }),
    db.auditLog.count({ where }),
    db.auditLog.count(),
    db.auditLog.count({ where: { recordHash: { not: null } } }),
    db.auditLog.aggregate({ _min: { chainSeq: true }, _max: { chainSeq: true } }),
  ])

  /* chainDigest su TUTTE le righe sigillate (ordine chainSeq): il
   * certificato copre la catena intera, non solo la finestra. */
  const sealedHashes = await db.auditLog.findMany({
    where: { recordHash: { not: null } },
    orderBy: { chainSeq: 'asc' },
    select: { recordHash: true },
  })
  const chainDigest = computeChainDigest(sealedHashes)

  const exported = rows.map((r) => ({
    id: r.id,
    action: r.action,
    actor: r.actor,
    targetId: r.targetId,
    targetLabel: r.targetLabel,
    plantId: r.plantId,
    createdAt: r.createdAt.getTime(),
    chainSeq: r.chainSeq,
    recordHash: r.recordHash,
  }))

  const data = {
    filters: { from: q.value.from ?? null, to: q.value.to ?? null, limit },
    totalMatching,
    returned: exported.length,
    truncated: totalMatching > exported.length,
    rows: exported,
    manifest: {
      totalRows,
      sealedRows,
      unsealedRows: totalRows - sealedRows,
      firstSeq: agg._min.chainSeq ?? null,
      lastSeq: agg._max.chainSeq ?? null,
      chainDigest,
      exportDigest: sha256hex(exported.map((r) => [r.id, String(r.createdAt), r.action, r.actor, r.chainSeq == null ? '' : String(r.chainSeq), r.recordHash ?? ''].join('|')).join('\n')),
      note: sealedRows === 0
        ? 'Nessuna riga è ancora sigillata: il manifest riporta i totali reali; usa POST /api/v2/audit/seal per sigillare la catena (operazione SUPER_ADMIN, persistente).'
        : 'chainDigest = SHA-256 dei recordHash di tutte le righe sigillate in ordine di chainSeq; exportDigest = SHA-256 canonico delle righe di questo export. Il FILE certificato (format=csv|json) esce con l\'header x-falco-export-sha256 = digest del body.',
    },
  }

  const asOf = maxOf(...rows.map((r) => r.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AuditExportSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

