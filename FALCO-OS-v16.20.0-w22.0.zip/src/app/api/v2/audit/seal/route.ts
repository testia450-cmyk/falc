/* ================================================================
 * /api/v2/audit/seal — POST (16.8, W6: sigillo della catena)
 * Sealer v12.1.0 V12-F PORTATO FEDELE da v15.16.0 (sorgente
 * originale recuperato dallo ZIP superstite dopo l'incidente #3):
 * sigilla in UNA transazione un batch (max 5.000 righe + la voce
 * AUDIT_SEAL_CREATE stessa) e crea l'AuditSeal con la spina
 * prevSealId. La catena CONTINUA da lastSeal.lastHash: le 47.348
 * righe già sigillate dal sealer v15 nel DB reale restano valide e
 * il sigillo v16 si aggancia ad esse.
 *  · role ≥ SUPER_ADMIN (l'admin demo è SUPER_ADMIN);
 *  · 422 NOTHING_TO_SEAL se non c'è nulla da sigillare;
 *  · risposta con verifica IMMEDIATA (verifyAuditTrailOnDb) — se la
 *    catena fosse rotta, verified=false con la diagnostica;
 *  · ATTENZIONE operatore: sigillare è persistente. Cancellare o
 *    riscrivere righe sigillate ROMPE la catena (tamper-evidence).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { AuditSealResultSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { sealUnsealedAuditRecords, verifyAuditTrailOnDb } from '@/lib/v2/audit-chain'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Ruolo SUPER_ADMIN richiesto per sigillare la catena audit', 403)
  }

  const email = session.session.user.email ?? 'sconosciuto'

  let outcome
  try {
    outcome = await sealUnsealedAuditRecords(db, { sealedBy: email, trigger: 'api' })
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    return fail('SEAL_FAILED', `Sigillo non riuscito: ${msg.slice(0, 200)}`, 500)
  }

  if (outcome.skipped) {
    return fail('NOTHING_TO_SEAL', 'Tutte le righe audit sono già sigillate: nessun sigillo necessario', 422)
  }

  /* Verifica immediata: il sigillo appena creato DEVE passare. */
  const verification = await verifyAuditTrailOnDb(db)

  const data = {
    sealId: outcome.sealId,
    sealedRows: outcome.sealed,
    lastSeq: outcome.lastSeq,
    lastHash: outcome.lastHash,
    skipped: outcome.skipped,
    remainingUnsealed: outcome.remainingUnsealed,
    verified: verification.ok,
    note: verification.ok
      ? `Catena sigillata e verificata: ${outcome.sealed} righe (fino a seq ${outcome.lastSeq}), ${verification.sealsVerified}/${verification.sealsTotal} sigilli validi, ricalcolo ${verification.recordsVerified} righe in ${verification.durationMs} ms.`
      : `ATTENZIONE: sigillo scritto ma la verifica ha trovato ${verification.breakages.length} rotture (${verification.breakages[0]?.reason ?? 'sconosciuta'}).`,
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AuditSealResultSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
