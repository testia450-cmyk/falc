/* ================================================================
 * /api/v2/audit — GET (sola lettura)
 * Registro audit REALE (48k+ righe): azioni di sistema e degli
 * operatori. Risponde SOLO { id, action, actor, targetLabel,
 * createdAt } — i `details` NON vengono MAI esposti (possono
 * contenere payload di azioni SYSTEM; la nota dell'operatore è
 * già visibile nella UI allarmi).
 *  · limit default 50, max 200; ordinamento createdAt DESC fisso;
 *  · filtro opzionale `action` con PREFIX match (startsWith, ad es.
 *    ?action=TICKET → TICKET_CREATE + TICKET_STATUS_CHANGE);
 *  · `total` = righe che soddisfano il filtro (badge onesto in UI);
 *    `returned` = righe effettivamente restituite;
 *  · il registro è GLOBALE (nessun filtro per impianto: le righe
 *    SYSTEM non hanno plantId — scelta documentata, non un limite).
 * Nessun campo credenziale selezionato (allowlist stretta).
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { AuditQuerySchema, AuditPageSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(AuditQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  /* Il registro è GLOBALE: nessun filtro per impianto (le righe SYSTEM
   * non hanno plantId) e nessuna risoluzione impianto richiesta. */
  const where: Prisma.AuditLogWhereInput = {}
  if (q.value.action) where.action = { startsWith: q.value.action }

  const [rows, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: q.value.limit,
      select: { id: true, action: true, actor: true, targetLabel: true, createdAt: true },
    }),
    db.auditLog.count({ where }),
  ])

  const data = {
    items: rows.map((r) => ({
      id: r.id,
      action: r.action,
      actor: r.actor,
      targetLabel: r.targetLabel ?? null,
      createdAt: r.createdAt.getTime(),
    })),
    total,
    returned: rows.length,
  }

  const asOf = maxOf(...rows.map((r) => r.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AuditPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
