/* ================================================================
 * /api/v2/reports/scheduled/[id] — PATCH + DELETE (16.8 W2)
 * Modifica (sostituzione integrale degli array, guard NO_CHANGES,
 * validazione semantica frequenza) ed eliminazione (cascade sugli
 * artefatti — 0 in riproduzione, dichiarato) con audit
 * REPORT_SCHEDULED_UPDATE (diff) / REPORT_SCHEDULED_DELETE.
 * nextRunAt ricalcolata alla modifica (proiezione pura, D2).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  UpdateScheduledReportInputSchema, ScheduledReportRowSchema, ScheduledReportDeletedSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { projectNextRun } from '../route'

export const dynamic = 'force-dynamic'

function parseJsonArray(raw: string): string[] {
  try {
    const v = JSON.parse(raw)
    return Array.isArray(v) ? v.map(String) : []
  } catch {
    return []
  }
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Ruolo TECNICO richiesto per modificare i report pianificati', 403)
  }

  const { id } = await ctx.params
  const existing = await db.scheduledReport.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Report pianificato non trovato', 404)

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo JSON non valido', 422)
  }
  const parsed = UpdateScheduledReportInputSchema.safeParse(body)
  if (!parsed.success) {
    return fail('BAD_QUERY', 'Payload non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const frequency = input.frequency ?? existing.frequency
  const hour = input.hour ?? existing.hour
  const dayOfWeek = input.dayOfWeek ?? existing.dayOfWeek
  const dayOfMonth = input.dayOfMonth ?? existing.dayOfMonth

  if (frequency === 'WEEKLY' && dayOfWeek == null) {
    return fail('BAD_FREQUENCY', 'Frequenza WEEKLY: dayOfWeek è obbligatorio (0 = domenica … 6 = sabato)', 422)
  }
  if (frequency === 'MONTHLY' && dayOfMonth == null) {
    return fail('BAD_FREQUENCY', 'Frequenza MONTHLY: dayOfMonth è obbligatorio (1–31)', 422)
  }

  /* --- Guard NO_CHANGES (confronto sui valori effettivi) --- */
  const nextChannels = input.channels ?? parseJsonArray(existing.channels)
  const nextRecipients = input.recipients ?? parseJsonArray(existing.recipients)
  const nextSections = input.includeSections ?? parseJsonArray(existing.includeSections)
  const same =
    (input.name == null || input.name === existing.name) &&
    (input.frequency == null || input.frequency === existing.frequency) &&
    (input.hour == null || input.hour === existing.hour) &&
    (input.dayOfWeek === undefined || input.dayOfWeek === existing.dayOfWeek) &&
    (input.dayOfMonth === undefined || input.dayOfMonth === existing.dayOfMonth) &&
    (input.enabled == null || input.enabled === existing.enabled) &&
    (input.channels == null || JSON.stringify(input.channels) === JSON.stringify(parseJsonArray(existing.channels))) &&
    (input.recipients == null || JSON.stringify(input.recipients) === JSON.stringify(parseJsonArray(existing.recipients))) &&
    (input.includeSections == null || JSON.stringify(input.includeSections) === JSON.stringify(parseJsonArray(existing.includeSections)))
  if (same) {
    return fail('NO_CHANGES', 'Nessuna modifica effettiva richiesta', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const nextRunAt = projectNextRun(frequency, hour, dayOfWeek, dayOfMonth)

  const updated = await db.$transaction(async (tx) => {
    const r = await tx.scheduledReport.update({
      where: { id },
      data: {
        ...(input.name != null ? { name: input.name } : {}),
        ...(input.frequency != null ? { frequency: input.frequency } : {}),
        ...(input.hour != null ? { hour: input.hour } : {}),
        ...(input.dayOfWeek != null ? { dayOfWeek: input.dayOfWeek } : {}),
        ...(input.dayOfMonth != null ? { dayOfMonth: input.dayOfMonth } : {}),
        ...(input.channels != null ? { channels: JSON.stringify(input.channels) } : {}),
        ...(input.recipients != null ? { recipients: JSON.stringify(input.recipients) } : {}),
        ...(input.includeSections != null ? { includeSections: JSON.stringify(input.includeSections) } : {}),
        ...(input.enabled != null ? { enabled: input.enabled } : {}),
        nextRunAt,
      },
    })
    const diff: Record<string, { from: unknown; to: unknown }> = {}
    if (input.name != null && input.name !== existing.name) diff.name = { from: existing.name, to: input.name }
    if (input.frequency != null && input.frequency !== existing.frequency) diff.frequency = { from: existing.frequency, to: input.frequency }
    if (input.hour != null && input.hour !== existing.hour) diff.hour = { from: existing.hour, to: input.hour }
    if (input.enabled != null && input.enabled !== existing.enabled) diff.enabled = { from: existing.enabled, to: input.enabled }
    if (input.channels != null) diff.channels = { from: parseJsonArray(existing.channels), to: input.channels }
    if (input.recipients != null) diff.recipients = { from: parseJsonArray(existing.recipients), to: input.recipients }
    if (input.includeSections != null) diff.sections = { from: parseJsonArray(existing.includeSections), to: input.includeSections }
    await tx.auditLog.create({
      data: {
        action: 'REPORT_SCHEDULED_UPDATE',
        actor: email,
        targetId: r.id,
        targetLabel: r.name.slice(0, 80),
        plantId: r.plantId,
        details: JSON.stringify({ id: r.id, diff }),
      },
    })
    return r
  })

  const data = {
    id: updated.id,
    name: updated.name,
    frequency: updated.frequency,
    hour: updated.hour,
    dayOfWeek: updated.dayOfWeek,
    dayOfMonth: updated.dayOfMonth,
    channels: nextChannels,
    recipients: nextRecipients,
    includeSections: nextSections,
    enabled: updated.enabled,
    lastRunAt: updated.lastRunAt?.getTime() ?? null,
    lastStatus: updated.lastStatus,
    nextRunAt: updated.nextRunAt?.getTime() ?? null,
    runCount: updated.runCount,
    artifactsCount: 0,
    createdAt: updated.createdAt.getTime(),
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(ScheduledReportRowSchema, data)
  return ok(data, updated.updatedAt.getTime(), mode)
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Ruolo TECNICO richiesto per eliminare i report pianificati', 403)
  }

  const { id } = await ctx.params
  const existing = await db.scheduledReport.findUnique({ where: { id }, include: { _count: { select: { artifacts: true } } } })
  if (!existing) return fail('NOT_FOUND', 'Report pianificato non trovato', 404)

  const email = session.session.user.email ?? 'sconosciuto'
  const removedArtifacts = existing._count.artifacts

  await db.$transaction(async (tx) => {
    await tx.scheduledReport.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'REPORT_SCHEDULED_DELETE',
        actor: email,
        targetId: id,
        targetLabel: existing.name.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({ id, name: existing.name, removedArtifacts }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  const data = { id, deleted: true, removedArtifacts }
  devValidate(ScheduledReportDeletedSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
