/* ================================================================
 * /api/v2/reports/scheduled — GET (elenco) + POST (creazione)
 * Report schedulati PDF v15 (modello ScheduledReport REALE dello
 * schema, 0 righe nel DB egidio): pianificazione con frequenza,
 * orario, canali (EMAIL/TELEGRAM/PDF), destinatari e sezioni.
 *  · ONESTÀ D2: il motore di schedulazione NON gira in riproduzione
 *    → lastRunAt resta null, lastStatus vuota, runCount 0, NESSUN
 *    ReportArtifact verrà mai generato: dichiarato nel payload
 *    (honesty) e in UI. La struttura è quella v15 pronta per il
 *    motore di produzione;
 *  · nextRunAt = proiezione PURA (date math da adesso, dichiarata
 *    «calcolata, non eseguita»);
 *  · POST (role ≥ TECNICO): validazione semantica frequenza (WEEKLY
 *    richiede dayOfWeek, MONTHLY richiede dayOfMonth, 422 espliciti),
 *    canali non vuoti, destinatari e-mail valide (max 20), sezioni
 *    del vocabolario v15; audit REPORT_SCHEDULED_CREATE in
 *    transazione con la create;
 *  · JSON arrays (channels/recipients/includeSections) letti con
 *    parse difensivo (campo corrotto → [] onesto, mai crash).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  CreateScheduledReportInputSchema, ScheduledReportsPageSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const HONESTY =
  'Il motore di schedulazione non è attivo in modalità riproduzione (D2): lastRunAt resta null, runCount 0 e nessun artefatto PDF viene generato. La pianificazione è reale e persistita; l\'esecuzione richiede il motore di produzione.'

function parseJsonArray(raw: string): string[] {
  try {
    const v = JSON.parse(raw)
    return Array.isArray(v) ? v.map(String) : []
  } catch {
    return []
  }
}

/** Proiezione della prossima esecuzione (date math puro, dichiarata). */
export function projectNextRun(frequency: string, hour: number, dayOfWeek: number | null, dayOfMonth: number | null): Date {
  const now = new Date()
  const candidate = new Date(now)
  candidate.setSeconds(0, 0)
  candidate.setHours(hour)
  const advance = (d: Date) => {
    switch (frequency) {
      case 'HOURLY':
        return new Date(d.getTime() + 3600_000)
      case 'DAILY':
        return new Date(d.getTime() + 24 * 3600_000)
      case 'WEEKLY':
        return new Date(d.getTime() + 7 * 24 * 3600_000)
      case 'MONTHLY': {
        const m = new Date(d)
        m.setMonth(m.getMonth() + 1)
        return m
      }
      default:
        return new Date(d.getTime() + 24 * 3600_000)
    }
  }
  const align = (d: Date): Date => {
    if (frequency === 'WEEKLY' && dayOfWeek != null) {
      while (d.getDay() !== dayOfWeek) d = new Date(d.getTime() + 24 * 3600_000)
    }
    if (frequency === 'MONTHLY' && dayOfMonth != null) {
      d.setDate(dayOfMonth)
    }
    return d
  }
  let next = align(candidate)
  if (next <= now) next = advance(next)
  return next
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const rows = await db.scheduledReport.findMany({
    where: { plantId: p.id },
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { artifacts: true } } },
  })

  const data = {
    items: rows.map((r) => ({
      id: r.id,
      name: r.name,
      frequency: r.frequency,
      hour: r.hour,
      dayOfWeek: r.dayOfWeek,
      dayOfMonth: r.dayOfMonth,
      channels: parseJsonArray(r.channels),
      recipients: parseJsonArray(r.recipients),
      includeSections: parseJsonArray(r.includeSections),
      enabled: r.enabled,
      lastRunAt: r.lastRunAt?.getTime() ?? null,
      lastStatus: r.lastStatus,
      nextRunAt: r.nextRunAt?.getTime() ?? null,
      runCount: r.runCount,
      artifactsCount: r._count.artifacts,
      createdAt: r.createdAt.getTime(),
    })),
    total: rows.length,
    honesty: HONESTY,
  }

  const asOf = maxOf(...rows.map((r) => r.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(ScheduledReportsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Ruolo TECNICO richiesto per pianificare report', 403)
  }

  const plant = await resolvePlant(new URL(req.url).searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo JSON non valido', 422)
  }
  const parsed = CreateScheduledReportInputSchema.safeParse(body)
  if (!parsed.success) {
    return fail('BAD_QUERY', 'Payload non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* --- Validazione semantica frequenza (stile finestre manutenzione) --- */
  if (input.frequency === 'WEEKLY' && input.dayOfWeek == null) {
    return fail('BAD_FREQUENCY', 'Frequenza WEEKLY: dayOfWeek è obbligatorio (0 = domenica … 6 = sabato)', 422)
  }
  if (input.frequency === 'MONTHLY' && input.dayOfMonth == null) {
    return fail('BAD_FREQUENCY', 'Frequenza MONTHLY: dayOfMonth è obbligatorio (1–31)', 422)
  }

  const nextRunAt = projectNextRun(input.frequency, input.hour, input.dayOfWeek ?? null, input.dayOfMonth ?? null)
  const email = session.session.user.email ?? 'sconosciuto'

  const created = await db.$transaction(async (tx) => {
    const r = await tx.scheduledReport.create({
      data: {
        plantId: p.id,
        name: input.name,
        frequency: input.frequency,
        hour: input.hour,
        dayOfWeek: input.dayOfWeek ?? 1,
        dayOfMonth: input.dayOfMonth ?? 1,
        channels: JSON.stringify(input.channels),
        recipients: JSON.stringify(input.recipients),
        includeSections: JSON.stringify(input.includeSections),
        enabled: input.enabled ?? true,
        nextRunAt,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'REPORT_SCHEDULED_CREATE',
        actor: email,
        targetId: r.id,
        targetLabel: r.name.slice(0, 80),
        plantId: p.id,
        details: JSON.stringify({
          name: r.name, frequency: r.frequency, hour: r.hour,
          channels: input.channels, recipientsCount: input.recipients.length,
          sections: input.includeSections,
        }),
      },
    })
    return r
  })

  const data = {
    items: [{
      id: created.id,
      name: created.name,
      frequency: created.frequency,
      hour: created.hour,
      dayOfWeek: created.dayOfWeek,
      dayOfMonth: created.dayOfMonth,
      channels: parseJsonArray(created.channels),
      recipients: parseJsonArray(created.recipients),
      includeSections: parseJsonArray(created.includeSections),
      enabled: created.enabled,
      lastRunAt: null,
      lastStatus: created.lastStatus,
      nextRunAt: created.nextRunAt?.getTime() ?? null,
      runCount: created.runCount,
      artifactsCount: 0,
      createdAt: created.createdAt.getTime(),
    }],
    total: 1,
    honesty: HONESTY,
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(ScheduledReportsPageSchema, { ok: true as const, asOf: created.createdAt.getTime(), mode, data })
  return ok(data, created.createdAt.getTime(), mode)
}
