/* ================================================================
 * /api/v2/reports/sla — GET (16.8, W2 residua)
 * Report SLA mensile + storico dai campi REALI dei ticket:
 * firstResponseAt / resolvedAt / slaResponseDueAt /
 * slaResolutionDueAt / slaPausedMinutes / escalationLevel.
 *  · month = YYYY-MM opzionale (default onesto: il mese più recente
 *    con ticket reali del plant, così il report si apre con dati);
 *  · popolazione = «coorte»: ticket CREATI nel mese (per i tempi);
 *    «closed» conta i ticket con closedAt NEL mese (standard ITSM);
 *  · copertura DICHIARATA: nel DB reale egidio firstResponseAt è
 *    valorizzato su 0/74 ticket e slaResponseDueAt/slaResolutionDueAt
 *    su 0/74 (SLADefinition = 0, D19): measured/evaluated escono con
 *    i numeri reali e le statistiche null («n.d.»), MAI mascherate;
 *  · resolutionTime al NETTO di slaPausedMinutes (pause SLA v15);
 *  · months + history = report SLA STORICO (W2): un rigo per ogni
 *    mese con ticket reali, nessun mese inventato;
 *  · l'impianto ha 74 ticket: caricati in un'unica query e aggregati
 *    in JS (approccio dichiarato, scalabile fino a ~50k righe).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { SlaReportQuerySchema, SlaReportSchema, type SlaMonthHistory } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const MONTH_RE = /^(\d{4})-(\d{2})$/

function monthKey(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`
}

function monthBounds(month: string): { from: Date; to: Date } {
  const m = MONTH_RE.exec(month)!
  const from = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, 1))
  const to = new Date(Date.UTC(Number(m[1]), Number(m[2]), 1))
  return { from, to }
}

function medianMin(values: number[]): number | null {
  if (!values.length) return null
  const s = [...values].sort((a, b) => a - b)
  const mid = Math.floor(s.length / 2)
  const v = s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2
  return Math.round(v * 10) / 10
}

function statsMin(values: number[]): { medianMin: number | null; avgMin: number | null; minMin: number | null; maxMin: number | null } {
  if (!values.length) return { medianMin: null, avgMin: null, minMin: null, maxMin: null }
  const avg = values.reduce((a, b) => a + b, 0) / values.length
  return {
    medianMin: medianMin(values),
    avgMin: Math.round(avg * 10) / 10,
    minMin: Math.round(Math.min(...values) * 10) / 10,
    maxMin: Math.round(Math.max(...values) * 10) / 10,
  }
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(SlaReportQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- Tutti i ticket reali del plant (74 righe: aggregazione in JS,
   *      approccio dichiarato nell'intestazione) --- */
  const tickets = await db.ticket.findMany({
    where: { plantId: p.id },
    select: {
      status: true, priority: true, source: true,
      createdAt: true, closedAt: true, resolvedAt: true, firstResponseAt: true,
      slaResponseDueAt: true, slaResolutionDueAt: true,
      slaPausedMinutes: true, escalationLevel: true,
    },
    orderBy: { createdAt: 'asc' },
  })

  const monthsWithData = [...new Set(tickets.map((t) => monthKey(t.createdAt)))].sort().reverse()
  const month = q.value.month ?? monthsWithData[0] ?? monthKey(new Date())
  const { from, to } = monthBounds(month)

  const coorte = tickets.filter((t) => t.createdAt >= from && t.createdAt < to)
  const closed = tickets.filter((t) => t.closedAt && t.closedAt >= from && t.closedAt < to).length

  const group = (key: 'status' | 'priority' | 'source') => {
    const m = new Map<string, number>()
    for (const t of coorte) m.set(String(t[key]), (m.get(String(t[key])) ?? 0) + 1)
    return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([k, count]) => ({ [key]: k, count }))
  }

  /* --- Tempi REALI: risposta (firstResponseAt) e risoluzione
   *      (resolvedAt al netto delle pause SLA) in minuti --- */
  const respValues = coorte
    .filter((t) => t.firstResponseAt)
    .map((t) => (t.firstResponseAt!.getTime() - t.createdAt.getTime()) / 60_000)
  const resoValues = coorte
    .filter((t) => t.resolvedAt)
    .map((t) => ((t.resolvedAt!.getTime() - t.createdAt.getTime()) / 60_000) - t.slaPausedMinutes)

  const respMeasured = respValues.length
  const resoMeasured = resoValues.length

  /* --- Conformità SLA: valutata SOLO dove i target esistono (campi
   *      slaDueAt valorizzati) — nel DB reale 0/74: dichiarato --- */
  const respEvaluated = coorte.filter((t) => t.slaResponseDueAt)
  const respInSla = respEvaluated.filter((t) => t.firstResponseAt && t.firstResponseAt <= t.slaResponseDueAt!)
  const resoEvaluated = coorte.filter((t) => t.slaResolutionDueAt)
  const resoInSla = resoEvaluated.filter((t) => t.resolvedAt && t.resolvedAt <= t.slaResolutionDueAt!)

  const slaDefinitions = await db.sLADefinition.count({ where: { plantId: p.id } })

  /* --- Storico: un rigo per ogni mese con ticket reali (W2) --- */
  const history: SlaMonthHistory[] = monthsWithData.slice().reverse().map((m) => {
    const { from: f, to: t2 } = monthBounds(m)
    const cm = tickets.filter((t) => t.createdAt >= f && t.createdAt < t2)
    const rEval = cm.filter((t) => t.slaResponseDueAt)
    const sEval = cm.filter((t) => t.slaResolutionDueAt)
    return {
      month: m,
      created: cm.length,
      closed: tickets.filter((t) => t.closedAt && t.closedAt >= f && t.closedAt < t2).length,
      responseMeasured: cm.filter((t) => t.firstResponseAt).length,
      resolutionMeasured: cm.filter((t) => t.resolvedAt).length,
      responseInSla: rEval.filter((t) => t.firstResponseAt && t.firstResponseAt <= t.slaResponseDueAt!).length,
      resolutionInSla: sEval.filter((t) => t.resolvedAt && t.resolvedAt <= t.slaResolutionDueAt!).length,
    }
  })

  const data = {
    month,
    windowFrom: from.getTime(),
    windowTo: to.getTime(),
    tickets: {
      total: tickets.length,
      created: coorte.length,
      closed,
      byStatus: group('status'),
      byPriority: group('priority'),
      bySource: group('source'),
    },
    responseTime: {
      measured: respMeasured,
      coverage: `${respMeasured} di ${coorte.length} ticket della coorte hanno firstResponseAt valorizzato (copertura dichiarata, nessun tempo stimato)`,
      ...statsMin(respValues),
    },
    resolutionTime: {
      measured: resoMeasured,
      coverage: `${resoMeasured} di ${coorte.length} ticket della coorte hanno resolvedAt valorizzato; tempi al netto di slaPausedMinutes`,
      pausedMinutesTotal: coorte.reduce((a, t) => a + t.slaPausedMinutes, 0),
      ...statsMin(resoValues),
    },
    slaCompliance: {
      response: {
        evaluated: respEvaluated.length,
        inSla: respInSla.length,
        late: respEvaluated.length - respInSla.length,
      },
      resolution: {
        evaluated: resoEvaluated.length,
        inSla: resoInSla.length,
        late: resoEvaluated.length - resoInSla.length,
      },
      slaDefinitions,
      note: slaDefinitions === 0
        ? 'Nessuna SLADefinition nel DB reale (D19): le soglie non sono mai state assegnate, la conformità è valutata solo dove i campi target dei ticket esistono.'
        : `${slaDefinitions} definizioni SLA reali dell'impianto.`,
    },
    escalation: {
      maxLevel: coorte.reduce((a, t) => Math.max(a, t.escalationLevel), 0),
      ticketsEscalated: coorte.filter((t) => t.escalationLevel > 0).length,
    },
    months: monthsWithData,
    history,
  }

  const asOf = maxOf(...tickets.map((t) => t.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(SlaReportSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
