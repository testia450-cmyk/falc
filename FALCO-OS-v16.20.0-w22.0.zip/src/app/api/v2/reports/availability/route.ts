/* ================================================================
 * /api/v2/reports/availability — GET (16.4, W2 residua)
 * Disponibilità di rete per dispositivo dalla serie REALE
 * «packetLoss» (51.438 campioni / 170 dispositivi nel DB reale,
 * 23/10 17:00 → 26/10 10:36 — serie CONGELATA alla fine del prelievo
 * reale): disponibilità = 100 − perdita media nella finestra.
 *  · finestra richiesta windowHours (24–168, default 48) DICHIARATA
 *    insieme alla copertura effettiva: coverageFrom/coverageTo =
 *    primo/ultimo campione packetLoss TROVATO nella finestra. Oltre
 *    coverageTo nessun campione esiste: le righe senza campioni
 *    escono con lossAvgPct/availabilityPct null → «n.d.» onesto
 *    (mai 100% per mancanza dato, mai OFFLINE per freschezza);
 *  · pingLatency riportata come statistiche supplementari (media/max
 *    ms nella finestra) ma NON è fonte di disponibilità: la presenza
 *    dei suoi campioni dipende dalla rotazione del replay, non dalla
 *    raggiungibilità — dichiarato nel contratto;
 *  · slaTargetsDefined = conteggio REALE di SLADefinition del plant
 *    (0 nel DB reale): nessuna soglia applicata o inventata;
 *  · scope dispositivi: come /devices (OR location.plantId /
 *    locationId null + decommissionedAt null — i 30 host scoperti
 *    compresi), allowlist colonne (mai credenziali);
 *  · nessuna paginazione: l'impianto reale ha 200 dispositivi attivi,
 *    la risposta è per intero (ordinata per hostname).
 * Aggregate con groupBy Prisma (AVG/MAX/COUNT + MIN/MAX timestamp):
 * una query per serie, il join con i dispositivi in JS.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import {
  AvailabilityQuerySchema, AvailabilityReportSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Arrotonda al centesimo (evita floating point rumorosi nel CSV/UI). */
function round2(v: number): number {
  return Math.round(v * 100) / 100
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(AvailabilityQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const windowHours = q.value.windowHours
  const windowStart = new Date(Date.now() - windowHours * 3_600_000)

  /* --- Serie REALE packetLoss nella finestra (fonte disponibilità).
   *      Query separate (non Promise.all): l'inferenza del tipo di
   *      ritorno del groupBy Prisma si degrada nella tupla. --- */
  const loss = await db.metricValue.groupBy({
    by: ['deviceId'],
    where: { metric: 'packetLoss', timestamp: { gte: windowStart } },
    _avg: { value: true },
    _max: { value: true, timestamp: true },
    _min: { timestamp: true },
    _count: { _all: true },
  })
  /* --- pingLatency (supplementare: NON disponibilità) --- */
  const ping = await db.metricValue.groupBy({
    by: ['deviceId'],
    where: { metric: 'pingLatency', timestamp: { gte: windowStart } },
    _avg: { value: true },
    _max: { value: true },
    _count: { _all: true },
  })
  /* --- Dispositivi attivi nello scope del plant (allowlist; v16.16
   *      W17-b: anche locationId per il raggruppamento per sede) --- */
  const devices = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
    select: { id: true, hostname: true, type: true, status: true, locationId: true, location: { select: { name: true } } },
  })
  /* --- SLA reali del plant: 0 righe nel DB reale (dichiarato).
   *      Il client Prisma espone il modello SLADefinition come
   *      «sLADefinition» (camelCase del nome composito). --- */
  const slaTargets = await db.sLADefinition.count({ where: { plantId: p.id } })

  const lossMap = new Map(loss.map((r) => [r.deviceId, r]))
  const pingMap = new Map(ping.map((r) => [r.deviceId, r]))

  const items = devices
    .map((d) => {
      const l = lossMap.get(d.id)
      const pg = pingMap.get(d.id)
      const lossAvg = l && l._count._all > 0 ? l._avg.value : null
      return {
        deviceId: d.id,
        hostname: d.hostname,
        type: d.type,
        dbStatus: d.status,
        locationId: d.locationId ?? null,
        locationName: d.location?.name ?? null,
        lossSamples: l ? l._count._all : 0,
        lossAvgPct: lossAvg != null ? round2(lossAvg) : null,
        lossMaxPct: l && l._count._all > 0 && l._max.value != null ? round2(l._max.value) : null,
        availabilityPct: lossAvg != null ? round2(100 - lossAvg) : null,
        firstSampleAt: l && l._count._all > 0 && l._min.timestamp ? l._min.timestamp.getTime() : null,
        lastSampleAt: l && l._count._all > 0 && l._max.timestamp ? l._max.timestamp.getTime() : null,
        pingSamples: pg ? pg._count._all : 0,
        pingAvgMs: pg && pg._count._all > 0 && pg._avg.value != null ? round2(pg._avg.value) : null,
        pingMaxMs: pg && pg._count._all > 0 && pg._max.value != null ? round2(pg._max.value) : null,
      }
    })
    .sort((a, b) => a.hostname.localeCompare(b.hostname, 'it'))

  /* --- v16.16 W17-b — raggruppamento PER SEDE (roadmap W2 residua):
   *      media sulle SOLE righe con campioni (le altre contate come
   *      «senza dati», mai azzerate né cento inventate), peggiore con
   *      hostname, copertura per sede. La media è quella semplice delle
   *      disponibilità per apparato (pesarla per i campioni sposterebbe
   *      il numero verso chi è campionato più spesso: dichiarato). --- */
  const locGroups = new Map<string, { locationId: string | null; locationName: string | null; rows: typeof items }>()
  for (const r of items) {
    const key = r.locationId ?? '__no_location__'
    const g = locGroups.get(key)
    if (g) {
      g.rows.push(r)
    } else {
      locGroups.set(key, { locationId: r.locationId, locationName: r.locationName, rows: [r] })
    }
  }
  const byLocation = [...locGroups.values()]
    .map((g) => {
      const withDataRows = g.rows.filter((r) => r.lossSamples > 0 && r.availabilityPct != null)
      const worst = withDataRows.reduce<null | (typeof withDataRows)[number]>((acc, r) => {
        if (!acc || (r.availabilityPct ?? 100) < (acc.availabilityPct ?? 100)) return r
        return acc
      }, null)
      const firsts = g.rows.map((r) => r.firstSampleAt).filter((v): v is number => v != null)
      const lasts = g.rows.map((r) => r.lastSampleAt).filter((v): v is number => v != null)
      return {
        locationId: g.locationId,
        locationName: g.locationName,
        devices: g.rows.length,
        withData: withDataRows.length,
        withoutData: g.rows.length - withDataRows.length,
        availabilityAvgPct: withDataRows.length > 0
          ? round2(withDataRows.reduce((s, r) => s + (r.availabilityPct ?? 0), 0) / withDataRows.length)
          : null,
        availabilityMinPct: worst?.availabilityPct ?? null,
        worstHostname: worst?.hostname ?? null,
        lossSamples: g.rows.reduce((s, r) => s + r.lossSamples, 0),
        coverageFrom: firsts.length > 0 ? Math.min(...firsts) : null,
        coverageTo: lasts.length > 0 ? Math.max(...lasts) : null,
      }
    })
    /* peggior disponibilità prima; sedi senza dati dopo (nomi asc);
     * «senza sede» (null) SEMPRE ultima: l'orfanoto non è una sede. */
    .sort((a, b) => {
      if (a.locationId == null && b.locationId == null) return 0
      if (a.locationId == null) return 1
      if (b.locationId == null) return -1
      const av = a.availabilityAvgPct
      const bv = b.availabilityAvgPct
      if (av == null && bv == null) return (a.locationName ?? '').localeCompare(b.locationName ?? '', 'it')
      if (av == null) return 1
      if (bv == null) return -1
      if (av !== bv) return av - bv
      return (a.locationName ?? '').localeCompare(b.locationName ?? '', 'it')
    })

  /* Copertura effettiva GLOBALE: primo/ultimo campione packetLoss
   * trovato nella finestra (la serie REALE termina a coverageTo —
   * oltre quella data i dati non esistono e il report lo dichiara). */
  const firsts = items.map((i) => i.firstSampleAt).filter((v): v is number => v != null)
  const lasts = items.map((i) => i.lastSampleAt).filter((v): v is number => v != null)

  const data = {
    items,
    byLocation,
    total: items.length,
    windowHours,
    coverageFrom: firsts.length > 0 ? Math.min(...firsts) : null,
    coverageTo: lasts.length > 0 ? Math.max(...lasts) : null,
    slaTargetsDefined: slaTargets,
  }

  const asOf = Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AvailabilityReportSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
