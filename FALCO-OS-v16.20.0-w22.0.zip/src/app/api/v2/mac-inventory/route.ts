/* ================================================================
 * /api/v2/mac-inventory — GET (16.5.0, W4 anticipata: «MAC inventory
 * (FDB × inventario)» della matrice di parità — anticipata perché il
 * dato REALE esiste: 3.307 osservazioni FDB su 20 apparati, serie
 * congelata al 26/10 09:50 — la copertura è DICHIARATA nel summary,
 * mai «fresca» spacciata).
 * Ogni riga = UNA osservazione FDB reale (apparato · porta · MAC ·
 * ultima volta visto) con risoluzione verso l'inventario (Device.
 * macAddress + extraMacs normalizzati; NESSUN database OUI — D20:
 * il produttore non è esposto, la UI mostra «non in inventario»
 * solo per la risoluzione, mai venditori inventati).
 * Filtri: q (MAC o hostname risolto), switchId (apparato che ha
 * visto il MAC), scope (all|resolved|unresolved), sort (lastSeen|
 * mac|hostname), paginazione reale (pageSize 10–200, default 25).
 * Il summary è GLOBALE (intero dataset PRIMA dei filtri: è la verità
 * dell'inventario MAC; i filtri cambiano l'elenco, non la realtà).
 * v16.15 W13: per le righe della PAGINA corrente, join con la tabella
 * ARP del plant (ArpEntry) → arpIp = IP più recente visto per quel
 * MAC (normalizzato). SOLO i MAC della pagina vengono cercati:
 * mai l'intera ArpEntry in memoria. '' = mai visto.
 * Lettura pura: nessuna scrittura, nessun dato inventato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { MacInventoryQuerySchema, MacInventoryPageSchema, type MacInventoryRow } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Normalizza un MAC per il confronto e la ricerca (minuscole, solo hex). */
function normMac(raw: string): string {
  return (raw || '').toLowerCase().replace(/[^0-9a-f]/g, '')
}

/** Forma AA:BB:CC:DD:EE:FF per la UI; raw grezzo se non normalizzabile (onestà). */
function displayMac(raw: string): string {
  const n = normMac(raw)
  if (n.length !== 12) return raw || ''
  return (n.match(/.{2}/g) ?? []).join(':').toUpperCase()
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const q = parseQuery(MacInventoryQuerySchema, url)
  if (!q.ok) return q.response
  const { page, pageSize, q: search, switchId, scope, sort, plantId: plantIdParam } = q.value

  const plant = await resolvePlant(plantIdParam)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const { now } = await loadDeviceRows(p.id)

  /* --- Inventario del plant (stesso scope di /devices) per la risoluzione:
   *     MAC primario + extraMacs, primo vincente. --- */
  const inventory = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
    select: { id: true, hostname: true, type: true, macAddress: true, extraMacs: true },
  })
  const macToDev = new Map<string, { id: string; hostname: string; type: string }>()
  for (const d of inventory) {
    const k = normMac(d.macAddress)
    if (k && !macToDev.has(k)) macToDev.set(k, { id: d.id, hostname: d.hostname, type: d.type })
    try {
      const v: unknown = JSON.parse(d.extraMacs || '[]')
      if (Array.isArray(v)) {
        for (const ex of v) {
          if (typeof ex !== 'string') continue
          const ek = normMac(ex)
          if (ek && !macToDev.has(ek)) macToDev.set(ek, { id: d.id, hostname: d.hostname, type: d.type })
        }
      }
    } catch { /* extraMacs non JSON: ignorato (dato storico corrotto non rompe la lettura) */ }
  }

  /* --- Osservazioni FDB del plant con l'apparato che le ha apprese.
   *     Il dataset reale è 3.307 righe: si carica per intero e si
   *     filtra/ordina in JS (paginazione e total ESATTI dalla stessa
   *     base, nessuna stima). --- */
  const fdbRows = await db.fdbObservation.findMany({
    where: { plantId: p.id },
    select: {
      mac: true, portName: true, lastSeenAt: true, deviceId: true,
      device: { select: { hostname: true } },
    },
    orderBy: { lastSeenAt: 'desc' },
  })

  const all: MacInventoryRow[] = fdbRows.map((f) => {
    const dev = macToDev.get(normMac(f.mac))
    return {
      mac: f.mac,
      macDisplay: displayMac(f.mac),
      switchId: f.deviceId,
      switchHostname: f.device?.hostname || f.deviceId,
      portName: f.portName,
      lastSeenAt: f.lastSeenAt.getTime(),
      resolved: !!dev,
      hostname: dev?.hostname ?? null,
      deviceId: dev?.id ?? null,
      deviceType: dev?.type ?? null,
      // v16.15 W13: riempito DOPO la paginazione, solo per le righe della
      // pagina corrente (join ArpEntry): '' = MAC mai visto nella tabella ARP.
      arpIp: '',
    }
  })

  /* --- Summary GLOBALE (prima dei filtri) — dichiarato nel contratto. --- */
  const resolvedCount = all.filter((r) => r.resolved).length
  const lastSeenMax = all.length ? Math.max(...all.map((r) => r.lastSeenAt)) : null

  /* --- Apparati con osservazioni FDB (filtro): id + hostname reali. --- */
  const switchesMap = new Map<string, string>()
  for (const r of all) if (!switchesMap.has(r.switchId)) switchesMap.set(r.switchId, r.switchHostname)
  const switches = [...switchesMap.entries()]
    .map(([id, hostname]) => ({ id, hostname }))
    .sort((a, b) => a.hostname.localeCompare(b.hostname, 'it'))

  /* --- Filtri --- */
  const searchLower = (search ?? '').trim().toLowerCase()
  const searchNorm = normMac(search ?? '')
  let items = all
  if (switchId) items = items.filter((r) => r.switchId === switchId)
  if (searchLower) {
    items = items.filter((r) =>
      (searchNorm && r.mac.includes(searchNorm)) ||
      (r.resolved && (r.hostname ?? '').toLowerCase().includes(searchLower)),
    )
  }
  if (scope === 'resolved') items = items.filter((r) => r.resolved)
  else if (scope === 'unresolved') items = items.filter((r) => !r.resolved)

  /* --- Ordinamento (lastSeen desc default; hostname: risolti asc, non risolti in coda) --- */
  const sorted = [...items]
  switch (sort) {
    case 'mac':
      sorted.sort((a, b) => a.mac.localeCompare(b.mac) || a.switchHostname.localeCompare(b.switchHostname, 'it'))
      break
    case 'hostname':
      sorted.sort((a, b) => {
        if (a.hostname == null && b.hostname == null) return b.lastSeenAt - a.lastSeenAt
        if (a.hostname == null) return 1
        if (b.hostname == null) return -1
        return a.hostname.localeCompare(b.hostname, 'it') || a.switchHostname.localeCompare(b.switchHostname, 'it')
      })
      break
    default:
      // lastSeen: già ordinati dalla query, ma dopo i filtri l'ordine resta — riassegna stabile
      sorted.sort((a, b) => b.lastSeenAt - a.lastSeenAt)
  }

  /* --- Paginazione reale (page oltre la fine → items vuoti, onesto) --- */
  const total = sorted.length
  const pageCount = Math.max(1, Math.ceil(total / pageSize))
  const safePage = Math.min(page, pageCount)
  const pageItems = sorted.slice((safePage - 1) * pageSize, safePage * pageSize)

  /* --- v16.15 W13: IP risolti dall'ARP per i MAC della PAGINA corrente.
   *     La query tocca SOLO i MAC della pagina (mai l'intera ArpEntry);
   *     cerca ENTRAMBE le forme del MAC perché nel DB reale la FDB storica
   *     è «aabbccddeeff» mentre la sonda L2 scrive «AA:BB:CC:DD:EE:FF»
   *     (normalizeMac) — il confronto avviene poi SEMPRE normalizzato.
   *     orderBy lastSeen desc: la prima riga vista per MAC è la più recente. --- */
  const pageMacVariants = new Set<string>()
  for (const r of pageItems) {
    pageMacVariants.add(r.mac)
    const disp = displayMac(r.mac)
    if (disp && disp !== r.mac) pageMacVariants.add(disp)
  }
  const arpIpByMac = new Map<string, string>()
  if (pageMacVariants.size > 0) {
    const arpRows = await db.arpEntry.findMany({
      where: { plantId: p.id, mac: { in: [...pageMacVariants] } },
      select: { mac: true, ip: true, lastSeen: true },
      orderBy: { lastSeen: 'desc' },
    })
    for (const a of arpRows) {
      const k = normMac(a.mac)
      if (k && !arpIpByMac.has(k)) arpIpByMac.set(k, a.ip)
    }
  }
  const itemsWithArp: MacInventoryRow[] = pageItems.map((r) => ({
    ...r,
    arpIp: arpIpByMac.get(normMac(r.mac)) ?? '',
  }))

  const asOf = maxOf(lastSeenMax) || now.getTime()
  const mode = apiMode(replay)

  const data = {
    items: itemsWithArp,
    total,
    page: safePage,
    pageSize,
    pageCount,
    switches,
    summary: { resolvedCount, unresolvedCount: all.length - resolvedCount, lastSeenMax },
  }
  const body = { ok: true as const, asOf, mode, data }
  devValidate(MacInventoryPageSchema, body)
  return ok(data, asOf, mode)
}
