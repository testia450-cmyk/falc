/* ================================================================
 * /api/v2/events — GET
 * Domanda a cui risponde (§6.1): «Cosa è successo di recente (flusso
 * eventi dispositivi) e posso scorrere indietro nel tempo?»
 * Cursor pagination su createdAt (before = epoch ms dell'ultimo item
 * della pagina precedente). Filtro per impianto (via device → location)
 * e per dispositivo.
 *  · nextCursor: createdAt dell'ultimo item SOLO se la pagina è piena
 *    (items.length === limit → potrebbero essercene altri); null quando
 *    la pagina non è piena (nessun dato oltre).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { EventsQuerySchema, EventsPageSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(EventsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()

  const items = await db.deviceEvent.findMany({
    where: {
      ...(q.value.deviceId ? { deviceId: q.value.deviceId } : {}),
      ...(q.value.before ? { createdAt: { lt: new Date(q.value.before) } } : {}),
      device: { plantId: p.id }, // v16.12 W10: scope per plantId diretto
    },
    orderBy: { createdAt: 'desc' },
    take: q.value.limit,
    include: { device: { select: { hostname: true } } },
  })

  const nextCursor = items.length === q.value.limit && items.length > 0
    ? items[items.length - 1].createdAt.getTime()
    : null

  const asOf = items[0]?.createdAt.getTime() || Date.now()
  const data = {
    items: items.map((e) => ({
      id: e.id,
      deviceId: e.deviceId,
      deviceHostname: e.device?.hostname ?? null,
      eventType: e.eventType,
      oldValue: e.oldValue ?? '',
      newValue: e.newValue ?? '',
      source: e.source ?? '',
      createdAt: e.createdAt.getTime(),
    })),
    nextCursor,
  }

  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(EventsPageSchema, body)
  return ok(data, asOf, mode)
}
