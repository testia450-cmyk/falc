/* ================================================================
 * /api/v2/cameras/streams — GET (16.3 additivo, onda W2 residua)
 * Domanda a cui risponde: «Com'è andato il flusso di ogni telecamera
 * nel tempo?» Registro flussi per apparato video (CAMERA/LPR/NVR,
 * convenzione unica v2): serie REALE di cameraStreamAlive sulla
 * finestra analizzata, aggregata in JS per dispositivo:
 *  · samples: campioni cameraStreamAlive nella finestra;
 *  · uptime24h/uptime7d: % campioni value>0 SOLO sui campioni presenti
 *    (zero campioni → null = «n.d.» in UI, MAI 0% per mancanza di dato;
 *    0% compare solo con campioni tutti flusso fermo: misura reale);
 *  · lastCheck/streamAlive: ultimo campione della finestra (value>0);
 *  · lastChange: ultima TRANSIZIONE di valore osservata tra campioni
 *    consecutivi (null = nessuna transizione o zero campioni: onesto,
 *    NON inventato);
 *  · rttMs: ultimo cameraRtt reale da getCameraStreamMap (derive.ts
 *    espone già il campo — nessuna seconda query necessaria).
 * FINESTRA RIDOTTA DICHIARATA (onestà §2.1): probe sul conteggio reale
 * dei campioni della finestra richiesta; se supera ~120.000 (nel DB
 * reale «egidio» la serie 168h è 136.470 campioni su ~2,7 giorni) la
 * rotta carica la finestra ridotta 48h (54.434 campioni al probe del
 * 27/10/2026) e dichiara windowHours=48 nella risposta. La finestra
 * effettivamente analizzata è SEMPRE quella dichiarata nel payload.
 * Filtri: locationId (CSV di id sede — cuid minuscoli: parse senza
 * uppercase, NON csv() di api-helpers che uppercasa e romperebbe gli
 * id reali), stream ('down'=alive===false, 'unknown'=null,
 * 'alive'=true — identico a /cameras), q su hostname/ip/locationName.
 * Ordinamento hostname localeCompare 'it'. Paginazione identica alle
 * rotte sorelle. Nessun campo credenziale selezionato (allowlist).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { CamerasStreamsQuerySchema, CamerasStreamsPageSchema, type StreamRegistryRow } from '@/lib/v2/contracts'
import { loadDeviceRows, getCameraStreamMap, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate, VIDEO_TYPES, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Soglia di carico oltre la quale la serie non viene caricata per
 *  intero (limite pratico di memoria del runtime, decisione dichiarata):
 *  la risposta serve allora la finestra ridotta 48h — o il minimo 24h —
 *  e dichiara la finestra realmente analizzata in data.windowHours. */
const MAX_SERIES_SAMPLES = 120_000
/** Finestra ridotta dichiarata quando quella richiesta è troppo pesante. */
const FALLBACK_WINDOW_HOURS = 48

/** Aggregato per dispositivo della serie cameraStreamAlive (finestra). */
interface StreamAgg {
  samples: number // campioni nella finestra
  alive: number // campioni value>0 nella finestra
  samples24: number // campioni nelle ultime 24h (sotto-finestra scorrevole)
  alive24: number // campioni value>0 nelle ultime 24h
  lastAlive: boolean // value>0 dell'ultimo campione
  lastCheck: number // epoch ms dell'ultimo campione
  lastChange: number | null // epoch ms dell'ultima transizione di valore
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(CamerasStreamsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()

  /* --- Decisione finestra: probe sul conteggio REALE dei campioni --- */
  const countFor = (hours: number) =>
    db.metricValue.count({
      where: {
        metric: 'cameraStreamAlive',
        plantId: p.id,
        timestamp: { gte: new Date(Date.now() - hours * 3600 * 1000) },
      },
    })
  let windowHours = q.value.windowHours
  let seriesCount = await countFor(windowHours)
  if (seriesCount > MAX_SERIES_SAMPLES) {
    // Finestra ridotta dichiarata: 48h; se anche quella eccede, il minimo 24h
    for (const h of [FALLBACK_WINDOW_HOURS, 24]) {
      if (h >= windowHours) continue
      const c = await countFor(h)
      windowHours = h
      seriesCount = c
      if (c <= MAX_SERIES_SAMPLES) break
    }
  }
  const since = new Date(Date.now() - windowHours * 3600 * 1000)
  const t24 = Date.now() - 24 * 3600 * 1000

  /* --- Caricamento serie + apparati video + mappa RTT --- */
  const [{ rows, asOf: rowsAsOf }, camMap, series] = await Promise.all([
    loadDeviceRows(p.id),
    getCameraStreamMap(p.id),
    db.metricValue.findMany({
      where: { metric: 'cameraStreamAlive', timestamp: { gte: since }, plantId: p.id },
      select: { deviceId: true, value: true, timestamp: true },
      orderBy: [{ deviceId: 'asc' }, { timestamp: 'asc' }],
    }),
  ])

  /* --- Aggregazione in JS per device (serie ordinata device+tempo) --- */
  const aggByDevice = new Map<string, StreamAgg>()
  let maxSampleAt = 0
  for (const s of series) {
    const at = s.timestamp.getTime()
    const alive = s.value > 0
    const a = aggByDevice.get(s.deviceId) ?? {
      samples: 0, alive: 0, samples24: 0, alive24: 0,
      lastAlive: alive, lastCheck: at, lastChange: null,
    }
    // transizione di valore tra campioni consecutivi dello stesso device
    // (il primo campione non è una transizione: non c'è il precedente)
    if (a.samples > 0 && alive !== a.lastAlive) a.lastChange = at
    a.samples++
    if (alive) a.alive++
    if (at >= t24) {
      a.samples24++
      if (alive) a.alive24++
    }
    a.lastAlive = alive
    a.lastCheck = at
    aggByDevice.set(s.deviceId, a)
    if (at > maxSampleAt) maxSampleAt = at
  }

  /** % (0-100, un decimale) di campioni attivi; null se zero campioni. */
  const uptime = (alive: number, total: number): number | null =>
    total === 0 ? null : Math.round((alive / total) * 1000) / 10

  /* --- Righe registro: un apparato video per riga --- */
  const needle = q.value.q?.toLowerCase() ?? ''
  // CSV di id sede: cuid MINUSCOLI — niente uppercase (csv() di
  // api-helpers uppercasa e romperebbe gli id reali)
  const locIds = (q.value.locationId ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)

  let items: StreamRegistryRow[] = []
  for (const r of rows) {
    if (!VIDEO_TYPES.includes(r.type)) continue

    if (locIds.length > 0 && !(r.locationId && locIds.includes(r.locationId))) continue

    const a = aggByDevice.get(r.id)
    // a esiste ⇔ almeno un campione nella finestra; altrimenti stream nullo
    const streamAlive = a ? a.lastAlive : null
    if (q.value.stream === 'down' && streamAlive !== false) continue
    if (q.value.stream === 'unknown' && streamAlive !== null) continue
    if (q.value.stream === 'alive' && streamAlive !== true) continue

    if (needle) {
      const hay = [r.hostname, r.ip, r.locationName ?? ''].join('\n').toLowerCase()
      if (!hay.includes(needle)) continue
    }

    items.push({
      deviceId: r.id,
      hostname: r.hostname,
      type: r.type,
      locationId: r.locationId,
      locationName: r.locationName,
      streamAlive,
      lastCheck: a ? a.lastCheck : null,
      lastChange: a ? a.lastChange : null,
      samples: a ? a.samples : 0,
      uptime24h: a ? uptime(a.alive24, a.samples24) : null,
      uptime7d: a ? uptime(a.alive, a.samples) : null,
      rttMs: camMap.byDevice.get(r.id)?.rttMs ?? null,
    })
  }

  items = items.sort((a, b) => a.hostname.localeCompare(b.hostname, 'it'))

  const total = items.length
  const pageCount = Math.max(1, Math.ceil(total / q.value.pageSize))
  items = items.slice((q.value.page - 1) * q.value.pageSize, q.value.page * q.value.pageSize)

  const asOf = maxOf(rowsAsOf, maxSampleAt) || Date.now()
  const data = {
    items, total,
    page: q.value.page,
    pageSize: q.value.pageSize,
    pageCount,
    // finestra realmente analizzata: dichiarata, mai mascherata
    windowHours,
  }
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(CamerasStreamsPageSchema, body)
  return ok(data, asOf, mode)
}
