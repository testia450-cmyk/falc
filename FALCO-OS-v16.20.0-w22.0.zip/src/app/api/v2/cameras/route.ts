/* ================================================================
 * /api/v2/cameras — GET
 * Domanda a cui risponde (§6.1): «Le telecamere vedono? I flussi sono
 * vivi e quanto è il ritardo?»
 * Apparati video (CAMERA/LPR/NVR, convenzione unica v2) con stato del
 * flusso dall'ULTIMO campione reale (cameraStreamAlive/cameraRtt, SQL
 * finestra in getCameraStreamMap):
 *  · streamAlive: null = mai campionato (stream «unknown»), true/false
 *    = ultimo campione (entry.at > 0 ⇔ campione esistente);
 *  · filtro stream: 'down' = alive===false, 'unknown' = null,
 *    'alive' = true;
 *  · 16.3 additivo: filtro sede locationId (CSV di id, opzionale);
 *  · nvrHostname: il dispositivo padre (parentId del DB oppure il
 *    parent dell'albero tier) SE e SOLO SE è un NVR (in questo impianto
 *    non ci sono NVR → null, nessuna invenzione);
 *  · rtspStream mascherato se contiene credenziali (regex '://…@'):
 *    nel DB reale non ne contiene — mascherato comunque (difesa in
 *    profondità, nessun segreto in risposta).
 * Nessun campo credenziale selezionato (allowlist).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { CamerasQuerySchema, CamerasPageSchema, type CameraRow } from '@/lib/v2/contracts'
import { loadDeviceRows, getCameraStreamMap, getReplayState, apiMode } from '@/lib/v2/derive'
import {
  resolvePlant, getPlantLinks, buildPlantTiers,
  devValidate, VIDEO_TYPES, maskRtsp, maxOf,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(CamerasQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const [{ rows, byId, asOf: rowsAsOf }, links, camMap, extras] = await Promise.all([
    loadDeviceRows(p.id),
    getPlantLinks(p.id),
    getCameraStreamMap(p.id),
    // parentId (persistito) + rtspStream (da mascherare) — select minima
    db.device.findMany({
      where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
      select: { id: true, parentId: true, rtspStream: true },
    }),
  ])
  const extraById = new Map(extras.map((e) => [e.id, e]))
  const tiers = buildPlantTiers(rows, links, p.topologyRootDeviceId)

  const needle = q.value.q?.toLowerCase() ?? ''
  // 16.3 additivo: filtro sede (CSV di id Location, cuid MINUSCOLI —
  // parse manuale: csv() di api-helpers uppercasa e romperebbe gli id)
  const locIds = (q.value.locationId ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
  let items: CameraRow[] = []
  let lastStreamAt = 0
  for (const r of rows) {
    if (!VIDEO_TYPES.includes(r.type)) continue

    if (locIds.length > 0 && !(r.locationId && locIds.includes(r.locationId))) continue

    const entry = camMap.byDevice.get(r.id)
    // entry.at > 0 ⇔ cameraStreamAlive davvero campionato
    const streamAlive = entry && entry.at > 0 ? entry.alive : null
    if (entry && entry.at > lastStreamAt) lastStreamAt = entry.at

    if (q.value.stream === 'down' && streamAlive !== false) continue
    if (q.value.stream === 'unknown' && streamAlive !== null) continue
    if (q.value.stream === 'alive' && streamAlive !== true) continue

    if (needle) {
      const hay = [r.hostname, r.ip, r.macAddress, r.model, r.brand, r.locationName ?? '']
        .join('\n').toLowerCase()
      if (!hay.includes(needle)) continue
    }

    // NVR padre (se esiste): parentId persistito, altrimenti parent dell'albero
    const extra = extraById.get(r.id)
    const parentId = extra?.parentId ?? tiers.parentOf.get(r.id) ?? null
    const parentRow = parentId ? byId.get(parentId) : undefined
    const nvrHostname = parentRow && parentRow.type === 'NVR' ? parentRow.hostname : null

    items.push({
      ...r,
      streamAlive,
      lastStreamCheck: entry && entry.at > 0 ? entry.at : null,
      rttMs: entry?.rttMs ?? null,
      nvrHostname,
      rtspStream: maskRtsp(extra?.rtspStream ?? ''),
    })
  }

  items = items.sort((a, b) => a.hostname.localeCompare(b.hostname, 'it'))

  const total = items.length
  const pageCount = Math.max(1, Math.ceil(total / q.value.pageSize))
  items = items.slice((q.value.page - 1) * q.value.pageSize, q.value.page * q.value.pageSize)

  const asOf = maxOf(rowsAsOf, lastStreamAt) || Date.now()
  const data = { items, total, page: q.value.page, pageSize: q.value.pageSize, pageCount }
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(CamerasPageSchema, body)
  return ok(data, asOf, mode)
}
