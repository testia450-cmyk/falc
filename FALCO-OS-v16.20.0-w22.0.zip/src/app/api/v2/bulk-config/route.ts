/* ================================================================
 * /api/v2/bulk-config — GET (elenco) + POST (ondata, 16.7 W3.5)
 * Ondate di configurazione multi-dispositivo REALI del DB (modello
 * BulkConfigChange v15.11 R8: tetto dispositivi e guardrail). DB
 * reale: 0 ondate → total 0 (onesto, non errore).
 *  · GET: ondate per createdAt desc; commandsJson/deviceIdsJson/
 *    safetyJson/resultsJson sono JSON-string nel modello → parse
 *    difensivo. targetCount = totale REALE dei target;
 *    targetHostnames = primi 20 (cap dichiarato nel contratto),
 *    risolti con UNA query per tutto l'elenco.
 *  · POST (role ≥ TECNICO): deviceIds deduplicati ⊆ dispositivi REALI
 *    dello scope del plant → 422 con offensori (max 5); oltre il tetto
 *    BULK_MAX_TARGETS dopo la deduplica → 422 (doppia verifica: zod
 *    limita già l'array grezzo); comandi contro il guardrail
 *    FORBIDDEN_COMMAND_PATTERNS → 422 FORBIDDEN_COMMAND; executor
 *    SSH → 422 REPLAY_NOEXEC (ondata SSH eseguibile solo con motori
 *    attivi). Executor SIMULATED (default): crea con status COMPLETED,
 *    startedAt/completedAt = ora, resultsJson per target
 *    {deviceId, hostname, ok: true, simulated: true, error: null,
 *    durationMs: 0} — DRY-RUN dichiarato riga per riga, mai «ok»
 *    inventato su una rete non raggiungibile. safetyJson {checked,
 *    forbidden: [], maxTargets, maxCommands, dryRunOnly: true}.
 *    Audit BULK_CONFIG_CREATE in TRANSAZIONE. 201 con la riga.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  BulkConfigPageSchema, BulkConfigRowSchema, CreateBulkConfigInputSchema,
  BULK_MAX_TARGETS, BULK_MAX_COMMANDS,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant, maxOf } from '@/app/api/v2/shared'
import {
  toBulkConfigRow, hostnameMapByIds, forbiddenCommandHits, guardrailReject, parseJsonStringArray,
} from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const waves = await db.bulkConfigChange.findMany({ orderBy: { createdAt: 'desc' } })

  /* Hostname dei target di TUTTE le ondate caricate con UNA sola
   * query (mai N+1); il filtro di plant resta a valle della lettura
   * delle ondate perché il modello non ha plantId: i target parlano. */
  const hostnameMap = await hostnameMapByIds(waves.flatMap((w) => parseJsonStringArray(w.deviceIdsJson)))

  const data = {
    items: waves.map((w) => toBulkConfigRow(w, hostnameMap)),
    total: waves.length, // 0 = nessuna ondata (onesto)
  }

  const asOf = maxOf(...waves.map((w) => w.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(BulkConfigPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { title, commands, deviceIds, executor? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con title, commands, deviceIds)', 422)
  }
  const parsed = CreateBulkConfigInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- Target: deduplicati, tutti REALI e nello scope del plant --- */
  const deviceIds = Array.from(new Set(input.deviceIds))
  if (deviceIds.length > BULK_MAX_TARGETS) {
    /* doppia verifica sul conteggio DEDUPLICATO (zod limita l'array
     * grezzo: la deduplica non può che ridurlo, ma il tetto resta) */
    return fail('BAD_BODY', `Troppi dispositivi target: ${deviceIds.length} > ${BULK_MAX_TARGETS} (tetto v15 R8 per ondata)`, 422, [
      { path: 'deviceIds', message: `Massimo ${BULK_MAX_TARGETS} dispositivi per ondata (ricevuti ${deviceIds.length} dopo deduplica)` },
    ])
  }
  const devices = await db.device.findMany({
    where: {
      id: { in: deviceIds },
      plantId: p.id, // v16.12 W10: scope per plantId diretto
      decommissionedAt: null,
    },
    select: { id: true, hostname: true },
  })
  const foundSet = new Set(devices.map((d) => d.id))
  const offending = deviceIds.filter((id) => !foundSet.has(id))
  if (offending.length > 0) {
    return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
      { path: 'deviceIds', message: `Id non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
    ])
  }

  /* --- Guardrail v15 sui comandi dell'ondata --- */
  const hits = forbiddenCommandHits(input.commands)
  if (hits.length > 0) return guardrailReject(hits)

  /* --- Executor: SSH NON eseguibile in riproduzione (nessun motore
   *      attivo): rifiuto onesto, dopo le validazioni dei target e
   *      del guardrail (l'ordine segue la specifica dell'ondata). --- */
  const executor = input.executor ?? 'SIMULATED'
  if (executor === 'SSH') {
    return fail('REPLAY_NOEXEC', 'ondata SSH eseguibile solo con motori attivi: in replay usare SIMULATED (dry-run)', 422)
  }

  const hostnameById = new Map(devices.map((d) => [d.id, d.hostname]))
  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- SIMULATED: ondata DRY-RUN dichiarata — risultati per target
   *      {ok: true, simulated: true, durationMs: 0}: «convalidato e
   *      non inviato», MAI un esito di rete inventato. --- */
  const results = deviceIds.map((deviceId) => ({
    deviceId,
    hostname: hostnameById.get(deviceId) ?? '',
    ok: true,
    simulated: true,
    error: null,
    durationMs: 0,
  }))

  const created = await db.$transaction(async (tx) => {
    const w = await tx.bulkConfigChange.create({
      data: {
        title: input.title,
        commandsJson: JSON.stringify(input.commands),
        deviceIdsJson: JSON.stringify(deviceIds),
        executor,
        status: 'COMPLETED', // dry-run istantaneo e DICHIARATO (resultsJson)
        safetyJson: JSON.stringify({
          checked: input.commands.length,
          forbidden: [], // qui ci arrivano solo ondate PULITE
          maxTargets: BULK_MAX_TARGETS,
          maxCommands: BULK_MAX_COMMANDS,
          dryRunOnly: true,
        }),
        resultsJson: JSON.stringify(results),
        requestedById: email,
        startedAt: now,
        completedAt: now,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'BULK_CONFIG_CREATE',
        actor: email,
        targetId: w.id,
        targetLabel: w.title.slice(0, 80),
        plantId: p.id,
        details: JSON.stringify({
          bulkId: w.id,
          title: w.title,
          targets: deviceIds.length,
          commands: input.commands.length,
          executor,
          dryRun: true, // DICHIARATO: nessun comando inviato in replay
          status: w.status,
        }),
      },
    })
    return w
  })

  const data = toBulkConfigRow(created, hostnameById)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(BulkConfigRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
