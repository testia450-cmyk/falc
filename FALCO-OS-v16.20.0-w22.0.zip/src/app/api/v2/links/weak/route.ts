/* ================================================================
 * /api/v2/links/weak — GET
 * Domanda a cui risponde (§6.1): «Quali link radio sono più deboli e
 * quanto manca al collasso?» (segnale uplink per stazione; per AP la
 * stazione figlia più debole — semantica §1.4, port radio-metrics).
 * Composizione: loadDeviceRows + computeNetworkTiers (parentOf per
 * l'hostname dell'uplink) + computeReachability (childrenOf per
 * stationSignalsOf sugli AP). Ordinamento dal più debole.
 * Solo valori REALI: segnale 0 = «non letto» → escluso (mai inventato).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { WeakLinksQuerySchema, WeakLinksSchema } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import {
  resolvePlant, getPlantLinks, buildPlantTiers, buildPlantReachability,
  computeWeakLinkRows, devValidate,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(WeakLinksQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const [{ rows, asOf }, links] = await Promise.all([
    loadDeviceRows(p.id),
    getPlantLinks(p.id),
  ])

  const tiers = buildPlantTiers(rows, links, p.topologyRootDeviceId)
  const reach = buildPlantReachability(rows, links)
  const weak = computeWeakLinkRows(rows, tiers, reach).slice(0, q.value.limit)

  const mode = apiMode(replay)
  const data = weak
  const body = { ok: true as const, asOf, mode, data }
  devValidate(WeakLinksSchema, body)
  return ok(data, asOf, mode)
}
