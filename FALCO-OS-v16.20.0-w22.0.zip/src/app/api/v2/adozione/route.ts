/* ================================================================
 * /api/v2/adozione — GET · POST (portata da v15 §13.8, GAP 1)
 * Domanda a cui risponde: «Quali apparati sono ancora senza sede?
 * Chi va confermato?». La coda è il punto in cui la scansione
 * incontra la DECISIONE UMANA: nessuna auto-adozione, mai.
 *
 * GET  · orphans: dispositivi SENZA sede (locationId null) nello
 *        scope dell'impianto — gli host scoperti (SYS:NEW_HOST) che
 *        v15 raccoglieva e che v16 mostra già come «non monitorati»;
 *      · toConfirm: requiresConfirmation=true (impianti sensibili,
 *        GAP 2 v15: 2-man rule prima dell'adozione definitiva);
 *      · locations: sedi REALI del plant per la scelta a tendina.
 *
 * POST · adopt {deviceId, locationId}: assegna la sede, azzera il
 *        flag requiresConfirmation, scrive audit ADOZIONE_ADOPT
 *        (attore, sede, hostname). Solo per orfani o «da confermare»:
 *        un dispositivo già adottato e confermato viene rifiutato
 *        con 422 (onesto, non un errore silenzioso);
 *      · dismiss {deviceId}: archivia la richiesta SENZA toccare il
 *        dispositivo (solo per «da confermare»), audit ADOZIONE_DISMISS.
 *
 * Scope impianto: stesso pattern OR di /devices (location.plantId ∨
 * locationId null) — coerente con tutto v16.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { AdoptionActionSchema, AdoptionQueueSchema } from '@/lib/v2/contracts'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

/* ---------------- Selezione colonna (allowlist) ---------------- */

const CANDIDATE_SELECT = {
  id: true,
  hostname: true,
  type: true,
  brand: true,
  model: true,
  macAddress: true,
  ip: true,
  firmwareVersion: true,
  lastSeenAt: true,
  status: true,
  requiresConfirmation: true,
  locationId: true,
} as const

type CandidateRaw = {
  id: string
  hostname: string
  type: string
  brand: string | null
  model: string | null
  macAddress: string | null
  ip: string | null
  firmwareVersion: string | null
  lastSeenAt: Date | null
  status: string
  requiresConfirmation: boolean
  locationId: string | null
}

function toCandidate(d: CandidateRaw) {
  return {
    id: d.id,
    hostname: d.hostname,
    type: d.type,
    brand: d.brand,
    model: d.model,
    macAddress: d.macAddress,
    ip: d.ip,
    firmwareVersion: d.firmwareVersion,
    lastSeenAt: d.lastSeenAt?.getTime() ?? null, // null = mai visto (onesto)
    status: d.status,
    requiresConfirmation: d.requiresConfirmation,
  }
}

/* ---------------- GET: la coda ---------------- */

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const plantId = plant.plant.id

  /* Orfani: senza sede, del QUESTO impianto (plantId diretto v16.12 W10:
   * un orfano appartiene all'impianto che lo ha scoperto — i 30 del DB
   * reale sono di egidio e NON appaiono più negli altri impianti).
   * Esclusi i dismessi: un apparato dismesso non è adottabile, va riattivato. */
  const [orphans, toConfirm, locations] = await Promise.all([
    db.device.findMany({
      where: { plantId, locationId: null, decommissionedAt: null },
      select: CANDIDATE_SELECT,
      orderBy: { hostname: 'asc' },
    }),
    db.device.findMany({
      where: {
        requiresConfirmation: true,
        plantId, // v16.12 W10: scope per plantId diretto
        decommissionedAt: null,
      },
      select: CANDIDATE_SELECT,
      orderBy: { hostname: 'asc' },
    }),
    db.location.findMany({
      where: { plantId },
      select: { id: true, name: true },
      orderBy: { name: 'asc' },
    }),
  ])

  const data = {
    orphans: orphans.map(toCandidate),
    toConfirm: toConfirm.map(toCandidate),
    locations,
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(AdoptionQueueSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}

/* ---------------- POST: azione umana (adopt | dismiss) ---------------- */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo un tecnico può adottare o archiviare un apparato', 403)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const plantId = plant.plant.id

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = AdoptionActionSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Azione di adozione non valida', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Il dispositivo deve esistere e appartenere a QUESTO impianto. */
  const device = await db.device.findFirst({
    where: { id: input.deviceId, plantId }, // v16.12 W10: scope per plantId diretto
    select: { ...CANDIDATE_SELECT, location: { select: { name: true } } },
  })
  if (!device) {
    return fail('NOT_FOUND', 'Dispositivo inesistente o fuori dall\'impianto', 404)
  }

  const email = session.session.user.email ?? 'sconosciuto'

  /* --- dismiss: solo per i «da confermare» --- */
  if (input.action === 'dismiss') {
    if (!device.requiresConfirmation) {
      return fail('BAD_STATE', 'Solo gli apparati «da confermare» possono essere archiviati dalla coda', 422)
    }
    const updated = await db.$transaction(async (tx) => {
      const d = await tx.device.update({
        where: { id: device.id },
        data: { requiresConfirmation: false },
        select: { id: true },
      })
      await tx.auditLog.create({
        data: {
          action: 'ADOZIONE_DISMISS',
          actor: email,
          targetId: d.id,
          targetLabel: device.hostname.slice(0, 80),
          plantId,
          details: JSON.stringify({
            deviceId: d.id,
            hostname: device.hostname,
            ip: device.ip,
            decision: 'archiviato senza adozione (operatore)',
          }),
        },
      })
      return d
    })
    const replay = await getReplayState()
    return ok({ id: updated.id, action: 'dismiss' }, Date.now(), apiMode(replay))
  }

  /* --- adopt: sede reale del plant + audit --- */
  const location = await db.location.findFirst({
    where: { id: input.locationId, plantId },
    select: { id: true, name: true },
  })
  if (!location) {
    return fail('BAD_BODY', 'Sede inesistente in questo impianto', 422, [
      { path: 'locationId', message: 'Sede non trovata' },
    ])
  }

  /* Un dispositivo già con sede e già confermato NON è in coda:
   * rifiuto esplicito (mai spostamenti silenziosi da questa rotta —
   * per il riposizionamento esiste la gestione inventario). */
  if (device.locationId != null && !device.requiresConfirmation) {
    return fail('BAD_STATE', 'Dispositivo già adottato (sede assegnata e confermata): fuori dalla coda adozione', 422)
  }

  const updated = await db.$transaction(async (tx) => {
    const d = await tx.device.update({
      where: { id: device.id },
      data: {
        locationId: location.id,
        requiresConfirmation: false,
        /* provenienza MANUALE (operatore): il motore topologico di
         * auto-assegnazione v15 non tocca mai le sedi messe a mano. */
        locationAssignedBy: '',
      },
      select: { id: true },
    })
    await tx.auditLog.create({
      data: {
        action: 'ADOZIONE_ADOPT',
        actor: email,
        targetId: d.id,
        targetLabel: device.hostname.slice(0, 80),
        plantId,
        details: JSON.stringify({
          deviceId: d.id,
          hostname: device.hostname,
          ip: device.ip,
          locationId: location.id,
          locationName: location.name,
          previousLocationId: device.locationId,
          decision: 'adottato su sede scelta dall\'operatore',
        }),
      },
    })
    return d
  })

  const replay = await getReplayState()
  return ok({ id: updated.id, action: 'adopt', locationId: location.id }, Date.now(), apiMode(replay))
}
