/* ================================================================
 * /api/v2/waves — GET (elenco) + POST (pianificazione) — 16.9.0 W4
 * ONDATE di configurazioni/firmware — port fedele da v15.12.0
 * (Fase R8, decisioni 31-32): preflight con scarti ONesti, lotti
 * pianificati (lotto 1 = canary), NESSUNA adozione automatica.
 * ONESTÀ D2 (dichiarata nel payload e nella UI): il MOTORE di
 * esecuzione per-item non gira in riproduzione → le ondate nascono
 * e restano DRAFT (pianificazione reale, esecuzione dichiarata non
 * disponibile); executionAvailable: false.
 *  · GET: elenco con preflight parsed, counts per stato item;
 *  · POST (role ≥ TECNICO): preflight REALE per ogni target
 *    (dismesso / in manutenzione / credenziali assenti / OFFLINE),
 *    lotti col canary, righe ConfigWaveItem PREFLIGHT_OK;
 *    audit WAVE_CREATED con scarti e motivi.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { WavesPageSchema, CreateWaveInputSchema, WaveRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/* ---------------- Motore puro (port v15 wave-engine.ts) ---------------- */

export interface WaveBatch {
  number: number
  deviceIds: string[]
  isCanary: boolean
}

/** Il PRIMO lotto è il canary (primi canarySize id), gli altri a
 * gruppi di batchSize. Ordine dato = deterministico. */
export function planWaveBatches(deviceIds: string[], opts: { batchSize?: number; canarySize?: number } = {}): WaveBatch[] {
  const batchSize = Math.max(1, Math.floor(opts.batchSize ?? 5))
  const canarySize = Math.max(1, Math.floor(opts.canarySize ?? 1))
  if (deviceIds.length === 0) return []

  const batches: WaveBatch[] = []
  batches.push({ number: 1, deviceIds: deviceIds.slice(0, canarySize), isCanary: true })

  let number = 2
  for (let i = canarySize; i < deviceIds.length; i += batchSize) {
    batches.push({ number, deviceIds: deviceIds.slice(i, i + batchSize), isCanary: false })
    number++
  }
  return batches
}

/** Regole DICHIARATE del preflight: niente target incerto in ondata. */
export function preflightDevice(row: {
  deviceId: string; decommissionedAt: Date | null; inMaintenance: boolean;
  hasCredentials: boolean; credentialState: string; status: string;
}): { ok: boolean; reason: string } {
  if (row.decommissionedAt) return { ok: false, reason: 'dispositivo DISMESSO: fuori da ogni ondata' }
  if (row.inMaintenance) return { ok: false, reason: 'dispositivo in MANUTENZIONE: rimandare a finestra dedicata' }
  if (!row.hasCredentials) return { ok: false, reason: `credenziali assenti (stato ${row.credentialState || 'UNKNOWN'})` }
  if (row.status && ['OFFLINE'].includes(row.status)) {
    return { ok: false, reason: 'dispositivo OFFLINE: non raggiungibile per l\'azione' }
  }
  return { ok: true, reason: 'preflight superato' }
}

/** Finestra di manutenzione attiva per il dispositivo (scope gruppo,
 * port compatto di getActiveMaintenanceForDevice v15 — fail-open). */
async function inActiveMaintenance(plantId: string, deviceId: string): Promise<boolean> {
  try {
    const windows = await db.maintenanceWindow.findMany({
      where: { plantId, state: 'ACTIVE' },
      include: { scopes: { select: { groupId: true } } },
    })
    if (windows.length === 0) return false
    if (windows.some((w) => w.scopes.length === 0)) return true // nessun gruppo = intero impianto
    const groupIds = windows.flatMap((w) => w.scopes.map((s) => s.groupId))
    if (groupIds.length === 0) return false
    const member = await db.deviceGroupMember.findFirst({ where: { deviceId, groupId: { in: groupIds } } })
    return !!member
  } catch {
    return false
  }
}

/* ---------------- GET: elenco ondate ---------------- */

function toWaveRow(w: {
  id: string; name: string; kind: string; action: string; status: string;
  batchSize: number; canarySize: number; stopOnFirstFailure: boolean;
  dryRun: boolean; createdBy: string; createdAt: Date; preflight: string | null;
  items: Array<{ status: string; isCanary: boolean; batchNumber: number }>;
}) {
  let preflight: Array<{ deviceId: string; hostname: string; ok: boolean; reason: string }> | null = null
  if (w.preflight) {
    try {
      const v = JSON.parse(w.preflight)
      if (Array.isArray(v)) preflight = v.slice(0, 500)
    } catch { /* preflight non readable → null dichiarato */ }
  }
  return {
    id: w.id,
    name: w.name,
    kind: w.kind,
    action: w.action,
    status: w.status,
    batchSize: w.batchSize,
    canarySize: w.canarySize,
    stopOnFirstFailure: w.stopOnFirstFailure,
    dryRun: w.dryRun,
    createdBy: w.createdBy,
    createdAt: w.createdAt.getTime(),
    preflight,
    counts: {
      total: w.items.length,
      canary: w.items.filter((i) => i.isCanary).length,
      applied: w.items.filter((i) => i.status === 'APPLIED').length,
      failed: w.items.filter((i) => i.status === 'FAILED').length,
      skipped: w.items.filter((i) => i.status === 'SKIPPED').length,
      pending: w.items.filter((i) => i.status === 'PREFLIGHT_OK' || i.status === 'PENDING').length,
    },
  }
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const plant = await resolvePlant(new URL(req.url).searchParams.get('plantId') ?? undefined) // v16.12 W10: impianto ATTIVO dal selettore
  if (!plant.ok) return plant.response

  const waves = await db.configWave.findMany({
    where: { plantId: plant.plant.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: { items: { select: { status: true, isCanary: true, batchNumber: true } } },
  })

  const data = {
    items: waves.map(toWaveRow),
    total: waves.length,
    executionAvailable: false as const, // D2: motore di esecuzione non attivo in riproduzione
  }
  const asOf = maxOf(...waves.map((w) => w.createdAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(WavesPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ---------------- POST: creazione + PREFLIGHT ---------------- */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = CreateWaveInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const plant = await resolvePlant(new URL(req.url).searchParams.get('plantId') ?? undefined) // v16.12 W10: impianto ATTIVO dal selettore
  if (!plant.ok) return plant.response
  const plantId = plant.plant.id
  const email = session.session.user.email ?? 'sconosciuto'

  /* target reali dell'impianto (v16.12 W10: perimetro plantId diretto) */
  const rows = await db.device.findMany({
    where: { id: { in: input.deviceIds }, plantId },
    select: {
      id: true, hostname: true, status: true, decommissionedAt: true,
      credentialState: true, username: true, password: true,
      snmpCommunityEnc: true, snmpV3Username: true,
    },
  })
  const byId = new Map(rows.map((r) => [r.id, r]))

  const preflight: Array<{ deviceId: string; hostname: string; ok: boolean; reason: string }> = []
  for (const deviceId of input.deviceIds) {
    const r = byId.get(deviceId)
    if (!r) {
      preflight.push({ deviceId, hostname: deviceId, ok: false, reason: 'dispositivo inesistente o fuori dall\'impianto' })
      continue
    }
    const inMaintenance = await inActiveMaintenance(plantId, deviceId)
    const hasCredentials = !!(r.username || r.password || r.snmpCommunityEnc || r.snmpV3Username)
    const v = preflightDevice({
      deviceId, decommissionedAt: r.decommissionedAt, inMaintenance,
      hasCredentials, credentialState: r.credentialState, status: r.status,
    })
    preflight.push({ deviceId, hostname: r.hostname, ok: v.ok, reason: v.reason })
  }

  const validIds = preflight.filter((p) => p.ok).map((p) => p.deviceId)
  const batches = planWaveBatches(validIds, { batchSize: input.batchSize, canarySize: input.canarySize })

  const now = new Date()
  const created = await db.$transaction(async (tx) => {
    const wave = await tx.configWave.create({
      data: {
        plantId,
        name: input.name,
        kind: input.kind,
        action: input.action ?? '',
        batchSize: input.batchSize ?? 5,
        canarySize: input.canarySize ?? 1,
        stopOnFirstFailure: input.stopOnFirstFailure ?? true,
        dryRun: input.dryRun ?? true,
        status: 'DRAFT', // SOLO pianificazione: l'avvio richiede il motore (D2)
        preflight: JSON.stringify(preflight),
        createdBy: email,
      },
    })
    for (const b of batches) {
      for (const deviceId of b.deviceIds) {
        await tx.configWaveItem.create({
          data: { waveId: wave.id, deviceId, batchNumber: b.number, isCanary: b.isCanary, status: 'PREFLIGHT_OK' },
        })
      }
    }
    await tx.auditLog.create({
      data: {
        action: 'WAVE_CREATED',
        actor: email,
        targetId: wave.id,
        targetLabel: wave.name.slice(0, 80),
        plantId,
        details: JSON.stringify({
          name: input.name, kind: input.kind,
          targets: input.deviceIds.length, validTargets: validIds.length,
          scarti: preflight.filter((p) => !p.ok).length, batches: batches.length,
          canary: batches[0]?.deviceIds.length ?? 0,
        }),
      },
    })
    return wave
  })

  const wave = await db.configWave.findUnique({
    where: { id: created.id },
    include: { items: { select: { status: true, isCanary: true, batchNumber: true } } },
  })
  const row = wave ? toWaveRow(wave) : null
  const replay = await getReplayState()
  const mode = apiMode(replay)
  if (row) devValidate(WaveRowSchema, row)
  return NextResponse.json(
    {
      ok: true as const, asOf: now.getTime(), mode,
      data: {
        wave: row,
        preflight,
        batches: batches.map((b) => ({ number: b.number, deviceIds: b.deviceIds, isCanary: b.isCanary })),
        scarti: preflight.filter((p) => !p.ok).length,
      },
    },
    { status: 201 },
  )
}
