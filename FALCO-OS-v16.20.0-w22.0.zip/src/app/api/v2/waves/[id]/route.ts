/* ================================================================
 * /api/v2/waves/[id] — DELETE — 16.9.0 W4
 * Eliminazione ondata: consentita SOLO su DRAFT (nessuna esecuzione
 * è mai partita in riproduzione — D2; eliminare una ondata in altri
 * stati richiederebbe il congelamento del report, non disponibile).
 * 404 se inesistente; 422 INVALID_STATE altrimenti; audit
 * WAVE_DELETED con counts al momento dell'eliminazione.
 * Gli item vengono rimossi a cascata (onDelete: Cascade).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { WaveDeletedSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.configWave.findUnique({
    where: { id },
    include: { items: { select: { status: true } } },
  })
  if (!existing) return fail('NOT_FOUND', 'Ondata non trovata', 404)

  if (existing.status !== 'DRAFT') {
    return fail('INVALID_STATE', `Eliminazione consentita solo su ondata DRAFT (stato attuale: ${existing.status})`, 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()
  const data = { deleted: true as const, id }

  await db.$transaction(async (tx) => {
    await tx.configWave.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'WAVE_DELETED',
        actor: email,
        targetId: id,
        targetLabel: existing.name.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({
          name: existing.name,
          items: existing.items.length,
          pending: existing.items.filter((i) => i.status === 'PREFLIGHT_OK' || i.status === 'PENDING').length,
        }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(WaveDeletedSchema, { ok: true as const, asOf: now.getTime(), mode, data })
  return ok(data, now.getTime(), mode)
}
