/* ================================================================
 * /api/v2/event-policies/{id} — PATCH (taratura/modifica) + DELETE
 * (16.7 W3.5). Operazioni su una regola evento REALE (AlertRule v15)
 * nello scope del plant (404 per id inesistente o di altro impianto).
 *  · PATCH (role ≥ TECNICO): le regole di SISTEMA (systemKey SYS:*,
 *    le 10 reali del DB) ammettono SOLO la taratura operativa
 *    {enabled, threshold, recoveryThreshold, betweenMax, sustainSeconds,
 *    severity, escalateAfterMinutes, cooldownMinutes}: qualunque altro
 *    campo nel corpo GREZZO → 422 SYSTEM_RULE (zod ignora le chiavi
 *    sconosciute, quindi il check è sul corpo prima del parse — mai
 *    input ignorato in silenzio). Le regole utente accettano tutto
 *    tranne systemKey (fuori dallo schema). Validazioni come la POST
 *    calcolate sui valori EFFETTIVI (patch ⊕ regola esistente):
 *    between ⇒ betweenMax > threshold; scope coerente con id REALI
 *    (ALL ⇒ scopeIds vuoto, SITE ⇒ sedi, DEVICE ⇒ dispositivi,
 *    LINK ⇒ collegamenti); deviceTypes ⊆ inventario; nome univoco
 *    per impianto case-insensitive (422 NAME_EXISTS). Patch senza
 *    ALCUN effetto reale → 422 NO_CHANGES. Audit EVENT_POLICY_UPDATE
 *    in TRANSAZIONE con diff {campo: {from, to}} (solo i campi
 *    cambiati davvero).
 *  · DELETE (role ≥ TECNICO): SYS → 422 SYSTEM_RULE (le regole di
 *    sistema non sono eliminabili, motore v15); utente → delete +
 *    audit EVENT_POLICY_DELETE {name, metric}. Se la regola ha
 *    allarmi nello storico (AlertEvent, integrità referenziale) la
 *    cancellazione è rifiutata con 422 RULE_IN_USE (onesto, mai 500).
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateEventPolicyInputSchema, EventPolicyRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import {
  devValidate, resolvePlant, offendingDeviceIds, parseDaysOfWeek,
} from '@/app/api/v2/shared'
import { toEventPolicyRow, parseJsonStringArray } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

/** Taratura operativa ammessa sulle regole SYS:* (motore v15): tutto
 *  il resto (nome, metrica, scope, confronto…) è struttura del motore
 *  e NON si tocca da qui. */
const SYS_TUNABLE_KEYS = new Set([
  'enabled', 'threshold', 'recoveryThreshold', 'betweenMax', 'sustainSeconds',
  'severity', 'escalateAfterMinutes', 'cooldownMinutes',
])

/** Chiavi presenti nel corpo GREZZO (zod ignora le chiavi sconosciute:
 *  la semantica conta, quindi il check è prima del parse). */
function rawBodyKeys(rawBody: unknown): string[] {
  if (rawBody && typeof rawBody === 'object' && !Array.isArray(rawBody)) {
    return Object.keys(rawBody as Record<string, unknown>)
  }
  return []
}

/** Confronto insiemistico (ordine irrilevante): rispecificare lo
 *  STESSO insieme non è una modifica. */
function sameSet(a: string[], b: string[]): boolean {
  if (a.length !== b.length) return false
  const sa = [...a].sort()
  const sb = [...b].sort()
  return sa.every((v, i) => v === sb[i])
}

function notFound() {
  return fail('NOT_FOUND', 'Regola evento non trovata in questo impianto', 404)
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo della regola)', 422)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const rule = await db.alertRule.findFirst({ where: { id, plantId: p.id } })
  if (!rule) return notFound()

  /* --- SYS: SOLO taratura operativa (check sul corpo GREZZO, PRIMA
   *      del parse zod: un campo strutturale presente — anche con
   *      valore illegale — è già una violazione SYSTEM_RULE, non un
   *      generico BAD_BODY). --- */
  const isSys = rule.systemKey != null
  if (isSys) {
    const illegal = rawBodyKeys(rawBody).filter((k) => !SYS_TUNABLE_KEYS.has(k))
    if (illegal.length > 0) {
      return fail('SYSTEM_RULE', 'le regole di sistema ammettono solo la taratura operativa', 422, [
        {
          path: illegal[0],
          message: `Campo non ammesso su una regola di sistema (SYS:*): ${illegal.join(', ')}. Taratura consentita: ${[...SYS_TUNABLE_KEYS].join(', ')}.`,
        },
      ])
    }
  }

  const parsed = UpdateEventPolicyInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* --- Valori EFFETTIVI (patch ⊕ regola esistente) --- */
  const cur = {
    name: rule.name,
    description: rule.description,
    enabled: rule.enabled,
    metric: rule.metric,
    deviceTypes: parseJsonStringArray(rule.deviceTypes),
    scopeType: rule.scopeType,
    scopeIds: parseJsonStringArray(rule.scopeIds),
    comparison: rule.comparison,
    threshold: rule.threshold,
    recoveryThreshold: rule.recoveryThreshold,
    betweenMax: rule.betweenMax,
    sustainSeconds: rule.sustainSeconds,
    severity: rule.severity,
    escalateAfterMinutes: rule.escalateAfterMinutes,
    cooldownMinutes: rule.cooldownMinutes,
    maintenanceDays: parseDaysOfWeek(rule.maintenanceDays),
  }
  const effDeviceTypes = input.deviceTypes !== undefined ? Array.from(new Set(input.deviceTypes)) : cur.deviceTypes
  const effScopeType = input.scopeType ?? cur.scopeType
  const effScopeIds = input.scopeIds !== undefined ? Array.from(new Set(input.scopeIds)) : cur.scopeIds
  const effComparison = input.comparison ?? cur.comparison
  const effThreshold = input.threshold ?? cur.threshold
  const effBetweenMax = input.betweenMax !== undefined ? input.betweenMax : cur.betweenMax

  /* --- between ⇒ betweenMax > threshold (anche combinando con la
   *      regola esistente: il check è sul risultato finale) --- */
  if (effComparison === 'between') {
    if (effBetweenMax == null) {
      return fail('BAD_BODY', 'Il confronto «between» richiede betweenMax', 422, [
        { path: 'betweenMax', message: 'betweenMax è obbligatorio quando il confronto è «between»' },
      ])
    }
    if (!(effBetweenMax > effThreshold)) {
      return fail('BAD_BODY', 'betweenMax deve essere maggiore di threshold', 422, [
        { path: 'betweenMax', message: `betweenMax (${effBetweenMax}) deve essere > threshold (${effThreshold})` },
      ])
    }
  }

  /* --- Validazioni come la POST, sui valori presenti --- */
  if (input.deviceTypes !== undefined && effDeviceTypes.length > 0) {
    const rows = await db.device.findMany({
      where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
      select: { type: true },
      distinct: ['type'],
    })
    const known = new Set(rows.map((r) => r.type))
    const unknown = effDeviceTypes.filter((t) => !known.has(t))
    if (unknown.length > 0) {
      return fail('BAD_BODY', 'Alcuni tipi dispositivo indicati non esistono nell\'inventario dell\'impianto', 422, [
        { path: 'deviceTypes', message: `Tipi non presenti nell'inventario (mostrati al massimo 5 su ${unknown.length})`, unknownTypes: unknown.slice(0, 5) },
      ])
    }
  }
  if (effScopeType === 'ALL' && effScopeIds.length > 0) {
    return fail('BAD_BODY', 'Lo scope ALL copre già tutto l\'impianto: scopeIds deve essere vuoto o assente', 422, [
      { path: 'scopeIds', message: `Con scopeType ALL non si indicano id (${effScopeIds.length} effettivi)` },
    ])
  }
  if (effScopeType === 'SITE' && effScopeIds.length > 0 && (input.scopeIds !== undefined || input.scopeType !== undefined)) {
    const found = await db.location.findMany({ where: { plantId: p.id, id: { in: effScopeIds } }, select: { id: true } })
    const foundSet = new Set(found.map((f) => f.id))
    const unknown = effScopeIds.filter((sid) => !foundSet.has(sid))
    if (unknown.length > 0) {
      return fail('BAD_BODY', 'Alcune sedi indicate non esistono in questo impianto', 422, [
        { path: 'scopeIds', message: `Id sede non validi (mostrati al massimo 5 su ${unknown.length})`, unknownLocationIds: unknown.slice(0, 5) },
      ])
    }
  }
  if (effScopeType === 'DEVICE' && effScopeIds.length > 0 && (input.scopeIds !== undefined || input.scopeType !== undefined)) {
    const offending = await offendingDeviceIds(p.id, effScopeIds)
    if (offending.length > 0) {
      return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
        { path: 'scopeIds', message: `Id dispositivo non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
      ])
    }
  }
  if (effScopeType === 'LINK' && effScopeIds.length > 0 && (input.scopeIds !== undefined || input.scopeType !== undefined)) {
    const found = await db.topologyLink.findMany({ where: { plantId: p.id, id: { in: effScopeIds } }, select: { id: true } })
    const foundSet = new Set(found.map((f) => f.id))
    const unknown = effScopeIds.filter((sid) => !foundSet.has(sid))
    if (unknown.length > 0) {
      return fail('BAD_BODY', 'Alcuni collegamenti indicati non esistono in questo impianto', 422, [
        { path: 'scopeIds', message: `Id collegamento non validi (mostrati al massimo 5 su ${unknown.length})`, unknownLinkIds: unknown.slice(0, 5) },
      ])
    }
  }

  /* --- Diff calcolato PRIMA della scrittura: una patch senza ALCUN
   *      effetto reale → 422 NO_CHANGES esplicito (mai no-op
   *      silenzioso). I campi uguali allo stato attuale non sono
   *      modifiche. --- */
  const nameChanged = input.name !== undefined && input.name !== cur.name
  const descriptionChanged = input.description !== undefined && input.description !== cur.description
  const enabledChanged = input.enabled !== undefined && input.enabled !== cur.enabled
  const metricChanged = input.metric !== undefined && input.metric !== cur.metric
  const deviceTypesChanged = input.deviceTypes !== undefined && !sameSet(input.deviceTypes, cur.deviceTypes)
  const scopeTypeChanged = input.scopeType !== undefined && input.scopeType !== cur.scopeType
  const scopeIdsChanged = input.scopeIds !== undefined && !sameSet(input.scopeIds, cur.scopeIds)
  const comparisonChanged = input.comparison !== undefined && input.comparison !== cur.comparison
  const thresholdChanged = input.threshold !== undefined && input.threshold !== cur.threshold
  const recoveryThresholdChanged = input.recoveryThreshold !== undefined && input.recoveryThreshold !== cur.recoveryThreshold
  const betweenMaxChanged = input.betweenMax !== undefined && input.betweenMax !== cur.betweenMax
  const sustainSecondsChanged = input.sustainSeconds !== undefined && input.sustainSeconds !== cur.sustainSeconds
  const severityChanged = input.severity !== undefined && input.severity !== cur.severity
  const escalateChanged = input.escalateAfterMinutes !== undefined && input.escalateAfterMinutes !== cur.escalateAfterMinutes
  const cooldownChanged = input.cooldownMinutes !== undefined && input.cooldownMinutes !== cur.cooldownMinutes
  if (
    !nameChanged && !descriptionChanged && !enabledChanged && !metricChanged && !deviceTypesChanged
    && !scopeTypeChanged && !scopeIdsChanged && !comparisonChanged && !thresholdChanged
    && !recoveryThresholdChanged && !betweenMaxChanged && !sustainSecondsChanged
    && !severityChanged && !escalateChanged && !cooldownChanged
  ) {
    return fail('NO_CHANGES', 'Nessun campo modificato: la patch non ha alcun effetto sulla regola (stato già conforme alla richiesta)', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + audit in transazione interattiva --- */
  const result = await db.$transaction(async (tx) => {
    /* nome cambiato → univocità per impianto (esclusa la regola stessa) */
    if (nameChanged) {
      const siblings = await tx.alertRule.findMany({
        where: { plantId: p.id, id: { not: rule.id } },
        select: { name: true },
      })
      if (siblings.some((s) => s.name.toLowerCase() === input.name!.toLowerCase())) {
        return { kind: 'exists' as const }
      }
    }

    const data: Prisma.AlertRuleUpdateInput = {}
    if (nameChanged) data.name = input.name!
    if (descriptionChanged) data.description = input.description!
    if (enabledChanged) data.enabled = input.enabled!
    if (metricChanged) data.metric = input.metric!
    if (deviceTypesChanged) data.deviceTypes = JSON.stringify(effDeviceTypes)
    if (scopeTypeChanged) data.scopeType = input.scopeType!
    if (scopeIdsChanged) data.scopeIds = JSON.stringify(effScopeIds)
    if (comparisonChanged) data.comparison = input.comparison!
    if (thresholdChanged) data.threshold = input.threshold!
    if (recoveryThresholdChanged) data.recoveryThreshold = input.recoveryThreshold
    if (betweenMaxChanged) data.betweenMax = input.betweenMax
    if (sustainSecondsChanged) data.sustainSeconds = input.sustainSeconds!
    if (severityChanged) data.severity = input.severity!
    if (escalateChanged) data.escalateAfterMinutes = input.escalateAfterMinutes!
    if (cooldownChanged) data.cooldownMinutes = input.cooldownMinutes!

    const updated = await tx.alertRule.update({ where: { id: rule.id }, data })

    /* Diff sintetico: SOLO ciò che è cambiato davvero {campo: from→to} */
    const changes: Record<string, unknown> = {}
    if (nameChanged) changes.name = { from: cur.name, to: input.name }
    if (descriptionChanged) changes.description = { from: cur.description.slice(0, 80), to: input.description!.slice(0, 80) }
    if (enabledChanged) changes.enabled = { from: cur.enabled, to: input.enabled }
    if (metricChanged) changes.metric = { from: cur.metric, to: input.metric }
    if (deviceTypesChanged) changes.deviceTypes = { from: cur.deviceTypes, to: effDeviceTypes }
    if (scopeTypeChanged) changes.scopeType = { from: cur.scopeType, to: input.scopeType }
    if (scopeIdsChanged) changes.scopeIds = { from: cur.scopeIds, to: effScopeIds }
    if (comparisonChanged) changes.comparison = { from: cur.comparison, to: input.comparison }
    if (thresholdChanged) changes.threshold = { from: cur.threshold, to: input.threshold }
    if (recoveryThresholdChanged) changes.recoveryThreshold = { from: cur.recoveryThreshold, to: input.recoveryThreshold }
    if (betweenMaxChanged) changes.betweenMax = { from: cur.betweenMax, to: input.betweenMax }
    if (sustainSecondsChanged) changes.sustainSeconds = { from: cur.sustainSeconds, to: input.sustainSeconds }
    if (severityChanged) changes.severity = { from: cur.severity, to: input.severity }
    if (escalateChanged) changes.escalateAfterMinutes = { from: cur.escalateAfterMinutes, to: input.escalateAfterMinutes }
    if (cooldownChanged) changes.cooldownMinutes = { from: cur.cooldownMinutes, to: input.cooldownMinutes }

    await tx.auditLog.create({
      data: {
        action: 'EVENT_POLICY_UPDATE',
        actor: email,
        targetId: updated.id,
        targetLabel: updated.name.slice(0, 80),
        plantId: updated.plantId,
        details: JSON.stringify({
          ruleId: updated.id,
          systemKey: updated.systemKey, // presente solo per le SYS (taratura)
          changes,
        }),
      },
    })
    return { kind: 'updated' as const, rule: updated }
  })

  if (result.kind === 'exists') {
    return fail('NAME_EXISTS', `Esiste già una regola evento chiamata «${input.name}» in questo impianto: i nomi sono univoci per impianto (confronto case-insensitive)`, 422)
  }

  const data = toEventPolicyRow(result.rule)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(EventPolicyRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}

/* ================================================================ */

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response

  const { id } = await ctx.params
  const rule = await db.alertRule.findFirst({ where: { id, plantId: plant.plant.id } })
  if (!rule) return notFound()

  /* Le SYS:* sono del motore v15: struttura del sistema, non dati
   * operatore — non si eliminano (si tarano, vedi PATCH). */
  if (rule.systemKey != null) {
    return fail('SYSTEM_RULE', 'le regole di sistema non sono eliminabili (motore v15)', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Delete + audit in transazione. AlertEvent punta alla regola
   *      SENZA cascade (Restrict): una regola con allarmi nello
   *      storico non si cancella — 422 onesto, mai un 500 opaco. --- */
  try {
    await db.$transaction(async (tx) => {
      await tx.alertRule.delete({ where: { id: rule.id } })
      await tx.auditLog.create({
        data: {
          action: 'EVENT_POLICY_DELETE',
          actor: email,
          targetId: rule.id,
          targetLabel: rule.name.slice(0, 80),
          plantId: rule.plantId,
          details: JSON.stringify({
            ruleId: rule.id,
            name: rule.name,
            metric: rule.metric,
          }),
        },
      })
    })
  } catch (e) {
    if ((e as { code?: string }).code === 'P2003') {
      return fail('RULE_IN_USE', 'La regola ha allarmi nello storico (AlertEvent) collegati: non è eliminabile per integrità referenziale', 422)
    }
    throw e
  }

  const data = { id: rule.id }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  return ok(data, now.getTime(), mode)
}
