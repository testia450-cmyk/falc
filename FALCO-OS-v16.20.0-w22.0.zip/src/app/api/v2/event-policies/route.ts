/* ================================================================
 * /api/v2/event-policies — GET (elenco) + POST (creazione, 16.7 W3.5)
 * Regole evento REALI del DB (modello AlertRule v15.11 R7): le 10
 * SYS:* del seed reale (motore allarmi v15) + le regole utente.
 * DB reale: 10 SYS, 0 utente → userCount 0 (onesto, non errore).
 *  · GET: regole del plant, SYS prima (per systemKey asc) poi utente
 *    per name — SQLite porta i NULL in testa in ASC, quindi l'ordine
 *    DOCUMENTATO del contratto è imposto con un riordino stabile in
 *    JS dopo la query. deviceTypes/scopeIds/maintenanceDays sono
 *    JSON-string nel modello → parse difensivo (mai crash su JSON
 *    storico corrotto). total = tutte; systemCount = SYS reali;
 *    userCount = il resto.
 *  · POST (role ≥ TECNICO): crea una regola UTENTE (systemKey null:
 *    le SYS:* nascono solo dal motore v15, mai da qui). Validazioni
 *    su dati REALI dell'inventario: deviceTypes ⊆ tipi distinti dei
 *    dispositivi attivi del plant (422 con offensori); scope SITE →
 *    scopeIds ⊆ sedi del plant; DEVICE → ⊆ dispositivi dello scope;
 *    LINK → ⊆ collegamenti del plant; ALL → scopeIds vuoto o assente
 *    (422). Nome univoco per impianto case-insensitive → 422
 *    NAME_EXISTS (verifica DENTRO la transazione). Defaults dichiarati:
 *    enabled true, scopeType ALL, sustainSeconds 0, severity WARNING,
 *    escalateAfterMinutes 0, cooldownMinutes 30, description "".
 *    Audit EVENT_POLICY_CREATE in TRANSAZIONE (name/metric/comparison/
 *    threshold/severity/scope). 201 con la riga creata.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  EventPoliciesPageSchema, EventPolicyRowSchema, CreateEventPolicyInputSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import {
  devValidate, resolvePlant, maxOf, offendingDeviceIds,
} from '@/app/api/v2/shared'
import { toEventPolicyRow } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const rules = await db.alertRule.findMany({
    where: { plantId: p.id },
    orderBy: [{ systemKey: 'asc' }, { name: 'asc' }],
  })

  /* SYS prima (systemKey asc), poi utente per name: in ASC SQLite
   * ordina i NULL PRIMA delle stringhe, quindi l'ordine del contratto
   * («SYS prima, poi utente») è garantito da questo riordino stabile. */
  const sorted = [...rules].sort((a, b) => {
    const aSys = a.systemKey != null ? 0 : 1
    const bSys = b.systemKey != null ? 0 : 1
    if (aSys !== bSys) return aSys - bSys
    if (aSys === 0) return (a.systemKey ?? '').localeCompare(b.systemKey ?? '', 'it')
    return a.name.localeCompare(b.name, 'it')
  })

  const data = {
    items: sorted.map(toEventPolicyRow),
    total: rules.length,
    systemCount: rules.filter((r) => r.systemKey != null).length, // 10 reali nel DB egidio
    userCount: rules.filter((r) => r.systemKey == null).length, // 0 ora: onesto
  }

  const asOf = maxOf(...rules.map((r) => r.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(EventPoliciesPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, metric, comparison, threshold, … } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name, metric, comparison, threshold)', 422)
  }
  const parsed = CreateEventPolicyInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- deviceTypes: SOLO tipi REALI dell'inventario del plant
   *      (distinti sui dispositivi attivi nello scope, come i gruppi
   *      DYNAMIC: niente regole su tipi fantasma). --- */
  const deviceTypes = input.deviceTypes ? Array.from(new Set(input.deviceTypes)) : []
  if (deviceTypes.length > 0) {
    const rows = await db.device.findMany({
      where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
      select: { type: true },
      distinct: ['type'],
    })
    const known = new Set(rows.map((r) => r.type))
    const unknown = deviceTypes.filter((t) => !known.has(t))
    if (unknown.length > 0) {
      return fail('BAD_BODY', 'Alcuni tipi dispositivo indicati non esistono nell\'inventario dell\'impianto', 422, [
        { path: 'deviceTypes', message: `Tipi non presenti nell'inventario (mostrati al massimo 5 su ${unknown.length})`, unknownTypes: unknown.slice(0, 5) },
      ])
    }
  }

  /* --- Scope: id REALI per tipo di scope (ALL = nessun id) --- */
  const scopeType = input.scopeType ?? 'ALL'
  const scopeIds = input.scopeIds ? Array.from(new Set(input.scopeIds)) : []
  if (scopeType === 'ALL' && scopeIds.length > 0) {
    return fail('BAD_BODY', 'Lo scope ALL copre già tutto l\'impianto: scopeIds deve essere vuoto o assente', 422, [
      { path: 'scopeIds', message: `Con scopeType ALL non si indicano id (${scopeIds.length} ricevuti)` },
    ])
  }
  if (scopeType === 'SITE' && scopeIds.length > 0) {
    const found = await db.location.findMany({ where: { plantId: p.id, id: { in: scopeIds } }, select: { id: true } })
    const foundSet = new Set(found.map((f) => f.id))
    const unknown = scopeIds.filter((id) => !foundSet.has(id))
    if (unknown.length > 0) {
      return fail('BAD_BODY', 'Alcune sedi indicate non esistono in questo impianto', 422, [
        { path: 'scopeIds', message: `Id sede non validi (mostrati al massimo 5 su ${unknown.length})`, unknownLocationIds: unknown.slice(0, 5) },
      ])
    }
  }
  if (scopeType === 'DEVICE' && scopeIds.length > 0) {
    const offending = await offendingDeviceIds(p.id, scopeIds)
    if (offending.length > 0) {
      return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
        { path: 'scopeIds', message: `Id dispositivo non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
      ])
    }
  }
  if (scopeType === 'LINK' && scopeIds.length > 0) {
    const found = await db.topologyLink.findMany({ where: { plantId: p.id, id: { in: scopeIds } }, select: { id: true } })
    const foundSet = new Set(found.map((f) => f.id))
    const unknown = scopeIds.filter((id) => !foundSet.has(id))
    if (unknown.length > 0) {
      return fail('BAD_BODY', 'Alcuni collegamenti indicati non esistono in questo impianto', 422, [
        { path: 'scopeIds', message: `Id collegamento non validi (mostrati al massimo 5 su ${unknown.length})`, unknownLinkIds: unknown.slice(0, 5) },
      ])
    }
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + audit in transazione interattiva: l'univocità del
   *      nome per impianto è case-insensitive (SQLite «=» è case
   *      sensitive → confronto in JS) e verificata DENTRO la
   *      transazione (check+create atomici). --- */
  const result = await db.$transaction(async (tx) => {
    const siblings = await tx.alertRule.findMany({ where: { plantId: p.id }, select: { name: true } })
    const dup = siblings.some((s) => s.name.toLowerCase() === input.name.toLowerCase())
    if (dup) return { kind: 'exists' as const }

    const rule = await tx.alertRule.create({
      data: {
        plantId: p.id,
        name: input.name,
        description: input.description ?? '',
        enabled: true,
        metric: input.metric,
        deviceTypes: JSON.stringify(deviceTypes),
        scopeType,
        scopeIds: JSON.stringify(scopeIds),
        comparison: input.comparison,
        threshold: input.threshold,
        recoveryThreshold: input.recoveryThreshold ?? null,
        betweenMax: input.betweenMax ?? null,
        sustainSeconds: input.sustainSeconds ?? 0,
        severity: input.severity ?? 'WARNING',
        escalateAfterMinutes: input.escalateAfterMinutes ?? 0,
        cooldownMinutes: input.cooldownMinutes ?? 30,
        maintenanceStart: '', // nessuna finestra di manutenzione alla nascita
        maintenanceEnd: '',
        maintenanceDays: '[]',
        systemKey: null, // regola UTENTE: le SYS:* nascono solo dal motore v15
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'EVENT_POLICY_CREATE',
        actor: email,
        targetId: rule.id,
        targetLabel: rule.name.slice(0, 80),
        plantId: rule.plantId,
        details: JSON.stringify({
          ruleId: rule.id,
          name: rule.name,
          metric: rule.metric,
          comparison: rule.comparison,
          threshold: rule.threshold,
          severity: rule.severity,
          scope: `${scopeType}${scopeIds.length > 0 ? ` (${scopeIds.length} id)` : ''}`,
        }),
      },
    })
    return { kind: 'created' as const, rule }
  })

  if (result.kind === 'exists') {
    return fail('NAME_EXISTS', `Esiste già una regola evento chiamata «${input.name}» in questo impianto: i nomi sono univoci per impianto (confronto case-insensitive)`, 422)
  }

  const data = toEventPolicyRow(result.rule)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(EventPolicyRowSchema, data) // risposta singola: valida la riga nella busta
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
