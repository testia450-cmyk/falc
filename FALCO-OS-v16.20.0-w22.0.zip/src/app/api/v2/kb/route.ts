/* ================================================================
 * /api/v2/kb — GET (elenco) + POST (creazione) — 16.9.0 W4
 * Knowledge base per impianto (modello v15 KnowledgeBase, port fedele):
 * articoli con titolo/corpo/tag, origine opzionale da ticket risolto.
 * Nel DB reale: 0 righe → items: [] (onesto, la prima arriva dalla POST).
 *  · GET: filtro q (contains su title/body), ordinamento updatedAt DESC,
 *    take 200 come v15; tags = parse difensivo del JSON;
 *  · POST (role ≥ TECNICO): crea articolo REALE con plantId dell'impianto
 *    risolto, createdBy = email di sessione; audit KB_CREATE.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { KbQuerySchema, KbPageSchema, CreateKbInputSchema, KbArticleRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export function parseTags(raw: string): string[] {
  try {
    const v = JSON.parse(raw)
    if (Array.isArray(v)) return v.map(String).filter(Boolean).slice(0, 10)
    return []
  } catch {
    return []
  }
}

export function toKbRow(r: {
  id: string; plantId: string | null; title: string; body: string;
  tags: string; ticketId: string | null; createdBy: string;
  createdAt: Date; updatedAt: Date;
}) {
  return {
    id: r.id,
    plantId: r.plantId,
    title: r.title,
    body: r.body,
    tags: parseTags(r.tags),
    ticketId: r.ticketId,
    createdBy: r.createdBy,
    createdAt: r.createdAt.getTime(),
    updatedAt: r.updatedAt.getTime(),
  }
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(KbQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response

  const where = {
    plantId: plant.plant.id,
    ...(q.value.q
      ? { OR: [{ title: { contains: q.value.q } }, { body: { contains: q.value.q } }] }
      : {}),
  }
  const rows = await db.knowledgeBase.findMany({
    where,
    orderBy: { updatedAt: 'desc' },
    take: 200,
  })

  const data = {
    items: rows.map(toKbRow),
    total: rows.length,
  }
  const asOf = maxOf(...rows.map((r) => r.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KbPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { title, body, tags? })', 422)
  }
  const parsed = CreateKbInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  const created = await db.$transaction(async (tx) => {
    const a = await tx.knowledgeBase.create({
      data: {
        plantId: plant.plant.id,
        title: input.title,
        body: input.body,
        tags: JSON.stringify(input.tags ?? []),
        createdBy: email,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'KB_CREATE',
        actor: email,
        targetId: a.id,
        targetLabel: a.title.slice(0, 80),
        plantId: plant.plant.id,
        details: JSON.stringify({ articleId: a.id, title: a.title, tags: input.tags ?? [] }),
      },
    })
    return a
  })

  const row = toKbRow(created)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KbArticleRowSchema, row)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data: row }, { status: 201 })
}
