/* ================================================================
 * /api/v2/kb/[id] — PATCH (modifica) + DELETE — 16.9.0 W4
 *  · PATCH (role ≥ TECNICO): title/body/tags con refine almeno-uno
 *    (422 NO_CHANGES se il body è vuoto); 404 se l'articolo non
 *    esiste; audit KB_UPDATE con diff dei campi;
 *  · DELETE (role ≥ TECNICO): 404 se inesistente; audit KB_DELETE.
 * La knowledge base è append-only nel registro audit (come v15).
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateKbInputSchema, KbArticleRowSchema, KbDeletedSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { toKbRow } from '@/app/api/v2/kb/route'

export const dynamic = 'force-dynamic'

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.knowledgeBase.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Articolo non trovato', 404)

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = UpdateKbInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const diff: Record<string, { from: unknown; to: unknown }> = {}
  if (input.title !== undefined && input.title !== existing.title) diff.title = { from: existing.title, to: input.title }
  if (input.body !== undefined && input.body !== existing.body) diff.body = { from: existing.body.slice(0, 80) + '…', to: input.body.slice(0, 80) + '…' }
  if (input.tags !== undefined) diff.tags = { from: existing.tags, to: JSON.stringify(input.tags) }
  if (Object.keys(diff).length === 0) {
    return fail('NO_CHANGES', 'Nessuna modifica effettiva nel payload', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const updated = await db.$transaction(async (tx) => {
    const a = await tx.knowledgeBase.update({
      where: { id },
      data: {
        ...(input.title !== undefined ? { title: input.title } : {}),
        ...(input.body !== undefined ? { body: input.body } : {}),
        ...(input.tags !== undefined ? { tags: JSON.stringify(input.tags) } : {}),
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'KB_UPDATE',
        actor: email,
        targetId: a.id,
        targetLabel: a.title.slice(0, 80),
        plantId: a.plantId,
        details: JSON.stringify({ articleId: a.id, fields: Object.keys(diff) }),
      },
    })
    return a
  })

  const row = toKbRow(updated)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KbArticleRowSchema, row)
  return NextResponse.json({ ok: true as const, asOf: updated.updatedAt.getTime(), mode, data: row })
}

/* ================================================================ */

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.knowledgeBase.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Articolo non trovato', 404)

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()
  const data = { deleted: true as const, id }
  await db.$transaction(async (tx) => {
    await tx.knowledgeBase.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'KB_DELETE',
        actor: email,
        targetId: id,
        targetLabel: existing.title.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({ articleId: id, title: existing.title }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KbDeletedSchema, { ok: true as const, asOf: now.getTime(), mode, data })
  return ok(data, now.getTime(), mode)
}
