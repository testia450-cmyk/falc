/* ================================================================
 * /api/v2/kb/from-ticket — POST — 16.9.0 W4
 * «Conoscenza ripetibile» v15: crea un articolo KB a partire da un
 * ticket (titolo → «KB: <titolo>», corpo = Problema/Soluzione dai
 * campi REALI del ticket, tags = [ticket, priorità], ticketId legato).
 * 404 se il ticket non esiste; audit KB_CREATE con origine dichiarata.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import { KbFromTicketInputSchema, KbArticleRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { toKbRow } from '@/app/api/v2/kb/route'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { ticketId })', 422)
  }
  const parsed = KbFromTicketInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }

  const ticket = await db.ticket.findUnique({ where: { id: parsed.data.ticketId } })
  if (!ticket) return fail('NOT_FOUND', 'Ticket non trovato', 404)

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  const created = await db.$transaction(async (tx) => {
    const a = await tx.knowledgeBase.create({
      data: {
        plantId: ticket.plantId,
        title: `KB: ${ticket.title}`.slice(0, 200),
        body: `Problema:\n${ticket.description}\n\nSoluzione:\n${ticket.resolution || '(da completare)'}`,
        tags: JSON.stringify(['ticket', ticket.priority]),
        ticketId: ticket.id,
        createdBy: email,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'KB_CREATE',
        actor: email,
        targetId: a.id,
        targetLabel: a.title.slice(0, 80),
        plantId: ticket.plantId,
        details: JSON.stringify({ articleId: a.id, fromTicket: ticket.id, ticketTitle: ticket.title }),
      },
    })
    return a
  })

  const row = toKbRow(created)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KbArticleRowSchema, row)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data: row }, { status: 201 })
}
