/* ================================================================
 * /api/v2/search — GET
 * Domanda a cui risponde (§6.1): «Cerco un apparato, una sede o un
 * allarme per nome/indirizzo/testo — cosa c'è che combacia?»
 *  · devices: match su hostname/ip/macAddress/modello (take 8), con
 *    uiStatus derivata (derive di v2, nessuno stato reinventato);
 *  · locations: match su name/identifier con deviceCount REALE
 *    (GROUP BY locationId sui dispositivi dell'impianto);
 *  · alarms: match sul messaggio, SOLO status != CLOSED (take 5).
 * q minimo 2 caratteri (contratto). Nessun campo credenziale.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { SearchQuerySchema, SearchResultsSchema } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(SearchQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const needle = q.value.q.toLowerCase()

  /* --- Dispositivi (hostname/ip/mac/modello) --- */
  const { rows, asOf: rowsAsOf } = await loadDeviceRows(p.id)
  const devices = rows
    .filter((r) =>
      [r.hostname, r.ip, r.macAddress, r.model]
        .some((f) => f.toLowerCase().includes(needle)))
    .sort((a, b) => a.hostname.localeCompare(b.hostname, 'it'))
    .slice(0, 8)
    .map((r) => ({ id: r.id, hostname: r.hostname, ip: r.ip, type: r.type, uiStatus: r.uiStatus }))

  /* --- Sedì (name/identifier) + conteggio dispositivi reale --- */
  const [locations, counts] = await Promise.all([
    db.location.findMany({
      where: {
        plantId: p.id,
        OR: [
          { name: { contains: q.value.q } },
          { identifier: { contains: q.value.q } },
        ],
      },
      orderBy: { name: 'asc' },
      take: 5,
      select: { id: true, name: true, identifier: true, lat: true, lng: true },
    }),
    db.device.groupBy({
      by: ['locationId'],
      where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
      _count: { _all: true },
    }),
  ])
  const countByLocation = new Map(counts.map((c) => [c.locationId, c._count._all]))

  /* --- Allarmi (messaggio, solo non chiusi) --- */
  const alarms = await db.alertEvent.findMany({
    where: { plantId: p.id, status: { not: 'CLOSED' }, message: { contains: q.value.q } },
    orderBy: { openedAt: 'desc' },
    take: 5,
    select: { id: true, severity: true, message: true, deviceId: true, openedAt: true },
  })

  const data = {
    devices,
    locations: locations.map((l) => ({
      id: l.id,
      name: l.name,
      identifier: l.identifier,
      lat: l.lat ?? null,
      lng: l.lng ?? null,
      deviceCount: countByLocation.get(l.id) ?? 0,
    })),
    alarms: alarms.map((a) => ({
      id: a.id,
      severity: a.severity,
      message: a.message,
      deviceId: a.deviceId ?? null,
    })),
  }

  const asOf = maxOf(rowsAsOf, alarms[0]?.openedAt.getTime() ?? null) || Date.now()
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(SearchResultsSchema, body)
  return ok(data, asOf, mode)
}
