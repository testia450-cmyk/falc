/* ================================================================
 * /api/v2/custom-oids — GET (elenco) + POST (creazione, 16.7 W3.5)
 * OID custom SNMP REALI del DB (modello CustomOid v15 fase G4:
 * template OID → DCI applicate ai device dal motore v11.3, NON attivo
 * in riproduzione). CustomOid è GLOBALE (nessun plantId nel modello:
 * un OID tecnico vale per tutta la flotta) → NESSUNO scope impianto,
 * né in GET né in POST. DB reale: 0 righe → total 0 (onesto, non
 * errore: l'operatore non ha ancora creato OID custom).
 *  · GET: tutti gli OID, name asc; appliedCount grezzo dal DB (0 nel
 *    replay: statistiche oneste, mai gonfiate);
 *  · POST (role ≥ TECNICO): crea con zod (nome tecnico + OID numerico
 *    validati dal contratto); name è UNIQUE globale (@@unique) →
 *    conflitto Prisma P2002 → 422 NAME_EXISTS (onesto, mai 500).
 *    Defaults dichiarati: unit "", scale 1, dataType FLOAT,
 *    intervalSec 300, description "", enabled true. Audit
 *    CUSTOM_OID_CREATE in TRANSAZIONE (plantId null: entità globale).
 *    201 con la riga creata.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { CustomOidsPageSchema, CustomOidRowSchema, CreateCustomOidInputSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { toCustomOidRow } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  /* CustomOid è globale (nessun plantId nel modello): elenco intero. */
  const oids = await db.customOid.findMany({ orderBy: { name: 'asc' } })

  const data = {
    items: oids.map(toCustomOidRow),
    total: oids.length, // 0 = nessun OID custom (onesto)
  }

  const asOf = maxOf(...oids.map((o) => o.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CustomOidsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, oid, unit?, scale?, … } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name e oid)', 422)
  }
  const parsed = CreateCustomOidInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + audit in transazione: name è @@unique GLOBALE →
   *      il conflitto arriva come P2002 e diventa 422 NAME_EXISTS
   *      (check+create atomici anche sotto race). --- */
  let created: Awaited<ReturnType<typeof db.customOid.create>>
  try {
    created = await db.$transaction(async (tx) => {
      const o = await tx.customOid.create({
        data: {
          name: input.name,
          oid: input.oid,
          unit: input.unit ?? '',
          scale: input.scale ?? 1,
          dataType: input.dataType ?? 'FLOAT',
          intervalSec: input.intervalSec ?? 300,
          description: input.description ?? '',
          enabled: input.enabled ?? true,
          appliedCount: 0, // onesto: nessuna DCI applicata nel replay
        },
      })
      await tx.auditLog.create({
        data: {
          action: 'CUSTOM_OID_CREATE',
          actor: email,
          targetId: o.id,
          targetLabel: o.name.slice(0, 80),
          plantId: null, // entità GLOBALE: nessun impianto coinvolto
          details: JSON.stringify({
            oidId: o.id,
            name: o.name,
            oid: o.oid,
            dataType: o.dataType,
            unit: o.unit,
            scale: o.scale,
            intervalSec: o.intervalSec,
            enabled: o.enabled,
          }),
        },
      })
      return o
    })
  } catch (e) {
    if ((e as { code?: string }).code === 'P2002') {
      return fail('NAME_EXISTS', `Esiste già un OID custom chiamato «${input.name}»: i nomi sono univoci (globali, non per impianto)`, 422)
    }
    throw e
  }

  const data = toCustomOidRow(created)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CustomOidRowSchema, data) // risposta singola: valida la riga nella busta
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
