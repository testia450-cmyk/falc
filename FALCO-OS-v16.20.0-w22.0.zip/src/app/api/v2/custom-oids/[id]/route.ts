/* ================================================================
 * /api/v2/custom-oids/{id} — PATCH (modifica) + DELETE (16.7 W3.5)
 * Operazioni su un OID custom REALE del DB (CustomOid v15 G4, entità
 * GLOBALE: lookup per id, nessuno scope impianto; 404 per id
 * inesistente).
 *  · PATCH (role ≥ TECNICO): name NON è modificabile (identità
 *    tecnica referenziata dalle DCI — omesso dallo schema): se il
 *    corpo GREZZO lo contiene → 422 esplicito (zod lo ignoerebbe in
 *    silenzio: mai input ignorato quando la semantica conta, stesso
 *    patto di ruleType su device-groups). Patch senza alcun effetto
 *    reale → 422 NO_CHANGES. Audit CUSTOM_OID_UPDATE in TRANSAZIONE
 *    con diff {campo: {from, to}} (solo i campi cambiati davvero).
 *  · DELETE (role ≥ TECNICO): delete + audit CUSTOM_OID_DELETE
 *    {name, oid}. Risponde {id}.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateCustomOidInputSchema, CustomOidRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { toCustomOidRow } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

function notFound() {
  return fail('NOT_FOUND', 'OID custom non trovato', 404)
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo fra oid, unit, scale, dataType, intervalSec, description, enabled)', 422)
  }

  /* name è l'identità tecnica dell'OID (univoca globale, referenziata
   * dalle DCI): NON modificabile — check sul corpo GREZZO perché zod
   * ignora le chiavi sconosciute (mai input ignorato in silenzio). */
  if (rawBody && typeof rawBody === 'object' && !Array.isArray(rawBody)
    && 'name' in (rawBody as Record<string, unknown>)) {
    return fail('BAD_BODY', 'Il campo «name» non è modificabile: è l\'identità tecnica dell\'OID custom. Crea un nuovo OID se serve un nome diverso', 422, [
      { path: 'name', message: 'Campo non modificabile (identità tecnica univoca)' },
    ])
  }

  const parsed = UpdateCustomOidInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const existing = await db.customOid.findUnique({ where: { id } })
  if (!existing) return notFound()

  /* --- Diff PRIMA della scrittura: patch senza ALCUN effetto reale
   *      → 422 NO_CHANGES esplicito (mai no-op silenzioso). --- */
  const oidChanged = input.oid !== undefined && input.oid !== existing.oid
  const unitChanged = input.unit !== undefined && input.unit !== existing.unit
  const scaleChanged = input.scale !== undefined && input.scale !== existing.scale
  const dataTypeChanged = input.dataType !== undefined && input.dataType !== existing.dataType
  const intervalChanged = input.intervalSec !== undefined && input.intervalSec !== existing.intervalSec
  const descriptionChanged = input.description !== undefined && input.description !== existing.description
  const enabledChanged = input.enabled !== undefined && input.enabled !== existing.enabled
  if (
    !oidChanged && !unitChanged && !scaleChanged && !dataTypeChanged
    && !intervalChanged && !descriptionChanged && !enabledChanged
  ) {
    return fail('NO_CHANGES', 'Nessun campo modificato: la patch non ha alcun effetto sull\'OID custom (stato già conforme alla richiesta)', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + audit in transazione --- */
  const updated = await db.$transaction(async (tx) => {
    const data: Prisma.CustomOidUpdateInput = {}
    if (oidChanged) data.oid = input.oid!
    if (unitChanged) data.unit = input.unit!
    if (scaleChanged) data.scale = input.scale!
    if (dataTypeChanged) data.dataType = input.dataType!
    if (intervalChanged) data.intervalSec = input.intervalSec!
    if (descriptionChanged) data.description = input.description!
    if (enabledChanged) data.enabled = input.enabled!

    const o = await tx.customOid.update({ where: { id: existing.id }, data })

    /* Diff sintetico: SOLO ciò che è cambiato davvero */
    const changes: Record<string, unknown> = {}
    if (oidChanged) changes.oid = { from: existing.oid, to: input.oid }
    if (unitChanged) changes.unit = { from: existing.unit, to: input.unit }
    if (scaleChanged) changes.scale = { from: existing.scale, to: input.scale }
    if (dataTypeChanged) changes.dataType = { from: existing.dataType, to: input.dataType }
    if (intervalChanged) changes.intervalSec = { from: existing.intervalSec, to: input.intervalSec }
    if (descriptionChanged) changes.description = { from: existing.description.slice(0, 80), to: input.description!.slice(0, 80) }
    if (enabledChanged) changes.enabled = { from: existing.enabled, to: input.enabled }

    await tx.auditLog.create({
      data: {
        action: 'CUSTOM_OID_UPDATE',
        actor: email,
        targetId: o.id,
        targetLabel: o.name.slice(0, 80),
        plantId: null, // entità GLOBALE: nessun impianto coinvolto
        details: JSON.stringify({ oidId: o.id, name: o.name, changes }),
      },
    })
    return o
  })

  const data = toCustomOidRow(updated)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CustomOidRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}

/* ================================================================ */

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.customOid.findUnique({ where: { id } })
  if (!existing) return notFound()

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Delete + audit in transazione --- */
  await db.$transaction(async (tx) => {
    await tx.customOid.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'CUSTOM_OID_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.name.slice(0, 80),
        plantId: null, // entità GLOBALE: nessun impianto coinvolto
        details: JSON.stringify({
          oidId: existing.id,
          name: existing.name,
          oid: existing.oid,
        }),
      },
    })
  })

  const data = { id: existing.id }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  return ok(data, now.getTime(), mode)
}
