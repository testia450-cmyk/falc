/* ================================================================
 * /api/v2/noc/summary — GET
 * Domanda a cui risponde (§6.1): «Com'è l'impianto in questo momento?»
 * Sintesi NOC: stati dispositivi, apparati video e flussi, link radio
 * (attivi/deboli), allarmi aperti per severità, copertura topologica,
 * salute pipeline e ultimi eventi.
 * Convenzioni oneste (documentate, nessun dato inventato):
 *  · «open» allarmi = status != CLOSED (include quindi i SUPPRESSED,
 *    che sono conteggiati a parte nel campo `suppressed`, sottoinsieme);
 *  · wirelessLinks: attivo = isLinkStatusActive (regola UNICA di
 *    sistema); degraded = link attivo con almeno un endpoint DEGRADED
 *    (sottoinsieme di active); unknown = non attivo; weak = endpoint
 *    radio con segnale uplink ≤ −75 dBm (contatore trasversale);
 *  · cameras = famiglia «apparati video» CAMERA/LPR/NVR (convenzione
 *    unica v2, vedi shared.ts); streamUnknown = mai campionato
 *    cameraStreamAlive (streamDown = ultimo campione = 0);
 *  · NOT_MONITORED/MAINTENANCE sugli apparati video non hanno counter
 *    dedicato nel contratto: restano nel totale, non nei 4 stati.
 * Nessun campo credenziale viene mai selezionato (allowlist DEVICE_COLUMNS).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { NocSummaryQuerySchema, NocSummarySchema } from '@/lib/v2/contracts'
import {
  loadDeviceRows, getCameraStreamMap, getReplayState, apiMode, appVersion,
} from '@/lib/v2/derive'
import { isLinkStatusActive } from '@/lib/domain/link-rules'
import {
  resolvePlant, getPlantLinks, buildPlantTiers, buildPlantReachability,
  computeWeakLinkRows, devValidate, VIDEO_TYPES, maxOf,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(NocSummaryQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const [{ rows, byId, asOf: rowsAsOf }, links, replay] = await Promise.all([
    loadDeviceRows(p.id),
    getPlantLinks(p.id),
    getReplayState(),
  ])

  /* --- Dispositivi per stato e tipo --- */
  const byState = { online: 0, degraded: 0, offline: 0, maintenance: 0, unknown: 0, notMonitored: 0 }
  const byType: Record<string, number> = {}
  for (const r of rows) {
    if (r.uiStatus === 'ONLINE') byState.online++
    else if (r.uiStatus === 'DEGRADED') byState.degraded++
    else if (r.uiStatus === 'OFFLINE') byState.offline++
    else if (r.uiStatus === 'MAINTENANCE') byState.maintenance++
    else if (r.uiStatus === 'UNKNOWN') byState.unknown++
    else if (r.uiStatus === 'NOT_MONITORED') byState.notMonitored++
    byType[r.type] = (byType[r.type] ?? 0) + 1
  }

  /* --- Apparati video e stato flusso (ultimo campione reale) --- */
  const camMap = await getCameraStreamMap(p.id)
  let camOnline = 0, camDegraded = 0, camOffline = 0, camUnknown = 0
  let streamDown = 0, streamUnknown = 0
  let lastStreamAt = 0
  for (const c of rows.filter((r) => VIDEO_TYPES.includes(r.type))) {
    const entry = camMap.byDevice.get(c.id)
    // entry.at > 0 ⇔ esiste davvero un campione cameraStreamAlive
    const alive = entry && entry.at > 0 ? entry.alive : null
    if (alive === false) streamDown++
    if (alive === null) streamUnknown++
    if (entry && entry.at > lastStreamAt) lastStreamAt = entry.at
    if (c.uiStatus === 'ONLINE') camOnline++
    else if (c.uiStatus === 'DEGRADED') camDegraded++
    else if (c.uiStatus === 'OFFLINE') camOffline++
    else if (c.uiStatus === 'UNKNOWN') camUnknown++
  }

  /* --- Link wireless/radio (solo TopologyLink del plant) --- */
  const tiers = buildPlantTiers(rows, links, p.topologyRootDeviceId)
  const reach = buildPlantReachability(rows, links)
  const wireless = links.filter((l) => {
    const t = (l.linkType || '').toUpperCase()
    return t === 'WIRELESS' || t === 'RADIO'
  })
  let wlActive = 0, wlDegraded = 0
  for (const l of wireless) {
    if (!isLinkStatusActive(l.linkStatus)) continue
    wlActive++
    const endpoints = [l.sourceDeviceId, l.targetDeviceId]
    if (endpoints.some((id) => (id ? byId.get(id)?.uiStatus : undefined) === 'DEGRADED')) wlDegraded++
  }
  const wlUnknown = wireless.length - wlActive
  const weakRows = computeWeakLinkRows(rows, tiers, reach)
  const wlWeak = weakRows.filter((w) => w.signalDbm <= -75).length

  /* --- Allarmi aperti (status != CLOSED) --- */
  const [sevGroups, suppressedCount, oldestOpen, alarmsMaxUpdated] = await Promise.all([
    db.alertEvent.groupBy({
      by: ['severity'],
      _count: { _all: true },
      where: { plantId: p.id, status: { not: 'CLOSED' } },
    }),
    db.alertEvent.count({ where: { plantId: p.id, status: 'SUPPRESSED' } }),
    db.alertEvent.findFirst({
      where: { plantId: p.id, status: { not: 'CLOSED' } },
      orderBy: { openedAt: 'asc' },
      select: { openedAt: true },
    }),
    db.alertEvent.aggregate({
      where: { plantId: p.id, status: { not: 'CLOSED' } },
      _max: { updatedAt: true },
    }),
  ])
  const bySeverity: Record<string, number> = {}
  let openAlarms = 0
  for (const g of sevGroups) {
    const n = g._count._all
    bySeverity[g.severity] = n
    openAlarms += n
  }
  const oldestOpenMinutes = oldestOpen?.openedAt
    ? Math.max(0, Math.round((Date.now() - oldestOpen.openedAt.getTime()) / 60000))
    : null

  /* --- Copertura topologica (ultimo snapshot reale) --- */
  const coverageSnap = await db.topologyCoverageSnapshot.findFirst({
    where: { plantId: p.id },
    orderBy: { createdAt: 'desc' },
  })
  const coverage = coverageSnap
    ? {
        certain: coverageSnap.certain,
        uncertain: coverageSnap.uncertain,
        unknown: coverageSnap.unknown,
        coveragePct: coverageSnap.coveragePct,
        goalPct: coverageSnap.goalPct,
        goalMet: coverageSnap.goalMet,
      }
    : null

  /* --- Pipeline / salute --- */
  let dbReachable = true
  try {
    await db.plant.count()
  } catch {
    dbReachable = false
  }

  /* --- Eventi recenti (join hostname) --- */
  const recentEvents = await db.deviceEvent.findMany({
    where: { device: { plantId: p.id } }, // v16.12 W10: scope per plantId diretto
    orderBy: { createdAt: 'desc' },
    take: 8,
    include: { device: { select: { hostname: true } } },
  })

  const asOf = maxOf(
    rowsAsOf,
    lastStreamAt,
    recentEvents[0]?.createdAt.getTime() ?? null,
    coverageSnap?.createdAt.getTime() ?? null,
    alarmsMaxUpdated._max.updatedAt?.getTime() ?? null,
  ) || Date.now()

  const data = {
    plant: {
      id: p.id,
      name: p.name,
      comune: p.comune,
      pingIntervalSec: p.pingIntervalSec,
      mapCenterLat: p.mapCenterLat,
      mapCenterLng: p.mapCenterLng,
      mapZoom: p.mapZoom,
    },
    devices: { total: rows.length, byState, byType },
    cameras: {
      total: rows.filter((r) => VIDEO_TYPES.includes(r.type)).length,
      online: camOnline,
      degraded: camDegraded,
      offline: camOffline,
      unknown: camUnknown,
      streamDown,
      streamUnknown,
    },
    wirelessLinks: {
      total: wireless.length,
      active: wlActive,
      degraded: wlDegraded,
      weak: wlWeak,
      unknown: wlUnknown,
    },
    alarms: {
      open: openAlarms,
      bySeverity,
      suppressed: suppressedCount,
      oldestOpenMinutes,
    },
    coverage,
    pipeline: {
      realtimeConnected: replay.enabled,
      lastTickAt: replay.lastTickAt,
      dbReachable,
      version: appVersion(),
    },
    recentEvents: recentEvents.map((e) => ({
      id: e.id,
      deviceId: e.deviceId,
      deviceHostname: e.device?.hostname ?? null,
      eventType: e.eventType,
      oldValue: e.oldValue ?? '',
      newValue: e.newValue ?? '',
      source: e.source ?? '',
      createdAt: e.createdAt.getTime(),
    })),
  }

  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(NocSummarySchema, body)
  return ok(data, asOf, mode)
}
