/* ================================================================
 * /api/v2/system/health — GET
 * Domanda a cui risponde (§6.1): «Il sistema è vivo? DB raggiungibile,
 * servizio realtime attivo, ultima scrittura?»
 *  · replay: heartbeat del mini-service realtime (file state.json,
 *    onesto per costruzione: enabled ⇔ tick recente);
 *  · dbReachable: prova reale (COUNT su Plant);
 *  · version: versione REALE del build (package.json);
 *  · lastDbWrite: MAX(Device.updatedAt) reale;
 *  · realtimeUrl: path relativo documentato con la porta del servizio
 *    realtime nel parametro XTransformPort (la porta non appare MAI
 *    altrove nel corpo della risposta).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession } from '@/lib/v2/api-helpers'
import { SystemHealthSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode, appVersion } from '@/lib/v2/derive'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET() {
  const session = await requireSession()
  if (!session.ok) return session.response

  const replay = await getReplayState()

  let dbReachable = false
  try {
    await db.plant.count()
    dbReachable = true
  } catch {
    dbReachable = false
  }

  let lastDbWrite: number | null = null
  if (dbReachable) {
    try {
      const agg = await db.device.aggregate({ _max: { updatedAt: true } })
      lastDbWrite = agg._max.updatedAt?.getTime() ?? null
    } catch {
      lastDbWrite = null
    }
  }

  const data = {
    version: appVersion(),
    dbReachable,
    realtimeUrl: '/?XTransformPort=3001',
    replay: {
      enabled: replay.enabled,
      importedAt: replay.importedAt,
      lastTickAt: replay.lastTickAt,
      nextTickAt: replay.nextTickAt,
      intervalSec: replay.intervalSec,
    },
    lastDbWrite,
  }

  const asOf = lastDbWrite ?? Date.now()
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(SystemHealthSchema, body)
  return ok(data, asOf, mode)
}
