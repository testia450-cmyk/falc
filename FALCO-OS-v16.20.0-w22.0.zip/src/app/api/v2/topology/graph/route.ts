/* ================================================================
 * /api/v2/topology/graph — GET
 * Domanda a cui risponde (§6.1): «Com'è strutturata la rete dell'impianto
 * (albero dal gateway, tier, blocchi) e quali collegamenti lo compongono?»
 * UNICA logica di albero: computeNetworkTiers (§6.2) su TierEdgeInput
 * costruiti dai TopologyLink reali (link con endpoint null scartati;
 * manuale ⇔ SOT in MANUAL_LINK_SOTS o conferma tecnico).
 *  · rootSource: 'operator' se Plant.topologyRootDeviceId è stato usato
 *    come radice, 'inferred' se la radice è stata inferita (pickGateway),
 *    'none' se nessun gateway;
 *  · edges: SOLO l'archi dell'albero (treePairs); per ogni coppia si
 *    recupera il TopologyLink originale (match in entrambe le direzioni,
 *    preferendo quello con stato ATTIVO) per linkType/linkStatus/
 *    confidence/evidence/speed/traffic/label; direzione source=upstream;
 *  · downstreamCount/unreachableCount dal grafo di raggiungibilità
 *    (link ATTIVI, BFS multi-sorgente);
 *  · blocks: buildNetworkBlocks (etichetta dal tipo dominante per tier).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { ok, requireSession, parseQuery, fail } from '@/lib/v2/api-helpers'
import { TopologyGraphQuerySchema, TopologyGraphSchema, LINK_SOURCES, DEFAULT_GRAPH_SOURCES } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { isLinkStatusActive, MANUAL_LINK_SOTS } from '@/lib/domain/link-rules'
import { buildNetworkBlocks } from '@/lib/domain/tiers'
import {
  resolvePlant, getPlantLinks, buildPlantTiers, buildPlantReachability,
  devValidate, maxOf, type PlantLinkRow,
} from '@/app/api/v2/shared'

/** Ordine di famiglia per il raggruppamento visivo (vedi sort dei nodi). */
const TYPE_RANK: Record<string, number> = {
  GATEWAY: 0, ROUTER: 1, FIREWALL: 2, SWITCH: 3,
  AP: 10, STA: 11,
  NVR: 20, CAMERA: 21, LPR: 22,
  SERVER: 30,
}

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(TopologyGraphQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- 16.10: fonti ammesse per l'albero (default: operatore +
   * protocolli + UISP). Fonti sconosciute → 422 onesto. Un link
   * CONFERMATO dall'operatore entra SEMPRE (verità > filtro). --- */
  const sourcesSet = new Set<string>(
    (q.value.sources ?? DEFAULT_GRAPH_SOURCES.join(','))
      .split(',')
      .map((s) => s.trim().toUpperCase())
      .filter((s) => s.length > 0),
  )
  for (const s of sourcesSet) {
    if (!(LINK_SOURCES as readonly string[]).includes(s)) {
      return fail('BAD_QUERY', `Fonte non valida: ${s} (ammesse: ${LINK_SOURCES.join(', ')})`, 422)
    }
  }

  const replay = await getReplayState()
  const [{ rows, byId, asOf: rowsAsOf }, allLinks] = await Promise.all([
    loadDeviceRows(p.id),
    getPlantLinks(p.id),
  ])

  /* --- filtra per fonte: included = fonte selezionata OPPURE
   * confermato dall'operatore (confirmed=true batte ogni filtro) --- */
  const included: PlantLinkRow[] = []
  let excludedInferred = 0
  let confirmedAlwaysIn = 0
  for (const l of allLinks) {
    const sot = (l.sourceOfTruth || 'ALTRO').toUpperCase()
    const isConfirmed = l.confirmed || sot === 'TECHNICIAN'
    if (isConfirmed && !sourcesSet.has(sot)) {
      // verità dell'operatore: entra SEMPRE anche fuori dalle fonti scelte
      confirmedAlwaysIn += 1
      included.push(l)
    } else if (sourcesSet.has(sot)) {
      included.push(l)
    } else {
      excludedInferred += 1
    }
  }
  const links = included

  const tiers = buildPlantTiers(rows, links, p.topologyRootDeviceId)
  const reach = buildPlantReachability(rows, links)

  /* --- Indice link per coppia (per arricchire gli archi dell'albero) --- */
  const pairKey = (a: string, b: string): string => (a < b ? `${a}::${b}` : `${b}::${a}`)
  const linkByPair = new Map<string, PlantLinkRow>()
  for (const l of links) {
    if (!l.sourceDeviceId || !l.targetDeviceId || l.sourceDeviceId === l.targetDeviceId) continue
    const key = pairKey(l.sourceDeviceId, l.targetDeviceId)
    const cur = linkByPair.get(key)
    // preferisci il link con stato ATTIVO (più fresco), altrimenti il primo
    if (!cur || (!isLinkStatusActive(cur.linkStatus) && isLinkStatusActive(l.linkStatus))) {
      linkByPair.set(key, l)
    }
  }

  /* --- Nodi (tier + parent dall'albero, uiStatus dai derive) --- */
  const nodes = rows
    .map((r) => ({
      id: r.id,
      hostname: r.hostname,
      ip: r.ip,
      type: r.type,
      uiStatus: r.uiStatus,
      tier: tiers.tierOf.get(r.id) ?? -1,
      // parentId solo se il parent è un nodo esposto (mai un «fantasma»)
      parentId: ((): string | null => {
        const pid = tiers.parentOf.get(r.id)
        return pid && byId.has(pid) ? pid : null
      })(),
      locationId: r.locationId,
      locationName: r.locationName,
      model: r.model,
      signalDbm: r.signalPresent ? r.signalStrength : null,
      linkQuality: r.linkQuality,
      downstreamCount: reach.downstream.get(r.id)?.length ?? 0,
    }))
    /* Ordine = ordine di inserimento nel layout ELK: raggruppa per tier e
     * per famiglia (infrastruttura → radio → apparati video → altro):
     * nella rete reale (stella L2 piatta: 163 vicini diretti del gateway,
     * vedi audit) produce cluster visivi leggibili invece di un nastro
     * sparso di 163 card. Nessun nodo inventato: solo ordine di disegno. */
    .sort((a, b) => {
      if (a.tier !== b.tier) return a.tier - b.tier
      const ra = TYPE_RANK[a.type] ?? 90
      const rb = TYPE_RANK[b.type] ?? 90
      if (ra !== rb) return ra - rb
      return a.hostname.localeCompare(b.hostname, 'it')
    })

  /* --- Archi SOLO dell'albero (source = upstream) ---
   * Nota onesta: 2 link reali puntano a dispositivi SENZA sede (locationId
   * null → fuori dallo scope impianto, invisibili a ogni endpoint v2):
   * quegli archi produrrebbero nodi «fantasma» nel grafo UI, quindi si
   * espongono solo le coppie con entrambi gli endpoint nell'inventario
   * del plant (l'albero è comunque calcolato dal motore su TUTTI i link). */
  const edges = Array.from(tiers.treePairs)
    .filter((key) => {
      const [a, b] = key.split('::')
      return byId.has(a) && byId.has(b)
    })
    .map((key) => {
      const [a, b] = key.split('::')
      // direzione: il parente a monte è il source (semantica repo)
      let source = a
      let target = b
      if (tiers.parentOf.get(b) === a) { source = a; target = b }
      else if (tiers.parentOf.get(a) === b) { source = b; target = a }
      const link = linkByPair.get(key)
      return {
        id: link?.id ?? `edge:${a}:${b}`,
        source,
        target,
        linkType: link?.linkType ?? '',
        linkStatus: link?.linkStatus ?? '',
        confidence: link?.confidence ?? '',
        evidence: link?.evidence ?? '',
        manual: link ? MANUAL_LINK_SOTS.has(link.sourceOfTruth) || link.confirmed : false,
        speedMbps: link?.speedMbps ?? 0,
        trafficInMbps: link?.trafficInMbps ?? 0,
        trafficOutMbps: link?.trafficOutMbps ?? 0,
        label: link?.label ?? '',
      }
    })

  /* --- Blocchi per tier --- */
  const blocks = buildNetworkBlocks(
    rows.map((r) => ({ id: r.id, type: r.type, ip: r.ip, hostname: r.hostname, model: r.model })),
    tiers.tierOf,
  )

  /* --- Provenienza della radice --- */
  const rootSource: 'operator' | 'inferred' | 'none' = tiers.gatewayId == null
    ? 'none'
    : p.topologyRootDeviceId && tiers.gatewayId === p.topologyRootDeviceId
      ? 'operator'
      : 'inferred'

  let linksAsOf = 0
  for (const l of links) {
    linksAsOf = Math.max(linksAsOf, l.trafficUpdatedAt?.getTime() ?? 0)
  }
  const asOf = maxOf(rowsAsOf, linksAsOf) || Date.now()

  const data = {
    plantId: p.id,
    gatewayId: tiers.gatewayId,
    rootSource,
    sources: Array.from(sourcesSet),
    linkStats: {
      total: allLinks.length,
      included: included.length,
      excludedInferred,
      confirmedAlwaysIn,
    },
    nodes,
    edges,
    blocks,
    discardedAutoEdges: tiers.discardedAutoEdges.length,
    unreachableCount: reach.unreachable.length,
  }

  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(TopologyGraphSchema, body)
  return ok(data, asOf, mode)
}
