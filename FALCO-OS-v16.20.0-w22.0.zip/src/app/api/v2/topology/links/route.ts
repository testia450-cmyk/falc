/* ================================================================
 * /api/v2/topology/links — GET (elenco + statistiche) + POST
 * (creazione manuale) — 16.10.0 W8
 *
 * GET: «Quali collegamenti ha l'impianto, con che fonte e
 * confidenza?» Filtri: sourceOfTruth, confidence, confirmed, ricerca
 * testuale, paginazione. Stats oneste dell'INVENTARIO COMPLETO
 * dell'impianto (total, confirmed, per fonte, per confidenza) — la
 * base del pannello «gestione collegamenti» e del purge.
 *
 * POST (role ≥ TECNICO): crea un collegamento MANUALE — la verità
 * dell'operatore (sourceOfTruth=TECHNICIAN, confirmed=true,
 * confidence=HIGH, evidence=TECHNICIAN, linkStatus=ACTIVE: il
 * cavo esiste perché l'operatore lo dichiara). I dispositivi devono
 * esistere ed essere nell'ambito dell'impianto; sorgente ≠
 * destinazione; 409 LINK_EXISTS se un collegamento tra i due
 * dispositivi esiste già (in entrambe le direzioni).
 * Audit TOPOLOGY_LINK_CREATE.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import {
  TopologyLinksQuerySchema, TopologyLinksPageSchema,
  CreateTopologyLinkInputSchema, TopologyLinkRowSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { LINK_SOURCES } from '@/lib/v2/contracts'

export const dynamic = 'force-dynamic'

const LINK_INCLUDE = {
  sourceDevice: { select: { id: true, hostname: true, ip: true, type: true } },
  targetDevice: { select: { id: true, hostname: true, ip: true, type: true } },
} as const

/* Riga arricchita: link + endpoint risolti (hostname/ip/tipo) */
type LinkWithDevices = {
  id: string
  sourceDeviceId: string | null
  targetDeviceId: string | null
  sourceLabel: string
  targetLabel: string
  linkType: string
  linkStatus: string
  confidence: string
  evidence: string
  sourceOfTruth: string
  confirmed: boolean
  sourcePort: string
  targetPort: string
  speedMbps: number
  duplex: string
  trafficInMbps: number
  trafficOutMbps: number
  label: string
  notes: string
  updatedAt: Date
  sourceDevice: { id: string; hostname: string; ip: string; type: string } | null
  targetDevice: { id: string; hostname: string; ip: string; type: string } | null
}

export function toRow(l: LinkWithDevices) {
  return {
    id: l.id,
    sourceDeviceId: l.sourceDeviceId ?? null,
    sourceHostname: l.sourceDevice?.hostname ?? null,
    sourceIp: l.sourceDevice?.ip ?? l.sourceLabel,
    sourceType: l.sourceDevice?.type ?? '',
    targetDeviceId: l.targetDeviceId ?? null,
    targetHostname: l.targetDevice?.hostname ?? null,
    targetIp: l.targetDevice?.ip ?? l.targetLabel,
    targetType: l.targetDevice?.type ?? '',
    sourceLabel: l.sourceLabel,
    targetLabel: l.targetLabel,
    linkType: l.linkType,
    linkStatus: l.linkStatus,
    confidence: l.confidence,
    evidence: l.evidence,
    sourceOfTruth: l.sourceOfTruth,
    confirmed: l.confirmed,
    sourcePort: l.sourcePort,
    targetPort: l.targetPort,
    speedMbps: l.speedMbps,
    duplex: l.duplex,
    trafficInMbps: l.trafficInMbps,
    trafficOutMbps: l.trafficOutMbps,
    label: l.label,
    notes: l.notes,
    updatedAt: l.updatedAt.getTime(),
  }
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(TopologyLinksQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response

  const sourceFilter = q.value.source?.toUpperCase()
  if (sourceFilter && !(LINK_SOURCES as readonly string[]).includes(sourceFilter)) {
    return fail('BAD_QUERY', `Fonte non valida: ${q.value.source} (ammesse: ${LINK_SOURCES.join(', ')})`, 422)
  }

  const links = await db.topologyLink.findMany({
    where: { plantId: plant.plant.id },
    include: LINK_INCLUDE,
    orderBy: [{ confirmed: 'desc' }, { updatedAt: 'desc' }],
  })

  /* ---- stats sull'inventario COMPLETO (prima dei filtri) ---- */
  const bySource = new Map<string, number>()
  const byConfidence = new Map<string, number>()
  let confirmedCount = 0
  for (const l of links) {
    const s = l.sourceOfTruth || 'ALTRO'
    bySource.set(s, (bySource.get(s) ?? 0) + 1)
    const c = l.confidence || 'EMPTY'
    byConfidence.set(c, (byConfidence.get(c) ?? 0) + 1)
    if (l.confirmed) confirmedCount += 1
  }

  /* ---- filtri (source/confidence/confirmed via query, q in memoria) ---- */
  let filtered = links
  if (sourceFilter) filtered = filtered.filter((l) => (l.sourceOfTruth || 'ALTRO').toUpperCase() === sourceFilter)
  if (q.value.confidence) {
    filtered = filtered.filter((l) => (l.confidence || 'EMPTY') === (q.value.confidence === 'EMPTY' ? '' : q.value.confidence))
  }
  if (q.value.confirmed) {
    filtered = filtered.filter((l) => q.value.confirmed === 'true' ? l.confirmed : !l.confirmed)
  }
  if (q.value.q) {
    const needle = q.value.q.toLowerCase()
    filtered = filtered.filter((l) =>
      l.sourceDevice?.hostname?.toLowerCase().includes(needle) ||
      l.targetDevice?.hostname?.toLowerCase().includes(needle) ||
      l.sourceLabel.toLowerCase().includes(needle) ||
      l.targetLabel.toLowerCase().includes(needle) ||
      l.label.toLowerCase().includes(needle) ||
      l.notes.toLowerCase().includes(needle),
    )
  }

  const page = q.value.page
  const pageSize = q.value.pageSize
  const start = (page - 1) * pageSize
  const pageRows = filtered.slice(start, start + pageSize)

  const data = {
    links: pageRows.map((l) => toRow(l)),
    total: filtered.length,
    page,
    pageSize,
    stats: {
      total: links.length,
      confirmed: confirmedCount,
      bySource: Array.from(bySource.entries())
        .map(([source, count]) => ({ source, count }))
        .sort((a, b) => b.count - a.count),
      byConfidence: Array.from(byConfidence.entries())
        .map(([confidence, count]) => ({ confidence, count }))
        .sort((a, b) => b.count - a.count),
    },
  }
  const asOf = links.length > 0 ? Math.max(...links.map((l) => l.updatedAt.getTime())) : Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(TopologyLinksPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = CreateTopologyLinkInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const plant = await db.plant.findUnique({ where: { id: input.plantId } })
  if (!plant) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* --- i dispositivi devono appartenere all'impianto (v16.12 W10: plantId diretto) --- */
  const scope = { plantId: input.plantId }
  const [src, tgt] = await Promise.all([
    db.device.findFirst({ where: { id: input.sourceDeviceId, ...scope }, select: { id: true, hostname: true, ip: true, type: true } }),
    db.device.findFirst({ where: { id: input.targetDeviceId, ...scope }, select: { id: true, hostname: true, ip: true, type: true } }),
  ])
  if (!src) return fail('NOT_FOUND', 'Dispositivo sorgente non trovato nell\'ambito dell\'impianto', 404)
  if (!tgt) return fail('NOT_FOUND', 'Dispositivo destinazione non trovato nell\'ambito dell\'impianto', 404)

  /* --- guardia duplicati (entrambe le direzioni) --- */
  const existing = await db.topologyLink.findFirst({
    where: {
      plantId: input.plantId,
      OR: [
        { sourceDeviceId: src.id, targetDeviceId: tgt.id },
        { sourceDeviceId: tgt.id, targetDeviceId: src.id },
      ],
    },
    select: { id: true },
  })
  if (existing) {
    return fail('LINK_EXISTS', `Un collegamento tra «${src.hostname}» e «${tgt.hostname}» esiste già: modificalo o eliminalo invece di crearne un duplicato`, 409)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const created = await db.$transaction(async (tx) => {
    const link = await tx.topologyLink.create({
      data: {
        plantId: input.plantId,
        sourceDeviceId: src.id,
        sourceLabel: src.hostname,
        targetDeviceId: tgt.id,
        targetLabel: tgt.hostname,
        linkType: input.linkType,
        label: input.label ?? '',
        notes: input.notes ?? '',
        sourcePort: input.sourcePort ?? '',
        targetPort: input.targetPort ?? '',
        speedMbps: input.speedMbps ?? 0,
        linkStatus: 'ACTIVE',
        sourceOfTruth: 'TECHNICIAN',
        confidence: 'HIGH',
        evidence: 'TECHNICIAN',
        confirmed: true,
      },
      include: LINK_INCLUDE,
    })
    await tx.auditLog.create({
      data: {
        action: 'TOPOLOGY_LINK_CREATE',
        actor: email,
        targetId: link.id,
        targetLabel: `${src.hostname} → ${tgt.hostname}`,
        plantId: input.plantId,
        details: JSON.stringify({
          source: src.hostname,
          target: tgt.hostname,
          linkType: input.linkType,
          label: input.label ?? '',
          sourcePort: input.sourcePort ?? '',
          targetPort: input.targetPort ?? '',
          speedMbps: input.speedMbps ?? 0,
          origin: 'manuale operatore',
        }),
      },
    })
    return link
  })

  const data = toRow(created)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(TopologyLinkRowSchema, data)
  return ok(data, Date.now(), mode)
}
