/* ================================================================
 * /api/v2/topology/links/[id] — PATCH (correggi/conferma) + DELETE
 * — 16.10.0 W8
 *
 * PATCH (role ≥ TECNICO): correzione MANUALE del collegamento:
 *   · campi cablatura (tipo, etichetta, porte, velocità, note,
 *     stato) — audit TOPOLOGY_LINK_UPDATE con diff;
 *   · confirmed=true (cristallizzazione v15): il link diventa
 *     verità dell'OPERATORE — sourceOfTruth=TECHNICIAN,
 *     confidence=HIGH, evidence=TECHNICIAN;
 *   · 422 NO_CHANGES se il payload non cambia nulla.
 *
 * DELETE (role ≥ TECNICO): elimina il collegamento SBAGLIATO
 * dall'inventario (l'operatore ha detto: le letture bridge/SNMP
 * non riflettono la rete reale — questo è lo strumento per
 * correggerle). Audit TOPOLOGY_LINK_DELETE.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateTopologyLinkInputSchema, TopologyLinkRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { toRow } from '@/app/api/v2/topology/links/route'

export const dynamic = 'force-dynamic'

const LINK_INCLUDE = {
  sourceDevice: { select: { id: true, hostname: true, ip: true, type: true } },
  targetDevice: { select: { id: true, hostname: true, ip: true, type: true } },
} as const

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.topologyLink.findUnique({ where: { id }, include: LINK_INCLUDE })
  if (!existing) return fail('NOT_FOUND', 'Collegamento non trovato', 404)

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = UpdateTopologyLinkInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* --- diff onesto (audit) --- */
  const diff: Record<string, { from: unknown; to: unknown }> = {}
  const scalar: Array<[string, unknown]> = [
    ['linkType', input.linkType], ['label', input.label], ['notes', input.notes],
    ['sourcePort', input.sourcePort], ['targetPort', input.targetPort],
    ['speedMbps', input.speedMbps], ['linkStatus', input.linkStatus], ['confirmed', input.confirmed],
  ]
  for (const [k, v] of scalar) {
    if (v === undefined) continue
    const from = (existing as unknown as Record<string, unknown>)[k]
    if (from !== v) diff[k] = { from, to: v }
  }
  if (Object.keys(diff).length === 0) {
    return fail('NO_CHANGES', 'Nessuna modifica effettiva nel payload', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const crystallize = input.confirmed === true
  const updated = await db.$transaction(async (tx) => {
    const link = await tx.topologyLink.update({
      where: { id },
      data: {
        ...(input.linkType !== undefined && input.linkType !== existing.linkType ? { linkType: input.linkType } : {}),
        ...(input.label !== undefined && input.label !== existing.label ? { label: input.label } : {}),
        ...(input.notes !== undefined && input.notes !== existing.notes ? { notes: input.notes } : {}),
        ...(input.sourcePort !== undefined && input.sourcePort !== existing.sourcePort ? { sourcePort: input.sourcePort } : {}),
        ...(input.targetPort !== undefined && input.targetPort !== existing.targetPort ? { targetPort: input.targetPort } : {}),
        ...(input.speedMbps !== undefined && input.speedMbps !== existing.speedMbps ? { speedMbps: input.speedMbps } : {}),
        ...(input.linkStatus !== undefined && input.linkStatus !== existing.linkStatus ? { linkStatus: input.linkStatus } : {}),
        ...(input.confirmed !== undefined && input.confirmed !== existing.confirmed ? { confirmed: input.confirmed } : {}),
        // cristallizzazione: la conferma dell'operatore è verità
        ...(crystallize ? { sourceOfTruth: 'TECHNICIAN', confidence: 'HIGH', evidence: 'TECHNICIAN' } : {}),
      },
      include: LINK_INCLUDE,
    })
    await tx.auditLog.create({
      data: {
        action: 'TOPOLOGY_LINK_UPDATE',
        actor: email,
        targetId: link.id,
        targetLabel: `${link.sourceLabel || existing.sourceDevice?.hostname || '?'} → ${link.targetLabel || existing.targetDevice?.hostname || '?'}`,
        plantId: link.plantId,
        details: JSON.stringify({
          fields: Object.keys(diff),
          diff,
          crystallized: crystallize || undefined,
        }),
      },
    })
    return link
  })

  const data = toRow(updated)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(TopologyLinkRowSchema, data)
  return ok(data, Date.now(), mode)
}

/* ================================================================ */

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.topologyLink.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Collegamento non trovato', 404)

  const email = session.session.user.email ?? 'sconosciuto'
  await db.$transaction(async (tx) => {
    await tx.topologyLink.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'TOPOLOGY_LINK_DELETE',
        actor: email,
        targetId: id,
        targetLabel: `${existing.sourceLabel || '?'} → ${existing.targetLabel || '?'}`,
        plantId: existing.plantId,
        details: JSON.stringify({
          linkType: existing.linkType,
          sourceOfTruth: existing.sourceOfTruth,
          confidence: existing.confidence,
          evidence: existing.evidence,
          confirmed: existing.confirmed,
          origin: 'eliminato dall\'operatore',
        }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  const data = { deleted: true as const, id }
  return ok(data, Date.now(), mode)
}
