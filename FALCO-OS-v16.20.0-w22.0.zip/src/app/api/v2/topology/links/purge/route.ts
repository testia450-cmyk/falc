/* ================================================================
 * /api/v2/topology/links/purge — POST — 16.10.0 W8
 *
 * «Le letture SNMP del bridge hanno prodotto una topologia che non
 * rispecchia la rete reale»: questo è lo strumento per RIPULIRLA
 * in blocco, con la sicurezza della v16:
 *   · dryRun=true (default): CONTEGGIO onesto + campione, NESSUNA
 *     scrittura — l'operatore vede ESATTAMENTE cosa sparirebbe;
 *   · dryRun=false: eliminazione in UNA transazione + audit
 *     TOPOLOGY_LINK_PURGE con criteri e conteggio;
 *   · MAI su link confermati o dell'operatore: la guardia è nella
 *     QUERY (confirmed=false AND sourceOfTruth ≠ TECHNICIAN), non
 *     solo nello schema — un link che l'operatore ha confermato
 *     NON SPARISCE MAI;
 *   · TECHNICIAN non è ammesso tra le fonti (contratto).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { PurgeLinksInputSchema, PurgeLinksResultSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = PurgeLinksInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const plant = await db.plant.findUnique({ where: { id: input.plantId } })
  if (!plant) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* --- perimetro della purge: MAI confermati, MAI dell'operatore --- */
  const where = {
    plantId: input.plantId,
    confirmed: false,
    sourceOfTruth: { in: input.sources },
    NOT: { sourceOfTruth: 'TECHNICIAN' },
  }

  if (input.dryRun) {
    const [count, sampleLinks] = await Promise.all([
      db.topologyLink.count({ where }),
      db.topologyLink.findMany({
        where,
        include: {
          sourceDevice: { select: { hostname: true } },
          targetDevice: { select: { hostname: true } },
        },
        take: 5,
        orderBy: { updatedAt: 'desc' },
      }),
    ])
    const data = {
      dryRun: true,
      count,
      sample: sampleLinks.map((l) => ({
        sourceHostname: l.sourceDevice?.hostname ?? l.sourceLabel,
        targetHostname: l.targetDevice?.hostname ?? l.targetLabel,
        sourceOfTruth: l.sourceOfTruth,
      })),
    }
    const replay = await getReplayState()
    const mode = apiMode(replay)
    devValidate(PurgeLinksResultSchema, { ok: true as const, asOf: Date.now(), mode, data })
    return ok(data, Date.now(), mode)
  }

  /* --- esecuzione: una transazione, un audit --- */
  const email = session.session.user.email ?? 'sconosciuto'
  const data = await db.$transaction(async (tx) => {
    const doomed = await tx.topologyLink.findMany({
      where,
      select: { id: true },
    })
    await tx.topologyLink.deleteMany({ where })
    await tx.auditLog.create({
      data: {
        action: 'TOPOLOGY_LINK_PURGE',
        actor: email,
        targetId: input.plantId,
        targetLabel: plant.name,
        plantId: input.plantId,
        details: JSON.stringify({
          sources: input.sources,
          deleted: doomed.length,
          guard: 'mai confermati, mai TECHNICIAN',
        }),
      },
    })
    return {
      dryRun: false,
      count: doomed.length,
      sample: [] as Array<{ sourceHostname: string; targetHostname: string; sourceOfTruth: string }>,
    }
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(PurgeLinksResultSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
