/* ================================================================
 * /api/v2/import/xlsx/preview — POST (FASE 1, dry-run)
 * 16.13 W11 · «partire già avvantaggiati»: l'operatore carica l'Excel
 * di installazione (formato SETI) e l'impianto si popola con sedi,
 * apparati e topologia REALE. ZERO scritture in preview.
 *
 * multipart/form-data:
 *   file    → .xlsx (max 15 MB)
 *   plantId → impianto su cui importare
 *
 * Risposta (XlsxPreviewSchema): { fileId, piano } con
 *   · sezioni → sedi esistenti (match fuzzy ALTA/MEDIA/BASSA con
 *     motivo) o CREATE;
 *   · apparati → UPDATE (match IP) o CREATE (credenziali CIFRATE
 *     solo in apply, se la chiave è configurata);
 *   · link radio dai gruppi SSID (source=upstream PTP/AP);
 *   · proposte di basestation sintetica (MAI pre-confermate);
 *   · dispositivi del DB fuori Excel (restano dove sono);
 *   · conteggio link auto-scoperti sostituibili (opt-in in apply).
 * ================================================================ */

import { mkdir, writeFile, readdir, unlink, stat } from 'fs/promises'
import { tmpdir } from 'os'
import { join } from 'path'
import { randomUUID } from 'crypto'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { XlsxPreviewSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { parseSetiXlsx } from '@/lib/domain/xlsx-parser'
import { planXlsxImport } from '@/lib/domain/xlsx-import-plan'

export const dynamic = 'force-dynamic'

const UPLOAD_DIR = join(tmpdir(), 'falco-xlsx-upload')
const MAX_FILE_BYTES = 15 * 1024 * 1024 // 15 MB
const STALE_MS = 2 * 60 * 60 * 1000 // 2 h

async function cleanupStaleUploads(): Promise<void> {
  try {
    await mkdir(UPLOAD_DIR, { recursive: true })
    const entries = await readdir(UPLOAD_DIR)
    const now = Date.now()
    for (const name of entries) {
      try {
        const f = await stat(join(UPLOAD_DIR, name))
        if (now - f.mtimeMs > STALE_MS) await unlink(join(UPLOAD_DIR, name))
      } catch {
        /* file sparito tra readdir e stat: ignora */
      }
    }
  } catch {
    /* best-effort */
  }
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* ---- multipart ---- */
  let formData: FormData
  try {
    formData = await req.formData()
  } catch {
    return fail('BAD_BODY', 'Richiesta non valida: atteso multipart/form-data con file e plantId', 422)
  }
  const file = formData.get('file')
  const plantId = String(formData.get('plantId') ?? '')
  if (!(file instanceof File)) {
    return fail('BAD_BODY', 'File .xlsx richiesto (campo «file» in multipart/form-data)', 422)
  }
  if (!plantId) {
    return fail('BAD_BODY', 'plantId richiesto', 422)
  }
  if (!file.name.toLowerCase().endsWith('.xlsx')) {
    return fail('BAD_BODY', 'Solo file .xlsx sono supportati (Excel di installazione)', 422)
  }
  if (file.size > MAX_FILE_BYTES) {
    return fail('BAD_BODY', `File troppo grande: ${(file.size / 1024 / 1024).toFixed(1)} MB (massimo 15 MB)`, 422)
  }
  if (file.size === 0) {
    return fail('BAD_BODY', 'File vuoto', 422)
  }

  /* ---- impianto ---- */
  const plant = await db.plant.findUnique({ where: { id: plantId } })
  if (!plant) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* ---- parse (nessuna scrittura) ---- */
  const buffer = Buffer.from(await file.arrayBuffer())
  let summary: ReturnType<typeof parseSetiXlsx>
  try {
    summary = parseSetiXlsx(buffer, file.name)
  } catch (e) {
    return fail('BAD_FILE', e instanceof Error ? e.message : 'File .xlsx non leggibile', 422)
  }
  if (summary.sections.length === 0) {
    return fail('BAD_FILE', 'Nessuna sezione con apparati riconosciuta: serve l\'Excel di installazione (sezioni di sede + righe IP/nome)', 422)
  }

  /* ---- dati attuali dell'impianto (per il piano) ---- */
  const [locations, devices, autoLinkCount] = await Promise.all([
    db.location.findMany({
      where: { plantId },
      select: { id: true, identifier: true, name: true },
    }),
    db.device.findMany({
      where: { plantId, decommissionedAt: null },
      select: { id: true, ip: true, hostname: true, type: true, ssid: true, locationId: true },
    }),
    db.topologyLink.count({
      where: { plantId, sourceOfTruth: { not: 'TECHNICIAN' } },
    }),
  ])

  const plan = planXlsxImport(summary, locations, devices, autoLinkCount)

  /* ---- salva il file in area temporanea con id opaco ---- */
  const fileId = `${randomUUID()}.xlsx`
  await cleanupStaleUploads()
  try {
    await mkdir(UPLOAD_DIR, { recursive: true })
    await writeFile(join(UPLOAD_DIR, fileId), buffer)
  } catch {
    return fail('INTERNAL', 'Impossibile salvare il file per la conferma: riprova', 500)
  }

  const data = {
    fileId,
    fileName: file.name,
    plantId,
    sheetName: summary.sheetName,
    network: summary.network,
    sections: plan.sections,
    links: plan.links,
    synthetic: plan.synthetic,
    lonelySsids: plan.lonelySsids,
    unmatchedExisting: plan.unmatchedExisting,
    autoLinkCount: plan.autoLinkCount,
    stats: plan.stats,
  }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(XlsxPreviewSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
