/* ================================================================
 * /api/v2/import/xlsx/apply — POST (FASE 2, conferma)
 * 16.13 W11 · esegue il piano CONFERMATO in UNA transazione.
 *
 * Il client invia SOLO indici e id riverificati:
 *   { fileId, plantId, sections: [{sectionIndex, locationId?}],
 *     createLinks, createLanLinks, synthetic: [{index, locationId?}],
 *     purgeAutoLinks }
 *
 * SICUREZZA E ONESTÀ (come l'import KMZ):
 *   · il fileId è opaco: RIAPRIAMO il file temporaneo della preview
 *     e RI-PARSIAMO + RI-DERIVIAMO il piano — nomi/SSID/credenziali
 *     vengono dal FILE, non dal payload;
 *   · le sedi scelte vengono riverificate (perimetro impianto);
 *   · password CIFRATE AES-256-GCM (rifiuto se la chiave manca);
 *   · purgeAutoLinks elimina SOLO i link auto-scoperti (mai quelli
 *     confermati dall'operatore);
 *   · audit DEVICE_IMPORT_XLSX con i conteggi.
 * ================================================================ */

import { readFile, unlink } from 'fs/promises'
import { tmpdir } from 'os'
import { join } from 'path'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { XlsxApplyInputSchema, XlsxApplyResultSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { parseSetiXlsx } from '@/lib/domain/xlsx-parser'
import { planXlsxImport } from '@/lib/domain/xlsx-import-plan'
import { applyXlsxImport } from '@/lib/domain/xlsx-apply'

export const dynamic = 'force-dynamic'

const UPLOAD_DIR = join(tmpdir(), 'falco-xlsx-upload')

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = XlsxApplyInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* ---- sicurezza del fileId (niente path traversal) ---- */
  if (!/^[A-Za-z0-9._-]+$/.test(input.fileId) || input.fileId.includes('..')) {
    return fail('BAD_BODY', 'fileId non valido', 422)
  }

  const plant = await db.plant.findUnique({ where: { id: input.plantId } })
  if (!plant) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* ---- riapri e ri-parsa il file della preview (verità del server) ---- */
  let fileBuffer: Buffer
  try {
    fileBuffer = await readFile(join(UPLOAD_DIR, input.fileId))
  } catch {
    return fail('NOT_FOUND', 'File di import non trovato: ripeti l\'anteprima (il file temporaneo scade con il server)', 404)
  }
  let summary: ReturnType<typeof parseSetiXlsx>
  try {
    summary = parseSetiXlsx(fileBuffer, input.fileId)
  } catch (e) {
    return fail('BAD_FILE', e instanceof Error ? e.message : 'File non più leggibile', 422)
  }

  /* ---- RI-DERIVA il piano lato server (il client non decide nulla) ---- */
  const [locations, devices, autoLinkCount] = await Promise.all([
    db.location.findMany({
      where: { plantId: input.plantId },
      select: { id: true, identifier: true, name: true },
    }),
    db.device.findMany({
      where: { plantId: input.plantId, decommissionedAt: null },
      select: { id: true, ip: true, hostname: true, type: true, ssid: true, locationId: true },
    }),
    db.topologyLink.count({
      where: { plantId: input.plantId, sourceOfTruth: { not: 'TECHNICIAN' } },
    }),
  ])
  // le scelte dell'operatore diventano la mappa manuale del piano
  const manualLocationMap: Record<number, string> = {}
  for (const s of input.sections) {
    if (s.locationId) manualLocationMap[s.sectionIndex] = s.locationId
  }
  const plan = planXlsxImport(summary, locations, devices, autoLinkCount, { manualLocationMap })

  const email = session.session.user.email ?? 'sconosciuto'
  const result = await db.$transaction(async (tx) => {
    const counts = await applyXlsxImport(summary, plan, {
      plantId: input.plantId,
      sections: input.sections.map((s) => ({
        sectionIndex: s.sectionIndex,
        locationId: s.locationId ?? null,
      })),
      createLinks: input.createLinks,
      createLanLinks: input.createLanLinks,
      synthetic: input.synthetic.map((s) => ({
        index: s.index,
        locationId: s.locationId ?? null,
      })),
      purgeAutoLinks: input.purgeAutoLinks,
      actor: email,
    }, tx)

    await tx.auditLog.create({
      data: {
        action: 'DEVICE_IMPORT_XLSX',
        actor: email,
        targetId: input.plantId,
        targetLabel: plant.name,
        plantId: input.plantId,
        details: JSON.stringify({
          fileName: input.fileId,
          sections: input.sections.length,
          ...counts,
        }),
      },
    })

    return counts
  }).catch((e: unknown) => {
    const code = (e as { code?: string })?.code
    if (code === 'BAD_BODY' || code === 'SETUP') {
      return { error: e instanceof Error ? e.message : 'Payload non valido' }
    }
    return { error: 'Errore durante l\'import: transazione annullata, nessuna riga scritta' }
  })

  if ('error' in result && result.error) {
    return fail('BAD_BODY', result.error, 422)
  }
  const applied = result as Exclude<typeof result, { error: string }>

  /* ---- pulizia del file temporaneo ---- */
  try {
    await unlink(join(UPLOAD_DIR, input.fileId))
  } catch {
    /* best-effort: scadrà con la pulizia stale */
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(XlsxApplyResultSchema, { ok: true as const, asOf: Date.now(), mode, data: applied })
  return ok(applied, Date.now(), mode)
}
