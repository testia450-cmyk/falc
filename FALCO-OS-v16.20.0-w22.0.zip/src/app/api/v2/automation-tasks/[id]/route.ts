/* ================================================================
 * /api/v2/automation-tasks/{id} — PATCH (modifica) + DELETE (16.7 W3.5)
 * Operazioni su un task di automazione REALE del DB (AutomationTask
 * v11.8 S5, entità GLOBALE: lookup per id, 404 per id inesistente).
 *  · PATCH (role ≥ TECNICO): patch parziale; deviceIds presente =
 *    SOSTITUZIONE INTEGRALE dei target (targetsJson riscritto, non un
 *    merge — semantica dichiarata) e validato contro i dispositivi
 *    REALI dello scope del plant (422 con offensori); name NON è
 *    modificabile (identità univoca globale @@unique referenziata
 *    dalle richieste di configurazione generate: check sul corpo
 *    GREZZO, zod lo ignoerebbe in silenzio). Patch senza alcun
 *    effetto reale → 422 NO_CHANGES. Audit AUTOMATION_TASK_UPDATE in
 *    TRANSAZIONE con diff {campo: {from, to}}.
 *  · DELETE (role ≥ TECNICO): delete + audit AUTOMATION_TASK_DELETE
 *    {name, targets, commands}. Le ConfigChangeRequest collegate
 *    sopravvivono (taskId → null, onDelete: SetNull dello schema);
 *    gli AutomationRunLog cadono a cascata. Risponde {id}.
 *  · NESSUN run in replay (dichiarato).
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateAutomationTaskInputSchema, AutomationTaskRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant, offendingDeviceIds } from '@/app/api/v2/shared'
import { toAutomationTaskRow, parseJsonStringArray, hostnameMapByIds } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

function notFound() {
  return fail('NOT_FOUND', 'Task di automazione non trovato', 404)
}

/** Confronto insiemistico (ordine irrilevante): rispecificare lo
 *  STESSO insieme di target non è una modifica. */
function sameSet(a: string[], b: string[]): boolean {
  if (a.length !== b.length) return false
  const sa = [...a].sort()
  const sb = [...b].sort()
  return sa.every((v, i) => v === sb[i])
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo fra description, deviceIds, category, commands, executor, intervalSec, confirmMinutes, guardrailMaxDevices, enabled)', 422)
  }

  /* name è l'identità del task (univoca globale, referenziata dalle
   * richieste generate): NON modificabile — check sul corpo GREZZO
   * perché zod ignora le chiavi sconosciute (mai input ignorato). */
  if (rawBody && typeof rawBody === 'object' && !Array.isArray(rawBody)
    && 'name' in (rawBody as Record<string, unknown>)) {
    return fail('BAD_BODY', 'Il campo «name» non è modificabile: è l\'identità univoca del task (referenziata dalle richieste generate). Crea un nuovo task se serve un nome diverso', 422, [
      { path: 'name', message: 'Campo non modificabile (identità univoca globale)' },
    ])
  }

  const parsed = UpdateAutomationTaskInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const existing = await db.automationTask.findUnique({ where: { id } })
  if (!existing) return notFound()

  /* --- deviceIds: SOSTITUZIONE INTEGRALE, validata contro i
   *      dispositivi REALI dello scope (se presenti). --- */
  const newTargets = input.deviceIds !== undefined ? Array.from(new Set(input.deviceIds)) : null
  if (newTargets && newTargets.length > 0) {
    const offending = await offendingDeviceIds(p.id, newTargets)
    if (offending.length > 0) {
      return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
        { path: 'deviceIds', message: `Id non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
      ])
    }
  }

  /* --- Diff PRIMA della scrittura: patch senza ALCUN effetto reale
   *      → 422 NO_CHANGES esplicito (mai no-op silenzioso). --- */
  const curTargets = parseJsonStringArray(existing.targetsJson)
  const descriptionChanged = input.description !== undefined && input.description !== existing.description
  const deviceIdsChanged = newTargets !== null && !sameSet(newTargets, curTargets)
  const categoryChanged = input.category !== undefined && input.category !== existing.category
  const commandsChanged = input.commands !== undefined
    && JSON.stringify(input.commands) !== JSON.stringify(parseJsonStringArray(existing.commandsJson))
  const executorChanged = input.executor !== undefined && input.executor !== existing.executor
  const intervalChanged = input.intervalSec !== undefined && input.intervalSec !== existing.intervalSec
  const confirmChanged = input.confirmMinutes !== undefined && input.confirmMinutes !== existing.confirmMinutes
  const guardrailChanged = input.guardrailMaxDevices !== undefined && input.guardrailMaxDevices !== existing.guardrailMaxDevices
  const enabledChanged = input.enabled !== undefined && input.enabled !== existing.enabled
  if (
    !descriptionChanged && !deviceIdsChanged && !categoryChanged && !commandsChanged
    && !executorChanged && !intervalChanged && !confirmChanged && !guardrailChanged && !enabledChanged
  ) {
    return fail('NO_CHANGES', 'Nessun campo modificato: la patch non ha alcun effetto sul task (stato già conforme alla richiesta)', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + audit in transazione --- */
  const updated = await db.$transaction(async (tx) => {
    const data: Prisma.AutomationTaskUpdateInput = {}
    if (descriptionChanged) data.description = input.description!
    if (deviceIdsChanged && newTargets) data.targetsJson = JSON.stringify(newTargets)
    if (categoryChanged) data.category = input.category!
    if (commandsChanged) data.commandsJson = JSON.stringify(input.commands)
    if (executorChanged) data.executor = input.executor!
    if (intervalChanged) data.intervalSec = input.intervalSec!
    if (confirmChanged) data.confirmMinutes = input.confirmMinutes!
    if (guardrailChanged) data.guardrailMaxDevices = input.guardrailMaxDevices!
    if (enabledChanged) data.enabled = input.enabled!

    const t = await tx.automationTask.update({ where: { id: existing.id }, data })

    /* Diff sintetico: SOLO ciò che è cambiato davvero */
    const changes: Record<string, unknown> = {}
    if (descriptionChanged) changes.description = { from: existing.description.slice(0, 80), to: input.description!.slice(0, 80) }
    if (deviceIdsChanged) changes.deviceIds = { from: curTargets.length, to: newTargets!.length }
    if (categoryChanged) changes.category = { from: existing.category, to: input.category }
    if (commandsChanged) changes.commands = { from: parseJsonStringArray(existing.commandsJson).length, to: input.commands!.length }
    if (executorChanged) changes.executor = { from: existing.executor, to: input.executor }
    if (intervalChanged) changes.intervalSec = { from: existing.intervalSec, to: input.intervalSec }
    if (confirmChanged) changes.confirmMinutes = { from: existing.confirmMinutes, to: input.confirmMinutes }
    if (guardrailChanged) changes.guardrailMaxDevices = { from: existing.guardrailMaxDevices, to: input.guardrailMaxDevices }
    if (enabledChanged) changes.enabled = { from: existing.enabled, to: input.enabled }

    await tx.auditLog.create({
      data: {
        action: 'AUTOMATION_TASK_UPDATE',
        actor: email,
        targetId: t.id,
        targetLabel: t.name.slice(0, 80),
        plantId: null, // entità GLOBALE: nessun impianto coinvolto
        details: JSON.stringify({ taskId: t.id, name: t.name, changes }),
      },
    })
    return t
  })

  const hostnameMap = await hostnameMapByIds(parseJsonStringArray(updated.targetsJson))
  const data = toAutomationTaskRow(updated, hostnameMap)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AutomationTaskRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}

/* ================================================================ */

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.automationTask.findUnique({ where: { id } })
  if (!existing) return notFound()

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Delete + audit in transazione: le ConfigChangeRequest con
   *      taskId sopravvivono (SetNull); gli AutomationRunLog cadono
   *      a cascata (schema). --- */
  await db.$transaction(async (tx) => {
    await tx.automationTask.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'AUTOMATION_TASK_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.name.slice(0, 80),
        plantId: null, // entità GLOBALE: nessun impianto coinvolto
        details: JSON.stringify({
          taskId: existing.id,
          name: existing.name,
          category: existing.category,
          targets: parseJsonStringArray(existing.targetsJson).length,
          commands: parseJsonStringArray(existing.commandsJson).length,
          runCount: existing.runCount, // onesto: mai eseguito in replay
        }),
      },
    })
  })

  const data = { id: existing.id }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  return ok(data, now.getTime(), mode)
}
