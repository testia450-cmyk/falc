/* ================================================================
 * /api/v2/automation-tasks — GET (elenco) + POST (creazione, 16.7 W3.5)
 * Task di automazione ricorrenti REALI del DB (modello AutomationTask
 * v11.8 S5: esecuzione pianificata con guardrail per run). DB reale:
 * 0 task → total 0 (onesto, non errore).
 *  · GET: task per name asc (entità GLOBALE nel modello: nessuno
 *    scope impianto); targetHostnames = primi 20 hostname dei target
 *    (cap dichiarato nel contratto, UNA query per l'elenco);
 *    targetCount REALE; runCount/lastRunAt/lastError grezzi (0/null/
 *    "": mai eseguito in replay, onesto).
 *  · POST (role ≥ TECNICO): deviceIds OPZIONALI ma, se presenti,
 *    ⊆ dispositivi REALI dello scope del plant → 422 con offensori
 *    (max 5); name UNIQUE globale (@@unique) → conflitto Prisma P2002
 *    → 422 NAME_EXISTS. Defaults dichiarati: category 'custom',
 *    executor SIMULATED, intervalSec 3600, confirmMinutes 10,
 *    guardrailMaxDevices 10, enabled true. Audit AUTOMATION_TASK_CREATE
 *    in TRANSAZIONE (plantId null: entità globale). 201 con la riga.
 *  · NESSUN endpoint run: l'esecuzione NON è disponibile in modalità
 *    riproduzione (nessun scheduler attivo) — dichiarato, mai finto.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { AutomationTasksPageSchema, AutomationTaskRowSchema, CreateAutomationTaskInputSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant, maxOf, offendingDeviceIds } from '@/app/api/v2/shared'
import { toAutomationTaskRow, hostnameMapByIds, parseJsonStringArray } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response

  /* AutomationTask è globale (nessun plantId nel modello): elenco
   * intero per name asc; l'impianto risolto serve solo a validare la
   * query (coerenza con le altre rotte dell'ondata). */
  const tasks = await db.automationTask.findMany({ orderBy: { name: 'asc' } })

  const hostnameMap = await hostnameMapByIds(tasks.flatMap((t) => parseJsonStringArray(t.targetsJson)))

  const data = {
    items: tasks.map((t) => toAutomationTaskRow(t, hostnameMap)),
    total: tasks.length, // 0 = nessun task (onesto)
  }

  const asOf = maxOf(...tasks.map((t) => t.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AutomationTasksPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, commands, deviceIds?, … } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name e commands)', 422)
  }
  const parsed = CreateAutomationTaskInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- Target OPZIONALI: se presenti, tutti REALI e nello scope
   *      del plant (niente target fantasma). --- */
  const deviceIds = input.deviceIds ? Array.from(new Set(input.deviceIds)) : []
  if (deviceIds.length > 0) {
    const offending = await offendingDeviceIds(p.id, deviceIds)
    if (offending.length > 0) {
      return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
        { path: 'deviceIds', message: `Id non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
      ])
    }
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + audit in transazione: name è @@unique GLOBALE →
   *      conflitto P2002 → 422 NAME_EXISTS. --- */
  let created: Awaited<ReturnType<typeof db.automationTask.create>>
  try {
    created = await db.$transaction(async (tx) => {
      const t = await tx.automationTask.create({
        data: {
          name: input.name,
          description: input.description ?? '',
          targetsJson: JSON.stringify(deviceIds),
          category: input.category ?? 'custom',
          commandsJson: JSON.stringify(input.commands),
          executor: input.executor ?? 'SIMULATED',
          intervalSec: input.intervalSec ?? 3600,
          confirmMinutes: input.confirmMinutes ?? 10,
          enabled: input.enabled ?? true,
          guardrailMaxDevices: input.guardrailMaxDevices ?? 10,
          runCount: 0, // onesto: mai eseguito in replay
          lastRunAt: null,
          lastError: '',
        },
      })
      await tx.auditLog.create({
        data: {
          action: 'AUTOMATION_TASK_CREATE',
          actor: email,
          targetId: t.id,
          targetLabel: t.name.slice(0, 80),
          plantId: null, // entità GLOBALE: nessun impianto coinvolto
          details: JSON.stringify({
            taskId: t.id,
            name: t.name,
            category: t.category,
            targets: deviceIds.length,
            commands: input.commands.length,
            executor: t.executor,
            intervalSec: t.intervalSec,
            confirmMinutes: t.confirmMinutes,
            guardrailMaxDevices: t.guardrailMaxDevices,
            enabled: t.enabled,
            note: 'nessuna esecuzione in replay: runCount resta 0',
          }),
        },
      })
      return t
    })
  } catch (e) {
    if ((e as { code?: string }).code === 'P2002') {
      return fail('NAME_EXISTS', `Esiste già un task di automazione chiamato «${input.name}»: i nomi sono univoci (globali, non per impianto)`, 422)
    }
    throw e
  }

  const hostnameMap = await hostnameMapByIds(deviceIds)
  const data = toAutomationTaskRow(created, hostnameMap)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AutomationTaskRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
