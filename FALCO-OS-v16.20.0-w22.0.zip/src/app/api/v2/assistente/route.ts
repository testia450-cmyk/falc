/* ================================================================
 * /api/v2/assistente — POST (stream SSE) — 16.9.0 W4
 * ASSISTENTE AI dell'operatore (voce «assistente» dell'onda W4).
 * v15 usava Ollama locale con SSE; v16 usa il model della piattaforma
 * (z-ai-web-dev-sdk, SOLO backend — mai client-side) con STREAMING
 * reale (frammenti via evento `delta`).
 * Il contesto di sistema è costruito da dati REALI del plant
 * (impianto, conteggi dispositivi per tipo/stato, allarmi aperti per
 * severità, ticket KPI, link radio deboli, sedi, KB): l'assistente
 * risponde sui dati di questo NOC, non su inventori — e le risposte
 * dichiarano i limiti quando il dato manca (onestà §2.1).
 * Eventi SSE: `status` (fase), `delta` (frammenti), `done`
 * {durationMs, contextChars}, `error` {message}.
 * Audit ASSISTENTE_QUERY bounded (domanda troncata, durata, caratteri
 * contesto — MAI il contenuto della risposta, troppo verboso).
 * Role ≥ TECNICO.
 * ================================================================ */

import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import { AssistenteInputSchema } from '@/lib/v2/contracts'
import { hasRole } from '@/lib/auth'
import { resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Contesto REALE dell'impianto ATTIVO, compatto e onesto (solo conteggi e
 *  nomi). v16.12 W10: ogni query è per-impianto (plantId diretto sul Device,
 *  Ticket/AlertEvent/Location da sempre) — l'assistente risponde SOLO con
 *  i dati dell'impianto selezionato, mai con quelli di un altro. */
async function buildPlantContext(plant: { id: string; name: string; comune: string }): Promise<{ text: string; chars: number }> {
  const plantName = plant.name

  const [byType, byStatus, locations, alarmsBySeverity, tickets, weakLinks, kbCount, orphans] = await Promise.all([
    db.device.groupBy({ by: ['type'], where: { plantId: plant.id }, _count: { _all: true } }),
    db.device.groupBy({ by: ['status'], where: { plantId: plant.id }, _count: { _all: true } }),
    db.location.count({ where: { plantId: plant.id } }),
    db.alertEvent.groupBy({ by: ['severity'], where: { plantId: plant.id, status: { in: ['OPEN', 'ACK', 'ESCALATED'] } }, _count: { _all: true } }),
    db.ticket.groupBy({ by: ['status'], where: { plantId: plant.id }, _count: { _all: true } }),
    db.device.findMany({
      where: { plantId: plant.id, type: 'STA' },
      select: { hostname: true, signalStrength: true },
      orderBy: { signalStrength: 'asc' },
      take: 5,
    }),
    db.knowledgeBase.count({ where: { plantId: plant.id } }),
    db.device.count({ where: { plantId: plant.id, locationId: null } }),
  ])

  const fmt = (rows: Array<{ [k: string]: unknown; _count: { _all: number } }>, key: string) =>
    rows.map((r) => `${String(r[key])}: ${r._count._all}`).join(', ') || 'nessuno'

  const total = byStatus.reduce((s, r) => s + r._count._all, 0)
  const openAlarms = alarmsBySeverity.reduce((s, r) => s + r._count._all, 0)

  const text = [
    `impianto: ${plantName} (comune: ${plant.comune})`,
    `dispositivi totali: ${total} — per stato: ${fmt(byStatus, 'status')}`,
    `dispositivi per tipo: ${fmt(byType, 'type')}`,
    `sedi (location): ${locations}, dispositivi senza sede: ${orphans}`,
    `allarmi aperti/con ACK: ${openAlarms} — per severità: ${fmt(alarmsBySeverity, 'severity')}`,
    `ticket per stato: ${fmt(tickets, 'status')}`,
    `link radio più deboli (STA per segnale noto): ${weakLinks.map((w) => `${w.hostname} ${w.signalStrength} dBm`).join(', ') || 'nessuno'}`,
    `articoli knowledge base: ${kbCount}`,
  ].join('\n')

  return { text, chars: text.length }
}

function sseFrame(event: string, data: string): string {
  return `event: ${event}\ndata: ${data.replace(/\n/g, '\\n')}\n\n`
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { message, history? })', 422)
  }
  const parsed = AssistenteInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const email = session.session.user.email ?? 'sconosciuto'
  const t0 = Date.now()

  /* Impianto ATTIVO dal selettore (?plantId=, default deterministico W8):
   * il contesto è SOLO di questo impianto (W10). */
  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* header SSE: nessun buffering intermedi, no-store (dato operativo) */
  const headers = {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-store',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  }

  const encoder = new TextEncoder()
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false
      const send = (event: string, data: string) => {
        if (closed) return
        try {
          controller.enqueue(encoder.encode(sseFrame(event, data)))
        } catch {
          closed = true
        }
      }

      try {
        send('status', 'Compongo il contesto reale dell\'impianto…')
        const ctx = await buildPlantContext({ id: p.id, name: p.name, comune: p.comune })
        send('status', 'Contesto pronto — interrogo il model…')

        const systemPrompt = [
          'Sei l\'assistente AI operatore di FALCO-OS, la console NOC di una rete di videosorveglianza e trasmissioni radio.',
          'Rispondi in ITALIANO, in modo conciso e operativo (massimo ~250 parole salvo richiesta esplicita).',
          'Hai sotto occhi il CONTESTO REALE dell\'impianto estratto dal database (conteggi, stati, allarmi, ticket, link deboli).',
          'Regole di onestà non negoziabili:',
          '- usa SOLO i dati del contesto per i numeri; se un dato non c\'è, dillo («non disponibile in questo momento») invece di inventarlo;',
          '- la console gira in modalità riproduzione (replay): le esecuzioni SSH/SNMP/poller non girano — se la domanda le riguarda, spiegalo;',
          '- per azioni operative (finestre di manutenzione, ticket, RMA, ondate, CVE) indica SEMPRE in quale vista/tab della console farle;',
          '- non hai accesso a credenziali, stream video o dati personali: rifiuta con gentilezza quelle richieste.',
          '',
          'CONTESTO REALE DELL\'IMPIANTO:',
          ctx.text,
        ].join('\n')

        const zai = await ZAI.create()
        const messages: Array<{ role: 'assistant' | 'user'; content: string }> = [
          { role: 'assistant', content: systemPrompt },
          ...(input.history ?? []).slice(-6),
          { role: 'user', content: input.message },
        ]

        const completion = await zai.chat.completions.create({
          messages,
          thinking: { type: 'disabled' },
          stream: true,
        })

        /* Lo stream del SDK è un ReadableStream SSE grezzo: si legge
         * con getReader() e si interpretano i frame `data:` OpenAI-
         * compatibili (choices[0].delta.content) — ogni frammento
         * parte SUBITO verso il client. */
        const reader = (completion as unknown as ReadableStream<string>).getReader()
        const decoder = new TextDecoder()
        let sseBuffer = ''
        let sawDelta = false
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          sseBuffer += typeof value === 'string' ? value : decoder.decode(value, { stream: true })
          const lines = sseBuffer.split('\n')
          sseBuffer = lines.pop() ?? '' // frame parziale: resta nel buffer
          for (const line of lines) {
            if (!line.startsWith('data: ')) continue
            const payload = line.slice(6).trim()
            if (!payload || payload === '[DONE]') continue
            try {
              const frame = JSON.parse(payload) as { choices?: Array<{ delta?: { content?: string }; message?: { content?: string } }> }
              const delta = frame.choices?.[0]?.delta?.content ?? frame.choices?.[0]?.message?.content ?? ''
              if (delta) {
                sawDelta = true
                send('delta', delta)
              }
            } catch { /* frame non JSON: scartato */ }
          }
        }
        if (!sawDelta) {
          send('error', JSON.stringify({ message: 'Il model non ha prodotto testo (stream vuoto)' }))
        }

        const durationMs = Date.now() - t0
        send('done', JSON.stringify({ durationMs, contextChars: ctx.chars }))

        await db.auditLog.create({
          data: {
            action: 'ASSISTENTE_QUERY',
            actor: email,
            targetId: null,
            targetLabel: input.message.slice(0, 80),
            details: JSON.stringify({
              message: input.message.slice(0, 300),
              durationMs,
              contextChars: ctx.chars,
              historyTurns: input.history?.length ?? 0,
            }),
          },
        }).catch(() => undefined)
      } catch (err) {
        send('error', JSON.stringify({ message: err instanceof Error ? err.message : 'Errore del model' }))
      } finally {
        try { controller.close() } catch { /* già chiuso */ }
      }
    },
  })

  return new Response(stream, { headers })
}
