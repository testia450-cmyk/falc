/* ================================================================
 * /api/v2/playbooks/{id} — PATCH (modifica) + DELETE (16.7 W3.5)
 * Operazioni su un playbook REALE del DB nello scope di lettura
 * dell'elenco (impianto + globali; 404 per id inesistente o di
 * altro impianto).
 *  · PATCH (role ≥ TECNICO): corpo vuoto/senza campi riconosciuti →
 *    422 NO_CHANGES (refine «almeno un campo», fatto QUI perché lo
 *    schema contratto è un partial puro). steps presente = SOSTITUZIONE
 *    INTEGRALE (deleteMany + createMany in $transaction, stepOrder
 *    1..n: non un merge — semantica dichiarata, mai input ignorato in
 *    silenzio); rispecificare le STEsse steps non è una modifica
 *    (422 NO_CHANGES). Audit PLAYBOOK_UPDATE con diff sintetico
 *    {campo: from→to, steps: replaced} in TRANSAZIONE.
 *  · DELETE (role ≥ TECNICO): delete con CASCADE delle steps
 *    (relazione dello schema) + audit PLAYBOOK_DELETE {name, steps}.
 *    Risponde {id}.
 *  · NESSUN endpoint run: l'esecuzione non è disponibile in replay.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdatePlaybookInputSchema, PlaybookRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { toPlaybookRow, PLAYBOOK_INCLUDE } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

function notFound() {
  return fail('NOT_FOUND', 'Playbook non trovato in questo impianto', 404)
}

/** Steps normalizzate per il confronto (rispecificare le STESSE
 *  steps con lo STESSO ordine non è una modifica). */
function normSteps(steps: Array<{ name: string; action: string; params?: string }>): unknown {
  return steps.map((s) => ({ name: s.name, action: s.action, params: s.params ?? '' }))
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo fra name, description, triggerRule, enabled, steps)', 422)
  }
  const parsed = UpdatePlaybookInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Corpo vuoto = nessun campo riconosciuto: il partial puro dello
   * schema lascerebbe passare {} — qui serve ALMENO un campo. */
  const bodyKeys = rawBody && typeof rawBody === 'object' && !Array.isArray(rawBody)
    ? Object.keys(rawBody as Record<string, unknown>)
    : []
  if (bodyKeys.length === 0) {
    return fail('NO_CHANGES', 'Nessun campo nella patch: serve almeno un campo fra name, description, triggerRule, enabled, steps', 422)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const existing = await db.playbook.findFirst({
    where: { id, OR: [{ plantId: p.id }, { plantId: null }] },
    include: PLAYBOOK_INCLUDE,
  })
  if (!existing) return notFound()

  /* --- Diff PRIMA della scrittura (patch senza ALCUN effetto reale
   *      → 422 NO_CHANGES: mai no-op silenzioso) --- */
  const nameChanged = input.name !== undefined && input.name !== existing.name
  const descriptionChanged = input.description !== undefined && input.description !== existing.description
  const triggerRuleChanged = input.triggerRule !== undefined && input.triggerRule !== existing.triggerRule
  const enabledChanged = input.enabled !== undefined && input.enabled !== existing.enabled
  const stepsChanged = input.steps !== undefined
    && JSON.stringify(normSteps(input.steps)) !== JSON.stringify(normSteps(
      existing.steps.map((s) => ({ name: s.description, action: s.actionType, params: s.params })),
    ))
  if (!nameChanged && !descriptionChanged && !triggerRuleChanged && !enabledChanged && !stepsChanged) {
    return fail('NO_CHANGES', 'Nessun campo modificato: la patch non ha alcun effetto sul playbook (stato già conforme alla richiesta)', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update (+ sostituzione integrale steps) + audit in
   *      transazione interattiva --- */
  const updated = await db.$transaction(async (tx) => {
    const data: Prisma.PlaybookUpdateInput = {}
    if (nameChanged) data.name = input.name!
    if (descriptionChanged) data.description = input.description!
    if (triggerRuleChanged) data.triggerRule = input.triggerRule!
    if (enabledChanged) data.enabled = input.enabled!
    const b = await tx.playbook.update({ where: { id: existing.id }, data })

    let replaced = 0
    if (stepsChanged && input.steps) {
      /* SOSTITUZIONE INTEGRALE: prima si azzera, poi si ricrea 1..n */
      await tx.playbookStep.deleteMany({ where: { playbookId: existing.id } })
      await tx.playbookStep.createMany({
        data: input.steps.map((s, i) => ({
          playbookId: existing.id,
          order: i + 1,
          actionType: s.action,
          params: s.params ?? '',
          description: s.name,
        })),
        // niente skipDuplicates: NON supportato su SQLite/Prisma; sicuro
        // senza perché le steps sono state appena azzerate (deleteMany)
      })
      replaced = input.steps.length
    }

    /* Diff sintetico + steps replaced count */
    const changes: Record<string, unknown> = {}
    if (nameChanged) changes.name = { from: existing.name, to: input.name }
    if (descriptionChanged) changes.description = { from: existing.description.slice(0, 80), to: input.description!.slice(0, 80) }
    if (triggerRuleChanged) changes.triggerRule = { from: existing.triggerRule, to: input.triggerRule }
    if (enabledChanged) changes.enabled = { from: existing.enabled, to: input.enabled }
    if (stepsChanged) changes.steps = { replaced: replaced, before: existing.steps.length }

    await tx.auditLog.create({
      data: {
        action: 'PLAYBOOK_UPDATE',
        actor: email,
        targetId: b.id,
        targetLabel: b.name.slice(0, 80),
        plantId: b.plantId,
        details: JSON.stringify({ playbookId: b.id, name: b.name, changes }),
      },
    })
    return b
  })

  /* Riga aggiornata con le steps ricaricate */
  const row = await db.playbook.findUnique({
    where: { id: updated.id },
    include: PLAYBOOK_INCLUDE,
  })
  if (!row) return notFound()

  const data = toPlaybookRow(row)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(PlaybookRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}

/* ================================================================ */

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response

  const { id } = await ctx.params
  const existing = await db.playbook.findFirst({
    where: { id, OR: [{ plantId: plant.plant.id }, { plantId: null }] },
    include: PLAYBOOK_INCLUDE,
  })
  if (!existing) return notFound()

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Delete + audit in transazione: le steps cadono a CASCADE
   *      (relazione onDelete: Cascade dello schema — contate PRIMA
   *      per l'audit, onestà del dettaglio). --- */
  await db.$transaction(async (tx) => {
    await tx.playbook.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'PLAYBOOK_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.name.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({
          playbookId: existing.id,
          name: existing.name,
          steps: existing.steps.length,
          triggerRule: existing.triggerRule || 'manuale',
        }),
      },
    })
  })

  const data = { id: existing.id }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  return ok(data, now.getTime(), mode)
}
