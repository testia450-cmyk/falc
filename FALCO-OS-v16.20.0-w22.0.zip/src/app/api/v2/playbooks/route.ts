/* ================================================================
 * /api/v2/playbooks — GET (elenco) + POST (creazione, 16.7 W3.5)
 * Playbook REALI del DB (modelli Playbook/PlaybookStep v10.41): DB
 * reale: 0 playbook → total 0 (onesto, non errore).
 *  · GET: playbook dell'impianto + quelli GLOBALI (plantId null),
 *    name asc, con steps in ordine di esecuzione (stepOrder asc).
 *    Mappatura dichiarata (il modello v15 non ha una colonna «name»
 *    per il passo): step.name → PlaybookStep.description,
 *    step.action → actionType (vocabolario PLAYBOOK_ACTIONS),
 *    params JSON grezzo ("" = nessuno). runCount/lastRunAt grezzi
 *    (0/null nel replay: nessuna esecuzione, dichiarato).
 *  · POST (role ≥ TECNICO): steps validati dal contratto (1-30, azioni
 *    del vocabolario PLAYBOOK_ACTIONS); crea playbook (plantId del
 *    plant) + steps con stepOrder 1..n in $TRANSAZIONE;
 *    triggerRule opzionale ("" = manuale). Audit PLAYBOOK_CREATE
 *    (name, steps count). 201 con la riga e le steps.
 *  · NESSUN endpoint run da questa ondata: l'esecuzione NON è
 *    disponibile in modalità riproduzione (dichiarato in UI, il
 *    backend non finge avvii).
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { PlaybooksPageSchema, PlaybookRowSchema, CreatePlaybookInputSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant, maxOf } from '@/app/api/v2/shared'
import { toPlaybookRow, PLAYBOOK_INCLUDE } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* Playbook dell'impianto + GLOBALI (plantId null): un playbook
   * globale vale per ogni impianto (semantica del modello v15). */
  const books = await db.playbook.findMany({
    where: { OR: [{ plantId: p.id }, { plantId: null }] },
    include: PLAYBOOK_INCLUDE,
    orderBy: { name: 'asc' },
  })

  const data = {
    items: books.map(toPlaybookRow),
    total: books.length, // 0 = nessun playbook (onesto)
  }

  const asOf = maxOf(...books.map((b) => b.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(PlaybooksPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, description?, triggerRule?, steps: […] } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name e steps)', 422)
  }
  const parsed = CreatePlaybookInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Playbook + steps in transazione: stepOrder 1..n nell'ordine
   *      dell'operatore; mappatura dichiarata name→description,
   *      action→actionType, params "" se assente. --- */
  const created = await db.$transaction(async (tx) => {
    const book = await tx.playbook.create({
      data: {
        plantId: p.id,
        name: input.name,
        description: input.description ?? '',
        triggerRule: input.triggerRule ?? '', // "" = manuale
        enabled: input.enabled ?? true,
        runCount: 0, // onesto: mai eseguito in replay
        lastRunAt: null,
        createdBy: email,
      },
    })
    await tx.playbookStep.createMany({
      data: input.steps.map((s, i) => ({
        playbookId: book.id,
        order: i + 1,
        actionType: s.action,
        params: s.params ?? '',
        description: s.name,
      })),
      // niente skipDuplicates: NON supportato su SQLite/Prisma; sicuro
      // senza perché il playbook è appena creato (nessuna step esiste)
    })
    await tx.auditLog.create({
      data: {
        action: 'PLAYBOOK_CREATE',
        actor: email,
        targetId: book.id,
        targetLabel: book.name.slice(0, 80),
        plantId: book.plantId,
        details: JSON.stringify({
          playbookId: book.id,
          name: book.name,
          steps: input.steps.length,
          triggerRule: book.triggerRule || 'manuale',
          enabled: book.enabled,
        }),
      },
    })
    return book
  })

  /* Riga di risposta con le steps appena scritte */
  const row = await db.playbook.findUnique({
    where: { id: created.id },
    include: PLAYBOOK_INCLUDE,
  })
  if (!row) return fail('CREATE_FAILED', 'Playbook creato ma non rileggibile', 500)

  const data = toPlaybookRow(row)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(PlaybookRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
