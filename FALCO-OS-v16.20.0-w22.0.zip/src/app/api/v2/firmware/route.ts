/* ================================================================
 * /api/v2/firmware — GET (elenco) + POST (pianificazione, 16.7 W3.5)
 * Job di upgrade firmware REALI del DB (modello FirmwareUpgradeJob v15
 * fase G2: scheduler con commit-confirm obbligatorio). DB reale:
 * 0 job → total 0 (onesto, non errore).
 *  · GET: job per createdAt desc con device in join (hostname/type/
 *    firmwareVersion ATTUALE dal DB; "" = n.d., la label vive in UI).
 *  · POST (role ≥ TECNICO): device REALE nello scope del plant (404);
 *    targetFirmware OBBLIGATORIO (zod); comandi custom OPZIONALI ma,
 *    se presenti, contro il guardrail FORBIDDEN_COMMAND_PATTERNS →
 *    422 FORBIDDEN_COMMAND; executor default 'SIMULATED'; scheduledAt
 *    default ora; status SCHEDULED — NESSUNA esecuzione in replay
 *    (dichiarato nell'output del job: onesto, mai un upgrade finto).
 *    Audit FIRMWARE_JOB_CREATE in TRANSAZIONE. 201 con la riga.
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { FirmwareJobsPageSchema, FirmwareJobRowSchema, CreateFirmwareJobInputSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, resolvePlant, maxOf } from '@/app/api/v2/shared'
import {
  toFirmwareJobRow, FIRMWARE_INCLUDE, forbiddenCommandHits, guardrailReject,
} from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const jobs = await db.firmwareUpgradeJob.findMany({
    where: { device: { plantId: p.id } }, // v16.12 W10: scope per plantId diretto
    include: FIRMWARE_INCLUDE,
    orderBy: { createdAt: 'desc' },
  })

  const data = {
    items: jobs.map(toFirmwareJobRow),
    total: jobs.length, // 0 = nessun job (onesto)
  }

  const asOf = maxOf(...jobs.map((j) => j.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(FirmwareJobsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { deviceId, targetFirmware, commands?, … } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con deviceId e targetFirmware)', 422)
  }
  const parsed = CreateFirmwareJobInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- Device REALE nello scope del plant (404) --- */
  const device = await db.device.findFirst({
    where: {
      id: input.deviceId,
      plantId: p.id, // v16.12 W10: scope per plantId diretto
      decommissionedAt: null,
    },
    select: { id: true, hostname: true, firmwareVersion: true },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato (o fuori dallo scope dell\'impianto, o dismesso)', 404)

  /* --- Guardrail v15 sui comandi custom (se presenti) --- */
  if (input.commands && input.commands.length > 0) {
    const hits = forbiddenCommandHits(input.commands)
    if (hits.length > 0) return guardrailReject(hits)
  }

  const executor = input.executor ?? 'SIMULATED'
  const confirmMinutes = input.confirmMinutes ?? 10 // default del modello v15 (upgrade = alto impatto)
  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()
  const scheduledAt = input.scheduledAt != null ? new Date(input.scheduledAt) : now

  const created = await db.$transaction(async (tx) => {
    const j = await tx.firmwareUpgradeJob.create({
      data: {
        deviceId: device.id,
        targetFirmware: input.targetFirmware,
        commandsJson: JSON.stringify(input.commands ?? []),
        executor,
        scheduledAt,
        confirmMinutes,
        status: 'SCHEDULED', // NESSUNA esecuzione in replay: dichiarato
        output: 'job pianificato: l\'esecuzione NON è disponibile in modalità riproduzione (nessun poller attivo) — dry-run dichiarato alla applicazione',
        error: '',
        requestedById: email,
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'FIRMWARE_JOB_CREATE',
        actor: email,
        targetId: j.id,
        targetLabel: `${device.hostname} → ${input.targetFirmware}`.slice(0, 80),
        plantId: p.id,
        details: JSON.stringify({
          jobId: j.id,
          deviceId: device.id,
          deviceHostname: device.hostname,
          currentFirmware: device.firmwareVersion, // attuale REALE dal DB ("" = n.d.)
          targetFirmware: input.targetFirmware,
          executor,
          scheduledAt: scheduledAt.getTime(),
          confirmMinutes,
          commands: (input.commands ?? []).length,
          status: j.status,
          note: 'nessuna esecuzione in replay: il job resta SCHEDULED fino a cancel/aggiornamento',
        }),
      },
    })
    return j
  })

  /* Riga di risposta con la join del device */
  const row = await db.firmwareUpgradeJob.findUnique({
    where: { id: created.id },
    include: FIRMWARE_INCLUDE,
  })
  if (!row) return fail('CREATE_FAILED', 'Job firmware creato ma non rileggibile', 500)

  const data = toFirmwareJobRow(row)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(FirmwareJobRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
