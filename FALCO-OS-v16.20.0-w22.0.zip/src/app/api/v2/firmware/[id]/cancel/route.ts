/* ================================================================
 * /api/v2/firmware/{id}/cancel — POST (16.7 W3.5)
 * Annullamento di un job firmware REALE: SCHEDULED → CANCELED.
 * Da qualunque altro stato (già in esecuzione, applicato, confermato,
 * rotolato back, fallito o già annullato) → 422 INVALID_TRANSITION
 * con lo stato attuale (mai silenzio, mai stato inventato).
 *  · role ≥ TECNICO; 404 per job o device inesistente;
 *  · update + audit FIRMWARE_JOB_CANCEL {from, to, deviceId,
 *    targetFirmware} in TRANSAZIONE;
 *  · risposta: la riga aggiornata (FirmwareJobRowSchema).
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { FirmwareJobRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { toFirmwareJobRow, FIRMWARE_INCLUDE } from '@/app/api/v2/ops-shared'

export const dynamic = 'force-dynamic'

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  const job = await db.firmwareUpgradeJob.findUnique({
    where: { id },
    include: FIRMWARE_INCLUDE,
  })
  if (!job) return fail('NOT_FOUND', 'Job firmware non trovato', 404)

  if (job.status !== 'SCHEDULED') {
    return fail('INVALID_TRANSITION', `Transizione non consentita: ${job.status} → CANCELED. Solo un job SCHEDULED può essere annullato (stato attuale: ${job.status}).`, 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + audit in transazione interattiva --- */
  const updated = await db.$transaction(async (tx) => {
    const j = await tx.firmwareUpgradeJob.update({
      where: { id: job.id },
      data: { status: 'CANCELED' },
      include: FIRMWARE_INCLUDE,
    })
    await tx.auditLog.create({
      data: {
        action: 'FIRMWARE_JOB_CANCEL',
        actor: email,
        targetId: j.id,
        targetLabel: `${j.device?.hostname ?? j.deviceId} → ${j.targetFirmware}`.slice(0, 80),
        plantId: j.device?.location?.plantId ?? null,
        details: JSON.stringify({
          jobId: j.id,
          deviceId: j.deviceId,
          targetFirmware: j.targetFirmware,
          from: 'SCHEDULED',
          to: 'CANCELED',
          by: email,
        }),
      },
    })
    return j
  })

  const data = toFirmwareJobRow(updated)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(FirmwareJobRowSchema, data)
  return ok(data, now.getTime(), mode)
}
