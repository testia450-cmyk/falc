/* ================================================================
 * /api/v2/setup/engine — GET · POST (v16.20 W22 «AUTO-RESUME»)
 * ================================================================
 * Il «puller» del setup: avvio/arresto del motore di monitoraggio
 * continuo per l'impianto attivo + stato vivo (cicli, campioni
 * scritti, eventi aperti/chiusi, notifiche, errori).
 *
 *   GET  → stato di TUTTI i motori attivi + righe EngineRuntime
 *          PERSISTITE (osservabilità: enabled, heartbeat, startedVia);
 *   POST { action: 'start', intervalSec?, radioEvery? } → avvia per
 *          l'impianto (primo ciclo SUBITO, poi ogni intervalSec) e
 *          PERSISTISCE la configurazione (auto-resume al riavvio);
 *        { action: 'stop' } → arresta (enabled=false: l'auto-resume
 *          del prossimo avvio LO RISPETTA — mai resurrezioni).
 *
 * Onestà dichiarata nella risposta: il motore vive nel processo del
 * server ma la configurazione è PERSISTITA — al riavvio del server
 * l'auto-resume (src/instrumentation.ts) lo RIATTIVA da solo.
 * RBAC: TECNICO+ (azione di monitoraggio attiva).
 * ================================================================ */

import { z } from 'zod'
import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { monitoringEngineStatus, monitoringEngineStatusFor, startMonitoringEngine, stopMonitoringEngine, engineRuntimeRows } from '@/lib/v2/polling-engine'

export const dynamic = 'force-dynamic'

const BodySchema = z.object({
  action: z.enum(['start', 'stop']),
  plantId: z.string().optional(),
  intervalSec: z.number().int().min(5).max(3600).optional(),
  radioEvery: z.number().int().min(1).max(60).optional(),
})

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plantId = url.searchParams.get('plantId')
  const rows = plantId ? [monitoringEngineStatusFor(plantId)].filter(Boolean) : monitoringEngineStatus()
  const runtimes = await engineRuntimeRows()

  const data = {
    engines: rows,
    runtimes: plantId ? runtimes.filter((r) => r.plantId === plantId) : runtimes,
    honestNotes: [
      'AUTO-RESUME ENTERPRISE (v16.20): la configurazione del motore è persistita nel DB (EngineRuntime) — al riavvio del server viene RIATTIVATO da solo con gli stessi parametri.',
      'L\u2019arresto VOLONTARIO è rispettato: un motore fermato da un operatore NON viene resuscitato al riavvio (enabled=false).',
      'A ogni ciclo: presenza (ping) + liveness SNMP + valutazione allarmi con dedup; la telemetria radio ogni N cicli. Heartbeat persistito a ogni ciclo (lastHeartbeatAt).',
      'PORT_STATE_CHANGE e NEW_DEVICE_SEEN restano del wizard on-demand (servono sonde L2 / scansioni).',
    ],
  }
  const replay = await getReplayState()
  return ok(data, Date.now(), apiMode(replay))
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono avviare il motore di monitoraggio', 403)
  }

  let raw: unknown = {}
  try {
    const text = await req.text()
    if (text.trim() !== '') raw = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = BodySchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri motore non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plantId = input.plantId ?? url.searchParams.get('plantId')
  if (!plantId) return fail('BAD_BODY', 'Impianto richiesto (query ?plantId= o body)', 422)

  if (input.action === 'stop') {
    const stopped = await stopMonitoringEngine(plantId, 'arresto richiesto dalla UI')
    await db.auditLog.create({
      data: {
        action: 'SETUP_MONITORING',
        actor: session.session.user.email ?? 'sconosciuto',
        targetId: plantId,
        targetLabel: 'motore monitoraggio: arresto',
        plantId,
        details: JSON.stringify({ action: 'stop', cycles: stopped?.cycles ?? 0, metricsWritten: stopped?.metricsWritten ?? 0 }),
      },
    }).catch(() => { /* audit best-effort */ })
    const replay = await getReplayState()
    return ok({ action: 'stop', stopped: stopped != null, engines: monitoringEngineStatus() }, Date.now(), apiMode(replay))
  }

  const started = await startMonitoringEngine({ plantId, intervalSec: input.intervalSec, radioEvery: input.radioEvery, via: 'WIZARD' })
  if ('error' in started) {
    return fail('NOT_FOUND', started.error, 404)
  }
  await db.auditLog.create({
    data: {
      action: 'SETUP_MONITORING',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: plantId,
      targetLabel: `motore monitoraggio: avvio (${started.intervalSec}s)`,
      plantId,
      details: JSON.stringify({
        action: 'start',
        intervalSec: started.intervalSec,
        radioEvery: started.radioEvery,
        note: 'configurazione PERSISTITA in EngineRuntime (auto-resume enterprise): al riavvio del server il motore si riattiva da solo',
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const replay = await getReplayState()
  const data = { action: 'start', engine: started, engines: monitoringEngineStatus() }
  return ok(data, Date.now(), apiMode(replay))
}
