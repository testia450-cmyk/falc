/* ================================================================
 * /api/v2/setup/scan — POST (v16.19 W21 — fase 2 del wizard setup)
 * ================================================================
 * Domanda a cui risponde: «Chi c'è DAVVERO su questa rete, e com'è
 * fatto?» — sweep TCP sul CIDR dell'impianto + identificazione batch
 * (SNMP multi-community, banner HTTP, OUI) con PERSISTENZA del job
 * (DiscoveryJob, finalmente vivo in v16) e CONFRONTO con l'inventario
 * dichiarato (l'Excel del progetto): confermati / mancanti / nuovi.
 *
 * Pattern verificati online (01/11/2026):
 *   · LibreNMS `scan:network` — sweep CIDR con credenziali SNMP di
 *     default + ping, «addresses that already belong to a device are
 *     skipped», --ping-fallback aggiunge come ICMP-only;
 *   · Zabbix network discovery — discovery + actions, evento per ogni
 *     check, unicità per IP.
 * Qui: la scansione è READ-ONLY sull'inventario (nessuna scrittura di
 * Device), i risultati vengono PERSISTITI nel job (tracciabilità) e il
 * confronto è onesto: un IP dichiarato e non visto resta «mancante»,
 * mai eliminato né inventato.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { SetupScanInputSchema, SetupScanResultSchema, type SetupCandidate } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Cap identificazione: 64 host vivi (2 chunk da 32 — deadline servizio 55 s cad.) */
const IDENTIFY_CAP = 64
const CHUNK = 32

/** Le porte standard del set di probe (v16.8): le tcpPorts passate alla
 *  sonda vendor sono SOLO le extra dichiarate dall'operatore. */
const STANDARD_PROBE_PORTS = [22, 80, 161, 443, 554, 631, 5000, 5060, 7547, 8080, 8291, 8899, 9100, 34567, 37777]

/** Trasformazione candidata → dispositivo FALCO (suggerimento onesto). */
function suggest(classification: { type: string }, httpServer: string | null): { type: string; monitorMode: 'full' | 'ping'; reason: string } {
  const t = classification.type
  if (t === 'CAMERA' || t === 'LPR' || t === 'ONT') {
    return { type: t, monitorMode: 'ping', reason: `endpoint ${t}: per i TLC conta la presenza (ping), non i valori` }
  }
  if (t === 'UNKNOWN' && httpServer && /ont|modem|alcatel|home ?box|hg8|fibra/i.test(httpServer)) {
    return { type: 'ONT', monitorMode: 'ping', reason: `banner HTTP «${httpServer}»: apparato TLC/operatora → ping-only` }
  }
  return { type: t === 'UNKNOWN' ? 'SERVER' : t, monitorMode: 'full', reason: 'apparato gestito: telemetria completa (SNMP/sonde)' }
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono avviare la scansione dell\'impianto', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = SetupScanInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri di scansione setup non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Il client API invia l'impianto come ?plantId= (convenzione v2Url):
   * il body lo può confermare, ma la query vince se il body tace. */
  const url = new URL(req.url)
  const plantIdHint = input.plantId ?? url.searchParams.get('plantId') ?? undefined
  const plant = await resolvePlant(plantIdHint)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const warnings: string[] = []

  /* --- job PERSISTITO: RUNNING prima di toccare la rete --- */
  const job = await db.discoveryJob.create({
    data: {
      plantId: p.id,
      subnet: input.cidr,
      status: 'RUNNING',
      triggeredBy: 'MANUAL',
      config: JSON.stringify({
        cidr: input.cidr,
        ports: input.ports ?? null,
        communities: input.communities ?? [],
        snmpPort: input.snmpPort ?? 161,
        httpPort: input.httpPort ?? null,
        wizard: 'W21',
      }),
    },
  })

  /* --- (1) sweep TCP sul CIDR --- */
  const prScan = await discoveryPost('/scan', {
    cidr: input.cidr,
    ports: input.ports,
    timeoutMs: input.timeoutMs ?? 900,
    maxHosts: 256,
    adaptive: true,
  }, { timeoutMs: 60_000 })
  if (!prScan.ok) {
    await db.discoveryJob.update({ where: { id: job.id }, data: { status: 'FAILED', error: 'servizio discovery non raggiungibile', finishedAt: new Date() } })
    return proxyFail(prScan)
  }
  const scanJob = (prScan.body as { job?: { hosts: Array<{ ip: string; alive: true; latencyMs: number; openPorts: Array<{ port: number }> }>; summary: { scanned: number; up: number }; durationMs: number } }).job
  if (!scanJob) {
    await db.discoveryJob.update({ where: { id: job.id }, data: { status: 'FAILED', error: 'payload scan inatteso', finishedAt: new Date() } })
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
  }

  const aliveHosts = scanJob.hosts.filter((h) => h.alive)
  await db.discoveryJob.update({
    where: { id: job.id },
    data: { hostsScanned: scanJob.summary.scanned, devicesFound: aliveHosts.length, progress: 50 },
  })

  /* --- (2) identificazione batch (chunk ≤32, cap onesto 64) --- */
  const communities = (input.communities ?? []).slice(0, 8)
  if (communities.length === 0) communities.push('public')
  const identifyTargets = aliveHosts.slice(0, IDENTIFY_CAP).map((h) => h.ip)
  if (aliveHosts.length > IDENTIFY_CAP) {
    warnings.push(`identificazione limitata ai primi ${IDENTIFY_CAP} host vivi su ${aliveHosts.length} (cap wizard)`)
  }

  const rawResults: Array<Record<string, unknown>> = []
  for (let i = 0; i < identifyTargets.length; i += CHUNK) {
    const chunk = identifyTargets.slice(i, i + CHUNK)
    const prBatch = await discoveryPost('/probe/vendor/batch', {
      targets: chunk,
      snmp: { communities, version: 'v2c', ...(input.snmpPort != null ? { port: input.snmpPort } : {}) },
      ...(input.httpPort != null ? { httpPort: input.httpPort } : {}),
      /* Le porte «extra» dello sweep entrano anche nella sonda vendor:
       * gli openPorts dichiarano SSH/API su porte non standard. */
      ...(() => {
        const extraTcp = (input.ports ?? []).filter((p) => !STANDARD_PROBE_PORTS.includes(p)).slice(0, 8)
        return extraTcp.length > 0 ? { tcpPorts: extraTcp } : {}
      })(),
      concurrency: 8,
      timeoutMs: 1500,
    }, { timeoutMs: 60_000 })
    if (!prBatch.ok) {
      warnings.push(`chunk ${Math.floor(i / CHUNK) + 1}: identificazione non riuscita (${(prBatch.body as { error?: { code?: string } })?.error?.code ?? 'errore'})`)
      continue
    }
    const bj = (prBatch.body as { job?: { results: Array<Record<string, unknown>> } }).job
    if (bj?.results) rawResults.push(...bj.results)
  }

  /* --- inventario attuale per il confronto (IP → device) --- */
  const inventory = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: { id: true, hostname: true, ip: true },
  })
  const byIp = new Map<string, { id: string; hostname: string }>()
  for (const d of inventory) if (!byIp.has(d.ip)) byIp.set(d.ip, { id: d.id, hostname: d.hostname })

  /* --- candidati: evidenza grezza + stato inventario + suggerimento --- */
  const scanByIp = new Map(aliveHosts.map((h) => [h.ip, h]))
  const candidates: SetupCandidate[] = []
  for (const r of rawResults) {
    const ip = String(r.ip ?? '')
    const sweep = scanByIp.get(ip)
    const snmpRaw = (r.snmp ?? null) as Record<string, unknown> | null
    const snmpReachable = snmpRaw?.reachable === true
    const matched = (snmpRaw?.matched ?? null) as { community?: string } | null
    const vendorGuess = (snmpRaw?.vendorGuess ?? null) as { vendor?: string } | null
    const product = (snmpRaw?.product ?? null) as { model?: string; osFamily?: string } | null
    const httpRaw = (r.http ?? null) as { server?: string | null; title?: string | null } | null
    const clsRaw = (r.classification ?? {}) as Record<string, unknown>
    const ouiRaw = (r.oui ?? null) as { mac?: string; vendor?: string } | null
    /* openPorts: number[] nel risultato vendor (il batch dello sweep
     * TORNA solo le porte aperte) — difensivo anche verso la forma
     * {port,state} della sonda singola. */
    const openPortsRaw = r.openPorts
    const openPorts: number[] = Array.isArray(openPortsRaw)
      ? openPortsRaw
        .map((x) => (typeof x === 'number' ? x : Number((x as { port?: number }).port)))
        .filter((n) => Number.isInteger(n) && n > 0 && n < 65536)
      : []

    const inv = byIp.get(ip) ?? null
    const sug = suggest(
      { type: String(clsRaw.type ?? 'UNKNOWN') },
      httpRaw?.server ?? null,
    )

    candidates.push({
      ip,
      alive: r.alive === true,
      latencyMs: typeof r.latencyMs === 'number' ? r.latencyMs : sweep?.latencyMs ?? null,
      openPorts,
      snmp: {
        reachable: snmpReachable,
        matchedCommunity: matched?.community ?? null,
        sysName: (snmpRaw?.sysName as string | null) ?? null,
        sysDescr: (snmpRaw?.sysDescr as string | null) ?? null,
        mac: (snmpRaw?.mac as string | null) ?? ouiRaw?.mac ?? null,
        vendor: vendorGuess?.vendor ?? (clsRaw.brand as string | null) ?? null,
        model: product?.model ?? (clsRaw.model as string | null) ?? null,
        osFamily: product?.osFamily ?? null,
        snmpPort: input.snmpPort ?? 161,
      },
      http: httpRaw ? { server: httpRaw.server ?? null, title: httpRaw.title ?? null } : null,
      classification: {
        type: String(clsRaw.type ?? 'UNKNOWN'),
        brand: (clsRaw.brand as string | null) ?? null,
        model: (clsRaw.model as string | null) ?? null,
        confidence: String(clsRaw.confidence ?? 'low'),
        evidenceCount: Array.isArray(clsRaw.evidence) ? (clsRaw.evidence as unknown[]).length : 0,
      },
      inInventory: inv != null,
      deviceId: inv?.id ?? null,
      deviceHostname: inv?.hostname ?? null,
      suggestedType: sug.type,
      suggestedMonitorMode: sug.monitorMode,
      suggestionReason: sug.reason,
    })
  }

  /* --- confronto onesto inventario (rete ipotetica) vs scansione --- */
  const seenIps = new Set(candidates.map((c) => c.ip))
  const confirmed = candidates.filter((c) => c.inInventory).length
  const newSeen = candidates.filter((c) => !c.inInventory).length
  const missingDevices = inventory.filter((d) => !seenIps.has(d.ip))
  const missingIps = [...new Set(missingDevices.map((d) => d.ip))].slice(0, 50)

  /* --- persistenza ESITO nel job (tracciabilità completa) --- */
  const compactResults = candidates.map((c) => ({
    ip: c.ip,
    alive: c.alive,
    latencyMs: c.latencyMs,
    openPorts: c.openPorts,
    snmp: { reachable: c.snmp.reachable, community: c.snmp.matchedCommunity, sysName: c.snmp.sysName, sysDescr: c.snmp.sysDescr, mac: c.snmp.mac, vendor: c.snmp.vendor, model: c.snmp.model },
    http: c.http,
    classification: { type: c.classification.type, brand: c.classification.brand, model: c.classification.model, confidence: c.classification.confidence },
    inInventory: c.inInventory,
  }))
  await db.discoveryJob.update({
    where: { id: job.id },
    data: {
      status: 'COMPLETED',
      progress: 100,
      devicesFound: candidates.length,
      finishedAt: new Date(),
      config: JSON.stringify({
        cidr: input.cidr,
        ports: input.ports ?? null,
        communities,
        snmpPort: input.snmpPort ?? 161,
        httpPort: input.httpPort ?? null,
        wizard: 'W21',
        results: compactResults,
        comparison: { confirmed, missing: missingIps.length, newSeen },
      }),
    },
  })

  /* --- audit --- */
  await db.auditLog.create({
    data: {
      action: 'SETUP_SCAN',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: p.id,
      targetLabel: `wizard setup · ${input.cidr}`,
      plantId: p.id,
      details: JSON.stringify({
        jobId: job.id,
        cidr: input.cidr,
        scanned: scanJob.summary.scanned,
        up: aliveHosts.length,
        identified: candidates.length,
        confirmed,
        missing: missingIps.length,
        newSeen,
        snmpPort: input.snmpPort ?? 161,
        durationMs: scanJob.durationMs,
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const data = {
    jobId: job.id,
    cidr: input.cidr,
    scanned: scanJob.summary.scanned,
    up: aliveHosts.length,
    durationMs: scanJob.durationMs,
    identified: candidates.length,
    candidates,
    comparison: { confirmed, missing: missingIps.length, newSeen, missingIps },
    warnings,
  }
  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SetupScanResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
