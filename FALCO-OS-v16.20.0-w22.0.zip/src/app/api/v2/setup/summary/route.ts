/* ================================================================
 * /api/v2/setup/summary — GET (v16.19 W21 — fase 7: riepilogo finale)
 * ================================================================
 * «La verifica globale alla chiusura del setup»: 100 apparati visti?
 * 30 antenne con SNMP ok, credenziali ok, dati LETTI? 30 switch con
 * sonde L2? 40 TLC monitorate? Motore avviato, DB che ha costruito la
 * rete, MAC confrontati, vendor letti o da specificare?
 *
 * TUTTO quello che risponde è contato dal DB reale e dai servizi reali
 * (nessun dato dichiarativo): conteggi per fase + stato motori +
 * note oneste dove la verità è parziale. La rotta risponde 200 con
 * dbReachable=true SOLO perché le query hanno funzionato davvero.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { SetupSummaryResultSchema } from '@/lib/v2/contracts'
import { discoveryGet } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { monitoringEngineStatusFor } from '@/lib/v2/polling-engine'

export const dynamic = 'force-dynamic'

const TWO_HOURS_MS = 2 * 3600 * 1000

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* La riga COMPLETA del plant (kmzFile, criticalityLevel, createdAt non
   * stanno nella vista PlantLite usata da resolvePlant). */
  const plantRow = await db.plant.findUnique({
    where: { id: p.id },
    select: { kmzFile: true, criticalityLevel: true, createdAt: true, snmpCommunities: true },
  })

  const now = new Date()
  const since2h = new Date(now.getTime() - TWO_HOURS_MS)

  /* ---------------- Fase import (Excel/KMZ) ---------------- */
  const [locations, devices, devicesWithCreds] = await Promise.all([
    db.location.count({ where: { plantId: p.id } }),
    db.device.findMany({
      where: { plantId: p.id, decommissionedAt: null },
      select: {
        id: true, hostname: true, ip: true, type: true, status: true,
        macAddress: true, brand: true, monitorMode: true, credentialState: true,
        snmpEnableState: true, lastSeenAt: true, username: true, locationId: true,
      },
      orderBy: { hostname: 'asc' },
    }),
    db.device.count({ where: { plantId: p.id, decommissionedAt: null, NOT: { username: '' } } }),
  ])

  const byType = new Map<string, number>()
  for (const d of devices) byType.set(d.type, (byType.get(d.type) ?? 0) + 1)

  /* ---------------- Fase scansione (job persistiti) ---------------- */
  const lastJob = await db.discoveryJob.findFirst({
    where: { plantId: p.id },
    orderBy: { startedAt: 'desc' },
  })
  let jobConfig: { results?: Array<{ ip: string; inInventory?: boolean; alive?: boolean }> } = {}
  try {
    jobConfig = lastJob ? JSON.parse(lastJob.config ?? '{}') : {}
  } catch {
    jobConfig = {}
  }
  const jobResults = Array.isArray(jobConfig.results) ? jobConfig.results : []
  const candidatesSeen = jobResults.length
  const candidatesInInventory = jobResults.filter((r) => r.inInventory).length
  const candidatesNew = candidatesSeen - candidatesInInventory

  /* ---------------- Fase credenziali ---------------- */
  const cred = { OK: 0, WRONG: 0, MISSING: 0, UNKNOWN: 0 }
  for (const d of devices) {
    const k = (d.credentialState || 'UNKNOWN') as keyof typeof cred
    if (k in cred) cred[k]++
    else cred.UNKNOWN++
  }
  const snmpEnabled = devices.filter((d) => d.snmpEnableState === 'ENABLED').length
  const pingMode = devices.filter((d) => d.monitorMode === 'ping').length

  /* ---------------- Fase telemetria (campioni REALI ultimi 2 h) ---------------- */
  const [metricRows, radioProbed, pingSwept] = await Promise.all([
    db.metricValue.findMany({
      where: { plantId: p.id, timestamp: { gte: since2h } },
      select: { metric: true },
    }),
    db.auditLog.count({ where: { plantId: p.id, action: 'DEVICE_RADIO_PROBE', createdAt: { gte: since2h } } }),
    db.auditLog.count({ where: { plantId: p.id, action: 'MONITOR_PING_SWEEP', createdAt: { gte: since2h } } }),
  ])
  const metricCounts = new Map<string, number>()
  for (const m of metricRows) metricCounts.set(m.metric, (metricCounts.get(m.metric) ?? 0) + 1)
  const radioMetrics2h = ['cpuLoad', 'memoryUsage', 'signalStrength', 'linkQuality', 'radioClients', 'radioTxRate'].reduce((acc, k) => acc + (metricCounts.get(k) ?? 0), 0)
  const pingMetrics2h = (metricCounts.get('pingLatency') ?? 0) + (metricCounts.get('packetLoss') ?? 0)
  const trafficMetrics2h = (metricCounts.get('port_traffic_in') ?? 0) + (metricCounts.get('port_traffic_out') ?? 0)

  const devicesSeen2h = devices.filter((d) => d.lastSeenAt != null && d.lastSeenAt >= since2h).length
  const devicesOnline = devices.filter((d) => d.status === 'ONLINE').length
  const devicesOffline = devices.filter((d) => d.status === 'OFFLINE').length

  /* L2 sonde: switch/gateway con FDB scritta di recente (sonde L2 vere). */
  const l2Probed = await db.device.count({
    where: {
      plantId: p.id,
      type: { in: ['SWITCH', 'GATEWAY', 'ROUTER', 'FIREWALL'] },
      decommissionedAt: null,
      fdbObservations: { some: { lastSeenAt: { gte: since2h } } },
    },
  })

  /* ---------------- Fase topologia / MAC / vendor ---------------- */
  const [links, linksByEvidenceRaw, fdbCount, arpCount, stpCount, vlanCount, fdbMacs] = await Promise.all([
    db.topologyLink.count({ where: { plantId: p.id } }),
    db.topologyLink.groupBy({ by: ['evidence'], where: { plantId: p.id }, _count: { _all: true } }),
    db.fdbObservation.count({ where: { plantId: p.id } }),
    db.arpEntry.count({ where: { plantId: p.id } }),
    db.stpObservation.count({ where: { plantId: p.id } }),
    db.vlanInventory.count({ where: { plantId: p.id } }),
    db.fdbObservation.findMany({ where: { plantId: p.id }, select: { mac: true }, distinct: ['mac'], take: 512 }),
  ])

  /* MAC confrontati: inventario con MAC vs MAC visti in FDB non in inventario. */
  const inventoryMacs = new Set(
    devices
      .map((d) => (d.macAddress ?? '').trim().toUpperCase())
      .filter((m) => m !== ''),
  )
  const macSeenNotInInventory = fdbMacs.filter((f) => {
    const m = (f.mac ?? '').trim().toUpperCase()
    return m !== '' && !m.startsWith('01:00:5E') && !inventoryMacs.has(m)
  }).length
  const macKnownInInventory = inventoryMacs.size

  const vendorUnknownDevices = devices
    .filter((d) => (d.macAddress ?? '') !== '' && (d.brand ?? '') === '')
    .slice(0, 10)
    .map((d) => ({ hostname: d.hostname, ip: d.ip, macAddress: d.macAddress }))

  /* ---------------- Fase allarmi ---------------- */
  const [rulesEnabled, rulesTotal, eventsOpen, eventsBySeverityRaw] = await Promise.all([
    db.alertRule.count({ where: { plantId: p.id, enabled: true } }),
    db.alertRule.count({ where: { plantId: p.id } }),
    db.alertEvent.count({ where: { plantId: p.id, status: 'OPEN' } }),
    db.alertEvent.groupBy({ by: ['severity'], where: { plantId: p.id, status: 'OPEN' }, _count: { _all: true } }),
  ])

  /* ---------------- Motori (servizi REALI) ---------------- */
  const prHealth = await discoveryGet('/health')
  const h = prHealth.ok ? (prHealth.body as { version?: string; uptimeSec?: number; capabilities?: string[]; oui?: { total?: number } }) : null
  const replay = await getReplayState()

  /* Il motore di monitoraggio continuo (W21-bis): stato VIVO dal
   * processo (cicli, campioni scritti dal puller, eventi aperti/chiusi
   * dalla valutazione continua, notifiche). v16.20 W22: la riga
   * EngineRuntime del DB dice anche SE il motore è configurato per
   * l'auto-resume (enabled) e chi ha avviato la sessione (startedVia). */
  const engine = monitoringEngineStatusFor(p.id)
  const runtimeRow = await db.engineRuntime.findUnique({
    where: { plantId: p.id },
    select: { enabled: true, startedVia: true, intervalSec: true, radioEveryNCycles: true, lastHeartbeatAt: true, totalCycles: true },
  }).catch(() => null)

  const honestNotes: string[] = []
  if (engine?.running) {
    honestNotes.push(`Motore di monitoraggio ATTIVO: tick ogni ${engine.intervalSec}s (presenza + liveness SNMP + valutazione allarmi con dedup), telemetria radio ogni ${engine.radioEvery} cicli. Sessione avviata da ${engine.startedVia === 'AUTO_RESUME' ? 'AUTO-RESUME (riavvio del server)' : engine.startedVia}. AUTO-RESUME ENTERPRISE: la configurazione è persistita nel DB — al prossimo riavvio del server il motore si RIATTIVA da solo.`)
    honestNotes.push(engine.notificationsSkipped > 0
      ? `Notifiche Telegram: ${engine.notificationsSkipped} eventi non inviati (integrazione telegram.botToken o chat id assenti — l'esito è scritto in NotificationLog, mai silenzioso).`
      : 'Notifiche Telegram: nessun invio mancante finora (vedi contatori del motore).')
    honestNotes.push('PORT_STATE_CHANGE e NEW_DEVICE_SEEN restano del wizard on-demand: richiedono sonde L2 / scansioni, non il tick di presenza.')
  } else {
    honestNotes.push(runtimeRow?.enabled
      ? 'Motore di monitoraggio: sessione non attiva in questo processo ma CONFIGURATO per l\u2019auto-resume (EngineRuntime.enabled=true) — verrà riattivato al prossimo avvio del server; oppure riavvialo subito dalla fase Telemetria.'
      : 'Telemetria on-demand: le sonde (radio, L2, ping) partono dal wizard/dalla scheda apparato — il motore continuo è FERMO (arresto volontario o mai avviato): avviarlo dalla fase Telemetria; il tick realtime :3001 è di riproduzione demo (rinfresca freschezza e jitter, non cambia stati).')
    honestNotes.push('Le notifiche EMAIL/TELEGRAM/WEBHOOK non partono dagli allarmi con il motore fermo: il dispatcher è parte del motore — gli eventi restano nel DB e nella vista Allarmi.')
  }
  if (devicesOffline > 0) honestNotes.push(`${devicesOffline} apparati risultano OFFLINE: verificati con sonde reali (nessun dato inventato) — controllare la fase credenziali/telemetria.`)

  const data = {
    plant: {
      id: p.id,
      name: p.name,
      comune: p.comune ?? '',
      criticalityLevel: plantRow?.criticalityLevel ?? 'STANDARD',
      kmzFile: plantRow?.kmzFile ?? '',
      createdAt: plantRow?.createdAt instanceof Date ? plantRow.createdAt.getTime() : 0,
    },
    importPhase: {
      locations,
      devicesInInventory: devices.length,
      devicesByType: [...byType.entries()].map(([type, count]) => ({ type, count })),
      devicesWithSshCredentials: devicesWithCreds,
    },
    scanPhase: {
      lastJob: lastJob
        ? {
          id: lastJob.id,
          subnet: lastJob.subnet,
          status: lastJob.status,
          hostsScanned: lastJob.hostsScanned,
          devicesFound: lastJob.devicesFound,
          startedAt: lastJob.startedAt instanceof Date ? lastJob.startedAt.getTime() : 0,
          finishedAt: lastJob.finishedAt instanceof Date ? lastJob.finishedAt.getTime() : null,
        }
        : null,
      candidatesSeen,
      candidatesInInventory,
      candidatesNew,
    },
    verifyPhase: {
      credentialsOk: cred.OK,
      credentialsWrong: cred.WRONG,
      credentialsMissing: cred.MISSING,
      credentialsUnknown: cred.UNKNOWN,
      snmpEnabled,
      pingMode,
    },
    telemetryPhase: {
      radioProbed,
      l2Probed,
      pingSwept,
      metricSamples2h: metricRows.length,
      radioMetrics2h,
      pingMetrics2h,
      trafficMetrics2h,
      devicesSeen2h,
      devicesOnline,
      devicesOffline,
    },
    topologyPhase: {
      links,
      linksByEvidence: linksByEvidenceRaw.map((g) => ({ evidence: g.evidence ?? '—', count: g._count._all })),
      fdbObservations: fdbCount,
      arpEntries: arpCount,
      stpObservations: stpCount,
      vlans: vlanCount,
      macKnownInInventory,
      macSeenNotInInventory,
      vendorUnknown: vendorUnknownDevices.length,
      vendorUnknownDevices,
    },
    alarmsPhase: {
      rulesEnabled,
      rulesTotal,
      eventsOpen,
      eventsBySeverity: eventsBySeverityRaw.map((g) => ({ severity: g.severity, count: g._count._all })),
    },
    engines: {
      discoveryService: {
        reachable: prHealth.ok,
        version: h?.version ?? null,
        uptimeSec: h?.uptimeSec ?? null,
        capabilities: h?.capabilities?.length ?? null,
        ouiPrefixes: h?.oui?.total ?? null,
      },
      realtimeService: {
        mode: replay.enabled ? 'replay' : 'static',
        lastTickAt: replay.lastTickAt,
        intervalSec: replay.intervalSec,
      },
      monitoringEngine: {
        running: engine?.running ?? false,
        busy: engine?.busy ?? false,
        startedVia: engine?.startedVia ?? null,
        autoResume: runtimeRow?.enabled ?? false,
        intervalSec: engine?.intervalSec ?? runtimeRow?.intervalSec ?? null,
        radioEvery: engine?.radioEvery ?? runtimeRow?.radioEveryNCycles ?? null,
        cycles: engine?.cycles ?? 0,
        lastCycleAt: engine?.lastCycleAt ?? null,
        lastCycleDurationMs: engine?.lastCycleDurationMs ?? null,
        metricsWritten: engine?.metricsWritten ?? 0,
        eventsOpened: engine?.eventsOpened ?? 0,
        eventsClosed: engine?.eventsClosed ?? 0,
        notificationsSent: engine?.notificationsSent ?? 0,
        notificationsSkipped: (engine?.notificationsSkipped ?? 0) + (engine?.notificationsFailed ?? 0),
        errors: engine?.errors ?? [],
      },
      dbReachable: true,
      apiReachable: true,
    },
    honestNotes,
  }

  devValidate(SetupSummaryResultSchema, { ok: true, asOf: Date.now(), mode: apiMode(replay), data })
  return ok(data, Date.now(), apiMode(replay))
}
