/* ================================================================
 * /api/v2/setup/adopt — POST (v16.19 W21 — fase 4 del wizard setup)
 * ================================================================
 * Domanda a cui risponde: «scriviamo nel DB gli apparati visti e
 * confrontiamo la rete ipotetica (Excel) con quella reale (sonde)?»
 *
 * COSA FA:
 *   · riprende l'ultimo job di scansione COMPLETATO del plant (o quello
 *     esplicito) e per OGNI candidato vivo non in inventario crea il
 *     Device con l'EVIDENZA della scansione: hostname da sysName SNMP
 *     (o classificazione), MAC letto, brand/modello, community CIFRATA
 *     della community che ha risposto, snmpEnableState ENABLED quando
 *     SNMP ha parlato, monitorMode ping per i TLC, baselineUntil +24 h
 *     anti falsi allarmi, requiresConfirmation per impianti SENSIBILI;
 *   · SKIP onesto per IP già in inventario (pattern LibreNMS: «addresses
 *     that already belong to a device are skipped») e per gli IP
 *     esclusi dall'operatore (es. host d'infrastruttura);
 *   · la SEDE resta una decisione umana: i nuovi arrivano come orfani
 *     nella coda adozione (regola v15 §13.8: mai auto-adozione);
 *   · ricalcola il confronto inventario vs rete DOPO l'adozione.
 *
 * Audit SETUP_ADOPT con l'elenco sintetico di ciò che è stato scritto.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { encryptSecret } from '@/lib/crypto'
import { hasRole } from '@/lib/auth'
import { SetupAdoptInputSchema, SetupAdoptResultSchema } from '@/lib/v2/contracts'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

interface CompactCandidate {
  ip: string
  alive: boolean
  latencyMs: number | null
  openPorts: number[]
  snmp: { reachable: boolean; community: string | null; sysName: string | null; sysDescr: string | null; mac: string | null; vendor: string | null; model: string | null }
  http: { server: string | null; title: string | null } | null
  classification: { type: string; brand: string | null; model: string | null; confidence: string }
  inInventory: boolean
}

/** Suggerimento tipo/monitorMode — stessa regola della fase scansione. */
function suggest(c: CompactCandidate): { type: string; monitorMode: 'full' | 'ping' } {
  const t = c.classification.type
  if (t === 'CAMERA' || t === 'LPR' || t === 'ONT') return { type: t, monitorMode: 'ping' }
  if (t === 'UNKNOWN' && c.http?.server && /ont|modem|alcatel|home ?box|hg8|fibra/i.test(c.http.server)) return { type: 'ONT', monitorMode: 'ping' }
  return { type: t === 'UNKNOWN' ? 'SERVER' : t, monitorMode: 'full' }
}

/** hostname onesto: sysName SNMP → brand+ultimo ottetto → host-IP. */
function pickHostname(c: CompactCandidate, type: string): string {
  if (c.snmp.sysName && c.snmp.sysName.trim() !== '') return c.snmp.sysName.trim().slice(0, 120)
  const brand = (c.classification.brand ?? c.snmp.vendor ?? '').replace(/[^A-Za-z0-9-]+/g, '') || type.toLowerCase()
  const tail = c.ip.split('.').slice(-2).join('-')
  return `${brand}-${tail}`.slice(0, 120)
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono adottare apparati', 403)
  }

  let raw: unknown = {}
  try {
    const text = await req.text()
    if (text.trim() !== '') raw = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = SetupAdoptInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri di adozione non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Il client API invia l'impianto come ?plantId= (convenzione v2Url). */
  const url = new URL(req.url)
  const plantIdHint = input.plantId ?? url.searchParams.get('plantId') ?? undefined
  const plant = await resolvePlant(plantIdHint)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- job di scansione: esplicito o l'ultimo COMPLETED del plant --- */
  const job = input.jobId
    ? await db.discoveryJob.findFirst({ where: { id: input.jobId, plantId: p.id } })
    : await db.discoveryJob.findFirst({ where: { plantId: p.id, status: 'COMPLETED' }, orderBy: { startedAt: 'desc' } })
  if (!job) {
    return fail('NO_SCAN', 'Nessuna scansione completata per questo impianto: eseguire prima la fase di scansione', 422)
  }

  let config: { cidr?: string; snmpPort?: number; httpPort?: number | null; results?: CompactCandidate[] } = {}
  try {
    config = JSON.parse(job.config ?? '{}')
  } catch {
    config = {}
  }
  const candidates = (config.results ?? []).filter((c) => c && c.alive)
  if (candidates.length === 0) {
    return fail('EMPTY_SCAN', 'Il job di scansione non contiene host vivi: nulla da adottare', 422)
  }

  /* --- inventario attuale (guardia skip per IP) --- */
  const inventory = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: { id: true, hostname: true, ip: true },
  })
  const byIp = new Set(inventory.map((d) => d.ip))

  const overrides = new Map(input.overrides?.map((o) => [o.ip, o]) ?? [])
  const skipIps = new Set(input.skipIps ?? [])

  const created: Array<{ deviceId: string; hostname: string; ip: string; type: string; monitorMode: string; macAddress: string; brand: string; snmpEnabled: boolean; baselineUntil: number | null }> = []
  const skipped: Array<{ ip: string; reason: string }> = []
  const baseline = new Date(Date.now() + 24 * 3600 * 1000)

  for (const c of candidates) {
    if (byIp.has(c.ip)) {
      skipped.push({ ip: c.ip, reason: 'già in inventario (skip onesto, pattern LibreNMS)' })
      continue
    }
    if (skipIps.has(c.ip)) {
      skipped.push({ ip: c.ip, reason: 'escluso dall\'operatore in questa esecuzione' })
      continue
    }

    const sug = suggest(c)
    const ov = overrides.get(c.ip)
    const type = ov?.type ?? sug.type
    const monitorMode = ov?.monitorMode ?? sug.monitorMode
    const hostname = pickHostname(c, type)
    const brand = (c.classification.brand ?? c.snmp.vendor ?? '').slice(0, 80)
    const model = (c.classification.model ?? c.snmp.model ?? '').slice(0, 120)
    const mac = (c.snmp.mac ?? '').slice(0, 17)

    /* Community che ha risposto: cifrata subito (nessun segreto in chiaro). */
    const communityEnc = c.snmp.reachable && c.snmp.community ? (encryptSecret(c.snmp.community) ?? '') : ''
    const snmpEnabled = c.snmp.reachable && c.snmp.community != null

    try {
      const device = await db.device.create({
        data: {
          plantId: p.id,
          ip: c.ip,
          hostname,
          type,
          status: 'ONLINE',
          falcoState: 'online',
          monitorMode,
          macAddress: mac,
          brand,
          model,
          ...(model ? { firmwareVersion: '' } : {}),
          snmpPort: config.snmpPort ?? 161,
          snmpCommunityEnc: communityEnc,
          ...(snmpEnabled ? { snmpEnableState: 'ENABLED', snmpEnableAt: new Date(), snmpEnableMethod: 'setup-wizard', snmpEnableNote: `Setup W21: SNMP risposto durante la scansione (${job.subnet})` } : {}),
          credentialState: snmpEnabled ? 'OK' : mac ? 'UNKNOWN' : 'MISSING',
          credentialStateAt: new Date(),
          credentialReason: snmpEnabled
            ? `Setup W21: community "${c.snmp.community}" accettata durante la scansione`
            : 'Setup W21: nessuna risposta SNMP in scansione',
          sshPort: 22,
          port: c.http ? (config.httpPort ?? 80) : 80,
          lastSeenAt: job.finishedAt ?? new Date(),
          requiresConfirmation: p.criticalityLevel === 'SENSIBILE',
          baselineUntil: baseline,
          notes: `Adottato dal wizard setup (job ${job.id.slice(0, 8)}): ${c.classification.confidence} confidenza${c.http?.server ? ` · banner «${c.http.server}»` : ''}${input.note ? ` · ${input.note}` : ''}`.slice(0, 500),
        },
        select: { id: true },
      })
      created.push({
        deviceId: device.id,
        hostname,
        ip: c.ip,
        type,
        monitorMode,
        macAddress: mac,
        brand,
        snmpEnabled,
        baselineUntil: baseline.getTime(),
      })
      byIp.add(c.ip)
    } catch (e) {
      skipped.push({ ip: c.ip, reason: `creazione non riuscita: ${e instanceof Error ? e.message.slice(0, 120) : 'errore DB'}` })
    }
  }

  /* --- confronto DOPO l'adozione (la rete ipotetica incontra il DB) --- */
  const seenIps = new Set(candidates.map((c) => c.ip))
  const inventoryAfter = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: { ip: true },
  })
  const confirmed = inventoryAfter.filter((d) => seenIps.has(d.ip)).length
  const missingIps = [...new Set(inventoryAfter.filter((d) => !seenIps.has(d.ip)).map((d) => d.ip))].slice(0, 50)
  const orphansAfter = await db.device.count({ where: { plantId: p.id, locationId: null, decommissionedAt: null } })

  await db.auditLog.create({
    data: {
      action: 'SETUP_ADOPT',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: p.id,
      targetLabel: `wizard setup · adozione ${created.length} apparati`,
      plantId: p.id,
      details: JSON.stringify({
        jobId: job.id,
        created: created.map((d) => ({ hostname: d.hostname, ip: d.ip, type: d.type, monitorMode: d.monitorMode, snmpEnabled: d.snmpEnabled })),
        skippedCount: skipped.length,
        orphansAfter,
        note: input.note ?? null,
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const warnings: string[] = []
  if (created.length > 0) {
    warnings.push(`${created.length} nuovi apparati scritti nel DB come ORFANI: la sede si assegna dalla coda adozione (decisione umana, mai automatica)`)
  }
  if (missingIps.length > 0) {
    warnings.push(`${missingIps.length} IP dichiarati in inventario non visti in rete: restano a libro, nessuna cancellazione automatica`)
  }

  const data = {
    created,
    skipped,
    orphansAfter,
    comparison: {
      confirmed,
      missing: missingIps.length,
      newSeen: candidates.filter((c) => !c.inInventory).length,
      adoptedNow: created.length,
      missingIps,
    },
    warnings,
  }
  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SetupAdoptResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
