/* ================================================================
 * /api/v2/setup/verify — POST (v16.19 W21 — fase 3 del wizard setup)
 * ================================================================
 * Domanda a cui risponde: «le credenziali di OGNI apparato sono
 * giuste?» — e per i TLC (monitorMode='ping') la domanda diventa:
 * «è presente?». Decisione operatore W21: «se sono TLC evitiamo, va
 * bene solo ping».
 *
 * COSA FA (tutto con sonde REALI, esiti onesti per apparato):
 *   · monitorMode='full' → sonda SNMP multi-community (community
 *     CIFRATA del device → CSV dell'impianto → 'public') sulla porta
 *     dichiarata; una risposta È la verifica: community accettata →
 *     credentialState OK + community salvata cifrata (se nuova) +
 *     snmpEnableState → ENABLED + MAC letto (ifPhysAddress) salvato
 *     se l'inventario non lo conosceva;
 *   · credenziali SSH presenti (utente+password cifrate) → sonda
 *     LOGIN SSH (nuova /probe/ssh del mini-service: nessun comando,
 *     solo autenticazione): 'ready' = credenziali giuste,
 *     AUTH_FAILED = rifiutate;
 *   · monitorMode='ping' → spazzata di presenza (ping TCP-adattivo
 *     sulla porta di gestione): vivo = «verificato», muto = UNKNOWN
 *     (un muto NON è «credenziali sbagliate»: è onestà).
 *
 * Stato combinato per apparato (campo v15 finalmente vivo in v16):
 *   OK      SNMP o SSH verificati
 *   WRONG   qualcosa ha RIFIUTATO (SSH AUTH_FAILED)
 *   MISSING nessuna credenziale dichiarata da verificare
 *   UNKNOWN muto/timeout — non si può dire (mai «wrong» dal buio)
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { decryptSecret, encryptSecret } from '@/lib/crypto'
import { hasRole } from '@/lib/auth'
import { SetupVerifyInputSchema, SetupVerifyResultSchema, type SetupVerifyDeviceRow } from '@/lib/v2/contracts'
import { discoveryPost } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const SNMP_TIMEOUT_MS = 2500
const SSH_TIMEOUT_MS = 6000
/** Concorrenza delle sonde SNMP per apparato (pool piccolo e onesto). */
const CONCURRENCY = 4

interface VerifyDevice {
  id: string
  hostname: string
  ip: string
  type: string
  monitorMode: string
  username: string
  password: string
  snmpCommunityEnc: string
  snmpPort: number
  snmpVersion: string
  sshPort: number
  macAddress: string
  brand: string
  model: string
  snmpEnableState: string
  port: number
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono verificare le credenziali', 403)
  }

  let raw: unknown = {}
  try {
    const text = await req.text()
    if (text.trim() !== '') raw = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = SetupVerifyInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri di verifica non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Il client API invia l'impianto come ?plantId= (convenzione v2Url). */
  const url = new URL(req.url)
  const plantIdHint = input.plantId ?? url.searchParams.get('plantId') ?? undefined
  const plant = await resolvePlant(plantIdHint)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const t0 = Date.now()
  const warnings: string[] = []

  const devices = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: {
      id: true, hostname: true, ip: true, type: true, monitorMode: true,
      username: true, password: true, snmpCommunityEnc: true, snmpPort: true,
      snmpVersion: true, sshPort: true, macAddress: true, snmpEnableState: true, port: true,
      brand: true, model: true,
    },
    orderBy: { hostname: 'asc' },
  }) as unknown as VerifyDevice[]

  if (devices.length === 0) {
    const data = {
      devices: [],
      summary: { total: 0, snmpOk: 0, snmpMute: 0, sshOk: 0, sshFailed: 0, pingAlive: 0, pingMute: 0, credentialsOk: 0, credentialsWrong: 0, credentialsMissing: 0, credentialsUnknown: 0 },
      durationMs: Date.now() - t0,
      warnings: ['nessun apparato in inventario: importare l\'Excel o adottare i candidati prima di verificare'],
    }
    const replay = await getReplayState()
    devValidate(SetupVerifyResultSchema, { ok: true, asOf: Date.now(), mode: apiMode(replay), data })
    return ok(data, Date.now(), apiMode(replay))
  }

  /* Community condivise dell'impianto (CSV su Plant.snmpCommunities). */
  const plantCommunities = (p.snmpCommunities ?? '').split(',').map((s) => s.trim()).filter((s) => s !== '')

  /* ---------------- (A) apparati ping-only: UNA spazzata di presenza ----------------
   * La porta di gestione: quella dell'apparato, con l'eventuale porta
   * dichiarata nel wizard come alternativa quando quella di inventario
   * è il default 80 (TLC con pannello su porta non standard). */
  const pingDevices = devices.filter((d) => d.monitorMode === 'ping').slice(0, 64)
  const pingByIp = new Map<string, { alive: boolean; latencyMs: number }>()
  if (pingDevices.length > 0) {
    const pr = await discoveryPost('/probe/ping', {
      targets: pingDevices.map((d) => ({ ip: d.ip, port: (d.port && d.port !== 80) ? d.port : (input.httpPort ?? d.port ?? 80) })),
      timeoutMs: 1500,
    }, { timeoutMs: 25_000 })
    if (!pr.ok) {
      warnings.push('spazzata ping non riuscita — stato TLC non verificato in questo giro')
    } else {
      const res = (pr.body as { result?: { results?: Array<{ ip: string; alive: boolean; latencyMs: number }> } }).result
      for (const r of res?.results ?? []) pingByIp.set(r.ip, { alive: r.alive, latencyMs: r.latencyMs })
    }
  }

  /* ---------------- (B) apparati gestiti: SNMP + SSH per apparato ---------------- */
  const fullDevices = devices.filter((d) => d.monitorMode !== 'ping')

  const snmpProbe = async (d: VerifyDevice): Promise<{
    row: SetupVerifyDeviceRow
    deviceUpdate: Record<string, unknown>
    communityMatched: string | null
    macRead: string | null
  }> => {
    const communities: string[] = []
    const push = (c: string | undefined | null) => {
      const t = (c ?? '').trim()
      if (t !== '' && !communities.includes(t)) communities.push(t)
    }
    push(decryptSecret(d.snmpCommunityEnc))
    for (const c of plantCommunities) push(c)
    push('public')

    const version = d.snmpVersion === 'v1' || d.snmpVersion === 'v3' ? d.snmpVersion : 'v2c'
    /* Precedenza onesta: la porta dichiarata NEL WIZARD (fase scansione)
     * vince su quella di default dell'inventario (161) — è l'operatore
     * che ha appena visto la rete rispondere su quella porta. */
    const port = input.snmpPort ?? (d.snmpPort || 161)

    const pr = await discoveryPost('/probe/snmp', {
      ip: d.ip,
      port,
      version,
      communities,
      timeoutMs: SNMP_TIMEOUT_MS,
      includeMac: true,
    }, { timeoutMs: 12_000 })

    const deviceUpdate: Record<string, unknown> = {}
    let snmpReachable = false
    let matchedCommunity: string | null = null
    let sysName: string | null = null
    let snmpError: string | null = null
    let macRead: string | null = null
    let communitySaved = false
    let vendorRead: string | null = null
    let modelRead: string | null = null

    if (pr.ok) {
      const r = (pr.body as { result?: Record<string, unknown> }).result
      if (r) {
        snmpReachable = r.reachable === true
        matchedCommunity = ((r.matched as { community?: string } | null)?.community) ?? null
        sysName = (r.sysName as string | null) ?? null
        macRead = (r.mac as string | null) ?? null
        snmpError = snmpReachable ? null : ((r.error as string | null) ?? 'timeout')
        vendorRead = ((r.vendorGuess as { vendor?: string } | null)?.vendor) ?? null
        modelRead = ((r.product as { model?: string } | null)?.model) ?? null
      } else {
        snmpError = 'risposta servizio senza payload'
      }
    } else {
      snmpError = (pr.body as { error?: { code?: string } })?.error?.code ?? 'servizio discovery non raggiungibile'
      warnings.push(`${d.hostname}: sonda SNMP non eseguita (${snmpError})`)
    }

    if (snmpReachable) {
      /* Una risposta È una verifica (regola W19/W20). */
      deviceUpdate.snmpEnableState = 'ENABLED'
      deviceUpdate.snmpEnableAt = new Date()
      deviceUpdate.snmpEnableNote = `Setup W21: community "${matchedCommunity ?? '—'}" accettata${sysName ? ` (sysName "${sysName}")` : ''}`.slice(0, 500)
      deviceUpdate.lastSeenAt = new Date()
      /* La porta che ha risposto diventa la porta dell'apparato: le
       * sonde successive (radio/L2) la useranno. */
      if (port !== d.snmpPort) deviceUpdate.snmpPort = port
      const stored = decryptSecret(d.snmpCommunityEnc)
      if (matchedCommunity && matchedCommunity !== stored) {
        const enc = encryptSecret(matchedCommunity)
        if (enc) {
          deviceUpdate.snmpCommunityEnc = enc
          communitySaved = true
        }
      }
      if (macRead && (!d.macAddress || d.macAddress === '')) {
        deviceUpdate.macAddress = macRead
      }
      /* Identità prodotto dichiarata via SNMP (sysDescr/OID enterprise):
       * il vendor «letto» riempie l'inventario quando manca. */
      if (vendorRead && (!d.brand || d.brand === '')) deviceUpdate.brand = vendorRead.slice(0, 80)
      if (modelRead && (!d.model || d.model === '')) deviceUpdate.model = modelRead.slice(0, 120)
    }

    return {
      row: {
        deviceId: d.id,
        hostname: d.hostname,
        ip: d.ip,
        type: d.type,
        monitorMode: 'full',
        snmp: { tried: true, reachable: snmpReachable, matchedCommunity, sysName, error: snmpError },
        ssh: { tried: false, authenticated: null, error: null },
        ping: { tried: false, alive: null, latencyMs: null },
        credentialState: '',
        credentialReason: '',
        macRead,
        communitySaved,
      },
      deviceUpdate,
      communityMatched: matchedCommunity,
      macRead,
    }
  }

  const sshProbe = async (d: VerifyDevice): Promise<{ authenticated: boolean | null; error: string | null; port: number }> => {
    const username = (d.username ?? '').trim()
    const password = decryptSecret(d.password)
    if (username === '' || !password) {
      return { authenticated: null, error: null, port: d.sshPort || 22 }
    }
    /* Come per SNMP: la porta dichiarata nel wizard vince sul default. */
    const port = input.sshPort ?? (d.sshPort || 22)
    const pr = await discoveryPost('/probe/ssh', {
      ip: d.ip,
      port,
      username,
      password,
      timeoutMs: SSH_TIMEOUT_MS,
    }, { timeoutMs: 25_000 })
    if (!pr.ok) {
      return { authenticated: null, error: (pr.body as { error?: { code?: string } })?.error?.code ?? 'servizio non raggiungibile', port }
    }
    const r = (pr.body as { result?: { authenticated?: boolean; error?: string | null; detail?: string | null } }).result
    if (!r) return { authenticated: null, error: 'payload ssh inatteso', port }
    return { authenticated: r.authenticated === true, error: r.authenticated === true ? null : (r.error ?? r.detail ?? 'rifiutato'), port }
  }

  /* Pool a concorrenza limitata (le sonde restano corte e oneste). */
  const probeResults: Array<{ d: VerifyDevice; snmp: Awaited<ReturnType<typeof snmpProbe>>; ssh: Awaited<ReturnType<typeof sshProbe>> }> = []
  for (let i = 0; i < fullDevices.length; i += CONCURRENCY) {
    const batch = fullDevices.slice(i, i + CONCURRENCY)
    const settled = await Promise.all(
      batch.map(async (d) => {
        const snmp = await snmpProbe(d)
        const ssh = await sshProbe(d)
        return { d, snmp, ssh }
      }),
    )
    probeResults.push(...settled)
  }

  /* ---------------- Stato combinato + persistenza ---------------- */
  const rows: SetupVerifyDeviceRow[] = []
  const summary = { total: devices.length, snmpOk: 0, snmpMute: 0, sshOk: 0, sshFailed: 0, pingAlive: 0, pingMute: 0, credentialsOk: 0, credentialsWrong: 0, credentialsMissing: 0, credentialsUnknown: 0 }

  for (const d of pingDevices) {
    const hit = pingByIp.get(d.ip) ?? { alive: false, latencyMs: 0 }
    if (hit.alive) summary.pingAlive++
    else summary.pingMute++
    const state = hit.alive ? 'OK' : 'UNKNOWN'
    const usedPort = (d.port && d.port !== 80) ? d.port : (input.httpPort ?? d.port ?? 80)
    const reason = hit.alive
      ? `TLC/ping-only: presenza verificata (TCP-adattivo su porta ${usedPort}, ${hit.latencyMs} ms)`
      : `TLC/ping-only: nessuna risposta al ping (porta ${usedPort}) — verificare raggiungibilità (non è un problema di credenziali)`
    rows.push({
      deviceId: d.id,
      hostname: d.hostname,
      ip: d.ip,
      type: d.type,
      monitorMode: 'ping',
      snmp: { tried: false, reachable: false, matchedCommunity: null, sysName: null, error: null },
      ssh: { tried: false, authenticated: null, error: null },
      ping: { tried: true, alive: hit.alive, latencyMs: hit.alive ? hit.latencyMs : null },
      credentialState: state,
      credentialReason: reason,
      macRead: null,
      communitySaved: false,
    })
    await db.device.update({
      where: { id: d.id },
      data: {
        credentialState: state,
        credentialStateAt: new Date(),
        credentialReason: reason.slice(0, 500),
        ...(hit.alive ? { status: 'ONLINE', falcoState: 'online', lastSeenAt: new Date(), ...(usedPort !== d.port ? { port: usedPort } : {}) } : {}),
      },
    }).catch(() => { /* difensivo */ })
    if (state === 'OK') summary.credentialsOk++
    else summary.credentialsUnknown++
  }

  for (const pr of probeResults) {
    const { d, snmp, ssh } = pr
    const row = snmp.row
    row.ssh = { tried: ssh.authenticated !== null, authenticated: ssh.authenticated, error: ssh.error }

    if (snmp.communityMatched) summary.snmpOk++
    else if (row.snmp.error) summary.snmpMute++
    if (ssh.authenticated === true) summary.sshOk++
    if (ssh.authenticated === false) summary.sshFailed++

    const hasCreds = snmp.communityMatched != null || ssh.authenticated !== null
    let state: string
    let reason: string
    if (snmp.communityMatched) {
      state = 'OK'
      reason = `SNMP OK: community "${snmp.communityMatched}" accettata${row.snmp.sysName ? ` — sysName "${row.snmp.sysName}"` : ''}`
    } else if (ssh.authenticated === true) {
      state = 'OK'
      reason = `SSH OK: login "${(d.username ?? '').trim()}" accettato (porta ${ssh.port})${row.snmp.error ? ` — SNMP muto (${row.snmp.error})` : ''}`
    } else if (ssh.authenticated === false && ssh.error != null && /AUTH_FAILED|password|auth/i.test(String(ssh.error))) {
      /* SOLO un rifiuto esplicito è «credenziali sbagliate»: un host
       * irraggiungibile (CONNECT_FAILED/timeout) NON condanna le
       * credenziali — resta UNKNOWN (onestà v15: mai «wrong» dal buio). */
      state = 'WRONG'
      reason = `SSH RIFIUTATO: ${ssh.error ?? 'credenziali rifiutate'}${row.snmp.error ? ` · SNMP muto (${row.snmp.error})` : ''}`
    } else if (!hasCreds && (d.username ?? '').trim() === '' && !decryptSecret(d.snmpCommunityEnc) && plantCommunities.length === 0) {
      state = 'MISSING'
      reason = 'nessuna credenziale dichiarata (né SNMP né SSH) e nessuna community condivisa'
    } else if (row.snmp.error === 'timeout' || row.snmp.error == null) {
      state = 'UNKNOWN'
      reason = `SNMP muto (${row.snmp.error ?? 'nessuna risposta'}): un timeout NON è «credenziali sbagliate» — verificare agente/ACL`
    } else {
      state = 'UNKNOWN'
      reason = `SNMP: ${row.snmp.error} — non verificabile in questo giro`
    }

    row.credentialState = state
    row.credentialReason = reason

    const update = {
      ...snmp.deviceUpdate,
      credentialState: state,
      credentialStateAt: new Date(),
      credentialReason: reason.slice(0, 500),
      /* La porta SSH che ha accettato il login diventa la porta
       * dell'apparato (le attivazioni W19 la useranno). */
      ...(ssh.authenticated === true && ssh.port !== d.sshPort ? { sshPort: ssh.port } : {}),
    }
    await db.device.update({ where: { id: d.id }, data: update }).catch(() => {
      warnings.push(`${d.hostname}: persistenza dello stato credenziali non riuscita (DB)`)
    })

    if (state === 'OK') summary.credentialsOk++
    else if (state === 'WRONG') summary.credentialsWrong++
    else if (state === 'MISSING') summary.credentialsMissing++
    else summary.credentialsUnknown++
    rows.push(row)
  }

  /* Riordino per hostname (coerenza UI). */
  rows.sort((a, b) => a.hostname.localeCompare(b.hostname))

  await db.auditLog.create({
    data: {
      action: 'SETUP_VERIFY',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: p.id,
      targetLabel: `wizard setup · verifica credenziali ${devices.length} apparati`,
      plantId: p.id,
      details: JSON.stringify({
        total: summary.total,
        snmpOk: summary.snmpOk,
        snmpMute: summary.snmpMute,
        sshOk: summary.sshOk,
        sshFailed: summary.sshFailed,
        pingAlive: summary.pingAlive,
        pingMute: summary.pingMute,
        credentialsOk: summary.credentialsOk,
        credentialsWrong: summary.credentialsWrong,
        credentialsMissing: summary.credentialsMissing,
        credentialsUnknown: summary.credentialsUnknown,
        durationMs: Date.now() - t0,
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const data = {
    devices: rows,
    summary,
    durationMs: Date.now() - t0,
    warnings,
  }
  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SetupVerifyResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
