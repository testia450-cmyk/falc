/* ================================================================
 * /api/v2/setup/alarms — POST (v16.19 W21 — fase 6 del wizard setup)
 * ================================================================
 * Domanda a cui risponde: «quali allarmi abbino a questi dispositivi,
 * e adesso cosa è GIÀ vero?»
 *
 * COSA FA (due metà, entrambe reali):
 *   (1) REGOLE: assicura sul plant le 6 regole richieste dall'operatore
 *       (segnale scarso, porta cambia stato, dispositivo offline, rete
 *       che cambia alberatura, nuovi dispositivi non adottati, nuovi
 *       apparati visti) — upsert idempotente per (plantId, systemKey);
 *       la soglia del segnale è tarabile;
 *   (2) VALUTAZIONE ONE-SHOT sui dati appena raccolti: per ogni
 *       dispositivo controlla SEGNALE (Device.signalStrength reale),
 *       OFFLINE (status reale dopo la spazzata ping), ORFANI (visti e
 *       non adottati), TOPOLOGIA (link costruiti nelle ultime 2 h da
 *       FDB/LLDP/STP). Ogni superamento → AlertEvent APERTO nel DB
 *       (con dedup: stessa regola+dispositivo+finestra → conta, non
 *       duplica).
 *
 * ONESTÀ (dichiarata nella risposta):
 *   · la valutazione CONTINUA (ogni ciclo di polling) è del motore di
 *     produzione; in questa build valuta il wizard alla chiusura e le
 *     sonde on-demand — non c'è uno scheduler in v16;
 *   · SYS:PORT_STATE_CHANGE registra la baseline delle porte STP: le
 *     variazioni si vedranno ai sondaggi SUCCESSIVI (nessuna storia
 *     falsificata al primo giro);
 *   · nessuna notifica EMAIL/TELEGRAM parte da qui: il dispatcher non
 *     è attivo in v16 — gli eventi vivono nel DB e nella vista Allarmi.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { SetupAlarmsInputSchema, SetupAlarmsResultSchema } from '@/lib/v2/contracts'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

interface EventRow {
  eventId: string
  systemKey: string
  severity: string
  deviceId: string | null
  deviceHostname: string | null
  message: string
  deduplicated: boolean
}

/** Apertura evento CON dedup: stessa regola+dispositivo già OPEN →
 *  incrementa occurrenceCount invece di duplicare (regola v15.11 R7). */
async function raiseEvent(input: {
  ruleId: string
  plantId: string
  deviceId: string | null
  severity: string
  currentValue: string
  message: string
  dedupTag: string
}): Promise<EventRow | null> {
  const existing = await db.alertEvent.findFirst({
    where: { ruleId: input.ruleId, status: 'OPEN', dedupTag: input.dedupTag },
    select: { id: true, occurrenceCount: true },
  })
  if (existing) {
    await db.alertEvent.update({
      where: { id: existing.id },
      data: { occurrenceCount: { increment: 1 }, currentValue: input.currentValue, message: input.message, updatedAt: new Date() },
    })
    return { eventId: existing.id, systemKey: '', severity: input.severity, deviceId: input.deviceId, deviceHostname: null, message: input.message, deduplicated: true }
  }
  const ev = await db.alertEvent.create({
    data: {
      ruleId: input.ruleId,
      plantId: input.plantId,
      deviceId: input.deviceId,
      severity: input.severity,
      status: 'OPEN',
      currentValue: input.currentValue,
      message: input.message,
      dedupTag: input.dedupTag,
    },
    select: { id: true },
  })
  return { eventId: ev.id, systemKey: '', severity: input.severity, deviceId: input.deviceId, deviceHostname: null, message: input.message, deduplicated: false }
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono attivare le regole di allarme', 403)
  }

  let raw: unknown = {}
  try {
    const text = await req.text()
    if (text.trim() !== '') raw = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = SetupAlarmsInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri allarmi non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Il client API invia l'impianto come ?plantId= (convenzione v2Url). */
  const url = new URL(req.url)
  const plantIdHint = input.plantId ?? url.searchParams.get('plantId') ?? undefined
  const plant = await resolvePlant(plantIdHint)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const signalThreshold = input.signalThresholdDbm ?? -75

  /* --- dati REALI del plant per soglie e valutazione --- */
  const [devices, linksCount, stpPorts, linksFresh] = await Promise.all([
    db.device.findMany({
      where: { plantId: p.id, decommissionedAt: null },
      select: { id: true, hostname: true, type: true, signalStrength: true, status: true, locationId: true, lastSeenAt: true },
      orderBy: { hostname: 'asc' },
    }),
    db.topologyLink.count({ where: { plantId: p.id } }),
    db.stpObservation.count({ where: { plantId: p.id } }),
    db.topologyLink.count({ where: { plantId: p.id, updatedAt: { gte: new Date(Date.now() - 2 * 3600 * 1000) } } }),
  ])

  /* ---------------- (1) REGOLE: upsert idempotente per systemKey ---------------- */
  const RULE_DEFS: Array<{ systemKey: string; name: string; description: string; metric: string; comparison: string; threshold: number; deviceTypes: string[]; severity: string }> = [
    { systemKey: 'SYS:LOW_SIGNAL', name: 'Segnale radio scarso', description: 'Segnale dBm sotto soglia sulle antenne (AP/STA)', metric: 'signalStrength', comparison: 'lt', threshold: signalThreshold, deviceTypes: ['AP', 'STA'], severity: 'AVERAGE' },
    { systemKey: 'SYS:DEVICE_DOWN', name: 'Dispositivo offline', description: 'Apparato che non risponde più (stato OFFLINE)', metric: 'reachable', comparison: 'eq', threshold: 0, deviceTypes: [], severity: 'CRITICAL' },
    { systemKey: 'SYS:PORT_STATE_CHANGE', name: 'Porta che cambia stato', description: 'Porta switch che cambia stato operativo (up/down)', metric: 'portOperStatus', comparison: 'ne', threshold: 1, deviceTypes: [], severity: 'WARNING' },
    { systemKey: 'SYS:TOPOLOGY_CHANGE', name: 'Rete che cambia alberatura', description: 'Numero di link di topologia diverso dalla baseline', metric: 'topologyLinkCount', comparison: 'ne', threshold: linksCount, deviceTypes: [], severity: 'AVERAGE' },
    { systemKey: 'SYS:NEW_HOST', name: 'Nuovo dispositivo rilevato e non adottato', description: 'Apparato visto in rete senza sede assegnata', metric: 'inventoryOrphanCount', comparison: 'gt', threshold: 0, deviceTypes: [], severity: 'INFO' },
    { systemKey: 'SYS:NEW_DEVICE_SEEN', name: 'Nuovo apparato visto in scansione', description: 'Host vivo non presente in inventario alla scansione', metric: 'scanNewSeenCount', comparison: 'gt', threshold: 0, deviceTypes: [], severity: 'INFO' },
  ]

  const rules: Array<{ systemKey: string; name: string; enabled: boolean; metric: string; threshold: number | null; severity: string; justCreated: boolean; id: string }> = []
  for (const def of RULE_DEFS) {
    const existing = await db.alertRule.findUnique({ where: { plantId_systemKey: { plantId: p.id, systemKey: def.systemKey } }, select: { id: true, enabled: true } })
    const rule = await db.alertRule.upsert({
      where: { plantId_systemKey: { plantId: p.id, systemKey: def.systemKey } },
      create: {
        plantId: p.id,
        name: def.name,
        description: def.description,
        enabled: true,
        metric: def.metric,
        deviceTypes: JSON.stringify(def.deviceTypes),
        scopeType: 'ALL',
        comparison: def.comparison,
        threshold: def.threshold,
        severity: def.severity,
        cooldownMinutes: 30,
        systemKey: def.systemKey,
      },
      update: {
        enabled: true,
        /* La soglia del segnale si ritara se l'operatore l'ha chiesto;
         * le altre baseline si aggiornano al valore corrente. */
        ...(def.systemKey === 'SYS:LOW_SIGNAL' ? { threshold: signalThreshold } : {}),
        ...(def.systemKey === 'SYS:TOPOLOGY_CHANGE' ? { threshold: linksCount } : {}),
      },
      select: { id: true, systemKey: true, name: true, enabled: true, metric: true, threshold: true, severity: true },
    })
    rules.push({ ...rule, systemKey: rule.systemKey ?? def.systemKey, threshold: rule.threshold ?? null, justCreated: existing == null })
  }
  const ruleByKey = new Map(rules.map((r) => [r.systemKey, r]))

  /* ---------------- (2) VALUTAZIONE ONE-SHOT sui dati reali ---------------- */
  const events: EventRow[] = []

  const pushEvent = async (systemKey: string, deviceId: string | null, hostname: string | null, severity: string, currentValue: string, message: string) => {
    const rule = ruleByKey.get(systemKey)
    if (!rule) return
    const ev = await raiseEvent({
      ruleId: rule.id,
      plantId: p.id,
      deviceId,
      severity,
      currentValue,
      message,
      /* Tag UNIFICATO col motore continuo (W21-bis): chi valuta per
       * secondo DEDUPLICA, non duplica — stesso evento, un'unica riga. */
      dedupTag: `sys:${systemKey}:${deviceId ?? 'plant'}`,
    })
    if (ev) events.push({ ...ev, systemKey, deviceHostname: hostname })
  }

  /* (a) segnale scarso: SOLO antenne con un segnale DAVVERO letto (!= 0). */
  let signalLow = 0
  for (const d of devices) {
    if ((d.type === 'AP' || d.type === 'STA') && d.signalStrength !== 0 && d.signalStrength <= signalThreshold) {
      signalLow++
      await pushEvent('SYS:LOW_SIGNAL', d.id, d.hostname, 'AVERAGE', `${d.signalStrength} dBm`, `Segnale scarso: ${d.hostname} dichiara ${d.signalStrength} dBm (soglia ${signalThreshold} dBm) — verificare allineamento/LOS`)
    }
  }

  /* (b) offline: stato REALE dopo le sonde del setup. */
  let offline = 0
  for (const d of devices) {
    if (d.status === 'OFFLINE') {
      offline++
      await pushEvent('SYS:DEVICE_DOWN', d.id, d.hostname, 'CRITICAL', 'OFFLINE', `${d.hostname} (${d.type}) risulta OFFLINE dopo la verifica del setup — nessuna risposta su alcun percorso`)
    }
  }

  /* (c) orfani (visti e non adottati): sede mai assegnata, visti di recente. */
  let orphansNew = 0
  for (const d of devices) {
    if (d.locationId == null && d.lastSeenAt != null && Date.now() - d.lastSeenAt.getTime() < 24 * 3600 * 1000) {
      orphansNew++
      await pushEvent('SYS:NEW_HOST', d.id, d.hostname, 'INFO', 'senza sede', `Nuovo dispositivo rilevato e NON adottato: ${d.hostname} (${d.type}) visto alle ${d.lastSeenAt.toLocaleString('it-IT')} — assegnare la sede dalla coda adozione`)
    }
  }

  /* (d) topologia: link costruiti/aggiornati nelle ultime 2 h (finestra setup). */
  if (linksFresh > 0) {
    await pushEvent('SYS:TOPOLOGY_CHANGE', null, null, 'INFO', `${linksCount} link`, `Topologia costruita/aggiornata durante il setup: ${linksFresh} link scritti nelle ultime 2 h (totale ${linksCount}) da FDB/LLDP/STP — baseline registrata a ${linksCount}`)
  }

  const evaluated = {
    devicesChecked: devices.length,
    signalLow,
    offline,
    orphansNew,
    topologyLinksFresh: linksFresh,
    portStateBaseline: stpPorts,
  }

  const honestNotes = [
    'Valutazione eseguita ORA sui dati reali del plant (one-shot del wizard): la valutazione CONTINUA a ogni ciclo di polling è del motore di produzione — in questa build le sonde sono on-demand e il tick realtime è di riproduzione demo.',
    `SYS:PORT_STATE_CHANGE: baseline iniziale di ${stpPorts} porte STP registrata — le variazioni si valutano ai sondaggi successivi (nessuno storico falsificato al primo giro).`,
    'Nessuna notifica EMAIL/TELEGRAM/WEBHOOK è stata inviata da questa rotta: il dispatcher di notifiche non è attivo in questa build — gli eventi sono nel DB e nella vista Allarmi.',
  ]

  await db.auditLog.create({
    data: {
      action: 'SETUP_ALARMS',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: p.id,
      targetLabel: `wizard setup · allarmi ${rules.length} regole`,
      plantId: p.id,
      details: JSON.stringify({
        rulesEnsured: rules.length,
        rulesCreated: rules.filter((r) => r.justCreated).length,
        eventsOpened: events.filter((e) => !e.deduplicated).length,
        eventsDeduplicated: events.filter((e) => e.deduplicated).length,
        evaluated,
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const data = {
    rules: rules.map((r) => ({ systemKey: r.systemKey, name: r.name, enabled: r.enabled, metric: r.metric, threshold: r.threshold, severity: r.severity, justCreated: r.justCreated })),
    events,
    evaluated,
    honestNotes,
  }
  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SetupAlarmsResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
