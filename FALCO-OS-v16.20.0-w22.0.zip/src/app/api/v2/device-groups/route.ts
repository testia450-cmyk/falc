/* ================================================================
 * /api/v2/device-groups — GET (elenco) + POST (creazione, 16.3/16.4 W3)
 * Gruppi di dispositivi REALI del DB (modello DeviceGroup v10.28 F3).
 * I gruppi sono entità GESTITE DALL'OPERATORE (come i ticket): crearli
 * NON è inventare dati. DB reale al 17-b: 0 gruppi → items: []
 * total: 0 (onesto, non errore).
 *  · GET: gruppi del plant, name asc. MANUAL: membri dalla relazione
 *    (cap onesto DEVICE_GROUP_MEMBERS_CAP = 500, memberCount = totale
 *    reale). DYNAMIC (16.4): membership CALCOLATA a runtime dalla
 *    ruleJson sullo stato attuale dei dispositivi (computeDynamicGroup-
 *    Members) — non salvata, ricalcolata a ogni lettura. NESSUNA
 *    paginazione: i gruppi di un impianto sono poche decine;
 *  · POST (role ≥ TECNICO): crea un gruppo REALE — MANUAL (default,
 *    retrocompat 16.3: deviceIds opzionali validati nello scope del
 *    plant → 422 con offensori) o DYNAMIC (16.4: rules OBBLATORIE
 *    con valori validati contro i dati reali del plant → 422 con
 *    offensori per criterio; deviceIds VIETATI — refine del contratto).
 *    Validazioni: name univoco per plant (check in $transaction →
 *    422 GROUP_EXISTS); audit DEVICE_GROUP_CREATE in TRANSAZIONE con
 *    ruleType, regola e conteggio membri (calcolato per i DYNAMIC);
 *    201 con la riga creata (membership calcolata per i DYNAMIC).
 * Nessun campo credenziale coinvolto (allowlist DEVICE_GROUP_INCLUDE).
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import {
  DeviceGroupsQuerySchema, DeviceGroupsPageSchema, DeviceGroupRowSchema,
  CreateDeviceGroupInputSchema, type GroupRule, type DeviceGroupRow,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import {
  resolvePlant, devValidate, maxOf, parseGroupRule,
  computeDynamicGroupMembers, validateGroupRuleValues,
  toDeviceGroupRow, DEVICE_GROUP_INCLUDE, offendingDeviceIds,
} from '@/app/api/v2/shared'

/** Membership calcolata per OGNI gruppo DYNAMIC dell'elenco (una
 *  query per gruppo: pochi gruppi per impianto, dichiarato nel
 *  contratto). Restituisce la mappa groupId → {members, total}. */
async function dynamicMembersOf(
  plantId: string,
  groups: Array<{ id: string; ruleType: string; ruleJson: string }>,
): Promise<Map<string, { members: DeviceGroupRow['members']; total: number }>> {
  const map = new Map<string, { members: DeviceGroupRow['members']; total: number }>()
  for (const g of groups) {
    if (g.ruleType !== 'DYNAMIC') continue
    const rules = parseGroupRule(g.ruleJson)
    if (!rules) continue // ruleJson illeggibile (difensivo): la riga esce con rules null e membri vuoti
    map.set(g.id, await computeDynamicGroupMembers(plantId, rules))
  }
  return map
}

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(DeviceGroupsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const groups = await db.deviceGroup.findMany({
    where: { plantId: p.id },
    orderBy: { name: 'asc' },
    include: DEVICE_GROUP_INCLUDE,
  })

  /* 16.4: membership dei gruppi DYNAMIC calcolata sullo stato attuale */
  const dynamic = await dynamicMembersOf(p.id, groups)

  const data = {
    items: groups.map((g) => toDeviceGroupRow(g, dynamic.get(g.id))),
    total: groups.length,
  }

  const asOf = maxOf(...groups.map((g) => g.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(DeviceGroupsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, description?, color?, ruleType?, rules?, deviceIds? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name, description?, color?, ruleType?, rules?, deviceIds?)', 422)
  }
  const parsed = CreateDeviceGroupInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data
  const isDynamic = input.ruleType === 'DYNAMIC'

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- 16.4 DYNAMIC: valori della regola validati contro i dati REALI
   *      del plant (niente regole su valori fantasma) e conteggio
   *      membri calcolato per la risposta e per l'audit. --- */
  let dynamicRules: GroupRule | null = null
  let computed: { members: DeviceGroupRow['members']; total: number } | null = null
  if (isDynamic) {
    dynamicRules = input.rules ?? null
    if (!dynamicRules) {
      return fail('BAD_BODY', 'Gruppo DYNAMIC: la regola (rules) è obbligatoria e deviceIds è vietato (membership calcolata, non salvata)', 422)
    }
    const offenders = await validateGroupRuleValues(p.id, dynamicRules)
    const bad = Object.entries(offenders).filter(([, list]) => list.length > 0)
    if (bad.length > 0) {
      return fail('BAD_BODY', 'La regola contiene valori non presenti nell\'impianto (validati contro i dati reali)', 422, bad.map(([k, list]) => ({
        path: `rules.${k}`,
        message: `Valori non presenti nell'impianto (mostrati al massimo 5 su ${list.length}): ${(list as string[]).slice(0, 5).join(', ')}`,
        ...(k === 'unknownLocationIds' ? { unknownLocationIds: (list as string[]).slice(0, 5) } : {}),
      })))
    }
    computed = await computeDynamicGroupMembers(p.id, dynamicRules)
  }

  /* --- deviceIds (SOLO MANUAL): deduplicati, tutti reali e nello
   *      scope del plant --- */
  const deviceIds = !isDynamic && input.deviceIds ? Array.from(new Set(input.deviceIds)) : []
  if (deviceIds.length > 0) {
    const offending = await offendingDeviceIds(p.id, deviceIds)
    if (offending.length > 0) {
      return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
        { path: 'deviceIds', message: `Id non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
      ])
    }
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + membership + audit in transazione interattiva ---
   * L'univocità name-per-plant è verificata DENTRO la transazione
   * (check+create atomici: niente corsa fra due richieste). */
  const result = await db.$transaction(async (tx) => {
    const dup = await tx.deviceGroup.count({ where: { plantId: p.id, name: input.name } })
    if (dup > 0) return { kind: 'exists' as const }

    const g = await tx.deviceGroup.create({
      data: {
        plantId: p.id,
        name: input.name,
        description: input.description ?? '',
        color: input.color ?? '#3b82f6', // default del modello (nessun colore inventato)
        ruleType: isDynamic ? 'DYNAMIC' : 'MANUAL',
        ruleJson: isDynamic && dynamicRules ? JSON.stringify(dynamicRules) : '{}', // regola validata o default inerte del modello
      },
    })
    if (!isDynamic && deviceIds.length > 0) {
      await tx.deviceGroupMember.createMany({
        data: deviceIds.map((deviceId) => ({ groupId: g.id, deviceId })),
        // niente skipDuplicates: NON supportato su SQLite/Prisma; sicuro
        // senza perché il gruppo è appena creato e gli id sono deduplicati
      })
    }
    await tx.auditLog.create({
      data: {
        action: 'DEVICE_GROUP_CREATE',
        actor: email,
        targetId: g.id,
        targetLabel: g.name.slice(0, 80),
        plantId: g.plantId,
        details: JSON.stringify(
          isDynamic
            ? {
                groupId: g.id,
                name: g.name,
                ruleType: 'DYNAMIC',
                rules: dynamicRules,
                computedMembers: computed?.total ?? 0, // conteggio ALLA CREAZIONE: ricalcolato a ogni lettura
              }
            : {
                groupId: g.id,
                name: g.name,
                ruleType: 'MANUAL',
                members: deviceIds.length,
              },
        ),
      },
    })
    return { kind: 'created' as const, id: g.id }
  })

  if (result.kind === 'exists') {
    return fail('GROUP_EXISTS', `Esiste già un gruppo chiamato «${input.name}» in questo impianto: i nomi sono univoci per impianto`, 422)
  }

  /* --- Riga di risposta (relazioni incluse; per i DYNAMIC la
   *      membership è RICALCOLATA dopo la creazione) --- */
  const row = await db.deviceGroup.findUnique({
    where: { id: result.id },
    include: DEVICE_GROUP_INCLUDE,
  })
  if (!row) return fail('CREATE_FAILED', 'Gruppo creato ma non rileggibile', 500)

  let dyn: { members: DeviceGroupRow['members']; total: number } | null = null
  if (row.ruleType === 'DYNAMIC') {
    const rules = parseGroupRule(row.ruleJson)
    if (rules) dyn = await computeDynamicGroupMembers(row.plantId, rules)
  }

  const data = toDeviceGroupRow(row, dyn ?? undefined)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(DeviceGroupRowSchema, data) // risposta singola: valida la riga nella busta
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
