/* ================================================================
 * /api/v2/device-groups/{id} — PATCH (modifica) + DELETE (16.3/16.4 W3)
 * Operazioni su un gruppo di dispositivi REALE del DB:
 *  · PATCH (role ≥ TECNICO): campi opzionali con refine almeno-uno.
 *    Se name cambia → univocità per plant verificata DENTRO la
 *    transazione (escluso il gruppo stesso) → 422 GROUP_EXISTS.
 *    deviceIds presente = SOSTITUZIONE INTEGRALE della membership
 *    (deleteMany + createMany in $transaction: non un merge —
 *    semantica dichiarata, mai input ignorato in silenzio);
 *    deviceIds validati come nella POST (422 con offensori max 5);
 *    audit DEVICE_GROUP_UPDATE con diff sintetico
 *    { name?: from→to, description/color?: from→to, members?: {added, removed},
 *      rules?: from→to } (16.4);
 *    DYNAMIC (16.4): rules presente = SOSTITUZIONE INTEGRALE della
 *    regola (valori validati contro i dati reali del plant → 422 con
 *    offensori per criterio); deviceIds su un DYNAMIC → 422 RULE_TYPE
 *    (membership calcolata, non salvata); rules su un MANUAL → 422
 *    RULE_TYPE; ruleType nel corpo → 422 RULE_TYPE_IMMUTABLE (il tipo
 *    di membership non si converte dopo la creazione — check sul
 *    corpo GREZZO perché zod ignora le chiavi sconosciute).
 *  · DELETE (role ≥ TECNICO): PRIMA conta i membri (righe per i
 *    MANUAL, CALCOLATI dalla regola per i DYNAMIC) e le finestre che
 *    usano il gruppo come scope (MaintenanceWindowGroup, per onestà
 *    nella risposta), poi delete in $transaction con audit
 *    DEVICE_GROUP_DELETE {name, ruleType, members|computedMembers,
 *    removedScopes} (16.4). Le finestre
 *    NON vengono eliminate: perdono solo questo scope (cascade dello
 *    schema); i dispositivi restano ovviamente nell'inventario.
 * Entrambe rispondono 404 per id inesistenti.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import {
  DeviceGroupRowSchema, UpdateDeviceGroupInputSchema, DeviceGroupDeletedSchema,
  type GroupRule, type DeviceGroupRow,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import {
  devValidate, toDeviceGroupRow, DEVICE_GROUP_INCLUDE, offendingDeviceIds,
  parseGroupRule, computeDynamicGroupMembers, validateGroupRuleValues,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

function notFound() {
  return fail('NOT_FOUND', 'Gruppo di dispositivi non trovato', 404)
}

/** Normalizzazione per il confronto fra regole (stessi criteri →
 *  stessi valori nello stesso ordine): una patch che rispecifica la
 *  regola IDENTICA non è una modifica (422 NO_CHANGES, onestà). */
function normRule(r: GroupRule | null): Record<string, string[]> | null {
  if (!r) return null
  const out: Record<string, string[]> = {}
  for (const key of ['deviceTypes', 'statuses', 'connectionTypes', 'locationIds'] as const) {
    const list = r[key]
    if (list && list.length > 0) out[key] = [...list].sort()
  }
  return out
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo fra name, description, color, rules, deviceIds)', 422)
  }

  /* 16.4: ruleType è IMMUTABILE — zod ignora le chiavi sconosciute,
   * quindi il check va fatto sul corpo GREZZO: mai input ignorato in
   * silenzio quando la semantica conta (convertire il tipo di
   * membership metterebbe regole su righe di membri e viceversa). */
  if (rawBody && typeof rawBody === 'object' && 'ruleType' in (rawBody as Record<string, unknown>)) {
    return fail('RULE_TYPE_IMMUTABLE', 'Il tipo di appartenenza (ruleType) non è modificabile dopo la creazione: MANUAL = membri espliciti, DYNAMIC = regola valutata a runtime. Crea un nuovo gruppo se ti serve l\'altro tipo.', 422)
  }

  const parsed = UpdateDeviceGroupInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const existing = await db.deviceGroup.findUnique({
    where: { id },
    include: DEVICE_GROUP_INCLUDE,
  })
  if (!existing) return notFound()

  const isDynamic = existing.ruleType === 'DYNAMIC'

  /* --- 16.4: incrocio input ⊕ tipo del gruppo — mai input ignorato --- */
  if (isDynamic && input.deviceIds !== undefined) {
    return fail('RULE_TYPE', 'Il gruppo è DYNAMIC: la membership è calcolata dalla regola a runtime e non può essere impostata per elenco. Modifica la regola (rules) oppure crea un gruppo MANUAL.', 422)
  }
  if (!isDynamic && input.rules !== undefined) {
    return fail('RULE_TYPE', 'Il gruppo è MANUAL: i membri si scelgono per elenco (deviceIds), non con una regola. Per un gruppo dinamico creane uno nuovo di tipo DYNAMIC.', 422)
  }

  /* --- rules (SOLO DYNAMIC): sostituzione integrale, valori validati
   *      contro i dati REALI del plant (niente regole su valori fantasma) --- */
  let newRules: GroupRule | null = null
  if (isDynamic && input.rules) {
    newRules = input.rules
    const offenders = await validateGroupRuleValues(existing.plantId, newRules)
    const bad = Object.entries(offenders).filter(([, list]) => list.length > 0)
    if (bad.length > 0) {
      return fail('BAD_BODY', 'La regola contiene valori non presenti nell\'impianto (validati contro i dati reali)', 422, bad.map(([k, list]) => ({
        path: `rules.${k}`,
        message: `Valori non presenti nell'impianto (mostrati al massimo 5 su ${list.length}): ${(list as string[]).slice(0, 5).join(', ')}`,
        ...(k === 'unknownLocationIds' ? { unknownLocationIds: (list as string[]).slice(0, 5) } : {}),
      })))
    }
  }

  /* --- deviceIds (SOLO MANUAL): sostituzione integrale, validati --- */
  const deviceIds = !isDynamic && input.deviceIds ? Array.from(new Set(input.deviceIds)) : null
  if (deviceIds && deviceIds.length > 0) {
    const offending = await offendingDeviceIds(existing.plantId, deviceIds)
    if (offending.length > 0) {
      return fail('BAD_BODY', 'Alcuni dispositivi indicati non esistono o non appartengono all\'impianto', 422, [
        { path: 'deviceIds', message: `Id non validi (mostrati al massimo 5 su ${offending.length})`, unknownDeviceIds: offending.slice(0, 5) },
      ])
    }
  }

  /* Membership ATTUALE (per il diff sintetico dell'audit) */
  const currentIds = new Set(existing.members.map((m) => m.deviceId))

  /* --- Diff calcolato PRIMA della scrittura (come le manutenzioni):
   * una patch senza ALCUN effetto reale → 422 NO_CHANGES esplicito,
   * mai input ignorato in silenzio. --- */
  const nameChanged = input.name !== undefined && input.name !== existing.name
  const descriptionChanged = input.description !== undefined && input.description !== existing.description
  const colorChanged = input.color !== undefined && input.color !== existing.color
  /* rules cambia solo se la regola normalizzata differisce da quella
   * salvata: rispecificare la regola IDENTICA non è una modifica. */
  const existingRules = isDynamic ? parseGroupRule(existing.ruleJson) : null
  const rulesChanged = newRules !== null && JSON.stringify(normRule(newRules)) !== JSON.stringify(normRule(existingRules))
  let added = 0
  let removed = 0
  if (deviceIds !== null) {
    const newIds = new Set(deviceIds)
    added = deviceIds.filter((d) => !currentIds.has(d)).length
    removed = [...currentIds].filter((d) => !newIds.has(d)).length
  }
  const membershipChanged = deviceIds !== null && (added > 0 || removed > 0)
  if (!nameChanged && !descriptionChanged && !colorChanged && !membershipChanged && !rulesChanged) {
    return fail('NO_CHANGES', 'Nessun campo modificato: la patch non ha alcun effetto sul gruppo (stato già conforme alla richiesta)', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + membership + audit in transazione interattiva --- */
  const result = await db.$transaction(async (tx) => {
    /* name cambiato → univocità per plant (escluso il gruppo stesso) */
    if (nameChanged) {
      const dup = await tx.deviceGroup.count({
        where: { plantId: existing.plantId, name: input.name!, id: { not: existing.id } },
      })
      if (dup > 0) return { kind: 'exists' as const }
    }

    const g = await tx.deviceGroup.update({
      where: { id: existing.id },
      data: {
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
        ...(input.color !== undefined ? { color: input.color } : {}),
        ...(rulesChanged && newRules ? { ruleJson: JSON.stringify(newRules) } : {}),
      },
    })

    let addedTx = 0
    let removedTx = 0
    if (membershipChanged) {
      await tx.deviceGroupMember.deleteMany({ where: { groupId: existing.id } })
      if (deviceIds !== null && deviceIds.length > 0) {
        await tx.deviceGroupMember.createMany({
          data: deviceIds.map((deviceId) => ({ groupId: existing.id, deviceId })),
          // niente skipDuplicates: NON supportato su SQLite/Prisma; sicuro
          // senza perché la membership è stata appena azzerata (deleteMany)
        })
      }
      addedTx = added
      removedTx = removed
    }

    /* Diff sintetico: SOLO ciò che è cambiato davvero (niente rumore) */
    const changes: Record<string, unknown> = {}
    if (nameChanged) {
      changes.name = { from: existing.name, to: input.name }
    }
    if (descriptionChanged) {
      changes.description = { from: existing.description.slice(0, 80), to: input.description!.slice(0, 80) }
    }
    if (colorChanged) {
      changes.color = { from: existing.color, to: input.color }
    }
    if (membershipChanged) {
      changes.members = { added: addedTx, removed: removedTx }
    }
    if (rulesChanged) {
      changes.rules = { from: normRule(existingRules), to: normRule(newRules) }
    }

    await tx.auditLog.create({
      data: {
        action: 'DEVICE_GROUP_UPDATE',
        actor: email,
        targetId: g.id,
        targetLabel: g.name.slice(0, 80),
        plantId: g.plantId,
        details: JSON.stringify({
          groupId: g.id,
          name: g.name,
          changes,
        }),
      },
    })
    return { kind: 'updated' as const }
  })

  if (result.kind === 'exists') {
    return fail('GROUP_EXISTS', `Esiste già un gruppo chiamato «${input.name}» in questo impianto: i nomi sono univoci per impianto`, 422)
  }

  /* --- Riga aggiornata (relazioni ricaricate; per i DYNAMIC la
   *      membership è RICALCOLATA dopo la modifica della regola) --- */
  const row = await db.deviceGroup.findUnique({
    where: { id: existing.id },
    include: DEVICE_GROUP_INCLUDE,
  })
  if (!row) return notFound()

  let dyn: { members: DeviceGroupRow['members']; total: number } | null = null
  if (row.ruleType === 'DYNAMIC') {
    const rules = parseGroupRule(row.ruleJson)
    if (rules) dyn = await computeDynamicGroupMembers(row.plantId, rules)
  }

  const data = toDeviceGroupRow(row, dyn ?? undefined)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(DeviceGroupRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.deviceGroup.findUnique({ where: { id } })
  if (!existing) return notFound()

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Delete + audit in transazione: i conteggi (membri, scope)
   * vengono letti DENTRO la transazione per essere coerenti con la
   * cancellazione (onestà della risposta removedScopes). Per i gruppi
   * DYNAMIC i membri sono CALCOLATI dalla regola (nessuna riga
   * salvata): l'audit dichiara regola e totale calcolato al momento
   * dell'eliminazione. La delete rimuove a cascata DeviceGroupMember
   * e MaintenanceWindowGroup (schema onDelete: Cascade): le finestre
   * sopravvivono. */
  const dynamicRules = existing.ruleType === 'DYNAMIC' ? parseGroupRule(existing.ruleJson) : null
  const computedTotal = dynamicRules
    ? (await computeDynamicGroupMembers(existing.plantId, dynamicRules)).total
    : null
  const removedScopes = await db.$transaction(async (tx) => {
    const members = await tx.deviceGroupMember.count({ where: { groupId: existing.id } })
    const scopes = await tx.maintenanceWindowGroup.count({ where: { groupId: existing.id } })
    await tx.deviceGroup.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'DEVICE_GROUP_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.name.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({
          groupId: existing.id,
          name: existing.name,
          ruleType: existing.ruleType,
          ...(computedTotal !== null
            ? { rules: dynamicRules, computedMembers: computedTotal }
            : { members }),
          removedScopes: scopes,
          note: 'Le finestre che usavano questo gruppo come scope NON vengono eliminate: perdono solo questo scope',
        }),
      },
    })
    return scopes
  })

  const data = { id: existing.id, removedScopes }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(DeviceGroupDeletedSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}