/* ================================================================
 * /api/v2/terminal/probe — POST {deviceId} (16.7 W3.5, W7.0)
 * Domanda a cui risponde: «Posso aprire una sessione SSH su questo
 * dispositivo reale?». Tentativo ONESTO: scansione TCP della porta 22
 * del device (mini-service discovery :3002, endpoint /scan con CIDR
 * /32) — NESSUNA sessione fittizia.
 *  · device REALE nello scope del plant → 404 altrimenti;
 *  · sshPortOpen/reachable/latencyMs dal risultato REALE della
 *    scansione (host con porta 22 aperta → reachable; latenza nulla
 *    se l'host non ha risposto: non misurabile, onesto);
 *  · detail dichiara l'esito: porta aperta → «sessione SSH non
 *    disponibile in modalità riproduzione (nessuna riga fittizia)»;
 *    chiusa/timeout → «host non raggiungibile sulla porta 22 (rete
 *    dimostrativa: gli IP dell'impianto non sono instradati)»;
 *  · sessionOpened: SEMPRE false in replay (dichiarato: MAI una
 *    sessione inventata);
 *  · servizio giù → 503 pass-through (proxyFail, come /discovery/*);
 *  · audit TERMINAL_PROBE (deviceId/hostname/esito): l'audit non
 *    blocca mai la risposta della sonda.
 * Lettura di rete + audit: sessione richiesta (nessun ruolo extra,
 * come le sonde /discovery/*). Nessuna credenziale toccata.
 * ================================================================ */

import { z } from 'zod'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { TerminalProbeResultSchema } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

/** Corpo {deviceId}: il dispositivo REALE su cui tentare la porta 22. */
const BodySchema = z.object({ deviceId: z.string().min(1, 'deviceId richiesto') })

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON { deviceId })', 422)
  }
  const parsed = BodySchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- Dispositivo REALE nello scope del plant --- */
  const device = await db.device.findFirst({
    where: {
      id: input.deviceId,
      plantId: p.id, // v16.12 W10: scope per plantId diretto
      decommissionedAt: null,
    },
    select: { id: true, hostname: true, ip: true },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato (o fuori dallo scope dell\'impianto, o dismesso)', 404)

  /* --- Scansione TCP della sola porta 22 (CIDR /32: un solo host).
   *      Il servizio elenca SOLO gli host con almeno una porta aperta:
   *      assenza = non raggiungibile (onesto). --- */
  const pr = await discoveryPost('/scan', {
    cidr: `${device.ip}/32`,
    ports: [22],
    timeoutMs: 1200,
  })
  if (!pr.ok) return proxyFail(pr)

  const wrapped = pr.body as { job?: {
    hosts: Array<{ ip: string; alive: true; latencyMs: number; openPorts: Array<{ port: number; state: string }> }>
  } }
  const job = wrapped.job
  if (!job) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
  }

  const host = job.hosts.find((h) => h.ip === device.ip)
  const sshPortOpen = host?.openPorts.some((port) => port.port === 22) ?? false
  /* Con la sola porta 22 in scansione: reachable ⇔ porta 22 aperta. */
  const reachable = sshPortOpen
  const latencyMs = sshPortOpen && host ? host.latencyMs : null
  const detail = sshPortOpen
    ? 'porta 22 aperta: sessione SSH non disponibile in modalità riproduzione (nessuna riga fittizia)'
    : 'host non raggiungibile sulla porta 22 (rete dimostrativa: gli IP dell\'impianto non sono instradati)'

  const data = {
    deviceId: device.id,
    hostname: device.hostname,
    ip: device.ip,
    sshPortOpen,
    reachable,
    latencyMs,
    detail,
    sessionOpened: false, // SEMPRE false in replay: MAI sessione fittizia
  }

  /* Audit del tentativo (deviceId/hostname/esito): non deve bloccare
   * la risposta della sonda. */
  const email = session.session.user.email ?? 'sconosciuto'
  try {
    await db.auditLog.create({
      data: {
        action: 'TERMINAL_PROBE',
        actor: email,
        targetId: device.id,
        targetLabel: device.hostname.slice(0, 80),
        plantId: p.id,
        details: JSON.stringify({
          deviceId: device.id,
          hostname: device.hostname,
          ip: device.ip,
          sshPortOpen,
          reachable,
          latencyMs,
          sessionOpened: false, // onesto: riproduzione, nessuna sessione
        }),
      },
    })
  } catch {
    /* l'audit non deve bloccare la risposta della sonda */
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(TerminalProbeResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
