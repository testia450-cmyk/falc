/* ================================================================
 * /api/v2/alarms — GET
 * Domanda a cui risponde (§6.1): «Quali allarmi sono aperti, quanto sono
 * gravi e vecchi, e quali sono soppressi da una causa radice?»
 * Filtri: status/severity (CSV), deviceId, testo sul messaggio.
 * Ordinamento: severità DESC (CRITICAL>HIGH>AVERAGE>WARNING>INFO) poi
 * openedAt DESC — l'ordinamento per severità NON è alfabetico, quindi
 * si ordina in memoria (select leggero su id/severity/openedAt, poi si
 * caricano con include solo gli item della pagina).
 * Deduzioni oneste (documentate):
 *  · suppressedByRootCause/rootCauseHostname dedotte dal messaggio: il
 *    DB reale usa il formato del correlatore v15 «[CORRELATO: causa
 *    radice X]» (4428 messaggi reali), il motore alert-engine v15 usa
 *    «[SOPPRESSO: causa radice X]»: la regex copre ENTRAMBI i marker,
 *    catturando l'hostname dopo «causa radice» fino a «]»;
 *  · deviceUiStatus derivata SOLO per i device della pagina (allowlist
 *    minima + getMonitoredMap + isStale, stessa regola deriveUiStatus);
 *  · ageMinutes = (now − openedAt)/60000 arrotondato;
 *  · senza filtro status si vedono TUTTI gli stati (anche CLOSED).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, requireSession, parseQuery, csv } from '@/lib/v2/api-helpers'
import { AlarmsQuerySchema, AlarmsPageSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode, getMonitoredMap, deriveUiStatus } from '@/lib/v2/derive'
import { isStale } from '@/lib/domain/status'
import { resolvePlant, devValidate, maxOf, SEVERITY_RANK } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const ROOT_CAUSE_RE = /\[(?:SOPPRESSO|CORRELATO)[^\]]*causa radice\s+([^\]]+?)\s*\]/

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(AlarmsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const now = new Date()

  /* --- Passo 1: chiave di ordinamento su tutto il set filtrato --- */
  const statusFilter = csv(q.value.status)
  const severityFilter = csv(q.value.severity)
  const where: Prisma.AlertEventWhereInput = { plantId: p.id }
  if (statusFilter.length) where.status = { in: statusFilter }
  if (severityFilter.length) where.severity = { in: severityFilter }
  if (q.value.deviceId) where.deviceId = q.value.deviceId
  if (q.value.q) where.message = { contains: q.value.q }

  const keys = await db.alertEvent.findMany({
    where,
    select: { id: true, severity: true, openedAt: true },
  })
  keys.sort((a, b) => {
    const sa = SEVERITY_RANK[a.severity] ?? 0
    const sb = SEVERITY_RANK[b.severity] ?? 0
    if (sa !== sb) return sb - sa // gravità prima
    return b.openedAt.getTime() - a.openedAt.getTime() // più recente prima
  })

  const total = keys.length
  const pageCount = Math.max(1, Math.ceil(total / q.value.pageSize))
  const pageIds = keys
    .slice((q.value.page - 1) * q.value.pageSize, q.value.page * q.value.pageSize)
    .map((k) => k.id)

  /* --- Passo 2: dettagli SOLO della pagina (rule + device) --- */
  const pageAlerts = pageIds.length
    ? await db.alertEvent.findMany({
        where: { id: { in: pageIds } },
        include: {
          rule: { select: { name: true } },
          device: { select: { id: true, hostname: true, ip: true, status: true, lastSeenAt: true } },
        },
      })
    : []
  const byId = new Map(pageAlerts.map((a) => [a.id, a]))
  const ordered = pageIds.map((id) => byId.get(id)).filter((a): a is NonNullable<typeof a> => !!a)

  /* --- deviceUiStatus: solo per i device referenziati dalla pagina --- */
  const devIds = [...new Set(ordered.map((a) => a.deviceId).filter((x): x is string => !!x))]
  const monitored = await getMonitoredMap(p.id)
  const devRecs = devIds.length
    ? await db.device.findMany({
        where: { id: { in: devIds } },
        select: { id: true, status: true, lastSeenAt: true },
      })
    : []
  const uiStatusById = new Map<string, string>()
  for (const d of devRecs) {
    const mon = monitored.byDevice.get(d.id)
    const stale = isStale(d.lastSeenAt, mon?.intervalSec ?? null, now)
    uiStatusById.set(d.id, deriveUiStatus({ status: d.status, monitored: !!mon, stale }))
  }

  const data = {
    items: ordered.map((a) => {
      const m = ROOT_CAUSE_RE.exec(a.message)
      return {
        id: a.id,
        ruleId: a.ruleId,
        ruleName: a.rule?.name ?? null,
        severity: a.severity,
        status: a.status,
        message: a.message,
        occurrenceCount: a.occurrenceCount,
        openedAt: a.openedAt.getTime(),
        acknowledgedAt: a.acknowledgedAt?.getTime() ?? null,
        acknowledgedBy: a.acknowledgedBy ?? null,
        closedAt: a.closedAt?.getTime() ?? null,
        escalatedAt: a.escalatedAt?.getTime() ?? null,
        deviceId: a.deviceId ?? null,
        deviceHostname: a.device?.hostname ?? null,
        deviceIp: a.device?.ip ?? null,
        deviceUiStatus: a.device ? (uiStatusById.get(a.device.id) ?? null) : null,
        suppressedByRootCause: m !== null,
        rootCauseHostname: m ? m[1] : null,
        ageMinutes: Math.round((now.getTime() - a.openedAt.getTime()) / 60000),
      }
    }),
    total,
    page: q.value.page,
    pageSize: q.value.pageSize,
    pageCount,
  }

  const asOf = maxOf(...ordered.map((a) => a.updatedAt.getTime())) || Date.now()
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(AlarmsPageSchema, body)
  return ok(data, asOf, mode)
}
