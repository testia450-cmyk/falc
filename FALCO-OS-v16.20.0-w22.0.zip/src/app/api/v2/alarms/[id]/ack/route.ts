/* ================================================================
 * /api/v2/alarms/[id]/ack — POST { note? }
 * Domanda a cui risponde (§6.1): «Prendo in carico questo allarme»
 * (riconoscimento Tecnico: OPEN → ACK, con audit trail).
 *  · richiede sessione (401) e ruolo ≥ TECNICO (403 FORBIDDEN);
 *  · solo allarmi OPEN: se già ACK → 409 ALREADY_ACK; se in altro
 *    stato (CLOSED/SUPPRESSED/ESCALATED) → 409 INVALID_STATE;
 *  · aggiorna acknowledgedAt/acknowledgedBy (email di sessione) e
 *    scrive AuditLog in TRANSAZIONE con l'update. Campi REALI del
 *    modello AuditLog verificati sullo schema Prisma (v15): action,
 *    actor, targetId, targetLabel, plantId, details (JSON), createdAt
 *    — NIENTE campi inesistenti (userId/ip non esistono nel modello).
 *  · risponde con l'allarme aggiornato (AlarmRowSchema).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { AckAlarmBodySchema, AlarmRowSchema } from '@/lib/v2/contracts'
import { hasRole } from '@/lib/auth'
import { getReplayState, apiMode, getMonitoredMap, deriveUiStatus } from '@/lib/v2/derive'
import { isStale } from '@/lib/domain/status'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const ROOT_CAUSE_RE = /\[(?:SOPPRESSO|CORRELATO)[^\]]*causa radice\s+([^\]]+?)\s*\]/

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  /* --- Corpo opzionale { note? } --- */
  let rawBody: unknown = {}
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con campo opzionale "note")', 422)
  }
  const parsedBody = AckAlarmBodySchema.safeParse(rawBody)
  if (!parsedBody.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsedBody.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const note = parsedBody.data.note

  /* --- Allarme esistente? --- */
  const alarm = await db.alertEvent.findUnique({
    where: { id },
    include: {
      rule: { select: { name: true } },
      device: { select: { id: true, hostname: true, ip: true, status: true, lastSeenAt: true } },
    },
  })
  if (!alarm) return fail('NOT_FOUND', 'Allarme non trovato', 404)

  if (alarm.status === 'ACK') {
    return fail('ALREADY_ACK', 'Allarme già riconosciuto', 409)
  }
  if (alarm.status !== 'OPEN') {
    return fail('INVALID_STATE', `Solo gli allarmi con stato OPEN possono essere riconosciuti (stato attuale: ${alarm.status})`, 409)
  }

  const now = new Date()
  const email = session.session.user.email ?? 'sconosciuto'

  /* --- Update + audit in transazione --- */
  const [updated] = await db.$transaction([
    db.alertEvent.update({
      where: { id },
      data: {
        status: 'ACK',
        acknowledgedAt: now,
        acknowledgedBy: email,
      },
      include: {
        rule: { select: { name: true } },
        device: { select: { id: true, hostname: true, ip: true, status: true, lastSeenAt: true } },
      },
    }),
    db.auditLog.create({
      data: {
        action: 'ALERT_ACK',
        actor: email,
        targetId: alarm.id,
        targetLabel: alarm.rule?.name ?? alarm.message.slice(0, 80),
        plantId: alarm.plantId,
        details: JSON.stringify({
          note: note ?? null,
          deviceId: alarm.deviceId ?? null,
          severity: alarm.severity,
          previousStatus: 'OPEN',
          newStatus: 'ACK',
          by: email,
        }),
      },
    }),
  ])

  /* --- deviceUiStatus per la riga di risposta --- */
  let deviceUiStatus: string | null = null
  if (updated.device) {
    const monitored = await getMonitoredMap(updated.plantId)
    const mon = monitored.byDevice.get(updated.device.id)
    const stale = isStale(updated.device.lastSeenAt, mon?.intervalSec ?? null, now)
    deviceUiStatus = deriveUiStatus({ status: updated.device.status, monitored: !!mon, stale })
  }

  const m = ROOT_CAUSE_RE.exec(updated.message)
  const data = {
    id: updated.id,
    ruleId: updated.ruleId,
    ruleName: updated.rule?.name ?? null,
    severity: updated.severity,
    status: updated.status,
    message: updated.message,
    occurrenceCount: updated.occurrenceCount,
    openedAt: updated.openedAt.getTime(),
    acknowledgedAt: updated.acknowledgedAt?.getTime() ?? null,
    acknowledgedBy: updated.acknowledgedBy ?? null,
    closedAt: updated.closedAt?.getTime() ?? null,
    escalatedAt: updated.escalatedAt?.getTime() ?? null,
    deviceId: updated.deviceId ?? null,
    deviceHostname: updated.device?.hostname ?? null,
    deviceIp: updated.device?.ip ?? null,
    deviceUiStatus,
    suppressedByRootCause: m !== null,
    rootCauseHostname: m ? m[1] : null,
    ageMinutes: Math.round((now.getTime() - updated.openedAt.getTime()) / 60000),
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  const asOf = now.getTime()
  devValidate(AlarmRowSchema, data) // risposta singola: valida la riga dentro ok()
  return ok(data, asOf, mode)
}
