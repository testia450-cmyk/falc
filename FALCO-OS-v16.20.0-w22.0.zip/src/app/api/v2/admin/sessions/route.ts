/* ================================================================
 * /api/v2/admin/sessions — GET — 16.9.0 W4
 * Sessioni attive (port v15 V12-G). ONESTÀ v16: la sessione NextAuth
 * è JWT STATELESS (auth.ts strategy 'jwt') → la tabella Session resta
 * a 0 righe per costruzione; la risposta lo DICHIARA (note) invece
 * di fingere un elenco. Le righe future (database sessions) verrebbero
 * elencate con utente/scadenza. SUPER_ADMIN only.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { AdminSessionsSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, maxOf } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Accesso negato. Richiesto ruolo SUPER_ADMIN.', 403)
  }

  const sessions = await db.session.findMany({
    include: { user: { select: { email: true, role: true } } },
    orderBy: { expires: 'desc' },
    take: 100,
  })

  const data = {
    total: sessions.length,
    sessions: sessions.map((s) => ({
      id: s.id,
      userEmail: s.user.email,
      userRole: s.user.role,
      expires: s.expires.getTime(),
    })),
    note: sessions.length === 0
      ? 'Nessuna sessione persistita: FALCO-OS v16 usa sessioni JWT stateless (12 ore), la tabella Session resta vuota per costruzione — dichiarato, non un errore.'
      : 'Sessioni persistite dalla tabella Session.',
  }

  const asOf = maxOf(...sessions.map((s) => s.expires.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AdminSessionsSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
