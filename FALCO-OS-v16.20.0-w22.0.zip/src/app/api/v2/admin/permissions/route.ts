/* ================================================================
 * /api/v2/admin/permissions — GET — 16.9.0 W4
 * Ispezione della matrice RBAC v2 (port statico fedele v15 V12-B):
 * «chi può fare cosa» dichiarato in un unico punto. Riservato a
 * SUPER_ADMIN (la matrice include i permessi amministrativi).
 * Payload statico e in-memory: zero query oltre l'auth.
 * ================================================================ */

import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { AdminPermissionsSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { PERMISSIONS, permissionModules, roleMatrix } from '@/lib/v2/rbac'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Accesso negato. Richiesto ruolo SUPER_ADMIN.', 403)
  }

  const matrix = roleMatrix()
  const data = {
    version: 2,
    catalog: [...PERMISSIONS],
    modules: permissionModules(),
    roles: Object.fromEntries(Object.entries(matrix).map(([role, perms]) => [role, [...perms]])),
  }

  const now = Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AdminPermissionsSchema, { ok: true as const, asOf: now, mode, data })
  return ok(data, now, mode)
}
