/* ================================================================
 * /api/v2/admin/stats — GET (conteggi REALI del DB)
 * Domanda a cui risponde (§6.8 Amministrazione): «Quanto è grande e
 * attivo il DB reale dell'impianto in questo momento?»
 *  · devices usa lo STESSO scope del /noc/summary (OR location.plantId
 *    / locationId null → 200, inclusi i 30 mai assegnati);
 *  · alertsOpen = status != CLOSED (stessa definizione del summary);
 *  · ticketsByStatus via groupBy (stati reali distinti del DB);
 *  · auditLogEntries e metricSamples sono conteggi pesanti (48k /
 *    ~700k righe): una tantum per vista, non in polling;
 *  · coveragePct dal più recente TopologyCoverageSnapshot reale
 *    (stesso calcolo già esposto dal summary: 56,1%; null = nessuno
 *    snapshot — mai un numero inventato).
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { AdminStatsQuerySchema, AdminStatsSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(AdminStatsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const now = new Date()

  const [
    devices,
    locations,
    plants,
    alertsOpen,
    alertsSuppressed,
    ticketGroups,
    maintenanceWindows,
    auditLogEntries,
    metricSamples,
    pollingSchedules,
    coverageSnap,
  ] = await Promise.all([
    db.device.count({ where: { plantId: p.id } }), // v16.12 W10: scope per plantId diretto
    db.location.count({ where: { plantId: p.id } }),
    db.plant.count(),
    db.alertEvent.count({ where: { plantId: p.id, status: { not: 'CLOSED' } } }),
    db.alertEvent.count({ where: { plantId: p.id, status: 'SUPPRESSED' } }),
    db.ticket.groupBy({ by: ['status'], _count: { _all: true }, where: { plantId: p.id } }),
    db.maintenanceWindow.count({ where: { plantId: p.id } }),
    db.auditLog.count(), // registro globale (righe SYSTEM senza plantId)
    db.metricValue.count({ where: { plantId: p.id } }),
    db.pollingSchedule.count({ where: { plantId: p.id } }),
    db.topologyCoverageSnapshot.findFirst({ where: { plantId: p.id }, orderBy: { createdAt: 'desc' } }),
  ])

  const ticketsByStatus: Record<string, number> = {}
  let ticketsTotal = 0
  for (const g of ticketGroups) {
    ticketsByStatus[g.status] = g._count._all
    ticketsTotal += g._count._all
  }

  const data = {
    devices,
    locations,
    plants,
    alertsOpen,
    alertsSuppressed,
    ticketsByStatus,
    ticketsTotal,
    maintenanceWindows,
    auditLogEntries,
    metricSamples,
    pollingSchedules,
    coveragePct: coverageSnap?.coveragePct ?? null,
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  const asOf = now.getTime()
  devValidate(AdminStatsSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
