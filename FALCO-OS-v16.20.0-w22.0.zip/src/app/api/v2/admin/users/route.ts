/* ================================================================
 * /api/v2/admin/users — GET (elenco) + POST (creazione) — 16.9.0 W4
 * AMMINISTRAZIONE COMPLETA: CRUD utenti (port fedele da v15
 * /api/admin/users, SUPER_ADMIN only). Nel DB reale: 1 utente
 * (admin demo) — la lista è REALE.
 *  · GET: righe con plantIds (assegnazioni reali) e sessionCount
 *    (tabella Session: JWT stateless → 0, dichiarato);
 *  · POST: policy password enterprise (port v15 V12-H: min 10,
 *    quattro classi, lista nera top-100, divieto dati personali),
 *    email unique (409), plantIds verificati PRIMA di scrivere (FK),
 *    hash bcrypt(12), mustChangePassword: true; audit USER_CREATE.
 * ================================================================ */

import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { AdminUsersPageSchema, CreateUserInputSchema, AdminUserRowSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { validatePasswordPolicy } from '@/lib/v2/rbac'

export const dynamic = 'force-dynamic'

export function toAdminUserRow(u: {
  id: string; name: string; email: string; role: string;
  mustChangePassword: boolean; totpEnabled: boolean;
  createdAt: Date; updatedAt: Date;
  plantAssignments: Array<{ plantId: string }>;
  _count: { sessions: number }
}) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    mustChangePassword: u.mustChangePassword,
    totpEnabled: u.totpEnabled,
    createdAt: u.createdAt.getTime(),
    updatedAt: u.updatedAt.getTime(),
    plantIds: u.plantAssignments.map((p) => p.plantId),
    sessionCount: u._count.sessions,
  }
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Accesso negato. Richiesto ruolo SUPER_ADMIN.', 403)
  }

  const users = await db.user.findMany({
    select: {
      id: true, name: true, email: true, role: true,
      mustChangePassword: true, totpEnabled: true,
      createdAt: true, updatedAt: true,
      plantAssignments: { select: { plantId: true } },
      _count: { select: { sessions: true } },
    },
    orderBy: { createdAt: 'asc' },
  })

  const data = {
    users: users.map(toAdminUserRow),
    total: users.length,
  }
  const asOf = maxOf(...users.map((u) => u.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AdminUsersPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Accesso negato. Richiesto ruolo SUPER_ADMIN.', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = CreateUserInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* policy password (contesto = utente NUOVO: email/nome del destinatario) */
  const policy = validatePasswordPolicy(input.password, { email: input.email, name: input.name })
  if (!policy.ok) {
    return fail('BAD_PASSWORD', `Password non conforme alla policy: ${policy.violations.map((v) => v.message).join('; ')}`, 422)
  }

  /* impianti assegnati verificati PRIMA di toccare le righe (FK onesta) */
  if (input.plantIds && input.plantIds.length > 0) {
    const found = await db.plant.findMany({ where: { id: { in: input.plantIds } }, select: { id: true } })
    if (found.length !== new Set(input.plantIds).size) {
      return fail('BAD_BODY', 'Uno o più impianti assegnati non esistono', 422)
    }
  }

  const existing = await db.user.findUnique({ where: { email: input.email } })
  if (existing) return fail('CONFLICT', 'Email già registrata', 409)

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  const user = await db.$transaction(async (tx) => {
    const u = await tx.user.create({
      data: {
        name: input.name,
        email: input.email,
        passwordHash: await bcrypt.hash(input.password, 12),
        role: input.role,
        mustChangePassword: true,
        ...(input.plantIds?.length
          ? { plantAssignments: { create: input.plantIds.map((pid) => ({ plantId: pid })) } }
          : {}),
      },
      select: {
        id: true, name: true, email: true, role: true,
        mustChangePassword: true, totpEnabled: true,
        createdAt: true, updatedAt: true,
        plantAssignments: { select: { plantId: true } },
        _count: { select: { sessions: true } },
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'USER_CREATE',
        actor: email,
        targetId: u.id,
        targetLabel: u.email,
        details: JSON.stringify({ role: u.role, plantCount: input.plantIds?.length ?? 0 }),
      },
    })
    return u
  })

  const row = toAdminUserRow(user)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AdminUserRowSchema, row)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data: row }, { status: 201 })
}
