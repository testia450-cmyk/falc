/* ================================================================
 * /api/v2/admin/users/[id] — PATCH (aggiorna) + DELETE — 16.9.0 W4
 * Port fedele v15 (guardie incluse):
 *  · PATCH: policy password sul DESTINATARIO (email/nome aggiornati),
 *    guardia ultimo SUPER_ADMIN anche sul DOWNGRADE (v11.17 M-14),
 *    email unique (409), plantIds = sostituzione integrale IN
 *    TRANSAZIONE (v11.18 M-02: mai utente senza perimetro a metà),
 *    reset password → passwordChangedAt + mustChangePassword (F-09:
 *    invalidazione sessioni compromesse); audit USER_UPDATE con
 *    fields (mai l'hash);
 *  · DELETE: vietato eliminare TE STESSO; guardia ultimo
 *    SUPER_ADMIN; audit USER_DELETE.
 * ================================================================ */

import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { UpdateUserInputSchema, AdminUserRowSchema, UserDeletedSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { validatePasswordPolicy } from '@/lib/v2/rbac'
import { toAdminUserRow } from '@/app/api/v2/admin/users/route'

export const dynamic = 'force-dynamic'

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Accesso negato. Richiesto ruolo SUPER_ADMIN.', 403)
  }

  const { id } = await ctx.params
  const existing = await db.user.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Utente non trovato', 404)

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = UpdateUserInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* policy sul DESTINATARIO (email/nome aggiornati, non l'admin) */
  if (input.password) {
    const policy = validatePasswordPolicy(input.password, {
      email: input.email || existing.email,
      name: input.name || existing.name,
    })
    if (!policy.ok) {
      return fail('BAD_PASSWORD', `Password non conforme alla policy: ${policy.violations.map((v) => v.message).join('; ')}`, 422)
    }
  }

  /* guardia downgrade ultimo SUPER_ADMIN (v11.17 M-14) */
  if (existing.role === 'SUPER_ADMIN' && input.role && input.role !== 'SUPER_ADMIN') {
    const superCount = await db.user.count({ where: { role: 'SUPER_ADMIN' } })
    if (superCount <= 1) {
      return fail('INVALID_STATE', 'Impossibile degradare l\'ultimo SUPER_ADMIN: prima promuovi un altro utente.', 422)
    }
  }

  /* email unique se cambiata */
  if (input.email && input.email !== existing.email) {
    const emailTaken = await db.user.findUnique({ where: { email: input.email } })
    if (emailTaken) return fail('CONFLICT', 'Email già registrata', 409)
  }

  /* impianti verificati PRIMA di toccare le righe */
  if (Array.isArray(input.plantIds) && input.plantIds.length > 0) {
    const found = await db.plant.findMany({ where: { id: { in: input.plantIds } }, select: { id: true } })
    if (found.length !== new Set(input.plantIds).size) {
      return fail('BAD_BODY', 'Uno o più impianti assegnati non esistono', 422)
    }
  }

  const updateData: Prisma.UserUpdateInput = {}
  if (input.name) updateData.name = input.name
  if (input.email) updateData.email = input.email
  if (input.role) updateData.role = input.role
  if (typeof input.mustChangePassword === 'boolean') updateData.mustChangePassword = input.mustChangePassword
  if (input.password) {
    updateData.passwordHash = await bcrypt.hash(input.password, 12)
    /* F-09: il reset invalida le sessioni esistenti del compromesso */
    updateData.passwordChangedAt = new Date()
    if (typeof input.mustChangePassword !== 'boolean') updateData.mustChangePassword = true
  }

  const email = session.session.user.email ?? 'sconosciuto'

  const user = await db.$transaction(async (tx) => {
    /* sostituzione integrale del perimetro, ATOMICA (M-02) */
    if (Array.isArray(input.plantIds)) {
      await tx.plantAssignment.deleteMany({ where: { userId: id } })
      if (input.plantIds.length > 0) {
        await tx.plantAssignment.createMany({
          data: input.plantIds.map((pid) => ({ userId: id, plantId: pid })),
        })
      }
    }
    const u = await tx.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true, name: true, email: true, role: true,
        mustChangePassword: true, totpEnabled: true,
        createdAt: true, updatedAt: true,
        plantAssignments: { select: { plantId: true } },
        _count: { select: { sessions: true } },
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'USER_UPDATE',
        actor: email,
        targetId: u.id,
        targetLabel: u.email,
        details: JSON.stringify({
          fields: Object.keys(updateData).filter((f) => f !== 'passwordHash'),
          passwordReset: !!input.password,
          role: input.role ?? existing.role,
        }),
      },
    })
    return u
  })

  const row = toAdminUserRow(user)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(AdminUserRowSchema, row)
  return NextResponse.json({ ok: true as const, asOf: user.updatedAt.getTime(), mode, data: row })
}

/* ================================================================ */

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'SUPER_ADMIN')) {
    return fail('FORBIDDEN', 'Accesso negato. Richiesto ruolo SUPER_ADMIN.', 403)
  }

  const { id } = await ctx.params
  if (id === session.session.user.id) {
    return fail('INVALID_STATE', 'Non puoi eliminare te stesso', 422)
  }

  const existing = await db.user.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Utente non trovato', 404)

  /* guardia ultimo SUPER_ADMIN (M-14): blocco permanente, solo via DB */
  if (existing.role === 'SUPER_ADMIN') {
    const superCount = await db.user.count({ where: { role: 'SUPER_ADMIN' } })
    if (superCount <= 1) {
      return fail('INVALID_STATE', 'Impossibile eliminare l\'ultimo SUPER_ADMIN: prima promuovi un altro utente.', 422)
    }
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()
  const data = { deleted: true as const, id }

  await db.$transaction(async (tx) => {
    await tx.user.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'USER_DELETE',
        actor: email,
        targetId: id,
        targetLabel: existing.email,
        details: JSON.stringify({ role: existing.role }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(UserDeletedSchema, { ok: true as const, asOf: now.getTime(), mode, data })
  return ok(data, now.getTime(), mode)
}
