/* ================================================================
 * /api/v2/locations — GET
 * Domanda a cui risponde (§6.1): «Cosa c'è in ogni sede e qual è la
 * situazione sintetica sulla mappa?»
 * Per ogni Location del plant (con coordinate reali): conteggi
 * dispositivi per stato UI (derivate v2: la STESSA regola di
 * /devices — nessuno stato reinventato), numero apparati video
 * (famiglia CAMERA/LPR/NVR, convenzione unica v2) e worstStatus.
 * GERARCHIA «WORST» (definita qui, una volta sola — mocks §3.3):
 *   OFFLINE > DEGRADED > UNKNOWN > NOT_MONITORED > MAINTENANCE > ONLINE
 * (MAINTENANCE è uno stato intenzionale: conta meno di UNKNOWN ma più
 * di ONLINE; worstStatus = null per sedi senza dispositivi).
 * Conteggi da UNA sola loadDeviceRows raggruppata per locationId.
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { MapLocationsQuerySchema, MapLocationsSchema, type UiStatus } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate, VIDEO_TYPES, uiWorstRank } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

interface LocAgg {
  devices: number
  online: number
  degraded: number
  offline: number
  unknown: number
  notMonitored: number
  cameraCount: number
  worst: { status: UiStatus; rank: number } | null
}

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(MapLocationsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const { rows, asOf } = await loadDeviceRows(p.id)

  /* --- Aggregazione in memoria per locationId (una sola lettura) --- */
  const byLocation = new Map<string, LocAgg>()
  const emptyAgg = (): LocAgg => ({
    devices: 0, online: 0, degraded: 0, offline: 0, unknown: 0, notMonitored: 0,
    cameraCount: 0, worst: null,
  })
  for (const r of rows) {
    if (!r.locationId) continue
    const agg = byLocation.get(r.locationId) ?? emptyAgg()
    agg.devices++
    if (r.uiStatus === 'ONLINE') agg.online++
    else if (r.uiStatus === 'DEGRADED') agg.degraded++
    else if (r.uiStatus === 'OFFLINE') agg.offline++
    else if (r.uiStatus === 'UNKNOWN') agg.unknown++
    else if (r.uiStatus === 'NOT_MONITORED') agg.notMonitored++
    if (VIDEO_TYPES.includes(r.type)) agg.cameraCount++
    const rank = uiWorstRank(r.uiStatus)
    if (rank < 99 && (!agg.worst || rank < agg.worst.rank)) {
      agg.worst = { status: r.uiStatus, rank }
    }
    byLocation.set(r.locationId, agg)
  }

  const locations = await db.location.findMany({
    where: { plantId: p.id },
    orderBy: { name: 'asc' },
    select: { id: true, name: true, identifier: true, lat: true, lng: true },
  })

  const data = locations.map((l) => {
    const agg = byLocation.get(l.id)
    return {
      id: l.id,
      name: l.name,
      identifier: l.identifier,
      lat: l.lat ?? null,
      lng: l.lng ?? null,
      devices: agg?.devices ?? 0,
      online: agg?.online ?? 0,
      degraded: agg?.degraded ?? 0,
      offline: agg?.offline ?? 0,
      unknown: agg?.unknown ?? 0,
      notMonitored: agg?.notMonitored ?? 0,
      worstStatus: agg?.worst?.status ?? null,
      cameraCount: agg?.cameraCount ?? 0,
    }
  })

  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(MapLocationsSchema, body)
  return ok(data, asOf, mode)
}
