/* ================================================================
 * /api/v2/locations/[id] — DELETE — 16.10.0 W8
 * «Gestione punti di ripresa»: eliminare un punto creato per errore
 * (es. import KMZ sbagliato) senza toccare il resto.
 *   · 404 se il punto non esiste;
 *   · 409 LOCATION_IN_USE se ci sono dispositivi assegnati: prima
 *     vanno spostati (onesto, nessuna azione distruttiva implicita);
 *   · audit LOCATION_DELETE.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.location.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Punto non trovato', 404)

  /* --- guardia: dispositivi assegnati → il punto NON si elimina --- */
  const deviceCount = await db.device.count({ where: { locationId: id } })
  if (deviceCount > 0) {
    return fail(
      'LOCATION_IN_USE',
      `Il punto «${existing.name}» ha ${deviceCount} dispositivi assegnati: spostali prima di eliminarlo.`,
      409,
    )
  }

  const email = session.session.user.email ?? 'sconosciuto'
  await db.$transaction(async (tx) => {
    await tx.location.delete({ where: { id } })
    await tx.auditLog.create({
      data: {
        action: 'LOCATION_DELETE',
        actor: email,
        targetId: id,
        targetLabel: existing.name,
        plantId: existing.plantId,
        details: JSON.stringify({
          name: existing.name,
          identifier: existing.identifier,
          lat: existing.lat,
          lng: existing.lng,
          origin: 'gestione punti (16.10)',
        }),
      },
    })
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  const data = { deleted: true as const, id }
  return ok(data, Date.now(), mode)
}
