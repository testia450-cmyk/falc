/* ================================================================
 * /api/v2/locations/import-kmz/preview — POST (FASE 1, dry-run)
 * 16.10.0 W8 · porta fedele v15 v11.16 (multipart, piano, ZERO
 * scritture sul DB).
 *
 * multipart/form-data:
 *   file    → .kmz o .kml (max 10 MB)
 *   plantId → impianto su cui importare i punti
 *
 * Risposta (KmzPreviewSchema): { fileId, fileName, plantId, plan }
 *   · fileId OPACO: il file viene salvato in area temporanea del
 *     server (os.tmpdir, MAI nell'albero del progetto) e la apply
 *     lo RIAPRE e lo RI-PARSA — il client non può inventarsi
 *     coordinate o dispositivi;
 *   · piano per ogni placemark: CREATE / UPDATE_COORDS / NOOP +
 *     proposte di associazione dispositivi (ALTA/MEDIA/BASSA con
 *     base dichiarata) — la conferma spetta SEMPRE all'operatore;
 *   · pulizia file temporanei più vecchi di 2 h a ogni preview.
 * ================================================================ */

import { mkdir, writeFile, readdir, unlink, stat } from 'fs/promises'
import { tmpdir } from 'os'
import { join } from 'path'
import { randomUUID } from 'crypto'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { KmzPreviewSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { parsePointsFile } from '@/lib/domain/kmz-parser'
import { planPointImport } from '@/lib/domain/point-import-plan'

export const dynamic = 'force-dynamic'

const UPLOAD_DIR = join(tmpdir(), 'falco-kmz-upload')
const MAX_FILE_BYTES = 10 * 1024 * 1024 // 10 MB (v15)
const STALE_MS = 2 * 60 * 60 * 1000 // 2 h (v15 cleanupStaleUploads)

async function cleanupStaleUploads(): Promise<void> {
  try {
    await mkdir(UPLOAD_DIR, { recursive: true })
    const entries = await readdir(UPLOAD_DIR)
    const now = Date.now()
    for (const name of entries) {
      try {
        const f = await stat(join(UPLOAD_DIR, name))
        if (now - f.mtimeMs > STALE_MS) await unlink(join(UPLOAD_DIR, name))
      } catch {
        /* file sparito tra readdir e stat: ignora */
      }
    }
  } catch {
    /* la pulizia è best-effort: mai far fallire la preview */
  }
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* ---- multipart ---- */
  let formData: FormData
  try {
    formData = await req.formData()
  } catch {
    return fail('BAD_BODY', 'Richiesta non valida: atteso multipart/form-data con file e plantId', 422)
  }
  const file = formData.get('file')
  const plantId = String(formData.get('plantId') ?? '')
  if (!(file instanceof File)) {
    return fail('BAD_BODY', 'File KMZ/KML richiesto (campo «file» in multipart/form-data)', 422)
  }
  if (!plantId) {
    return fail('BAD_BODY', 'plantId richiesto', 422)
  }
  const lower = file.name.toLowerCase()
  if (!lower.endsWith('.kmz') && !lower.endsWith('.kml')) {
    return fail('BAD_BODY', 'Solo file .kmz e .kml sono supportati', 422)
  }
  if (file.size > MAX_FILE_BYTES) {
    return fail('BAD_BODY', `File troppo grande: ${(file.size / 1024 / 1024).toFixed(1)} MB (massimo 10 MB)`, 422)
  }
  if (file.size === 0) {
    return fail('BAD_BODY', 'File vuoto', 422)
  }

  /* ---- impianto ---- */
  const plant = await db.plant.findUnique({ where: { id: plantId } })
  if (!plant) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* ---- parse (il parse non scrive MAI sul DB) ---- */
  const buffer = Buffer.from(await file.arrayBuffer())
  let placemarks: Awaited<ReturnType<typeof parsePointsFile>>
  try {
    placemarks = await parsePointsFile(buffer, file.name)
  } catch (e) {
    return fail('BAD_FILE', e instanceof Error ? e.message : 'File KMZ/KML non leggibile', 422)
  }
  if (placemarks.length === 0) {
    return fail('BAD_FILE', 'Nessun placemark con coordinate valido nel file', 422)
  }

  /* ---- dati attuali dell'impianto (per il piano) ---- */
  const [locations, devices] = await Promise.all([
    db.location.findMany({
      where: { plantId },
      select: { id: true, identifier: true, name: true, address: true, lat: true, lng: true },
    }),
    db.device.findMany({
      where: { plantId, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
      select: { id: true, hostname: true, ip: true, type: true, locationId: true, locationAssignedBy: true },
    }),
  ])
  // punti «Da posizionare» (UNPLACED): i dispositivi lì sopra sono proponibili
  const unplacedLocationIds = locations
    .filter((l) => /da posizionare|unplaced/i.test(`${l.name} ${l.identifier}`))
    .map((l) => l.id)

  const plan = planPointImport(
    placemarks,
    locations.map((l) => ({ ...l, lat: l.lat ?? null, lng: l.lng ?? null })),
    devices.map((d) => ({ ...d, locationAssignedBy: d.locationAssignedBy ?? '' })),
    unplacedLocationIds,
  )

  /* ---- salva il file in area temporanea con id opaco ---- */
  const ext = lower.endsWith('.kmz') ? 'kmz' : 'kml'
  const fileId = `${randomUUID()}.${ext}`
  await cleanupStaleUploads()
  try {
    await mkdir(UPLOAD_DIR, { recursive: true })
    await writeFile(join(UPLOAD_DIR, fileId), buffer)
  } catch {
    return fail('INTERNAL', 'Impossibile salvare il file per la conferma: riprova', 500)
  }

  const data = {
    fileId,
    fileName: file.name,
    plantId,
    points: plan.points,
    created: plan.created,
    updated: plan.updated,
    noop: plan.noop,
    skipped: plan.skipped,
    unplacedDevices: plan.unplacedDevices,
    totalDevices: plan.totalDevices,
  }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KmzPreviewSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
