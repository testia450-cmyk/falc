/* ================================================================
 * /api/v2/locations/import-kmz/apply — POST (FASE 2, conferma)
 * 16.10.0 W8 · porta fedele v15 v11.16.
 *
 * Il client invia SOLO ciò che ha confermato nell'anteprima:
 *   { fileId, plantId, points: [{ placemarkIndex, action,
 *     existingLocationId, deviceIds }] }
 *
 * SICUREZZA E ONESTÀ (il client non decide nulla da solo):
 *   · il fileId è opaco: RIAPRIAMO il file temporaneo della preview
 *     e RI-PARSIAMO — nome/coordinate/descrizione vengono dal FILE,
 *     non dal payload;
 *   · existingLocationId viene riverificato (punto dell'impianto);
 *   · deviceIds vengono riverificati (perimetro: dispositivi senza
 *     punto reale dell'impianto);
 *   · un placemark può essere usato una sola volta; NOOP non riscrive.
 *
 * Le associazioni confermate diventano MANUALI
 * (locationAssignedBy '') → àncore per il motore topologico.
 * Il file KMZ/KML viene conservato in upload/kmz e registrato su
 * Plant.kmzFile (come v15). Audit LOCATION_IMPORT.
 * ================================================================ */

import { readFile, copyFile, mkdir, unlink } from 'fs/promises'
import { tmpdir } from 'os'
import { join } from 'path'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { KmzApplyInputSchema, KmzApplyResultSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { parsePointsFileFull } from '@/lib/domain/kmz-parser'
import { deriveKmzGapLinks } from '@/lib/domain/kmz-gap-links'
import { deriveIdentifier } from '@/lib/domain/point-import-plan'

export const dynamic = 'force-dynamic'

const UPLOAD_DIR = join(tmpdir(), 'falco-kmz-upload')
const KMZ_DIR = join(process.cwd(), 'upload', 'kmz')

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = KmzApplyInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const { fileId, plantId, points: confirmed } = parsed.data

  /* ---- sicurezza del fileId (niente path traversal) ---- */
  if (!/^[A-Za-z0-9._-]+$/.test(fileId) || fileId.includes('..')) {
    return fail('BAD_BODY', 'fileId non valido', 422)
  }

  const plant = await db.plant.findUnique({ where: { id: plantId } })
  if (!plant) return fail('NOT_FOUND', 'Impianto non trovato', 404)

  /* ---- riapri e ri-parsa il file della preview (verità del server) ---- */
  let fileBuffer: Buffer
  try {
    fileBuffer = await readFile(join(UPLOAD_DIR, fileId))
  } catch {
    return fail('NOT_FOUND', 'File di import non trovato: ripeti l\'anteprima (il file temporaneo scade con il server)', 404)
  }
  let placemarks: Awaited<ReturnType<typeof parsePointsFileFull>>['placemarks']
  let polylines: Awaited<ReturnType<typeof parsePointsFileFull>>['polylines']
  try {
    const full = await parsePointsFileFull(fileBuffer, fileId)
    placemarks = full.placemarks
    polylines = full.polylines
  } catch (e) {
    return fail('BAD_FILE', e instanceof Error ? e.message : 'File non più leggibile', 422)
  }

  /* ---- dati attuali dell'impianto ---- */
  const [locations, devices] = await Promise.all([
    db.location.findMany({
      where: { plantId },
      select: { id: true, identifier: true, name: true, address: true, lat: true, lng: true },
    }),
    db.device.findMany({
      where: { plantId, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
      select: { id: true, hostname: true, ip: true, type: true, locationId: true, locationAssignedBy: true },
    }),
  ])
  const locById = new Map(locations.map((l) => [l.id, l]))
  const unplacedLocationIds = new Set(
    locations.filter((l) => /da posizionare|unplaced/i.test(`${l.name} ${l.identifier}`)).map((l) => l.id),
  )
  // perimetro associabile: dispositivi SENZA punto reale dell'impianto
  const associable = new Set(
    devices.filter((d) => d.locationId == null || unplacedLocationIds.has(d.locationId)).map((d) => d.id),
  )

  /* ---- riverifica di OGNI punto confermato ---- */
  const usedPlacemarks = new Set<number>()
  const usedLocations = new Set<string>()
  let created = 0
  let updated = 0
  let assigned = 0
  let noop = 0

  const email = session.session.user.email ?? 'sconosciuto'
  const result = await db.$transaction(async (tx) => {
    const existingIdentifiers = new Set(locations.map((l) => l.identifier))

    for (const cp of confirmed) {
      const pm = placemarks[cp.placemarkIndex]
      if (!pm) {
        throw Object.assign(new Error(`placemarkIndex ${cp.placemarkIndex} fuori range`), { code: 'BAD_BODY' })
      }
      if (usedPlacemarks.has(cp.placemarkIndex)) {
        throw Object.assign(new Error('un placemark può essere confermato una sola volta'), { code: 'BAD_BODY' })
      }
      usedPlacemarks.add(cp.placemarkIndex)

      let locationId: string

      if (cp.action === 'CREATE') {
        // creazione: identifier derivato dal NOME nel FILE, univoco
        const identifier = deriveIdentifier(pm.name, existingIdentifiers)
        existingIdentifiers.add(identifier)
        const loc = await tx.location.create({
          data: {
            plantId,
            identifier,
            name: pm.name,
            address: pm.description?.slice(0, 300) ?? '',
            lat: pm.lat,
            lng: pm.lng,
          },
        })
        locationId = loc.id
        created += 1
      } else {
        // UPDATE_COORDS / NOOP: existingLocationId riverificato
        const existingId = cp.existingLocationId ?? null
        if (!existingId) {
          throw Object.assign(new Error(`punto «${pm.name}»: azione ${cp.action} richiede existingLocationId`), { code: 'BAD_BODY' })
        }
        const loc = locById.get(existingId)
        if (!loc) {
          throw Object.assign(new Error(`punto ${existingId} non trovato nell'impianto`), { code: 'BAD_BODY' })
        }
        if (usedLocations.has(existingId)) {
          throw Object.assign(new Error(`punto «${loc.name}» confermato due volte`), { code: 'BAD_BODY' })
        }
        usedLocations.add(existingId)
        locationId = existingId

        if (cp.action === 'UPDATE_COORDS') {
          // aggiorna SOLO le coordinate (il nome/indirizzo restano dell'anagrafica)
          await tx.location.update({ where: { id: existingId }, data: { lat: pm.lat, lng: pm.lng } })
          updated += 1
        } else {
          noop += 1
        }
      }

      /* ---- associazioni dispositivi confermate (àncore MANUALI) ---- */
      for (const deviceId of cp.deviceIds ?? []) {
        if (!associable.has(deviceId)) {
          const dev = devices.find((d) => d.id === deviceId)
          throw Object.assign(
            new Error(`dispositivo ${dev ? `«${dev.hostname}»` : deviceId} non è associabile: ha già un punto reale o è fuori dall'impianto`),
            { code: 'BAD_BODY' },
          )
        }
        await tx.device.update({
          where: { id: deviceId },
          data: { locationId, locationAssignedBy: '' },
        })
        assigned += 1
      }
    }

    /* ---- v16.13 W11: collegamenti dai PERCORSI KMZ ----
     * Le polilinee «Linea N» sono i percorsi reali della rete: chiudono
     * i buchi che l'Excel non copre (SSID solitari, ripetitori fuori
     * inventario), SOLO quando i dispositivi esistono già (import
     * Excel fatto prima o impianto già popolato). Regole d'onesta
     * nella lib: mai un secondo padre, mai il gateway servito. */
    const linksCreated = await deriveKmzGapLinks(tx, plantId, polylines)

    /* ---- conserva il file KMZ e registralo sull'impianto (v15) ---- */
    const storedName = `${plantId}-${fileId}`
    let plantKmzFile = plant.kmzFile
    try {
      await mkdir(KMZ_DIR, { recursive: true })
      await copyFile(join(UPLOAD_DIR, fileId), join(KMZ_DIR, storedName))
      plantKmzFile = storedName
      await tx.plant.update({ where: { id: plantId }, data: { kmzFile: storedName } })
    } catch {
      // conservazione best-effort: l'import anagrafico è già valido,
      // il file resta solo temporaneo (dichiarato in audit)
      plantKmzFile = plant.kmzFile
    }

    await tx.auditLog.create({
      data: {
        action: 'LOCATION_IMPORT',
        actor: email,
        targetId: plantId,
        targetLabel: plant.name,
        plantId,
        details: JSON.stringify({
          fileName: fileId,
          points: confirmed.length,
          created,
          updated,
          noop,
          assigned,
          kmzStored: plantKmzFile === plant.kmzFile ? false : plantKmzFile,
          linksCreated,
        }),
      },
    })

    return { plantKmzFile, linksCreated }
  }).catch((e: unknown) => {
    const code = (e as { code?: string })?.code
    if (code === 'BAD_BODY') {
      return { error: e instanceof Error ? e.message : 'Payload non valido' }
    }
    return { error: 'Errore durante l\'import: transazione annullata, nessuna riga scritta' }
  })

  if ('error' in result && result.error) {
    return fail('BAD_BODY', result.error, 422)
  }
  const applied = result as { plantKmzFile: string; linksCreated: number }

  /* ---- pulizia del file temporaneo (è stato conservato) ---- */
  try {
    await unlink(join(UPLOAD_DIR, fileId))
  } catch {
    /* best-effort: scadrà con la pulizia stale */
  }

  const data = {
    created,
    updated,
    assigned,
    noop,
    linksCreated: applied.linksCreated,
    plantKmzFile: applied.plantKmzFile ?? plant.kmzFile,
  }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(KmzApplyResultSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}
