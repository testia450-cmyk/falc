/* ================================================================
 * /api/v2/rma — GET (piano) + POST (esecuzione) — 16.9.0 W4
 * SOSTITUZIONE GUASTO (RMA) GUIDATA — port fedele da v15.12.0
 * (Fase R8, decisione 53), servizio rma-service.ts.
 * I 5 passi della decisione 53:
 *   (1) verifica d'impatto a valle PRIMA del cambio (BFS reachability);
 *   (2) portabilità guidata di credenziali CIFRATE, posizione/punto,
 *       note, gruppi;
 *   (3) genealogia: il vecchio è ANTECEDENTE del nuovo
 *       (DeviceReplacement, append-only);
 *   (4) chiusura controllata del vecchio in DISMESSO (credenziali
 *       revocate, allarmi chiusi, polling spento, cronologia INTATTA);
 *   (5) audit di ogni passo (RMA_*).
 * La sostituzione è SEMPRE umana: niente passi automatici. I
 * collegamenti confermati del vecchio passano al nuovo (l'impianto
 * fisico non è cambiato) — onestà della topologia v15.
 * GET = solo lettura (nessuna scrittura, nessun audit: convenzione v16).
 * POST (role ≥ TECNICO) esegue i passi 2-5 su comando esplicito.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { RmaQuerySchema, RmaPlanSchema, RmaExecuteInputSchema, RmaExecuteResultSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { resolvePlant, devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/* ---------------- Raggiungibilità (port compatto v15 dec. 41) -------
 * Grafo NON DIRETTO sui collegamenti ATTIVI (UP/ACTIVE/CONFIRMED/ON);
 * BFS multi-sorgente dai gateway; downstream(R) = tutti i dispositivi
 * il cui percorso verso il gateway passa per R (R escluso). */

const ACTIVE_LINK_STATUSES = new Set(['UP', 'ACTIVE', 'CONFIRMED', 'ON'])
const GATEWAY_TYPES = ['GATEWAY', 'ROUTER']

export function computeDownstream(
  nodes: Array<{ id: string; type: string }>,
  links: Array<{ sourceDeviceId: string | null; targetDeviceId: string | null; linkStatus: string }>,
): Map<string, string[]> {
  const adjacency = new Map<string, string[]>()
  const linkSeen = new Set<string>()
  for (const l of links) {
    if (!l.sourceDeviceId || !l.targetDeviceId) continue
    if (l.sourceDeviceId === l.targetDeviceId) continue
    if (!ACTIVE_LINK_STATUSES.has((l.linkStatus || '').toUpperCase())) continue
    const key = l.sourceDeviceId < l.targetDeviceId
      ? `${l.sourceDeviceId}|${l.targetDeviceId}`
      : `${l.targetDeviceId}|${l.sourceDeviceId}`
    if (linkSeen.has(key)) continue
    linkSeen.add(key)
    if (!adjacency.has(l.sourceDeviceId)) adjacency.set(l.sourceDeviceId, [])
    if (!adjacency.has(l.targetDeviceId)) adjacency.set(l.targetDeviceId, [])
    adjacency.get(l.sourceDeviceId)!.push(l.targetDeviceId)
    adjacency.get(l.targetDeviceId)!.push(l.sourceDeviceId)
  }

  /* BFS multi-sorgente dai gateway: parent = via verso il gateway.
   * downstream(R) = nodi il cui percorso verso il gateway passa per R. */
  const via = new Map<string, string | null>()
  const visited = new Set<string>()
  const queue: Array<{ id: string; parent: string | null }> = []
  for (const n of nodes) {
    if (GATEWAY_TYPES.includes(n.type)) {
      queue.push({ id: n.id, parent: null })
      visited.add(n.id)
    }
  }
  while (queue.length > 0) {
    const cur = queue.shift()!
    for (const next of adjacency.get(cur.id) ?? []) {
      if (visited.has(next)) continue
      visited.add(next)
      via.set(next, cur.id)
      queue.push({ id: next, parent: cur.id })
    }
  }

  const downstream = new Map<string, string[]>()
  for (const n of nodes) {
    const desc: string[] = []
    for (const other of nodes) {
      if (other.id === n.id) continue
      let hop: string | undefined = other.id
      const seen = new Set<string>()
      while (hop && !seen.has(hop)) {
        seen.add(hop)
        const parent = via.get(hop)
        if (parent === n.id) { desc.push(other.id); break }
        hop = parent ?? undefined
      }
    }
    downstream.set(n.id, desc)
  }
  return downstream
}

/** Prima causa OFFLINE risalendo il percorso verso il gateway (v15). */
async function findUpstreamRootCause(
  plantId: string,
  deviceId: string,
): Promise<{ id: string; hostname: string } | null> {
  const devices = await db.device.findMany({
    where: { plantId }, // v16.12 W10: scope per plantId diretto
    select: { id: true, type: true, status: true, hostname: true },
  })
  const links = await db.topologyLink.findMany({
    where: { plantId },
    select: { sourceDeviceId: true, targetDeviceId: true, linkStatus: true },
  })
  const adjacency = new Map<string, string[]>()
  const linkSeen = new Set<string>()
  for (const l of links) {
    if (!l.sourceDeviceId || !l.targetDeviceId) continue
    if (l.sourceDeviceId === l.targetDeviceId) continue
    if (!ACTIVE_LINK_STATUSES.has((l.linkStatus || '').toUpperCase())) continue
    const key = l.sourceDeviceId < l.targetDeviceId ? `${l.sourceDeviceId}|${l.targetDeviceId}` : `${l.targetDeviceId}|${l.sourceDeviceId}`
    if (linkSeen.has(key)) continue
    linkSeen.add(key)
    if (!adjacency.has(l.sourceDeviceId)) adjacency.set(l.sourceDeviceId, [])
    if (!adjacency.has(l.targetDeviceId)) adjacency.set(l.targetDeviceId, [])
    adjacency.get(l.sourceDeviceId)!.push(l.targetDeviceId)
    adjacency.get(l.targetDeviceId)!.push(l.sourceDeviceId)
  }
  const via = new Map<string, string | null>()
  const visited = new Set<string>()
  const queue: Array<{ id: string; via: string | null }> = []
  for (const n of devices) {
    if (GATEWAY_TYPES.includes(n.type)) {
      queue.push({ id: n.id, via: null })
      visited.add(n.id)
    }
  }
  while (queue.length > 0) {
    const cur = queue.shift()!
    for (const next of adjacency.get(cur.id) ?? []) {
      if (visited.has(next)) continue
      visited.add(next)
      via.set(next, cur.id)
      queue.push({ id: next, via: cur.id })
    }
  }
  // risali il percorso dispositivo → gateway
  const path: string[] = []
  let hop: string | undefined = deviceId
  const seen = new Set<string>()
  while (hop && !seen.has(hop)) {
    seen.add(hop)
    path.push(hop)
    hop = via.get(hop) ?? undefined
  }
  if (path.length < 2) return null
  for (let i = path.length - 2; i >= 0; i--) {
    const ancestorId = path[i]
    if (ancestorId === deviceId) continue
    const dev = devices.find((d) => d.id === ancestorId)
    if (dev?.status === 'OFFLINE') return { id: dev.id, hostname: dev.hostname }
  }
  return null
}

/* ---------------- GET: piano della sostituzione ---------------- */

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(RmaQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(new URL(req.url).searchParams.get('plantId') ?? undefined) // v16.12 W10: impianto ATTIVO dal selettore
  if (!plant.ok) return plant.response
  const plantId = plant.plant.id

  const device = await db.device.findFirst({
    where: { id: q.value.deviceId, plantId }, // v16.12 W10: scope per plantId diretto
    include: {
      location: { select: { id: true, identifier: true, name: true } },
      groupMemberships: { select: { id: true, groupId: true } },
    },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato in questo impianto', 404)

  /* impatto a valle (BFS reachability — mai vittime dichiarate a mano) */
  const [nodes, links] = await Promise.all([
    db.device.findMany({
      where: { plantId }, // v16.12 W10: scope per plantId diretto
      select: { id: true, type: true, status: true, hostname: true, ip: true },
    }),
    db.topologyLink.findMany({
      where: { plantId },
      select: { sourceDeviceId: true, targetDeviceId: true, linkStatus: true },
    }),
  ])
  const downstream = computeDownstream(
    nodes.map((n) => ({ id: n.id, type: n.type })),
    links,
  )
  const victimIds = downstream.get(device.id) ?? []
  const byId = new Map(nodes.map((n) => [n.id, n]))
  const victims = victimIds
    .map((id) => byId.get(id))
    .filter((v): v is { id: string; type: string; status: string; hostname: string; ip: string } => !!v)
    .map((v) => ({ id: v.id, hostname: v.hostname, ip: v.ip, type: v.type, status: v.status }))

  const upstream = await findUpstreamRootCause(plantId, device.id)

  const confirmedLinks = await db.topologyLink.count({
    where: {
      plantId,
      OR: [{ sourceDeviceId: device.id }, { targetDeviceId: device.id }],
      linkStatus: { in: ['ACTIVE', 'UP'] },
    },
  })

  const genealogyRows = await db.deviceReplacement.findMany({
    where: { plantId, oldDeviceId: device.id },
    orderBy: { createdAt: 'desc' },
    take: 10,
    select: { oldDeviceId: true, newDeviceId: true, createdAt: true },
  })

  const credentials: string[] = []
  if (device.username) credentials.push('username')
  if (device.password) credentials.push('password (cifrata AES-256-GCM)')
  if (device.snmpCommunityEnc) credentials.push('snmpCommunity (cifrata AES-256-GCM)')
  if (device.snmpAuthKey) credentials.push('snmpV3 auth key (cifrata)')
  if (device.snmpPrivKey) credentials.push('snmpV3 priv key (cifrata)')

  const warnings: string[] = []
  if (upstream && upstream.id !== device.id) {
    warnings.push(`guasto probabile a MONTE (${upstream.hostname}): sostituire quest'apparato potrebbe non risolvere il guasto`)
  }
  if (victims.length > 0) {
    warnings.push(`${victims.length} dispositivi a valle dipendono da questo apparato: pianificare la finestra di manutenzione`)
  }
  if (device.decommissionedAt) {
    warnings.push('dispositivo già DISMESSO: la sostituzione parte da un apparato attivo')
  }

  const data = {
    deviceId: device.id,
    hostname: device.hostname,
    plantId,
    impact: {
      downstreamVictims: victims.length,
      victims: victims.slice(0, 50),
    },
    portable: {
      credentials,
      locationId: device.locationId,
      pointIdentifier: device.location?.identifier ?? null,
      notes: !!device.notes,
      groupIds: device.groupMemberships.map((g) => g.groupId),
      confirmedLinks,
    },
    genealogy: genealogyRows.map((g) => ({
      oldDeviceId: g.oldDeviceId, newDeviceId: g.newDeviceId, at: g.createdAt.getTime(),
    })),
    warnings,
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(RmaPlanSchema, { ok: true as const, asOf: Date.now(), mode, data })
  return ok(data, Date.now(), mode)
}

/* ---------------- POST: esecuzione guidata (passi 2-5) ---------------- */

const CIPHER_CREDENTIAL_FIELDS = [
  'password', // AES-256-GCM application-level
  'snmpCommunityEnc', // AES-256-GCM (R4)
  'snmpAuthKey', 'snmpPrivKey', // AES-256-GCM application-level
] as const

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = RmaExecuteInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const plant = await resolvePlant(new URL(req.url).searchParams.get('plantId') ?? undefined) // v16.12 W10: impianto ATTIVO dal selettore
  if (!plant.ok) return plant.response
  const plantId = plant.plant.id
  const email = session.session.user.email ?? 'sconosciuto'

  const old = await db.device.findFirst({
    where: { id: input.oldDeviceId, plantId }, // v16.12 W10: scope per plantId diretto
    include: { groupMemberships: { select: { groupId: true } } },
  })
  if (!old) {
    return fail('NOT_FOUND', 'Dispositivo da sostituire non trovato nell\'impianto', 404)
  }
  if (old.decommissionedAt) {
    return fail('INVALID_STATE', 'Il dispositivo è già DISMESSO: la sostituzione deve partire da un apparato attivo', 422)
  }
  const reason = input.reason || 'sostituzione guasto'

  /* --- SNAPSHOT in memoria (dopo la dismissione i campi cifrati sono revocati) --- */
  const cipherSnapshot: Record<string, string> = {}
  for (const f of CIPHER_CREDENTIAL_FIELDS) {
    const v = (old as unknown as Record<string, string | null>)[f]
    if (v) cipherSnapshot[f] = v
  }
  const plainSnapshot = {
    username: old.username,
    snmpCommunity: old.snmpCommunity, // LEGACY v15.8: se non ancora cifrata, si copia dichiarandolo
    snmpVersion: old.snmpVersion,
    snmpV3Username: old.snmpV3Username,
    snmpSecurityLevel: old.snmpSecurityLevel,
    sshPort: old.sshPort,
    credentialState: old.credentialState,
    credentialReason: old.credentialReason,
  }
  const locationSnapshot = old.locationId
  const groupSnapshot = old.groupMemberships.map((g) => g.groupId)

  const steps: Array<{ step: string; ok: boolean; detail: string }> = []
  const push = (step: string, ok: boolean, detail: string) => { steps.push({ step, ok, detail }) }

  const now = new Date()
  const created = await db.$transaction(async (tx) => {
    /* --- passo 4 (anticipato per liberare l'IP): dismissione CONTROLLATA --- */
    await tx.device.update({
      where: { id: old.id },
      data: {
        status: 'DECOMMISSIONED',
        decommissionedAt: now,
        decommissionReason: `RMA: sostituzione guidata — ${reason}`,
        username: '', password: '', snmpCommunity: '', snmpCommunityEnc: '',
        snmpAuthKey: '', snmpPrivKey: '', snmpV3Username: '',
      },
    })
    await tx.alertEvent.updateMany({
      where: { deviceId: old.id, status: { in: ['OPEN', 'ACK', 'ESCALATED', 'SUPPRESSED'] } },
      data: { status: 'CLOSED', closedAt: now },
    })
    await tx.pollingSchedule.updateMany({ where: { deviceId: old.id }, data: { enabled: false } })
    push('dismissione controllata del vecchio', true, `${old.hostname} → DECOMMISSIONED, credenziali revocate, allarmi chiusi, polling spento, cronologia INTATTA`)
    await tx.auditLog.create({
      data: {
        action: 'RMA_OLD_DECOMMISSIONED', actor: email, targetId: old.id,
        targetLabel: old.hostname, plantId,
        details: JSON.stringify({ motivo: reason }),
      },
    })

    /* --- passo 2: nuovo dispositivo nello STESSO punto (stesso impianto,
     *         proprietà diretta v16.12 W10) --- */
    const dev = await tx.device.create({
      data: {
        plantId, // v16.12 W10: il sostituto appartiene allo stesso impianto
        hostname: input.replacement.hostname,
        ip: input.replacement.ip,
        type: input.replacement.type,
        brand: input.replacement.brand ?? '',
        model: input.replacement.model ?? '',
        macAddress: input.replacement.macAddress ?? '',
        port: input.replacement.port ?? 80,
        connectionType: input.replacement.connectionType ?? old.connectionType,
        locationId: locationSnapshot,
        notes: `RMA: sostituisce ${old.hostname} (${old.id}) il ${now.toISOString()}. ${reason}`.trim(),
        // finestra di assestamento: anti falsi allarmi post-sostituzione (v10.30)
        baselineUntil: new Date(now.getTime() + 24 * 60 * 60 * 1000),
        // credenziali CIFRATE copiate TALI QUALI (chiave master fuori dal DB)
        ...plainSnapshot,
        ...cipherSnapshot,
      },
    })
    push('creazione nuovo dispositivo', true, `creato ${dev.hostname} (${dev.id}) nello stesso punto`)
    await tx.auditLog.create({
      data: {
        action: 'RMA_DEVICE_CREATED', actor: email, targetId: dev.id,
        targetLabel: dev.hostname, plantId,
        details: JSON.stringify({ sostituisce: old.id, punto: locationSnapshot, campiCifrati: Object.keys(cipherSnapshot) }),
      },
    })

    /* --- passo 2c: gruppi --- */
    for (const groupId of groupSnapshot) {
      await tx.deviceGroupMember.create({ data: { deviceId: dev.id, groupId } })
    }
    push('portabilità gruppi', true, `${groupSnapshot.length} gruppi riassegnati`)

    /* --- passo 3: genealogia (vecchio → nuovo, append-only) --- */
    const replacement = await tx.deviceReplacement.create({
      data: {
        plantId,
        oldDeviceId: old.id,
        newDeviceId: dev.id,
        reason,
        createdBy: email,
        steps: '[]', // riempito sotto, fuori dalla tx per chiarezza v15
      },
    })
    push('genealogia', true, `DeviceReplacement ${replacement.id}: ${old.id} → ${dev.id}`)
    await tx.auditLog.create({
      data: {
        action: 'RMA_GENEALOGY_LINKED', actor: email, targetId: replacement.id,
        targetLabel: `${old.hostname} → ${dev.hostname}`, plantId,
        details: JSON.stringify({ old: old.id, nuovo: dev.id }),
      },
    })

    /* --- topologia: i collegamenti del vecchio passano al nuovo --- */
    const movedLinks = await tx.topologyLink.count({
      where: { plantId, OR: [{ sourceDeviceId: old.id }, { targetDeviceId: old.id }] },
    })
    await tx.topologyLink.updateMany({ where: { plantId, sourceDeviceId: old.id }, data: { sourceDeviceId: dev.id } })
    await tx.topologyLink.updateMany({ where: { plantId, targetDeviceId: old.id }, data: { targetDeviceId: dev.id } })
    push('portabilità topologia', true, `${movedLinks} collegamenti portati al nuovo (stesso impianto fisico)`)
    await tx.auditLog.create({
      data: {
        action: 'RMA_TOPOLOGY_PORTED', actor: email, targetId: dev.id,
        targetLabel: dev.hostname, plantId,
        details: JSON.stringify({ collegamenti: movedLinks }),
      },
    })

    /* motivo di dismissione con riferimento esplicito al nuovo */
    await tx.device.update({
      where: { id: old.id },
      data: { decommissionReason: `RMA: sostituito da ${dev.id} (${dev.hostname}) — ${reason}` },
    })

    return dev
  })

  const data = { newDeviceId: created.id, steps }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(RmaExecuteResultSchema, { ok: true as const, asOf: now.getTime(), mode, data })
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
