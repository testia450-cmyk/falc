/* ================================================================
 * /api/v2/cve/import — POST — 16.9.0 W4
 * Importazione catalogo (role ≥ RESPONSABILE_COMUNE come v15):
 *  · { demo: true } → le 12 voci dimostrative v15 (pubbliche,
 *    semplificate — NON un feed NVD, dichiarato in UI);
 *  · { entries: [...] } → voci custom (regex CVE-YYYY-NNNN+,
 *    severity/cvss/patterns validati dal contratto zod).
 * Upsert per cveId (update title/descrizione/severità/riferimento;
 * pattern sostituiti a cascata e ricreati). Audit CVE_IMPORT con
 * conteggi ed errori per voce.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import { CveImportInputSchema, CveImportResultSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { DEMO_CVE_CATALOG } from '@/lib/v2/cve-engine'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'RESPONSABILE_COMUNE')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo RESPONSABILE_COMUNE o superiore', 403)
  }

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = CveImportInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }

  const email = session.session.user.email ?? 'sconosciuto'

  const entries = parsed.data.demo === true
    ? DEMO_CVE_CATALOG.map((e) => ({
      cveId: e.cveId,
      title: e.title,
      description: 'Voce del catalogo dimostrativo v15 (pubblica, semplificata per test e demo — NON un feed NVD completo).',
      severity: e.severity,
      cvss: e.cvss,
      publishedAt: undefined,
      reference: '',
      patterns: e.patterns,
    }))
    : parsed.data.entries ?? []

  let imported = 0
  const errors: string[] = []
  for (const e of entries) {
    try {
      await db.cveEntry.upsert({
        where: { cveId: e.cveId },
        update: {
          title: e.title, description: e.description,
          severity: e.severity, cvss: e.cvss, reference: e.reference,
          ...(e.publishedAt ? { publishedAt: new Date(e.publishedAt) } : {}),
          patterns: {
            deleteMany: {},
            create: e.patterns.map((p) => ({
              vendorPattern: p.vendorPattern, modelPattern: p.modelPattern,
              firmwareMin: p.firmwareMin, firmwareMax: p.firmwareMax,
            })),
          },
        },
        create: {
          cveId: e.cveId, title: e.title, description: e.description,
          severity: e.severity, cvss: e.cvss, reference: e.reference,
          ...(e.publishedAt ? { publishedAt: new Date(e.publishedAt) } : {}),
          patterns: {
            create: e.patterns.map((p) => ({
              vendorPattern: p.vendorPattern, modelPattern: p.modelPattern,
              firmwareMin: p.firmwareMin, firmwareMax: p.firmwareMax,
            })),
          },
        },
      })
      imported++
    } catch (err) {
      errors.push(`${e.cveId}: ${err instanceof Error ? err.message : String(err)}`)
    }
  }

  await db.auditLog.create({
    data: {
      action: 'CVE_IMPORT',
      actor: email,
      targetId: null,
      targetLabel: `import: ${imported} voci`,
      details: JSON.stringify({
        imported, errors: errors.length,
        demo: parsed.data.demo === true, totale: entries.length,
      }),
    },
  })

  const now = new Date()
  const data = { imported, errors }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CveImportResultSchema, { ok: true as const, asOf: now.getTime(), mode, data })
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
