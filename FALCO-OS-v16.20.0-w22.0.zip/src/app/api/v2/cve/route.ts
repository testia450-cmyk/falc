/* ================================================================
 * /api/v2/cve — GET (catalogo) — 16.9.0 W4
 * Catalogo CveEntry REALE dal DB (include patterns), ordinamento
 * severità/cveId come v15, take 500. Nel DB reale: 0 righe →
 * entries: [] + demoCatalogAvailable: 12 (il catalogo dimostrativo
 * v15 è importabile da POST /api/v2/cve/import { demo: true }).
 * ONESTÀ: il catalogo NON è un feed NVD — è ciò che l'operatore ha
 * importato (o il dimostrativo pubblico v15).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession } from '@/lib/v2/api-helpers'
import { CveCatalogSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { DEMO_CVE_CATALOG } from '@/lib/v2/cve-engine'

export const dynamic = 'force-dynamic'

const SEVERITY_ORDER: Record<string, number> = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 }

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const entries = await db.cveEntry.findMany({
    include: { patterns: true },
    orderBy: [{ severity: 'asc' }, { cveId: 'asc' }],
    take: 500,
  })
  // severità 'asc' alfabetico non è gravità: riordino dichiarato per rank
  entries.sort((a, b) => {
    const ra = SEVERITY_ORDER[a.severity] ?? 0
    const rb = SEVERITY_ORDER[b.severity] ?? 0
    if (ra !== rb) return rb - ra // CRITICAL prima
    return a.cveId < b.cveId ? -1 : 1
  })

  const data = {
    entries: entries.map((e) => ({
      id: e.id,
      cveId: e.cveId,
      title: e.title,
      description: e.description,
      severity: e.severity,
      cvss: e.cvss,
      reference: e.reference,
      publishedAt: e.publishedAt ? e.publishedAt.getTime() : null,
      patterns: e.patterns.slice(0, 20).map((p) => ({
        vendorPattern: p.vendorPattern,
        modelPattern: p.modelPattern,
        firmwareMin: p.firmwareMin,
        firmwareMax: p.firmwareMax,
      })),
    })),
    total: entries.length,
    demoCatalogAvailable: DEMO_CVE_CATALOG.length,
  }

  const asOf = maxOf(...entries.map((e) => e.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CveCatalogSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
