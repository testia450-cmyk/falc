/* ================================================================
 * /api/v2/cve/scan — POST — 16.9.0 W4
 * Esegue la scan CVE REALE dell'inventario (role ≥ RESPONSABILE_COMUNE
 * come v15): dispositivi attivi (non dismessi) × catalogo CveEntry →
 * upsert CveFinding (preserva IGNORED/RESOLVED = decisioni umane),
 * auto-resolve delle OPEN il cui match è scomparso.
 * Con catalogo vuoto: scanned=N, findings=0 — NESSUNA riga scritta
 * (no-op onesto). Il matching è PURO sui dati REALI (brand/model/
 * firmware): senza firmware noto non si afferma nulla.
 * Audit CVE_SCAN_RUN con riepilogo + primi errori.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import { CveScanReportSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'
import { scanAllCves } from '@/lib/v2/cve-engine'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'RESPONSABILE_COMUNE')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo RESPONSABILE_COMUNE o superiore', 403)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const report = await scanAllCves()

  await db.auditLog.create({
    data: {
      action: 'CVE_SCAN_RUN',
      actor: email,
      targetId: null,
      targetLabel: `scan: ${report.scanned} dispositivi, ${report.findings} finding`,
      details: JSON.stringify({
        scanned: report.scanned, findings: report.findings,
        new: report.newFindings, autoResolved: report.autoResolved,
        summary: report.summary, errors: report.errors.slice(0, 5),
      }),
    },
  })

  const now = new Date()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CveScanReportSchema, { ok: true as const, asOf: now.getTime(), mode, data: report })
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data: report }, { status: 201 })
}
