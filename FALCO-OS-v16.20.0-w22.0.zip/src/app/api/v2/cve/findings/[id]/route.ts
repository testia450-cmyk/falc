/* ================================================================
 * /api/v2/cve/findings/[id] — PATCH — 16.9.0 W4
 * Stato della finding: OPEN | IGNORED | RESOLVED (role ≥
 * RESPONSABILE_COMUNE come v15). lastSeenAt aggiornata; audit
 * CVE_FINDING_UPDATE con transizione from→to e nota. 404 se la
 * finding non esiste.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import { CveFindingPatchSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'RESPONSABILE_COMUNE')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo RESPONSABILE_COMUNE o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.cveFinding.findUnique({
    where: { id },
    include: { cveEntry: { select: { cveId: true } } },
  })
  if (!existing) return fail('NOT_FOUND', 'Finding non trovata', 404)

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422)
  }
  const parsed = CveFindingPatchSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  const updated = await db.$transaction(async (tx) => {
    const f = await tx.cveFinding.update({
      where: { id },
      data: { status: parsed.data.status, lastSeenAt: now },
    })
    await tx.auditLog.create({
      data: {
        action: 'CVE_FINDING_UPDATE',
        actor: email,
        targetId: id,
        targetLabel: `${existing.cveEntry.cveId} @ ${existing.deviceId}`,
        details: JSON.stringify({
          from: existing.status, to: parsed.data.status,
          note: parsed.data.note ?? '',
        }),
      },
    })
    return f
  })

  const replay = await getReplayState()
  const mode = apiMode(replay)
  return NextResponse.json({
    ok: true as const, asOf: now.getTime(), mode,
    data: { id: updated.id, status: updated.status, lastSeenAt: updated.lastSeenAt.getTime() },
  })
}
