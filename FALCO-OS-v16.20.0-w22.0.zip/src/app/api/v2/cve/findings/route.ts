/* ================================================================
 * /api/v2/cve/findings — GET — 16.9.0 W4
 * Finding REali (join device + entry), filtro status opzionale,
 * ranking per gravità desc (rankFindings v15), take 500.
 * Counts OPEN/IGNORED/RESOLVED sempre GLOBALI (non filtrati) per
 * la striscia KPI. Nel DB reale: 0 finding (nessuna scan mai
 * eseguita) → findings: [] + counts a zero, onesto.
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { CveFindingsQuerySchema, CveFindingsPageSchema } from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { rankFindings } from '@/lib/v2/cve-engine'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(CveFindingsQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const [rows, countsAll] = await Promise.all([
    db.cveFinding.findMany({
      where: q.value.status ? { status: q.value.status } : undefined,
      include: {
        device: { select: { hostname: true, ip: true, brand: true, model: true, firmwareVersion: true } },
        cveEntry: { select: { cveId: true, title: true, severity: true, cvss: true, reference: true } },
      },
      orderBy: { firstSeenAt: 'desc' },
      take: 500,
    }),
    db.cveFinding.groupBy({ by: ['status'], _count: { _all: true } }),
  ])

  const countsMap = new Map(countsAll.map((c) => [c.status, c._count._all]))
  const counts = {
    OPEN: countsMap.get('OPEN') ?? 0,
    IGNORED: countsMap.get('IGNORED') ?? 0,
    RESOLVED: countsMap.get('RESOLVED') ?? 0,
  }

  const findings = rankFindings(rows.map((r) => ({
    id: r.id,
    deviceId: r.deviceId,
    hostname: r.device.hostname,
    ip: r.device.ip,
    brand: r.device.brand,
    model: r.device.model,
    firmwareVersion: r.device.firmwareVersion,
    cveId: r.cveEntry.cveId,
    title: r.cveEntry.title,
    severity: r.cveEntry.severity,
    cvss: r.cveEntry.cvss,
    reference: r.cveEntry.reference,
    status: r.status,
    firstSeenAt: r.firstSeenAt.getTime(),
    lastSeenAt: r.lastSeenAt.getTime(),
    firmwareAtFind: r.firmwareAtFind,
  })))

  const data = { findings, counts }
  const asOf = maxOf(...rows.map((r) => r.lastSeenAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CveFindingsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
