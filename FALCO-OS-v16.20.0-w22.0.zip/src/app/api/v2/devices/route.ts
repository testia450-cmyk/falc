/* ================================================================
 * /api/v2/devices — GET
 * Domanda a cui risponde (§6.1): «Quali dispositivi ho nell'impianto,
 * in che stato sono, e come li filtro/ordino?»
 * Inventario paginato con filtri (famiglia/tipo/stato/testo) e
 * ordinamento. 200 dispositivi: filtro/paginazione IN MEMORIA sopra
 * loadDeviceRows (scelta deliberata: semplice e comunque O(200)).
 * Ordinamenti documentati:
 *  · signal/lastSeen: valori mancanti sempre IN CODA (mai inventati);
 *  · status: asc = dal migliore al peggiore (gerarchia UI_WORST_ORDER
 *    in shared.ts, documentata una volta sola), desc = peggiori prima.
 * Nessun campo credenziale selezionato (allowlist DEVICE_COLUMNS).
 * ================================================================ */

import { ok, requireSession, parseQuery, csv } from '@/lib/v2/api-helpers'
import { DevicesQuerySchema, DevicesPageSchema } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import type { DeviceRow } from '@/lib/v2/contracts'
import { resolvePlant, devValidate, FAMILY_TYPES, uiWorstRank } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(DevicesQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const { rows, asOf } = await loadDeviceRows(p.id)

  /* --- Filtri in memoria --- */
  const typeFilter = csv(q.value.type)
  const statusFilter = csv(q.value.status)
  const needle = q.value.q?.toLowerCase() ?? ''
  const familyTypes = q.value.family && q.value.family !== 'all' ? FAMILY_TYPES[q.value.family] : null

  const filtered = rows.filter((r) => {
    // v16.17 W18: sede esatta (pannello mappa). Le righe senza sede
    // (host scoperti non adottati) restano fuori: nessun congedio.
    if (q.value.locationId && r.locationId !== q.value.locationId) return false
    if (familyTypes && !familyTypes.includes(r.type)) return false
    if (typeFilter.length && !typeFilter.includes(r.type)) return false
    if (statusFilter.length && !statusFilter.includes(r.uiStatus)) return false
    if (needle) {
      const hay = [r.hostname, r.ip, r.macAddress, r.model, r.brand, r.locationName ?? '']
        .join('\n').toLowerCase()
      if (!hay.includes(needle)) return false
    }
    return true
  })

  /* --- Ordinamento (nulls sempre in coda per signal/lastSeen) --- */
  const dir = q.value.dir
  const cmpNullable = (va: number | null, vb: number | null): number => {
    if (va === null && vb === null) return 0
    if (va === null) return 1
    if (vb === null) return -1
    return dir === 'asc' ? va - vb : vb - va
  }
  const cmpStr = (va: string, vb: string): number => {
    const c = va.localeCompare(vb, 'it')
    return dir === 'asc' ? c : -c
  }
  const cmpNum = (va: number, vb: number): number => (dir === 'asc' ? va - vb : vb - va)

  const sortKey = q.value.sort
  const sorted = [...filtered].sort((a: DeviceRow, b: DeviceRow) => {
    let c = 0
    switch (sortKey) {
      case 'ip':
        c = cmpStr(a.ip, b.ip)
        break
      case 'type':
        c = cmpStr(a.type, b.type)
        break
      case 'status':
        // asc = migliori prima (ONLINE in testa); desc = peggiori prima
        c = dir === 'asc' ? uiWorstRank(b.uiStatus) - uiWorstRank(a.uiStatus) : uiWorstRank(a.uiStatus) - uiWorstRank(b.uiStatus)
        break
      case 'signal':
        c = cmpNullable(a.signalPresent ? a.signalStrength : null, b.signalPresent ? b.signalStrength : null)
        break
      case 'lastSeen':
        c = cmpNullable(a.lastSeenAt, b.lastSeenAt)
        break
      case 'uptime':
        c = cmpNum(a.uptimeSeconds, b.uptimeSeconds)
        break
      default:
        c = cmpStr(a.hostname, b.hostname)
    }
    if (c !== 0) return c
    return a.hostname.localeCompare(b.hostname, 'it') // tie-break stabile
  })

  /* --- Paginazione --- */
  const page = q.value.page
  const pageSize = q.value.pageSize
  const total = sorted.length
  const pageCount = Math.max(1, Math.ceil(total / pageSize))
  const items = sorted.slice((page - 1) * pageSize, page * pageSize)

  const mode = apiMode(replay)
  const data = { items, total, page, pageSize, pageCount }
  const body = { ok: true as const, asOf, mode, data }
  devValidate(DevicesPageSchema, body)
  return ok(data, asOf, mode)
}
