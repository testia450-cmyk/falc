/* ================================================================
 * /api/v2/devices/[id]/overview — GET
 * Domanda a cui risponde (§6.1): «Cosa c'è dietro questo apparato:
 * percorso verso il gateway, causa radice a monte, impatto a valle,
 * metriche chiave, link, eventi e allarmi aperti?»
 * Semantica (port rca-engine / topology-reachability, nessuna doppia
 * logica in UI — §6.2):
 *  · parentChain: dal DISPOSITIVO al GATEWAY (reverse del pathToGateway
 *    BFS, che parte dal gateway); include il dispositivo stesso in testa;
 *    vuoto se il dispositivo non è raggiungibile;
 *  · rootCause: risalendo dal dispositivo verso il gateway (escluso il
 *    dispositivo stesso, port findUpstreamRootCause) il PRIMO antenato
 *    con dbStatus OFFLINE; null se non esiste (anche se il dispositivo
 *    stesso è la radice);
 *  · impact: discendenti nel grafo di raggiungibilità (link ATTIVI);
 *  · keyMetrics: ultimo campione REALE per metrica (SQL finestra) —
 *    metriche assenti semplicemente non compaiono;
 *  · series: bucket 30 minuti su 24h con GROUP BY (nessun punto
 *    inventato: senza dati → array vuoto);
 *  · per CAMERA/LPR: stato flusso (cameraStreamAlive/cameraRtt);
 *    per AP: stazioni figlie dirette; per STA: AP di uplink.
 * Nessun campo credenziale selezionato.
 * ================================================================ */

import { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { DeviceOverviewSchema, SNMP_ENABLE_STATES } from '@/lib/v2/contracts'
import { loadDeviceRows, getCameraStreamMap, getReplayState, apiMode } from '@/lib/v2/derive'
import {
  resolvePlant, getPlantLinks, buildPlantReachability,
  devValidate, VIDEO_TYPES, maxOf,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const KEY_METRICS = [
  'pingLatency', 'packetLoss', 'cpuLoad', 'memoryUsage', 'temperature',
  'cameraRtt', 'signalStrength', 'linkQuality',
] as const
const SERIES_WINDOW_H = 24

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const { id } = await ctx.params

  const url = new URL(req.url)
  const plantIdParam = url.searchParams.get('plantId') ?? undefined

  const plant = await resolvePlant(plantIdParam)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const { rows, byId, now } = await loadDeviceRows(p.id)
  const device = byId.get(id)
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)

  /* --- v16.18 W19: dettaglio attivazione SNMP (metodo/nota/tentativo)
   *      — letto dal record RAW perché la DeviceRow porta solo i due
   *      campi-badge (stato + modalità). Nessun segreto qui: la nota è
   *      l'ultimo esito LEGGIBILE (max 500), il metodo l'id ricetta. --- */
  const actRow = await db.device.findUnique({
    where: { id },
    select: { snmpEnableState: true, snmpEnableMethod: true, snmpEnableNote: true, snmpEnableAt: true },
  })
  const snmpActivation = {
    state: (actRow?.snmpEnableState ?? device.snmpEnableState) as (typeof SNMP_ENABLE_STATES)[number],
    method: actRow?.snmpEnableMethod ?? '',
    note: actRow?.snmpEnableNote ?? '',
    at: actRow?.snmpEnableAt ? actRow.snmpEnableAt.getTime() : null,
  }

  const links = await getPlantLinks(p.id)
  const reach = buildPlantReachability(rows, links)

  /* --- Percorso del problema: dal dispositivo al gateway --- */
  const path = reach.pathToGateway.get(id) ?? [] // [gateway, …, dispositivo]
  const chainIds = [...path].reverse() // [dispositivo, …, gateway]
  const parentChain = chainIds
    .map((cid) => byId.get(cid))
    .filter((r): r is NonNullable<typeof r> => !!r)
    .map((r) => ({ id: r.id, hostname: r.hostname, ip: r.ip, type: r.type, uiStatus: r.uiStatus }))

  /* --- Causa radice a monte (port findUpstreamRootCause) --- */
  let rootCause: { id: string; hostname: string; ip: string } | null = null
  for (let i = 1; i < chainIds.length; i++) { // salta il dispositivo stesso
    const anc = byId.get(chainIds[i])
    if (anc && anc.dbStatus === 'OFFLINE') {
      rootCause = { id: anc.id, hostname: anc.hostname, ip: anc.ip }
      break
    }
  }

  /* --- Impatto a valle (grafo link ATTIVI) --- */
  const downstream = reach.downstream.get(id) ?? []
  const camerasDownstream = downstream.filter((did) => {
    const r = byId.get(did)
    return !!r && VIDEO_TYPES.includes(r.type)
  }).length
  const offlineDownstream = downstream.filter((did) => byId.get(did)?.dbStatus === 'OFFLINE').length

  /* --- Metriche chiave: ultimo campione reale per metrica --- */
  const keyMetricsRows = await db.$queryRaw<Array<{ metric: string; value: number; unit: string; timestamp: Date }>>`
    SELECT metric, value, unit, timestamp FROM (
      SELECT metric, value, unit, timestamp,
             ROW_NUMBER() OVER (PARTITION BY metric ORDER BY timestamp DESC) AS rn
      FROM MetricValue
      WHERE deviceId = ${id} AND metric IN (${Prisma.join([...KEY_METRICS])})
    ) WHERE rn = 1`
  const keyMetrics = keyMetricsRows.map((m) => ({
    metric: m.metric,
    value: m.value,
    unit: m.unit || null,
    timestamp: m.timestamp.getTime(),
  }))

  /* --- Stato flusso (solo apparati video) --- */
  let camera: { streamAlive: boolean | null; lastStreamCheck: number | null; rttMs: number | null } | null = null
  if (device.type === 'CAMERA' || device.type === 'LPR') {
    const camMap = await getCameraStreamMap(p.id)
    const entry = camMap.byDevice.get(id)
    // entry.at > 0 ⇔ cameraStreamAlive davvero campionato (altrimenti null)
    camera = {
      streamAlive: entry && entry.at > 0 ? entry.alive : null,
      lastStreamCheck: entry && entry.at > 0 ? entry.at : null,
      rttMs: entry?.rttMs ?? null,
    }
  }

  /* --- Stazioni agganciate (per AP: figli diretti nel grafo attivo) --- */
  const stations = device.type === 'AP'
    ? (reach.children.get(id) ?? [])
        .map((kid) => byId.get(kid))
        .filter((k): k is NonNullable<typeof k> => !!k)
        .map((k) => ({
          id: k.id,
          hostname: k.hostname,
          signalStrength: k.signalPresent ? k.signalStrength : null,
          linkQuality: k.linkQuality,
          uiStatus: k.uiStatus,
        }))
    : []

  /* --- AP di uplink (per STA) --- */
  let uplinkAp: { id: string; hostname: string; signalStrength: number | null } | null = null
  if (device.type === 'STA') {
    const idx = path.lastIndexOf(id)
    let uplinkRow = idx >= 1 ? byId.get(path[idx - 1]) : undefined
    if (!uplinkRow) {
      // fallback: parentId persistito sul dispositivo (se il grafo non copre)
      const rec = await db.device.findUnique({ where: { id }, select: { parentId: true } })
      uplinkRow = rec?.parentId ? byId.get(rec.parentId) : undefined
    }
    if (uplinkRow) {
      uplinkAp = {
        id: uplinkRow.id,
        hostname: uplinkRow.hostname,
        signalStrength: device.signalPresent ? device.signalStrength : null,
      }
    }
  }

  /* --- Collegamenti del dispositivo (source = upstream, semantica repo) --- */
  const deviceLinks = links
    .filter((l) => l.sourceDeviceId === id || l.targetDeviceId === id)
    .map((l) => {
      const isSource = l.sourceDeviceId === id
      const peerId = isSource ? l.targetDeviceId : l.sourceDeviceId
      const peerRow = peerId ? byId.get(peerId) : undefined
      return {
        id: l.id,
        peerId,
        peerHostname: peerRow?.hostname ?? (isSource ? l.targetLabel : l.sourceLabel) ?? '',
        linkType: l.linkType,
        linkStatus: l.linkStatus,
        confidence: l.confidence || '',
        evidence: l.evidence || '',
        speedMbps: l.speedMbps ?? 0,
        trafficInMbps: l.trafficInMbps ?? 0,
        trafficOutMbps: l.trafficOutMbps ?? 0,
        trafficUpdatedAt: l.trafficUpdatedAt ? l.trafficUpdatedAt.getTime() : null,
        direction: isSource ? ('downstream' as const) : ('upstream' as const),
      }
    })

  /* --- Eventi recenti e allarmi aperti --- */
  const [recentEvents, openAlerts] = await Promise.all([
    db.deviceEvent.findMany({
      where: { deviceId: id },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    db.alertEvent.findMany({
      where: { deviceId: id, status: { not: 'CLOSED' } },
      orderBy: { openedAt: 'desc' },
      take: 10,
    }),
  ])

  /* --- Serie 24h (bucket 30 min, GROUP BY: nessun punto inventato) --- */
  const seriesMetrics = ['pingLatency', 'packetLoss']
  if (device.type === 'AP' || device.type === 'STA') seriesMetrics.push('signalStrength', 'linkQuality')
  if (device.type === 'CAMERA' || device.type === 'LPR') seriesMetrics.push('cameraRtt')
  const sinceMs = now.getTime() - SERIES_WINDOW_H * 3600 * 1000
  // bucket: divisione INTERA su letterali SQL (timestamp è INTEGER ms) →
  // bucket multipli di 30 min esatti, GROUP BY stabile
  const seriesRows = await db.$queryRaw<Array<{ metric: string; bucket: number; v: number }>>`
    SELECT metric, (timestamp / 1800000) * 1800000 AS bucket, AVG(value) AS v
    FROM MetricValue
    WHERE deviceId = ${id} AND metric IN (${Prisma.join(seriesMetrics)}) AND timestamp >= ${sinceMs}
    GROUP BY metric, bucket
    ORDER BY bucket ASC`
  const seriesMap = new Map<string, Array<{ t: number; v: number }>>()
  for (const row of seriesRows) {
    const arr = seriesMap.get(row.metric) ?? []
    arr.push({ t: Number(row.bucket), v: Math.round(row.v * 100) / 100 })
    seriesMap.set(row.metric, arr)
  }
  const series = seriesMetrics
    .filter((m) => seriesMap.has(m))
    .map((m) => ({ metric: m, points: seriesMap.get(m) ?? [] }))

  const asOf = maxOf(
    device.lastSeenAt,
    keyMetrics.length ? Math.max(...keyMetrics.map((m) => m.timestamp)) : null,
    camera?.lastStreamCheck ?? null,
    recentEvents[0]?.createdAt.getTime() ?? null,
    openAlerts[0]?.openedAt.getTime() ?? null,
    series.length ? Math.max(...series.map((s) => (s.points.length ? s.points[s.points.length - 1].t : 0))) : null,
    deviceLinks.length ? Math.max(...deviceLinks.map((l) => l.trafficUpdatedAt ?? 0)) : null,
  ) || now.getTime()

  const data = {
    identity: device,
    snmpActivation,
    parentChain,
    rootCause,
    impact: {
      devicesDownstream: downstream.length,
      camerasDownstream,
      offlineDownstream,
    },
    keyMetrics,
    camera,
    stations,
    uplinkAp,
    links: deviceLinks,
    recentEvents: recentEvents.map((e) => ({
      id: e.id,
      eventType: e.eventType,
      oldValue: e.oldValue ?? '',
      newValue: e.newValue ?? '',
      source: e.source ?? '',
      createdAt: e.createdAt.getTime(),
    })),
    openAlerts: openAlerts.map((a) => ({
      id: a.id,
      severity: a.severity,
      message: a.message,
      openedAt: a.openedAt.getTime(),
      occurrenceCount: a.occurrenceCount,
      status: a.status,
    })),
    series,
  }

  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(DeviceOverviewSchema, body)
  return ok(data, asOf, mode)
}
