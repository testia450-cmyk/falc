/* ================================================================
 * /api/v2/devices/[id]/ports — GET (16.5.0, W3-proroga — parità v15 G3)
 * Tabella «cosa c'è su ogni porta» per lo switch corrente, costruita
 * SOLO da quattro fonti REALI del DB (union: nessuna porta inventata):
 *   1. TopologyLink (sia lato source che target) → collegato a
 *      (hostname/IP/type dell'altro capo), evidenza/confidenza della
 *      ricostruzione, speedMbps/duplex — dati del LINK (velocità
 *      negoziata STORICA, NON lettura live);
 *   2. FdbObservation → MAC visti per porta + elenco (max 20/porta,
 *      ultima osservazione prima) con risoluzione verso l'inventario;
 *   3. serie MetricValue «port_utilization:<nomePorta>» → ultimo
 *      campione per porta + copertura REALE della serie (dichiarata,
 *      come nel report disponibilità);
 *   4. StpObservation (v16.15): stato/designato per porta come letto
 *      dalla sonda L2 — decora le porte già note (fonti 1-3), NON ne
 *      aggiunge: tabella vuota → stp null (l'UI non mostra nulla).
 * Risoluzione MAC→inventario: Device.macAddress + Device.extraMacs
 * (JSON array) normalizzati (minuscole, senza separatori); non
 * risolto → null (UI: «non in inventario»). NESSUN database OUI
 * (decisione D20): il produttore del MAC non è esposto.
 * UPLINK: peer del link di tipo INFRA secondo INFRA_TYPES di
 * src/lib/domain/tiers.ts — la STESSA classificazione usata da
 * shared.ts (buildPlantTiers) per l'albero unico: GATEWAY, ROUTER,
 * FIREWALL, SWITCH, AP, BRIDGE, REPEATER. Le STA restano escluse
 * (endpoint di rete, non trasporto): differenza DICHIARATA rispetto
 * a v15 (che includeva STA nei tipi di uplink).
 * Onestà: se l'apparato non ha NESSUNA delle tre fonti (es. non è
 * uno switch, o non ha stato letto) → ports=[] + summary a zero
 * (l'UI mostra l'empty state: «porte disponibili solo sugli switch
 * con dati FDB/topologia»). Lo stato live della porta, la velocità
 * CORRENTE e il PoE richiedono SNMP (modalità riproduzione: fuori
 * replay — dichiarato in UI).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { DevicePortsSchema, PORT_MACS_SHOWN, type DevicePortRow, type PortMacEntry } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate, maxOf } from '@/app/api/v2/shared'
import { INFRA_TYPES } from '@/lib/domain/tiers'

export const dynamic = 'force-dynamic'

/** Normalizza un MAC per il confronto: minuscole, solo caratteri hex
 * (il DB reale FDB è già «f8ce07585136», l'inventario «04:F4:1C:5E:C7:6E»). */
function normMac(raw: string): string {
  return (raw || '').toLowerCase().replace(/[^0-9a-f]/g, '')
}

/** Forma AA:BB:CC:DD:EE:FF per la UI; se il raw non è 12 hex, esce grezzo (onestà). */
function displayMac(raw: string): string {
  const n = normMac(raw)
  if (n.length !== 12) return raw || ''
  return (n.match(/.{2}/g) ?? []).join(':').toUpperCase()
}

interface ResolvedDevice { id: string; hostname: string; type: string }

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const { id } = await ctx.params

  const url = new URL(req.url)
  const plantIdParam = url.searchParams.get('plantId') ?? undefined

  const plant = await resolvePlant(plantIdParam)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const { byId, now } = await loadDeviceRows(p.id)
  const device = byId.get(id)
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)

  /* --- 1. Inventario del plant (stesso scope di /devices) per la
   *        risoluzione MAC→dispositivo: MAC primario + extraMacs,
   *        primo vincente (stesso spirito di v15 T8: le interfacce
   *        multiple censite in extraMacs devono risolvere). --- */
  const inventory = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null }, // v16.12 W10: scope per plantId diretto
    select: { id: true, hostname: true, type: true, macAddress: true, extraMacs: true },
  })
  const macToDev = new Map<string, ResolvedDevice>()
  for (const d of inventory) {
    const k = normMac(d.macAddress)
    if (k && !macToDev.has(k)) macToDev.set(k, { id: d.id, hostname: d.hostname, type: d.type })
    try {
      const v: unknown = JSON.parse(d.extraMacs || '[]')
      if (Array.isArray(v)) {
        for (const ex of v) {
          if (typeof ex !== 'string') continue
          const ek = normMac(ex)
          if (ek && !macToDev.has(ek)) macToDev.set(ek, { id: d.id, hostname: d.hostname, type: d.type })
        }
      }
    } catch { /* extraMacs non JSON: ignorato (dato storico corrotto non rompe la lettura) */ }
  }

  /* --- 2. Collegamenti dello switch (source E target): per ogni porta
   *        il link «migliore» — rank: confermati prima, poi confidenza
   *        (HIGH/MEDIUM/LOW/'' come vocabolario del dominio), poi
   *        evidenza (LLDP/CDP/MNDP > FDB* > altro), poi peer INFRA
   *        (più significativo come uplink), stabile per id. --- */
  const links = await db.topologyLink.findMany({
    where: { OR: [{ sourceDeviceId: id }, { targetDeviceId: id }] },
    select: {
      id: true, sourceDeviceId: true, sourcePort: true, targetDeviceId: true, targetPort: true,
      speedMbps: true, duplex: true, linkStatus: true, confidence: true, evidence: true,
      confirmed: true, trafficUpdatedAt: true,
      sourceDevice: { select: { id: true, hostname: true, type: true, ip: true } },
      targetDevice: { select: { id: true, hostname: true, type: true, ip: true } },
    },
  })
  const CONF_RANK: Record<string, number> = { HIGH: 0, MEDIUM: 1, LOW: 2, '': 3 }
  const EV_RANK: Record<string, number> = {
    LLDP: 0, CDP: 0, MNDP: 0, TECHNICIAN: 0,
    FDB_PAIR: 1, FDB_MUTUAL: 1, FDB_ENDPOINT: 1, UISP: 1, PORT_MAP: 1, SNMP_L2: 1,
  }
  interface PortLink {
    id: string
    port: string
    peer: { id: string; hostname: string; type: string; ip: string | null } | null
    speedMbps: number
    duplex: string
    confidence: string
    evidence: string
    trafficUpdatedAt: Date | null
    rank: number
  }
  const portLinks: PortLink[] = links
    .map((l): PortLink | null => {
      const isSource = l.sourceDeviceId === id
      const port = (isSource ? l.sourcePort : l.targetPort) || ''
      const peerRaw = isSource ? l.targetDevice : l.sourceDevice
      if (!port || !peerRaw) return null
      const conf = l.confidence || ''
      const ev = l.evidence || ''
      const peerInfra = INFRA_TYPES.has((peerRaw.type || '').toUpperCase())
      const rank =
        (l.confirmed ? 0 : 10) +
        (CONF_RANK[conf] ?? 3) * 10 +
        (EV_RANK[ev] ?? 2) * 100 +
        (peerInfra ? 0 : 1000)
      return {
        id: l.id, port,
        peer: { id: peerRaw.id, hostname: peerRaw.hostname, type: peerRaw.type, ip: peerRaw.ip ?? null },
        speedMbps: l.speedMbps ?? 0,
        duplex: l.duplex || '',
        confidence: conf,
        evidence: ev,
        trafficUpdatedAt: l.trafficUpdatedAt,
        rank,
      }
    })
    .filter((l): l is PortLink => l !== null)
  const bestLinkByPort = new Map<string, PortLink>()
  for (const pl of portLinks) {
    const cur = bestLinkByPort.get(pl.port)
    if (!cur || pl.rank < cur.rank) bestLinkByPort.set(pl.port, pl)
  }

  /* --- 3. FDB per porta (ultima osservazione prima). --- */
  const fdbRows = await db.fdbObservation.findMany({
    where: { deviceId: id },
    select: { mac: true, portName: true, lastSeenAt: true },
    orderBy: { lastSeenAt: 'desc' },
  })
  const fdbByPort = new Map<string, Array<{ mac: string; lastSeenAt: Date }>>()
  for (const f of fdbRows) {
    const arr = fdbByPort.get(f.portName) ?? []
    arr.push({ mac: f.mac, lastSeenAt: f.lastSeenAt })
    fdbByPort.set(f.portName, arr)
  }

  /* --- 3bis. STP per porta (v16.15 W13): stato/designato/root dalla
   *        sonda L2 (StpObservation, BRIDGE-MIB dot1dStp). Join per
   *        portName: più righe sullo STESSO nome (portNum diversi
   *        risolti sullo stesso ifName) → vince la più recente. --- */
  const stpRows = await db.stpObservation.findMany({
    where: { deviceId: id },
    select: { portName: true, portState: true, designatedBridgeMac: true, isRootPort: true },
    orderBy: { lastSeenAt: 'desc' },
  })
  const stpByPort = new Map<string, { portState: string; designatedBridgeMac: string; isRootPort: boolean }>()
  for (const s of stpRows) {
    if (!s.portName || stpByPort.has(s.portName)) continue
    stpByPort.set(s.portName, {
      portState: s.portState,
      designatedBridgeMac: s.designatedBridgeMac,
      isRootPort: s.isRootPort,
    })
  }

  /* --- 4. Utilizzazione per porta dalla serie REALE
   *        port_utilization:<nomePorta> (ultimo campione per porta +
   *        copertura della serie: la findMany ordinata dà l'ultimo
   *        valore per metrica; l'aggregato dà la copertura reale). --- */
  const utilSamples = await db.metricValue.findMany({
    where: { deviceId: id, metric: { startsWith: 'port_utilization:' } },
    select: { metric: true, value: true, timestamp: true },
    orderBy: { timestamp: 'desc' },
  })
  const utilLastByMetric = new Map<string, { last: number; at: number }>()
  for (const s of utilSamples) {
    if (!utilLastByMetric.has(s.metric)) {
      utilLastByMetric.set(s.metric, { last: s.value, at: s.timestamp.getTime() })
    }
  }
  const utilAgg = utilSamples.length
    ? await db.metricValue.aggregate({
        _min: { timestamp: true },
        _max: { timestamp: true },
        where: { deviceId: id, metric: { startsWith: 'port_utilization:' } },
      })
    : null
  const utilCoverage = utilAgg?._min.timestamp && utilAgg._max.timestamp
    ? { from: utilAgg._min.timestamp.getTime(), to: utilAgg._max.timestamp.getTime() }
    : null

  /* --- 5. UNION delle porte reali delle tre fonti di riga (nessuna
   *        porta inventata; l'STP del punto 3bis decora, non aggiunge). --- */
  const portNames = new Set<string>()
  for (const pl of portLinks) portNames.add(pl.port)
  for (const port of fdbByPort.keys()) portNames.add(port)
  for (const metric of utilLastByMetric.keys()) {
    const portName = metric.slice('port_utilization:'.length)
    if (portName) portNames.add(portName)
  }

  let resolvedCount = 0
  let unattachedMacs = 0
  let fdbLastSeenAt: number | null = null
  for (const f of fdbRows) {
    const t = f.lastSeenAt.getTime()
    if (fdbLastSeenAt == null || t > fdbLastSeenAt) fdbLastSeenAt = t
    if (macToDev.has(normMac(f.mac))) resolvedCount += 1
    if (!bestLinkByPort.has(f.portName)) unattachedMacs += 1
  }

  const ports: DevicePortRow[] = []
  for (const portName of portNames) {
    const link = bestLinkByPort.get(portName) ?? null
    const observed = fdbByPort.get(portName) ?? []
    const macs: PortMacEntry[] = observed.slice(0, PORT_MACS_SHOWN).map((m) => {
      const dev = macToDev.get(normMac(m.mac))
      return {
        mac: m.mac,
        display: displayMac(m.mac),
        resolved: !!dev,
        hostname: dev?.hostname ?? null,
        deviceId: dev?.id ?? null,
        deviceType: dev?.type ?? null,
        lastSeenAt: m.lastSeenAt.getTime(),
      }
    })
    const util = utilLastByMetric.get(`port_utilization:${portName}`) ?? null
    const peer = link?.peer ?? null
    ports.push({
      portName,
      macsSeen: observed.length,
      connectedTo: peer
        ? { deviceId: peer.id, hostname: peer.hostname, type: peer.type, ip: peer.ip }
        : null,
      evidence: link?.evidence || null,
      confidence: link?.confidence || null,
      speedMbps: link?.speedMbps ?? 0,
      duplex: link?.duplex ?? '',
      utilization: util ? { last: util.last, at: util.at } : null,
      // uplink = peer INFRA secondo la classificazione dei tier (vedi header):
      // nessun collegamento noto → MAI uplink (nessuna deduzione dai MAC).
      uplink: !!peer && INFRA_TYPES.has((peer.type || '').toUpperCase()),
      // v16.15 W13: dichiarazione STP della porta se la sonda L2 l'ha letta
      // (null = mai letta: l'UI non mostra nulla — l'assenza non è un errore).
      stp: stpByPort.get(portName) ?? null,
      macs,
    })
  }
  ports.sort((a, b) => {
    if (a.uplink !== b.uplink) return a.uplink ? -1 : 1
    if (a.macsSeen !== b.macsSeen) return b.macsSeen - a.macsSeen
    return a.portName.localeCompare(b.portName, 'it')
  })

  const summary = {
    totalPorts: portNames.size,
    portsWithMacs: ports.filter((r) => r.macsSeen > 0).length,
    macsTotal: fdbRows.length,
    resolvedCount,
    unattachedMacs,
    windowDeclared: { fdbLastSeenAt, utilCoverage },
  }

  const asOf = maxOf(
    device.lastSeenAt,
    fdbLastSeenAt,
    utilCoverage?.to ?? null,
    ...portLinks.map((l) => (l.trafficUpdatedAt ? l.trafficUpdatedAt.getTime() : null)),
  ) || now.getTime()

  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data: { ports, summary } }
  devValidate(DevicePortsSchema, body)
  return ok({ ports, summary }, asOf, mode)
}
