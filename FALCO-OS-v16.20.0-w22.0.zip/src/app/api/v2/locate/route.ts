/* ================================================================
 * /api/v2/locate — GET (v16.18 W20 — «dove è collegato?»)
 * ================================================================
 * Domanda a cui risponde: «Questa telecamera / questo IP / questo MAC
 * — su quale switch e su quale porta è collegato?»
 *
 * Percorso di risoluzione (OGNI passo dichiarato in `resolution`):
 *   · query MAC (AA:BB:… o aabbcc…) → MAC normalizzato;
 *   · query IP → tabella ARP del plant (ArpEntry, ultima vista) → MAC;
 *   · query hostname → inventario dispositivi → MAC primario;
 *   · MAC → FDB (FdbObservation: dove lo switch ha IMPARATO il MAC,
 *     con porta e ultima volta visto);
 *   · dispositivo risolto → link di topologia (uplink dichiarato).
 *
 * ONESTÀ COSTITUZIONALE:
 *   · la FDB dice dove il MAC è stato appreso: se il dispositivo sta
 *     dietro un bridge intermedio (switch a valle), la porta indicata
 *     è quella dell'UPLINK — viene detto nelle note;
 *   · nessun avvistamento = «la sonda Layer-2 non ha ancora imparato
 *     questo MAC», NON un errore;
 *   · lettura pura: nessuna scrittura, nessun dato inventato.
 * RBAC: utente autenticato (lettura).
 * ================================================================ */

import { db } from '@/lib/db'
import { ok, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import { LocateQuerySchema, LocateResultSchema } from '@/lib/v2/contracts'
import { loadDeviceRows, getReplayState, apiMode } from '@/lib/v2/derive'
import { resolvePlant, devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Normalizza un MAC per il confronto (minuscole, solo hex). */
function normMac(raw: string): string {
  return (raw || '').toLowerCase().replace(/[^0-9a-f]/g, '')
}

/** Forma AA:BB:CC:DD:EE:FF (display); raw se non normalizzabile. */
function displayMac(raw: string): string {
  const n = normMac(raw)
  if (n.length !== 12) return raw || ''
  return (n.match(/.{2}/g) ?? []).join(':').toUpperCase()
}

const IPV4_RE = /^(\d{1,3}\.){3}\d{1,3}$/

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(LocateQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const replay = await getReplayState()
  const { rows, byId } = await loadDeviceRows(p.id)

  const query = q.value.q.trim()
  const resolution: string[] = []
  const notes: string[] = [
    'La FDB dichiara su quale porta lo switch ha IMPARATO il MAC: se il dispositivo sta dietro un bridge intermedio (es. switch a valle), la porta indicata è quella dell\'uplink verso quel bridge.',
  ]

  /* --- inventario MAC→dispositivo (primario + extraMacs) --- */
  const macToDev = new Map<string, string>()
  for (const r of rows) {
    const k = normMac(r.macAddress)
    if (k && !macToDev.has(k)) macToDev.set(k, r.id)
  }
  // extraMacs: letti solo per i dispositivi (secondo passo, stesso plant)
  const rawDevices = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: { id: true, extraMacs: true },
  })
  for (const d of rawDevices) {
    try {
      const v: unknown = JSON.parse(d.extraMacs || '[]')
      if (Array.isArray(v)) {
        for (const ex of v) {
          if (typeof ex !== 'string') continue
          const k = normMac(ex)
          if (k && !macToDev.has(k)) macToDev.set(k, d.id)
        }
      }
    } catch { /* extraMacs non JSON: ignorato */ }
  }

  /* --- (1) risoluzione query → MAC --- */
  let resolvedMac: string | null = null
  let resolvedIp: string | null = null
  let deviceId: string | null = null

  const queryNorm = normMac(query)
  if (queryNorm.length === 12) {
    resolvedMac = queryNorm
    resolution.push(`Query riconosciuta come MAC → ${displayMac(queryNorm)}.`)
  } else if (IPV4_RE.test(query)) {
    resolvedIp = query
    resolution.push(`Query riconosciuta come IPv4 → tabella ARP del plant.`)
    const arp = await db.arpEntry.findFirst({
      where: { plantId: p.id, ip: query },
      orderBy: { lastSeen: 'desc' },
      select: { mac: true, ip: true, lastSeen: true },
    })
    if (arp) {
      resolvedMac = normMac(arp.mac) || null
      resolution.push(`ARP: ${arp.ip} → ${displayMac(arp.mac)} (ultima vista ${arp.lastSeen.toISOString()}).`)
    } else {
      resolution.push('ARP: nessuna voce per questo IP (la sonda L2 non l\'ha ancora appresa).')
    }
  } else {
    // hostname (case-insensitive, contains)
    const needle = query.toLowerCase()
    const match = rows.find((r) => r.hostname.toLowerCase().includes(needle))
    if (match) {
      deviceId = match.id
      resolvedMac = normMac(match.macAddress) || null
      resolvedIp = match.ip
      resolution.push(`Query riconosciuta come hostname → ${match.hostname} (MAC ${match.macAddress || 'n.d.'}).`)
    }
  }

  /* --- (2) MAC → dispositivo dell'inventario --- */
  if (resolvedMac && !deviceId) {
    deviceId = macToDev.get(resolvedMac) ?? null
    if (deviceId) resolution.push(`MAC risolto nell'inventario dispositivi.`)
  }
  const deviceRow = deviceId ? byId.get(deviceId) ?? null : null
  if (deviceRow && !resolvedIp) resolvedIp = deviceRow.ip

  /* --- (3) MAC → avvistamenti FDB (switch + porta) --- */
  const sightings: Array<{
    switchId: string; switchHostname: string; switchType: string
    portName: string; lastSeenAt: number; speedMbps: number | null; duplex: 'full' | 'half' | null
  }> = []
  if (resolvedMac) {
    // il DB reale mescola le forme «aabb…» e «AA:BB:…»: si cercano ENTRAMBE
    const variants = [resolvedMac, displayMac(resolvedMac)]
    const fdb = await db.fdbObservation.findMany({
      where: { plantId: p.id, mac: { in: variants } },
      select: {
        deviceId: true, portName: true, lastSeenAt: true,
        device: { select: { hostname: true, type: true } },
      },
      orderBy: { lastSeenAt: 'desc' },
      take: 200,
    })
    // velocità/duplex del link verso la porta (se il link esiste)
    const linkBySwitch = new Map<string, { speedMbps: number | null; duplex: 'full' | 'half' | null }>()
    if (deviceRow) {
      const links = await db.topologyLink.findMany({
        where: {
          plantId: p.id,
          OR: [
            { sourceDeviceId: deviceRow.id },
            { targetDeviceId: deviceRow.id },
          ],
        },
        select: { sourceDeviceId: true, targetDeviceId: true, speedMbps: true, duplex: true },
      })
      for (const l of links) {
        const other = l.sourceDeviceId === deviceRow.id ? l.targetDeviceId : l.sourceDeviceId
        if (other == null) continue
        if (!linkBySwitch.has(other)) {
          linkBySwitch.set(other, { speedMbps: l.speedMbps > 0 ? l.speedMbps : null, duplex: l.duplex === 'full' || l.duplex === 'half' ? l.duplex : null })
        }
      }
    }
    const seen = new Set<string>()
    for (const f of fdb) {
      const key = `${f.deviceId}|${f.portName}`
      if (seen.has(key)) continue
      seen.add(key)
      const link = linkBySwitch.get(f.deviceId)
      sightings.push({
        switchId: f.deviceId,
        switchHostname: f.device?.hostname || f.deviceId,
        switchType: f.device?.type || '',
        portName: f.portName,
        lastSeenAt: f.lastSeenAt.getTime(),
        speedMbps: link?.speedMbps ?? null,
        duplex: link?.duplex ?? null,
      })
    }
    if (sightings.length === 0) {
      notes.push('Nessun avvistamento FDB per questo MAC: la sonda Layer-2 degli switch non l\'ha ancora imparato (o il dispositivo è collegato wireless/dietro un NAT).')
    }
  } else if (!deviceId) {
    notes.push('Query non risolvibile a MAC né a dispositivo: prova con l\'indirizzo IP, il MAC completo o l\'hostname esatto.')
  }

  /* --- (4) link di topologia del dispositivo --- */
  const links: Array<{
    id: string; sourceHostname: string; targetHostname: string
    sourcePort: string; targetPort: string
    sourceOfTruth: string; confidence: string
    speedMbps: number; duplex: 'full' | 'half' | null
  }> = []
  if (deviceRow) {
    const rowsLinks = await db.topologyLink.findMany({
      where: {
        plantId: p.id,
        OR: [{ sourceDeviceId: deviceRow.id }, { targetDeviceId: deviceRow.id }],
      },
      select: {
        id: true, sourceDeviceId: true, targetDeviceId: true,
        sourcePort: true, targetPort: true, sourceOfTruth: true,
        confidence: true, speedMbps: true, duplex: true,
      },
      orderBy: { updatedAt: 'desc' },
      take: 12,
    })
    for (const l of rowsLinks) {
      const source = byId.get(l.sourceDeviceId ?? '')
      const target = byId.get(l.targetDeviceId ?? '')
      links.push({
        id: l.id,
        sourceHostname: source?.hostname ?? l.sourceDeviceId ?? 'rimosso',
        targetHostname: target?.hostname ?? l.targetDeviceId ?? 'rimosso',
        sourcePort: l.sourcePort,
        targetPort: l.targetPort,
        sourceOfTruth: l.sourceOfTruth,
        confidence: l.confidence,
        speedMbps: l.speedMbps,
        duplex: l.duplex === 'full' || l.duplex === 'half' ? l.duplex : null,
      })
    }
  }

  const data = {
    query,
    resolvedMac: resolvedMac ? displayMac(resolvedMac) : null,
    resolvedIp,
    device: deviceRow ? {
      id: deviceRow.id,
      hostname: deviceRow.hostname,
      ip: deviceRow.ip,
      type: deviceRow.type,
      uiStatus: deviceRow.uiStatus,
      macAddress: deviceRow.macAddress,
      locationName: deviceRow.locationName,
    } : null,
    resolution,
    sightings,
    links,
    notes,
  }

  const asOf = Date.now()
  const mode = apiMode(replay)
  const body = { ok: true as const, asOf, mode, data }
  devValidate(LocateResultSchema, body)
  return ok(data, asOf, mode)
}
