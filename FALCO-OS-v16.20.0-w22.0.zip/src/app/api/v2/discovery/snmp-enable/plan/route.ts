/* ================================================================
 * /api/v2/discovery/snmp-enable/plan — POST (v16.18 W19)
 * ================================================================
 * La PREVIEW dell'attivazione SNMP assistita: per un dispositivo
 * dell'inventario sceglie la RICETTA per-vendor (marca/modello/tipo
 * DICHIARATI — o l'override umano) e la restituisce con i comandi
 * INTERPOLATI. Ciò che la finestra mostra PRIMA della conferma.
 *
 * REGOLE:
 *   · NESSUNA scrittura su DB, NESSUN contatto con l'apparato:
 *     questa rotta è una lettura del catalogo (il servizio :3002
 *     risponde in pochi ms, pick purissimo);
 *   · il pick parte DALL'EVIDENZA dell'inventario (brand/model/type
 *     del dispositivo): se il modello non è dichiarato, la ricetta
 *     generica «manuale» è la risposta onesta;
 *   · le credenziali NON vengono mai mostrate: solo la PRESENZA di
 *     username+password cifrate (l'operatore sa che può riusarle) e
 *     lo username (non è un segreto);
 *   · RBAC: TECNICO+ (la preview mostra i comandi che verranno
 *     eseguiti — CLIENTE in sola lettura non li riguarda).
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { SnmpEnablePlanInputSchema, SnmpEnablePlanResultSchema } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo un tecnico può pianificare l\'attivazione SNMP', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = SnmpEnablePlanInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri della pianificazione non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const device = await db.device.findUnique({
    where: { id: input.deviceId },
    select: {
      id: true, hostname: true, ip: true, type: true, brand: true, model: true,
      snmpPort: true, snmpEnableState: true, monitorMode: true,
      plantId: true, decommissionedAt: true,
      username: true, password: true, sshPort: true,
    },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)
  if (device.decommissionedAt) {
    return fail('DECOMMISSIONED', 'Dispositivo dismesso: le credenziali sono revocate e l\'attivazione non ha senso (usa il flusso RMA)', 422)
  }

  const community = input.community ?? 'public'
  const contact = input.contact ?? 'FALCO-OS'
  const location = input.location ?? ''

  const pr = await discoveryPost('/actuate/recipe-plan', {
    brand: device.brand,
    model: device.model,
    type: device.type,
    ...(input.recipeId ? { recipeId: input.recipeId } : {}),
    community,
    contact,
    location,
  })
  if (!pr.ok) return proxyFail(pr)

  const wrapped = pr.body as {
    result?: {
      picked: string
      pingOnly: boolean
      alternatives: Array<{ recipeId: string; label: string; transport: string }>
      recipe: {
        recipeId: string
        vendor: string
        family: string
        transport: 'ssh' | 'http-swos' | 'manual' | 'ping-only'
        confidence: 'verified' | 'high' | 'medium'
        source: string
        note: string
        webPath: string | null
        steps: Array<{ cmd: string; note: string | null; fatal: boolean; benign: string | null }>
        manualSteps: string[]
      }
    }
  }
  const r = wrapped.result
  if (!r || !r.recipe) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza la ricetta attesa' } } })
  }

  const data = {
    device: {
      id: device.id,
      hostname: device.hostname,
      ip: device.ip,
      type: device.type,
      brand: device.brand,
      model: device.model,
      snmpPort: device.snmpPort,
      snmpEnableState: device.snmpEnableState as '' | 'ENABLED' | 'ENABLED_UNVERIFIED' | 'FAILED' | 'MANUAL_REQUIRED',
      monitorMode: device.monitorMode as 'full' | 'ping',
      /* Presenza di credenziali CIFRATE: username+password non vuoti.
       * La password non viene MAI mostrata (regola v16: nessun segreto
       * nel contratto API) — solo il fatto che esistono, così
       * l'operatore sa che può usarle senza riscriverle. */
      hasSavedCredentials: device.username !== '' && device.password !== '',
      savedUsername: device.username,
    },
    picked: r.picked,
    pingOnly: r.pingOnly,
    recipe: r.recipe,
    alternatives: r.alternatives,
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SnmpEnablePlanResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
