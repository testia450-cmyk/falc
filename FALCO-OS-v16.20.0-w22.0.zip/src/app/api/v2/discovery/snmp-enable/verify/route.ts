/* ================================================================
 * /api/v2/discovery/snmp-enable/verify — POST (v16.18 W19)
 * ================================================================
 * Riverifica post-attivazione: dopo un ENABLED_UNVERIFIED (l'agente
 * SNMP può impiegare secondi a partire dopo l'applicazione dei
 * comandi) o dopo l'attivazione MANUALE dal pannello web, la sonda
 * read-only prova di nuovo le community del dispositivo.
 *
 * REGOLE:
 *   · community provate: quella CIFRATA del device + public (dedup,
 *     max 8) — la stessa lista che userebbe una scansione;
 *   · la verifica RIUSCITA promuove lo stato a ENABLED (e se la
 *     community trovata non era cifrata sul device, la salva);
 *   · la verifica FALLITA NON retrocede MAI uno stato: i comandi
 *     applicati restano applicati (onestà: la sonda che non risponde
 *     dice «non risponde», non «non è stato attivato»);
 *   · audit DEVICE_SNMP_VERIFY con la sintesi;
 *   · RBAC: TECNICO+.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { decryptSecret, encryptSecret } from '@/lib/crypto'
import { z } from 'zod'
import { SnmpVerifyResultSchema, type SnmpVerifyResult } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

const BodySchema = z.object({ deviceId: z.string().min(1) })

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo un tecnico può rilanciare la verifica SNMP', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = BodySchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'deviceId richiesto', 422)
  }

  const device = await db.device.findUnique({
    where: { id: parsed.data.deviceId },
    select: {
      id: true, hostname: true, ip: true, plantId: true, decommissionedAt: true,
      snmpPort: true, snmpCommunityEnc: true, snmpEnableState: true,
    },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)
  if (device.decommissionedAt) {
    return fail('DECOMMISSIONED', 'Dispositivo dismesso: verifiche impossibili (credenziali revocate)', 422)
  }

  const stored = device.snmpCommunityEnc !== '' ? decryptSecret(device.snmpCommunityEnc) : null
  const communities = Array.from(new Set([...(stored ? [stored] : []), 'public'])).slice(0, 8)

  const pr = await discoveryPost('/probe/snmp', {
    ip: device.ip,
    port: device.snmpPort,
    version: 'v2c',
    communities,
    timeoutMs: 2500,
  })
  if (!pr.ok) return proxyFail(pr)

  const probe = (pr.body as { result?: {
    reachable: boolean
    matched?: { community: string } | null
    sysName?: string | null
    sysDescr?: string | null
    error?: string | null
  } }).result
  if (!probe) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza l\'esito della sonda' } } })
  }

  let newState = device.snmpEnableState as '' | 'ENABLED' | 'ENABLED_UNVERIFIED' | 'FAILED' | 'MANUAL_REQUIRED'
  if (probe.reachable) {
    newState = 'ENABLED'
    /* Se la community che ha risposto non era cifrata sul device, la
     * salviamo (le sonde future la useranno per prime). */
    const matched = probe.matched?.community
    if (matched && matched !== stored) {
      const enc = encryptSecret(matched)
      if (enc) await db.device.update({ where: { id: device.id }, data: { snmpCommunityEnc: enc } })
    }
    await db.device.update({
      where: { id: device.id },
      data: {
        snmpEnableState: 'ENABLED',
        snmpEnableNote: `Verificato: sonda SNMP raggiungibile${probe.sysName ? ` (sysName "${probe.sysName}")` : ''}`.slice(0, 500),
        snmpEnableAt: new Date(),
      },
    })
  }

  await db.auditLog.create({
    data: {
      action: 'DEVICE_SNMP_VERIFY',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: device.id,
      targetLabel: `${device.hostname} (${device.ip})`,
      details: JSON.stringify({
        reachable: probe.reachable,
        sysName: probe.sysName ?? null,
        stateBefore: device.snmpEnableState,
        stateAfter: newState,
        communitiesTried: communities.length,
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const data: SnmpVerifyResult = {
    deviceId: device.id,
    reachable: probe.reachable,
    matchedCommunity: probe.matched?.community ?? null,
    sysName: probe.sysName ?? null,
    sysDescr: probe.sysDescr ?? null,
    error: probe.error ?? null,
    snmpEnableState: newState,
  }
  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SnmpVerifyResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
