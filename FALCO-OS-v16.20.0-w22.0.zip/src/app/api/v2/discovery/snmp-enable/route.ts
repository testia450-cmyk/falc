/* ================================================================
 * /api/v2/discovery/snmp-enable — POST (v16.18 W19)
 * ================================================================
 * ESEGUI l'attivazione SNMP assistita su UN dispositivo, dopo la
 * conferma umana esplicita (la finestra ha mostrato i comandi in
 * chiaro — preview /plan — e l'operatore ha premuto «Esegui»).
 *
 * TRE percorsi, per trasporto della ricetta:
 *   · ssh / http-swos → CONTATTO REALE con l'apparato (SSH o API
 *     HTTP digest del pannello SwOS): il mini-service :3002 esegue
 *     i comandi e verifica con la SONDA SNMP (read-only). Stato
 *     persistito: ENABLED / ENABLED_UNVERIFIED / FAILED.
 *   · ping-only (telecamere) → DICHIARAZIONE: monitorMode='ping'
 *     sul Device, NESSUN pacchetto verso l'apparato.
 *   · manual (Hikvision/Dahua/PLANET/UniFi/…) → DICHIARAZIONE:
 *     snmpEnableState='MANUAL_REQUIRED' con le istruzioni mostrate
 *     in UI — nessuna scrittura tentata alla cieca.
 *
 * REGOLE D'ORO:
 *   · la SONDA resta read-only (mai SET SNMP): qui parla l'ATTUATORE,
 *     separato, su conferma umana;
 *   · credenziali SSH: quelle della FINESTRA (non persistite) OPPURE
 *     quelle CIFRATE del dispositivo (decifrate SOLO qui, mai in
 *     risposta); la community di lettura, se ENABLED, viene salvata
 *     CIFRATA (AES-256-GCM) per le sonde future;
 *   · audit DEVICE_SNMP_ENABLE: la SINTESI (ricetta, trasporto,
 *     stato, passi ok, sysName della verifica) — MAI password, MAI
 *     community in chiaro nel registro;
 *   · RBAC: TECNICO+.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { decryptSecret, encryptSecret } from '@/lib/crypto'
import { SnmpEnableInputSchema, SnmpEnableResultSchema, type SnmpEnableResult } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Nota leggibile persistita sul Device: ultimo esito (max 500). */
function readableNote(notes: string[]): string {
  return notes.join(' · ').slice(0, 500)
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo un tecnico può eseguire l\'attivazione SNMP', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = SnmpEnableInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Dichiarazione di attivazione non valida', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const device = await db.device.findUnique({
    where: { id: input.deviceId },
    select: {
      id: true, hostname: true, ip: true, type: true, brand: true, model: true,
      plantId: true, decommissionedAt: true,
      snmpPort: true, snmpCommunityEnc: true,
      username: true, password: true, sshPort: true, port: true,
      snmpEnableState: true, monitorMode: true,
    },
  })
  if (!device) return fail('NOT_FOUND', 'Dispositivo non trovato', 404)
  if (device.decommissionedAt) {
    return fail('DECOMMISSIONED', 'Dispositivo dismesso: credenziali revocate, attivazione impossibile (usa il flusso RMA)', 422)
  }

  /* --- 1) Metadati della ricetta (pick puro del servizio): serve
   *        il TRASPORTO per decidere il percorso PRIMA di toccare
   *        qualunque apparato. --- */
  const planPr = await discoveryPost('/actuate/recipe-plan', {
    brand: device.brand,
    model: device.model,
    type: device.type,
    recipeId: input.recipeId,
    community: input.community,
    contact: input.contact,
    location: input.location,
  })
  if (!planPr.ok) return proxyFail(planPr)
  const plan = (planPr.body as { result?: { recipe?: { transport: 'ssh' | 'http-swos' | 'manual' | 'ping-only'; note: string } } }).result?.recipe
  if (!plan) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza la ricetta attesa' } } })
  }

  const now = new Date()
  const replay = await getReplayState()

  /* --- 2a) Telecamera → DICHIARAZIONE ping-only (nessun contatto) --- */
  if (plan.transport === 'ping-only') {
    await db.device.update({
      where: { id: device.id },
      data: { monitorMode: 'ping' },
    })
    await db.auditLog.create({
      data: {
        action: 'DEVICE_SNMP_ENABLE',
        actor: session.session.user.email ?? 'sconosciuto',
        targetId: device.id,
        targetLabel: `${device.hostname} (${device.ip})`,
        details: JSON.stringify({
          recipeId: input.recipeId,
          transport: 'ping-only',
          declaration: 'monitorMode=ping',
          contact: 'NONE — telecamera: monitoraggio presenza ICMP, nessun pacchetto inviato',
        }),
      },
    }).catch(() => { /* audit best-effort, l'azione è già fatta */ })

    const data: SnmpEnableResult = {
      recipeId: input.recipeId,
      transport: 'ping-only',
      applied: false,
      steps: [],
      verify: { reachable: false, matchedCommunity: null, sysName: null, sysDescr: null, error: null },
      state: '',
      notes: [
        'Telecamera: monitoraggio di presenza ICMP dichiarato (monitorMode=ping).',
        'Nessun comando è stato inviato al dispositivo: i valori SNMP non servono, conta online/offline.',
        'La spazzata ping si lancia dalla scheda apparato (o su tutte le telecamere dall\'elenco dispositivi).',
      ],
      persisted: {
        snmpEnableState: device.snmpEnableState as '' | 'ENABLED' | 'ENABLED_UNVERIFIED' | 'FAILED' | 'MANUAL_REQUIRED',
        snmpEnableMethod: '',
        monitorMode: 'ping',
        communitySaved: false,
      },
    }
    const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
    devValidate(SnmpEnableResultSchema, body)
    return ok(data, body.asOf, body.mode)
  }

  /* --- 2b) Ricetta MANUALE → DICHIARAZIONE MANUAL_REQUIRED (nessun
   *        contatto: le istruzioni restano in UI, mai eseguite). --- */
  if (plan.transport === 'manual') {
    const note = readableNote([`Ricetta manuale (${input.recipeId}): attivare dal pannello web seguendo le istruzioni mostrate.`, plan.note])
    await db.device.update({
      where: { id: device.id },
      data: {
        snmpEnableState: 'MANUAL_REQUIRED',
        snmpEnableMethod: input.recipeId,
        snmpEnableNote: note,
        snmpEnableAt: now,
      },
    })
    await db.auditLog.create({
      data: {
        action: 'DEVICE_SNMP_ENABLE',
        actor: session.session.user.email ?? 'sconosciuto',
        targetId: device.id,
        targetLabel: `${device.hostname} (${device.ip})`,
        details: JSON.stringify({
          recipeId: input.recipeId,
          transport: 'manual',
          declaration: 'MANUAL_REQUIRED',
          contact: 'NONE — nessuna automazione per questo vendor: istruzioni manuali',
        }),
      },
    }).catch(() => { /* audit best-effort */ })

    const data: SnmpEnableResult = {
      recipeId: input.recipeId,
      transport: 'manual',
      applied: false,
      steps: [],
      verify: { reachable: false, matchedCommunity: null, sysName: null, sysDescr: null, error: null },
      state: 'MANUAL_REQUIRED',
      notes: [
        'Nessuna automazione disponibile per questo vendor: FALCO-OS non invia comandi alla cieca.',
        'Attivare SNMP dal pannello web seguendo le istruzioni, poi rilanciare la verifica dalla scheda.',
      ],
      persisted: {
        snmpEnableState: 'MANUAL_REQUIRED',
        snmpEnableMethod: input.recipeId,
        monitorMode: device.monitorMode as 'full' | 'ping',
        communitySaved: false,
      },
    }
    const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
    devValidate(SnmpEnableResultSchema, body)
    return ok(data, body.asOf, body.mode)
  }

  /* --- 2c) SSH / SwOS → l'ATTUATORE (contatto reale). Credenziali:
   *        finestra OPPURE cifrate del dispositivo (decifrate qui,
   *        mai in risposta). --- */
  let ssh: { port: number; username: string; password: string } | undefined
  let swos: { port: number; username: string; password: string } | undefined

  if (input.ssh) {
    ssh = {
      port: input.ssh.port ?? device.sshPort ?? 22,
      username: input.ssh.username,
      password: input.ssh.password,
    }
  } else if (device.username !== '' && device.password !== '') {
    const plain = decryptSecret(device.password)
    if (plain == null) {
      return fail('CREDS_UNREADABLE', 'Le credenziali salvate non sono decifrabili (chiave master assente o ruotata): inserirle nella finestra di attivazione', 422)
    }
    ssh = { port: device.sshPort ?? 22, username: device.username, password: plain }
  }

  if (input.swos) {
    swos = {
      port: input.swos.port ?? device.port ?? 80,
      username: input.swos.username,
      password: input.swos.password,
    }
  } else if (device.username !== '' && device.password !== '') {
    const plain = decryptSecret(device.password)
    if (plain == null) {
      return fail('CREDS_UNREADABLE', 'Le credenziali salvate non sono decifrabili (chiave master assente o ruotata): inserirle nella finestra di attivazione', 422)
    }
    swos = { port: device.port ?? 80, username: device.username, password: plain }
  }

  if (plan.transport === 'ssh' && !ssh) {
    return fail('SSH_CREDS_REQUIRED', 'Credenziali SSH assenti: inserirle nella finestra (o salvarle nella scheda apparato) — nessun comando è stato eseguito', 422)
  }
  if (plan.transport === 'http-swos' && !swos) {
    return fail('SWOS_CREDS_REQUIRED', 'Credenziali del pannello SwOS assenti: inserire utente e password del pannello web — nessun comando è stato eseguito', 422)
  }

  /* Community per la verifica finale: quella della finestra + quella
   * CIFRATA del dispositivo (se diversa) — max 8, dedup. */
  const stored = device.snmpCommunityEnc !== '' ? decryptSecret(device.snmpCommunityEnc) : null
  const verifyCommunities = Array.from(new Set([input.community, ...(stored ? [stored] : [])])).slice(0, 8)

  const pr = await discoveryPost('/actuate/snmp-enable', {
    ip: device.ip,
    recipeId: input.recipeId,
    community: input.community,
    contact: input.contact,
    location: input.location,
    snmpPort: input.snmpPort ?? device.snmpPort,
    verifyCommunities,
    ...(ssh ? { ssh } : {}),
    ...(swos ? { swos } : {}),
  }, { timeoutMs: 80_000 })
  if (!pr.ok) return proxyFail(pr)

  const result = (pr.body as { result?: SnmpEnableResult }).result
  if (!result) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza l\'esito dell\'attuazione' } } })
  }

  /* --- 3) Persistenza onesta dello stato + community CIFRATA --- */
  const communitySaved = result.state === 'ENABLED' && result.verify.matchedCommunity != null
  let savedCommunityEnc = device.snmpCommunityEnc
  if (communitySaved && result.verify.matchedCommunity) {
    const enc = encryptSecret(result.verify.matchedCommunity)
    if (enc) {
      savedCommunityEnc = enc
      await db.device.update({ where: { id: device.id }, data: { snmpCommunityEnc: enc } })
    }
  }

  await db.device.update({
    where: { id: device.id },
    data: {
      snmpEnableState: result.state,
      snmpEnableMethod: result.recipeId,
      snmpEnableNote: readableNote(result.notes.length > 0 ? result.notes : [result.state]),
      snmpEnableAt: now,
    },
  })

  await db.auditLog.create({
    data: {
      action: 'DEVICE_SNMP_ENABLE',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: device.id,
      targetLabel: `${device.hostname} (${device.ip})`,
      details: JSON.stringify({
        recipeId: result.recipeId,
        transport: result.transport,
        state: result.state,
        applied: result.applied,
        stepsOk: result.steps.filter((s) => s.ok).length,
        stepsTotal: result.steps.length,
        verifyReachable: result.verify.reachable,
        verifySysName: result.verify.sysName,
        communitySaved,
        credsSource: input.ssh || input.swos ? 'window' : 'saved-encrypted',
      }),
    },
  }).catch(() => { /* audit best-effort: l'esito è già persistito */ })

  const data: SnmpEnableResult = {
    ...result,
    persisted: {
      snmpEnableState: result.state,
      snmpEnableMethod: result.recipeId,
      monitorMode: device.monitorMode as 'full' | 'ping',
      communitySaved,
    },
  }
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(SnmpEnableResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
