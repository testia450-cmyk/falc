/* ================================================================
 * /api/v2/discovery/vendor-batch — POST (v16.8 — puller integrato)
 * ================================================================
 * Identificazione di N IP (≤32) in UNA richiesta: il backend fa UN
 * solo round-trip verso il mini-service :3002 (che a sua volta sonda
 * in parallelo con concurrency controllata) invece di N fetch
 * sequenziali da 5-15 s l'uno. È il «puller» dell'ondata Scansione:
 * · auth + zod QUI, motore batch nel mini-service;
 * · NESSUNA scrittura su DB (la sonda resta read-only: l'adozione è
 *   un'azione umana esplicita, § /api/v2/adozione);
 * · audit DISCOVERY_VENDOR_BATCH con la sola SINTESI (nessun IP nel
 *   dettaglio — la privacy dell'operazione resta quella delle scan).
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { devValidate } from '@/app/api/v2/shared'
import { VendorBatchInputSchema, VendorBatchResultSchema, type VendorProbeResult } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = VendorBatchInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri del batch non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const pr = await discoveryPost('/probe/vendor/batch', input)
  if (!pr.ok) return proxyFail(pr)

  const wrapped = pr.body as {
    job?: {
      concurrency: number
      durationMs: number
      total: number
      alive: number
      classified: number
      results: Array<{
        ip: string
        alive: boolean
        latencyMs: number | null
        slowHost?: boolean
        openPorts: Array<{ port: number; state: string }>
        http: Record<string, string | null | undefined> | null
        tls: { cn?: string | null; issuer?: string | null; validTo?: string | null } | null
        snmp: Record<string, unknown> | null
        onvif: Record<string, unknown> | null
        oui: { mac: string; vendor: string; category: string } | null
        classification: Record<string, unknown>
      }>
    }
  }
  const job = wrapped.job
  if (!job) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
  }

  /* Il servizio restituisce http/tls/snmp/onvif/classification con i
   * campi v16.8 (slowHost, matched, product, os…): si inoltrano TALI
   * QUALE nella busta v2 — il contratto li dichiara opzionali. */
  const results = job.results as unknown as VendorProbeResult[]

  const data = {
    concurrency: job.concurrency,
    durationMs: job.durationMs,
    total: job.total,
    alive: job.alive,
    classified: job.classified,
    results,
  }

  try {
    await db.auditLog.create({
      data: {
        action: 'DISCOVERY_VENDOR_BATCH',
        actor: session.session.user.email ?? 'sconosciuto',
        targetId: null,
        targetLabel: `batch ${job.total} IP`,
        details: JSON.stringify({
          total: job.total,
          alive: job.alive,
          classified: job.classified,
          durationMs: job.durationMs,
          communities: input.snmp?.communities?.length ?? input.snmp?.community ? 'custom' : 'default',
        }),
      },
    })
  } catch {
    /* l'audit non deve bloccare la risposta */
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(VendorBatchResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
