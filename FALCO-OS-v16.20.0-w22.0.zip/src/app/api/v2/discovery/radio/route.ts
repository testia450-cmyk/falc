/* ================================================================
 * /api/v2/discovery/radio — POST (v16.18 W20 — telemetria radio & salute)
 * ================================================================
 * Domanda a cui risponde: «Cosa dichiara DAVVERO quest'antenna/router
 * via SNMP — SSID, segnale, CCQ, frequenza, velocità radio, client
 * associati, CPU, RAM, porte ethernet con duplex?»
 *
 * Sonda del mini-service :3002 (POST /probe/radio) su UN apparato
 * dell'inventario: batteria OID «candidati» (MIKROTIK-MIB 14988 +
 * HOST-RESOURCES + UCD + EtherLike + firma airMAX 41112) con
 * PROVENANCE per ogni campo — la sonda non inventa mai la fonte.
 *
 * Persistenza (regola d'oro: verità > inferenza):
 *   · Device: SOLO i campi effettivamente letti (null → non toccati);
 *     uptime da sysUpTime; lastSeenAt aggiornato (l'apparato ha
 *     risposto); radioMode/linkMode DEDOTTI dai dati reali (client>0
 *     → AP con PTP/PTMP dal numero di stazioni; segnale senza client
 *     → STA);
 *   · MetricValue: campioni cpuLoad, memoryUsage, signalStrength,
 *     linkQuality, radioClients, radioTxRate (solo se presenti);
 *   · snmpEnableState → ENABLED (una risposta SNMP È una verifica);
 *     la community che ha risposto viene cifrata e salvata se nuova;
 *   · AuditLog DEVICE_RADIO_PROBE con la sintesi onesta.
 *
 * RBAC: TECNICO+. Telecamere in monitorMode='ping': la sonda si può
 * comunque lanciare (non fa danno — è sola lettura), ma la risposta
 * dichiara la modalità dichiarata.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { decryptSecret, encryptSecret } from '@/lib/crypto'
import { hasRole } from '@/lib/auth'
import { RadioTelemetryInputSchema, RadioTelemetryResultSchema } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

interface RadioProbePayload {
  reachable: boolean
  matched?: { community?: string; version?: string } | null
  sysName?: string | null
  sysDescr?: string | null
  sysObjectID?: string | null
  uptimeTicks?: number | null
  health?: {
    cpuLoadPct?: number | null
    ramUsedKb?: number | null
    ramTotalKb?: number | null
    provenance?: Array<{ field: string; oid: string; label: string; confidence: string }>
  }
  radios?: Array<{
    index: number
    ssid?: string | null
    band?: string | null
    frequencyMhz?: number | null
    signalDbm?: number | null
    noiseFloorDbm?: number | null
    snrDb?: number | null
    txRateMbps?: number | null
    rxRateMbps?: number | null
    ccqPercent?: number | null
  }>
  clients?: Array<{
    mac?: string | null
    signalDbm?: number | null
    txRateMbps?: number | null
    rxRateMbps?: number | null
    lastIp?: string | null
  }>
  ports?: Array<{
    ifIndex: number
    name?: string | null
    speedMbps?: number | null
    duplex?: 'full' | 'half' | null
  }>
  provenance?: Array<{ field: string; oid: string; label: string; confidence: string }>
  warnings?: string[]
  notes?: string[]
  error?: string
  detail?: string
}

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono eseguire la sonda telemetria', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = RadioTelemetryInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri della sonda telemetria non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* FIX W21 (multi-impianto): il client API v2 inietta l'impianto ATTIVO
   * come ?plantId= (v2Url) — il body lo può confermare, ma senza questa
   * lettura la rotta ricadeva sul primo impianto creato, ignorando
   * quello selezionato dall'operatore. */
  const queryPlantId = new URL(req.url).searchParams.get('plantId')

  const plant = await resolvePlant(input.plantId ?? queryPlantId ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const device = await db.device.findUnique({
    where: { id: input.deviceId },
    select: {
      id: true, hostname: true, ip: true, type: true, plantId: true,
      decommissionedAt: true, monitorMode: true,
      snmpPort: true, snmpCommunityEnc: true, snmpVersion: true,
      snmpEnableState: true,
    },
  })
  if (!device || device.plantId !== p.id) {
    return fail('NOT_FOUND', 'Dispositivo non trovato nell\'impianto', 404)
  }
  if (device.decommissionedAt) {
    return fail('DECOMMISSIONED', 'Dispositivo dismesso: sonde impossibili (credenziali revocate)', 422)
  }

  /* --- community: cifrata del device → richieste → public --- */
  const communities: string[] = []
  const pushCommunity = (c: string) => {
    const t = c.trim()
    if (t !== '' && !communities.includes(t)) communities.push(t)
  }
  const enc = device.snmpCommunityEnc
  if (enc) {
    const plain = decryptSecret(enc)
    if (plain) pushCommunity(plain)
  }
  for (const c of input.communities ?? []) pushCommunity(c)
  if (communities.length === 0) pushCommunity('public')

  const version = device.snmpVersion === 'v1' || device.snmpVersion === 'v3' ? device.snmpVersion : 'v2c'

  /* --- sonda telemetria verso il mini-service --- */
  const pr = await discoveryPost('/probe/radio', {
    ip: device.ip,
    port: device.snmpPort || 161,
    version,
    communities,
    timeoutMs: input.timeoutMs ?? 2500,
    walkTimeoutMs: 1800,
  }, { timeoutMs: 35_000 })
  if (!pr.ok) return proxyFail(pr)

  const wrapped = pr.body as { result?: RadioProbePayload }
  const probe = wrapped.result
  if (!probe) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
  }

  const persisted = {
    cpuLoad: false, ram: false, ssid: false, signalStrength: false,
    linkQuality: false, currentFrequency: false, radioMode: false,
    uptimeSeconds: false, metricsSaved: 0, snmpEnableState: device.snmpEnableState,
  }

  /* --- esito onesto: apparato muto → report senza valori --- */
  if (!probe.reachable) {
    await db.auditLog.create({
      data: {
        action: 'DEVICE_RADIO_PROBE',
        actor: session.session.user.email ?? 'sconosciuto',
        targetId: device.id,
        targetLabel: `${device.hostname} (${device.ip})`,
        plantId: p.id,
        details: JSON.stringify({
          reachable: false,
          error: probe.error ?? null,
          communitiesTried: communities.length,
        }),
      },
    }).catch(() => { /* audit best-effort */ })

    const data = {
      device: { id: device.id, hostname: device.hostname, ip: device.ip, type: device.type },
      reachable: false as const,
      sysName: null, sysDescr: null, matched: null,
      error: probe.error ?? 'timeout',
      detail: probe.detail ?? 'nessuna risposta SNMP',
      health: { cpuLoadPct: null, ramUsedKb: null, ramTotalKb: null, provenance: [] },
      radios: [], clients: [], ports: [], provenance: [],
      derived: { radioMode: null, linkMode: null, note: 'Apparato non raggiungibile via SNMP: nessun campo toccato.' },
      persisted,
      warnings: [`SNMP non raggiungibile su ${device.ip}:${device.snmpPort || 161} — community tentate: ${communities.join(', ')}`],
      notes: probe.notes ?? [],
    }
    const replay = await getReplayState()
    devValidate(RadioTelemetryResultSchema, { ok: true, asOf: Date.now(), mode: apiMode(replay), data })
    return ok(data, Date.now(), apiMode(replay))
  }

  /* --- apparato raggiungibile: deduzione + persistenza --- */
  const radios = probe.radios ?? []
  const clients = probe.clients ?? []
  const mainRadio = radios.find((r) => r.ssid || r.signalDbm != null) ?? radios[0] ?? null

  /* radioMode/linkMode DEDOTTI dai dati reali (come deduceLinkMode v11.29:
   * 1 stazione = PTP, più = PTMP; qui dal numero di CLIENT dichiarati). */
  let derivedRadioMode: 'ap' | 'sta' | null = null
  let derivedLinkMode: 'PTP' | 'PTMP' | null = null
  let derivedNote = ''
  if (clients.length > 0) {
    derivedRadioMode = 'ap'
    derivedLinkMode = clients.length === 1 ? 'PTP' : 'PTMP'
    derivedNote = `${clients.length} client radio dichiarati dalla registration table → AP (${derivedLinkMode}).`
  } else if (mainRadio && mainRadio.signalDbm != null) {
    derivedRadioMode = 'sta'
    derivedNote = 'Segnale radio dichiarato senza client associati → stazione (STA) verso il proprio AP.'
  } else {
    derivedNote = 'Modalità radio non deducibile da questa lettura (né client né segnale): i campi esistenti non vengono toccati.'
  }

  /* Device: SOLO i campi realmente letti (null → non toccati). */
  const deviceUpdate: Record<string, unknown> = { lastSeenAt: new Date() }
  if (probe.health?.cpuLoadPct != null) {
    deviceUpdate.cpuLoad = probe.health.cpuLoadPct
    persisted.cpuLoad = true
  }
  if (probe.health?.ramUsedKb != null && probe.health.ramTotalKb != null && probe.health.ramTotalKb > 0) {
    deviceUpdate.ramUsed = probe.health.ramUsedKb
    deviceUpdate.ramTotal = probe.health.ramTotalKb
    persisted.ram = true
  }
  if (mainRadio?.ssid) {
    deviceUpdate.ssid = mainRadio.ssid
    persisted.ssid = true
  }
  if (mainRadio?.signalDbm != null) {
    deviceUpdate.signalStrength = mainRadio.signalDbm
    persisted.signalStrength = true
  }
  if (mainRadio?.ccqPercent != null) {
    deviceUpdate.linkQuality = mainRadio.ccqPercent
    persisted.linkQuality = true
  }
  if (mainRadio?.frequencyMhz != null) {
    deviceUpdate.currentFrequency = String(mainRadio.frequencyMhz)
    persisted.currentFrequency = true
  }
  if (derivedRadioMode) {
    deviceUpdate.radioMode = derivedRadioMode
    deviceUpdate.linkMode = derivedLinkMode ?? ''
    persisted.radioMode = true
  }
  if (probe.uptimeTicks != null && probe.uptimeTicks > 0) {
    deviceUpdate.uptimeSeconds = Math.round(probe.uptimeTicks / 100)
    persisted.uptimeSeconds = true
  }

  /* Una risposta SNMP È una verifica: promuove lo stato (come W19). */
  const storedPlain = device.snmpCommunityEnc ? decryptSecret(device.snmpCommunityEnc) : null
  const matchedCommunity = probe.matched?.community
  if (matchedCommunity && matchedCommunity !== '—' && matchedCommunity !== storedPlain) {
    const newEnc = encryptSecret(matchedCommunity)
    if (newEnc) deviceUpdate.snmpCommunityEnc = newEnc
  }
  if (device.snmpEnableState !== 'ENABLED') {
    deviceUpdate.snmpEnableState = 'ENABLED'
    deviceUpdate.snmpEnableNote = `Telemetria letta: sonda SNMP raggiungibile${probe.sysName ? ` (sysName "${probe.sysName}")` : ''}`.slice(0, 500)
    deviceUpdate.snmpEnableAt = new Date()
    persisted.snmpEnableState = 'ENABLED'
  }

  /* MetricValue: campioni SOLO per i valori presenti (nessun campione
   * di un null — un grafico con buchi onesti è meglio di uno zero finto). */
  const now = new Date()
  const metrics: Array<{ deviceId: string; plantId: string; metric: string; value: number; unit: string; timestamp: Date }> = []
  if (probe.health?.cpuLoadPct != null) {
    metrics.push({ deviceId: device.id, plantId: p.id, metric: 'cpuLoad', value: probe.health.cpuLoadPct, unit: '%', timestamp: now })
  }
  if (probe.health?.ramUsedKb != null && probe.health.ramTotalKb != null && probe.health.ramTotalKb > 0) {
    metrics.push({ deviceId: device.id, plantId: p.id, metric: 'memoryUsage', value: Math.round((probe.health.ramUsedKb / probe.health.ramTotalKb) * 100), unit: '%', timestamp: now })
  }
  if (mainRadio?.signalDbm != null) {
    metrics.push({ deviceId: device.id, plantId: p.id, metric: 'signalStrength', value: mainRadio.signalDbm, unit: 'dBm', timestamp: now })
  }
  if (mainRadio?.ccqPercent != null) {
    metrics.push({ deviceId: device.id, plantId: p.id, metric: 'linkQuality', value: mainRadio.ccqPercent, unit: '%', timestamp: now })
  }
  if (clients.length > 0) {
    metrics.push({ deviceId: device.id, plantId: p.id, metric: 'radioClients', value: clients.length, unit: 'n', timestamp: now })
  }
  if (mainRadio?.txRateMbps != null) {
    metrics.push({ deviceId: device.id, plantId: p.id, metric: 'radioTxRate', value: mainRadio.txRateMbps, unit: 'Mbps', timestamp: now })
  }

  try {
    await db.device.update({ where: { id: device.id }, data: deviceUpdate })
    if (metrics.length > 0) {
      await db.metricValue.createMany({ data: metrics })
      persisted.metricsSaved = metrics.length
    }
  } catch {
    /* la persistenza fallita non invalida la LETTURA: il report resta
     * onesto (persisted dice cosa è successo davvero) */
    persisted.cpuLoad = false
    persisted.ram = false
    persisted.ssid = false
    persisted.signalStrength = false
    persisted.linkQuality = false
    persisted.currentFrequency = false
    persisted.radioMode = false
    persisted.uptimeSeconds = false
    persisted.metricsSaved = 0
    persisted.snmpEnableState = device.snmpEnableState
  }

  await db.auditLog.create({
    data: {
      action: 'DEVICE_RADIO_PROBE',
      actor: session.session.user.email ?? 'sconosciuto',
      targetId: device.id,
      targetLabel: `${device.hostname} (${device.ip})`,
      plantId: p.id,
      details: JSON.stringify({
        reachable: true,
        sysName: probe.sysName ?? null,
        cpuLoad: probe.health?.cpuLoadPct ?? null,
        ramTotalKb: probe.health?.ramTotalKb ?? null,
        radios: radios.length,
        clients: clients.length,
        ports: (probe.ports ?? []).length,
        metricsSaved: persisted.metricsSaved,
        derived: derivedRadioMode ? { radioMode: derivedRadioMode, linkMode: derivedLinkMode } : null,
        provenanceCount: (probe.provenance ?? []).length,
        monitorMode: device.monitorMode,
      }),
    },
  }).catch(() => { /* audit best-effort */ })

  const data = {
    device: { id: device.id, hostname: device.hostname, ip: device.ip, type: device.type },
    reachable: true as const,
    sysName: probe.sysName ?? null,
    sysDescr: probe.sysDescr ?? null,
    matched: probe.matched ? { community: probe.matched.community ?? '—', version: probe.matched.version ?? 'v2c' } : null,
    error: null as string | null,
    detail: null as string | null,
    health: {
      cpuLoadPct: probe.health?.cpuLoadPct ?? null,
      ramUsedKb: probe.health?.ramUsedKb ?? null,
      ramTotalKb: probe.health?.ramTotalKb ?? null,
      provenance: probe.health?.provenance ?? [],
    },
    radios,
    clients,
    ports: probe.ports ?? [],
    provenance: probe.provenance ?? [],
    derived: {
      radioMode: derivedRadioMode,
      linkMode: derivedLinkMode,
      note: derivedNote,
    },
    persisted,
    warnings: probe.warnings ?? [],
    notes: [
      ...(probe.notes ?? []),
      ...(device.monitorMode === 'ping' ? ['Dispositivo dichiarato monitorMode="ping": la telemetria SNMP è letta comunque (sola lettura), ma i valori non alimentano il monitoraggio ordinario.'] : []),
    ],
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(RadioTelemetryResultSchema, body)
  return ok(data, body.asOf, body.mode)
}
