/* ================================================================
 * /api/v2/discovery/l2/adopt-arp — POST (v16.16 W17-a)
 * ================================================================
 * Domanda a cui risponde: «Il report batch elenca MAC con IP noto
 * NON in inventario come CANDIDATI adozione — come li adotto?»
 *
 * Prima di W17 il candidato era solo un report (la lista nel dialog
 * L2) e l'adozione richiedeva un giro manuale (dispositivo nuovo a
 * mano). Ora il pulsante «Adotta» chiama QUESTA rotta: una scelta
 * umana esplicita che crea il dispositivo dall'evidenza reale.
 *
 * REGOLE D'ORO (le stesse di sempre):
 *   · la decisione è UMANA: il corpo porta la dichiarazione
 *     dell'operatore (hostname, tipo, sede, note) — il server non
 *     sceglie MAI nulla al posto suo;
 *   · NESSUN dato inventato: MAC e IP arrivano dal report batch (sonda
 *     reale), il vendor arriva dal database OUI IEEE (10.679
 *     prefissi) o resta vuoto, lastSeenAt arriva dalla riga di
 *     evidenza (ArpEntry/FdbObservation) o resta null;
 *   · guardie a valle: al click il mondo può essere cambiato — il MAC
 *     deve essere ancora LIBERO nell'inventario (altrimenti 422 con
 *     il device che lo porta) e l'IP non deve appartenere a un ALTRO
 *     device (altrimenti 422: se è una sostituzione, la rotta onesta
 *     è il flusso RMA, non un doppione);
 *   · ArpEntry/FdbObservation NON vengono toccate: sono il registro
 *     delle osservazioni (append-only); il nuovo device con
 *     macAddress noto viene riconosciuto da solo ai prossimi giri
 *     (il join MAC↔inventario della tab MAC si chiude da sé);
 *   · finestra di assestamento 24h (baselineUntil, come RMA v15):
 *     anti falsi allarmi post-provisioning;
 *   · audit ADOZIONE_ARP_ADOPT: la decisione, l'evidenza e la
 *     provenienza (seenBy) — niente segreti nel registro.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { hasRole } from '@/lib/auth'
import { ArpAdoptionInputSchema, ArpAdoptionResultSchema } from '@/lib/v2/contracts'
import { discoveryGet } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { normalizeMac } from '@/lib/domain/l2-reconstruct'

export const dynamic = 'force-dynamic'

/** Finestra di assestamento post-adozione (stessa dell'RMA v15). */
const BASELINE_HOURS = 24

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo un tecnico può adottare un candidato ARP', 403)
  }

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response
  const plantId = plant.plant.id

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = ArpAdoptionInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Dichiarazione di adozione non valida', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* MAC: il server ri-normalizza (il report manda già AA:BB:CC:DD:EE:FF,
   * ma la rotta non si fida di nessuno). */
  const mac = normalizeMac(input.mac)
  if (!mac) {
    return fail('BAD_BODY', 'MAC non valido (atteso AA:BB:CC:DD:EE:FF)', 422)
  }

  /* --- guardia 1: il MAC deve essere ancora LIBERO nell'impianto --- */
  const macOwner = await db.device.findFirst({
    where: { plantId, macAddress: mac },
    select: { id: true, hostname: true, decommissionedAt: true, ip: true },
  })
  if (macOwner) {
    return fail('MAC_INVENTORY', macOwner.decommissionedAt
      ? `Il MAC risulta già su «${macOwner.hostname}» (dismesso il ${macOwner.decommissionedAt.toISOString().slice(0, 10)}): se è lo stesso apparato rimesso in rete, usare il flusso RMA`
      : `Il MAC risulta già in inventario su «${macOwner.hostname}» (${macOwner.ip})`, 422, { deviceId: macOwner.id, hostname: macOwner.hostname })
  }

  /* --- guardia 2: l'IP non deve appartenere a un ALTRO device attivo --- */
  const ipOwner = await db.device.findFirst({
    where: { plantId, ip: input.ip, decommissionedAt: null },
    select: { id: true, hostname: true, macAddress: true },
  })
  if (ipOwner && (ipOwner.macAddress ?? '') !== mac) {
    return fail('IP_IN_USE', `L'IP ${input.ip} è già di «${ipOwner.hostname}»: se è una sostituzione, usare il flusso RMA (porta genealogia e credenziali)`, 422, { deviceId: ipOwner.id, hostname: ipOwner.hostname })
  }

  /* --- guardia 3: la sede (se dichiarata) deve essere dell'impianto --- */
  let locationName: string | null = null
  if (input.locationId) {
    const loc = await db.location.findFirst({
      where: { id: input.locationId, plantId },
      select: { id: true, name: true },
    })
    if (!loc) {
      return fail('NOT_FOUND', 'Sede inesistente o fuori dall\'impianto', 404)
    }
    locationName = loc.name
  }

  /* --- evidenza reale nel DB (righe scritte dalle sonde) --- */
  /* ArpEntry NON ha la relazione device (deviceId è un riferimento
   * libero nello schema v15): l'hostname dello switch che ha visto il
   * MAC si risolve con UNA lettura in più, solo se c'è la riga. */
  const arpRow = await db.arpEntry.findFirst({
    where: { mac, plantId },
    orderBy: { lastSeen: 'desc' },
    select: { lastSeen: true, deviceId: true },
  })
  let arpSeenBy: string | null = null
  if (arpRow?.deviceId) {
    const observer = await db.device.findUnique({
      where: { id: arpRow.deviceId },
      select: { hostname: true },
    })
    arpSeenBy = observer?.hostname ?? null
  }
  const fdbRow = arpRow
    ? null
    : await db.fdbObservation.findFirst({
        where: { mac, plantId },
        orderBy: { lastSeenAt: 'desc' },
        select: { lastSeenAt: true, device: { select: { hostname: true } } },
      })
  const evidence: 'ARP' | 'FDB' | 'REPORT' = arpRow ? 'ARP' : fdbRow ? 'FDB' : 'REPORT'
  const seenBy = arpSeenBy ?? fdbRow?.device?.hostname ?? null
  const lastSeenAt = arpRow?.lastSeen ?? fdbRow?.lastSeenAt ?? null

  /* --- vendor OUI IEEE (best-effort: il lookup non deve bloccare
   *     l'adozione — un MAC fuori banca dati resta vendor '') --- */
  let ouiVendor = ''
  try {
    const pr = await discoveryGet(`/oui?mac=${encodeURIComponent(mac)}`)
    if (pr.ok) {
      const r = pr.body as { vendor?: string } | null
      ouiVendor = typeof r?.vendor === 'string' ? r.vendor : ''
    }
  } catch {
    /* servizio discovery giù: adozione senza vendor, dichiarato */
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()
  const baselineUntil = new Date(now.getTime() + BASELINE_HOURS * 60 * 60 * 1000)
  const provenance = [
    `Adottato da candidato ARP il ${now.toISOString().slice(0, 16).replace('T', ' ')} UTC`,
    seenBy ? `visto dall'ARP di ${seenBy}` : null,
    evidence === 'REPORT' ? 'evidenza: report batch (nessuna riga ARP/FDB persistita)' : null,
  ].filter(Boolean).join(' · ')

  /* --- creazione + audit in transazione --- */
  const created = await db.$transaction(async (tx) => {
    const device = await tx.device.create({
      data: {
        plantId,
        hostname: input.hostname,
        ip: input.ip,
        type: input.type,
        macAddress: mac,
        brand: ouiVendor,
        connectionType: input.connectionType,
        locationId: input.locationId ?? null,
        notes: [provenance, input.notes ?? ''].filter(Boolean).join('\n'),
        /* onestà: vivo quanto la sua ultima evidenza reale (null se il
         * MAC non ha righe nel DB — il poller lo valuterà da sé) */
        lastSeenAt,
        /* anti falsi allarmi post-provisioning (stessa finestra RMA) */
        baselineUntil,
      },
      select: { id: true, hostname: true, ip: true, type: true, macAddress: true, brand: true, connectionType: true, locationId: true, baselineUntil: true },
    })
    await tx.auditLog.create({
      data: {
        action: 'ADOZIONE_ARP_ADOPT',
        actor: email,
        targetId: device.id,
        targetLabel: device.hostname.slice(0, 80),
        plantId,
        details: JSON.stringify({
          deviceId: device.id,
          mac,
          ip: input.ip,
          type: input.type,
          connectionType: input.connectionType,
          locationId: input.locationId ?? null,
          evidence,
          seenBy,
          ouiVendor,
          lastSeenAt: lastSeenAt ? lastSeenAt.toISOString() : null,
          note: input.notes ?? '',
          decision: 'adozione umana da candidato ARP (report batch L2)',
        }),
      },
    })
    return device
  })

  const data = {
    id: created.id,
    hostname: created.hostname,
    ip: created.ip,
    macAddress: created.macAddress ?? mac,
    type: created.type,
    brand: created.brand ?? '',
    connectionType: created.connectionType ?? '',
    locationId: created.locationId,
    locationName,
    baselineUntil: created.baselineUntil ? created.baselineUntil.toISOString() : null,
    evidence,
    seenBy,
    ouiVendor,
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(ArpAdoptionResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
