/* ================================================================
 * /api/v2/discovery/l2 — POST (v16.15 — ricostruzione rete in bridge)
 * ================================================================
 * Domanda a cui risponde: «Com'è fatta DAVVERO la rete dietro questo
 * switch, quando tutto passa da un bridge?»
 *
 * Sonda Layer-2 del mini-service :3002 su UN apparato dell'inventario
 * (LLDP-MIB + CDP + BRIDGE-MIB dot1dBasePort/FDB + Q-BRIDGE + IF-MIB
 * + v16.15: STP dot1dStpPortTable + ARP ipNetToMedia + VLAN statiche),
 * poi la PURE FUNCTION l2Reconstruct combina le dichiarazioni:
 *   · LLDP/CDP → link HIGH (il vicino dichiara se stesso);
 *   · FDB → link MEDIUM per MAC di dispositivi noti su porta UNICA
 *     (evidenza FDB_ENDPOINT);
 *   · più dispositivi noti sulla STESSA porta → segmento in bridge:
 *     link LOW con evidenza DAISY_CHAIN (onesti: NON si finge un cavo
 *     dedicato dove c'è un segmento condiviso);
 *   · STP → corrobora i link (bridge designato = MAC del collegato).
 *
 * Persistenza (regola d'oro: verità > inferenza):
 *   · FdbObservation: TUTTE le osservazioni MAC (cap 512, alimenta
 *     l'inventario MAC e la vista per porta), upsert {deviceId,
 *     portName, mac};
 *   · v16.15 — ArpEntry: la tabella ARP (cap 256, upsert {ip,
 *     deviceId}); StpObservation: la dichiarazione STP per porta
 *     (cap 128, upsert {deviceId, portNum}); VlanInventory: le VLAN
 *     dichiarate (cap 32, upsert {deviceId, vlanId});
 *   · TopologyLink: SOLO link tra dispositivi dell'inventario; i link
 *     dell'OPERATORE (TECHNICIAN o confirmed) non vengono MAI toccati;
 *     i link inferiti precedenti della STESSA fonte vengono aggiornati;
 *   · AuditLog TOPOLOGY_L2_SCAN: chi ha sondato cosa, con che esito.
 * (Le scritture vivono in src/lib/v2/l2-persist.ts — condivise con la
 *  rotta batch /l2/batch: una fonte sola di verità.)
 *
 * Community: prima quella CIFRATA del dispositivo (snmpCommunityEnc),
 * poi le eventuali communities aggiuntive della richiesta, poi
 * «public» — il servizio le tenta in ordine e dichiara quale ha risposto.
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { decryptSecret } from '@/lib/crypto'
import { hasRole } from '@/lib/auth'
import { DiscoveryL2InputSchema, DiscoveryL2ResultSchema } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { l2Reconstruct, type InventoryDevice, type L2ProbePayload } from '@/lib/domain/l2-reconstruct'
import {
  MAX_PERSISTED_ARP_ROWS,
  MAX_PERSISTED_OBSERVATIONS,
  MAX_PERSISTED_STP_PORTS,
  MAX_PERSISTED_VLANS,
  countLinkOutcome,
  persistArpEntries,
  persistFdbObservations,
  persistInferredLink,
  persistStpObservations,
  persistVlanInventory,
} from '@/lib/v2/l2-persist'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono eseguire la sonda Layer-2', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = DiscoveryL2InputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri della sonda L2 non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* FIX W21 (multi-impianto): il client API v2 inietta l'impianto ATTIVO
   * come ?plantId= (v2Url) — il body lo può confermare, ma senza questa
   * lettura la rotta ricadeva sul primo impianto creato, ignorando
   * quello selezionato dall'operatore. */
  const queryPlantId = new URL(req.url).searchParams.get('plantId')

  /* --- impianto e apparato da sondare --- */
  const plant = await resolvePlant(input.plantId ?? queryPlantId ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const device = await db.device.findUnique({
    where: { id: input.deviceId },
    select: {
      id: true, hostname: true, ip: true, type: true, macAddress: true,
      plantId: true, snmpPort: true, snmpCommunityEnc: true, snmpVersion: true,
    },
  })
  if (!device || device.plantId !== p.id) {
    return fail('NOT_FOUND', 'Dispositivo non trovato nell\'impianto', 404)
  }

  /* --- community: cifrata del device → richieste → public --- */
  const communities: string[] = []
  const pushCommunity = (c: string) => {
    const t = c.trim()
    if (t !== '' && !communities.includes(t)) communities.push(t)
  }
  const enc = device.snmpCommunityEnc
  if (enc) {
    const plain = decryptSecret(enc)
    if (plain) pushCommunity(plain)
  }
  for (const c of input.communities ?? []) pushCommunity(c)
  if (communities.length === 0) pushCommunity('public')

  const version = device.snmpVersion === 'v1' || device.snmpVersion === 'v3' ? device.snmpVersion : 'v2c'

  /* --- sonda L2 verso il mini-service --- */
  const pr = await discoveryPost('/probe/l2', {
    ip: device.ip,
    port: device.snmpPort || 161,
    version,
    communities,
    timeoutMs: input.timeoutMs ?? 2000,
    walkTimeoutMs: 1500,
  })
  if (!pr.ok) return proxyFail(pr)

  const wrapped = pr.body as { result?: L2ProbePayload & { error?: string; detail?: string } }
  const probe = wrapped.result
  if (!probe) {
    return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
  }

  const switchDevice: InventoryDevice = {
    id: device.id,
    ip: device.ip,
    hostname: device.hostname,
    macAddress: device.macAddress ?? '',
    type: device.type,
  }

  /* --- esito onesto: switch muto → report senza link (nessun errore finto) --- */
  if (!probe.reachable) {
    const data = {
      switch: {
        id: switchDevice.id,
        hostname: switchDevice.hostname,
        ip: switchDevice.ip,
        sysName: null,
        matched: null,
      },
      reachable: false,
      error: probe.error,
      detail: probe.detail,
      links: [],
      unmatchedNeighbors: [],
      sharedPorts: [],
      warnings: [`SNMP non raggiungibile su ${device.ip}:${device.snmpPort || 161} — community tentate: ${communities.join(', ')}`],
      persistence: { linksCreated: 0, linksUpdated: 0, linksSkippedOperator: 0, observationsSaved: 0 },
      stats: {
        lldpNeighbors: 0, cdpNeighbors: 0, fdbEntries: 0, vlanFdbEntries: 0,
        matchedLinks: 0, observations: 0, unmatchedNeighbors: 0, sharedPorts: 0,
      },
    }
    const replay = await getReplayState()
    devValidate(DiscoveryL2ResultSchema, { ok: true, asOf: Date.now(), mode: apiMode(replay), data })
    return ok(data, Date.now(), apiMode(replay))
  }

  /* --- inventario del plant (per l'abbinamento vicini/MAC) --- */
  const rows = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: { id: true, hostname: true, ip: true, macAddress: true, type: true },
  })
  const inventory: InventoryDevice[] = rows.map((r) => ({
    id: r.id,
    ip: r.ip,
    hostname: r.hostname,
    macAddress: r.macAddress ?? '',
    type: r.type,
  }))

  const reconstruction = l2Reconstruct(probe, inventory, switchDevice)

  /* --- (1) persistenza osservazioni MAC (upsert, cap onesto) --- */
  const observationsSaved = await persistFdbObservations({
    plantId: p.id,
    deviceId: device.id,
    observations: reconstruction.observations,
    budget: MAX_PERSISTED_OBSERVATIONS,
  })

  /* --- (1b) v16.15 — ARP: tabella ipNetToMedia → ArpEntry (cap 256) --- */
  const arpSaved = await persistArpEntries({
    plantId: p.id,
    deviceId: device.id,
    arp: reconstruction.arp,
  })

  /* --- (1c) v16.15 — STP: dot1dStpPortTable → StpObservation (cap 128) --- */
  const stpSaved = await persistStpObservations({
    plantId: p.id,
    deviceId: device.id,
    probe,
  })

  /* --- (1d) v16.15 — VLAN statiche → VlanInventory (cap 32) --- */
  const vlanSaved = await persistVlanInventory({
    plantId: p.id,
    deviceId: device.id,
    vlans: reconstruction.vlans,
  })

  /* --- (2) persistenza link inferiti (MAI sui link dell'operatore) --- */
  const linkCounters = { linksCreated: 0, linksUpdated: 0, linksSkippedOperator: 0 }

  for (const link of reconstruction.links) {
    const outcome = await persistInferredLink({
      plantId: p.id,
      sourceDeviceId: link.switchDeviceId,
      targetDeviceId: link.targetDeviceId,
      sourcePort: link.sourcePort,
      targetPort: link.targetPort,
      sourceOfTruth: link.sourceOfTruth,
      confidence: link.confidence,
      evidence: link.evidence,
      speedMbps: link.speedMbps,
      notes: `ricostruzione L2 v16.8 — ${link.detail}`,
    })
    countLinkOutcome(outcome, linkCounters)
  }
  const { linksCreated, linksUpdated, linksSkippedOperator } = linkCounters

  /* --- audit: chi ha sondato cosa, con che esito --- */
  try {
    await db.auditLog.create({
      data: {
        action: 'TOPOLOGY_L2_SCAN',
        actor: session.session.user.email ?? 'sconosciuto',
        targetId: device.id,
        targetLabel: `${device.hostname} (${device.ip})`,
        details: JSON.stringify({
          matched: probe.matched ?? null,
          lldp: reconstruction.stats.lldpNeighbors,
          cdp: reconstruction.stats.cdpNeighbors,
          fdb: reconstruction.stats.fdbEntries,
          vlanFdb: reconstruction.stats.vlanFdbEntries,
          arp: reconstruction.stats.arpEntries,
          stp: reconstruction.stats.stpPorts,
          vlans: reconstruction.stats.vlans,
          linksCreated,
          linksUpdated,
          linksSkippedOperator,
          observationsSaved,
          arpSaved,
          stpSaved,
          vlanSaved,
          warnings: reconstruction.warnings.slice(0, 5),
        }),
      },
    })
  } catch {
    /* l'audit non deve bloccare la risposta */
  }

  const data = {
    switch: {
      id: switchDevice.id,
      hostname: switchDevice.hostname,
      ip: switchDevice.ip,
      sysName: probe.sysName ?? null,
      matched: probe.matched ?? null,
    },
    reachable: true as const,
    links: reconstruction.links.map((l) => ({
      switchDeviceId: l.switchDeviceId,
      targetDeviceId: l.targetDeviceId,
      targetHostname: l.targetHostname,
      targetIp: l.targetIp,
      sourcePort: l.sourcePort,
      targetPort: l.targetPort,
      sourcePortNum: l.sourcePortNum,
      sourceOfTruth: l.sourceOfTruth,
      confidence: l.confidence,
      evidence: l.evidence,
      speedMbps: l.speedMbps,
      stpCorroborated: l.stpCorroborated,
      detail: l.detail,
    })),
    unmatchedNeighbors: reconstruction.unmatchedNeighbors,
    sharedPorts: reconstruction.sharedPorts,
    unmatchedMacsWithIp: reconstruction.unmatchedMacsWithIp,
    stp: reconstruction.stp,
    vlans: reconstruction.vlans,
    arp: reconstruction.arp.slice(0, 32),
    warnings: [
      ...reconstruction.warnings,
      ...(reconstruction.observations.length > MAX_PERSISTED_OBSERVATIONS
        ? [`osservazioni MAC persistite limitate a ${MAX_PERSISTED_OBSERVATIONS} su ${reconstruction.observations.length}`]
        : []),
      ...(reconstruction.stats.arpEntries > MAX_PERSISTED_ARP_ROWS
        ? [`voci ARP persistite limitate a ${MAX_PERSISTED_ARP_ROWS} su ${reconstruction.stats.arpEntries}`]
        : []),
      ...((probe.stp?.ports?.length ?? 0) > MAX_PERSISTED_STP_PORTS
        ? [`porte STP persistite limitate a ${MAX_PERSISTED_STP_PORTS} su ${probe.stp?.ports?.length ?? 0}`]
        : []),
      ...(reconstruction.stats.vlans > MAX_PERSISTED_VLANS
        ? [`VLAN di ${device.hostname} limitate a ${MAX_PERSISTED_VLANS} su ${reconstruction.stats.vlans}`]
        : []),
    ],
    persistence: { linksCreated, linksUpdated, linksSkippedOperator, observationsSaved, arpSaved, stpSaved, vlanSaved },
    stats: reconstruction.stats,
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(DiscoveryL2ResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
