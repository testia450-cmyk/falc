/* ================================================================
 * /api/v2/discovery/l2/batch — POST (v16.15 W14 — multi-switch)
 * ================================================================
 * Domanda a cui risponde: «Se SONDO tutti gli switch dell'impianto
 * in UNA volta, la rete in bridge si ricompone da sola?»
 *
 * UNA richiesta verso il mini-service :3002 (/probe/l2/batch: max 12
 * apparati, concurrency 1-4, deadline interna 300 s → il proxy qui
 * estende il timeout a 320 s), poi:
 *   · l2Reconstruct PER OGNI switch raggiunto (link endpoint, come la
 *     rotta singola /l2);
 *   · l2Correlate UNA volta su tutte le sonde (PURE function in
 *     src/lib/domain/l2-correlate.ts): link switch↔switch con porte
 *     di ENTRAMBI i lati, direzione verso la root STP, candidati ARP;
 *   · persistenza per ognuno (stessa logica della rotta singola, in
 *     src/lib/v2/l2-persist.ts): FdbObservation (cap TOTALE 512 per
 *     tutta l'esecuzione), ArpEntry (256), StpObservation (128),
 *     VlanInventory (32), link inferiti.
 *
 * REGOLE D'ORO (le stesse di sempre):
 *   · i link dell'OPERATORE (TECHNICIAN o confirmed) restano
 *     INTOCCABILI — verità > inferenza;
 *   · precedenza delle evidenze per coppia: LLDP/CDP (dichiarazione)
 *     > FDB_MUTUAL (avvistamento reciproco, porte di entrambi i lati)
 *     > FDB_PAIR/STP_DESIGNATED > FDB_ENDPOINT/DAISY_CHAIN: se la coppia
 *     è coperta da un link PIÙ DEBOLE di quello del correlatore, il link
 *     viene AGGIORNATO coi dati superiori (porte di entrambi i lati);
 *     se è coperta da LLDP/CDP il correlatore si fa da parte (onesto);
 *   · NESSUN dato inventato: apparati muti → reachable:false con il
 *     motivo vero; cap raggiunti → dichiarati nei warnings; MAC non
 *     in inventario con IP → candidati adozione, mai auto-adottati;
 *   · selezione: `deviceIds` espliciti (devono essere dell'impianto)
 *     oppure TUTTI i SWITCH/GATEWAY/ROUTER/FIREWALL attivi, cap 12
 *     con avviso (non errore);
 *   · community per apparato: prima la CIFRATA del device, poi le
 *     condivise della richiesta, poi «public».
 *
 * Audit TOPOLOGY_L2_BATCH_SCAN: la SINTESI dell'esecuzione (niente
 * indirizzi nel dettaglio, come i batch vendor).
 * ================================================================ */

import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { decryptSecret } from '@/lib/crypto'
import { hasRole } from '@/lib/auth'
import { DiscoveryL2BatchInputSchema, DiscoveryL2BatchResultSchema, type L2BatchSwitchResult } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'
import { devValidate, resolvePlant } from '@/app/api/v2/shared'
import { l2Reconstruct, type InventoryDevice, type L2ProbePayload } from '@/lib/domain/l2-reconstruct'
import { l2Correlate, type CorrelatorSwitch } from '@/lib/domain/l2-correlate'
import {
  MAX_PERSISTED_ARP_ROWS,
  MAX_PERSISTED_OBSERVATIONS,
  MAX_PERSISTED_STP_PORTS,
  MAX_PERSISTED_VLANS,
  countLinkOutcome,
  persistArpEntries,
  persistFdbObservations,
  persistInferredLink,
  persistStpObservations,
  persistVlanInventory,
} from '@/lib/v2/l2-persist'

export const dynamic = 'force-dynamic'

/** Cap del batch: il mini-service rifiuta oltre 12 target (v16.15 W14). */
const MAX_BATCH_SWITCHES = 12
/** Cap TOTALE di osservazioni MAC persistite in UNA esecuzione batch
 *  (la finestra onesta è per l'esecuzione, non per switch: il
 *  contatore unico observationsSaved dichiara la verità). */
const MAX_BATCH_OBSERVATIONS = 512
/** Timeout proxy esteso: deadline interna del servizio 300 s + margine
 *  per far arrivare il suo errore onesto (il default 20 s è per le
 *  sonde singole, qui sarebbe un bug). */
const BATCH_PROXY_TIMEOUT_MS = 320_000

/** Tipi d'impianto che parlano bridge: la selezione automatica sonda
 *  questi (l'operatore può sempre forzare via deviceIds). */
const L2_BATCH_TYPES = ['SWITCH', 'GATEWAY', 'ROUTER', 'FIREWALL']

/** Campi del device che il batch usa (allowlist stretta come /l2). */
const DEVICE_SELECT = {
  id: true, hostname: true, ip: true, type: true, macAddress: true,
  plantId: true, snmpPort: true, snmpCommunityEnc: true, snmpVersion: true,
} as const

interface BatchDevice {
  id: string
  hostname: string
  ip: string
  type: string
  macAddress: string | null
  plantId: string
  snmpPort: number
  snmpCommunityEnc: string
  snmpVersion: string
}

/** Statistiche zero (apparato muto): NESSUN campo inventato. */
const EMPTY_L2_STATS = {
  lldpNeighbors: 0,
  cdpNeighbors: 0,
  fdbEntries: 0,
  vlanFdbEntries: 0,
  arpEntries: 0,
  stpPorts: 0,
  vlans: 0,
  matchedLinks: 0,
  unmatchedNeighbors: 0,
  sharedPorts: 0,
  unmatchedMacsWithIp: 0,
  observations: 0,
} as const

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response
  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Solo TECNICO o ruoli superiori possono eseguire la sonda Layer-2', 403)
  }

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = DiscoveryL2BatchInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri del batch L2 non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  /* FIX W21 (multi-impianto): il client API v2 inietta l'impianto ATTIVO
   * come ?plantId= (v2Url) — il body lo può confermare, ma senza questa
   * lettura la rotta ricadeva sul primo impianto creato, ignorando
   * quello selezionato dall'operatore. */
  const queryPlantId = new URL(req.url).searchParams.get('plantId')

  /* --- impianto --- */
  const plant = await resolvePlant(input.plantId ?? queryPlantId ?? undefined)
  if (!plant.ok) return plant.response
  const p = plant.plant

  /* --- selezione target: esplicita o automatica (per tipo) --- */
  let devices: BatchDevice[]
  if (input.deviceIds) {
    const uniqueIds = [...new Set(input.deviceIds)]
    const rows = await db.device.findMany({ where: { id: { in: uniqueIds } }, select: DEVICE_SELECT })
    const byId = new Map(rows.map((r) => [r.id, r as BatchDevice]))
    for (const id of uniqueIds) {
      const d = byId.get(id)
      if (!d || d.plantId !== p.id) {
        return fail('NOT_FOUND', 'Dispositivo non trovato nell\'impianto', 404)
      }
    }
    devices = uniqueIds.map((id) => byId.get(id) as BatchDevice)
  } else {
    devices = await db.device.findMany({
      where: { plantId: p.id, decommissionedAt: null, type: { in: L2_BATCH_TYPES } },
      select: DEVICE_SELECT,
      orderBy: { hostname: 'asc' },
    }) as BatchDevice[]
  }

  /* --- cap 12: avviso onesto, NON errore (l'operatore spezza) --- */
  const warnings: string[] = []
  if (devices.length > MAX_BATCH_SWITCHES) {
    warnings.push(`target limitati a ${MAX_BATCH_SWITCHES} su ${devices.length} apparati candidati (cap batch — ripetere per i restanti)`)
    devices = devices.slice(0, MAX_BATCH_SWITCHES)
  }

  /* --- community per dispositivo + target dedup per ip:porta ---
   * Due dispositivi sullo STESSO ip:porta SNMP sono un'anomalia di
   * inventario: si sonda UNA volta (la prima per hostname) e si
   * dichiara lo skip — MAI attribuire la stessa sonda a due deviceId. */
  const targets: Array<{ ip: string; port: number; version: 'v1' | 'v2c' | 'v3'; communities: string[]; device: BatchDevice }> = []
  const seenEndpoints = new Set<string>()
  for (const d of devices) {
    const port = d.snmpPort || 161
    const key = `${d.ip}:${port}`
    if (seenEndpoints.has(key)) {
      const first = targets.find((t) => t.ip === d.ip && t.port === port)
      warnings.push(`${d.hostname} (${key}) escluso dal batch: stesso endpoint SNMP di ${first?.device.hostname ?? key} — verificare l'inventario`)
      continue
    }
    seenEndpoints.add(key)

    const communities: string[] = []
    const pushCommunity = (c: string) => {
      const t = c.trim()
      if (t !== '' && !communities.includes(t)) communities.push(t)
    }
    if (d.snmpCommunityEnc) {
      const plain = decryptSecret(d.snmpCommunityEnc)
      if (plain) pushCommunity(plain)
    }
    for (const c of input.communities ?? []) pushCommunity(c)
    if (communities.length === 0) pushCommunity('public')

    const version: 'v1' | 'v2c' | 'v3' = d.snmpVersion === 'v1' || d.snmpVersion === 'v3' ? d.snmpVersion : 'v2c'
    targets.push({ ip: d.ip, port, version, communities, device: d })
  }

  /* --- sonda batch verso il mini-service (skip onesto se vuota) --- */
  let job: {
    concurrency: number
    durationMs: number
    total: number
    reachable: number
    results: Array<{ ip: string; port: number } & L2ProbePayload & { error?: string; detail?: string }>
  } | null = null
  if (targets.length === 0) {
    warnings.push('nessun apparato SWITCH/GATEWAY/ROUTER/FIREWALL attivo nell\'impianto — batch vuoto')
  } else {
    const pr = await discoveryPost(
      '/probe/l2/batch',
      {
        targets: targets.map((t) => ({ ip: t.ip, port: t.port, version: t.version, communities: t.communities })),
        concurrency: input.concurrency ?? 2,
        timeoutMs: input.timeoutMs ?? 2000,
        walkTimeoutMs: 1500,
      },
      { timeoutMs: BATCH_PROXY_TIMEOUT_MS },
    )
    if (!pr.ok) return proxyFail(pr)

    const wrapped = pr.body as {
      job?: {
        concurrency: number
        durationMs: number
        total: number
        reachable: number
        results: Array<{ ip: string; port: number } & L2ProbePayload & { error?: string; detail?: string }>
      }
    }
    job = wrapped.job ?? null
    if (!job) {
      return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
    }
  }

  /* --- inventario del plant (per l'abbinamento vicini/MAC) --- */
  const rows = await db.device.findMany({
    where: { plantId: p.id, decommissionedAt: null },
    select: { id: true, hostname: true, ip: true, macAddress: true, type: true },
  })
  const inventory: InventoryDevice[] = rows.map((r) => ({
    id: r.id,
    ip: r.ip,
    hostname: r.hostname,
    macAddress: r.macAddress ?? '',
    type: r.type,
  }))

  /* --- matching risultati → dispositivi, ricostruzione per switch --- */
  const probeByEndpoint = new Map<string, NonNullable<typeof job>['results'][number]>()
  if (job) {
    for (const r of job.results) probeByEndpoint.set(`${r.ip}:${r.port}`, r)
  }

  const correlatorSwitches: CorrelatorSwitch[] = []
  const reconstructions = new Map<string, ReturnType<typeof l2Reconstruct>>()
  const perSwitch: L2BatchSwitchResult[] = []

  for (const t of targets) {
    const probe = probeByEndpoint.get(`${t.ip}:${t.port}`)
    if (!probe) {
      // onestà difensiva: il servizio dichiara una riga per target
      perSwitch.push({
        deviceId: t.device.id, hostname: t.device.hostname, ip: t.device.ip,
        reachable: false, matched: null, sysName: null,
        stats: { ...EMPTY_L2_STATS },
        warnings: ['il servizio discovery non ha riportato risultato per questo target'],
      })
      continue
    }
    if (!probe.reachable) {
      perSwitch.push({
        deviceId: t.device.id, hostname: t.device.hostname, ip: t.device.ip,
        reachable: false, matched: null, sysName: null,
        stats: { ...EMPTY_L2_STATS },
        warnings: [
          `SNMP non raggiungibile su ${t.ip}:${t.port} — community tentate: ${t.communities.join(', ')}`,
          ...(probe.error ? [`${probe.error}${probe.detail ? ` — ${probe.detail}` : ''}`] : []),
        ],
      })
      continue
    }

    const switchDevice: InventoryDevice = {
      id: t.device.id,
      ip: t.device.ip,
      hostname: t.device.hostname,
      macAddress: t.device.macAddress ?? '',
      type: t.device.type,
    }
    correlatorSwitches.push({ device: switchDevice, probe })
    const reconstruction = l2Reconstruct(probe, inventory, switchDevice)
    reconstructions.set(t.device.id, reconstruction)
    perSwitch.push({
      deviceId: t.device.id,
      hostname: t.device.hostname,
      ip: t.device.ip,
      reachable: true,
      matched: probe.matched ?? null,
      sysName: probe.sysName ?? null,
      stats: {
        lldpNeighbors: reconstruction.stats.lldpNeighbors,
        cdpNeighbors: reconstruction.stats.cdpNeighbors,
        fdbEntries: reconstruction.stats.fdbEntries,
        vlanFdbEntries: reconstruction.stats.vlanFdbEntries,
        arpEntries: reconstruction.stats.arpEntries,
        stpPorts: reconstruction.stats.stpPorts,
        vlans: reconstruction.stats.vlans,
        matchedLinks: reconstruction.stats.matchedLinks,
        unmatchedNeighbors: reconstruction.stats.unmatchedNeighbors,
        sharedPorts: reconstruction.stats.sharedPorts,
        unmatchedMacsWithIp: reconstruction.stats.unmatchedMacsWithIp,
        observations: reconstruction.stats.observations,
      },
      warnings: reconstruction.warnings,
    })
  }

  /* --- correlazione UNA volta su tutte le sonde raggiunte --- */
  const correlation = l2Correlate(correlatorSwitches, inventory)

  /* --- persistenza: stessa logica della rotta singola (l2-persist) --- */
  let observationsSaved = 0
  let arpSaved = 0
  let stpSaved = 0
  let vlanSaved = 0
  const linkCounters = { linksCreated: 0, linksUpdated: 0, linksSkippedOperator: 0 }
  /** Coppia (idA|idB ordinati) → evidenza che l'ha coperta in QUESTA
   *  esecuzione: serve alla precedenza LLDP/CDP > FDB_MUTUAL > … */
  const coveredPairs = new Map<string, string>()

  for (const sw of correlatorSwitches) {
    const reconstruction = reconstructions.get(sw.device.id)
    if (!reconstruction) continue // difensivo: non dovrebbe accadere

    /* (a) FDB: budget TOTALE condiviso tra tutti gli switch */
    const budget = MAX_BATCH_OBSERVATIONS - observationsSaved
    const savedObs = await persistFdbObservations({
      plantId: p.id,
      deviceId: sw.device.id,
      observations: reconstruction.observations,
      budget,
    })
    observationsSaved += savedObs
    if (savedObs < reconstruction.observations.length) {
      warnings.push(`osservazioni MAC di ${sw.device.hostname}: persistite ${savedObs} su ${reconstruction.observations.length} (cap batch ${MAX_BATCH_OBSERVATIONS})`)
    }

    /* (b) ARP / STP / VLAN per apparato (cap per sonda, contatori batch) */
    const savedArp = await persistArpEntries({ plantId: p.id, deviceId: sw.device.id, arp: reconstruction.arp })
    arpSaved += savedArp
    if (reconstruction.stats.arpEntries > MAX_PERSISTED_ARP_ROWS) {
      warnings.push(`voci ARP di ${sw.device.hostname} persistite limitate a ${MAX_PERSISTED_ARP_ROWS} su ${reconstruction.stats.arpEntries}`)
    }

    stpSaved += await persistStpObservations({ plantId: p.id, deviceId: sw.device.id, probe: sw.probe })
    if (reconstruction.stats.stpPorts > MAX_PERSISTED_STP_PORTS) {
      warnings.push(`porte STP di ${sw.device.hostname} persistite limitate a ${MAX_PERSISTED_STP_PORTS} su ${reconstruction.stats.stpPorts}`)
    }

    const savedVlan = await persistVlanInventory({ plantId: p.id, deviceId: sw.device.id, vlans: reconstruction.vlans })
    vlanSaved += savedVlan
    if (reconstruction.stats.vlans > MAX_PERSISTED_VLANS) {
      warnings.push(`VLAN di ${sw.device.hostname} limitate a ${MAX_PERSISTED_VLANS} su ${reconstruction.stats.vlans}`)
    }

    /* (c) link endpoint (LLDP/CDP/FDB/DAISY_CHAIN) — regola operatore */
    for (const link of reconstruction.links) {
      const outcome = await persistInferredLink({
        plantId: p.id,
        sourceDeviceId: link.switchDeviceId,
        targetDeviceId: link.targetDeviceId,
        sourcePort: link.sourcePort,
        targetPort: link.targetPort,
        sourceOfTruth: link.sourceOfTruth,
        confidence: link.confidence,
        evidence: link.evidence,
        speedMbps: link.speedMbps,
        notes: `ricostruzione L2 batch v16.15 — ${link.detail}`,
      })
      countLinkOutcome(outcome, linkCounters)
      coveredPairs.set([link.switchDeviceId, link.targetDeviceId].sort().join('|'), link.sourceOfTruth)
    }
  }

  /* --- link switch↔switch dal correlatore (precedenza per coppia) --- */
  /** Rango delle evidenze: chi dichiara vince su chi inferisce; l'avvistamento
   *  reciproco (FDB_MUTUAL) vale più del singolo FDB_ENDPOINT perché porta le
   *  porte di ENTRAMBI i lati e (spesso) la direzione STP. */
  const EVIDENCE_RANK: Record<string, number> = {
    LLDP: 5, CDP: 5,
    FDB_MUTUAL: 4, FDB_PAIR: 3, STP_DESIGNATED: 3,
    FDB: 2, DAISY_CHAIN: 1,
  }
  for (const link of correlation.switchLinks) {
    const pairKey = [link.upstreamDeviceId, link.downstreamDeviceId].sort().join('|')
    const coveredBy = coveredPairs.get(pairKey)
    const coveredRank = coveredBy !== undefined ? (EVIDENCE_RANK[coveredBy] ?? 2) : 0
    const linkRank = EVIDENCE_RANK[link.kind] ?? 2
    if (coveredBy !== undefined && coveredRank >= linkRank) {
      // dichiarazione/dichiarazione equivalente già persistita: niente doppioni
      warnings.push(`link correlatore ${link.upstreamHostname}↔${link.downstreamHostname} non persistito: coppia già coperta da ${coveredBy} in questa esecuzione`)
      continue
    }
    coveredPairs.set(pairKey, link.kind)
    if (coveredBy !== undefined && coveredRank < linkRank) {
      warnings.push(`link ${link.upstreamHostname}↔${link.downstreamHostname} promosso a ${link.kind}: porte di entrambi i lati (era ${coveredBy})`)
    }
    const outcome = await persistInferredLink({
      plantId: p.id,
      sourceDeviceId: link.upstreamDeviceId,
      targetDeviceId: link.downstreamDeviceId,
      sourcePort: link.upstreamPort,
      targetPort: link.downstreamPort,
      sourceOfTruth: link.kind,
      confidence: link.confidence,
      evidence: link.evidence,
      speedMbps: link.upstreamSpeedMbps || link.downstreamSpeedMbps,
      notes: `ricostruzione L2 batch v16.15 — ${link.detail}`,
    })
    countLinkOutcome(outcome, linkCounters)
  }
  const { linksCreated, linksUpdated, linksSkippedOperator } = linkCounters

  const reachableCount = correlatorSwitches.length

  /* --- audit: la SINTESI dell'esecuzione (niente IP nel dettaglio) --- */
  try {
    await db.auditLog.create({
      data: {
        action: 'TOPOLOGY_L2_BATCH_SCAN',
        actor: session.session.user.email ?? 'sconosciuto',
        plantId: p.id,
        targetId: null,
        targetLabel: `batch ${targets.length} apparati L2`,
        details: JSON.stringify({
          scanned: targets.length,
          reachable: reachableCount,
          concurrency: job?.concurrency ?? input.concurrency ?? 2,
          durationMs: job?.durationMs ?? 0,
          switchLinks: correlation.switchLinks.length,
          linksCreated,
          linksUpdated,
          linksSkippedOperator,
          observationsSaved,
          arpSaved,
          stpSaved,
          vlanSaved,
          rootBridgeMac: correlation.rootBridgeMac,
          warnings: warnings.slice(0, 5),
        }),
      },
    })
  } catch {
    /* l'audit non deve bloccare la risposta */
  }

  const data = {
    scanned: targets.length,
    reachable: reachableCount,
    concurrency: job?.concurrency ?? input.concurrency ?? 2,
    durationMs: job?.durationMs ?? 0,
    switchLinks: correlation.switchLinks,
    rootBridgeMac: correlation.rootBridgeMac,
    rootVotes: correlation.rootVotes,
    rootPorts: correlation.rootPorts,
    arpCandidates: correlation.arpCandidates,
    perSwitch,
    persistence: {
      linksCreated,
      linksUpdated,
      linksSkippedOperator,
      observationsSaved,
      arpSaved,
      stpSaved,
      vlanSaved,
    },
    warnings: [...warnings, ...correlation.warnings],
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(DiscoveryL2BatchResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
