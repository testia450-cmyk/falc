/* ================================================================
 * /api/v2/discovery/scan — POST
 * Domanda a cui risponde (§ ondata W3.4): «Chi c'è su questa rete?»
 * Sweep TCP-connect multi-porta portato da v15 (pingHost di
 * agents/core.ts: UP = almeno una porta risponde, latenza = minima).
 * · auth + zod QUI, motore nel mini-service :3002;
 * · CIDR fino a 256 host (il servizio rifiuta oltre con TOO_LARGE);
 * · risultato SOLO host vivi: una rete muta torna lista vuota
 *   (ONESTO, non errore);
 * · audit DISCOVERY_SCAN: chi ha scansito quale intervallo e con
 *   quale esito (tracciabilità dell'operazione di rete, come v15).
 * Ambiente sandbox: la scansione raggiunge solo la rete del server
 * demo (127.0.0.1) — in produzione su sito funziona sull'impianto.
 * ================================================================ */

import { z } from 'zod'
import { db } from '@/lib/db'
import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { devValidate } from '@/app/api/v2/shared'
import { DiscoveryScanInputSchema, DiscoveryScanResultSchema } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

const BodySchema = DiscoveryScanInputSchema

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = BodySchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri di scansione non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const pr = await discoveryPost('/scan', input)
  if (!pr.ok) return proxyFail(pr)

  /* Il servizio incapsula in { ok, job: {...} } — qui si scarta la
   * busta interna e si incapsula in quella v2. I campi v16.8
   * (adaptive, secondPass, slowHosts) sono opzionali nel contratto. */
  const wrapped = pr.body as { job?: {
    cidr: string
    adaptive?: boolean
    durationMs: number
    hosts: Array<{ ip: string; alive: true; latencyMs: number; secondPass?: boolean; openPorts: Array<{ port: number; state: string }> }>
    summary: { scanned: number; up: number; withOpenPorts: number; slowHosts?: number }
  } }
  const job = wrapped.job
  if (!job) return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })
  const data = {
    cidr: job.cidr,
    adaptive: job.adaptive,
    durationMs: job.durationMs,
    hosts: job.hosts,
    summary: job.summary,
  }

  /* Audit dell'operazione di rete (chi/scansito che cosa/esito):
   * niente IP singoli nel dettaglio — solo il sintesi, il range è
   * già nel targetLabel. */
  const email = session.session.user.email ?? 'sconosciuto'
  try {
    await db.auditLog.create({
      data: {
        action: 'DISCOVERY_SCAN',
        actor: email,
        targetId: null,
        targetLabel: input.cidr,
        details: JSON.stringify({
          cidr: input.cidr,
          ports: input.ports ?? null, // null = set v15 di default
          scanned: data.summary.scanned,
          up: data.summary.up,
          durationMs: data.durationMs,
        }),
      },
    })
  } catch {
    /* l'audit non deve bloccare la risposta della scansione */
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(DiscoveryScanResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
