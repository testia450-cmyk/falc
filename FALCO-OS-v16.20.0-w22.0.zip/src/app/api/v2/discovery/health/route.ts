/* ================================================================
 * /api/v2/discovery/health — GET
 * Domanda a cui risponde: «Il motore di scansione è attivo? Quali
 * capacità offre? Quanti prefissi OUI contiene il database IEEE?»
 * Proxy pass-through del mini-service discovery (:3002): auth qui,
 * verità lì. Un servizio spento NON è un errore del NOC: 503 con
 * messaggio operativo (l'ondata discovery è facoltativa e il resto
 * della console continua a funzionare).
 * ================================================================ */

import { ok, requireSession } from '@/lib/v2/api-helpers'
import { devValidate } from '@/app/api/v2/shared'
import { DiscoveryHealthSchema } from '@/lib/v2/contracts'
import { discoveryGet, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

export async function GET() {
  const session = await requireSession()
  if (!session.ok) return session.response

  const pr = await discoveryGet('/health')
  if (!pr.ok) return proxyFail(pr)

  const svc = pr.body as { service: string; uptimeSec: number; version: string; capabilities: string[]; oui: { total: number; brands: number } }
  const data = {
    service: svc.service,
    uptimeSec: svc.uptimeSec,
    version: svc.version,
    capabilities: svc.capabilities,
    oui: svc.oui,
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(DiscoveryHealthSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
