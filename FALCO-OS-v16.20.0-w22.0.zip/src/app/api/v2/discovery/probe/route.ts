/* ================================================================
 * /api/v2/discovery/probe — POST
 * Domanda a cui risponde: «Che apparato è questo IP?»
 * Sonda combinata portata da v15: port-scan + banner HTTP + SNMP
 * (sysDescr/sysObjectID → vendor da enterprise OID) + ONVIF
 * GetDeviceInformation (marca/modello/firmware/seriale/hw) + OUI.
 * Fusione evidenze con priorità v15: ONVIF > SNMP > banner > porte.
 * · auth + zod QUI, motori nel mini-service :3002;
 * · host muto = alive:false con evidenze vuote (ONESTO);
 * · NESSUNA scrittura su DB: la sonda non tocca l'inventario
 *   (l'adozione resta un'azione umana esplicita, § /api/v2/adozione).
 * ================================================================ */

import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { devValidate } from '@/app/api/v2/shared'
import { VendorProbeInputSchema, VendorProbeResultSchema } from '@/lib/v2/contracts'
import { discoveryPost, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  let raw: unknown
  try {
    raw = await req.json()
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non leggibile (JSON atteso)', 422)
  }
  const parsed = VendorProbeInputSchema.safeParse(raw)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Parametri della sonda non validi', 422, parsed.error.issues?.map((i) => ({ path: i.path.map(String).join('.'), message: i.message })))
  }
  const input = parsed.data

  const pr = await discoveryPost('/probe/vendor', input)
  if (!pr.ok) return proxyFail(pr)

  /* Il servizio incapsula in { ok, result: {...} } — si scarta la
   * busta interna e si incapsula in quella v2. I campi v16.8
   * (slowHost, matched, product, os/realm/cert) sono opzionali nel
   * contratto: passati TALI QUALE, assenti se la sonda non li ha. */
  const wrapped = pr.body as { result?: {
    ip: string
    alive: boolean
    latencyMs: number | null
    slowHost?: boolean
    openPorts: Array<{ port: number; state: string }>
    http: {
      server: string | null
      title: string | null
      realm?: string | null
      certCn?: string | null
      certIssuer?: string | null
    } | null
    tls: { cn: string | null; issuer: string | null; validTo: string | null } | null
    snmp: {
      reachable: boolean
      matched?: { community: string; version: string } | null
      sysDescr?: string | null
      sysObjectID?: string | null
      sysName?: string | null
      ifCount?: number | null
      vendorGuess?: { vendor: string; source: string } | null
      product?: { osFamily: string | null; osVersion: string | null; model: string | null; source: string } | null
      error?: string
    } | null
    onvif: {
      reachable: boolean
      manufacturer?: string | null
      model?: string | null
      firmwareVersion?: string | null
      serialNumber?: string | null
      hardwareId?: string | null
      error?: string
    } | null
    oui: { mac: string; vendor: string; category: string } | null
    classification: {
      type: string
      brand: string | null
      model: string | null
      confidence: 'high' | 'medium' | 'low'
      os?: string | null
      osVersion?: string | null
      firmwareVersion?: string | null
      evidence: Array<{ source: string; value: string }>
    }
  } }
  const r = wrapped.result
  if (!r) return proxyFail({ ok: false, status: 502, body: { error: { code: 'BAD_SERVICE_RESPONSE', message: 'Il servizio discovery ha risposto senza il payload atteso' } } })

  const data = {
    ip: r.ip,
    alive: r.alive,
    latencyMs: r.latencyMs,
    slowHost: r.slowHost,
    openPorts: r.openPorts,
    http: r.http,
    snmp: r.snmp,
    onvif: r.onvif,
    oui: r.oui,
    classification: r.classification,
  }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(VendorProbeResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
