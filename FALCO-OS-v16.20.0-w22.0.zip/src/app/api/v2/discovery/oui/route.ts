/* ================================================================
 * /api/v2/discovery/oui — GET ?mac=
 * Domanda a chi risponde: «Di chi è questo MAC?»
 * Lookup sul database IEEE portato da v15 (10.679 prefissi, 101
 * brand, longest-prefix MA-S→MA-M→MA-L). Nessuna invenzione: un
 * MAC non in banca dati = 404 onesto.
 * ================================================================ */

import { fail, ok, requireSession } from '@/lib/v2/api-helpers'
import { devValidate } from '@/app/api/v2/shared'
import { OuiLookupResultSchema } from '@/lib/v2/contracts'
import { discoveryGet, proxyFail } from '@/lib/v2/discovery-proxy'
import { apiMode, getReplayState } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

const MAC_RE = /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const url = new URL(req.url)
  const mac = (url.searchParams.get('mac') ?? '').trim()
  if (!MAC_RE.test(mac)) {
    return fail('BAD_QUERY', 'MAC atteso nel formato AA:BB:CC:DD:EE:FF', 422)
  }

  const pr = await discoveryGet(`/oui?mac=${encodeURIComponent(mac)}`)
  if (!pr.ok) return proxyFail(pr)

  const r = pr.body as { mac: string; prefix: string; vendor: string; category: string; blockType: string }
  const data = { mac: r.mac, prefix: r.prefix, vendor: r.vendor, category: r.category, blockType: r.blockType }

  const replay = await getReplayState()
  const body = { ok: true as const, asOf: Date.now(), mode: apiMode(replay), data }
  devValidate(OuiLookupResultSchema, body)
  return ok(data, Date.now(), apiMode(replay))
}
