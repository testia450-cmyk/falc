/* ================================================================
 * /api/v2/integrations/test — POST (16.7 W7.0)
 * «Questa integrazione riesce a raggiungere la sua destinazione?»
 * Tentativo REALE di connessione con timeout (default 8000 ms):
 *  · http  → GET con UA FALCO-OS/16.7: reachable = res.ok,
 *    statusCode + latencyMs misurati;
 *  · tcp   → net.connect({host, port}): porta aperta = reachable
 *    (statusCode null: TCP non ha status HTTP);
 *  · telegram → getMe con il token del corpo: 200+ok → «bot valido:
 *    <username>»; 401 → «token rifiutato da Telegram»;
 *  · webhook → NON gestito qui: 422 BAD_KIND (si testa da
 *    /integrations/webhooks/[id]/test, consegna firmata HMAC).
 * TUTTI gli esiti sono ONESTI: in sandbox senza internet i fallimenti
 * di rete sono DICHIARATI (DNS non risolvibile / timeout / errore
 * reale) — mai un «test superato» inventato.
 *  · Audit INTEGRATION_TEST {kind, target} PRIMA del tentativo (traccia
 *    chi ha testato cosa — MAI il token, MAI query segrete nel target);
 *  · il token Telegram NON viene salvato da nessuna parte e NON può
 *    comparire in target/detail/audit (sanitizzazione difensiva).
 * Nessuna scrittura su DB oltre all'audit. Role ≥ TECNICO.
 * ================================================================ */

import net from 'net'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import { IntegrationTestInputSchema, IntegrationTestResultSchema } from '@/lib/v2/contracts'
import { devValidate } from '@/app/api/v2/shared'
import { hasRole } from '@/lib/auth'
import { getReplayState, apiMode } from '@/lib/v2/derive'

export const dynamic = 'force-dynamic'

/** Timeout di default per ogni tentativo (ms). */
const DEFAULT_TIMEOUT_MS = 8000

/** Esito comune dei tre tipi di test. */
type TestOutcome = {
  reachable: boolean
  statusCode: number | null
  latencyMs: number
  detail: string
}

/** Classificazione ONESTA dell'errore di rete: DNS non risolvibile,
 *  timeout, oppure l'errore reale riportato com'è (mai inventato). */
function honestNetworkDetail(err: unknown, timeoutMs: number): string {
  const name = err instanceof Error ? err.name : ''
  const message = err instanceof Error ? err.message : String(err)
  const causeCode = err instanceof Error && err.cause && typeof err.cause === 'object'
    && 'code' in (err.cause as Record<string, unknown>)
    ? String((err.cause as { code: unknown }).code)
    : ''
  const all = `${name} ${message} ${causeCode}`
  if (name === 'AbortError' || name === 'TimeoutError' || /timeout|timed?\s*out/i.test(all)) {
    return `timeout: nessuna risposta entro ${timeoutMs} ms`
  }
  if (/ENOTFOUND|EAI_AGAIN|getaddrinfo|dns/i.test(all)) {
    return 'DNS non risolvibile'
  }
  return `errore di rete: ${message || name || 'sconosciuto'}`
}

/** URL senza query string (le query possono portare token segreti:
 *  il target del test non le contiene MAI). */
function httpTarget(url: string): string {
  try {
    const u = new URL(url)
    return `${u.protocol}//${u.host}${u.pathname}`
  } catch {
    return url
  }
}

/** Tentativo HTTP reale (GET, UA FALCO-OS/16.7, timeout AbortController). */
async function httpTest(url: string, timeoutMs: number): Promise<TestOutcome> {
  const start = Date.now()
  const ac = new AbortController()
  const timer = setTimeout(() => ac.abort(), timeoutMs)
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { 'User-Agent': 'FALCO-OS/16.7' },
      signal: ac.signal,
    })
    const latencyMs = Date.now() - start
    return {
      reachable: res.ok,
      statusCode: res.status,
      latencyMs,
      detail: res.ok
        ? `HTTP ${res.status}: destinazione raggiungibile`
        : `HTTP ${res.status}: raggiunta, ma risposta non 2xx`,
    }
  } catch (err) {
    return {
      reachable: false,
      statusCode: null,
      latencyMs: Date.now() - start,
      detail: honestNetworkDetail(err, timeoutMs),
    }
  } finally {
    clearTimeout(timer)
  }
}

/** Tentativo TCP reale (net.connect): porta aperta = reachable.
 *  statusCode null: TCP non ha codici di stato HTTP. */
function tcpTest(host: string, port: number, timeoutMs: number): Promise<TestOutcome> {
  return new Promise((resolve) => {
    const start = Date.now()
    const socket = net.connect({ host, port })
    let settled = false
    const finish = (reachable: boolean, detail: string) => {
      if (settled) return
      settled = true
      socket.destroy()
      resolve({ reachable, statusCode: null, latencyMs: Date.now() - start, detail })
    }
    socket.setTimeout(timeoutMs, () => finish(false, `timeout: nessuna risposta entro ${timeoutMs} ms`))
    socket.once('connect', () => finish(true, `porta ${port} aperta su ${host}`))
    socket.once('error', (err: Error) => {
      const code = (err as NodeJS.ErrnoException).code ?? ''
      if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') finish(false, 'DNS non risolvibile')
      else if (code === 'ECONNREFUSED') finish(false, `connessione rifiutata sulla porta ${port}`)
      else if (code === 'ETIMEDOUT') finish(false, `timeout: nessuna risposta entro ${timeoutMs} ms`)
      else finish(false, `errore di rete: ${err.message}`)
    })
  })
}

/** Tentativo Telegram reale (getMe con il token del corpo — NON salvato).
 *  La risposta valida il token: 200+ok → bot valido con username. */
async function telegramTest(token: string, timeoutMs: number): Promise<TestOutcome> {
  const start = Date.now()
  const ac = new AbortController()
  const timer = setTimeout(() => ac.abort(), timeoutMs)
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/getMe`, { signal: ac.signal })
    const latencyMs = Date.now() - start
    if (res.status === 401) {
      return { reachable: false, statusCode: 401, latencyMs, detail: 'token rifiutato da Telegram' }
    }
    if (res.ok) {
      const json = await res.json() as { ok?: boolean; result?: { username?: string } } | null
      if (json?.ok === true && typeof json.result?.username === 'string') {
        return { reachable: true, statusCode: res.status, latencyMs, detail: `bot valido: ${json.result.username}` }
      }
      /* 200 ma corpo inatteso: onesto, nessuna inferenza */
      return { reachable: false, statusCode: res.status, latencyMs, detail: `risposta inattesa da Telegram (HTTP ${res.status} senza esito ok)` }
    }
    return { reachable: false, statusCode: res.status, latencyMs, detail: `HTTP ${res.status} da api.telegram.org` }
  } catch (err) {
    /* Sanitizzazione difensiva: il token NON può comparire nel dettaglio
     * (alcuni runtime includono l'URL — e quindi il token — nel messaggio). */
    const detail = honestNetworkDetail(err, timeoutMs).split(token).join('***')
    return { reachable: false, statusCode: null, latencyMs: Date.now() - start, detail }
  } finally {
    clearTimeout(timer)
  }
}

/* ---------------------------------------------------------------- */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { kind, url? | host+port? | token?, timeoutMs? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con kind e i parametri del test)', 422)
  }
  const parsed = IntegrationTestInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* I webhook hanno la loro rotta di test dedicata (consegna firmata). */
  if (input.kind === 'webhook') {
    return fail('BAD_KIND', 'i webhook si testano da /integrations/webhooks/[id]/test', 422)
  }

  const timeoutMs = input.timeoutMs ?? DEFAULT_TIMEOUT_MS

  /* Target pubblico del test (MAI il token, MAI query segrete). */
  const target =
    input.kind === 'http' ? httpTarget(input.url!)
      : input.kind === 'tcp' ? `${input.host}:${input.port}`
        : 'api.telegram.org'

  const email = session.session.user.email ?? 'sconosciuto'

  /* Audit PRIMA del tentativo: traccia chi ha testato cosa (kind e
   * target soltanto — mai token, mai segreti). Non blocca il test. */
  try {
    await db.auditLog.create({
      data: {
        action: 'INTEGRATION_TEST',
        actor: email,
        targetId: null,
        targetLabel: target.slice(0, 80),
        plantId: null,
        details: JSON.stringify({ kind: input.kind, target }),
      },
    })
  } catch {
    /* l'audit non deve bloccare il tentativo di connessione */
  }

  /* --- Tentativo REALE per kind --- */
  let outcome: TestOutcome
  if (input.kind === 'http') {
    outcome = await httpTest(input.url!, timeoutMs)
  } else if (input.kind === 'tcp') {
    outcome = await tcpTest(input.host!, input.port!, timeoutMs)
  } else {
    outcome = await telegramTest(input.token!, timeoutMs)
  }

  const data = {
    kind: input.kind,
    target,
    reachable: outcome.reachable,
    statusCode: outcome.statusCode,
    latencyMs: outcome.latencyMs,
    detail: outcome.detail,
  }

  const asOf = Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(IntegrationTestResultSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}
