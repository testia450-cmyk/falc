/* ================================================================
 * /api/v2/integrations — GET · POST (upsert) · DELETE (16.7 W7.0)
 * Configurazioni delle integrazioni esterne (modello IntegrationConfig,
 * porta v15): SMTP, Telegram, osTicket, Grafana, … — chiave univoca
 * «smtp.host» / «telegram.botToken:PLANT-X», valore SEMPRE cifrato
 * AES-256-GCM (crypto.ts, chiave master in env DEVICE_CREDENTIALS_KEY).
 *  · GET (qualsiasi sessione): elenco ordinato category asc, key asc;
 *    value REALE solo per righe isSecret=false decifrabili, altrimenti
 *    maschera "***" + hasValue (MAI il segreto in risposta);
 *    webhooks: [] placeholder — la UI chiama /integrations/webhooks;
 *  · POST (role ≥ TECNICO): upsert by key (findUnique → update/create
 *    in $transaction + audit INTEGRATION_UPSERT {key, category,
 *    isSecret, enabled, created} — MAI il value); senza chiave master
 *    → 422 KEY_MISSING (nessun fallback a testo in chiaro); risponde
 *    201 (creazione) / 200 (aggiornamento) con la riga mascherata;
 *  · DELETE ?id= (role ≥ TECNICO): 404 se assente, delete + audit
 *    INTEGRATION_DELETE {key, category} in $transaction → {id}.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import {
  IntegrationsPageSchema, IntegrationConfigRowSchema, UpsertIntegrationInputSchema,
  type IntegrationConfigRow,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { encryptSecret, hasMasterKey, decryptSecret } from '@/lib/crypto'

export const dynamic = 'force-dynamic'

/** Query della DELETE: ?id= (id della riga da eliminare). */
const DeleteQuerySchema = z.object({ id: z.string().min(1, 'id richiesto') })

/** Risposta della DELETE: {id} della riga eliminata. */
const DeletedSchema = z.object({ id: z.string() })

/** Riga grezza del modello interessata dal serializzatore (allowlist). */
type ConfigRow = {
  id: string
  key: string
  category: string
  value: string
  isSecret: boolean
  enabled: boolean
  note: string
  updatedBy: string | null
  updatedAt: Date
}

/** Serializza una riga IntegrationConfig nel contratto:
 *  · isSecret=false → valore REALE via decryptSecret (decrypt fallito,
 *    es. chiave rotata → "***" onesto, hasValue resta true: il valore
 *    ESISTE ma non è leggibile);
 *  · isSecret=true → SEMPRE "***" (il segreto non esce mai);
 *  · hasValue = true se la riga esiste con un valore salvato. */
function toIntegrationRow(c: ConfigRow): IntegrationConfigRow {
  let value = '***'
  if (!c.isSecret) {
    const plain = decryptSecret(c.value)
    value = plain ?? '***' // decrypt fallito → maschera, mai crash
  }
  return {
    id: c.id,
    key: c.key,
    category: c.category,
    value,
    isSecret: c.isSecret,
    enabled: c.enabled,
    note: c.note,
    updatedBy: c.updatedBy ?? '',
    updatedAt: c.updatedAt.getTime(),
    hasValue: c.value !== '',
  }
}

/* ---------------------------------------------------------------- */

export async function GET() {
  const session = await requireSession()
  if (!session.ok) return session.response

  const configs = await db.integrationConfig.findMany({
    orderBy: [{ category: 'asc' }, { key: 'asc' }],
  })

  /* Categorie DISTINTE reali (l'ordinamento category asc le lascia
   * già in ordine deterministico). */
  const categories: string[] = []
  for (const c of configs) {
    if (!categories.includes(c.category)) categories.push(c.category)
  }

  const data = {
    configs: configs.map(toIntegrationRow),
    webhooks: [] as string[], // placeholder: la UI chiama /integrations/webhooks
    totalConfigs: configs.length,
    categories,
  }

  const asOf = maxOf(...configs.map((c) => c.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(IntegrationsPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { key, category, value, isSecret?, note?, enabled? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con key, category, value)', 422)
  }
  const parsed = UpsertIntegrationInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* --- Chiave master AES: senza di essa NESSUN valore viene salvato
   *      (mai fallback a testo in chiaro — onestà di sicurezza). --- */
  if (!hasMasterKey()) {
    return fail('KEY_MISSING', 'chiave master AES assente: configurare DEVICE_CREDENTIALS_KEY', 422)
  }
  const enc = encryptSecret(input.value)
  if (enc === null) {
    return fail('KEY_MISSING', 'chiave master AES assente: configurare DEVICE_CREDENTIALS_KEY', 422)
  }

  /* --- Upsert by key (key è @unique): findUnique → update/create --- */
  const existing = await db.integrationConfig.findUnique({ where: { key: input.key } })
  const email = session.session.user.email ?? 'sconosciuto'

  const saved = await db.$transaction(async (tx) => {
    let row: ConfigRow
    let created: boolean
    if (existing) {
      /* Update: il valore è SEMPRE ricifrato con l'input attuale (e il
       * nuovo flag isSecret: il mask in lettura segue il flag fresco). */
      row = await tx.integrationConfig.update({
        where: { id: existing.id },
        data: {
          category: input.category,
          value: enc,
          isSecret: input.isSecret ?? existing.isSecret,
          enabled: input.enabled ?? existing.enabled,
          note: input.note ?? existing.note,
          updatedBy: email,
        },
      })
      created = false
    } else {
      row = await tx.integrationConfig.create({
        data: {
          key: input.key,
          category: input.category,
          value: enc,
          isSecret: input.isSecret ?? true,
          enabled: input.enabled ?? true,
          note: input.note ?? '',
          updatedBy: email,
        },
      })
      created = true
    }

    await tx.auditLog.create({
      data: {
        action: 'INTEGRATION_UPSERT',
        actor: email,
        targetId: row.id,
        targetLabel: row.key.slice(0, 80),
        plantId: null, // configurazione globale: nessuno scope impianto
        details: JSON.stringify({
          key: row.key,
          category: row.category,
          isSecret: row.isSecret,
          enabled: row.enabled,
          created, // MAI il value: il segreto non finisce nell'audit
        }),
      },
    })
    return { row, created }
  })

  const data = toIntegrationRow(saved.row)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(IntegrationConfigRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: Date.now(), mode, data }, { status: saved.created ? 201 : 200 })
}

/* ================================================================ */

export async function DELETE(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const q = parseQuery(DeleteQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const existing = await db.integrationConfig.findUnique({ where: { id: q.value.id } })
  if (!existing) return fail('NOT_FOUND', 'Configurazione integrazione non trovata', 404)

  const email = session.session.user.email ?? 'sconosciuto'

  /* --- Delete + audit in transazione (nessun segreto nei details) --- */
  const deletedId = await db.$transaction(async (tx) => {
    await tx.integrationConfig.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'INTEGRATION_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.key.slice(0, 80),
        plantId: null,
        details: JSON.stringify({
          key: existing.key,
          category: existing.category,
        }),
      },
    })
    return existing.id
  })

  const data = { id: deletedId }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(DeletedSchema, data)
  return ok(data, Date.now(), mode)
}
