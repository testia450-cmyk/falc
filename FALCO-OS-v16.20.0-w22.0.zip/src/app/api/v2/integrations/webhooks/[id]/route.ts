/* ================================================================
 * /api/v2/integrations/webhooks/{id} — PATCH · DELETE (16.7 W7.0)
 *  · PATCH (role ≥ TECNICO): campi opzionali {name?, url?, active?,
 *    events?, description?} — corpo vuoto (nessun campo) → 422
 *    NO_CHANGES; url deve essere http(s) (refine locale: il contratto
 *    UpdateWebhookInputSchema ha solo .url(), il check http(s) vive
 *    qui senza toccare contracts.ts); events = SOSTITUZIONE integrale
 *    del filtro (semantica dichiarata, mai merge in silenzio);
 *    update + audit WEBHOOK_UPDATE con diff sintetico from→to in
 *    $transaction; risposta = riga aggiornata (con ultime 10 consegne
 *    + totale, come la GET della collection).
 *  · DELETE (role ≥ TECNICO): le consegne (WebhookDelivery) sono
 *    rimosse A CASCATA dalla relazione onDelete: Cascade dello schema;
 *    delete + audit WEBHOOK_DELETE {name, url, removedDeliveries} in
 *    $transaction → risposta {id}.
 * Nessun segreto esce: hasSecret booleano soltanto.
 * ================================================================ */

import { z } from 'zod'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  WebhookEndpointRowSchema, UpdateWebhookInputSchema, type WebhookEndpointRow,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate } from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Risposta della DELETE: {id} dell'endpoint eliminato. */
const WebhookDeletedSchema = z.object({ id: z.string() })

/** Riga consegna grezza interessata dal serializzatore. */
type DeliveryRow = {
  id: string
  endpointId: string
  eventType: string
  status: string
  attempts: number
  lastStatusCode: number | null
  lastError: string
  latencyMs: number
  deliveredAt: Date | null
  createdAt: Date
}

/** Riga endpoint grezza interessata dal serializzatore. */
type EndpointRow = {
  id: string
  name: string
  url: string
  secret: string
  events: string
  plantId: string | null
  active: boolean
  description: string
  lastDeliveryAt: Date | null
  lastStatus: string
  createdAt: Date
  updatedAt: Date
}

/** Parse difensivo del filtro eventi (JSON string nel modello):
 *  mai crash su JSON corrotto → [] onesto. */
function parseEvents(raw: string): string[] {
  try {
    const v: unknown = JSON.parse(raw || '[]')
    if (!Array.isArray(v)) return []
    return v.filter((e): e is string => typeof e === 'string')
  } catch {
    return []
  }
}

function toDeliveryRow(d: DeliveryRow) {
  return {
    id: d.id,
    endpointId: d.endpointId,
    eventType: d.eventType,
    status: d.status,
    attempts: d.attempts,
    lastStatusCode: d.lastStatusCode ?? null,
    lastError: d.lastError,
    latencyMs: d.latencyMs,
    deliveredAt: d.deliveredAt?.getTime() ?? null,
    createdAt: d.createdAt.getTime(),
  }
}

/** Serializza un endpoint nel contratto: hasSecret = segreto salvato
 *  (il valore NON esce mai); lastStatus/lastDeliveryAt dal DB. */
function toEndpointRow(
  e: EndpointRow,
  deliveries: DeliveryRow[],
  deliveriesTotal: number,
): WebhookEndpointRow {
  return {
    id: e.id,
    name: e.name,
    url: e.url,
    events: parseEvents(e.events),
    plantId: e.plantId,
    active: e.active,
    description: e.description,
    hasSecret: e.secret !== '',
    lastDeliveryAt: e.lastDeliveryAt?.getTime() ?? null,
    lastStatus: e.lastStatus,
    deliveries: deliveries.map(toDeliveryRow),
    deliveriesTotal,
  }
}

/** Riguarda l'endpoint con le ULTIME 10 consegne + totale (per la
 *  risposta PATCH, identica alla GET della collection). */
async function endpointWithDeliveries(id: string): Promise<WebhookEndpointRow | null> {
  const e = await db.webhookEndpoint.findUnique({ where: { id } })
  if (!e) return null
  const [deliveries, total] = await Promise.all([
    db.webhookDelivery.findMany({
      where: { endpointId: id },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    db.webhookDelivery.count({ where: { endpointId: id } }),
  ])
  return toEndpointRow(e, deliveries, total)
}

/* ---------------------------------------------------------------- */

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  /* --- Corpo JSON { name?, url?, active?, events?, description? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo fra name, url, active, events, description)', 422)
  }
  const parsed = UpdateWebhookInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* Almeno un campo: patch vuota → NO_CHANGES esplicito. */
  if (input.name === undefined && input.url === undefined && input.active === undefined
    && input.events === undefined && input.description === undefined) {
    return fail('NO_CHANGES', 'Nessun campo da aggiornare: fornire almeno uno fra name, url, active, events, description', 422)
  }

  /* url http(s): refine locale (il contratto ha solo .url() — il check
   * http(s) vivrebbe nel contratto ma contracts.ts non si tocca). */
  if (input.url !== undefined && !/^https?:\/\//.test(input.url)) {
    return fail('BAD_BODY', 'URL non valido: http(s) richiesto', 422, [{ path: 'url', message: 'http(s) richiesto' }])
  }

  const existing = await db.webhookEndpoint.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Endpoint webhook non trovato', 404)

  /* --- Diff sintetico calcolato PRIMA della scrittura (solo ciò che
   *      cambia davvero: nessun rumore nell'audit) --- */
  const changes: Record<string, unknown> = {}
  if (input.name !== undefined && input.name !== existing.name) {
    changes.name = { from: existing.name, to: input.name }
  }
  if (input.url !== undefined && input.url !== existing.url) {
    changes.url = { from: existing.url, to: input.url }
  }
  if (input.active !== undefined && input.active !== existing.active) {
    changes.active = { from: existing.active, to: input.active }
  }
  if (input.events !== undefined) {
    const current = parseEvents(existing.events)
    if (JSON.stringify([...input.events].sort()) !== JSON.stringify([...current].sort())) {
      changes.events = { from: current, to: input.events }
    }
  }
  if (input.description !== undefined && input.description !== existing.description) {
    changes.description = { from: existing.description.slice(0, 80), to: input.description.slice(0, 80) }
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + audit in transazione (nessun segreto nei details) --- */
  await db.$transaction(async (tx) => {
    const e = await tx.webhookEndpoint.update({
      where: { id: existing.id },
      data: {
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.url !== undefined ? { url: input.url } : {}),
        ...(input.active !== undefined ? { active: input.active } : {}),
        ...(input.events !== undefined ? { events: JSON.stringify(input.events) } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'WEBHOOK_UPDATE',
        actor: email,
        targetId: e.id,
        targetLabel: e.name.slice(0, 80),
        plantId: e.plantId,
        details: JSON.stringify({
          name: e.name,
          changes, // diff from→to dei soli campi realmente modificati
        }),
      },
    })
  })

  const data = await endpointWithDeliveries(existing.id)
  if (!data) return fail('NOT_FOUND', 'Endpoint webhook non trovato', 404)

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(WebhookEndpointRowSchema, data)
  return ok(data, now.getTime(), mode)
}

/* ================================================================ */

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  const existing = await db.webhookEndpoint.findUnique({ where: { id } })
  if (!existing) return fail('NOT_FOUND', 'Endpoint webhook non trovato', 404)

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Delete + audit in transazione: le consegne collegate sono
   *      rimosse A CASCATA dalla relazione (onDelete: Cascade dello
   *      schema Prisma); il conteggio è letto DENTRO la transazione
   *      per essere coerente con la cancellazione (onestà). --- */
  const deletedId = await db.$transaction(async (tx) => {
    const removedDeliveries = await tx.webhookDelivery.count({ where: { endpointId: existing.id } })
    await tx.webhookEndpoint.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'WEBHOOK_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.name.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({
          name: existing.name,
          url: existing.url,
          removedDeliveries,
        }),
      },
    })
    return existing.id
  })

  const data = { id: deletedId }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(WebhookDeletedSchema, data)
  return ok(data, now.getTime(), mode)
}
