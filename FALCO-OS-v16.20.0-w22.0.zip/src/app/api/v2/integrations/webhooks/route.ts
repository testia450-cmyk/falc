/* ================================================================
 * /api/v2/integrations/webhooks — GET · POST (16.7 W7.0)
 * Endpoint webhook USCENTI (modello WebhookEndpoint, porta v12):
 * URL + segreto HMAC per endpoint (AES-256-GCM, crypto.ts) + filtro
 * eventi JSON + scope impianto opzionale (null = globale).
 *  · GET (qualsiasi sessione): elenco orderBy createdAt desc con le
 *    ULTIME 10 consegne per endpoint + totale (hasSecret = segreto
 *    salvato, MAI esposto; date → epoch ms);
 *  · POST (role ≥ TECNICO): crea l'endpoint; secret assente = GENERATO
 *    (randomBytes(24) hex, 48 char) e cifrato; senza chiave master →
 *    422 KEY_MISSING. plantId se fornito deve esistere → 404
 *    PLANT_NOT_FOUND. Audit WEBHOOK_CREATE {name, url, events, plantId,
 *    secretGenerated} — MAI il segreto. Risponde 201 con la riga +
 *    secretOneTime: il segreto GENERATO è restituito IN CHIARO UNA
 *    SOLA VOLTA (l'operatore lo salva subito: non sarà più recuperabile,
 *    nel DB resta solo il ciphertext) — null se fornito dall'utente.
 *    Lo schema della riga creata estende localmente il contratto con
 *    secretOneTime (contracts.ts non viene toccato).
 * ================================================================ */

import { randomBytes } from 'crypto'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { ok, fail, requireSession } from '@/lib/v2/api-helpers'
import {
  WebhooksPageSchema, WebhookEndpointRowSchema, CreateWebhookInputSchema,
  type WebhookEndpointRow,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import { devValidate, maxOf } from '@/app/api/v2/shared'
import { encryptSecret, hasMasterKey } from '@/lib/crypto'

export const dynamic = 'force-dynamic'

/** Schema LOCALE: riga endpoint + secretOneTime (segreto generato
 *  restituito UNA volta sola alla creazione). Estende il contratto
 *  senza toccare contracts.ts. */
const CreatedWebhookRowSchema = WebhookEndpointRowSchema.extend({
  secretOneTime: z.string().nullable(),
})

/** Riga consegna grezza interessata dal serializzatore. */
type DeliveryRow = {
  id: string
  endpointId: string
  eventType: string
  status: string
  attempts: number
  lastStatusCode: number | null
  lastError: string
  latencyMs: number
  deliveredAt: Date | null
  createdAt: Date
}

/** Riga endpoint grezza interessata dal serializzatore. */
type EndpointRow = {
  id: string
  name: string
  url: string
  secret: string
  events: string
  plantId: string | null
  active: boolean
  description: string
  lastDeliveryAt: Date | null
  lastStatus: string
  createdAt: Date
  updatedAt: Date
}

/** Parse difensivo del filtro eventi (JSON string nel modello):
 *  mai crash su JSON corrotto → [] onesto. */
function parseEvents(raw: string): string[] {
  try {
    const v: unknown = JSON.parse(raw || '[]')
    if (!Array.isArray(v)) return []
    return v.filter((e): e is string => typeof e === 'string')
  } catch {
    return []
  }
}

function toDeliveryRow(d: DeliveryRow) {
  return {
    id: d.id,
    endpointId: d.endpointId,
    eventType: d.eventType,
    status: d.status,
    attempts: d.attempts,
    lastStatusCode: d.lastStatusCode ?? null,
    lastError: d.lastError,
    latencyMs: d.latencyMs,
    deliveredAt: d.deliveredAt?.getTime() ?? null,
    createdAt: d.createdAt.getTime(),
  }
}

/** Serializza un endpoint nel contratto: hasSecret = segreto salvato
 *  (il valore NON esce mai); lastStatus/lastDeliveryAt dal DB. */
function toEndpointRow(
  e: EndpointRow,
  deliveries: DeliveryRow[],
  deliveriesTotal: number,
): WebhookEndpointRow {
  return {
    id: e.id,
    name: e.name,
    url: e.url,
    events: parseEvents(e.events),
    plantId: e.plantId,
    active: e.active,
    description: e.description,
    hasSecret: e.secret !== '',
    lastDeliveryAt: e.lastDeliveryAt?.getTime() ?? null,
    lastStatus: e.lastStatus,
    deliveries: deliveries.map(toDeliveryRow),
    deliveriesTotal,
  }
}

/** Ultime 10 consegne + totale per un endpoint (query per endpoint:
 *  take per-endpoint non esprimibile in una sola query Prisma). */
async function deliveriesOf(endpointId: string): Promise<{ deliveries: DeliveryRow[]; total: number }> {
  const [deliveries, total] = await Promise.all([
    db.webhookDelivery.findMany({
      where: { endpointId },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    db.webhookDelivery.count({ where: { endpointId } }),
  ])
  return { deliveries, total }
}

/* ---------------------------------------------------------------- */

export async function GET() {
  const session = await requireSession()
  if (!session.ok) return session.response

  const endpoints = await db.webhookEndpoint.findMany({
    orderBy: { createdAt: 'desc' },
  })

  const loaded = await Promise.all(
    endpoints.map(async (e) => ({ e, ...(await deliveriesOf(e.id)) })),
  )

  const items = loaded.map(({ e, deliveries, total }) => toEndpointRow(e, deliveries, total))

  const data = { items, total: items.length }

  const asOf = maxOf(
    ...endpoints.map((e) => e.updatedAt.getTime()),
    ...loaded.flatMap((l) => l.deliveries.map((d) => d.createdAt.getTime())),
  ) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(WebhooksPageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, url, secret?, events?, plantId?, description? } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name e url http(s))', 422)
  }
  const parsed = CreateWebhookInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  /* --- Chiave master AES: senza di essa NESSUN segreto viene salvato
   *      (mai fallback a testo in chiaro — onestà di sicurezza). --- */
  if (!hasMasterKey()) {
    return fail('KEY_MISSING', 'chiave master AES assente: configurare DEVICE_CREDENTIALS_KEY', 422)
  }

  /* Segreto: fornito dall'operatore OPPURE generato (48 hex char).
   * Viene cifrato subito; in chiaro sopravvive SOLO nella risposta
   * one-time di questa creazione. */
  const secretProvided = input.secret ?? null
  const secretPlain = secretProvided ?? randomBytes(24).toString('hex')
  const secretEnc = encryptSecret(secretPlain)
  if (secretEnc === null) {
    return fail('KEY_MISSING', 'chiave master AES assente: configurare DEVICE_CREDENTIALS_KEY', 422)
  }

  /* plantId opzionale: se fornito e non null deve essere un impianto
   * REALE (null = endpoint globale su tutti gli impianti). */
  let plantId: string | null = null
  if (input.plantId != null) {
    const plant = await db.plant.findUnique({
      where: { id: input.plantId },
      select: { id: true },
    })
    if (!plant) return fail('PLANT_NOT_FOUND', 'Impianto non trovato', 404)
    plantId = input.plantId
  }

  const events = input.events ?? []
  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + audit in transazione (MAI il segreto nei details) --- */
  const created = await db.$transaction(async (tx) => {
    const e = await tx.webhookEndpoint.create({
      data: {
        name: input.name,
        url: input.url,
        secret: secretEnc,
        events: JSON.stringify(events),
        plantId,
        active: true,
        description: input.description ?? '',
      },
    })
    await tx.auditLog.create({
      data: {
        action: 'WEBHOOK_CREATE',
        actor: email,
        targetId: e.id,
        targetLabel: e.name.slice(0, 80),
        plantId: e.plantId,
        details: JSON.stringify({
          name: e.name,
          url: e.url,
          events,
          plantId: e.plantId,
          secretGenerated: secretProvided === null, // MAI il segreto
        }),
      },
    })
    return e
  })

  /* Riga risposta: endpoint appena creato (nessuna consegna ancora) +
   * secretOneTime SOLO quando il segreto è stato GENERATO (se fornito
   * dall'utente → null: l'operatore lo conosce già). Il segreto NON
   * sarà più recuperabile: nel DB resta solo il ciphertext AES. */
  const data = {
    ...toEndpointRow(created, [], 0),
    secretOneTime: secretProvided === null ? secretPlain : null,
  }

  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(CreatedWebhookRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
