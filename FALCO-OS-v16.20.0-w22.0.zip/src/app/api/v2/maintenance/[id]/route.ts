/* ================================================================
 * /api/v2/maintenance/{id} — PATCH (modifica completa) + DELETE
 * Operazioni su una finestra di manutenzione REALE:
 *  · PATCH (16.3 W3): oltre alla pausa/ripresa { state } del 16.2
 *    (RETROCOMPATIBILE: stesso audit MAINTENANCE_STATE) accetta i
 *    campi name/description/type/scheduleType/daysOfWeek/dayOfMonth/
 *    startTime/endTime/activeUntil/groupIds — almeno uno richiesto.
 *    La validazione SEMANTICA usa la COMBINAZIONE con la finestra
 *    ESISTENTE (valori effettivi): startTime≠endTime, WEEKLY →
 *    daysOfWeek non vuoto (e giorni SOLO per WEEKLY), MONTHLY →
 *    dayOfMonth 1..31 (zod), activeUntil null ok / futuro ok /
 *    passato → 422; state identico a quello attuale → 422
 *    INVALID_TRANSITION (comportamento 16.2 preservato); groupIds =
 *    SOSTITUZIONE INTEGRALE degli scope (gruppi REALI del plant,
 *    422 con offensori altrimenti); patch senza alcun effetto →
 *    422 NO_CHANGES (mai input ignorato in silenzio, mai no-op
 *    mascherato da successo).
 *    Audit: MAINTENANCE_STATE {from,to} per il cambio stato +
 *    MAINTENANCE_UPDATE per le modifiche di campo (diff
 *    {campo: from→to}) e scope ({added, removed} con nomi reali);
 *    risponde la MaintenanceRow aggiornata (con scopes).
 *  · DELETE: rimozione definitiva con audit MAINTENANCE_DELETE.
 *    Permettata perché le finestre sono PROGRAMMAZIONI (non storia):
 *    gli Intervention collegati sopravvivono (schema onDelete: SetNull →
 *    maintenanceWindowId diventa null, la storia resta nel registro);
 *    i gruppi collegati (MaintenanceWindowGroup) vengono rimossi a
 *    cascata dallo schema (nessuna perdita di dati primari).
 * Entrambe richiedono role ≥ TECNICO (stesso guard dei ticket) e
 * scrivono l'audit in TRANSAZIONE con la mutazione.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { fail, requireSession } from '@/lib/v2/api-helpers'
import {
  MaintenanceRowSchema, UpdateMaintenanceInputSchema, MaintenanceDeletedSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import {
  devValidate, toMaintenanceRow, parseDaysOfWeek, loadWindowScopes, loadPlantGroupsByIds,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

/** Carica la finestra o risponde 404 (helper locale per PATCH/DELETE). */
function notFound() {
  return fail('NOT_FOUND', 'Finestra di manutenzione non trovata', 404)
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params

  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con almeno un campo fra state, name, description, type, scheduleType, daysOfWeek, dayOfMonth, startTime, endTime, activeUntil, groupIds)', 422)
  }
  const parsed = UpdateMaintenanceInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const existing = await db.maintenanceWindow.findUnique({ where: { id } })
  if (!existing) return notFound()

  /* --- Comportamento 16.2 preservato: stato identico → 422 (vale
   * anche nelle patch miste: mai input ignorato in silenzio). --- */
  if (input.state !== undefined && input.state === existing.state) {
    return fail('INVALID_TRANSITION', `La finestra è già in stato ${input.state} (nessuna modifica necessaria)`, 422)
  }

  /* --- Validazione semantica sui valori EFFETTIVI (input ⊕ esistente) --- */
  const effStart = input.startTime ?? existing.startTime
  const effEnd = input.endTime ?? existing.endTime
  if (effStart === effEnd) {
    return fail('BAD_BODY', 'Orario di fine identico a quello di inizio (durata nulla)', 422, [{ path: 'endTime', message: `Inizio e fine coincidono (${effStart})` }])
  }
  const effSchedule = input.scheduleType ?? existing.scheduleType
  const effDays = input.daysOfWeek ?? parseDaysOfWeek(existing.daysOfWeek)
  if (effSchedule === 'WEEKLY' && effDays.length === 0) {
    return fail('BAD_BODY', 'Con periodicità settimanale serve almeno un giorno', 422, [{ path: 'daysOfWeek', message: 'Nessun giorno selezionato' }])
  }
  /* Giorni forniti MA periodicità effettiva non settimanale → rifiuto
   * esplicito (stessa regola del create: mai input ignorato). */
  if (effSchedule !== 'WEEKLY' && input.daysOfWeek !== undefined && input.daysOfWeek.length > 0) {
    return fail('BAD_BODY', 'I giorni si applicano solo alla periodicità settimanale', 422, [{ path: 'daysOfWeek', message: `Periodicità effettiva: ${effSchedule}` }])
  }
  /* activeUntil: null = rimuovi scadenza (ok); futuro ok; passato → 422. */
  if (input.activeUntil != null && input.activeUntil <= Date.now()) {
    return fail('BAD_BODY', 'La fine della validità (activeUntil) deve essere nel futuro (oppure null per rimuovere la scadenza)', 422, [{ path: 'activeUntil', message: 'Data già passata' }])
  }

  /* --- groupIds (se presenti): gruppi REALI del plant, sostituzione
   * integrale degli scope. Carico anche gli scope ATTUALI per il diff. --- */
  const groupIds = input.groupIds !== undefined ? Array.from(new Set(input.groupIds)) : null
  let groupNamesById = new Map<string, string>()
  if (groupIds && groupIds.length > 0) {
    groupNamesById = await loadPlantGroupsByIds(existing.plantId, groupIds)
    const missing = groupIds.filter((gid) => !groupNamesById.has(gid))
    if (missing.length > 0) {
      return fail('BAD_BODY', 'Alcuni gruppi indicati non esistono in questo impianto', 422, [
        { path: 'groupIds', message: `Id gruppo non validi (mostrati al massimo 5 su ${missing.length})`, unknownGroupIds: missing.slice(0, 5) },
      ])
    }
  }
  const currentScopes = await db.maintenanceWindowGroup.findMany({
    where: { windowId: existing.id },
    select: { groupId: true, group: { select: { name: true } } },
  })
  const currentScopeIds = new Set(currentScopes.map((s) => s.groupId))

  /* --- Diff onesto: SOLO ciò che cambia davvero --- */
  const diff: Record<string, { from: unknown; to: unknown }> = {}
  if (input.name !== undefined && input.name !== existing.name) diff.name = { from: existing.name, to: input.name }
  if (input.description !== undefined && input.description !== existing.description) diff.description = { from: existing.description.slice(0, 80), to: input.description.slice(0, 80) }
  if (input.type !== undefined && input.type !== existing.type) diff.type = { from: existing.type, to: input.type }
  if (input.scheduleType !== undefined && input.scheduleType !== existing.scheduleType) diff.scheduleType = { from: existing.scheduleType, to: input.scheduleType }
  if (input.daysOfWeek !== undefined) {
    const same = [...input.daysOfWeek].sort((a, b) => a - b).join(',') === [...parseDaysOfWeek(existing.daysOfWeek)].sort((a, b) => a - b).join(',')
    if (!same) diff.daysOfWeek = { from: parseDaysOfWeek(existing.daysOfWeek), to: [...input.daysOfWeek].sort((a, b) => a - b) }
  }
  if (input.dayOfMonth !== undefined && input.dayOfMonth !== existing.dayOfMonth) diff.dayOfMonth = { from: existing.dayOfMonth, to: input.dayOfMonth }
  if (input.startTime !== undefined && input.startTime !== existing.startTime) diff.startTime = { from: existing.startTime, to: input.startTime }
  if (input.endTime !== undefined && input.endTime !== existing.endTime) diff.endTime = { from: existing.endTime, to: input.endTime }
  if (input.activeUntil !== undefined) {
    const from = existing.activeUntil?.getTime() ?? null
    if ((input.activeUntil ?? null) !== from) diff.activeUntil = { from, to: input.activeUntil ?? null }
  }
  let scopesDiff: { added: string[]; removed: string[] } | null = null
  if (groupIds !== null) {
    const newSet = new Set(groupIds)
    const added = groupIds.filter((gid) => !currentScopeIds.has(gid)).map((gid) => groupNamesById.get(gid)!)
    const removed = currentScopes.filter((s) => !newSet.has(s.groupId)).map((s) => s.group.name)
    if (added.length > 0 || removed.length > 0) scopesDiff = { added, removed }
  }

  const stateChanged = input.state !== undefined // (≠ esistente, già validato sopra)
  const hasChanges = Object.keys(diff).length > 0 || scopesDiff !== null
  if (!stateChanged && !hasChanges) {
    return fail('NO_CHANGES', 'Nessuna modifica da applicare: i valori indicati sono identici a quelli attuali della finestra', 422)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Update + scope replace + audit in transazione interattiva --- */
  const updated = await db.$transaction(async (tx) => {
    const w = await tx.maintenanceWindow.update({
      where: { id: existing.id },
      data: {
        ...(input.state !== undefined ? { state: input.state } : {}),
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
        ...(input.type !== undefined ? { type: input.type } : {}),
        ...(input.scheduleType !== undefined ? { scheduleType: input.scheduleType } : {}),
        ...(input.daysOfWeek !== undefined ? { daysOfWeek: JSON.stringify(input.daysOfWeek) } : {}),
        ...(input.dayOfMonth !== undefined ? { dayOfMonth: input.dayOfMonth } : {}),
        ...(input.startTime !== undefined ? { startTime: input.startTime } : {}),
        ...(input.endTime !== undefined ? { endTime: input.endTime } : {}),
        ...(input.activeUntil !== undefined ? { activeUntil: input.activeUntil === null ? null : new Date(input.activeUntil) } : {}),
      },
    })

    /* groupIds = SOSTITUZIONE INTEGRALE degli scope (dichiarata nel
     * contratto): deleteMany + createMany atomici nella transazione. */
    if (groupIds !== null) {
      await tx.maintenanceWindowGroup.deleteMany({ where: { windowId: existing.id } })
      if (groupIds.length > 0) {
        await tx.maintenanceWindowGroup.createMany({
          data: groupIds.map((groupId) => ({ windowId: existing.id, groupId })),
          // niente skipDuplicates: NON supportato su SQLite/Prisma; sicuro
          // senza perché gli scope sono stati appena azzerati (deleteMany)
        })
      }
    }

    /* Audit: MAINTENANCE_STATE per il cambio stato (16.2 invariato)… */
    if (input.state !== undefined) {
      await tx.auditLog.create({
        data: {
          action: 'MAINTENANCE_STATE',
          actor: email,
          targetId: w.id,
          targetLabel: w.name.slice(0, 80),
          plantId: w.plantId,
          details: JSON.stringify({ windowId: w.id, from: existing.state, to: input.state }),
        },
      })
    }
    /* …MAINTENANCE_UPDATE per le modifiche di campo e/o scope (16.3). */
    if (hasChanges) {
      await tx.auditLog.create({
        data: {
          action: 'MAINTENANCE_UPDATE',
          actor: email,
          targetId: w.id,
          targetLabel: w.name.slice(0, 80),
          plantId: w.plantId,
          details: JSON.stringify({
            windowId: w.id,
            name: w.name,
            diff,
            ...(scopesDiff !== null ? { scopes: scopesDiff } : {}),
          }),
        },
      })
    }
    return w
  })

  /* --- Riga aggiornata con gli scope effettivi (nome gruppo reale) --- */
  const scopes = (await loadWindowScopes([updated.id])).get(updated.id) ?? []
  const data = toMaintenanceRow(updated, scopes.length, scopes)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(MaintenanceRowSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  const { id } = await ctx.params
  const existing = await db.maintenanceWindow.findUnique({ where: { id } })
  if (!existing) return notFound()

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  await db.$transaction(async (tx) => {
    await tx.maintenanceWindow.delete({ where: { id: existing.id } })
    await tx.auditLog.create({
      data: {
        action: 'MAINTENANCE_DELETE',
        actor: email,
        targetId: existing.id,
        targetLabel: existing.name.slice(0, 80),
        plantId: existing.plantId,
        details: JSON.stringify({
          windowId: existing.id,
          name: existing.name,
          state: existing.state,
          schedule: `${existing.scheduleType} ${existing.startTime}-${existing.endTime}`,
          note: 'Gli interventi collegati restano nel registro (maintenanceWindowId → null)',
        }),
      },
    })
  })

  const data = { id: existing.id }
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(MaintenanceDeletedSchema, data)
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data })
}
