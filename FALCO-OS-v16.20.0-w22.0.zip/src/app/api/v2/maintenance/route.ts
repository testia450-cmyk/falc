/* ================================================================
 * /api/v2/maintenance — GET (elenco) + POST (creazione, 16.2)
 * Finestre di manutenzione REALI del DB (modello MaintenanceWindow
 * v15.11 R7). DB reale al 16.1: 0 finestre → items: [] (onesto).
 *  · daysOfWeek è String JSON "[1..7]" nel modello: qui viene
 *    interpretato (parse difensivo, mai crash, mai valori inventati);
 *  · scopesCount = gruppi di dispositivi collegati (groupBy su
 *    MaintenanceWindowGroup per le sole finestre caricate);
 *  · 16.3 additivo W3: scopes con NOME del gruppo (loadWindowScopes,
 *    query separata) per le chip della vista Operazioni;
 *  · ordinamento name asc (deterministico); type/scheduleType/state
 *    restano grezzi: le label vivono nella UI.
 * POST (inizio W3): crea una finestra REALE (role ≥ TECNICO) con
 *  validazione zod del corpo; 16.3 W3: groupIds OPZIONALE = scope su
 *  gruppi REALI del plant (422 con id offensori se un gruppo non
 *  esiste) → MaintenanceWindowGroup create in $transaction; audit
 *  MAINTENANCE_CREATE con scopes: [nomi gruppi reali] quando groupIds
 *  è fornito (nota onesta «nessuno» altrimenti); risponde 201 con la
 *  riga creata (scopes inclusi).
 * Nessun campo credenziale coinvolto.
 * ================================================================ */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, requireSession, parseQuery } from '@/lib/v2/api-helpers'
import {
  MaintenanceQuerySchema, MaintenancePageSchema, MaintenanceRowSchema,
  CreateMaintenanceInputSchema,
} from '@/lib/v2/contracts'
import { getReplayState, apiMode } from '@/lib/v2/derive'
import { hasRole } from '@/lib/auth'
import {
  resolvePlant, devValidate, maxOf, toMaintenanceRow, loadWindowScopes, loadPlantGroupsByIds,
} from '@/app/api/v2/shared'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  const q = parseQuery(MaintenanceQuerySchema, new URL(req.url))
  if (!q.ok) return q.response

  const plant = await resolvePlant(q.value.plantId)
  if (!plant.ok) return plant.response
  const p = plant.plant

  const windows = await db.maintenanceWindow.findMany({
    where: { plantId: p.id },
    orderBy: { name: 'asc' },
  })

  /* 16.3 W3: scope con NOME del gruppo per le sole finestre caricate
   * (mai groupBy su tutto lo storico). */
  const scopesBy = await loadWindowScopes(windows.map((w) => w.id))

  const data = {
    items: windows.map((w) => {
      const scopes = scopesBy.get(w.id) ?? []
      return toMaintenanceRow(w, scopes.length, scopes)
    }),
  }

  const asOf = maxOf(...windows.map((w) => w.updatedAt.getTime())) || Date.now()
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(MaintenancePageSchema, { ok: true as const, asOf, mode, data })
  return ok(data, asOf, mode)
}

/* ================================================================ */

export async function POST(req: Request) {
  const session = await requireSession()
  if (!session.ok) return session.response

  if (!hasRole(session.session.user.role, 'TECNICO')) {
    return fail('FORBIDDEN', 'Permessi insufficienti: richiesto ruolo TECNICO o superiore', 403)
  }

  /* --- Corpo JSON { name, description?, type, scheduleType, … } --- */
  let rawBody: unknown = null
  try {
    const text = await req.text()
    if (text.trim()) rawBody = JSON.parse(text)
  } catch {
    return fail('BAD_BODY', 'Corpo della richiesta non valido (atteso JSON con name, type, scheduleType, startTime, endTime)', 422)
  }
  const parsed = CreateMaintenanceInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return fail('BAD_BODY', 'Corpo della richiesta non valido', 422, parsed.error.issues?.map((i) => ({ path: i.path.join('.'), message: i.message })))
  }
  const input = parsed.data

  const url = new URL(req.url)
  const plant = await resolvePlant(url.searchParams.get('plantId') ?? undefined)
  if (!plant.ok) return plant.response

  /* activeUntil è un epoch ms opzionale: scartato se nel passato
   * (una scadenza già passata creerebbe una finestra inattiva subito:
   * meglio rifiutare onestamente a monte). */
  if (input.activeUntil != null && input.activeUntil <= Date.now()) {
    return fail('BAD_BODY', 'La fine della validità (activeUntil) deve essere nel futuro', 422, [{ path: 'activeUntil', message: 'Data già passata' }])
  }

  /* --- 16.3 W3: groupIds opzionali = scope su gruppi REALI del plant
   * (deduplicati; un id mancante è un offensore → 422 onesto). */
  const groupIds = input.groupIds ? Array.from(new Set(input.groupIds)) : []
  let groupNames: string[] = []
  if (groupIds.length > 0) {
    const found = await loadPlantGroupsByIds(plant.plant.id, groupIds)
    const missing = groupIds.filter((id) => !found.has(id))
    if (missing.length > 0) {
      return fail('BAD_BODY', 'Alcuni gruppi indicati non esistono in questo impianto', 422, [
        { path: 'groupIds', message: `Id gruppo non validi (mostrati al massimo 5 su ${missing.length})`, unknownGroupIds: missing.slice(0, 5) },
      ])
    }
    /* Nomi nell'ordine degli id forniti (ordine operatore preservato) */
    groupNames = groupIds.map((id) => found.get(id)!)
  }

  const email = session.session.user.email ?? 'sconosciuto'
  const now = new Date()

  /* --- Create + scope + audit in transazione interattiva --- */
  const created = await db.$transaction(async (tx) => {
    const w = await tx.maintenanceWindow.create({
      data: {
        plantId: plant.plant.id,
        name: input.name,
        description: input.description,
        type: input.type,
        scheduleType: input.scheduleType,
        daysOfWeek: JSON.stringify(input.daysOfWeek),
        dayOfMonth: input.dayOfMonth,
        startTime: input.startTime,
        endTime: input.endTime,
        activeSince: now,
        activeUntil: input.activeUntil ? new Date(input.activeUntil) : null,
        state: 'ACTIVE',
      },
    })
    if (groupIds.length > 0) {
      await tx.maintenanceWindowGroup.createMany({
        data: groupIds.map((groupId) => ({ windowId: w.id, groupId })),
        // niente skipDuplicates: NON supportato su SQLite/Prisma; sicuro
        // senza perché la finestra è appena creata e gli id sono deduplicati
      })
    }
    await tx.auditLog.create({
      data: {
        action: 'MAINTENANCE_CREATE',
        actor: email,
        targetId: w.id,
        targetLabel: w.name.slice(0, 80),
        plantId: w.plantId,
        details: JSON.stringify({
          windowId: w.id,
          name: w.name,
          type: w.type,
          scheduleType: w.scheduleType,
          days: w.daysOfWeek,
          time: `${w.startTime}-${w.endTime}`,
          /* 16.3 W3: nomi dei gruppi REALI quando groupIds è fornito;
           * senza groupIds la nota onesta 16.2 resta com'era. */
          scopes: groupIds.length > 0 ? groupNames : 'nessuno (DeviceGroup vuoto nel DB reale)',
        }),
      },
    })
    return w
  })

  /* Riga di risposta con gli scope creati (groupId + nome reale) */
  const scopeList = groupIds.map((groupId, i) => ({ groupId, name: groupNames[i] }))
  const data = toMaintenanceRow(created, groupIds.length, scopeList)
  const replay = await getReplayState()
  const mode = apiMode(replay)
  devValidate(MaintenanceRowSchema, data) // risposta singola: valida la riga nella busta
  return NextResponse.json({ ok: true as const, asOf: now.getTime(), mode, data }, { status: 201 })
}
