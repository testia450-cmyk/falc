/* ================================================================
 * /api/hooks/test-receiver — POST (PUBBLICO, senza sessione)
 * Ricevitore di test per i webhook FALCO-OS (W7): è il DESTINATARIO
 * reale a cui il motore di consegna invia il payload firmato
 * HMAC-SHA256 (header X-Falco-Signature: t=<epoch>,v1=<hex>).
 *
 * Cosa fa (e cosa NON fa):
 *  · verifica che la firma sia PRESENTE e ben FORMATA (t=…,v1=64hex);
 *  · risponde 200 con l'eco di {firma, bodySha256, bodyLen} così che
 *    il MITTENTE possa verificare crittograficamente che il
 *    destinatario ha ricevuto ESATTAMENTE i byte firmati;
 *  · NON espone dati, NON scrive sul DB, NON richiede autenticazione
 *    (i webhook sono server-to-server: la sicurezza è la firma).
 * Un Ricevitore di produzione verificarebbe v1 == HMAC(secret,
 * t.body): qui il segreto appartiene al mittente, quindi la verifica
 * crittografica avviene lato mittente (vedi /api/v2/integrations/
 * webhooks/[id]/test).
 * ================================================================ */

import { createHash } from 'crypto'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

const SIG_RE = /^t=(\d{1,13}),v1=([0-9a-f]{64})$/

export async function POST(req: Request) {
  const raw = await req.text().catch(() => '')
  const sig = req.headers.get('x-falco-signature') ?? ''
  const m = SIG_RE.exec(sig.trim())

  if (!m) {
    return NextResponse.json(
      { ok: false, error: 'SIGNATURE_MISSING', detail: 'Header X-Falco-Signature assente o malformato (atteso «t=<epoch>,v1=<hex64>»)' },
      { status: 401 },
    )
  }

  const bodySha256 = createHash('sha256').update(raw, 'utf8').digest('hex')
  return NextResponse.json(
    {
      ok: true,
      received: {
        signature: sig.trim(),
        timestamp: Number(m[1]),
        bodyLen: Buffer.byteLength(raw, 'utf8'),
        bodySha256,
      },
    },
    { status: 200 },
  )
}

export async function GET() {
  return NextResponse.json(
    { ok: false, error: 'POST_ONLY', detail: 'Ricevitore di test webhook: inviare POST firmato X-Falco-Signature' },
    { status: 405 },
  )
}
