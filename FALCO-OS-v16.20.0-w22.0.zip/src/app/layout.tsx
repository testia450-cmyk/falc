import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FALCO-OS v16 — NOC",
  description:
    "Network Operations Center di FALCO-OS: monitoraggio in tempo reale di impianti, dispositivi, link radio e allarmi.",
  icons: { icon: "/logo.svg" },
};

export const viewport: Viewport = {
  themeColor: "#051224",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    /* Tema gestito da next-themes (attribute="class", default scuro):
     * la classe dark/light viene applicata prima del paint dal suo
     * script inline — nessun flash, nessun mismatch di idratazione. */
    <html lang="it" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
