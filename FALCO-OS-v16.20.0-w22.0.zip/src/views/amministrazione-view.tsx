/* ================================================================
 * FALCO-OS v16 — Vista «Amministrazione» (§6.10)
 * Tre tab (onda 16.7): «Sistema» (salute, conteggi DB reali, registro
 * audit senza dettagli sensibili, account di sessione e roadmap
 * onesta W3/W4 — badge non interattivi), «Integrazioni» (W7:
 * configurazioni cifrate, test di connessione reali, webhook HMAC)
 * e «OID custom» (W3.5: metriche vendor del polling SNMP) e «Certificazione»
 * (16.8 W6: catena audit sigillata, verifica crittografica, sigillo
 * SUPER_ADMIN, export certificato SHA-256). Nessun numero inventato: tutto
 * da /api/v2/system/health, /api/v2/admin/stats, /api/v2/audit e le API
 * 16.7/16.8 delle sezioni.
 * ================================================================ */

'use client'

import { useMemo, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useQuery } from '@tanstack/react-query'
import {
  Database, Gauge, ScrollText, ShieldCheck, UserRound, RefreshCw,
} from 'lucide-react'

import { PageHeader } from '@/components/page-header'
import { EmptyState, ErrorPanel } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import CustomOidsSection from '@/components/custom-oids-view'
import CertificazioneSection from '@/components/certificazione-view'
import IntegrazioniSection from '@/components/integrazioni-view'
import { UtentiPermessiPanel } from '@/components/utenti-permessi'
import { ImpiantiPanel } from '@/components/impianti-panel'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { api, ApiError, type AdminStats } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtPct } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* Label degli stati ticket (vocabolario del workflow v8; valori
 * ignoti mostrati raw — mai traduzione inventata). */
const TICKET_STATUS_LABELS: Record<string, string> = {
  OPEN: 'Aperti',
  IN_PROGRESS: 'In lavorazione',
  RESOLVED: 'Risolti',
  CLOSED: 'Chiusi',
}

/* Roadmap onesta (badge d'onda NON interattivi) */
const ROADMAP: Array<{ wave: 'W3' | 'W4'; title: string; description: string }> = [
  { wave: 'W3', title: 'Config bulk e ondate', description: 'Applicazione di configurazioni a lotti con canary e arresto al primo fallimento.' },
  { wave: 'W3', title: 'Aggiornamenti firmware', description: 'Piani di aggiornamento firmware con preflight di raggiungibilità e credenziali.' },
  { wave: 'W3', title: 'Playbooks operativi', description: 'Procedure guidate per le operazioni ricorrenti (riavvio, verifica link, sostituzione).' },
  { wave: 'W3', title: 'Terminale di servizio', description: 'Accesso tecnico agli apparati con sessioni tracciate nell\'audit.' },
  { wave: 'W4', title: 'Knowledge base', description: 'Archivio delle cause radice storiche e delle soluzioni adottate.' },
  { wave: 'W4', title: 'CVE e vulnerabilità', description: 'Incrocio firmware/modello con banche CVE per segnalare apparati esposti.' },
  { wave: 'W4', title: 'Speed test', description: 'Misurazioni programmate di banda verso i punti di rete.' },
]

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

export default function AmministrazioneView() {
  /* v16.17 W18: sezione profonda (deep-link ?sez=impianti) — il tasto
   * «Importa Excel/KMZ» della mappa arriva qui dritto. La scelta resta
   * nell'URL: condivisibile e refresh-sicura come ogni altro stato. */
  const adminSez = useApp((s) => s.adminSez)
  const set = useApp((s) => s.set)
  const { data: session } = useSession()
  const [actionFilter, setActionFilter] = useState('')

  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  })
  const stats = useQuery({
    queryKey: ['admin-stats'],
    queryFn: () => api.adminStats(),
    staleTime: 60_000,
  })
  const audit = useQuery({
    queryKey: ['audit', 50],
    queryFn: () => api.audit({ limit: 50 }),
    staleTime: 30_000,
  })

  /* Filtro azione: contains lato client sulle righe GIÀ CARICATE
   * (le più recenti): dichiarato in UI, nessuna pretesa di copertura
   * totale del registro da 48k+ righe. */
  const auditItems = audit.data?.data.items ?? []
  const filteredAudit = useMemo(() => {
    const needle = actionFilter.trim().toLowerCase()
    if (!needle) return auditItems
    return auditItems.filter((a) =>
      a.action.toLowerCase().includes(needle)
      || a.actor.toLowerCase().includes(needle)
      || (a.targetLabel ?? '').toLowerCase().includes(needle))
  }, [auditItems, actionFilter])

  const h = health.data?.data
  const st: AdminStats | undefined = stats.data?.data

  return (
    <div>
      <PageHeader
        title="Amministrazione"
        subtitle="Sistema e dati reali del DB; integrazioni e OID custom (onda 16.7); gestione utenti e permessi: onda W4; impianti e import KMZ: onda 16.10"
        mode={health.data?.mode}
        importedAt={h?.replay.importedAt ?? null}
      />

      {/* Quattro tab (16.7 + W6): la lista SCORRE orizzontalmente su mobile
       * invece di sbordare (stesso pattern della vista Operazioni);
       * da sm in poi torna inline centrata. v16.17 W18: tab CONTROLLATA
       * dallo store (sez) per il deep-link dall'import della mappa. */}
      <Tabs
        value={adminSez ?? 'sistema'}
        onValueChange={(v) => { set({ adminSez: v as 'impianti' | 'sistema' | 'integrazioni' | 'oid-custom' | 'certificazione' | 'utenti' }) }}
      >
        <TabsList
          aria-label="Sezioni della vista Amministrazione"
          className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit sm:justify-center"
        >
          <TabsTrigger value="impianti" className="shrink-0">Impianti</TabsTrigger>
          <TabsTrigger value="sistema" className="shrink-0">Sistema</TabsTrigger>
          <TabsTrigger value="integrazioni" className="shrink-0">Integrazioni</TabsTrigger>
          <TabsTrigger value="oid-custom" className="shrink-0">OID custom</TabsTrigger>
          <TabsTrigger value="certificazione" className="shrink-0">Certificazione</TabsTrigger>
          <TabsTrigger value="utenti" className="shrink-0">Utenti e permessi</TabsTrigger>
        </TabsList>

        {/* 16.10 W8: impianti — CRUD reale + import punti KMZ/KML in due
         * fasi (anteprima → conferma). Primi in lista: l'impianto è
         * l'entità principale del sistema. */}
        <TabsContent value="impianti" className="mt-4">
          <ImpiantiPanel />
        </TabsContent>

        <TabsContent value="sistema" className="mt-4">
      {/* Griglia con track minmax(0,1fr) (difetto overflow mobile §regole UI:
       * il track auto si allarga al min-content della tabella audit) */}
      <div className="grid min-w-0 grid-cols-1 gap-4 lg:grid-cols-2">
        {/* --- Sistema --- */}
        <Card className="min-w-0 border-border/70 bg-surface">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Gauge className="size-4 text-text-2" aria-hidden />
              Sistema
            </CardTitle>
          </CardHeader>
          <CardContent>
            {health.isPending ? (
              <div role="status" aria-busy="true" className="h-28 animate-pulse rounded-md bg-raised/60">
                <span className="sr-only">Caricamento salute sistema</span>
              </div>
            ) : health.isError ? (
              <ErrorPanel message={errInfo(health.error).message} code={errInfo(health.error).code} onRetry={() => { void health.refetch() }} />
            ) : (
              <dl className="grid gap-x-8 gap-y-2.5 text-sm">
                <Row label="Versione" value={<span className="num font-medium">{h?.version ?? 'n.d.'}</span>} />
                <Row
                  label="Database"
                  value={h?.dbReachable
                    ? <span className="font-medium text-ok">Raggiungibile</span>
                    : <span className="font-medium text-crit">Non raggiungibile</span>}
                />
                <Row
                  label="Modalità riproduzione"
                  value={h?.replay.enabled ? (
                    <span className="flex flex-wrap items-baseline gap-x-2">
                      <span className="font-medium text-info">attiva</span>
                      <span className="text-xs text-text-2">
                        dati reali importati {fmtDateTime(h?.replay.importedAt)} · ciclo ogni {h?.replay.intervalSec ?? 'n.d.'} s
                        {h?.replay.lastTickAt ? ` · ultimo ${fmtDateTime(h.replay.lastTickAt)}` : ''}
                      </span>
                    </span>
                  ) : (
                    <span className="font-medium text-warn">ferma (fermo immagine)</span>
                  )}
                />
                <Row label="Canale realtime" value={<span className="num break-all text-xs">{h?.realtimeUrl ?? 'n.d.'}</span>} />
              </dl>
            )}
          </CardContent>
        </Card>

        {/* --- Conteggi DB reali --- */}
        <Card className="min-w-0 border-border/70 bg-surface">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Database className="size-4 text-text-2" aria-hidden />
              Conteggi DB reali
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stats.isPending ? (
              <div className="h-40 animate-pulse rounded-md bg-raised/60" role="status" aria-busy="true"><span className="sr-only">Caricamento conteggi</span></div>
            ) : stats.isError ? (
              <ErrorPanel message={errInfo(stats.error).message} code={errInfo(stats.error).code} onRetry={() => { void stats.refetch() }} />
            ) : st ? (
              <>
                <dl className="grid gap-x-8 gap-y-2.5 text-sm">
                  <Row label="Dispositivi" value={<span className="num font-medium">{fmtNumber(st.devices)}</span>} />
                  <Row label="Sedi" value={<span className="num font-medium">{fmtNumber(st.locations)}</span>} />
                  <Row label="Impianti" value={<span className="num font-medium">{fmtNumber(st.plants)}</span>} />
                  <Row
                    label="Allarmi non chiusi"
                    value={<span className="num font-medium">{fmtNumber(st.alertsOpen)}</span>}
                    hint="status ≠ CLOSED: aperti, riconosciuti, escalati e soppressi (stessa definizione della dashboard)"
                  />
                  <Row
                    label="— di cui soppressi"
                    value={<span className="num font-medium">{fmtNumber(st.alertsSuppressed)}</span>}
                    hint="soppressi dal motore RCA per causa radice già segnalata"
                  />
                  <Row
                    label="Ticket"
                    value={
                      <span className="flex flex-wrap items-baseline gap-x-2">
                        <span className="num font-medium">{fmtNumber(st.ticketsTotal)}</span>
                        <span className="text-xs text-text-2">
                          ({Object.entries(st.ticketsByStatus).map(([k, v]) => `${TICKET_STATUS_LABELS[k] ?? k}: ${fmtNumber(v)}`).join(', ') || 'nessuno'})
                        </span>
                      </span>
                    }
                  />
                  <Row label="Finestre di manutenzione" value={<span className="num font-medium">{fmtNumber(st.maintenanceWindows)}</span>} />
                  <Row label="Voci audit" value={<span className="num font-medium">{fmtNumber(st.auditLogEntries)}</span>} />
                  <Row label="Campioni metriche" value={<span className="num font-medium">{fmtNumber(st.metricSamples)}</span>} />
                  <Row label="Schede polling" value={<span className="num font-medium">{fmtNumber(st.pollingSchedules)}</span>} />
                  <Row
                    label="Copertura topologica"
                    value={st.coveragePct != null ? <span className="num font-medium">{fmtPct(st.coveragePct)}</span> : 'n.d.'}
                    hint="ultimo snapshot reale del motore (obiettivo 70%)"
                  />
                </dl>
                {stats.data ? <AsOf ts={stats.data.asOf} className="mt-4" prefix="conteggi alle" /> : null}
              </>
            ) : null}
          </CardContent>
        </Card>

        {/* --- Registro audit (sola lettura, senza dettagli) --- */}
        <Card className="min-w-0 border-border/70 bg-surface lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
              <ScrollText className="size-4 text-text-2" aria-hidden />
              Registro audit
              {audit.data ? (
                <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
                  {fmtNumber(audit.data.data.total)} righe totali: mostrate le più recenti
                </Badge>
              ) : null}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {audit.isPending ? (
              <div className="h-40 animate-pulse rounded-md bg-raised/60" role="status" aria-busy="true"><span className="sr-only">Caricamento registro audit</span></div>
            ) : audit.isError ? (
              <ErrorPanel message={errInfo(audit.error).message} code={errInfo(audit.error).code} onRetry={() => { void audit.refetch() }} />
            ) : (
              <>
                <div className="mb-3 flex flex-wrap items-center gap-2">
                  <Input
                    type="search"
                    value={actionFilter}
                    onChange={(e) => setActionFilter(e.target.value)}
                    placeholder="Filtra le righe mostrate per azione, autore o oggetto…"
                    aria-label="Filtro testuale sulle righe di audit mostrate"
                    className="h-9 max-w-xs"
                  />
                  <p className="text-xs text-text-2">
                    {actionFilter.trim()
                      ? <><span className="num">{fmtNumber(filteredAudit.length)}</span> di <span className="num">{fmtNumber(auditItems.length)}</span> righe mostrate corrispondono al filtro</>
                      : <>ultime <span className="num">{fmtNumber(auditItems.length)}</span> righe (limite API 200)</>}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="ml-auto h-9"
                    disabled={audit.isFetching}
                    onClick={() => { void audit.refetch() }}
                  >
                    <RefreshCw className={cn('size-3.5', audit.isFetching && 'animate-spin')} aria-hidden />
                    Aggiorna
                  </Button>
                </div>

                {filteredAudit.length === 0 ? (
                  <EmptyState
                    title="Nessuna voce di audit corrispondente"
                    description={actionFilter.trim() ? 'Nessuna delle righe mostrate contiene il filtro corrente.' : 'Il registro audit non ha righe.'}
                  />
                ) : (
                  <div className="max-h-96 overflow-y-auto scroll-thin overflow-x-auto rounded-lg border border-border/70" role="region" aria-label="Registro audit: ultime voci, scorribile con le frecce" tabIndex={0}>
                    <Table>
                      <TableCaption className="sr-only">
                        Registro audit: azione, autore, oggetto e data/ora delle voci più recenti (i dettagli non vengono esposti)
                      </TableCaption>
                      <TableHeader>
                        <TableRow className="hover:bg-transparent">
                          <TableHead scope="col" className="w-[190px]">Azione</TableHead>
                          <TableHead scope="col" className="w-[170px]">Autore</TableHead>
                          <TableHead scope="col">Oggetto</TableHead>
                          <TableHead scope="col" className="w-[150px]">Quando</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredAudit.map((a) => (
                          <TableRow key={a.id}>
                            <TableCell>
                              <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2" title={a.action}>
                                {a.action}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <span className="block max-w-[160px] truncate text-xs" title={a.actor}>{a.actor || 'n.d.'}</span>
                            </TableCell>
                            <TableCell>
                              <span className="block max-w-[280px] truncate text-xs text-text-2" title={a.targetLabel ?? undefined}>
                                {a.targetLabel || '—'}
                              </span>
                            </TableCell>
                            <TableCell>
                              <span className="num text-xs" title={fmtDateTimeFull(a.createdAt)}>{fmtDateTime(a.createdAt)}</span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* --- Account di sessione --- */}
        <Card className="min-w-0 border-border/70 bg-surface">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <UserRound className="size-4 text-text-2" aria-hidden />
              Account
            </CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="grid gap-x-8 gap-y-2.5 text-sm">
              <Row label="Nome" value={session?.user?.name || 'n.d.'} />
              <Row label="Email" value={<span className="break-all">{session?.user?.email || 'n.d.'}</span>} />
              <Row
                label="Ruolo"
                value={
                  <span className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className="num gap-1.5 border-info/40 bg-info-soft font-medium text-info">
                      <ShieldCheck className="size-3.5" aria-hidden />
                      {session?.user?.role || 'n.d.'}
                    </Badge>
                  </span>
                }
              />
            </dl>
            <p className="mt-4 flex items-start gap-2 rounded-md border border-dashed border-border bg-raised/40 px-3 py-2 text-xs text-text-2">
              Gestione utenti, permessi e rubrica contatti: onda successiva del piano di migrazione.
              <Badge variant="outline" className="num ml-auto shrink-0 border-border bg-raised font-normal text-text-2" aria-label="Onda 4 del piano di migrazione">W4</Badge>
            </p>
          </CardContent>
        </Card>

        {/* --- Roadmap W3/W4 (trasparenza, non pulsanti finti) --- */}
        <Card className="min-w-0 border-border/70 bg-surface">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Roadmap W3/W4</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="grid gap-2.5">
              {ROADMAP.map((item) => (
                <li key={item.title} className="flex items-start gap-2.5">
                  <Badge variant="outline" className="num mt-0.5 shrink-0 border-border bg-raised font-normal text-text-2" aria-label={`Onda ${item.wave} del piano di migrazione`}>
                    {item.wave}
                  </Badge>
                  <div className="min-w-0">
                    <p className="text-[13px] font-medium">{item.title}</p>
                    <p className="mt-0.5 text-xs leading-relaxed text-text-2">{item.description}</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
        </TabsContent>

        <TabsContent value="integrazioni" className="mt-4">
          <IntegrazioniSection />
        </TabsContent>

        <TabsContent value="oid-custom" className="mt-4">
          <CustomOidsSection />
        </TabsContent>

        <TabsContent value="certificazione" className="mt-4">
          <CertificazioneSection />
        </TabsContent>
        {/* 16.9 W4: amministrazione completa — CRUD utenti (bcrypt +
         * guardie ultimo SUPER_ADMIN), matrice RBAC v15, sessioni
         * (onestà: JWT stateless → 0 righe persistite). */}
        <TabsContent value="utenti" className="mt-4">
          <UtentiPermessiPanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}

/* ---------------- Helper ---------------- */

function Row({ label, value, hint }: { label: string; value: React.ReactNode; hint?: string }) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-3">
      <dt className="w-44 shrink-0 text-[13px] text-text-2" title={hint}>{label}</dt>
      <dd className="min-w-0 break-words">{value}</dd>
    </div>
  )
}
