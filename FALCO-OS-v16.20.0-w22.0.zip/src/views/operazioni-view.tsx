/* ================================================================
 * FALCO-OS v16 — Vista «Operazioni» (§6.7)
 * Ticket ITSM e finestre di manutenzione REALI del DB (nessun dato
 * inventato): KPI con definizioni in tooltip, filtri server-side,
 * tabella con dettaglio espandibile, transizioni di stato SOLO legali
 * (macchina a stati validata dal backend §B.3), creazione ticket con
 * selettore dispositivo reale (ricerca server-side).
 * Finestre di manutenzione (16.2 → 16.3 W3): letture reali +
 * CREAZIONE, MODIFICA COMPLETA (nome/tipo/periodicità/orari/validità
 * con PATCH e audit MAINTENANCE_UPDATE), pausa/ripresa (audit
 * MAINTENANCE_STATE), eliminazione (audit MAINTENANCE_DELETE; gli
 * interventi collegati restano) e SCOPE PER GRUPPI reali.
 * Gruppi dispositivi (16.3/16.4 W3): terzo tab — CRUD completo con
 * membership MULTI (sostituzione integrale dichiarata), colore DATO
 * DELL'OPERATORE salvato nel DB (unico inline style consentito),
 * empty state onesto (il DB reale parte da 0 gruppi). 16.4: gruppi
 * DYNAMIC con regola (AND fra criteri, OR fra i valori) valutata a
 * RUNTIME sullo stato reale dei dispositivi — membership calcolata,
 * mai salvata; tipi/stati/connessioni validati contro i valori
 * distinti REALI dell'inventario, sedi contro quelle del plant;
 * anteprima del conteggio live dallo stesso dato (pageSize 200 =
 * tutto l'inventario reale); ruleType immutabile dopo la creazione.
 * Scansione & Adozione (16.6 W3.4): quarto tab — motore discovery
 * (:3002), sonda di identificazione in sola lettura e coda adozione
 * con gli orfani REALI del DB (decisione sempre umana, v15 §13.8).
 * Operazioni evolute (16.7 W3.5): quinto tab — component dedicato
 * (config-requests commit-confirm, ondate bulk, firmware, playbook,
 * automazioni, terminale SSH onesto; vedi operazioni-evolute.tsx).
 * Onestà: «n.d.» per campi mancanti, liste vuote dichiarate, mai
 * «OFFLINE» per mancanza dato; badge sempre icona+testo (§4.2).
 * ================================================================ */

'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  CalendarClock, CalendarX2, Check, ChevronDown, ChevronLeft, ChevronRight, CircleAlert, CircleCheck,
  CircleDot, CheckCheck, FileText, Hourglass, Info, Layers, Loader2, Monitor, OctagonAlert, Pause,
  Pencil, Play, Plus, RefreshCw, Search, Sparkles, Trash2, TriangleAlert, UserCheck, Wrench, type LucideIcon,
} from 'lucide-react'

import { PageHeader } from '@/components/page-header'
import { KpiCard } from '@/components/kpi-card'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import ScansioneAdozioneSection from '@/components/scansione-adozione'
import OperazioniEvoluteSection from '@/components/operazioni-evolute'
import SchedaIntervento from '@/components/scheda-intervento'
import { KbPanel } from '@/components/kb-panel'
import { RmaOndatePanel } from '@/components/rma-ondate'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  Popover, PopoverContent, PopoverTrigger,
} from '@/components/ui/popover'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
} from '@/components/ui/command'
import { api, ApiError, type TicketRow, type MaintenanceRow, type DeviceRow, type DeviceGroupRow, type GroupRule } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { fmtDateTime, fmtDateTimeFull, fmtNumber, fmtRelative } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Costanti vista ---------------- */

const PAGE_SIZE = 25

/* Stati del workflow ticket v8: badge icona+testo (mai solo colore).
 * Valori ignoti → badge neutro con valore raw (mai crash, mai
 * traduzione inventata). */
const TICKET_STATUS_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  OPEN: { label: 'Aperto', cls: 'bg-warn-soft text-warn border-warn/40', Icon: CircleDot },
  IN_PROGRESS: { label: 'In lavorazione', cls: 'bg-info-soft text-info border-info/40', Icon: Hourglass },
  RESOLVED: { label: 'Risolto', cls: 'bg-ok-soft text-ok border-ok/40', Icon: CircleCheck },
  CLOSED: { label: 'Chiuso', cls: 'bg-raised text-text-2 border-border', Icon: CheckCheck },
}

/* Priorità: valori REALI distinti nel DB = CRITICAL, HIGH (16.1);
 * MEDIUM/LOW sono del vocabolario del dominio (default modello):
 * label pronte, mai inventate. */
const PRIORITY_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  CRITICAL: { label: 'Critica', cls: 'bg-crit-soft text-crit-text border-crit/40', Icon: OctagonAlert },
  HIGH: { label: 'Alta', cls: 'bg-warn-soft text-warn border-warn/40', Icon: TriangleAlert },
  MEDIUM: { label: 'Media', cls: 'bg-info-soft text-info border-info/40', Icon: CircleAlert },
  LOW: { label: 'Bassa', cls: 'bg-ok-soft text-ok border-ok/40', Icon: Info },
}

const SOURCE_LABELS: Record<string, string> = {
  MANUAL: 'Manuale',
  AUTO: 'Automatica (motore regole)',
  WATCHDOG: 'Watchdog',
}

/* Filtri: Tutti + stati/priorità del workflow (i valori distinti reali
 * crescono via transizioni PATCH; il filtro «Tutti» copre tutto). */
type StatusFilterKey = 'all' | 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED'
const STATUS_FILTERS: Array<{ value: StatusFilterKey; label: string; api?: string }> = [
  { value: 'all', label: 'Tutti', api: undefined },
  { value: 'OPEN', label: 'Aperti', api: 'OPEN' },
  { value: 'IN_PROGRESS', label: 'In lavorazione', api: 'IN_PROGRESS' },
  { value: 'RESOLVED', label: 'Risolti', api: 'RESOLVED' },
  { value: 'CLOSED', label: 'Chiusi', api: 'CLOSED' },
]

type PriorityFilterKey = 'all' | 'CRITICAL' | 'HIGH'
const PRIORITY_FILTERS: Array<{ value: PriorityFilterKey; label: string; api?: string }> = [
  { value: 'all', label: 'Tutte', api: undefined },
  { value: 'CRITICAL', label: 'Critiche', api: 'CRITICAL' },
  { value: 'HIGH', label: 'Alte', api: 'HIGH' },
]

/* Manutenzioni: label dei vocabolari reali del modello (valore grezzo
 * visibile se ignoto — mai traduzione inventata). */
const MW_TYPE_LABELS: Record<string, { label: string; hint: string }> = {
  WITH_DATA: { label: 'Con raccolta dati', hint: 'suppressione allarmi attiva durante la finestra' },
  NO_DATA: { label: 'Raccolta sospesa', hint: 'raccolta dati sospesa durante la finestra' },
}
const MW_SCHEDULE_LABELS: Record<string, string> = {
  ONCE: 'Una volta',
  DAILY: 'Giornaliera',
  WEEKLY: 'Settimanale',
  MONTHLY: 'Mensile',
}
const WEEKDAY_LABELS = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'] // 1 = lunedì

/* Gruppi dispositivi (16.3 W3): colore di DEFAULT del modello
 * DeviceGroup — è un DATO dell'operatore salvato nel DB, NON un
 * colore del tema: nel markup vive solo come inline style. */
const DEFAULT_GROUP_COLOR = '#3b82f6'
const COLOR_HEX_RE = /^#[0-9a-fA-F]{6}$/

/** Dispositivo selezionato nel selettore multi del dialog gruppo: i
 *  campi sono SOLO quelli mostrati nelle chip (hostname, tipo, sede). */
type PickedDevice = { id: string; hostname: string; type: string; locationName: string | null }

/** Epoch ms → stringa data locale yyyy-mm-dd per <input type=date>.
 *  Usata per precaricare la «fine validità» di una finestra esistente
 *  SENZA spostare il valore (il confronto avviene sulla stringa). */
function toLocalDateStr(epoch: number): string {
  const d = new Date(epoch)
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Durata compatta per la colonna SLA («tra 3 h», «in ritardo da 2 g»). */
function fmtDuration(ms: number): string {
  const abs = Math.abs(ms)
  const min = Math.floor(abs / 60000)
  if (min < 60) return `${Math.max(1, min)} min`
  const h = Math.floor(min / 60)
  if (h < 24) return `${h} h`
  return `${Math.floor(h / 24)} g`
}

/* ================================================================
 * OperazioniView
 * ================================================================ */

export default function OperazioniView() {
  return (
    <div>
      <PageHeader
        title="Operazioni"
        subtitle="Ticket, finestre di manutenzione, gruppi dispositivi, scansione rete e operazioni evolute del DB reale"
      />
      <Tabs defaultValue="ticket">
        {/* 5 tab: su mobile (390px) la lista SCORRE
         * orizzontalmente invece di sbordare (stesso pattern della
         * scheda dispositivo); da sm in poi torna inline centrata. */}
        <TabsList
          aria-label="Sezioni della vista Operazioni"
          className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit sm:justify-center"
        >
          <TabsTrigger value="ticket" className="shrink-0">Ticket</TabsTrigger>
          <TabsTrigger value="manutenzioni" className="shrink-0">Finestre di manutenzione</TabsTrigger>
          <TabsTrigger value="gruppi" className="shrink-0">Gruppi dispositivi</TabsTrigger>
          <TabsTrigger value="scansione" className="shrink-0">Scansione &amp; Adozione</TabsTrigger>
          <TabsTrigger value="evolute" className="shrink-0">Operazioni evolute</TabsTrigger>
          <TabsTrigger value="kb" className="shrink-0">Knowledge base</TabsTrigger>
          <TabsTrigger value="rma" className="shrink-0">RMA e ondate</TabsTrigger>
        </TabsList>
        <TabsContent value="ticket" className="mt-4">
          <TicketsSection />
        </TabsContent>
        <TabsContent value="manutenzioni" className="mt-4">
          <MaintenanceSection />
        </TabsContent>
        <TabsContent value="gruppi" className="mt-4">
          <DeviceGroupsSection />
        </TabsContent>
        <TabsContent value="scansione" className="mt-4">
          <ScansioneAdozioneSection />
        </TabsContent>
        <TabsContent value="evolute" className="mt-4">
          <OperazioniEvoluteSection />
        </TabsContent>
        {/* 16.9 W4: knowledge base (CRUD + da ticket) e RMA/ondate
         * (sostituzione guidata + ondate con preflight, D2 onesto) */}
        <TabsContent value="kb" className="mt-4">
          <KbPanel />
        </TabsContent>
        <TabsContent value="rma" className="mt-4">
          <RmaOndatePanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}

/* ================================================================
 * Sezione Ticket
 * ================================================================ */

function TicketsSection() {
  const { data: session } = useSession()
  const queryClient = useQueryClient()
  const openDevice = useApp((s) => s.openDevice)
  const navigate = useApp((s) => s.navigate)

  /* Ruolo: il CLIENTE è in sola lettura (autorità permessi = backend) */
  const role = session?.user?.role
  const canAct = !!role && role !== 'CLIENTE'

  /* Filtri */
  const [statusKey, setStatusKey] = useState<StatusFilterKey>('all')
  const [priorityKey, setPriorityKey] = useState<PriorityFilterKey>('all')
  const [qInput, setQInput] = useState('')
  const [q, setQ] = useState('')
  const [page, setPage] = useState(1)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  /* Ricerca testuale con debounce (300 ms) */
  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim())
      setPage(1)
    }, 300)
    return () => clearTimeout(t)
  }, [qInput])

  const statusApi = STATUS_FILTERS.find((f) => f.value === statusKey)?.api
  const priorityApi = PRIORITY_FILTERS.find((f) => f.value === priorityKey)?.api

  const tickets = useQuery({
    queryKey: ['tickets', statusKey, priorityKey, q, page],
    queryFn: () => api.tickets({
      status: statusApi,
      priority: priorityApi,
      q: q || undefined,
      page,
      pageSize: PAGE_SIZE,
    }),
    placeholderData: keepPreviousData,
    staleTime: 15_000,
  })

  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    refetchInterval: 60_000,
  })

  const pageData = tickets.data?.data
  const items = pageData?.items ?? []
  const total = pageData?.total ?? 0
  const shownPage = pageData?.page ?? 1
  const pageCount = pageData?.pageCount ?? 1
  const kpis = pageData?.kpis
  const asOf = tickets.data?.asOf

  /* --- Transizioni di stato (mutazione reale, esito reale) --- */
  const [resolveTarget, setResolveTarget] = useState<TicketRow | null>(null)
  const [resolveText, setResolveText] = useState('')
  const [closeTarget, setCloseTarget] = useState<TicketRow | null>(null)
  const [newTicketOpen, setNewTicketOpen] = useState(false)

  /* 16.8 (W2 residua): «Scheda intervento» — documento stampabile
   * per il tecnico in campo (dialog di anteprima + stampa/PDF). */
  const [schedaTicketId, setSchedaTicketId] = useState<string | null>(null)

  const transition = useMutation({
    mutationFn: (v: { id: string; patch: Parameters<typeof api.updateTicket>[1] }) => api.updateTicket(v.id, v.patch),
    onSuccess: (row, vars) => {
      const toLabel = TICKET_STATUS_META[row.status]?.label ?? row.status
      const verb = vars.patch.status === 'IN_PROGRESS' ? 'preso in carico' : vars.patch.status === 'RESOLVED' ? 'risolto' : 'chiuso'
      toast.success(`Ticket ${verb}`, {
        description: `«${row.title.slice(0, 60)}${row.title.length > 60 ? '…' : ''}» → ${toLabel}. Azione registrata nell'audit.`,
      })
      setResolveTarget(null)
      setResolveText('')
      setCloseTarget(null)
      void queryClient.invalidateQueries({ queryKey: ['tickets'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Transizione non riuscita', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  const openDeviceFromTicket = (deviceId: string) => {
    openDevice(deviceId)
    navigate('dispositivi')
  }

  return (
    <div>
      {/* KPI strip: 4 card REALI con definizione in tooltip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard
          label="Aperti"
          value={kpis ? kpis.open : '…'}
          asOf={asOf}
          accent={kpis ? (kpis.open > 0 ? 'warn' : 'ok') : 'none'}
          definition="Ticket con stato OPEN nel DB reale dell'impianto (nessun filtro utente applicato)."
        />
        <KpiCard
          label="In lavorazione"
          value={kpis ? kpis.inProgress : '…'}
          asOf={asOf}
          accent={kpis ? (kpis.inProgress > 0 ? 'info' : 'none') : 'none'}
          definition="Ticket con stato IN_PROGRESS: presa in carico effettuata da un operatore."
        />
        <KpiCard
          label="Risolti (7 giorni)"
          value={kpis ? kpis.resolved7d : '…'}
          asOf={asOf}
          accent={kpis ? (kpis.resolved7d > 0 ? 'ok' : 'none') : 'none'}
          definition="Ticket con resolvedAt negli ultimi 7 giorni."
        />
        <KpiCard
          label="SLA scaduti"
          value={kpis ? kpis.slaOverdue : '…'}
          asOf={asOf}
          accent={kpis ? (kpis.slaOverdue > 0 ? 'crit' : 'none') : 'none'}
          definition="Ticket non chiusi (OPEN o IN_PROGRESS) con slaResolutionDueAt precedente a adesso. Nel DB reale attuale nessun ticket ha SLA impostate: il conteggio resta 0 finché il motore non ne scrive."
        />
      </div>

      {/* Filtri + nuovo ticket */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Select
          value={statusKey}
          onValueChange={(v) => { setStatusKey(v as StatusFilterKey); setPage(1) }}
        >
          <SelectTrigger className="w-[160px]" aria-label="Filtro stato ticket">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STATUS_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={priorityKey}
          onValueChange={(v) => { setPriorityKey(v as PriorityFilterKey); setPage(1) }}
        >
          <SelectTrigger className="w-[140px]" aria-label="Filtro priorità">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {PRIORITY_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="relative min-w-[180px] flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-text-2" aria-hidden />
          <Input
            type="search"
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            placeholder="Cerca titolo, descrizione, assegnatario…"
            aria-label="Ricerca testuale nei ticket"
            className="pl-8"
          />
        </div>

        <Button
          variant="outline"
          className="h-9"
          onClick={() => { void tickets.refetch() }}
          disabled={tickets.isFetching}
        >
          <RefreshCw className={cn('size-3.5', tickets.isFetching && 'animate-spin')} aria-hidden />
          Aggiorna
        </Button>

        {canAct ? (
          <Button className="ml-auto h-9" onClick={() => setNewTicketOpen(true)}>
            <Plus className="size-3.5" aria-hidden />
            Nuovo ticket
          </Button>
        ) : null}
      </div>

      {/* Nota ordinamento */}
      <div className="mt-3 mb-2 flex items-center justify-between gap-2">
        <p className="text-xs text-text-2">Ordinati per ultimo aggiornamento, i più recenti prima</p>
        {tickets.isFetching && !tickets.isPending ? (
          <span className="flex items-center gap-1 text-xs text-text-2">
            <Loader2 className="size-3 animate-spin" aria-hidden />
            aggiornamento…
          </span>
        ) : null}
      </div>

      {/* Tabella */}
      {tickets.isPending ? (
        <LoadingRows rows={8} />
      ) : tickets.isError ? (
        <ErrorPanel
          message={errInfo(tickets.error).message}
          code={errInfo(tickets.error).code}
          onRetry={() => { void tickets.refetch() }}
        />
      ) : items.length === 0 ? (
        <EmptyState
          title="Nessun ticket con questi filtri"
          description="Nessun ticket del DB reale corrisponde a stato, priorità e ricerca correnti. Prova a modificare i filtri."
        />
      ) : (
        <div
          className={cn(
            'overflow-x-auto rounded-lg border border-border/70 bg-surface transition-opacity',
            tickets.isFetching && 'opacity-70',
          )}
          aria-busy={tickets.isFetching}
        >
          <TooltipProvider delayDuration={150}>
            <Table>
              <TableCaption className="sr-only">
                Ticket del DB reale: titolo, priorità, stato, SLA, assegnatario e ultimo aggiornamento
              </TableCaption>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead scope="col" className="min-w-[220px]">Titolo</TableHead>
                  <TableHead scope="col" className="w-[110px]">Priorità</TableHead>
                  <TableHead scope="col" className="w-[130px]">Stato</TableHead>
                  <TableHead scope="col" className="w-[130px]">
                    SLA
                  </TableHead>
                  <TableHead scope="col" className="w-[140px]">Assegnatario</TableHead>
                  <TableHead scope="col" className="w-[110px]">
                    Agg. {asOf ? <AsOf ts={asOf} prefix="· dati alle" className="ml-0.5" /> : null}
                  </TableHead>
                  <TableHead scope="col" className="w-[260px]">
                    <span className="sr-only">Azioni</span>
                    Azioni
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((t) => (
                  <TicketItem
                    key={t.id}
                    ticket={t}
                    canAct={canAct}
                    expanded={expandedId === t.id}
                    pending={transition.isPending && transition.variables?.id === t.id}
                    onToggleDetails={() => setExpandedId(expandedId === t.id ? null : t.id)}
                    onOpenDevice={openDeviceFromTicket}
                    onTake={(ticket) => transition.mutate({ id: ticket.id, patch: { status: 'IN_PROGRESS' } })}
                    onResolve={(ticket) => { setResolveTarget(ticket); setResolveText('') }}
                    onClose={(ticket) => setCloseTarget(ticket)}
                    onScheda={(ticket) => setSchedaTicketId(ticket.id)}
                  />
                ))}
              </TableBody>
            </Table>
          </TooltipProvider>
        </div>
      )}

      {/* Paginazione */}
      {!tickets.isPending && !tickets.isError && total > 0 ? (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-text-2">
            Pagina <span className="num">{shownPage}</span> di <span className="num">{pageCount}</span> ·{' '}
            <span className="num">{fmtNumber(total)}</span> ticket
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={shownPage <= 1 || tickets.isFetching}
              onClick={() => setPage(shownPage - 1)}
            >
              <ChevronLeft className="size-3.5" aria-hidden />
              Precedente
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={shownPage >= pageCount || tickets.isFetching}
              onClick={() => setPage(shownPage + 1)}
            >
              Successiva
              <ChevronRight className="size-3.5" aria-hidden />
            </Button>
          </div>
        </div>
      ) : null}

      {/* Conferma «Risolvi»: risoluzione obbligatoria */}
      <AlertDialog
        open={!!resolveTarget}
        onOpenChange={(open) => {
          if (!open && !transition.isPending) { setResolveTarget(null); setResolveText('') }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Risolvi il ticket</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Il ticket passa a <strong className="text-foreground">Risolto</strong> e la risoluzione
              resta nel DB. La transizione è valida da <em>In lavorazione</em>; l'azione registra chi,
              quando e una voce di audit.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {resolveTarget ? (
            <p className="line-clamp-2 break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2" title={resolveTarget.title}>
              {resolveTarget.title}
            </p>
          ) : null}
          <div className="grid gap-1.5">
            <label htmlFor="resolve-text" className="text-xs font-medium text-text-2">
              Risoluzione (obbligatoria, max 2000 caratteri)
            </label>
            <Textarea
              id="resolve-text"
              value={resolveText}
              maxLength={2000}
              onChange={(e) => setResolveText(e.target.value)}
              placeholder="es. sostituito alimentatore switch, verifica con ping OK…"
              aria-required="true"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={transition.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              disabled={transition.isPending || !resolveText.trim()}
              onClick={(e) => {
                e.preventDefault() // resta aperto finché la risposta reale non arriva
                if (!resolveTarget || transition.isPending) return
                transition.mutate({ id: resolveTarget.id, patch: { status: 'RESOLVED', resolution: resolveText.trim() } })
              }}
            >
              {transition.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
              Risolvi
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Conferma «Chiudi» */}
      <AlertDialog
        open={!!closeTarget}
        onOpenChange={(open) => { if (!open && !transition.isPending) setCloseTarget(null) }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {closeTarget?.status === 'OPEN' ? 'Chiudi direttamente il ticket' : 'Chiudi il ticket'}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              {closeTarget?.status === 'OPEN'
                ? 'Chiusura diretta da Aperto (es. annullamento o intervento già completato). Se vuoi lasciare traccia, usa prima «Prendi in carico» e poi «Risolvi» con la risoluzione.'
                : 'Il ticket passa a Chiuso definitivamente. L\'azione registra chi, quando e una voce di audit.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {closeTarget ? (
            <p className="line-clamp-2 break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2" title={closeTarget.title}>
              {closeTarget.title}
            </p>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={transition.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              disabled={transition.isPending}
              onClick={(e) => {
                e.preventDefault()
                if (!closeTarget || transition.isPending) return
                transition.mutate({ id: closeTarget.id, patch: { status: 'CLOSED' } })
              }}
            >
              {transition.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
              Chiudi
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Nuovo ticket */}
      {canAct ? (
        <NewTicketDialog
          open={newTicketOpen}
          onOpenChange={setNewTicketOpen}
        />
      ) : null}

      {/* 16.8: «Scheda intervento» (anteprima + stampa/PDF) */}
      <SchedaIntervento ticketId={schedaTicketId} onClose={() => setSchedaTicketId(null)} />
    </div>
  )
}

/* ================================================================
 * Riga ticket (espandibile)
 * ================================================================ */

function TicketItem({
  ticket, canAct, expanded, pending, onToggleDetails, onOpenDevice, onTake, onResolve, onClose, onScheda,
}: {
  ticket: TicketRow
  canAct: boolean
  expanded: boolean
  pending: boolean
  onToggleDetails: () => void
  onOpenDevice: (id: string) => void
  onTake: (t: TicketRow) => void
  onResolve: (t: TicketRow) => void
  onClose: (t: TicketRow) => void
  onScheda: (t: TicketRow) => void
}) {
  const statusMeta = TICKET_STATUS_META[ticket.status] ?? { label: ticket.status, cls: 'bg-raised text-text-2 border-border', Icon: CircleAlert }
  const prioMeta = PRIORITY_META[ticket.priority] ?? { label: ticket.priority, cls: 'bg-raised text-text-2 border-border', Icon: CircleAlert }
  const detailsId = `ticket-details-${ticket.id}`
  const deviceId = ticket.device?.id

  /* SLA: scaduto solo per ticket non chiusi con scadenza passata */
  const slaOverdue = ticket.slaResolutionDueAt != null
    && (ticket.status === 'OPEN' || ticket.status === 'IN_PROGRESS')
    && ticket.slaResolutionDueAt < Date.now()

  return (
    <>
      <TableRow className={cn('align-top', pending && 'opacity-60')}>
        <TableCell className="max-w-[280px]">
          <button
            type="button"
            className="line-clamp-2 break-words text-left text-sm font-medium hover:text-link hover:underline"
            title={ticket.title}
            onClick={onToggleDetails}
            aria-expanded={expanded}
            aria-controls={detailsId}
          >
            {ticket.title}
          </button>
          {ticket.device ? (
            <span className="mt-1 flex items-center gap-1.5 text-xs text-text-2">
              <Monitor className="size-3.5 shrink-0" aria-hidden />
              <button
                type="button"
                className="truncate font-medium text-link hover:underline"
                onClick={() => deviceId && onOpenDevice(deviceId)}
                title={`Apri ${ticket.device.hostname}`}
              >
                {ticket.device.hostname}
              </button>
              {ticket.device.ip ? <span className="num shrink-0">{ticket.device.ip}</span> : null}
            </span>
          ) : null}
        </TableCell>
        <TableCell>
          <Badge variant="outline" className={cn('gap-1.5 font-medium whitespace-nowrap', prioMeta.cls)}>
            <prioMeta.Icon className="size-3.5" aria-hidden />
            {prioMeta.label}
          </Badge>
        </TableCell>
        <TableCell>
          <Badge variant="outline" className={cn('gap-1.5 font-medium whitespace-nowrap', statusMeta.cls)}>
            <statusMeta.Icon className="size-3.5" aria-hidden />
            {statusMeta.label}
          </Badge>
        </TableCell>
        <TableCell>
          {ticket.slaResolutionDueAt == null ? (
            <span className="text-xs text-text-2" title="Nessuna scadenza SLA impostata su questo ticket">n.d.</span>
          ) : slaOverdue ? (
            <span className="font-medium text-crit" title={`Scadenza SLA: ${fmtDateTimeFull(ticket.slaResolutionDueAt)}`}>
              in ritardo
              <span className="sr-only"> dal {fmtDateTime(ticket.slaResolutionDueAt)}</span>
            </span>
          ) : (
            <span className="num text-xs text-text-2" title={`Scadenza SLA: ${fmtDateTimeFull(ticket.slaResolutionDueAt)}`}>
              tra {fmtDuration(ticket.slaResolutionDueAt - Date.now())}
            </span>
          )}
        </TableCell>
        <TableCell>
          <span className="block max-w-[130px] truncate text-xs" title={ticket.assignedTo || undefined}>
            {ticket.assignedTo || 'n.d.'}
          </span>
        </TableCell>
        <TableCell>
          <span className="num text-xs text-text-2" title={fmtDateTimeFull(ticket.updatedAt)}>
            {fmtRelative(ticket.updatedAt)}
          </span>
        </TableCell>
        <TableCell>
          <div className="flex flex-wrap items-center gap-1.5">
            {pending ? (
              <span className="flex items-center gap-1 text-xs text-text-2">
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
                attendi…
              </span>
            ) : canAct ? (
              <>
                {ticket.status === 'OPEN' ? (
                  <Button variant="ghost" size="sm" className="h-8 gap-1 px-2 text-xs" onClick={() => onTake(ticket)}>
                    <UserCheck className="size-3.5" aria-hidden />
                    Prendi in carico
                  </Button>
                ) : null}
                {ticket.status === 'IN_PROGRESS' ? (
                  <Button variant="ghost" size="sm" className="h-8 gap-1 px-2 text-xs" onClick={() => onResolve(ticket)}>
                    <CircleCheck className="size-3.5" aria-hidden />
                    Risolvi
                  </Button>
                ) : null}
                {ticket.status === 'OPEN' || ticket.status === 'RESOLVED' ? (
                  <Button variant="ghost" size="sm" className="h-8 gap-1 px-2 text-xs text-text-2" onClick={() => onClose(ticket)}>
                    <CheckCheck className="size-3.5" aria-hidden />
                    Chiudi
                  </Button>
                ) : null}
              </>
            ) : null}
            <Button
              variant="ghost"
              size="sm"
              className="h-8 gap-1 px-2 text-xs text-text-2"
              onClick={onToggleDetails}
              aria-expanded={expanded}
              aria-controls={detailsId}
              aria-label={`Dettaglio del ticket ${ticket.title.slice(0, 40)}`}
            >
              <ChevronDown className={cn('size-3.5 transition-transform', expanded && 'rotate-180')} aria-hidden />
              Dettaglio
            </Button>
            {/* 16.8: «Scheda intervento» — documento stampabile per il
             * tecnico in campo (sola lettura: disponibile a ogni ruolo) */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 text-text-2"
                  onClick={() => onScheda(ticket)}
                  aria-label={`Scheda intervento di ${ticket.title.slice(0, 40)}`}
                  title="Scheda intervento (documento stampabile per il tecnico)"
                >
                  <FileText className="size-3.5" aria-hidden />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top" className="text-xs">
                Scheda intervento (documento stampabile per il tecnico)
              </TooltipContent>
            </Tooltip>
          </div>
        </TableCell>
      </TableRow>

      {/* Dettaglio espandibile */}
      {expanded ? (
        <TableRow className="bg-raised/25 hover:bg-raised/25">
          <TableCell colSpan={7} className="px-4 py-3">
            <div id={detailsId}>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-dim">Descrizione</p>
              <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-relaxed">{ticket.description || 'n.d.'}</p>

              {ticket.rootCause ? (
                <>
                  <p className="mt-3 text-[10px] font-semibold uppercase tracking-wider text-dim">Causa radice</p>
                  <p className="mt-1 break-words text-xs leading-relaxed">{ticket.rootCause}</p>
                </>
              ) : null}
              {ticket.resolution ? (
                <>
                  <p className="mt-3 text-[10px] font-semibold uppercase tracking-wider text-dim">Risoluzione</p>
                  <p className="mt-1 break-words text-xs leading-relaxed">{ticket.resolution}</p>
                </>
              ) : null}

              <dl className="mt-3 grid gap-x-6 gap-y-1.5 text-xs sm:grid-cols-2">
                <Hist label="Creato" value={fmtDateTimeFull(ticket.createdAt)} />
                <Hist label="Aggiornato" value={fmtDateTimeFull(ticket.updatedAt)} />
                {ticket.resolvedAt != null ? <Hist label="Risolto" value={fmtDateTimeFull(ticket.resolvedAt)} /> : null}
                {ticket.closedAt != null ? <Hist label="Chiuso" value={fmtDateTimeFull(ticket.closedAt)} /> : null}
                <Hist label="Sorgente" value={SOURCE_LABELS[ticket.source] ?? ticket.source} />
                <Hist label="Sede" value={ticket.locationName ?? 'n.d.'} />
                <Hist label="Escalation" value={ticket.escalationLevel > 0 ? `livello ${ticket.escalationLevel}` : 'nessuna'} />
                <Hist
                  label="Interventi / commenti"
                  value={`${fmtNumber(ticket.interventionsCount)} / ${fmtNumber(ticket.commentsCount)}`}
                />
              </dl>
            </div>
          </TableCell>
        </TableRow>
      ) : null}
    </>
  )
}

/* ================================================================
 * Dialog «Nuovo ticket» (creazione reale)
 * ================================================================ */

function NewTicketDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const queryClient = useQueryClient()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [priority, setPriority] = useState<'CRITICAL' | 'HIGH'>('HIGH')
  const [formError, setFormError] = useState<string | null>(null)
  const [device, setDevice] = useState<DeviceRow | null>(null)
  const [pickerOpen, setPickerOpen] = useState(false)
  const [pickerQuery, setPickerQuery] = useState('')

  /* Ricerca dispositivi server-side (ricerca reale, nessun elenco finto) */
  const deviceSearch = useQuery({
    queryKey: ['ticket-device-search', pickerQuery],
    queryFn: () => api.devices({ q: pickerQuery || undefined, pageSize: 20 }),
    enabled: pickerOpen,
    staleTime: 10_000,
  })

  const create = useMutation({
    mutationFn: (input: { title: string; description: string; priority: 'CRITICAL' | 'HIGH'; deviceId?: string }) =>
      api.createTicket(input),
    onSuccess: (row) => {
      toast.success('Ticket creato', {
        description: `«${row.title.slice(0, 60)}${row.title.length > 60 ? '…' : ''}» — stato ${TICKET_STATUS_META[row.status]?.label ?? row.status}, assegnato a ${row.assignedTo || 'n.d.'}.`,
      })
      resetForm()
      onOpenChange(false)
      void queryClient.invalidateQueries({ queryKey: ['tickets'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      setFormError(`${e.message}${e.code ? ` (codice ${e.code})` : ''}`)
    },
  })

  const resetForm = () => {
    setTitle('')
    setDescription('')
    setPriority('HIGH')
    setDevice(null)
    setPickerQuery('')
    setFormError(null)
  }

  const submit = () => {
    /* Validazione onesta lato client (la stessa del contratto server) */
    if (title.trim().length < 5) { setFormError('Il titolo richiede almeno 5 caratteri.'); return }
    if (description.trim().length < 10) { setFormError('La descrizione richiede almeno 10 caratteri.'); return }
    setFormError(null)
    create.mutate({
      title: title.trim(),
      description: description.trim(),
      priority,
      deviceId: device?.id,
    })
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o && !create.isPending) { onOpenChange(false); resetForm() }
        else if (o) onOpenChange(true)
      }}
    >
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Nuovo ticket</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Crea un ticket reale nel DB dell'impianto: sorgente «manuale», stato iniziale Aperto,
            assegnato all'operatore connesso. La creazione è registrata nell'audit.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <label htmlFor="ticket-title" className="text-xs font-medium text-text-2">
              Titolo (min 5 caratteri)
            </label>
            <Input
              id="ticket-title"
              value={title}
              maxLength={200}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="es. Sostituzione antenna radio P4"
              aria-required="true"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="ticket-desc" className="text-xs font-medium text-text-2">
              Descrizione (min 10 caratteri)
            </label>
            <Textarea
              id="ticket-desc"
              value={description}
              maxLength={5000}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="es. Il link radio verso P4 è degradato da ieri; verificare allineamento e connettori."
              aria-required="true"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="ticket-priority" className="text-xs font-medium text-text-2">
              Priorità (valori reali del DB)
            </label>
            <Select value={priority} onValueChange={(v) => { setPriority(v as 'CRITICAL' | 'HIGH') }}>
              <SelectTrigger id="ticket-priority" aria-label="Priorità del ticket">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="HIGH">
                  <span className="inline-flex items-center gap-1.5">
                    <TriangleAlert className="size-3.5 text-warn" aria-hidden /> Alta
                  </span>
                </SelectItem>
                <SelectItem value="CRITICAL">
                  <span className="inline-flex items-center gap-1.5">
                    <OctagonAlert className="size-3.5 text-crit" aria-hidden /> Critica
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[11px] text-text-2">
              Il DB reale contiene ticket con priorità Critica e Alta: sono le uniche selezionabili.
            </p>
          </div>

          <div className="grid gap-1.5">
            <span className="text-xs font-medium text-text-2">Dispositivo (opzionale)</span>
            <div className="flex flex-wrap items-center gap-2">
              {device ? (
                <Badge variant="outline" className="gap-1.5 border-link/40 bg-info-soft font-normal text-info">
                  <Monitor className="size-3.5" aria-hidden />
                  <span className="max-w-[180px] truncate">{device.hostname}</span>
                  <span className="num">{device.ip}</span>
                  <button
                    type="button"
                    className="ml-1 rounded-sm hover:text-foreground"
                    aria-label={`Rimuovi dispositivo ${device.hostname}`}
                    onClick={() => setDevice(null)}
                  >
                    ×
                  </button>
                </Badge>
              ) : null}
              <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9">
                    <Search className="size-3.5" aria-hidden />
                    {device ? 'Cambia dispositivo' : 'Collega un dispositivo'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[340px] p-0" align="start">
                  <Command shouldFilter={false}>
                    <CommandInput
                      placeholder="Cerca hostname, IP, modello…"
                      value={pickerQuery}
                      onValueChange={setPickerQuery}
                    />
                    <CommandList>
                      {deviceSearch.isPending ? (
                        <div className="flex items-center justify-center gap-2 px-3 py-6 text-xs text-text-2">
                          <Loader2 className="size-4 animate-spin" aria-hidden />
                          ricerca dispositivi…
                        </div>
                      ) : deviceSearch.isError ? (
                        <div className="px-3 py-6 text-center text-xs text-crit">
                          Ricerca non riuscita: {errInfo(deviceSearch.error).message}
                        </div>
                      ) : (
                        <>
                          <CommandEmpty>Nessun dispositivo trovato con questa ricerca.</CommandEmpty>
                          <CommandGroup heading="Dispositivi reali dell'impianto">
                            {(deviceSearch.data?.data.items ?? []).map((d) => (
                              <CommandItem
                                key={d.id}
                                value={d.id}
                                onSelect={() => {
                                  setDevice(d)
                                  setPickerOpen(false)
                                }}
                              >
                                <Monitor className="size-4 shrink-0" aria-hidden />
                                <span className="min-w-0 flex-1 truncate">{d.hostname}</span>
                                <span className="num shrink-0 text-xs text-text-2">{d.ip}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </>
                      )}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              <span className="text-[11px] text-text-2">
                Se collegato, il ticket eredita impianto e sede del dispositivo.
              </span>
            </div>
          </div>

          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs text-crit-text">
              {formError}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" disabled={create.isPending} onClick={() => { onOpenChange(false); resetForm() }}>
            Annulla
          </Button>
          <Button disabled={create.isPending} onClick={submit}>
            {create.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Plus className="size-4" aria-hidden />}
            Crea ticket
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * Sezione «Finestre di manutenzione» (dati REALI; creazione/modifica
 * completa/pausa/ripresa/eliminazione + scope per gruppi — 16.3 W3)
 * ================================================================ */

function MaintenanceSection() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<MaintenanceRow | null>(null)

  const maintenance = useQuery({
    queryKey: ['maintenance'],
    queryFn: () => api.maintenance(),
    staleTime: 60_000,
  })

  /* Gruppi REALI: colori/nomi per le chip degli scope sulle card
   * (chiave ['device-groups'] condivisa col tab «Gruppi dispositivi»). */
  const groups = useQuery({
    queryKey: ['device-groups'],
    queryFn: () => api.deviceGroups(),
    staleTime: 60_000,
  })
  const groupColorById = new Map((groups.data?.data.items ?? []).map((g) => [g.id, g.color]))

  /* Pausa/ripresa: PATCH { state } → riga aggiornata + audit. */
  const setState = useMutation({
    mutationFn: ({ id, state }: { id: string; state: 'ACTIVE' | 'PAUSED' }) => api.updateMaintenanceState(id, state),
    onSuccess: (row) => {
      toast.success(row.state === 'PAUSED' ? 'Finestra sospesa' : 'Finestra riattivata', {
        description: `«${row.name}» — stato salvato nel DB reale con audit MAINTENANCE_STATE.`,
      })
      void queryClient.invalidateQueries({ queryKey: ['maintenance'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Aggiornamento non riuscito', { description: `${info.message}${info.code ? ` (${info.code})` : ''}` })
    },
  })

  /* Eliminazione: DELETE con audit; gli interventi collegati restano. */
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteMaintenance(id),
    onSuccess: () => {
      toast.success('Finestra eliminata', { description: 'Rimossa dal DB reale con audit MAINTENANCE_DELETE; gli interventi collegati restano nel registro.' })
      void queryClient.invalidateQueries({ queryKey: ['maintenance'] })
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', { description: `${info.message}${info.code ? ` (${info.code})` : ''}` })
    },
  })

  const items = maintenance.data?.data.items ?? []
  const busy = setState.isPending || remove.isPending

  return (
    <div>
      {/* Nota onesta: creazione/modifica/pausa/eliminazione attive
       * (16.3); scope per gruppi ATTIVO con gruppi reali del tab
       * dedicato (il DB reale parte da 0 gruppi). */}
      <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2">
        <Wrench className="size-4 shrink-0 text-text-2" aria-hidden />
        <p className="min-w-0 flex-1 text-xs text-text-2">
          Le finestre sospendono la generazione degli allarmi durante gli interventi programmati
          (modello reale del DB). Creazione, modifica, pausa ed eliminazione attive con audit; lo
          scope per gruppi è attivo: i gruppi reali si creano nella scheda «Gruppi dispositivi»
          (il DB reale parte da 0 gruppi — dichiarato, nessun gruppo finto).
        </p>
        <Button size="sm" className="h-8 shrink-0" onClick={() => setCreateOpen(true)} aria-haspopup="dialog">
          <Plus className="size-3.5" aria-hidden />
          Nuova finestra
        </Button>
      </div>

      {maintenance.isPending ? (
        <LoadingRows rows={4} />
      ) : maintenance.isError ? (
        <ErrorPanel
          message={errInfo(maintenance.error).message}
          code={errInfo(maintenance.error).code}
          onRetry={() => { void maintenance.refetch() }}
        />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<CalendarClock className="size-10 text-text-2" aria-hidden />}
          title="Nessuna finestra di manutenzione nel DB reale"
          description="L'impianto non ha finestre di manutenzione configurate: nessuna soppressione programmata attiva. Usa «Nuova finestra» per programmarne una (scrittura reale nel DB con audit)."
        />
      ) : (
        <ul className="grid gap-3 md:grid-cols-2" aria-label="Finestre di manutenzione reali">
          {items.map((w) => (
            <MaintenanceCard
              key={w.id}
              w={w}
              busy={busy}
              groupColorById={groupColorById}
              onToggle={(state) => setState.mutate({ id: w.id, state })}
              onEdit={() => setEditTarget(w)}
              onDelete={() => remove.mutate(w.id)}
            />
          ))}
        </ul>
      )}
      {maintenance.data ? <AsOf ts={maintenance.data.asOf} className="mt-3" prefix="dati aggiornati alle" /> : null}

      {/* Dialog condiviso creazione/modifica (mount condizionato:
       * lo stato si prefilla dai props senza effetti — vedi commento
       * nel componente) */}
      {createOpen ? (
        <MaintenanceFormDialog
          mode="create"
          open
          onOpenChange={(o) => { if (!o) setCreateOpen(false) }}
        />
      ) : null}
      {editTarget ? (
        <MaintenanceFormDialog
          mode="edit"
          row={editTarget}
          open
          onOpenChange={(o) => { if (!o) setEditTarget(null) }}
        />
      ) : null}
    </div>
  )
}

/* ---------------- Card finestra con azioni ---------------- */

function MaintenanceCard({
  w, busy, groupColorById, onToggle, onEdit, onDelete,
}: {
  w: MaintenanceRow
  busy: boolean
  groupColorById: Map<string, string>
  onToggle: (state: 'ACTIVE' | 'PAUSED') => void
  onEdit: () => void
  onDelete: () => void
}) {
  const [confirmDelete, setConfirmDelete] = useState(false)
  const typeMeta = MW_TYPE_LABELS[w.type] ?? null
  const scheduleLabel = MW_SCHEDULE_LABELS[w.scheduleType] ?? w.scheduleType
  const active = w.state === 'ACTIVE'

  const days = w.daysOfWeek
    .filter((d) => d >= 1 && d <= 7)
    .map((d) => WEEKDAY_LABELS[d - 1])
    .join(', ')

  return (
    <li className="rounded-lg border border-border/70 bg-surface p-4">
      <div className="flex flex-wrap items-center gap-2">
        <CalendarClock className="size-4 shrink-0 text-text-2" aria-hidden />
        <p className="min-w-0 flex-1 truncate text-sm font-medium" title={w.name}>{w.name}</p>
        {/* Stato: icona + testo (mai solo colore) */}
        <Badge variant="outline" className={cn(
          'gap-1.5 font-medium whitespace-nowrap',
          active ? 'border-ok/40 bg-ok-soft text-ok' : 'border-warn/40 bg-warn-soft text-warn',
        )}>
          {active ? <Play className="size-3.5" aria-hidden /> : <Pause className="size-3.5" aria-hidden />}
          {active ? 'Attiva' : 'In pausa'}
        </Badge>
      </div>

      {w.description ? (
        <p className="mt-2 break-words text-xs leading-relaxed text-text-2">{w.description}</p>
      ) : null}

      <dl className="mt-3 grid gap-x-6 gap-y-1.5 text-xs">
        <Hist
          label="Tipo"
          value={
            typeMeta ? (
              <TooltipProvider delayDuration={150}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button type="button" className="cursor-help underline decoration-dotted underline-offset-2">
                      {typeMeta.label}
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="max-w-56 text-xs leading-relaxed">
                    {typeMeta.hint}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ) : (w.type || 'n.d.')
          }
        />
        <Hist label="Periodicità" value={scheduleLabel} />
        {w.scheduleType === 'WEEKLY' ? <Hist label="Giorni" value={days || 'n.d.'} /> : null}
        {w.scheduleType === 'MONTHLY' ? <Hist label="Giorno del mese" value={String(w.dayOfMonth)} /> : null}
        <Hist label="Orario" value={`${w.startTime || 'n.d.'} – ${w.endTime || 'n.d.'}`} />
        <Hist label="Validità" value={`${fmtDateTime(w.activeSince)} → ${w.activeUntil ? fmtDateTime(w.activeUntil) : 'senza scadenza'}`} />
      </dl>

      {/* Scope: chip con NOME reale del gruppo + pallino colore
       * (colore = dato operatore dal DB, inline style — non tema) */}
      <div className="mt-3">
        <p className="text-[10px] font-semibold uppercase tracking-wider text-dim">Gruppi collegati (scope)</p>
        {w.scopes.length > 0 ? (
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {w.scopes.map((s) => {
              const color = groupColorById.get(s.groupId)
              return (
                <Badge key={s.groupId} variant="outline" className="gap-1.5 font-normal" title={color ? `Colore del gruppo: ${color}` : undefined}>
                  {/* colore del gruppo: DATO dell'operatore salvato nel DB (eccezione inline style) */}
                  <span aria-hidden className="size-2.5 shrink-0 rounded-full border border-border" style={color ? { backgroundColor: color } : undefined} />
                  <span className="max-w-[160px] truncate">{s.name}</span>
                </Badge>
              )
            })}
          </div>
        ) : (
          <p className="mt-1 text-xs text-text-2">nessuno (finestra su tutto l'impianto)</p>
        )}
      </div>

      {/* Azioni: modifica completa (16.3), pausa/ripresa reversibile,
       * eliminazione con conferma esplicita. Mai input ignorato in
       * silenzio: errori → toast (gestiti nelle mutation della
       * sezione). Touch target ≥44px su mobile (h-11 sm:h-9). */}
      <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/50 pt-3">
        <Button
          variant="outline"
          size="sm"
          className="h-11 sm:h-8"
          disabled={busy}
          onClick={onEdit}
          aria-haspopup="dialog"
          aria-label={`Modifica la finestra ${w.name}`}
        >
          <Pencil className="size-3.5" aria-hidden />
          Modifica
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="h-11 sm:h-8"
          disabled={busy}
          onClick={() => onToggle(active ? 'PAUSED' : 'ACTIVE')}
          aria-label={active ? `Sospendi la finestra ${w.name}` : `Riattiva la finestra ${w.name}`}
        >
          {active ? <Pause className="size-3.5" aria-hidden /> : <Play className="size-3.5" aria-hidden />}
          {active ? 'Sospendi' : 'Riattiva'}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-11 text-crit hover:bg-crit-soft hover:text-crit-text sm:h-8"
          disabled={busy}
          onClick={() => setConfirmDelete(true)}
          aria-label={`Elimina la finestra ${w.name}`}
        >
          <Trash2 className="size-3.5" aria-hidden />
          Elimina
        </Button>
      </div>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare la finestra di manutenzione?</AlertDialogTitle>
            <AlertDialogDescription>
              «{w.name}» ({scheduleLabel}, {w.startTime}–{w.endTime}) sarà rimossa dal DB reale
              con voce di audit MAINTENANCE_DELETE. Gli eventuali interventi collegati restano
              nel registro. L&apos;operazione non è reversibile: ricrea la finestra se ti serve di nuovo.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={busy}
              onClick={(e) => {
                e.preventDefault()
                onDelete()
                setConfirmDelete(false)
              }}
            >
              <Trash2 className="size-3.5" aria-hidden />
              Elimina definitivamente
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </li>
  )
}

/* ---------------- Dialog creazione/modifica finestra (condiviso) ----------------
 * 16.3 W3: UN solo dialog per «Nuova finestra» (POST) e «Modifica»
 * (PATCH) — riduce la duplicazione del 16.2. Il componente è montato
 * SOLO quando serve (mount condizionato nel genitore): lo stato si
 * prefilla dai props con gli initializer di useState, niente
 * setState dentro effetti (regola lint react-hooks v6).
 * In modifica vengono inviati SOLO i campi cambiati (stessa semantica
 * del diff del server); la data di validità è confrontata come
 * stringa yyyy-mm-dd per non spostare l'epoch salvato. */

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/
const MW_SCHEDULES = ['ONCE', 'DAILY', 'WEEKLY', 'MONTHLY'] as const

function MaintenanceFormDialog({ mode, row, open, onOpenChange }: {
  mode: 'create' | 'edit'
  row?: MaintenanceRow | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()

  /* Prefill: create → default onesti; edit → valori REALI della riga
   * (giorni filtrati 1..7, orari grezzi, data locale senza spostamenti). */
  const [name, setName] = useState(row?.name ?? '')
  const [description, setDescription] = useState(row?.description ?? '')
  const [type, setType] = useState<'WITH_DATA' | 'NO_DATA'>(row?.type === 'NO_DATA' ? 'NO_DATA' : 'WITH_DATA')
  const [scheduleType, setScheduleType] = useState<(typeof MW_SCHEDULES)[number]>(
    MW_SCHEDULES.find((s) => s === row?.scheduleType) ?? 'ONCE',
  )
  const [days, setDays] = useState<number[]>(
    row && row.scheduleType === 'WEEKLY' ? row.daysOfWeek.filter((d) => d >= 1 && d <= 7) : [],
  )
  const [dayOfMonth, setDayOfMonth] = useState(
    row && row.dayOfMonth >= 1 && row.dayOfMonth <= 31 ? row.dayOfMonth : 1,
  )
  const [startTime, setStartTime] = useState(row && TIME_RE.test(row.startTime) ? row.startTime : '22:00')
  const [endTime, setEndTime] = useState(row && TIME_RE.test(row.endTime) ? row.endTime : '23:30')
  const [until, setUntil] = useState(row?.activeUntil ? toLocalDateStr(row.activeUntil) : '') // yyyy-mm-dd, vuoto = senza scadenza
  const [scopeIds, setScopeIds] = useState<string[]>(row?.scopes.map((s) => s.groupId) ?? [])
  const [error, setError] = useState<string | null>(null)

  /* Gruppi REALI per il selettore scope (chiave ['device-groups']
   * condivisa col tab «Gruppi dispositivi» e con la sezione finestre). */
  const groups = useQuery({
    queryKey: ['device-groups'],
    queryFn: () => api.deviceGroups(),
    staleTime: 60_000,
  })
  const groupItems = groups.data?.data.items ?? []

  const toggleScope = (id: string) => {
    setScopeIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createMaintenance>[0]) => api.createMaintenance(input),
    onSuccess: (r) => {
      toast.success('Finestra di manutenzione creata', {
        description: `«${r.name}» scritta nel DB reale (audit MAINTENANCE_CREATE${r.scopes.length > 0 ? `, scope su ${r.scopes.length} gruppi reali` : ''}).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['maintenance'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      setError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const update = useMutation({
    mutationFn: (v: { id: string; patch: Parameters<typeof api.updateMaintenance>[1] }) => api.updateMaintenance(v.id, v.patch),
    onSuccess: (r) => {
      toast.success('Finestra aggiornata', {
        description: `«${r.name}» — modifiche salvate nel DB reale (audit MAINTENANCE_UPDATE con diff).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['maintenance'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      setError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const pending = create.isPending || update.isPending

  const submit = () => {
    setError(null)
    /* Validazione onesta lato client (la stessa del contratto server) */
    if (name.trim().length < 3) { setError('Il nome deve avere almeno 3 caratteri'); return }
    if (!TIME_RE.test(startTime) || !TIME_RE.test(endTime)) { setError('Orari in formato HH:mm'); return }
    if (startTime === endTime) { setError('Orario di fine identico a quello di inizio (durata nulla)'); return }
    if (scheduleType === 'WEEKLY' && days.length === 0) { setError('Con periodicità settimanale seleziona almeno un giorno'); return }
    const activeUntil = until ? new Date(`${until}T23:59:59`).getTime() : null
    if (activeUntil != null && activeUntil <= Date.now()) { setError('La fine validità deve essere nel futuro'); return }

    if (mode === 'create') {
      create.mutate({
        name: name.trim(),
        description: description.trim(),
        type,
        scheduleType,
        daysOfWeek: scheduleType === 'WEEKLY' ? [...days].sort((a, b) => a - b) : [],
        dayOfMonth: scheduleType === 'MONTHLY' ? dayOfMonth : 1,
        startTime,
        endTime,
        activeUntil,
        groupIds: scopeIds.length > 0 ? [...scopeIds] : undefined,
      })
      return
    }

    /* --- Modifica: PATCH con SOLO i campi cambiati (il server rifà il
     *    diff: doppio controllo onesto, mai input fantasma) --- */
    if (!row) return
    const patch: Parameters<typeof api.updateMaintenance>[1] = {}
    if (name.trim() !== row.name) patch.name = name.trim()
    if (description.trim() !== row.description) patch.description = description.trim()
    if (type !== row.type) patch.type = type
    if (scheduleType !== row.scheduleType) patch.scheduleType = scheduleType
    /* Cambiando periodicità i giorni vanno azzerati/riempiti di
     * conseguenza (il server rifiuta giorni con schedule non WEEKLY). */
    const effDays = scheduleType === 'WEEKLY' ? [...days].sort((a, b) => a - b) : []
    const rowDays = [...row.daysOfWeek].sort((a, b) => a - b)
    if (effDays.join(',') !== rowDays.join(',')) patch.daysOfWeek = effDays
    const effDom = scheduleType === 'MONTHLY' ? dayOfMonth : 1
    if (effDom !== row.dayOfMonth) patch.dayOfMonth = effDom
    if (startTime !== row.startTime) patch.startTime = startTime
    if (endTime !== row.endTime) patch.endTime = endTime
    const rowUntil = row.activeUntil ? toLocalDateStr(row.activeUntil) : ''
    if (until !== rowUntil) patch.activeUntil = activeUntil // null = rimuovi scadenza
    const rowScopeIds = row.scopes.map((s) => s.groupId).sort().join(',')
    const formScopeIds = [...scopeIds].sort().join(',')
    if (formScopeIds !== rowScopeIds) patch.groupIds = [...scopeIds] // sostituzione integrale
    if (Object.keys(patch).length === 0) { setError('Nessuna modifica da salvare: i valori sono identici a quelli attuali della finestra.'); return }
    update.mutate({ id: row.id, patch })
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v && !pending) onOpenChange(false) }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? 'Nuova finestra di manutenzione' : 'Modifica finestra di manutenzione'}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {mode === 'create'
              ? 'Scrittura REALE nel DB (audit MAINTENANCE_CREATE). Lo scope su gruppi reali è opzionale: senza gruppi la finestra vale per l\'intero impianto.'
              : 'Modifica REALE nel DB (audit MAINTENANCE_UPDATE con diff dei campi). La sospensione/riattivazione resta dal bottone «Sospendi/Riattiva» della card (audit MAINTENANCE_STATE separato). Vengono inviati solo i campi cambiati.'}
          </DialogDescription>
        </DialogHeader>

        <form
          className="grid gap-3"
          onSubmit={(e) => { e.preventDefault(); submit() }}
          noValidate
        >
          <div className="grid gap-1.5">
            <label htmlFor="mw-name" className="text-xs font-medium text-text-2">Nome *</label>
            <Input id="mw-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="es. Manutenzione switch sede Comune" maxLength={120} aria-required="true" />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="mw-desc" className="text-xs font-medium text-text-2">Descrizione</label>
            <Textarea id="mw-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={2000} placeholder="Opzionale: motivo, tecnici coinvolti…" />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <label htmlFor="mw-type" className="text-xs font-medium text-text-2">Tipo</label>
              <Select value={type} onValueChange={(v) => setType(v as typeof type)}>
                <SelectTrigger id="mw-type" aria-label="Tipo di finestra"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="WITH_DATA">Con raccolta dati</SelectItem>
                  <SelectItem value="NO_DATA">Raccolta sospesa</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="mw-sched" className="text-xs font-medium text-text-2">Periodicità</label>
              <Select value={scheduleType} onValueChange={(v) => setScheduleType(v as typeof scheduleType)}>
                <SelectTrigger id="mw-sched" aria-label="Periodicità della finestra"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(MW_SCHEDULE_LABELS).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {scheduleType === 'WEEKLY' ? (
            <fieldset className="grid gap-1.5">
              <legend className="text-xs font-medium text-text-2">Giorni (almeno uno)</legend>
              <div className="flex flex-wrap gap-1.5">
                {WEEKDAY_LABELS.map((label, i) => {
                  const value = i + 1
                  const checked = days.includes(value)
                  return (
                    <button
                      key={value}
                      type="button"
                      role="checkbox"
                      aria-checked={checked}
                      aria-label={`Giorno ${label}`}
                      onClick={() => setDays((prev) => (checked ? prev.filter((d) => d !== value) : [...prev, value]))}
                      className={cn(
                        'rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors',
                        checked ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-raised text-text-2 hover:border-control-border',
                      )}
                    >
                      {label}
                    </button>
                  )
                })}
              </div>
            </fieldset>
          ) : null}

          {scheduleType === 'MONTHLY' ? (
            <div className="grid gap-1.5">
              <label htmlFor="mw-dom" className="text-xs font-medium text-text-2">Giorno del mese (1–31)</label>
              <Input
                id="mw-dom" type="number" min={1} max={31} value={dayOfMonth}
                onChange={(e) => setDayOfMonth(Math.min(31, Math.max(1, Number(e.target.value) || 1)))}
                className="num w-24"
              />
            </div>
          ) : null}

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <label htmlFor="mw-start" className="text-xs font-medium text-text-2">Orario inizio *</label>
              <Input id="mw-start" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="num" />
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="mw-end" className="text-xs font-medium text-text-2">Orario fine *</label>
              <Input id="mw-end" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className="num" />
            </div>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="mw-until" className="text-xs font-medium text-text-2">Fine validità</label>
            <Input id="mw-until" type="date" value={until} onChange={(e) => setUntil(e.target.value)} className="num" />
            <p className="text-[11px] text-dim">Vuoto = senza scadenza{mode === 'edit' ? ' (cancellare la data rimuove la scadenza attuale)' : ''}.</p>
          </div>

          {/* Scope: gruppi REALI (checkbox list). 0 gruppi → testo
           * onesto, nessun gruppo finto inventato. */}
          <fieldset className="grid gap-1.5">
            <legend className="text-xs font-medium text-text-2">Scope: gruppi dispositivi (opzionale)</legend>
            {groups.isPending ? (
              <p className="flex items-center gap-2 text-xs text-text-2">
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
                caricamento gruppi reali…
              </p>
            ) : groups.isError ? (
              <p className="text-xs text-crit" role="alert">
                Gruppi non caricabili: {errInfo(groups.error).message}
              </p>
            ) : groupItems.length === 0 ? (
              <p className="text-[11px] leading-relaxed text-text-2">
                Nessun gruppo disponibile: creane uno nella scheda «Gruppi dispositivi». Senza scope
                la finestra si applica all&apos;intero impianto.
              </p>
            ) : (
              <div
                className="grid max-h-44 gap-1 overflow-y-auto scroll-thin rounded-md border border-border/70 bg-raised/40 p-2"
                role="group"
                aria-label="Gruppi selezionabili come scope della finestra"
              >
                {groupItems.map((g) => {
                  const checked = scopeIds.includes(g.id)
                  return (
                    <label
                      key={g.id}
                      htmlFor={`mw-scope-${g.id}`}
                      className="flex min-h-11 cursor-pointer items-center gap-2.5 rounded-md px-2 py-1.5 text-sm hover:bg-raised/70"
                    >
                      <Checkbox
                        id={`mw-scope-${g.id}`}
                        checked={checked}
                        onCheckedChange={() => toggleScope(g.id)}
                        aria-label={`Usa il gruppo ${g.name} come scope`}
                      />
                      {/* colore del gruppo: DATO dell'operatore dal DB (eccezione inline style) */}
                      <span
                        aria-hidden
                        className="size-3 shrink-0 rounded-full border border-border"
                        style={COLOR_HEX_RE.test(g.color) ? { backgroundColor: g.color } : undefined}
                      />
                      <span className="min-w-0 flex-1 truncate" title={g.name}>{g.name}</span>
                      <span className="num shrink-0 text-xs text-text-2">{fmtNumber(g.memberCount)} disp.</span>
                    </label>
                  )
                })}
              </div>
            )}
            <p className="text-[11px] text-dim">
              Nessun gruppo selezionato = finestra su TUTTO l&apos;impianto. Il salvataggio{' '}
              {mode === 'edit' ? 'SOSTITUISCE integralmente gli scope attuali' : ' Collega i gruppi scelti come scope'}.
            </p>
          </fieldset>

          {error ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs text-crit-text">{error}</p>
          ) : null}

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="h-11 sm:h-9" onClick={() => onOpenChange(false)} disabled={pending}>
              Annulla
            </Button>
            <Button type="submit" className="h-11 sm:h-9" disabled={pending}>
              {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <CalendarClock className="size-3.5" aria-hidden />}
              {mode === 'create' ? (create.isPending ? 'Creazione…' : 'Crea finestra') : (update.isPending ? 'Salvataggio…' : 'Salva modifiche')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================================
 * Sezione «Gruppi dispositivi» (16.3 W3 — CRUD + membership MANUAL)
 * I gruppi sono entità GESTITE DALL'OPERATORE (come i ticket): il DB
 * reale parte da 0 gruppi (probe bun:sqlite readonly del 17-b) e la
 * lista vuota è dichiarata onestamente, NON mascherata.
 * ================================================================ */

function DeviceGroupsSection() {
  const { data: session } = useSession()
  const queryClient = useQueryClient()
  const role = session?.user?.role
  const canAct = !!role && role !== 'CLIENTE' // autorità permessi = backend

  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<DeviceGroupRow | null>(null)

  const groups = useQuery({
    queryKey: ['device-groups'],
    queryFn: () => api.deviceGroups(),
    staleTime: 60_000,
  })

  /* Finestre reali: contano gli scope per gruppo (badge in card e
   * avviso onesto nell'AlertDialog di eliminazione). */
  const maintenance = useQuery({
    queryKey: ['maintenance'],
    queryFn: () => api.maintenance(),
    staleTime: 60_000,
  })
  const windows = maintenance.data?.data.items ?? []
  const scopeCountOf = (groupId: string) =>
    windows.filter((w) => w.scopes.some((s) => s.groupId === groupId)).length

  /* Sedi REALI (16.4): per i gruppi DYNAMIC con criterio sede la card
   * mostra i NOMI delle sedi della regola, non gli id grezzi. */
  const locations = useQuery({
    queryKey: ['locations'],
    queryFn: () => api.locations(),
    staleTime: 60_000,
  })
  const locationNameOf = (id: string) =>
    locations.data?.data.find((l) => l.id === id)?.name ?? null

  /* Eliminazione: DELETE con audit; le finestre che lo usano come
   * scope NON vengono eliminate (perdono solo lo scope — cascade). */
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteDeviceGroup(id),
    onSuccess: (res) => {
      toast.success('Gruppo eliminato', {
        description: res.removedScopes > 0
          ? `Rimosso dal DB reale (audit DEVICE_GROUP_DELETE). ${res.removedScopes} finestr${res.removedScopes === 1 ? 'a' : 'e'} di manutenzione ${res.removedScopes === 1 ? 'lo usava' : 'lo usavano'} come scope: ${res.removedScopes === 1 ? 'resta, perde' : 'restano, perdono'} solo questo scope.`
          : 'Rimosso dal DB reale (audit DEVICE_GROUP_DELETE). I dispositivi restano nell\'inventario: eliminare un gruppo non dismette apparati.',
      })
      void queryClient.invalidateQueries({ queryKey: ['device-groups'] })
      void queryClient.invalidateQueries({ queryKey: ['maintenance'] }) // gli scope delle finestre sono cambiati
    },
    onError: (e) => {
      const info = errInfo(e)
      toast.error('Eliminazione non riuscita', { description: `${info.message}${info.code ? ` (${info.code})` : ''}` })
    },
  })

  const items = groups.data?.data.items ?? []

  return (
    <div>
      {/* Nota onesta: gruppi = entità gestite dall'operatore; DB reale
       * a 0 gruppi al rilascio 16.3 (probe readonly). 16.4: anche i
       * gruppi DYNAMIC (regola valutata a runtime sullo stato reale). */}
      <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2">
        <Layers className="size-4 shrink-0 text-text-2" aria-hidden />
        <p className="min-w-0 flex-1 text-xs text-text-2">
          I gruppi dispositivi sono entità gestite dall&apos;operatore (come i ticket) e si usano come
          scope delle finestre di manutenzione. Due tipi: MANUAL a membri espliciti e DYNAMIC con
          regola (tipo, stato, connessione, sede) valutata a runtime sullo stato reale dei
          dispositivi — la membership non viene salvata, si ricalcola a ogni lettura. Il DB reale
          parte da 0 gruppi: nessun gruppo finto, l&apos;elenco onesto è vuoto finché non ne crei.
        </p>
        {canAct ? (
          <Button size="sm" className="h-8 shrink-0" onClick={() => setCreateOpen(true)} aria-haspopup="dialog">
            <Plus className="size-3.5" aria-hidden />
            Nuovo gruppo
          </Button>
        ) : null}
      </div>

      {groups.isPending ? (
        <LoadingRows rows={4} />
      ) : groups.isError ? (
        <ErrorPanel
          message={errInfo(groups.error).message}
          code={errInfo(groups.error).code}
          onRetry={() => { void groups.refetch() }}
        />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<Layers className="size-10 text-text-2" aria-hidden />}
          title="Nessun gruppo nel database reale"
          description="Nessun gruppo nel database reale — crea il primo gruppo per usarlo come scope delle finestre di manutenzione. L'elenco parte vuoto perché i gruppi sono entità gestite dall'operatore: nessun gruppo inventato."
        />
      ) : (
        <ul className="grid gap-3 md:grid-cols-2" aria-label="Gruppi di dispositivi reali">
          {items.map((g) => (
            <DeviceGroupCard
              key={g.id}
              g={g}
              canAct={canAct}
              busy={remove.isPending}
              scopeCount={scopeCountOf(g.id)}
              locationNameOf={locationNameOf}
              onEdit={() => setEditTarget(g)}
              onDelete={() => remove.mutate(g.id)}
            />
          ))}
        </ul>
      )}
      {groups.data ? <AsOf ts={groups.data.asOf} className="mt-3" prefix="dati aggiornati alle" /> : null}

      {/* Dialog condiviso creazione/modifica (mount condizionato:
       * prefill dai props, niente setState in effetti) */}
      {createOpen ? (
        <DeviceGroupDialog
          mode="create"
          open
          onOpenChange={(o) => { if (!o) setCreateOpen(false) }}
        />
      ) : null}
      {editTarget ? (
        <DeviceGroupDialog
          mode="edit"
          group={editTarget}
          open
          onOpenChange={(o) => { if (!o) setEditTarget(null) }}
        />
      ) : null}
    </div>
  )
}

/* ---------------- Card gruppo con azioni ---------------- */

function DeviceGroupCard({
  g, canAct, busy, scopeCount, locationNameOf, onEdit, onDelete,
}: {
  g: DeviceGroupRow
  canAct: boolean
  busy: boolean
  scopeCount: number
  locationNameOf: (id: string) => string | null
  onEdit: () => void
  onDelete: () => void
}) {
  const [confirmDelete, setConfirmDelete] = useState(false)
  const dynamic = g.ruleType === 'DYNAMIC'
  const shown = g.members.slice(0, 8)
  const more = g.memberCount - shown.length

  return (
    <li className="rounded-lg border border-border/70 bg-surface p-4">
      <div className="flex flex-wrap items-center gap-2">
        {/* Colore del gruppo: DATO dell'operatore salvato nel DB (NON un
         * colore del tema) → unica eccezione inline style consentita. */}
        <span
          aria-hidden
          className="size-4 shrink-0 rounded-full border border-border"
          style={COLOR_HEX_RE.test(g.color) ? { backgroundColor: g.color } : undefined}
          title={COLOR_HEX_RE.test(g.color) ? `Colore del gruppo: ${g.color}` : 'Colore non valido nel DB'}
        />
        <p className="min-w-0 flex-1 truncate text-sm font-medium" title={g.name}>{g.name}</p>
        <Badge variant="outline" className="gap-1.5 font-medium whitespace-nowrap">
          <Monitor className="size-3.5" aria-hidden />
          <span className="num">{fmtNumber(g.memberCount)}</span> dispositiv{g.memberCount === 1 ? 'o' : 'i'}
        </Badge>
        <Badge
          variant="outline"
          className={
            dynamic
              ? 'gap-1.5 border-primary/40 bg-info-soft font-normal text-info whitespace-nowrap'
              : 'gap-1.5 font-normal whitespace-nowrap'
          }
          title={dynamic ? 'Appartenenza calcolata dalla regola a ogni lettura (non salvata nel DB)' : 'Membri espliciti salvati in DeviceGroupMember'}
        >
          {dynamic ? <Sparkles className="size-3.5" aria-hidden /> : <Layers className="size-3.5" aria-hidden />}
          {dynamic ? 'Dinamico' : 'Manuale'}
        </Badge>
      </div>

      {g.description ? (
        <p className="mt-2 break-words text-xs leading-relaxed text-text-2">{g.description}</p>
      ) : null}

      {dynamic ? <RuleSummary rules={g.rules} locationNameOf={locationNameOf} /> : null}

      {/* Membri: MANUAL = membri salvati; DYNAMIC = dispositivi che
       * soddisfano la regola ADESSO (calcolati a questa lettura). */}
      <div className="mt-3">
        <p className="text-[10px] font-semibold uppercase tracking-wider text-dim">
          {dynamic ? 'Corrispondono alla regola (ora)' : 'Membri'}
        </p>
        {g.memberCount === 0 ? (
          <p className="mt-1 text-xs text-text-2">
            {dynamic
              ? 'nessun dispositivo corrisponde alla regola in questo momento'
              : 'nessun dispositivo (gruppo vuoto)'}
          </p>
        ) : (
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {shown.map((m) => (
              <Badge
                key={m.id}
                variant="outline"
                className="max-w-[220px] gap-1.5 font-normal"
                title={`${m.hostname} · ${m.type}${m.locationName ? ` · ${m.locationName}` : ' · senza sede'}`}
              >
                <Monitor className="size-3 shrink-0" aria-hidden />
                <span className="truncate">{m.hostname}</span>
              </Badge>
            ))}
            {more > 0 ? (
              <Badge
                variant="outline"
                className="gap-1 font-normal"
                title={`Altri ${more} oltre ai primi 8 mostrati${g.memberCount > g.members.length ? ` (la API elenca i primi 500 su ${fmtNumber(g.memberCount)} totali)` : ''}`}
              >
                +<span className="num">{fmtNumber(more)}</span> altri
              </Badge>
            ) : null}
          </div>
        )}
        {dynamic ? (
          <p className="mt-1.5 text-[11px] text-dim">
            Elenco ricalcolato a ogni lettura: se un dispositivo cambia tipo, stato, connessione o
            sede entra o esce dal gruppo da solo (nessuna membership salvata).
          </p>
        ) : null}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/50 pt-3">
        {canAct ? (
          <>
            <Button
              variant="outline"
              size="sm"
              className="h-11 sm:h-8"
              disabled={busy}
              onClick={onEdit}
              aria-haspopup="dialog"
              aria-label={`Modifica il gruppo ${g.name}`}
            >
              <Pencil className="size-3.5" aria-hidden />
              Modifica
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-11 text-crit hover:bg-crit-soft hover:text-crit-text sm:h-8"
              disabled={busy}
              onClick={() => setConfirmDelete(true)}
              aria-label={`Elimina il gruppo ${g.name}`}
            >
              <Trash2 className="size-3.5" aria-hidden />
              Elimina
            </Button>
          </>
        ) : null}
        {scopeCount > 0 ? (
          <Badge variant="outline" className="gap-1.5 border-info/40 bg-info-soft font-normal text-info whitespace-nowrap">
            <Info className="size-3.5" aria-hidden />
            scope di <span className="num">{scopeCount}</span> finestr{scopeCount === 1 ? 'a' : 'e'}
          </Badge>
        ) : null}
      </div>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare il gruppo «{g.name}»?</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              {dynamic ? (
                <>
                  Il gruppo è DINAMICO: {fmtNumber(g.memberCount)} {g.memberCount === 1 ? 'dispositivo' : 'dispositivi'}{' '}
                  corrispondono ora alla regola (nessuna membership salvata da rimuovere).
                  L&apos;eliminazione rimuove la regola e il raggruppamento; gli apparati restano
                  nell&apos;inventario e il loro stato non cambia.
                </>
              ) : (
                <>
                  Il gruppo contiene {fmtNumber(g.memberCount)} {g.memberCount === 1 ? 'dispositivo' : 'dispositivi'}:
                  l&apos;eliminazione rimuove SOLO il raggruppamento, gli apparati restano nell&apos;inventario.
                </>
              )}
              {scopeCount > 0 ? (
                <>
                  {' '}Il gruppo è lo scope di {scopeCount} {scopeCount === 1 ? 'finestra' : 'finestre'} di
                  manutenzione: le finestre NON verranno eliminate, perderanno solo questo scope.
                </>
              ) : null}
              {' '}Azione registrata nell&apos;audit (DEVICE_GROUP_DELETE{dynamic ? ' con regola e conteggio calcolato' : ''}) e non reversibile.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={busy}
              onClick={(e) => {
                e.preventDefault()
                onDelete()
                setConfirmDelete(false)
              }}
            >
              <Trash2 className="size-3.5" aria-hidden />
              Elimina gruppo
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </li>
  )
}

/** Sintesi leggibile della regola DYNAMIC (chip per criterio, AND
 *  dichiarato): i valori di tipo/stato/connessione sono i dati GREZZI
 *  del DB, le sedi mostrano il NOME reale quando risolvibile. */
function RuleSummary({ rules, locationNameOf }: {
  rules: GroupRule | null
  locationNameOf: (id: string) => string | null
}) {
  if (!rules) {
    return (
      <p className="mt-2 rounded-md border border-warn/40 bg-warn-soft px-2.5 py-1.5 text-[11px] leading-relaxed text-warn" role="note">
        Regola illeggibile nel dato storico (ruleJson non valida): l&apos;elenco mostra 0 membri.
        Modifica la regola per ripristinare il gruppo dinamico.
      </p>
    )
  }
  const chips: Array<{ label: string; title: string }> = []
  if (rules.deviceTypes?.length) chips.push({ label: `tipi: ${rules.deviceTypes.join(', ')}`, title: `Tipo dispositivo IN (${rules.deviceTypes.join(', ')})` })
  if (rules.statuses?.length) chips.push({ label: `stati: ${rules.statuses.join(', ')}`, title: `Stato raggiungibilità IN (${rules.statuses.join(', ')})` })
  if (rules.connectionTypes?.length) chips.push({ label: `connessioni: ${rules.connectionTypes.join(', ')}`, title: `Connessione IN (${rules.connectionTypes.join(', ')})` })
  if (rules.locationIds?.length) {
    const names = rules.locationIds.map((id) => locationNameOf(id) ?? id.slice(0, 8))
    chips.push({ label: `sedi: ${names.join(', ')}`, title: `Sede IN (${names.join(', ')})` })
  }
  return (
    <div className="mt-2 grid gap-1">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-dim">Regola (AND fra i criteri)</p>
      <div className="flex flex-wrap gap-1.5">
        {chips.map((c) => (
          <Badge key={c.label} variant="outline" className="max-w-full gap-1.5 border-primary/40 bg-info-soft font-normal text-info" title={c.title}>
            <Sparkles className="size-3 shrink-0" aria-hidden />
            <span className="truncate">{c.label}</span>
          </Badge>
        ))}
      </div>
    </div>
  )
}

/* ---------------- Dialog nuovo/modifica gruppo (MANUAL + DYNAMIC) ----------------
 * MANUAL: selettore dispositivi MULTI via Popover+Command (ricerca
 * server-side reale, chip rimovibili) — membership = SOSTITUZIONE
 * INTEGRALE. DYNAMIC (16.4): costruttore di regola con valori REALI
 * dell'inventario (tipi/stati/connessioni distinti + sedi del plant),
 * anteprima del conteggio calcolata dallo stesso dato, note oneste
 * (membership non salvata, ricalcolata a ogni lettura). Mount
 * condizionato: prefill dai props, niente setState in effetti.
 * ruleType: scelto alla creazione, IMMUTABILE in modifica (422
 * RULE_TYPE_IMMUTABLE — dichiarato in UI). */

function DeviceGroupDialog({ mode, group, open, onOpenChange }: {
  mode: 'create' | 'edit'
  group?: DeviceGroupRow | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const queryClient = useQueryClient()

  const [name, setName] = useState(group?.name ?? '')
  const [description, setDescription] = useState(group?.description ?? '')
  /* input type=color richiede #rrggbb: un colore malformato nel DB
   * (caso difensivo) mostra il default del modello — SOLO visuale. */
  const [color, setColor] = useState(
    group && COLOR_HEX_RE.test(group.color) ? group.color : DEFAULT_GROUP_COLOR,
  )
  /* 16.4: tipo di appartenenza — scelto alla CREAZIONE, immutabile
   * dopo (contratto 422 RULE_TYPE_IMMUTABLE). */
  const [ruleType, setRuleType] = useState<'MANUAL' | 'DYNAMIC'>(
    group?.ruleType === 'DYNAMIC' ? 'DYNAMIC' : 'MANUAL',
  )
  const [picked, setPicked] = useState<PickedDevice[]>(
    group
      ? group.members.map((m) => ({ id: m.id, hostname: m.hostname, type: m.type, locationName: m.locationName }))
      : [],
  )
  /* Criteri della regola DYNAMIC (prefill dalla regola salvata). */
  const [ruleTypes, setRuleTypes] = useState<string[]>(group?.rules?.deviceTypes ?? [])
  const [ruleStatuses, setRuleStatuses] = useState<string[]>(group?.rules?.statuses ?? [])
  const [ruleConnections, setRuleConnections] = useState<string[]>(group?.rules?.connectionTypes ?? [])
  const [ruleLocationIds, setRuleLocationIds] = useState<string[]>(group?.rules?.locationIds ?? [])
  const [pickerOpen, setPickerOpen] = useState(false)
  const [pickerQuery, setPickerQuery] = useState('')
  const [locOpen, setLocOpen] = useState(false)
  const [locQuery, setLocQuery] = useState('')
  const [error, setError] = useState<string | null>(null)

  /* Ricerca dispositivi server-side (ricerca reale, nessun elenco finto). */
  const deviceSearch = useQuery({
    queryKey: ['group-device-search', pickerQuery],
    queryFn: () => api.devices({ q: pickerQuery || undefined, pageSize: 20 }),
    enabled: pickerOpen,
    staleTime: 10_000,
  })

  /* 16.4: inventario INTERO (pageSize 200 = tutti i dispositivi reali
   * dell'impianto) per i valori distinti del costruttore di regola e
   * per l'ANTEPRIMA del conteggio — calcolata client-side sullo
   * STESSO dato che il server valuta con la regola. Caricato SOLO in
   * modalità dinamica. */
  const inventory = useQuery({
    queryKey: ['group-rule-inventory'],
    queryFn: () => api.devices({ pageSize: 200 }),
    enabled: ruleType === 'DYNAMIC',
    staleTime: 60_000,
  })
  const invItems = inventory.data?.data.items ?? []
  const distinctTypes = Array.from(new Set(invItems.map((d) => d.type))).filter((v) => v !== '').sort((a, b) => a.localeCompare(b, 'it'))
  const distinctStatuses = Array.from(new Set(invItems.map((d) => d.dbStatus))).filter((v) => v !== '').sort((a, b) => a.localeCompare(b, 'it'))
  const distinctConnections = Array.from(new Set(invItems.map((d) => d.connectionType))).filter((v) => v !== '').sort((a, b) => a.localeCompare(b, 'it'))

  /* Sedi REALI del plant per il criterio sede. */
  const locations = useQuery({
    queryKey: ['locations'],
    queryFn: () => api.locations(),
    enabled: ruleType === 'DYNAMIC',
    staleTime: 60_000,
  })
  const locItems = locations.data?.data ?? []
  const locFiltered = locQuery.trim()
    ? locItems.filter((l) => `${l.name} ${l.identifier}`.toLowerCase().includes(locQuery.trim().toLowerCase()))
    : locItems

  /* Anteprima ONESTA: conteggio dei dispositivi dell'inventario che
   * soddisfano la regola ADESSO (stessa semantica AND/OR del server,
   * calcolata sul dato reale della API — non una stima). */
  const preview = (() => {
    if (ruleType !== 'DYNAMIC' || invItems.length === 0) return null
    return invItems.filter((d) =>
      (ruleTypes.length === 0 || ruleTypes.includes(d.type))
      && (ruleStatuses.length === 0 || ruleStatuses.includes(d.dbStatus))
      && (ruleConnections.length === 0 || ruleConnections.includes(d.connectionType))
      && (ruleLocationIds.length === 0 || (d.locationId != null && ruleLocationIds.includes(d.locationId))),
    ).length
  })()

  /* Sopra il cap dei 500 membri elencati dalla API la membership NON è
   * modificabile da qui: sostituire una lista incompleta perderebbe
   * membri reali. Onesto: selettore disattivato + spiegazione. (Nel
   * DB reale l'impianto ha 200 dispositivi: il cap è irraggiungibile.) */
  const capped = !!group && group.ruleType === 'MANUAL' && group.memberCount > group.members.length

  const create = useMutation({
    mutationFn: (input: Parameters<typeof api.createDeviceGroup>[0]) => api.createDeviceGroup(input),
    onSuccess: (r) => {
      toast.success('Gruppo creato', {
        description: r.ruleType === 'DYNAMIC'
          ? `«${r.name}» dinamico — ${fmtNumber(r.memberCount)} ${r.memberCount === 1 ? 'dispositivo corrisponde' : 'dispositivi corrispondono'} alla regola ORA (ricalcolati a ogni lettura). Scrittura reale nel DB (audit DEVICE_GROUP_CREATE).`
          : `«${r.name}» con ${fmtNumber(r.memberCount)} ${r.memberCount === 1 ? 'dispositivo' : 'dispositivi'} — scrittura reale nel DB (audit DEVICE_GROUP_CREATE).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['device-groups'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      setError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const update = useMutation({
    mutationFn: (v: { id: string; patch: Parameters<typeof api.updateDeviceGroup>[1] }) => api.updateDeviceGroup(v.id, v.patch),
    onSuccess: (r) => {
      toast.success('Gruppo aggiornato', {
        description: r.ruleType === 'DYNAMIC'
          ? `«${r.name}» — regola aggiornata: ${fmtNumber(r.memberCount)} ${r.memberCount === 1 ? 'dispositivo corrisponde' : 'dispositivi corrispondono'} ora (audit DEVICE_GROUP_UPDATE con diff della regola).`
          : `«${r.name}» — ${fmtNumber(r.memberCount)} ${r.memberCount === 1 ? 'dispositivo' : 'dispositivi'} (audit DEVICE_GROUP_UPDATE con diff).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['device-groups'] })
      /* i nomi dei gruppi compaiono negli scope delle finestre:
       * invalida anche ['maintenance'] per allineare le chip. */
      void queryClient.invalidateQueries({ queryKey: ['maintenance'] })
      onOpenChange(false)
    },
    onError: (e) => {
      const info = errInfo(e)
      setError(`${info.message}${info.code ? ` (codice ${info.code})` : ''}`)
    },
  })

  const pending = create.isPending || update.isPending

  const togglePicked = (d: DeviceRow) => {
    setPicked((prev) =>
      prev.some((p) => p.id === d.id)
        ? prev.filter((p) => p.id !== d.id)
        : [...prev, { id: d.id, hostname: d.hostname, type: d.type, locationName: d.locationName ?? null }],
    )
  }

  const toggleRuleValue = (setter: React.Dispatch<React.SetStateAction<string[]>>, v: string) => {
    setter((prev) => (prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v]))
  }

  /** Regola corrente del form (null = nessun criterio selezionato). */
  const buildRule = (): GroupRule | null => {
    const has = ruleTypes.length + ruleStatuses.length + ruleConnections.length + ruleLocationIds.length > 0
    if (!has) return null
    return {
      ...(ruleTypes.length > 0 ? { deviceTypes: [...ruleTypes].sort() } : {}),
      ...(ruleStatuses.length > 0 ? { statuses: [...ruleStatuses].sort() } : {}),
      ...(ruleConnections.length > 0 ? { connectionTypes: [...ruleConnections].sort() } : {}),
      ...(ruleLocationIds.length > 0 ? { locationIds: [...ruleLocationIds].sort() } : {}),
    }
  }

  const submit = () => {
    setError(null)
    if (name.trim().length < 2) { setError('Il nome deve avere almeno 2 caratteri'); return }

    if (mode === 'create') {
      if (ruleType === 'DYNAMIC') {
        const rules = buildRule()
        if (!rules) { setError('La regola richiede almeno un criterio: scegli tipi, stati, connessioni o sedi'); return }
        create.mutate({ name: name.trim(), description: description.trim(), color, ruleType: 'DYNAMIC', rules })
      } else {
        create.mutate({
          name: name.trim(),
          description: description.trim(),
          color,
          deviceIds: picked.length > 0 ? picked.map((p) => p.id) : undefined,
        })
      }
      return
    }

    /* --- Modifica: SOLO i campi cambiati (il server rifà il diff). --- */
    if (!group) return
    const patch: Parameters<typeof api.updateDeviceGroup>[1] = {}
    if (name.trim() !== group.name) patch.name = name.trim()
    if (description.trim() !== group.description) patch.description = description.trim()
    if (color !== group.color) patch.color = color
    if (group.ruleType === 'DYNAMIC') {
      const rules = buildRule()
      if (!rules) { setError('La regola richiede almeno un criterio: scegli tipi, stati, connessioni o sedi'); return }
      if (JSON.stringify(normRuleClient(rules)) !== JSON.stringify(normRuleClient(group.rules))) patch.rules = rules
    } else if (!capped) {
      const currentIds = group.members.map((m) => m.id)
      const pickedIds = picked.map((p) => p.id)
      const same = currentIds.length === pickedIds.length && currentIds.every((id) => pickedIds.includes(id))
      /* deviceIds presente = SOSTITUZIONE INTEGRALE della membership */
      if (!same) patch.deviceIds = pickedIds
    }
    if (Object.keys(patch).length === 0) { setError('Nessuna modifica da salvare: i valori sono identici a quelli attuali del gruppo.'); return }
    update.mutate({ id: group.id, patch })
  }

  const ruleCriteriaCount = ruleTypes.length + ruleStatuses.length + ruleConnections.length + ruleLocationIds.length

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v && !pending) onOpenChange(false) }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? 'Nuovo gruppo dispositivi' : `Modifica gruppo «${group?.name ?? ''}»`}</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            {mode === 'create'
              ? 'I gruppi sono entità gestite dall\'operatore: scrittura REALE nel DB (audit DEVICE_GROUP_CREATE). Scegli il tipo di appartenenza: membri espliciti (manuale) o una regola valutata sullo stato reale dei dispositivi (dinamico).'
              : group?.ruleType === 'DYNAMIC'
                ? 'Modifica REALE nel DB (audit DEVICE_GROUP_UPDATE con diff della regola). La membership resta calcolata a runtime: l\'elenco dei corrispondenti si aggiorna da solo a ogni lettura.'
                : 'Modifica REALE nel DB (audit DEVICE_GROUP_UPDATE con diff sintetico). Se tocchi i dispositivi, la selezione SOSTITUISCE integralmente i membri attuali (l\'audit registra aggiunti/rimossi).'}
          </DialogDescription>
        </DialogHeader>

        <form
          className="grid gap-3"
          onSubmit={(e) => { e.preventDefault(); submit() }}
          noValidate
        >
          <div className="grid gap-1.5">
            <label htmlFor="dg-name" className="text-xs font-medium text-text-2">Nome (2–80 caratteri) *</label>
            <Input
              id="dg-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="es. Telecamere scuole"
              maxLength={80}
              aria-required="true"
            />
            <p className="text-[11px] text-dim">Univoco per impianto: un duplicato viene rifiutato (422 GROUP_EXISTS).</p>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="dg-desc" className="text-xs font-medium text-text-2">Descrizione</label>
            <Textarea
              id="dg-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              maxLength={500}
              placeholder="Opzionale: a cosa serve il gruppo…"
            />
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="dg-color" className="text-xs font-medium text-text-2">Colore del gruppo</label>
            <div className="flex items-center gap-2">
              {/* input colore NATIVO: il colore è un DATO dell'operatore
               * salvato nel DB, NON un colore del tema → value diretto. */}
              <input
                id="dg-color"
                type="color"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                className="size-11 cursor-pointer rounded-md border border-control-border bg-background p-1"
                aria-label="Colore del gruppo (dato operatore, non dipende dal tema)"
              />
              <span className="num text-xs text-text-2" aria-hidden>{color}</span>
            </div>
            <p className="text-[11px] text-dim">Salvato nel DB così com&apos;è (hex #RRGGBB): è un dato dell&apos;operatore, non un colore del tema.</p>
          </div>

          {/* --- Tipo di appartenenza: in creazione si SCEGLIE, in
           *      modifica è IMMUTABILE (contratto 422) --- */}
          {mode === 'create' ? (
            <fieldset className="grid gap-1.5">
              <legend className="text-xs font-medium text-text-2">Tipo di appartenenza *</legend>
              <RadioGroup
                value={ruleType}
                onValueChange={(v) => setRuleType(v === 'DYNAMIC' ? 'DYNAMIC' : 'MANUAL')}
                className="grid gap-2"
                aria-label="Tipo di appartenenza del gruppo"
              >
                <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-raised p-3 transition-colors has-[button[data-state=checked]]:border-primary">
                  <RadioGroupItem value="MANUAL" className="mt-0.5" />
                  <span className="grid gap-0.5">
                    <span className="text-xs font-medium">Manuale</span>
                    <span className="text-[11px] leading-snug text-text-2">
                      Membri scelti uno a uno dall&apos;inventario reale. A ogni modifica la selezione
                      sostituisce integralmente i membri (audit con aggiunti/rimossi).
                    </span>
                  </span>
                </label>
                <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-raised p-3 transition-colors has-[button[data-state=checked]]:border-primary">
                  <RadioGroupItem value="DYNAMIC" className="mt-0.5" />
                  <span className="grid gap-0.5">
                    <span className="text-xs font-medium">Dinamico</span>
                    <span className="text-[11px] leading-snug text-text-2">
                      Regola (tipo, stato, connessione, sede) valutata a runtime sullo stato reale:
                      la membership non viene salvata, si ricalcola a ogni lettura.
                    </span>
                  </span>
                </label>
              </RadioGroup>
              <p className="text-[11px] text-dim">
                Non modificabile dopo la creazione (il server risponde 422 RULE_TYPE_IMMUTABLE):
                il tipo di membership non si converte.
              </p>
            </fieldset>
          ) : (
            <div className="flex items-center gap-2 rounded-lg border border-border/70 bg-raised/40 px-3 py-2">
              {group?.ruleType === 'DYNAMIC' ? <Sparkles className="size-3.5 shrink-0 text-text-2" aria-hidden /> : <Layers className="size-3.5 shrink-0 text-text-2" aria-hidden />}
              <p className="min-w-0 flex-1 text-xs text-text-2">
                Tipo: <strong>{group?.ruleType === 'DYNAMIC' ? 'dinamico — regola calcolata a runtime' : 'manuale — membri espliciti'}</strong> (immutabile).
              </p>
            </div>
          )}

          {ruleType === 'DYNAMIC' ? (
            /* --- Costruttore della regola DYNAMIC: valori REALI
             *    dell'inventario, AND fra criteri, OR fra i valori. --- */
            <div className="grid gap-3 rounded-lg border border-border/70 bg-raised/30 p-3">
              <p className="text-xs font-medium text-text-2" id="dg-rule-label">
                Regola — AND fra i criteri selezionati, OR fra i valori di ciascuno
              </p>

              {inventory.isPending ? (
                <div className="flex items-center gap-2 px-1 py-3 text-xs text-text-2" role="status">
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                  caricamento valori reali dell&apos;inventario…
                  <span className="sr-only">caricamento dei valori distinti di tipo, stato e connessione dall&apos;inventario reale</span>
                </div>
              ) : inventory.isError ? (
                <p className="px-1 py-2 text-xs text-crit" role="alert">
                  Inventario non disponibile: {errInfo(inventory.error).message}
                </p>
              ) : (
                <>
                  <RuleChips
                    label="Tipo dispositivo"
                    values={distinctTypes}
                    picked={ruleTypes}
                    onToggle={(v) => toggleRuleValue(setRuleTypes, v)}
                  />
                  <RuleChips
                    label="Stato (reale del DB)"
                    values={distinctStatuses}
                    picked={ruleStatuses}
                    onToggle={(v) => toggleRuleValue(setRuleStatuses, v)}
                  />
                  <RuleChips
                    label="Connessione"
                    values={distinctConnections}
                    picked={ruleConnections}
                    onToggle={(v) => toggleRuleValue(setRuleConnections, v)}
                  />

                  {/* Sede: multi-select Popover+Command (41 sedi reali) */}
                  <div className="grid gap-1.5">
                    <span className="text-xs font-medium text-text-2" id="dg-loc-label">
                      Sedi ({ruleLocationIds.length > 0 ? <span className="num">{ruleLocationIds.length}</span> : 'nessuna'} selezionat{ruleLocationIds.length === 1 ? 'a' : 'e'})
                    </span>
                    {ruleLocationIds.length > 0 ? (
                      <div className="flex max-h-24 flex-wrap gap-1.5 overflow-y-auto scroll-thin" role="list" aria-labelledby="dg-loc-label">
                        {ruleLocationIds.map((id) => {
                          const loc = locItems.find((l) => l.id === id)
                          return (
                            <Badge key={id} variant="outline" className="gap-1.5 border-link/40 bg-info-soft font-normal text-info" role="listitem">
                              <span className="max-w-[170px] truncate" title={loc ? `${loc.name} (${loc.identifier}) · ${loc.devices} dispositivi` : id}>
                                {loc ? loc.name : id.slice(0, 10)}
                              </span>
                              <button
                                type="button"
                                className="ml-1 rounded-sm hover:text-foreground"
                                aria-label={`Rimuovi la sede ${loc?.name ?? id} dalla regola`}
                                onClick={() => setRuleLocationIds((prev) => prev.filter((x) => x !== id))}
                              >
                                ×
                              </button>
                            </Badge>
                          )
                        })}
                      </div>
                    ) : null}
                    <Popover open={locOpen} onOpenChange={setLocOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="h-11 sm:h-9"
                          aria-expanded={locOpen}
                          aria-haspopup="listbox"
                          aria-label="Aggiungi sedi alla regola (sedi reali dell'impianto)"
                        >
                          <Search className="size-3.5" aria-hidden />
                          Aggiungi sedi
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[340px] p-0" align="start">
                        <Command shouldFilter={false}>
                          <CommandInput
                            placeholder="Cerca sede o identificatore…"
                            value={locQuery}
                            onValueChange={setLocQuery}
                          />
                          <CommandList>
                            {locations.isPending ? (
                              <div className="flex items-center justify-center gap-2 px-3 py-6 text-xs text-text-2">
                                <Loader2 className="size-4 animate-spin" aria-hidden />
                                caricamento sedi…
                              </div>
                            ) : locations.isError ? (
                              <div className="px-3 py-6 text-center text-xs text-crit">
                                Sedi non disponibili: {errInfo(locations.error).message}
                              </div>
                            ) : (
                              <>
                                <CommandEmpty>Nessuna sede trovata con questa ricerca.</CommandEmpty>
                                <CommandGroup heading="Sedi reali dell'impianto">
                                  {locFiltered.map((l) => {
                                    const selected = ruleLocationIds.includes(l.id)
                                    return (
                                      <CommandItem
                                        key={l.id}
                                        value={l.id}
                                        onSelect={() => toggleRuleValue(setRuleLocationIds, l.id)}
                                        aria-label={`${l.name}${selected ? ' (già selezionata: clic per rimuoverla)' : ''}`}
                                      >
                                        {selected
                                          ? <Check className="size-4 shrink-0 text-ok" aria-hidden />
                                          : <CircleDot className="size-4 shrink-0" aria-hidden />}
                                        <span className="min-w-0 flex-1 truncate">{l.name}</span>
                                        <span className="num shrink-0 text-xs text-text-2">{l.devices} dev</span>
                                      </CommandItem>
                                    )
                                  })}
                                </CommandGroup>
                              </>
                            )}
                          </CommandList>
                          <div className="border-t border-border/60 p-2">
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              className="h-9 w-full"
                              onClick={() => setLocOpen(false)}
                            >
                              Fatto (<span className="num">{ruleLocationIds.length}</span> selezionat{ruleLocationIds.length === 1 ? 'a' : 'e'})
                            </Button>
                          </div>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <p className="text-[11px] text-dim">
                      Nessun criterio sulla sede = qualsiasi sede (host senza sede compresi, se gli
                      altri criteri corrispondono).
                    </p>
                  </div>
                </>
              )}

              {/* Anteprima ONESTA: conteggio calcolato sull'inventario
               *    reale caricato (pagina intera, pageSize 200). */}
              {preview !== null ? (
                <p className="rounded-md border border-info/40 bg-info-soft px-2.5 py-1.5 text-xs text-info" role="status">
                  <strong className="num">{fmtNumber(preview)}</strong>{' '}
                  {preview === 1 ? 'dispositivo corrisponde' : 'dispositivi corrispondono'} alla regola ora
                  {ruleCriteriaCount === 0 ? ' (nessun criterio: servirebbe almeno un criterio — il server rifiuta una regola vuota)' : ''}.
                </p>
              ) : null}
              {ruleCriteriaCount === 0 ? (
                <p className="text-[11px] leading-relaxed text-warn" role="note">
                  La regola richiede almeno un criterio (il contratto rifiuta una regola vuota:
                  varrebbe «tutti i dispositivi», ingannevole).
                </p>
              ) : null}
              <p className="text-[11px] leading-relaxed text-dim">
                La membership NON viene salvata: il server ricalcola la regola a ogni lettura sullo
                stato reale (tipi, stati e connessioni validati contro i valori distinti presenti
                nell&apos;impianto; sedi contro quelle reali).
              </p>
            </div>
          ) : (
            /* --- MANUAL: selettore dispositivi multi (come 16.3) --- */
            <div className="grid gap-1.5">
              <span className="text-xs font-medium text-text-2" id="dg-members-label">
                Dispositivi ({picked.length > 0 ? <span className="num">{picked.length}</span> : 'nessuno'} selezionat{picked.length === 1 ? 'o' : 'i'})
              </span>
              {picked.length > 0 ? (
                <div
                  className="flex max-h-32 flex-wrap gap-1.5 overflow-y-auto scroll-thin"
                  role="list"
                  aria-labelledby="dg-members-label"
                  aria-label="Dispositivi selezionati come membri del gruppo"
                >
                  {picked.map((p) => (
                    <Badge key={p.id} variant="outline" className="gap-1.5 border-link/40 bg-info-soft font-normal text-info" role="listitem">
                      <Monitor className="size-3.5 shrink-0" aria-hidden />
                      <span
                        className="max-w-[170px] truncate"
                        title={`${p.hostname} · ${p.type}${p.locationName ? ` · ${p.locationName}` : ' · senza sede'}`}
                      >
                        {p.hostname}
                      </span>
                      <button
                        type="button"
                        className="ml-1 rounded-sm hover:text-foreground"
                        aria-label={`Rimuovi ${p.hostname} dalla selezione`}
                        onClick={() => setPicked((prev) => prev.filter((x) => x.id !== p.id))}
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              ) : null}
              {capped ? (
                <p className="text-[11px] leading-relaxed text-warn" role="note">
                  Il gruppo ha {fmtNumber(group?.memberCount ?? 0)} membri, sopra il cap di 500 elencati
                  dalla API: la modifica dei membri da qui è disattivata per non sostituire una lista
                  incompleta (i membri attuali restano invariati).
                </p>
              ) : (
                <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="h-11 sm:h-9"
                      aria-expanded={pickerOpen}
                      aria-haspopup="listbox"
                      aria-label="Aggiungi dispositivi al gruppo (ricerca nell'inventario reale)"
                    >
                      <Search className="size-3.5" aria-hidden />
                      Aggiungi dispositivi
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[340px] p-0" align="start">
                    <Command shouldFilter={false}>
                      <CommandInput
                        placeholder="Cerca hostname, IP, modello…"
                        value={pickerQuery}
                        onValueChange={setPickerQuery}
                      />
                      <CommandList>
                        {deviceSearch.isPending ? (
                          <div className="flex items-center justify-center gap-2 px-3 py-6 text-xs text-text-2">
                            <Loader2 className="size-4 animate-spin" aria-hidden />
                            ricerca dispositivi…
                          </div>
                        ) : deviceSearch.isError ? (
                          <div className="px-3 py-6 text-center text-xs text-crit">
                            Ricerca non riuscita: {errInfo(deviceSearch.error).message}
                          </div>
                        ) : (
                          <>
                            <CommandEmpty>Nessun dispositivo trovato con questa ricerca.</CommandEmpty>
                            <CommandGroup heading="Dispositivi reali dell'impianto">
                              {(deviceSearch.data?.data.items ?? []).map((d) => {
                                const selected = picked.some((p) => p.id === d.id)
                                return (
                                  <CommandItem
                                    key={d.id}
                                    value={d.id}
                                    onSelect={() => togglePicked(d)}
                                    aria-label={`${d.hostname}${selected ? ' (già selezionato: clic per rimuoverlo)' : ''}`}
                                  >
                                    {selected
                                      ? <Check className="size-4 shrink-0 text-ok" aria-hidden />
                                      : <Monitor className="size-4 shrink-0" aria-hidden />}
                                    <span className="min-w-0 flex-1 truncate">{d.hostname}</span>
                                    <span className="num shrink-0 text-xs text-text-2">{d.ip}</span>
                                  </CommandItem>
                                )
                              })}
                            </CommandGroup>
                          </>
                        )}
                      </CommandList>
                      <div className="border-t border-border/60 p-2">
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-9 w-full"
                          onClick={() => setPickerOpen(false)}
                        >
                          Fatto (<span className="num">{picked.length}</span> selezionati)
                        </Button>
                      </div>
                    </Command>
                  </PopoverContent>
                </Popover>
              )}
              <p className="text-[11px] text-dim">
                {mode === 'edit'
                  ? 'Al salvataggio la selezione SOSTITUISCE integralmente i membri attuali (audit con aggiunti/rimossi).'
                  : 'I dispositivi si scelgono dall\'inventario reale (ricerca server-side).'}
              </p>
            </div>
          )}

          {error ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs text-crit-text">{error}</p>
          ) : null}

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" className="h-11 sm:h-9" onClick={() => onOpenChange(false)} disabled={pending}>
              Annulla
            </Button>
            <Button type="submit" className="h-11 sm:h-9" disabled={pending}>
              {pending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Layers className="size-3.5" aria-hidden />}
              {mode === 'create' ? (create.isPending ? 'Creazione…' : 'Crea gruppo') : (update.isPending ? 'Salvataggio…' : 'Salva modifiche')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/** Chip a interruttore per i valori di un criterio della regola
 *  (pattern dei giorni WEEKLY del dialog manutenzioni). I valori sono
 *  REALI (distinti dall'inventario), mai un vocabolario hard-coded. */
function RuleChips({ label, values, picked, onToggle }: {
  label: string
  values: string[]
  picked: string[]
  onToggle: (v: string) => void
}) {
  return (
    <fieldset className="grid gap-1.5">
      <legend className="text-xs font-medium text-text-2">
        {label} ({picked.length > 0 ? <span className="num">{picked.length}</span> : 'nessuno'} selezionat{picked.length === 1 ? 'o' : 'i'})
      </legend>
      <div className="flex flex-wrap gap-1.5">
        {values.map((v) => {
          const checked = picked.includes(v)
          return (
            <button
              key={v}
              type="button"
              role="checkbox"
              aria-checked={checked}
              aria-label={`${label}: ${v}`}
              onClick={() => onToggle(v)}
              className={cn(
                'rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors',
                checked ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-raised text-text-2 hover:border-control-border',
              )}
            >
              {v}
            </button>
          )
        })}
      </div>
    </fieldset>
  )
}

/** Normalizzazione client della regola per il confronto (stessa
 *  semantica del server): rispecificare la regola IDENTICA in una
 *  patch non è una modifica. */
function normRuleClient(r: GroupRule | null): Record<string, string[]> | null {
  if (!r) return null
  const out: Record<string, string[]> = {}
  for (const key of ['deviceTypes', 'statuses', 'connectionTypes', 'locationIds'] as const) {
    const list = r[key]
    if (list && list.length > 0) out[key] = [...list].sort()
  }
  return out
}

/* ---------------- Helper ---------------- */

function Hist({ label, value, breakAll }: { label: string; value: React.ReactNode; breakAll?: boolean }) {
  return (
    <div className="flex gap-2 sm:block">
      <dt className="shrink-0 text-text-2">{label}</dt>
      <dd className={cn('num', breakAll && 'break-all')}>{value}</dd>
    </div>
  )
}
