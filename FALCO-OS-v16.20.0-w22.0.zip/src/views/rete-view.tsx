/* ================================================================
 * FALCO-OS v16 — Vista «Rete» (§6.2)
 * Tre viste correlate: Topologia (canvas dell'albero unico con
 * pannello dettaglio nodo/collegamento), Mappa (sedi geografiche
 * con lista e filtro stato) e MAC (inventario MAC: FDB × inventario,
 * 16.5.0 W4 anticipata — solo osservazioni FDB reali, serie
 * congelata dichiarata). Realtime: invalidazione ogni 2 tick
 * (topologia/mappa); l'inventario MAC è serie congelata → nessuna
 * invalidazione realtime (nessuna novità attesa, dichiarato).
 * ================================================================ */

'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient, keepPreviousData } from '@tanstack/react-query'
import { ArrowUpRight, Check, ChevronLeft, ChevronRight, Download, FileSpreadsheet, Loader2, MousePointerClick, Network, Pin, Radio, Trash2, Video, X } from 'lucide-react'
import { toast } from 'sonner'
import { api } from '@/lib/client/api'
import type { MacInventoryRow } from '@/lib/v2/contracts'
import { useApp } from '@/lib/client/store'
import { fmtDbm, fmtDateTimeFull, fmtMbps, fmtNumber, fmtRelative, typeLabel } from '@/lib/client/format'
import { subscribeRealtime } from '@/lib/client/socket'
import { usePalette } from '@/lib/client/theme-palette'
import { PageHeader } from '@/components/page-header'
import { StatusBadge } from '@/components/status-badge'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { MapView, type MapLinkLine } from '@/components/map-view'
import TopologyView, { edgeVisual, edgeSourceFamily, isDownStatus, topoSourceMembers, type TopoNode, type TopoEdge } from '@/components/topology-view'
import { ConfidenceBadge, SourceBadge, TopologyLinksManager } from '@/components/topology-links-manager'
import { SpeedTestPanel } from '@/components/speed-test-panel'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableCaption, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { cn } from '@/lib/utils'

type LocationRow = Awaited<ReturnType<typeof api.locations>>['data'][number]
type LocFilter = 'all' | 'problems' | 'online'

/* ---------------- Pannello: dettaglio NODO (mini-quicklook) ---------------- */

function TypeIcon({ type }: { type: string }) {
  const t = type.toUpperCase()
  const cls = 'flex size-9 shrink-0 items-center justify-center rounded-lg border border-border bg-raised/60 text-text-2'
  if (t === 'CAMERA' || t === 'LPR' || t === 'NVR') return <span className={cls}><Video className="size-4" aria-hidden /></span>
  if (t === 'AP' || t === 'STA') return <span className={cls}><Radio className="size-4" aria-hidden /></span>
  return <span className={cls}><Network className="size-4" aria-hidden /></span>
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border/60 bg-raised/40 px-2.5 py-2">
      <p className="text-[10px] uppercase tracking-wide text-text-2">{label}</p>
      <p className="num mt-0.5 text-sm font-medium">{value}</p>
    </div>
  )
}

function NodeDetail({
  node, plantId, isCurrentRoot,
}: {
  node: TopoNode
  plantId: string | null
  isCurrentRoot: boolean
}) {
  const openDevice = useApp((s) => s.openDevice)
  const queryClient = useQueryClient()
  const [rootDialogOpen, setRootDialogOpen] = useState(false)
  const isRadio = node.type === 'AP' || node.type === 'STA'

  /* 16.10 W8: la radice scelta dall'operatore batte ogni euristica
   * (Plant.topologyRootDeviceId, v11.27). Mutazione reale + audit. */
  const setRoot = useMutation({
    mutationFn: () => api.updatePlant(plantId ?? '', { topologyRootDeviceId: node.id }),
    onSuccess: (plant) => {
      toast.success('Radice impostata', {
        description: `L’albero ora parte da «${node.hostname}» (impianto «${plant.name}», audit PLANT_UPDATE): la scelta dell’operatore batte ogni euristica.`,
      })
      setRootDialogOpen(false)
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
    },
    onError: (err) => {
      toast.error('Cambio radice non riuscito', {
        description: err instanceof Error ? err.message : 'Errore sconosciuto',
      })
    },
  })

  return (
    <div className="space-y-4">
      <section aria-label="Identità del nodo">
        <div className="flex items-center gap-2.5">
          <TypeIcon type={node.type} />
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{node.hostname}</p>
            <p className="truncate text-xs text-text-2">
              {typeLabel(node.type)}{node.model ? ` · ${node.model}` : ''}
            </p>
          </div>
        </div>
        <dl className="mt-3 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5 text-xs">
          <dt className="text-text-2">IP</dt>
          <dd className="num truncate">{node.ip || 'n.d.'}</dd>
          <dt className="text-text-2">Sede</dt>
          <dd className="truncate">{node.locationName || 'n.d.'}</dd>
          <dt className="text-text-2">Livello</dt>
          <dd className="num">T{node.tier} nell’albero</dd>
        </dl>
      </section>

      <section aria-label="Stato del nodo">
        <StatusBadge status={node.uiStatus} />
        <div className="mt-2 grid grid-cols-2 gap-2">
          {isRadio ? (
            <Metric label="Segnale" value={node.signalDbm != null ? fmtDbm(node.signalDbm) : 'n.d.'} />
          ) : null}
          <Metric label="A valle" value={`${node.downstreamCount} dispositivi`} />
        </div>
      </section>

      <div className="space-y-2 border-t border-border pt-3">
        <Button
          size="sm" variant="outline" className="h-9 w-full"
          onClick={() => openDevice(node.id)}
        >
          <ArrowUpRight className="mr-1 size-3.5" aria-hidden /> Apri quick-look
        </Button>
        {isCurrentRoot ? (
          <p
            className="flex items-center justify-center gap-1.5 text-xs text-text-2"
            title="Plant.topologyRootDeviceId: questo nodo è la radice scelta dall'operatore"
          >
            <Pin className="size-3.5" aria-hidden /> radice attuale
          </p>
        ) : (
          <>
            <Button
              size="sm" variant="outline" className="h-9 w-full"
              onClick={() => setRootDialogOpen(true)}
              disabled={!plantId || setRoot.isPending}
              title={plantId ? 'Scegli questo nodo come radice dell’albero (Plant.topologyRootDeviceId)' : 'Impianto non ancora caricato…'}
            >
              {setRoot.isPending
                ? <Loader2 className="mr-1 size-3.5 animate-spin" aria-hidden />
                : <Pin className="mr-1 size-3.5" aria-hidden />}
              Imposta come radice
            </Button>
            <AlertDialog open={rootDialogOpen} onOpenChange={(o) => { if (!setRoot.isPending) setRootDialogOpen(o) }}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Imposta come radice</AlertDialogTitle>
                  <AlertDialogDescription>
                    La radice scelta batte ogni euristica: l’albero partirà da {node.hostname}.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={setRoot.isPending}>Annulla</AlertDialogCancel>
                  <AlertDialogAction
                    disabled={setRoot.isPending || !plantId}
                    onClick={(e) => {
                      e.preventDefault() /* resta aperto finché la risposta reale non arriva */
                      setRoot.mutate()
                    }}
                  >
                    {setRoot.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Pin className="size-4" aria-hidden />}
                    Imposta come radice
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </>
        )}
      </div>
    </div>
  )
}

/* ---------------- Pannello: dettaglio EDGE (collegamento) ---------------- */

function EndpointRow({
  label, node, onOpen,
}: {
  label: string
  node: TopoNode | undefined
  onOpen: (id: string) => void
}) {
  return (
    <li className="flex items-center gap-2 rounded-md bg-raised/50 px-2 py-1.5 text-xs">
      <span className="w-6 shrink-0 text-[10px] font-semibold uppercase tracking-wider text-text-2">{label}</span>
      {node ? (
        <>
          <StatusBadge status={node.uiStatus} size="xs" className="shrink-0" />
          <button
            className="truncate text-left hover:text-link hover:underline"
            onClick={() => onOpen(node.id)}
            title={`${node.hostname} · ${node.ip || 'n.d.'}`}
          >
            {node.hostname}
          </button>
        </>
      ) : (
        <span className="text-text-2">n.d.</span>
      )}
    </li>
  )
}

function EdgeDetail({
  edge, nodesById, asOf,
}: {
  edge: TopoEdge
  nodesById: Map<string, TopoNode>
  asOf: number | undefined
}) {
  const openDevice = useApp((s) => s.openDevice)
  const queryClient = useQueryClient()
  const p = usePalette()
  const [deleteOpen, setDeleteOpen] = useState(false)
  const source = nodesById.get(edge.source)
  const target = nodesById.get(edge.target)
  const targetDown = isDownStatus(target?.uiStatus)
  const v = edgeVisual(edge, targetDown, p)
  const sourceName = source?.hostname ?? edge.source
  const targetName = target?.hostname ?? edge.target

  /* 16.10 W8: conferma (cristallizzazione) ed eliminazione reali del
   * collegamento — permessi e audit li fa rispettare il server. */
  const confirmLink = useMutation({
    mutationFn: () => api.updateTopologyLink(edge.id, { confirmed: true }),
    onSuccess: () => {
      toast.success('Collegamento confermato: ora è verità dell’operatore', {
        description: `«${sourceName} → ${targetName}» — fonte TECHNICIAN, confidenza HIGH (audit TOPOLOGY_LINK_UPDATE).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
    },
    onError: (err) => {
      toast.error('Conferma non riuscita', {
        description: err instanceof Error ? err.message : 'Errore sconosciuto',
      })
    },
  })

  const removeLink = useMutation({
    mutationFn: () => api.deleteTopologyLink(edge.id),
    onSuccess: () => {
      toast.success('Collegamento eliminato', {
        description: `«${sourceName} → ${targetName}» rimosso dall’inventario reale (audit TOPOLOGY_LINK_DELETE).`,
      })
      setDeleteOpen(false)
      void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
      void queryClient.invalidateQueries({ queryKey: ['topology-links'] })
    },
    onError: (err) => {
      toast.error('Eliminazione non riuscita', {
        description: err instanceof Error ? err.message : 'Errore sconosciuto',
      })
    },
  })

  return (
    <div className="space-y-4">
      <section aria-label="Tipo di collegamento">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={cn('inline-block w-6 shrink-0', v.dash ? 'border-t-2 border-dashed' : 'border-t-2')}
            style={{ borderColor: v.color, borderWidth: edge.manual ? 3 : undefined }}
            aria-hidden
          />
          <p className="text-sm font-semibold">{edge.linkType || 'Collegamento'}</p>
          <ConfidenceBadge confidence={edge.confidence} />
          <SourceBadge source={edgeSourceFamily(edge) || 'n.d.'} />
          {edge.manual ? (
            <Badge variant="outline" className="border-ok/40 bg-ok-soft text-ok">confermato</Badge>
          ) : (
            <Badge variant="outline" className="border-border bg-raised text-text-2">bozza</Badge>
          )}
        </div>
        {edge.label ? <p className="mt-0.5 truncate text-xs text-text-2" title={edge.label}>{edge.label}</p> : null}
      </section>

      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5 text-xs">
        <dt className="text-text-2">Stato</dt>
        <dd>{edge.linkStatus || 'n.d.'}</dd>
        <dt className="text-text-2">Confidenza</dt>
        <dd>{edge.confidence || 'n.d.'}</dd>
        <dt className="text-text-2">Evidenza</dt>
        <dd>{edge.evidence || 'n.d.'}</dd>
        <dt className="text-text-2">Velocità</dt>
        <dd className="num">{edge.speedMbps > 0 ? fmtMbps(edge.speedMbps) : 'n.d.'}</dd>
        <dt className="text-text-2">Traffico in</dt>
        <dd className="num">{edge.trafficInMbps > 0 ? fmtMbps(edge.trafficInMbps) : 'n.d.'}</dd>
        <dt className="text-text-2">Traffico out</dt>
        <dd className="num">{edge.trafficOutMbps > 0 ? fmtMbps(edge.trafficOutMbps) : 'n.d.'}</dd>
      </dl>
      <AsOf ts={asOf} prefix="riferimento dati" />

      <section aria-label="Estremi del collegamento">
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-text-2">Estremi</p>
        <ul className="space-y-1">
          <EndpointRow label="Da" node={source} onOpen={openDevice} />
          <EndpointRow label="A" node={target} onOpen={openDevice} />
        </ul>
      </section>

      <section aria-label="Azioni sul collegamento" className="space-y-2 border-t border-border pt-3">
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm" variant="outline" className="h-9"
            onClick={() => confirmLink.mutate()}
            disabled={confirmLink.isPending || removeLink.isPending || edge.manual}
            title={edge.manual ? 'Già confermato: è verità dell’operatore' : 'Cristallizza: confirmed=true, fonte TECHNICIAN, confidenza HIGH'}
          >
            {confirmLink.isPending
              ? <Loader2 className="mr-1 size-3.5 animate-spin" aria-hidden />
              : <Check className="mr-1 size-3.5" aria-hidden />}
            Conferma collegamento
          </Button>
          <Button
            size="sm" variant="outline" className="h-9 border-crit/40 text-crit hover:bg-crit-soft hover:text-crit"
            onClick={() => setDeleteOpen(true)}
            disabled={confirmLink.isPending || removeLink.isPending}
            title="Elimina il collegamento sbagliato dall’inventario (audit)"
          >
            {removeLink.isPending
              ? <Loader2 className="mr-1 size-3.5 animate-spin" aria-hidden />
              : <Trash2 className="mr-1 size-3.5" aria-hidden />}
            Elimina collegamento
          </Button>
        </div>
        <p className="text-[11px] text-dim">
          Le azioni richiedono ruolo TECNICO o superiore (il server le fa rispettare) e sono tracciate nell’audit.
          La conferma entra sempre nell’albero, quale che sia il filtro delle fonti.
        </p>
      </section>

      <AlertDialog open={deleteOpen} onOpenChange={(o) => { if (!removeLink.isPending) setDeleteOpen(o) }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Elimina collegamento</AlertDialogTitle>
            <AlertDialogDescription>
              Il collegamento {sourceName} → {targetName} verrà eliminato dall’inventario.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={removeLink.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={removeLink.isPending}
              onClick={(e) => {
                e.preventDefault() /* resta aperto finché la risposta reale non arriva */
                removeLink.mutate()
              }}
            >
              {removeLink.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

/* ---------------- Tab Mappa: riga sede ---------------- */

function LocationRowButton({
  loc, selected, onSelect,
}: {
  loc: LocationRow
  selected: boolean
  onSelect: (id: string) => void
}) {
  const counts =
    loc.devices > 0
      ? `${loc.devices} dispositivi · ${loc.online} online · ${loc.degraded} degr. · ${loc.offline} off · ${loc.unknown} scon. · ${loc.notMonitored} n.m.`
      : 'nessun dispositivo associato'
  return (
    <button
      type="button"
      onClick={() => { onSelect(loc.id) }}
      aria-pressed={selected}
      className={cn(
        'flex w-full items-center gap-2.5 rounded-lg border px-3 py-2.5 text-left transition-colors',
        selected ? 'border-link bg-info-soft' : 'border-border bg-surface hover:bg-raised',
      )}
      title={`${loc.name} (${loc.identifier}) — ${counts}`}
    >
      {loc.worstStatus ? (
        <StatusBadge status={loc.worstStatus} size="xs" className="shrink-0" />
      ) : (
        <Badge variant="outline" className="shrink-0 border-border bg-raised text-text-2">vuota</Badge>
      )}
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[13px] font-medium">{loc.name}</span>
        <span className="num block truncate text-[11px] text-text-2">{counts}</span>
      </span>
    </button>
  )
}

/* ---------------- Tab MAC: inventario (FDB × inventario, 16.5.0) ---------------- */

const MAC_PAGE_SIZE = 25

function csvEscape(v: string): string {
  return `"${v.replace(/"/g, '""')}"`
}

/** Export CSV della pagina corrente (stesso stile degli export del
 *  progetto: BOM UTF-8, separatore «;», prima riga di provenienza). */
function downloadMacCsv(rows: MacInventoryRow[], meta: { page: number; pageCount: number; scope: string; switchName: string | null; q: string }) {
  const stamp = new Date().toISOString()
  const provenance = `# FALCO-OS generato il ${stamp} — dati reali del DB (FdbObservation × inventario) — PAGINA ${meta.page} di ${meta.pageCount} (export della pagina corrente; scope=${meta.scope}; apparato=${meta.switchName ?? 'tutti'}; ricerca=${meta.q || '—'})`
  const header = ['MAC', 'Apparato (FDB)', 'Porta', 'Ultima osservazione', 'Inventario', 'Dispositivo', 'IP (ARP)']
  const body = rows.map((r) => [
    r.macDisplay,
    r.switchHostname,
    r.portName,
    fmtDateTimeFull(r.lastSeenAt),
    r.resolved ? 'In inventario' : 'Non in inventario',
    r.hostname ?? '',
    r.arpIp ?? '',
  ])
  const lines = [provenance, header.map(csvEscape).join(';'), ...body.map((r) => r.map(csvEscape).join(';'))]
  const blob = new Blob([`\ufeff${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `inventario-mac-pagina-${meta.page}.csv`
  document.body.appendChild(a)
  a.click()
  a.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 5_000)
}

function MacInventoryTab() {
  const openDevice = useApp((s) => s.openDevice)
  const navigate = useApp((s) => s.navigate)

  const [qInput, setQInput] = useState('')
  const [q, setQ] = useState('')
  const [switchId, setSwitchId] = useState('all')
  const [scope, setScope] = useState<'all' | 'resolved' | 'unresolved'>('all')
  const [sort, setSort] = useState<'lastSeen' | 'mac' | 'hostname'>('lastSeen')
  const [page, setPage] = useState(1)

  /* Ricerca con debounce (300 ms): reset pagina a ogni cambio filtro */
  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim())
      setPage(1)
    }, 300)
    return () => clearTimeout(t)
  }, [qInput])

  const macs = useQuery({
    queryKey: ['mac-inventory', q, switchId, scope, sort, page],
    queryFn: () => api.macInventory({
      q: q || undefined,
      switchId: switchId === 'all' ? undefined : switchId,
      scope,
      sort,
      page,
      pageSize: MAC_PAGE_SIZE,
    }),
    placeholderData: keepPreviousData,
    staleTime: 60_000,
  })

  const data = macs.data?.data
  const items = data?.items ?? []
  const total = data?.total ?? 0
  const shownPage = data?.page ?? 1
  const pageCount = data?.pageCount ?? 1
  const summary = data?.summary
  /* Serie congelata: ultima osservazione reale più vecchia di 24 h → nota onesta */
  const frozen = summary?.lastSeenMax != null && Date.now() - summary.lastSeenMax > 24 * 3_600_000

  const openResolved = (deviceId: string) => {
    openDevice(deviceId)
    navigate('dispositivi')
  }

  return (
    <div className="space-y-3">
      {/* Summary GLOBALE (prima dei filtri) + nota di copertura */}
      <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 text-xs text-text-2">
        <span>
          Osservazioni MAC reali (FDB × inventario):{' '}
          <strong className="num text-foreground">{summary ? fmtNumber(summary.resolvedCount + summary.unresolvedCount) : '…'}</strong>
        </span>
        <span>
          In inventario: <strong className="num text-foreground">{summary ? fmtNumber(summary.resolvedCount) : '…'}</strong>
          {' · '}non in inventario: <strong className="num text-foreground">{summary ? fmtNumber(summary.unresolvedCount) : '…'}</strong>
        </span>
        <span className="flex items-center gap-1.5">
          <span className="text-dim">·</span>
          <span>osservazioni fino al {summary?.lastSeenMax ? <span className="num">{fmtDateTimeFull(summary.lastSeenMax)}</span> : 'n.d.'} (serie congelata)</span>
        </span>
        {macs.data ? <AsOf ts={macs.data.asOf} prefix="· dati alle" className="ml-0.5" /> : null}
      </div>
      {frozen ? (
        <p className="rounded-md border border-warn/40 bg-warn-soft px-2.5 py-1.5 text-xs text-warn" role="note">
          La serie FDB termina al {summary?.lastSeenMax ? <span className="num">{fmtDateTimeFull(summary.lastSeenMax)}</span> : 'n.d.'}:
          il prelievo reale è finito lì. Nessun MAC «fresco» viene inventato oltre quella data.
        </p>
      ) : null}

      {/* Filtri (server-side) */}
      <div className="flex flex-wrap items-center gap-2">
        <Input
          value={qInput}
          onChange={(e) => setQInput(e.target.value)}
          placeholder="Cerca MAC o hostname…"
          aria-label="Cerca per MAC o hostname risolto"
          className="h-9 w-full sm:w-56"
        />
        <Select
          value={switchId}
          onValueChange={(v) => { setSwitchId(v); setPage(1) }}
        >
          <SelectTrigger className="w-full sm:w-[220px]" aria-label="Filtra per apparato che ha visto il MAC">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="max-h-72">
            <SelectItem value="all">Tutti gli apparati (FDB)</SelectItem>
            {(data?.switches ?? []).map((s) => (
              <SelectItem key={s.id} value={s.id}>{s.hostname}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={scope}
          onValueChange={(v) => { setScope(v as 'all' | 'resolved' | 'unresolved'); setPage(1) }}
        >
          <SelectTrigger className="w-full sm:w-[170px]" aria-label="Filtra per risoluzione nell'inventario">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti i MAC</SelectItem>
            <SelectItem value="resolved">In inventario</SelectItem>
            <SelectItem value="unresolved">Non in inventario</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={sort}
          onValueChange={(v) => { setSort(v as 'lastSeen' | 'mac' | 'hostname'); setPage(1) }}
        >
          <SelectTrigger className="w-full sm:w-[190px]" aria-label="Ordinamento">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="lastSeen">Ordina: ultima osservazione</SelectItem>
            <SelectItem value="mac">Ordina: MAC</SelectItem>
            <SelectItem value="hostname">Ordina: hostname</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Tabella */}
      {macs.isLoading ? (
        <div role="status" aria-busy="true" className="space-y-2">
          <span className="sr-only">Caricamento inventario MAC</span>
          <Skeleton className="h-8 w-full rounded-md" />
          <Skeleton className="h-64 w-full rounded-lg" />
        </div>
      ) : macs.isError ? (
        <ErrorPanel
          message={(macs.error as Error).message}
          onRetry={() => { void macs.refetch() }}
        />
      ) : items.length === 0 ? (
        <EmptyState
          title="Nessuna osservazione MAC corrisponde ai filtri"
          description="Cambia ricerca, apparato o scope: l'elenco contiene SOLE osservazioni FDB reali del DB (nessun MAC inventato)."
        />
      ) : (
        <div
          className="max-h-96 overflow-y-auto scroll-thin [&_[data-slot=table-container]]:overflow-x-visible"
          role="region"
          aria-label="Tabella inventario MAC"
          tabIndex={0}
        >
          <Table>
            <TableCaption>
              Osservazioni FDB reali × inventario · {MAC_PAGE_SIZE} righe per pagina · serie congelata (nessun MAC inventato)
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead scope="col" className="min-w-[150px]">MAC</TableHead>
                <TableHead scope="col" className="min-w-[130px]">Apparato (FDB)</TableHead>
                <TableHead scope="col" className="min-w-[100px]">Porta</TableHead>
                <TableHead scope="col" className="min-w-[130px]">Ultima osservazione</TableHead>
                <TableHead scope="col" className="min-w-[130px]">Inventario</TableHead>
                <TableHead scope="col" className="min-w-[140px]">Dispositivo</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((r, i) => (
                <TableRow key={`${r.switchId}-${r.portName}-${r.mac}-${r.lastSeenAt}-${i}`}>
                  <TableCell className="num font-medium" title={r.mac}>{r.macDisplay}</TableCell>
                  <TableCell className="text-text-2" title={`Apparato che ha appreso il MAC: ${r.switchHostname}`}>{r.switchHostname}</TableCell>
                  <TableCell className="num text-text-2">{r.portName}</TableCell>
                  <TableCell className="num text-text-2" title={fmtDateTimeFull(r.lastSeenAt)}>{fmtRelative(r.lastSeenAt)}</TableCell>
                  <TableCell>
                    {r.resolved ? (
                      <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40">In inventario</Badge>
                    ) : (
                      <Badge variant="outline" className="bg-warn-soft text-warn border-warn/40">Non in inventario</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {r.resolved && r.hostname && r.deviceId ? (
                      <button
                        type="button"
                        className="text-left font-medium hover:text-link hover:underline"
                        onClick={() => openResolved(r.deviceId!)}
                        title={`Apri la scheda di ${r.hostname}${r.deviceType ? ` (${typeLabel(r.deviceType)})` : ''}`}
                      >
                        {r.hostname}
                      </button>
                    ) : r.resolved && r.hostname ? (
                      <span>{r.hostname}</span>
                    ) : (
                      <span className="flex flex-wrap items-center gap-1.5">
                        <span className="text-text-2" title="MAC non presente nell'inventario (Device.macAddress/extraMacs)">—</span>
                        {r.arpIp ? (
                          <Badge
                            variant="outline"
                            className="bg-info-soft text-info border-info/40"
                            title={`IP risolto dalla tabella ARP: il MAC è vivo e risponde a ${r.arpIp} (l'adozione resta una scelta umana)`}
                          >
                            IP <span className="num">{r.arpIp}</span>
                          </Badge>
                        ) : null}
                      </span>
                    )}
                    {r.deviceType ? <span className="ml-1.5 text-[11px] text-text-2">{typeLabel(r.deviceType)}</span> : null}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Paginazione reale + export della pagina corrente */}
      {!macs.isError && total > 0 ? (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-text-2">
            Pagina <span className="num">{shownPage}</span> di <span className="num">{pageCount}</span> ·{' '}
            <span className="num">{fmtNumber(total)}</span> osservazioni con i filtri attuali
            {' · '}export limitato alla pagina corrente
          </p>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={shownPage <= 1 || macs.isFetching}
              onClick={() => setPage(shownPage - 1)}
            >
              <ChevronLeft className="size-3.5" aria-hidden />
              Precedente
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={shownPage >= pageCount || macs.isFetching}
              onClick={() => setPage(shownPage + 1)}
            >
              Successiva
              <ChevronRight className="size-3.5" aria-hidden />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={items.length === 0}
              onClick={() => {
                if (!data) return
                downloadMacCsv(data.items, {
                  page: data.page,
                  pageCount: data.pageCount,
                  scope,
                  switchName: switchId === 'all' ? null : (data.switches.find((s) => s.id === switchId)?.hostname ?? switchId),
                  q,
                })
                toast.success(`CSV esportato: ${fmtNumber(data.items.length)} osservazioni (pagina ${data.page} di ${data.pageCount}, dati reali del DB)`)
              }}
            >
              <Download className="size-3.5" aria-hidden />
              Esporta CSV (pagina)
            </Button>
          </div>
        </div>
      ) : null}
      <p className="text-[11px] text-dim">
        Ogni riga è una osservazione FDB reale (apparato · porta · MAC · ultima volta visto). La risoluzione
        confronta il MAC con Device.macAddress e extraMacs dell'inventario: nessun produttore (OUI) è incluso.
        L&apos;eventuale IP arriva dalla tabella ARP del plant (join per MAC, v16.15): è l&apos;indizio che quel MAC è
        vivo — l&apos;adozione resta una scelta umana.
      </p>
    </div>
  )
}

/* ---------------- Pannello sede stile UISP (v16.17 W18) ----------------
 * Richiesta operatore: «quando clicco un punto sulla mappa devono
 * apparire tutti i dispositivi che appartengono al punto, come fa
 * UISP di Ubiquiti». Elenco COMPLETO della sede (filtro locationId
 * additivo su /api/v2/devices), ogni riga apre la scheda apparato. */

function LocationDevicesPanel({
  loc,
  onClose,
}: {
  loc: LocationRow
  onClose: () => void
}) {
  const openDevice = useApp((s) => s.openDevice)
  const set = useApp((s) => s.set)
  const navigate = useApp((s) => s.navigate)

  const devices = useQuery({
    queryKey: ['location-devices', loc.id],
    queryFn: () => api.devices({ locationId: loc.id, pageSize: 200, sort: 'status', dir: 'desc' }),
    staleTime: 60_000,
  })

  const items = devices.data?.data.items ?? []

  return (
    <section
      aria-label={`Dispositivi della sede ${loc.name}`}
      className="min-w-0 rounded-lg border border-border bg-surface"
    >
      {/* Intestazione: nome del PUNTO + stato + chiusura */}
      <header className="flex items-start gap-2 border-b border-border/70 px-3 py-2.5">
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold" title={loc.name}>{loc.name}</p>
          <p className="mt-0.5 text-[11px] text-text-2 num">
            {loc.devices} dispositivi · {loc.online} online
            {loc.offline > 0 ? ` · ${loc.offline} offline` : ''}
            {loc.degraded > 0 ? ` · ${loc.degraded} degradati` : ''}
            {loc.cameraCount > 0 ? ` · ${loc.cameraCount} video` : ''}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <StatusBadge status={loc.worstStatus ?? 'NOT_MONITORED'} size="xs" />
          <Button
            variant="ghost" size="sm" className="size-7 p-0" onClick={onClose}
            aria-label="Chiudi dettaglio sede"
          >
            <X className="size-3.5" aria-hidden />
          </Button>
        </div>
      </header>

      {/* Elenco dispositivi del punto (tutti, scroll interno) */}
      <div className="scroll-thin max-h-[min(52vh,420px)] overflow-y-auto" role="list" aria-label="Dispositivi della sede">
        {devices.isLoading ? (
          <div className="space-y-1.5 p-3" aria-busy="true">
            {[...Array(5)].map((_, i) => <div key={i} className="h-11 animate-pulse rounded-md bg-raised/50" />)}
          </div>
        ) : devices.isError ? (
          <div className="p-3">
            <ErrorPanel message={(devices.error as Error).message} onRetry={() => { void devices.refetch() }} />
          </div>
        ) : items.length === 0 ? (
          <EmptyState
            title="Nessun dispositivo in questa sede"
            description="La sede esiste ma nessun apparato le è assegnato (guarda Dispositivi senza sede)."
            className="py-8"
          />
        ) : (
          <ul className="divide-y divide-border/60">
            {items.map((d) => (
              <li key={d.id} role="listitem">
                <button
                  type="button"
                  className="flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors hover:bg-raised/30"
                  onClick={() => openDevice(d.id)}
                  title={`Apri la scheda di ${d.hostname}`}
                >
                  <StatusBadge status={d.uiStatus} size="xs" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-medium">{d.hostname}</p>
                    <p className="truncate text-xs text-text-2">
                      {typeLabel(d.type)} · <span className="num">{d.ip}</span>
                      {d.signalPresent ? ` · ${fmtDbm(d.signalStrength)}` : ''}
                    </p>
                  </div>
                  <span className="shrink-0 text-[10px] text-text-2 num">{fmtRelative(d.lastSeenAt)}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <footer className="flex items-center justify-between gap-2 border-t border-border/70 px-3 py-2">
        <p className="text-[10px] leading-relaxed text-text-2">
          {devices.data ? <span className="num">{items.length}/{devices.data.data.total}</span> : '…'} apparati · ordinati dal peggiore
        </p>
        <Button
          variant="ghost" size="sm" className="h-7 px-2 text-xs text-link hover:text-link"
          onClick={() => { set({ q: null }); navigate('dispositivi') }}
          title="Vai all'inventario completo"
        >
          Inventario <ArrowUpRight className="size-3" aria-hidden />
        </Button>
      </footer>
    </section>
  )
}

/* ---------------- Vista principale ---------------- */

export default function ReteView() {
  const set = useApp((s) => s.set)
  const navigate = useApp((s) => s.navigate)
  const reteTab = useApp((s) => s.reteTab)
  const topologyNode = useApp((s) => s.topologyNode)
  const deviceId = useApp((s) => s.deviceId)
  const mapProvider = useApp((s) => s.mapProvider)
  const activePlantId = useApp((s) => s.activePlantId)
  const topoSources = useApp((s) => s.topoSources)

  const tab = reteTab ?? 'topologia'
  /* Selezione arco derivata: memorizza anche il nodo selezionato al momento
   * della scelta — se la selezione nodo cambia, il dettaglio arco svanisce
   * (stato derivato, senza effetti a cascata). */
  const [edgeSel, setEdgeSel] = useState<{ id: string; node: string | null } | null>(null)
  const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null)
  const [locFilter, setLocFilter] = useState<LocFilter>('all')
  /* 16.10 W8: dialog «Gestione collegamenti» (di proprietà di QUESTA
   * vista: TopologyView chiede l'apertura via onOpenLinksManager). */
  const [linksManagerOpen, setLinksManagerOpen] = useState(false)

  const queryClient = useQueryClient()
  const summary = useQuery({ queryKey: ['noc-summary'], queryFn: () => api.summary(), staleTime: 60_000 })
  const health = useQuery({ queryKey: ['system-health'], queryFn: () => api.systemHealth(), staleTime: 60_000 })
  const locs = useQuery({ queryKey: ['map-locations'], queryFn: () => api.locations(), staleTime: 60_000 })

  /* Impianto attivo per le azioni di scrittura (radice dell'albero):
  * store se scelto, primo impianto reale altrimenti (query ['plants']). */
  const plants = useQuery({ queryKey: ['plants'], queryFn: () => api.plants(), staleTime: 300_000 })
  const plantId = activePlantId ?? plants.data?.data?.reduce((a, b) => (a.createdAt <= b.createdAt ? a : b))?.id ?? null

  /* 16.10 W8: STESSA fonte/filtro del canvas (topology-view) — stessa
   * query key ['topology-graph', sourcesKey] → cache condivisa e
   * invalidazione con prefisso (realtime + mutazioni) su tutte le
   * varianti di fonti. */
  const sources = useMemo(() => topoSourceMembers(topoSources), [topoSources])
  const sourcesKey = sources.join(',')
  const topo = useQuery({
    queryKey: ['topology-graph', sourcesKey],
    queryFn: () => api.topologyGraph({ sources }),
    staleTime: 60_000,
  })

  /* Realtime: invalidazione ogni 2 tick (~60 s), mai a ogni evento */
  const tickCount = useRef(0)
  useEffect(() => {
    const dispose = subscribeRealtime({
      onTick: () => {
        tickCount.current += 1
        if (tickCount.current % 2 === 0) {
          void queryClient.invalidateQueries({ queryKey: ['topology-graph'] })
          void queryClient.invalidateQueries({ queryKey: ['map-locations'] })
          /* v16.17 W18: anche il pannello dispositivi del punto segue il
           * ritmo realtime della mappa (mai per singolo evento). */
          void queryClient.invalidateQueries({ queryKey: ['location-devices'] })
        }
      },
    })
    return dispose
  }, [queryClient])

  const topoData = topo.data?.data
  const nodesById = useMemo(
    () => new Map((topoData?.nodes ?? []).map((n) => [n.id, n])),
    [topoData],
  )
  const selectedNodeId = topologyNode ?? deviceId
  const nodeDetail = useMemo(
    () => (topoData?.nodes ?? []).find((n) => n.id === selectedNodeId) ?? null,
    [topoData, selectedNodeId],
  )
  const edgeDetail = useMemo(
    () => (edgeSel && edgeSel.node === topologyNode
      ? (topoData?.edges ?? []).find((e) => e.id === edgeSel.id) ?? null
      : null),
    [edgeSel, topologyNode, topoData],
  )

  /* Filtro stato sedi (condiviso da mappa e lista) */
  const locFilterFn = useMemo(() => {
    switch (locFilter) {
      case 'problems':
        return (s: string | null) => s === 'DEGRADED' || s === 'OFFLINE' || s === 'UNKNOWN' || s === 'NOT_MONITORED'
      case 'online':
        return (s: string | null) => s === 'ONLINE'
      default:
        return () => true
    }
  }, [locFilter])

  const filteredLocations = useMemo(() => {
    const all = locs.data?.data ?? []
    return all.filter((l) => locFilterFn(l.worstStatus))
  }, [locs.data, locFilterFn])

  /* v16.17 W18: la rete REALE disegnata sul territorio — per ogni arco
   * dell'albero (fonti già filtrate dal selettore) con i due capi in
   * sedi DIVERSE e con coordinate GPS, una linea tra i due punti.
   * Colore/tratteggio dalla STESSA edgeVisual del canvas topologico
   * (coerenza visiva mappa↔topologia); tooltip onesto: capi, tipo,
   * segnale quando campionato. Nessuna linea senza dato. */
  const palette = usePalette()
  const linkLines = useMemo<MapLinkLine[]>(() => {
    const nodes = topoData?.nodes ?? []
    const edges = topoData?.edges ?? []
    if (!edges.length) return []
    const locById = new Map((locs.data?.data ?? []).map((l) => [l.id, l]))
    const nodeById = new Map(nodes.map((n) => [n.id, n]))
    const out: MapLinkLine[] = []
    for (const e of edges) {
      const a = nodeById.get(e.source)
      const b = nodeById.get(e.target)
      if (!a?.locationId || !b?.locationId || a.locationId === b.locationId) continue
      const la = locById.get(a.locationId)
      const lb = locById.get(b.locationId)
      if (!la || !lb || la.lat == null || la.lng == null || lb.lat == null || lb.lng == null) continue
      const vis = edgeVisual(e, isDownStatus(b.uiStatus), palette)
      out.push({
        from: [la.lat, la.lng],
        to: [lb.lat, lb.lng],
        color: vis.color,
        dashed: !!vis.dash,
        tooltip: `${a.hostname} → ${b.hostname} · ${e.linkType}${b.signalDbm != null ? ` · ${fmtDbm(b.signalDbm)}` : ''}`,
      })
    }
    return out
  }, [topoData, locs.data, palette])

  const plantName = summary.data?.data.plant.name ?? '…'

  /* Sede selezionata (click su marker mappa o riga lista): alimenta il
   * pannello dispositivi del punto (v16.17 W18, pattern UISP). */
  const selectedLocation = useMemo(
    () => (locs.data?.data ?? []).find((l) => l.id === selectedLocationId) ?? null,
    [locs.data, selectedLocationId],
  )

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <PageHeader
        title={`Rete · ${plantName}`}
        subtitle="Topologia logica filtrabile per fonte dei collegamenti (operatore · protocolli · UISP · inferenze), mappa geografica delle sedi e inventario MAC (FDB × inventario)"
        section={tab === 'mappa' ? 'Mappa sedi' : tab === 'mac' ? 'Inventario MAC' : 'Topologia'}
        mode={summary.data?.mode}
        importedAt={health.data?.data.replay.importedAt ?? null}
      />

      <Tabs
        value={tab}
        onValueChange={(v) => { set({ reteTab: v === 'mappa' ? 'mappa' : v === 'mac' ? 'mac' : v === 'speed' ? 'speed' : 'topologia' }) }}
        className="flex min-h-0 flex-1 flex-col"
      >
        <TabsList
          aria-label="Sezioni della vista Rete"
          className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit sm:justify-center"
        >
          <TabsTrigger value="topologia" className="shrink-0">Topologia</TabsTrigger>
          <TabsTrigger value="mappa" className="shrink-0">Mappa</TabsTrigger>
          <TabsTrigger value="mac" className="shrink-0">MAC</TabsTrigger>
          <TabsTrigger value="speed" className="shrink-0">Speed test</TabsTrigger>
        </TabsList>

        {/* ---------------- Tab Topologia ---------------- */}
        <TabsContent value="topologia" className="mt-2 flex min-h-0 flex-1 flex-col">
          <div className="flex min-h-0 flex-col gap-4 lg:flex-row">
            <div className="min-w-0 flex-1">
              <TopologyView
                onSelectEdge={(edgeId) => { setEdgeSel(edgeId ? { id: edgeId, node: topologyNode } : null) }}
                onOpenLinksManager={() => setLinksManagerOpen(true)}
                className="h-[calc(100vh_-_300px)] min-h-[520px]"
              />
            </div>
            <aside className="w-full shrink-0 border-t border-border pt-3 lg:w-80 lg:border-l lg:border-t-0 lg:pl-4 lg:pt-0">
              <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-wider text-text-2">
                Dettaglio selezione
              </p>
              <div className="max-h-[calc(100vh_-_380px)] overflow-y-auto scroll-thin pr-1 lg:max-h-[calc(100vh_-_340px)]">
                {edgeDetail ? (
                  <EdgeDetail edge={edgeDetail} nodesById={nodesById} asOf={topo.data?.asOf} />
                ) : nodeDetail ? (
                  <NodeDetail
                    node={nodeDetail}
                    plantId={plantId}
                    isCurrentRoot={!!topoData && topoData.rootSource === 'operator' && topoData.gatewayId === nodeDetail.id}
                  />
                ) : (
                  <EmptyState
                    icon={<MousePointerClick className="size-10" aria-hidden />}
                    title="Seleziona un nodo o un collegamento"
                    description="Clicca un nodo del grafo per l'identità e le metriche, o un arco per i dettagli del collegamento."
                  />
                )}
              </div>
            </aside>
          </div>
          {/* 16.10 W8: gestione collegamenti (dialog controllato, nodi dal
           * grafo corrente per i selettori del nuovo collegamento). */}
          <TopologyLinksManager
            open={linksManagerOpen}
            onOpenChange={setLinksManagerOpen}
            nodes={topoData?.nodes ?? []}
          />
        </TabsContent>

        {/* ---------------- Tab Mappa ---------------- */}
        <TabsContent value="mappa" className="mt-2 flex min-h-0 flex-1 flex-col">
          <div className="grid min-h-0 min-w-0 flex-1 gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
            <div className="h-[420px] min-h-[420px] lg:h-[calc(100vh_-_320px)]">
              <MapView
                provider={mapProvider ?? 'osm'}
                onProviderChange={(p) => { set({ mapProvider: p }) }}
                selectedLocationId={selectedLocationId}
                onSelectLocation={setSelectedLocationId}
                filter={locFilterFn}
                linkLines={linkLines}
              />
            </div>
            <aside className="flex min-w-0 flex-col gap-3">
              {/* v16.17 W18: dettaglio sede selezionata (pattern UISP) —
               * il click sul punto della mappa (o sulla lista) riempie il
               * pannello con TUTTI i dispositivi della sede. */}
              {selectedLocation ? (
                <LocationDevicesPanel loc={selectedLocation} onClose={() => setSelectedLocationId(null)} />
              ) : null}
              <div className="flex items-center justify-between gap-2">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-text-2">
                  Sedi <span className="num">({filteredLocations.length})</span>
                  {linkLines.length > 0 ? <span> · <span className="num">{linkLines.length}</span> collegamenti sul territorio</span> : null}
                </p>
                {/* Scopribilità: l'import Excel/KMZ vive in Amministrazione·
                 * Impianti — un taso qui accorcia il percorso (richiesta
                 * operatore: «come faccio a caricare excel e kmz?»). */}
                <Button
                  variant="outline" size="sm" className="h-7 gap-1.5 px-2 text-[11px]"
                  onClick={() => { set({ adminSez: 'impianti' }); navigate('amministrazione') }}
                  title="Importa Excel di installazione o punti KMZ/KML (Amministrazione → Impianti)"
                >
                  <FileSpreadsheet className="size-3.5" aria-hidden /> Importa Excel/KMZ
                </Button>
              </div>
              <ToggleGroup
                type="single" variant="outline" size="sm"
                value={locFilter}
                onValueChange={(v) => { if (v) setLocFilter(v as LocFilter) }}
                aria-label="Filtra le sedi per stato"
              >
                <ToggleGroupItem value="all" className="text-xs">Tutti</ToggleGroupItem>
                <ToggleGroupItem value="problems" className="text-xs">Con problemi</ToggleGroupItem>
                <ToggleGroupItem value="online" className="text-xs">Online</ToggleGroupItem>
              </ToggleGroup>
              <div className="scroll-thin max-h-96 space-y-1.5 overflow-y-auto pr-1" role="list" aria-label="Elenco delle sedi">
                {locs.isLoading ? (
                  <LoadingRows rows={6} />
                ) : locs.isError ? (
                  <ErrorPanel
                    message={(locs.error as Error).message}
                    onRetry={() => { void locs.refetch() }}
                  />
                ) : filteredLocations.length === 0 ? (
                  <EmptyState
                    title="Nessuna sede corrisponde al filtro"
                    description="Cambia il filtro stato per vedere le altre sedi dell'impianto."
                  />
                ) : (
                  filteredLocations.map((l) => (
                    <div role="listitem" key={l.id}>
                      <LocationRowButton
                        loc={l}
                        selected={selectedLocationId === l.id}
                        onSelect={setSelectedLocationId}
                      />
                    </div>
                  ))
                )}
              </div>
            </aside>
          </div>
        </TabsContent>
        {/* ---------------- Tab MAC: inventario (16.5.0) ---------------- */}
        <TabsContent value="mac" className="mt-2 flex min-h-0 flex-1 flex-col">
          <MacInventoryTab />
        </TabsContent>
        {/* 16.9 W4: speed test iperf3 (executor assente → 501 onesto;
         * SIMULATED marcato, mai spacciato). */}
        <TabsContent value="speed" className="mt-2">
          <SpeedTestPanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}
