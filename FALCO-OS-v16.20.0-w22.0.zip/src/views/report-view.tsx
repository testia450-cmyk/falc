/* ================================================================
 * FALCO-OS v16 — Vista «Report» (§6.9)
 * Onesta al 100%: SOLO export che funzionano ADESSO su dati reali
 * del DB (CSV generati client-side dai dati caricati via API); i
 * report programmati sono dichiarati come roadmap W2 con badge NON
 * interattivo (nessun pulsante finto). La «Sintesi impianto» mostra
 * i numeri reali del summary: la base del report futuro.
 * 16.4 (W2 residua): sezione «Disponibilità di rete» — dalla serie
 * REALE packetLoss (congelata alla fine del prelievo reale: copertura
 * DICHIARATA, n.d. oltre), finestra 24/48/168 h scelta dall'operatore,
 * nessuna soglia SLA inventata (SLADefinition = 0 nel DB reale),
 * export CSV della tabella.
 * 16.8 (W2 residua): «Report SLA mensile» — coorte REALE dei ticket
 * del mese selezionato, tempi SOLO dai campi esistenti
 * (firstResponseAt/resolvedAt: «n.d.» altrove, mai 0), copertura e
 * nota D19 DICHIARATE dal payload; storico per mese + CSV. «Report
 * pianificati» — CRUD REALE sul modello ScheduledReport (il motore
 * di schedulazione non gira in riproduzione: D2 dichiarato dal
 * payload; nextRunAt è proiezione calcolata, mai eseguita).
 * Nessun numero inventato; liste vuote dichiarate; errori → toast.
 * ================================================================ */

'use client'

import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Activity, CalendarClock, Download, FileSpreadsheet, FileText, Loader2, Plus, Printer, Trash2, TriangleAlert,
} from 'lucide-react'

import { PageHeader } from '@/components/page-header'
import { EmptyState, ErrorPanel } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { api, ApiError, type DeviceRow, type AlarmRow, type WeakLinkRow, type AvailabilityRow, type AvailabilityByLocationRow } from '@/lib/client/api'
import type { CreateScheduledReportInput, NocSummary, ScheduledReportRow, SlaReport } from '@/lib/v2/contracts'
import {
  STATUS_META, SEVERITY_META, fmtAgeMinutes, fmtDateTime, fmtDateTimeFull, fmtDbm, fmtNumber, fmtPct, typeLabel,
} from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Report programmati (roadmap residua, statici) ----------------
 * Le voci consegnate in 16.8 (Scheda intervento PDF, Report SLA
 * mensile, Esportazione programmata) sono diventate sezioni REALI
 * sopra: qui resta la sola voce non ancora consegnata del piano. */
const PLANNED_REPORTS: Array<{ title: string; description: string }> = [
  {
    title: 'Report disponibilità per sede',
    description: 'Disponibilità degli apparati per sede, aggregata dalle metriche reali raccolte dai poller (nessun dato stimato).',
  },
]

/* ---------------- Helper CSV ---------------- */

function csvEscape(v: string): string {
  return `"${v.replace(/"/g, '""')}"`
}

/** Righe → file CSV scaricato (BOM UTF-8, separatore «;» come il resto
 *  del progetto). Prima riga: commento di provenienza con data ISO. */
function downloadCsv(filename: string, header: string[], rows: string[][]) {
  const stamp = new Date().toISOString()
  const lines = [
    `# FALCO-OS generato il ${stamp} — dati reali del DB`,
    header.map(csvEscape).join(';'),
    ...rows.map((r) => r.map(csvEscape).join(';')),
  ]
  const blob = new Blob([`\ufeff${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 5_000)
}

function fileStamp(): string {
  return new Date().toISOString().slice(0, 16).replace(/[:T]/g, '')
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* ---------------- Vocabolari e helper 16.8 (W2 residua) ---------------- */

/* Ticket del DB reale: etichette del dominio con fallback onesto sul
 * valore grezzo restituito dal backend (mai inventato). */
const TICKET_STATUS_LABELS: Record<string, string> = {
  OPEN: 'Aperto', IN_PROGRESS: 'In lavorazione', RESOLVED: 'Risolto', CLOSED: 'Chiuso',
}
const TICKET_PRIORITY_LABELS: Record<string, string> = {
  CRITICAL: 'Critica', HIGH: 'Alta', MEDIUM: 'Media', LOW: 'Bassa',
}
const TICKET_SOURCE_LABELS: Record<string, string> = {
  MANUAL: 'Manuale', AUTO: 'Automatica', WATCHDOG: 'Watchdog',
}

/** 'YYYY-MM' → «ottobre 2026» (fallback: la stringa così com'è). */
function monthLabel(m: string): string {
  const d = new Date(`${m}-01T00:00:00`)
  if (Number.isNaN(d.getTime())) return m
  return d.toLocaleDateString('it-IT', { month: 'long', year: 'numeric' })
}

/** Minuti REALI: null → «n.d.» (mai 0 spacciato per misura). */
function fmtMin(v: number | null): string {
  return v == null ? 'n.d.' : fmtAgeMinutes(v)
}

/* Report pianificati: vocabolari del contratto v15/16 (valori del DB). */
const FREQ_LABELS: Record<string, string> = {
  HOURLY: 'Oraria', DAILY: 'Giornaliera', WEEKLY: 'Settimanale', MONTHLY: 'Mensile',
}
const WEEKDAY_LABELS = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato']
const CHANNEL_LABELS: Record<string, string> = { EMAIL: 'E-mail', TELEGRAM: 'Telegram', PDF: 'PDF' }
const SECTION_LABELS: Record<string, string> = {
  devices: 'Dispositivi', tickets: 'Ticket', sla: 'Report SLA', metrics: 'Metriche', alarms: 'Allarmi', availability: 'Disponibilità',
}
const CHANNEL_OPTIONS = ['EMAIL', 'TELEGRAM', 'PDF'] as const
type ChannelOption = (typeof CHANNEL_OPTIONS)[number]
const SECTION_OPTIONS = ['devices', 'tickets', 'sla', 'metrics', 'alarms', 'availability'] as const
type SectionOption = (typeof SECTION_OPTIONS)[number]
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** Dettaglio frequenza con i dati REALI della riga (no stime). */
function freqDetail(r: ScheduledReportRow): string {
  const hh = `${String(r.hour).padStart(2, '0')}:00`
  if (r.frequency === 'HOURLY') return `ogni ora · ${hh}`
  if (r.frequency === 'DAILY') return `tutti i giorni alle ${hh}`
  if (r.frequency === 'WEEKLY') return `${WEEKDAY_LABELS[r.dayOfWeek ?? 0] ?? 'n.d.'} alle ${hh}`
  if (r.frequency === 'MONTHLY') return `il giorno ${r.dayOfMonth ?? 'n.d.'} alle ${hh}`
  return r.frequency
}

function toggleIn<T>(list: T[], v: T, on: boolean): T[] {
  return on ? (list.includes(v) ? list : [...list, v]) : list.filter((x) => x !== v)
}

/* ================================================================
 * ReportView
 * ================================================================ */

type ExportKind = 'devices' | 'alarms' | 'weak' | 'pdf'

function escapeHtml(v: string): string {
  return v.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

/* --- Export PDF via stampa del browser (16.2): documento autonomo in
 *     nuova scheda con stili inline (nessuna dipendenza dall'app);
 *     window.print() apre la finestra «Salva come PDF» del sistema.
 *     Dati REALI del summary (la stessa base della sezione «Sintesi
 *     impianto»): prima riga di provenienza, nessun numero inventato. */
function printSintesi(s: NocSummary) {
  const esc = escapeHtml
  const generated = new Date().toLocaleString('it-IT')
  const rows: Array<[string, string]> = [
    ['Dispositivi', `${fmtNumber(s.devices.total)} — ${fmtNumber(s.devices.byState.online)} online, ${fmtNumber(s.devices.byState.degraded)} degradati, ${fmtNumber(s.devices.byState.notMonitored)} non monitorati`],
    ['Telecamere', `${fmtNumber(s.cameras.total)} — flussi fermi: ${fmtNumber(s.cameras.streamDown)}, mai campionati: ${fmtNumber(s.cameras.streamUnknown)}`],
    ['Link wireless', `${fmtNumber(s.wirelessLinks.total)} — attivi ${fmtNumber(s.wirelessLinks.active)}, deboli (≤ −75 dBm) ${fmtNumber(s.wirelessLinks.weak)}`],
    ['Allarmi non chiusi', `${fmtNumber(s.alarms.open)} — di cui soppressi per causa radice ${fmtNumber(s.alarms.suppressed)}`],
    ['Copertura topologica', s.coverage ? `${s.coverage.coveragePct.toFixed(1).replace('.', ',')}% su obiettivo ${s.coverage.goalPct.toFixed(1).replace('.', ',')}%` : 'n.d.'],
  ]
  const html = `<!doctype html>
<html lang="it"><head><meta charset="utf-8"/>
<title>Sintesi impianto — ${esc(s.plant.name)} — FALCO-OS</title>
<style>
  body { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color:#101826; margin:48px; }
  h1 { font-size:22px; margin:0 0 4px; }
  h2 { font-size:14px; margin:28px 0 8px; text-transform:uppercase; letter-spacing:.05em; color:#5b6472; }
  .sub { color:#5b6472; font-size:13px; margin:0; }
  table { border-collapse:collapse; width:100%; font-size:14px; }
  th, td { border:1px solid #d8dee8; padding:8px 10px; text-align:left; vertical-align:top; }
  th { background:#f1f4f9; width:220px; }
  .foot { margin-top:28px; font-size:11px; color:#5b6472; border-top:1px solid #d8dee8; padding-top:10px; }
  @media print { body { margin:16mm; } }
</style></head><body>
<h1>Sintesi impianto — ${esc(s.plant.name)} (${esc(s.plant.comune)})</h1>
<p class="sub">Generato il ${generated} da FALCO-OS — dati reali del database</p>
<h2>Indicatori</h2>
<table><tbody>
${rows.map(([k, v]) => `<tr><th scope="row">${esc(k)}</th><td>${esc(v)}</td></tr>`).join('\n')}
</tbody></table>
<p class="foot">Documento generato dai dati reali del DB: nessun dato di esempio. Sorgente: GET /api/v2/noc/summary · FALCO-OS v16.</p>
</body></html>`
  const w = window.open('', '_blank', 'width=900,height=1100')
  if (!w) {
    toast.error('Stampa non riuscita', { description: 'Il browser ha bloccato la finestra di stampa: consenti i popup per questo sito.' })
    return
  }
  w.document.open()
  w.document.write(html)
  w.document.close()
  w.focus()
  w.setTimeout(() => w.print(), 300)
}

export default function ReportView() {
  const [busy, setBusy] = useState<ExportKind | null>(null)
  /* 16.4: finestra del report disponibilità (24/48/168 h). */
  const [availWindow, setAvailWindow] = useState<24 | 48 | 168>(48)

  const summary = useQuery({
    queryKey: ['noc-summary'],
    queryFn: () => api.summary(),
    staleTime: 60_000,
  })
  const availability = useQuery({
    queryKey: ['availability', availWindow],
    queryFn: () => api.availability(availWindow),
    staleTime: 60_000,
  })
  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    staleTime: 60_000,
  })

  /* --- Export 1: inventario dispositivi COMPLETO (loop pagine da 200) --- */
  const exportDevices = async () => {
    setBusy('devices')
    try {
      const all: DeviceRow[] = []
      let page = 1
      let pageCount = 1
      do {
        const res = await api.devices({ page, pageSize: 200 })
        all.push(...res.data.items)
        pageCount = res.data.pageCount
        page++
      } while (page <= pageCount)
      if (all.length === 0) {
        toast.info('Nessun dispositivo da esportare', { description: 'Il DB reale non ha dispositivi per i filtri correnti.' })
        return
      }
      downloadCsv(
        `falco-inventario-dispositivi-${fileStamp()}.csv`,
        ['Hostname', 'IP', 'Tipo', 'Stato', 'Marca', 'Modello', 'Segnale (dBm)', 'Qualità link', 'Ultima vista', 'Sede'],
        all.map((d) => [
          d.hostname,
          d.ip || 'n.d.',
          typeLabel(d.type),
          STATUS_META[d.uiStatus]?.label ?? d.uiStatus,
          d.brand || 'n.d.',
          d.model || 'n.d.',
          d.signalPresent ? String(d.signalStrength) : 'n.d.',
          fmtPct(d.linkQuality),
          d.lastSeenAt ? fmtDateTimeFull(d.lastSeenAt) : 'mai visto',
          d.locationName ?? 'n.d.',
        ]),
      )
      toast.success(`CSV esportato: ${fmtNumber(all.length)} dispositivi (inventario completo, dati reali del DB)`)
    } catch (err) {
      const e = errInfo(err)
      toast.error('Esportazione inventario non riuscita', { description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}` })
    } finally {
      setBusy(null)
    }
  }

  /* --- Export 2: allarmi aperti (status OPEN,ACK,ESCALATED — la stessa
   *     definizione del filtro «Aperti» della vista Allarmi) --- */
  const exportAlarms = async () => {
    setBusy('alarms')
    try {
      const all: AlarmRow[] = []
      let page = 1
      let pageCount = 1
      do {
        const res = await api.alarms({ status: 'OPEN,ACK,ESCALATED', page, pageSize: 100 })
        all.push(...res.data.items)
        pageCount = res.data.pageCount
        page++
      } while (page <= pageCount)
      if (all.length === 0) {
        toast.info('Nessun allarme aperto da esportare', { description: 'Il DB reale non ha allarmi aperti, riconosciuti o escalati.' })
        return
      }
      downloadCsv(
        `falco-allarmi-aperti-${fileStamp()}.csv`,
        ['Severità', 'Stato', 'Messaggio', 'Dispositivo', 'IP', 'Aperto il', 'Occorrenze', 'Riconosciuto da', 'Soppresso per causa radice'],
        all.map((a) => [
          SEVERITY_META[a.severity]?.label ?? a.severity,
          a.status,
          a.message,
          a.deviceHostname ?? 'n.d.',
          a.deviceIp ?? 'n.d.',
          fmtDateTimeFull(a.openedAt),
          String(a.occurrenceCount),
          a.acknowledgedBy ?? 'n.d.',
          a.suppressedByRootCause ? `sì (${a.rootCauseHostname ?? 'n.d.'})` : 'no',
        ]),
      )
      toast.success(`CSV esportato: ${fmtNumber(all.length)} allarmi aperti (dati reali del DB)`)
    } catch (err) {
      const e = errInfo(err)
      toast.error('Esportazione allarmi non riuscita', { description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}` })
    } finally {
      setBusy(null)
    }
  }

  /* --- Export 3: link radio deboli (limite API 50) --- */
  const exportWeakLinks = async () => {
    setBusy('weak')
    try {
      const res = await api.weakLinks(50)
      const all: WeakLinkRow[] = res.data
      if (all.length === 0) {
        toast.info('Nessun link radio da esportare', { description: 'Il DB reale non ha apparati radio con segnale letto.' })
        return
      }
      downloadCsv(
        `falco-link-deboli-${fileStamp()}.csv`,
        ['Hostname', 'IP', 'Tipo', 'Segnale (dBm)', 'Qualità link', 'Frequenza', 'SSID', 'Uplink verso', 'Sede', 'Ultima vista'],
        all.map((w) => [
          w.hostname,
          w.ip || 'n.d.',
          typeLabel(w.type),
          fmtDbm(w.signalDbm),
          fmtPct(w.linkQuality),
          w.frequency || 'n.d.',
          w.ssid || 'n.d.',
          w.uplinkApHostname ?? 'n.d.',
          w.locationName ?? 'n.d.',
          w.lastSeenAt ? fmtDateTimeFull(w.lastSeenAt) : 'mai visto',
        ]),
      )
      toast.success(`CSV esportato: ${fmtNumber(all.length)} link radio (i più deboli prima, dati reali del DB)`)
    } catch (err) {
      const e = errInfo(err)
      toast.error('Esportazione link deboli non riuscita', { description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}` })
    } finally {
      setBusy(null)
    }
  }

  /* --- Export 4 (16.4): disponibilità di rete dalla tabella caricata
   *     (stesso dato mostrato: nessuna doppia fonte) --- */
  const exportAvailability = () => {
    const a = availability.data?.data
    if (!a || a.items.length === 0) {
      toast.info('Nessuna riga di disponibilità da esportare', { description: 'Il report non ha dati caricati.' })
      return
    }
    downloadCsv(
      `falco-disponibilita-${a.windowHours}h-${fileStamp()}.csv`,
      ['Hostname', 'Tipo', 'Sede', 'Stato DB', 'Disponibilità %', 'Perdita media %', 'Perdita max %', 'Campioni perdita', 'Primo campione', 'Ultimo campione', 'Latenza media (ms)', 'Latenza max (ms)'],
      a.items.map((r) => [
        r.hostname,
        typeLabel(r.type),
        r.locationName ?? 'n.d.',
        r.dbStatus,
        r.availabilityPct != null ? r.availabilityPct.toFixed(2) : 'n.d.',
        r.lossAvgPct != null ? r.lossAvgPct.toFixed(2) : 'n.d.',
        r.lossMaxPct != null ? r.lossMaxPct.toFixed(2) : 'n.d.',
        String(r.lossSamples),
        r.firstSampleAt ? fmtDateTimeFull(r.firstSampleAt) : 'n.d.',
        r.lastSampleAt ? fmtDateTimeFull(r.lastSampleAt) : 'n.d.',
        r.pingAvgMs != null ? r.pingAvgMs.toFixed(1) : 'n.d.',
        r.pingMaxMs != null ? r.pingMaxMs.toFixed(1) : 'n.d.',
      ]),
    )
    toast.success(`CSV esportato: ${fmtNumber(a.items.length)} dispositivi (finestra ${a.windowHours} h, dati reali della serie packetLoss)`)
  }

  const s = summary.data?.data

  return (
    <div>
      <PageHeader
        title="Report"
        subtitle="Esportazioni reali, report SLA mensile e pianificazione report — voci W2 residue consegnate (16.8)"
        mode={summary.data?.mode}
        importedAt={health.data?.data.replay.importedAt ?? null}
      />

      {/* --- Export reali (ora) --- */}
      <section aria-labelledby="export-now">
        <h2 id="export-now" className="text-sm font-semibold">Export reali (ora)</h2>
        <p className="mt-0.5 text-xs text-text-2">
          File CSV generati al momento del clic dai dati REALI del DB (nessun campionamento, nessun
          dato finto). La prima riga di ogni file dichiara data e ora di generazione.
        </p>
        <div className="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <ExportCard
            icon={<FileSpreadsheet className="size-5" aria-hidden />}
            title="Inventario dispositivi"
            description="Tutti i dispositivi dell'impianto (pagine da 200): hostname, IP, tipo, stato, sede, segnale radio, ultima vista."
            busy={busy === 'devices'}
            disabled={busy !== null}
            onDownload={() => { void exportDevices() }}
          />
          <ExportCard
            icon={<TriangleAlert className="size-5" aria-hidden />}
            title="Allarmi aperti"
            description="Allarmi con stato aperto, riconosciuto o escalato (la stessa definizione del filtro «Aperti» della vista Allarmi), con causa radice."
            busy={busy === 'alarms'}
            disabled={busy !== null}
            onDownload={() => { void exportAlarms() }}
          />
          <ExportCard
            icon={<FileSpreadsheet className="size-5" aria-hidden />}
            title="Link radio deboli"
            description="Link radio ordinati dal più debole (massimo 50, limite dell'API): segnale, frequenza, uplink, sede."
            busy={busy === 'weak'}
            disabled={busy !== null}
            onDownload={() => { void exportWeakLinks() }}
          />
          <ExportCard
            icon={<FileText className="size-5" aria-hidden />}
            title="Sintesi impianto (PDF)"
            description="Documento stampabile con gli indicatori reali del summary (dispositivi, telecamere, link, allarmi, copertura): apre la finestra di stampa del browser per «Salva come PDF»."
            busy={busy === 'pdf'}
            disabled={busy !== null || !s}
            downloadLabel="Stampa / PDF"
            onDownload={() => {
              if (!s) return
              setBusy('pdf')
              try { printSintesi(s) } finally { setBusy(null) }
            }}
          />
        </div>
      </section>

      {/* --- Disponibilità di rete (16.4, W2 residua): serie REALE
       *     packetLoss con finestra e copertura DICHIARATE --- */}
      <section aria-labelledby="avail-report" className="mt-8">
        <div className="flex flex-wrap items-center gap-2">
          <h2 id="avail-report" className="text-sm font-semibold">Disponibilità di rete (perdita pacchetti)</h2>
          <Badge variant="outline" className="border-border bg-raised font-normal text-text-2" aria-label="Onda 2 del piano di migrazione, residua consegnata in 16.4">W2</Badge>
          <div className="ml-auto">
            <Select
              value={String(availWindow)}
              onValueChange={(v) => { setAvailWindow(Number(v) === 24 || Number(v) === 168 ? (Number(v) as 24 | 168) : 48) }}
            >
              <SelectTrigger className="h-9 w-[150px]" aria-label="Finestra del report disponibilità">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24">Ultime 24 ore</SelectItem>
                <SelectItem value="48">Ultime 48 ore</SelectItem>
                <SelectItem value="168">Ultime 7 giorni</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <p className="mt-0.5 text-xs text-text-2">
          Disponibilità = 100 − perdita pacchetti media, dalla serie REALE «packetLoss» del poller.
          La latenza (pingLatency) è riportata come statistica supplementare, non come disponibilità.
        </p>

        {availability.isPending ? (
          <div role="status" aria-busy="true" className="mt-3 h-40 animate-pulse rounded-lg bg-surface">
            <span className="sr-only">Caricamento report disponibilità</span>
          </div>
        ) : availability.isError ? (
          <ErrorPanel
            className="mt-3"
            message={errInfo(availability.error).message}
            code={errInfo(availability.error).code}
            onRetry={() => { void availability.refetch() }}
          />
        ) : availability.data ? <AvailabilityTable data={availability.data.data} onExport={exportAvailability} /> : null}
      </section>

      {/* --- Report SLA mensile (16.8, W2 residua): coorte REALE dei
       *     ticket del mese selezionato; tempi SOLO dai campi esistenti
       *     («n.d.» altrove), copertura e nota D19 dichiarate --- */}
      <SlaReportSection />

      {/* --- Report pianificati (16.8, W2 residua): CRUD REALE sul
       *     modello ScheduledReport; il motore di schedulazione non
       *     gira in riproduzione (D2, dichiarato dal payload) --- */}
      <ScheduledReportsSection />

      {/* --- Report programmati (roadmap residua): le voci consegnate in
       *     16.8 sono diventate sezioni reali sopra; resta la sola voce
       *     dichiarativa del piano, nessun pulsante finto --- */}
      <section aria-labelledby="export-planned" className="mt-8">
        <div className="flex items-center gap-2">
          <h2 id="export-planned" className="text-sm font-semibold">Report programmati (roadmap)</h2>
          <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2" aria-label="Onda 2 del piano di migrazione">W2</Badge>
        </div>
        <p className="mt-0.5 text-xs text-text-2">
          Le voci consegnate in 16.8 — Scheda intervento PDF, Report SLA mensile ed Esportazione
          programmata — sono diventate sezioni reali sopra. Resta la sola voce dichiarativa del
          piano di migrazione (trasparenza, non funzioni simulate).
        </p>
        <ul className="mt-3 grid gap-2 md:grid-cols-2">
          {PLANNED_REPORTS.map((r) => (
            <li key={r.title} className="rounded-lg border border-dashed border-border bg-surface/50 p-4">
              <div className="flex items-start gap-2.5">
                <CalendarClock className="mt-0.5 size-4 shrink-0 text-dim" aria-hidden />
                <div className="min-w-0">
                  <p className="text-sm font-medium">{r.title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-text-2">{r.description}</p>
                </div>
                <Badge variant="outline" className="num ml-auto shrink-0 border-border bg-raised font-normal text-text-2">W2</Badge>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {/* --- Sintesi impianto (adesso): base del report futuro --- */}
      <section aria-labelledby="plant-summary" className="mt-8">
        <h2 id="plant-summary" className="text-sm font-semibold">Sintesi impianto (adesso)</h2>
        <p className="mt-0.5 text-xs text-text-2">
          Numeri reali del summary — la stessa base dati su cui sarà costruito il report
          programmato dell&apos;onda W2.
        </p>
        {summary.isPending ? (
          <div role="status" aria-busy="true" className="mt-3 h-40 animate-pulse rounded-lg bg-surface">
            <span className="sr-only">Caricamento sintesi</span>
          </div>
        ) : summary.isError ? (
          <ErrorPanel
            className="mt-3"
            message={errInfo(summary.error).message}
            code={errInfo(summary.error).code}
            onRetry={() => { void summary.refetch() }}
          />
        ) : !s ? (
          <EmptyState className="mt-3" title="Sintesi non disponibile" description="Il summary non ha restituito dati." />
        ) : (
          <Card className="mt-3 border-border/70 bg-surface">
            <CardContent className="p-4 sm:p-6">
              <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
                <Row label="Impianto" value={`${s.plant.name} (${s.plant.comune})`} />
                <Row
                  label="Dispositivi"
                  value={
                    <>
                      <span className="num font-medium">{fmtNumber(s.devices.total)}</span>
                      <span className="text-text-2"> · {fmtNumber(s.devices.byState.online)} online, {fmtNumber(s.devices.byState.degraded)} degradati, {fmtNumber(s.devices.byState.notMonitored)} non monitorati</span>
                    </>
                  }
                />
                <Row
                  label="Telecamere"
                  value={
                    <>
                      <span className="num font-medium">{fmtNumber(s.cameras.total)}</span>
                      <span className="text-text-2"> · flussi fermi all'ultimo controllo: </span>
                      <span className={cn('num font-medium', s.cameras.streamDown > 0 ? 'text-crit' : 'text-ok')}>{fmtNumber(s.cameras.streamDown)}</span>
                      <span className="text-text-2">, mai campionati: {fmtNumber(s.cameras.streamUnknown)}</span>
                    </>
                  }
                />
                <Row
                  label="Link wireless"
                  value={
                    <>
                      <span className="num font-medium">{fmtNumber(s.wirelessLinks.total)}</span>
                      <span className="text-text-2"> · attivi {fmtNumber(s.wirelessLinks.active)}, deboli (≤ −75 dBm) {fmtNumber(s.wirelessLinks.weak)}</span>
                    </>
                  }
                />
                <Row
                  label="Allarmi non chiusi"
                  value={
                    <>
                      <span className="num font-medium">{fmtNumber(s.alarms.open)}</span>
                      <span className="text-text-2"> · di cui soppressi per causa radice {fmtNumber(s.alarms.suppressed)}</span>
                    </>
                  }
                />
                <Row
                  label="Copertura topologica"
                  value={s.coverage ? (
                    <>
                      <span className={cn('num font-medium', s.coverage.goalMet ? 'text-ok' : 'text-warn')}>{fmtPct(s.coverage.coveragePct)}</span>
                      <span className="text-text-2"> su obiettivo {fmtPct(s.coverage.goalPct)}</span>
                    </>
                  ) : 'n.d.'}
                />
              </dl>
              {summary.data ? <AsOf ts={summary.data.asOf} className="mt-4" /> : null}
            </CardContent>
          </Card>
        )}
      </section>
    </div>
  )
}

/* ---------------- Sotto-componenti ---------------- */

/** Tabella disponibilità: copertura e finestra DICHIARATE in caption,
 *  «n.d.» dove la serie non ha campioni (mai 100% per mancanza dato),
 *  ordinamento: peggior disponibilità prima (n.d. in coda). Nessuna
 *  colorazione di merito: SLADefinition = 0 nel DB reale, nessuna
 *  soglia inventata (i valori critici/ok sono SOLO descrittivi del
 *  numero, non un giudizio di conformità). */
function AvailabilityTable({
  data, onExport,
}: {
  data: {
    items: AvailabilityRow[]
    byLocation: AvailabilityByLocationRow[]
    total: number
    windowHours: number
    coverageFrom: number | null
    coverageTo: number | null
    slaTargetsDefined: number
  }
  onExport: () => void
}) {
  const rows = [...data.items].sort((a, b) => {
    if (a.availabilityPct == null && b.availabilityPct == null) return a.hostname.localeCompare(b.hostname, 'it')
    if (a.availabilityPct == null) return 1
    if (b.availabilityPct == null) return -1
    return a.availabilityPct - b.availabilityPct
  })
  const withData = data.items.filter((r) => r.lossSamples > 0).length
  /* La serie REALE termina a coverageTo: se è più vecchia di 1 h lo
   * dichiariamo apertamente (il prelievo reale è finito lì). */
  const frozen = data.coverageTo != null && Date.now() - data.coverageTo > 3_600_000

  return (
    <Card className="mt-3 border-border/70 bg-surface">
      <CardContent className="p-4 sm:p-6">
        <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
          <div className="grid gap-1 text-xs text-text-2">
            <p>
              Finestra richiesta: <strong className="num">{data.windowHours} h</strong> · dispositivi
              con campioni nella finestra: <strong className="num">{fmtNumber(withData)}</strong> di{' '}
              <strong className="num">{fmtNumber(data.total)}</strong>
            </p>
            <p>
              Copertura effettiva dei campioni reali:{' '}
              {data.coverageFrom != null && data.coverageTo != null ? (
                <>
                  <span className="num">{fmtDateTimeFull(data.coverageFrom)}</span> →{' '}
                  <span className="num">{fmtDateTimeFull(data.coverageTo)}</span>
                </>
              ) : 'nessun campione packetLoss nella finestra (tutte le righe «n.d.»)'}
            </p>
            {frozen ? (
              <p className="rounded-md border border-warn/40 bg-warn-soft px-2.5 py-1.5 text-warn" role="note">
                La serie «packetLoss» termina al {data.coverageTo != null ? fmtDateTimeFull(data.coverageTo) : 'n.d.'}:
                il prelievo reale è finito lì. Oltre quella data nessun campione esiste — la disponibilità
                delle righe senza campioni è «n.d.», mai 100% inventato.
              </p>
            ) : null}
            <p>
              Obiettivi SLA definiti nel DB reale: <strong className="num">{fmtNumber(data.slaTargetsDefined)}</strong>
              {data.slaTargetsDefined === 0 ? ' — nessuna soglia di conformità applicata (nessun SLA inventato)' : ''}
            </p>
          </div>
          <Button variant="outline" size="sm" className="h-9 shrink-0" onClick={onExport} disabled={rows.length === 0}>
            <Download className="size-3.5" aria-hidden />
            Scarica CSV
          </Button>
        </div>

        {/* v16.16 W17-b — disponibilità PER SEDE (roadmap W2 residua):
            * media delle sole righe con campioni, peggiore con hostname,
            * «senza dati» contati a parte (mai zero né cento inventati). */}
        {data.byLocation.length > 0 ? (
          <div className="mb-4 rounded-lg border border-border/70 bg-raised/30">
            <p className="border-b border-border/60 px-3 py-2 text-xs font-medium text-text-1" id="avail-by-location-caption">
              Disponibilità per sede · media delle sole righe con campioni · peggiore prima · «senza sede» ultima
            </p>
            <div className="max-h-64 overflow-y-auto scroll-thin" role="region" aria-label="Disponibilità per sede" tabIndex={0}>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[140px]">Sede</TableHead>
                    <TableHead className="text-right">Apparati</TableHead>
                    <TableHead className="text-right">Con dati</TableHead>
                    <TableHead className="text-right">Disponibilità media</TableHead>
                    <TableHead className="min-w-[170px]">Peggiore apparato</TableHead>
                    <TableHead className="text-right">Campioni</TableHead>
                    <TableHead className="min-w-[150px]">Copertura</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.byLocation.map((g) => (
                    <TableRow key={g.locationId ?? '__no_location__'} className={g.locationId == null ? 'bg-raised/20' : undefined}>
                      <TableCell className="max-w-[180px] truncate font-medium" title={g.locationName ?? 'senza sede (host scoperti non adottati)'}>
                        {g.locationName ?? <span className="text-dim">senza sede</span>}
                      </TableCell>
                      <TableCell className="num text-right text-text-2">{fmtNumber(g.devices)}</TableCell>
                      <TableCell className="num text-right text-text-2" title={`${g.withoutData} senza campioni nella finestra (n.d.)`}>
                        {fmtNumber(g.withData)}
                        {g.withoutData > 0 ? <span className="text-dim"> +{fmtNumber(g.withoutData)} n.d.</span> : null}
                      </TableCell>
                      <TableCell className={cn('num text-right font-medium', g.availabilityAvgPct == null ? 'text-dim' : g.availabilityAvgPct < 95 ? 'text-crit-text' : g.availabilityAvgPct < 99 ? 'text-warn' : 'text-ok')}>
                        {g.availabilityAvgPct != null ? `${g.availabilityAvgPct.toFixed(2)}%` : 'n.d.'}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate text-text-2" title={g.worstHostname ?? undefined}>
                        {g.worstHostname != null && g.availabilityMinPct != null ? (
                          <>
                            <span className="font-medium text-text-1">{g.worstHostname}</span>
                            {' '}
                            <span className={cn('num', g.availabilityMinPct < 95 ? 'text-crit-text' : g.availabilityMinPct < 99 ? 'text-warn' : 'text-ok')}>
                              {g.availabilityMinPct.toFixed(2)}%
                            </span>
                          </>
                        ) : (
                          <span className="text-dim">n.d.</span>
                        )}
                      </TableCell>
                      <TableCell className="num text-right text-text-2">
                        <span className="inline-flex items-center gap-1">
                          <Activity className="size-3 text-dim" aria-hidden />
                          {fmtNumber(g.lossSamples)}
                        </span>
                      </TableCell>
                      <TableCell className="num text-right text-[11px] text-text-2" title={g.coverageFrom != null && g.coverageTo != null ? `da ${fmtDateTimeFull(g.coverageFrom)} a ${fmtDateTimeFull(g.coverageTo)}` : 'nessun campione nella finestra'}>
                        {g.coverageFrom != null && g.coverageTo != null ? (
                          <>
                            {fmtDateTime(g.coverageFrom)} → {fmtDateTime(g.coverageTo)}
                          </>
                        ) : (
                          <span className="text-dim">n.d.</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : null}

        <div className="max-h-96 overflow-y-auto scroll-thin [&_[data-slot=table-container]]:overflow-x-visible" role="region" aria-label="Tabella disponibilità per dispositivo" tabIndex={0}>
          <Table>
            <TableCaption>
              Serie reale packetLoss · disponibilità = 100 − perdita media · ordinata dalla peggior
              disponibilità · «n.d.» = nessun campione nella finestra
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[150px]">Dispositivo</TableHead>
                <TableHead className="min-w-[110px]">Sede</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead className="text-right">Disponibilità</TableHead>
                <TableHead className="text-right">Perdita media</TableHead>
                <TableHead className="text-right">Perdita max</TableHead>
                <TableHead className="text-right">Campioni</TableHead>
                <TableHead className="text-right">Latenza media</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.deviceId}>
                  <TableCell className="max-w-[220px] truncate font-medium" title={r.hostname}>{r.hostname}</TableCell>
                  <TableCell className="max-w-[140px] truncate text-text-2" title={r.locationName ?? 'senza sede'}>
                    {r.locationName ?? <span className="text-dim">senza sede</span>}
                  </TableCell>
                  <TableCell className="text-text-2">{r.dbStatus}</TableCell>
                  <TableCell className={cn('num text-right font-medium', r.availabilityPct == null ? 'text-dim' : r.availabilityPct < 95 ? 'text-crit-text' : r.availabilityPct < 99 ? 'text-warn' : 'text-ok')}>
                    {r.availabilityPct != null ? `${r.availabilityPct.toFixed(2)}%` : 'n.d.'}
                  </TableCell>
                  <TableCell className="num text-right text-text-2">{r.lossAvgPct != null ? `${r.lossAvgPct.toFixed(2)}%` : 'n.d.'}</TableCell>
                  <TableCell className="num text-right text-text-2">{r.lossMaxPct != null ? `${r.lossMaxPct.toFixed(2)}%` : 'n.d.'}</TableCell>
                  <TableCell className="num text-right text-text-2" title={r.firstSampleAt && r.lastSampleAt ? `da ${fmtDateTimeFull(r.firstSampleAt)} a ${fmtDateTimeFull(r.lastSampleAt)}` : undefined}>
                    <span className="inline-flex items-center gap-1">
                      <Activity className="size-3 text-dim" aria-hidden />
                      {fmtNumber(r.lossSamples)}
                    </span>
                  </TableCell>
                  <TableCell className="num text-right text-text-2">{r.pingAvgMs != null ? `${r.pingAvgMs.toFixed(1)} ms` : 'n.d.'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {availabilityRowsHint(rows.length)}
      </CardContent>
    </Card>
  )
}

function availabilityRowsHint(n: number) {
  if (n === 0) return null
  return (
    <p className="mt-2 text-[11px] text-dim">
      {fmtNumber(n)} righe · i valori critici/degradati descrivono il NUMERO (sotto 95%/99%), non un
      giudizio di conformità: nessuna soglia SLA è definita nel DB reale.
    </p>
  )
}

function ExportCard({
  icon, title, description, busy, disabled, onDownload, downloadLabel,
}: {
  icon: React.ReactNode
  title: string
  description: string
  busy: boolean
  disabled: boolean
  onDownload: () => void
  downloadLabel?: string
}) {
  return (
    <Card className="border-border/70 bg-surface">
      <CardContent className="flex h-full flex-col gap-3 p-4">
        <div className="flex items-center gap-2.5">
          <span className="text-text-2">{icon}</span>
          <p className="text-sm font-medium">{title}</p>
        </div>
        <p className="min-w-0 flex-1 text-xs leading-relaxed text-text-2">{description}</p>
        <Button variant="outline" className="h-9" disabled={disabled} onClick={onDownload} aria-live={busy ? 'polite' : undefined}>
          {busy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : (downloadLabel != null ? <Printer className="size-3.5" aria-hidden /> : <Download className="size-3.5" aria-hidden />)}
          {busy ? 'Preparazione…' : (downloadLabel ?? 'Scarica CSV')}
        </Button>
      </CardContent>
    </Card>
  )
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 border-b border-border/50 pb-2.5 sm:flex-row sm:items-baseline sm:gap-3 sm:border-0 sm:pb-0">
      <dt className="w-40 shrink-0 text-[13px] text-text-2">{label}</dt>
      <dd className="min-w-0 break-words">{value}</dd>
    </div>
  )
}

/* ================================================================
 * 16.8 (W2 residua) — Sezione «Report SLA mensile»
 * Coorte REALE dei ticket del mese selezionato (selettore sui mesi
 * con ticket reali restituiti dal payload, default = il più recente
 * scelto dal server). Tempi di prima risposta e risoluzione SOLO dai
 * campi esistenti (firstResponseAt/resolvedAt): «n.d.» quando la
 * misura non c'è, mai 0 spacciato per misura; le stringhe coverage e
 * la nota D19 sono mostrate così come il backend le dichiara. Storico
 * per mese + export CSV client-side (stesso helper del file).
 * ================================================================ */

function SlaReportSection() {
  /* null = nessuna scelta manuale: usa il default del server
   * (months[0], il più recente). */
  const [month, setMonth] = useState<string | null>(null)

  const sla = useQuery({
    queryKey: ['sla-report', month],
    queryFn: () => api.slaReport(month ?? undefined),
    staleTime: 60_000,
  })

  const d = sla.data?.data
  const selected = month ?? d?.month ?? ''
  /* Durante il cambio mese (refetch) la lista precedente non c'è: il
   * selettore resta comunque visibile con il solo mese selezionato. */
  const months = d?.months ?? (month != null ? [month] : [])

  return (
    <section aria-labelledby="sla-report" className="mt-8">
      <div className="flex flex-wrap items-center gap-2">
        <h2 id="sla-report" className="text-sm font-semibold">Report SLA mensile</h2>
        <Badge variant="outline" className="border-border bg-raised font-normal text-text-2" aria-label="Onda 2 del piano di migrazione, residua consegnata in 16.8">W2</Badge>
        {months.length > 0 ? (
          <div className="ml-auto">
            <Select value={selected} onValueChange={(v) => { setMonth(v) }}>
              <SelectTrigger className="h-9 w-[190px]" aria-label="Mese del report SLA (solo mesi con ticket reali)">
                <SelectValue placeholder="Mese" />
              </SelectTrigger>
              <SelectContent>
                {months.map((m) => (
                  <SelectItem key={m} value={m}>{monthLabel(m)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ) : null}
      </div>
      <p className="mt-0.5 text-xs text-text-2">
        Coorte dei ticket del mese selezionato (dati REALI del DB): tempi di prima risposta e
        risoluzione calcolati solo dove i campi esistono — «n.d.» dichiarato altrove, nessun
        tempo stimato.
      </p>

      {sla.isPending ? (
        <div role="status" aria-busy="true" className="mt-3 h-40 animate-pulse rounded-lg bg-surface">
          <span className="sr-only">Caricamento report SLA</span>
        </div>
      ) : sla.isError ? (
        <ErrorPanel
          className="mt-3"
          message={errInfo(sla.error).message}
          code={errInfo(sla.error).code}
          onRetry={() => { void sla.refetch() }}
        />
      ) : !d || !sla.data ? (
        <EmptyState className="mt-3" title="Report SLA non disponibile" description="Il report SLA non ha restituito dati." />
      ) : d.months.length === 0 ? (
        <EmptyState
          className="mt-3"
          icon={<FileText className="size-10" aria-hidden />}
          title="Nessun mese con ticket"
          description="Il DB reale non ha ticket: nessuna coorte mensile da analizzare. Il report SLA si popolerà con i primi ticket reali."
        />
      ) : (
        <SlaReportBody d={d} ts={sla.data.asOf} />
      )}
    </section>
  )
}

/** Corpo del report SLA del mese selezionato (solo dati reali del payload). */
function SlaReportBody({ d, ts }: { d: SlaReport; ts: number }) {
  const timeRows: Array<{ label: string; resp: number | null; reso: number | null }> = [
    { label: 'Mediana', resp: d.responseTime.medianMin, reso: d.resolutionTime.medianMin },
    { label: 'Media', resp: d.responseTime.avgMin, reso: d.resolutionTime.avgMin },
    { label: 'Minimo', resp: d.responseTime.minMin, reso: d.resolutionTime.minMin },
    { label: 'Massimo', resp: d.responseTime.maxMin, reso: d.resolutionTime.maxMin },
  ]
  const noCompliance = d.slaCompliance.response.evaluated === 0 && d.slaCompliance.resolution.evaluated === 0

  const exportHistory = () => {
    if (d.history.length === 0) {
      toast.info('Nessun mese nello storico SLA', { description: 'Lo storico reale non ha righe da esportare.' })
      return
    }
    downloadCsv(
      `falco-sla-storico-${fileStamp()}.csv`,
      ['Mese', 'Ticket creati', 'Ticket chiusi', 'Prima risposta misurata', 'Risoluzioni misurate', 'In SLA risposta', 'In SLA risoluzione'],
      d.history.map((h) => [
        monthLabel(h.month), String(h.created), String(h.closed),
        String(h.responseMeasured), String(h.resolutionMeasured),
        String(h.responseInSla), String(h.resolutionInSla),
      ]),
    )
    toast.success(`CSV esportato: ${fmtNumber(d.history.length)} mesi (storico SLA, dati reali del DB)`)
  }

  return (
    <>
      {/* Striscia KPI (valori reali della coorte del mese) */}
      <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <SlaKpi
          label="Ticket della coorte"
          value={fmtNumber(d.tickets.created)}
          sub={`aperti nel mese · totali nel mese: ${fmtNumber(d.tickets.total)}`}
        />
        <SlaKpi label="Chiusi nel mese" value={fmtNumber(d.tickets.closed)} sub="ticket chiusi nella finestra del mese" />
        <SlaKpi
          label="Prima risposta (misurata)"
          value={fmtMin(d.responseTime.medianMin)}
          dim={d.responseTime.measured === 0}
          sub={d.responseTime.measured === 0
            ? `${fmtNumber(d.responseTime.measured)} ticket con firstResponseAt: tempi «n.d.»`
            : `mediana · media ${fmtMin(d.responseTime.avgMin)} · su ${fmtNumber(d.responseTime.measured)} ticket`}
        />
        <SlaKpi
          label="Risoluzione (misurata)"
          value={fmtMin(d.resolutionTime.medianMin)}
          dim={d.resolutionTime.measured === 0}
          sub={d.resolutionTime.measured === 0
            ? `${fmtNumber(d.resolutionTime.measured)} ticket con resolvedAt: tempi «n.d.»`
            : `mediana · media ${fmtMin(d.resolutionTime.avgMin)} · su ${fmtNumber(d.resolutionTime.measured)} ticket`}
        />
        <SlaKpi
          label="Conformità risposta (in SLA / valutati)"
          value={`${fmtNumber(d.slaCompliance.response.inSla)}/${fmtNumber(d.slaCompliance.response.evaluated)}`}
          dim={noCompliance}
          sub={`risoluzione: ${fmtNumber(d.slaCompliance.resolution.inSla)}/${fmtNumber(d.slaCompliance.resolution.evaluated)}${noCompliance ? ' — nessun ticket valutabile (nota D19 sotto)' : ''}`}
        />
      </div>

      {/* Nota onesta: copertura REALE dei campi SLA + nota D19 dal payload */}
      <div className="mt-3 rounded-lg border border-border/70 bg-raised/40 px-3 py-2.5" role="note" aria-label="Copertura dichiarata dei campi SLA reali del DB">
        <div className="flex items-start gap-2.5">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-text-2" aria-hidden />
          <div className="grid min-w-0 gap-1 text-xs text-text-2">
            <p>
              Campi SLA reali del DB: firstResponseAt{' '}
              <strong className="num">{fmtNumber(d.responseTime.measured)}/{fmtNumber(d.tickets.total)}</strong>, slaResponseDueAt{' '}
              <strong className="num">{fmtNumber(d.slaCompliance.response.evaluated)}/{fmtNumber(d.tickets.total)}</strong>, slaResolutionDueAt{' '}
              <strong className="num">{fmtNumber(d.slaCompliance.resolution.evaluated)}/{fmtNumber(d.tickets.total)}</strong>, SLADefinition{' '}
              <strong className="num">{fmtNumber(d.slaCompliance.slaDefinitions)}</strong> (D19).
            </p>
            <p className="text-dim">{d.slaCompliance.note}</p>
          </div>
        </div>
      </div>

      {/* Tempi reali (tabella): «n.d.» quando la misura non esiste */}
      <Card className="mt-3 border-border/70 bg-surface">
        <CardContent className="p-4 sm:p-6">
          <div className="mb-3 grid gap-1 text-xs text-text-2">
            <p>
              Mese analizzato: <strong className="num">{monthLabel(d.month)}</strong> · finestra:{' '}
              <span className="num">{fmtDateTimeFull(d.windowFrom)}</span> → <span className="num">{fmtDateTimeFull(d.windowTo)}</span>
            </p>
            <p>{d.responseTime.coverage}</p>
            <p>{d.resolutionTime.coverage}</p>
          </div>
          <Table>
            <TableCaption>
              Tempi reali dai campi del DB · «n.d.» = misura non disponibile (mai 0 per mancanza dato)
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Statistica</TableHead>
                <TableHead className="text-right">Prima risposta</TableHead>
                <TableHead className="text-right">Risoluzione</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {timeRows.map((r) => (
                <TableRow key={r.label}>
                  <TableCell className="font-medium">{r.label}</TableCell>
                  <TableCell className={cn('num text-right', r.resp == null ? 'text-dim' : 'text-text-2')}>{fmtMin(r.resp)}</TableCell>
                  <TableCell className={cn('num text-right', r.reso == null ? 'text-dim' : 'text-text-2')}>{fmtMin(r.reso)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <p className="mt-2 text-[11px] leading-relaxed text-dim">
            Tempo totale in pausa SLA (slaPausedMinutes): {fmtMin(d.resolutionTime.pausedMinutesTotal)} · escalation:
            livello massimo {fmtNumber(d.escalation.maxLevel)}, ticket escalati {fmtNumber(d.escalation.ticketsEscalated)}.
          </p>
        </CardContent>
      </Card>

      {/* Storico SLA (tabella + export CSV client-side) */}
      <Card className="mt-3 border-border/70 bg-surface">
        <CardContent className="p-4 sm:p-6">
          <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-medium">Storico SLA</p>
              <p className="mt-0.5 text-xs text-text-2">
                Un rigo per ogni mese con ticket reali ({fmtNumber(d.history.length)} mesi); «In SLA» è
                conteggiato solo dove i campi target esistono (D19).
              </p>
            </div>
            <Button variant="outline" size="sm" className="h-9 shrink-0" onClick={exportHistory} disabled={d.history.length === 0}>
              <Download className="size-3.5" aria-hidden />
              Scarica CSV
            </Button>
          </div>
          {d.history.length === 0 ? (
            <p className="rounded-md border border-dashed border-border px-3 py-4 text-xs text-text-2">
              Nessun mese nello storico: il DB reale ha ticket solo nel mese corrente.
            </p>
          ) : (
            <div className="max-h-96 overflow-y-auto scroll-thin [&_[data-slot=table-container]]:overflow-x-visible" role="region" aria-label="Storico SLA per mese, tabella scorribile" tabIndex={0}>
              <Table>
                <TableCaption>
                  Report SLA storico · un rigo per mese con ticket reali · «In SLA» valutato solo dove i campi target esistono (D19)
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[130px]">Mese</TableHead>
                    <TableHead className="text-right">Creati</TableHead>
                    <TableHead className="text-right">Chiusi</TableHead>
                    <TableHead className="text-right">Prima risposta misurata</TableHead>
                    <TableHead className="text-right">Risoluzioni misurate</TableHead>
                    <TableHead className="text-right">In SLA risposta</TableHead>
                    <TableHead className="text-right">In SLA risoluzione</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {d.history.map((h) => (
                    <TableRow key={h.month}>
                      <TableCell className="font-medium">{monthLabel(h.month)}</TableCell>
                      <TableCell className="num text-right">{fmtNumber(h.created)}</TableCell>
                      <TableCell className="num text-right">{fmtNumber(h.closed)}</TableCell>
                      <TableCell className="num text-right">{fmtNumber(h.responseMeasured)}</TableCell>
                      <TableCell className="num text-right">{fmtNumber(h.resolutionMeasured)}</TableCell>
                      <TableCell className="num text-right">{fmtNumber(h.responseInSla)}</TableCell>
                      <TableCell className="num text-right">{fmtNumber(h.resolutionInSla)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Distribuzione della coorte (conteggi reali) */}
      <Card className="mt-3 border-border/70 bg-surface">
        <CardContent className="p-4 sm:p-6">
          <p className="text-sm font-medium">Distribuzione della coorte</p>
          <p className="mt-0.5 text-xs text-text-2">Conteggi reali dei ticket del mese per stato, priorità e sorgente.</p>
          <div className="mt-3 grid gap-4 md:grid-cols-3">
            <DistGroup title="Stato" items={d.tickets.byStatus.map((x) => ({ label: TICKET_STATUS_LABELS[x.status] ?? x.status, count: x.count }))} />
            <DistGroup title="Priorità" items={d.tickets.byPriority.map((x) => ({ label: TICKET_PRIORITY_LABELS[x.priority] ?? x.priority, count: x.count }))} />
            <DistGroup title="Sorgente" items={d.tickets.bySource.map((x) => ({ label: TICKET_SOURCE_LABELS[x.source] ?? x.source, count: x.count }))} />
          </div>
          <AsOf ts={ts} className="mt-4" />
        </CardContent>
      </Card>
    </>
  )
}

function SlaKpi({ label, value, sub, dim }: { label: string; value: string; sub?: string; dim?: boolean }) {
  return (
    <Card className="border-border/70 bg-surface">
      <CardContent className="p-4">
        <p className="text-xs text-text-2">{label}</p>
        <p className={cn('num mt-1 text-lg font-semibold', dim && 'text-dim')}>{value}</p>
        {sub ? <p className="mt-1 text-[11px] leading-relaxed text-dim">{sub}</p> : null}
      </CardContent>
    </Card>
  )
}

function DistGroup({ title, items }: { title: string; items: Array<{ label: string; count: number }> }) {
  return (
    <div>
      <p className="text-xs font-medium text-text-2">Ticket per {title.toLowerCase()}</p>
      {items.length === 0 ? (
        <p className="mt-1.5 text-[11px] text-dim">nessun ticket nella coorte</p>
      ) : (
        <ul className="mt-1.5 flex flex-wrap gap-1.5">
          {items.map((i) => (
            <li key={i.label}>
              <Badge variant="outline" className="num border-border bg-raised font-normal text-text-2">
                {i.label}: {fmtNumber(i.count)}
              </Badge>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

/* ================================================================
 * 16.8 (W2 residua) — Sezione «Report pianificati»
 * CRUD REALE sulle pianificazioni (modello ScheduledReport del DB):
 * creazione (POST), attivazione/sospensione (PATCH enabled),
 * eliminazione (DELETE con conferma). Il motore di schedulazione NON
 * gira in riproduzione: la stringa honesty del payload è mostrata
 * intera nel banner (D2); nextRunAt è una proiezione calcolata, mai
 * eseguita; runCount/lastRunAt dichiarati («mai eseguito»).
 * ================================================================ */

function ScheduledReportsSection() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<ScheduledReportRow | null>(null)

  const page = useQuery({
    queryKey: ['scheduled-reports'],
    queryFn: () => api.scheduledReports(),
    staleTime: 30_000,
  })

  /* Attivazione/sospensione: PATCH { enabled } → riga reale aggiornata. */
  const toggle = useMutation({
    mutationFn: (v: { id: string; enabled: boolean }) => api.updateScheduledReport(v.id, { enabled: v.enabled }),
    onSuccess: (row, vars) => {
      toast.success(vars.enabled ? 'Report attivato' : 'Report sospeso', {
        description: `«${row.name}» — stato salvato nel DB reale. Le esecuzioni restano a 0 finché il motore non è attivo (D2).`,
      })
      void queryClient.invalidateQueries({ queryKey: ['scheduled-reports'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Aggiornamento non riuscito', { description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}` })
    },
  })

  /* Eliminazione: DELETE con conferma; artefatti rimossi dichiarati. */
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteScheduledReport(id),
    onSuccess: (res) => {
      toast.success('Report pianificato eliminato', {
        description: `Rimosso dal DB reale. Artefatti rimossi: ${fmtNumber(res.removedArtifacts)} (0 attesi in riproduzione, D2).`,
      })
      setDeleteTarget(null)
      void queryClient.invalidateQueries({ queryKey: ['scheduled-reports'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Eliminazione non riuscita', { description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}` })
    },
  })

  const items = page.data?.data.items ?? []
  const honesty = page.data?.data.honesty

  return (
    <section aria-labelledby="scheduled-reports" className="mt-8">
      <div className="flex flex-wrap items-center gap-2">
        <h2 id="scheduled-reports" className="text-sm font-semibold">Report pianificati</h2>
        <Badge variant="outline" className="border-border bg-raised font-normal text-text-2" aria-label="Onda 2 del piano di migrazione, residua consegnata in 16.8">W2</Badge>
        <div className="ml-auto">
          <Button size="sm" className="h-9" onClick={() => setCreateOpen(true)} aria-haspopup="dialog">
            <Plus className="size-3.5" aria-hidden />
            Pianifica report
          </Button>
        </div>
      </div>
      <p className="mt-0.5 text-xs text-text-2">
        Pianificazioni REALI salvate nel DB (frequenza, orario, canali, destinatari, sezioni):
        creazione, attivazione/sospensione ed eliminazione attive adesso; l&apos;invio vero richiede
        il motore di produzione.
      </p>

      {page.isPending ? (
        <div role="status" aria-busy="true" className="mt-3 h-40 animate-pulse rounded-lg bg-surface">
          <span className="sr-only">Caricamento report pianificati</span>
        </div>
      ) : page.isError ? (
        <ErrorPanel
          className="mt-3"
          message={errInfo(page.error).message}
          code={errInfo(page.error).code}
          onRetry={() => { void page.refetch() }}
        />
      ) : (
        <>
          {honesty ? (
            <div role="note" className="mt-3 flex items-start gap-3 rounded-lg border border-warn/40 bg-warn-soft px-4 py-3">
              <TriangleAlert className="mt-0.5 size-5 shrink-0 text-warn" aria-hidden />
              <div className="min-w-0">
                <p className="text-sm font-medium text-warn">Dichiarazione del server (onestà D2)</p>
                <p className="mt-0.5 text-xs leading-relaxed text-text-2">{honesty}</p>
              </div>
            </div>
          ) : null}

          {items.length === 0 ? (
            <EmptyState
              className="mt-3"
              icon={<CalendarClock className="size-10" aria-hidden />}
              title="Nessun report pianificato"
              description="Il DB reale parte da 0: la prima pianificazione arriva dalla creazione con «Pianifica report». Nessuna riga di esempio."
              action={
                <Button variant="outline" size="sm" className="h-9" onClick={() => setCreateOpen(true)} aria-haspopup="dialog">
                  <Plus className="size-3.5" aria-hidden />
                  Pianifica il primo report
                </Button>
              }
            />
          ) : (
            <Card className="mt-3 border-border/70 bg-surface">
              <CardContent className="p-4 sm:p-6">
                <div className="max-h-96 overflow-y-auto scroll-thin [&_[data-slot=table-container]]:overflow-x-visible" role="region" aria-label="Report pianificati, tabella scorribile" tabIndex={0}>
                  <Table>
                    <TableCaption>
                      {fmtNumber(items.length)} pianificazioni reali del DB · la prossima esecuzione è una proiezione
                      calcolata, non eseguita · «mai eseguito» = runCount 0 reale
                    </TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="min-w-[170px]">Report</TableHead>
                        <TableHead className="min-w-[150px]">Frequenza</TableHead>
                        <TableHead>Canali</TableHead>
                        <TableHead className="min-w-[130px]">Destinatari</TableHead>
                        <TableHead className="min-w-[150px]">Sezioni</TableHead>
                        <TableHead>Attivo</TableHead>
                        <TableHead className="min-w-[140px]">Prossima esecuzione</TableHead>
                        <TableHead className="min-w-[120px]">Esecuzioni</TableHead>
                        <TableHead className="w-10">Azioni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell className="max-w-[220px]">
                            <p className="truncate font-medium" title={r.name}>{r.name}</p>
                            <p className="text-[11px] text-dim">creato il {fmtDateTime(r.createdAt)}</p>
                          </TableCell>
                          <TableCell>
                            <p>{FREQ_LABELS[r.frequency] ?? r.frequency}</p>
                            <p className="text-[11px] text-dim">{freqDetail(r)}</p>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {r.channels.map((c) => (
                                <Badge key={c} variant="outline" className="border-border bg-raised font-normal text-text-2">
                                  {CHANNEL_LABELS[c] ?? c}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[180px]" title={r.recipients.length > 0 ? r.recipients.join(', ') : 'nessun destinatario'}>
                            <span className="num font-medium">{fmtNumber(r.recipients.length)}</span>
                            {r.recipients.length > 0 ? (
                              <p className="truncate text-[11px] text-dim">{r.recipients.join(', ')}</p>
                            ) : (
                              <p className="text-[11px] text-dim">nessuno</p>
                            )}
                          </TableCell>
                          <TableCell className="max-w-[240px] whitespace-normal">
                            <div className="flex flex-wrap gap-1">
                              {r.includeSections.map((s) => (
                                <Badge key={s} variant="outline" className="border-border bg-raised font-normal text-text-2">
                                  {SECTION_LABELS[s] ?? s}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={r.enabled}
                              disabled={toggle.isPending}
                              onCheckedChange={(v) => { toggle.mutate({ id: r.id, enabled: v === true }) }}
                              aria-label={r.enabled ? `Sospendi il report «${r.name}»` : `Attiva il report «${r.name}»`}
                            />
                          </TableCell>
                          <TableCell>
                            <p className="num">{r.nextRunAt != null ? fmtDateTime(r.nextRunAt) : 'n.d.'}</p>
                            <p className="text-[11px] text-dim">proiezione, non eseguita</p>
                          </TableCell>
                          <TableCell>
                            <p className="num">{fmtNumber(r.runCount)}</p>
                            <p className="text-[11px] text-dim">{r.lastRunAt != null ? fmtDateTime(r.lastRunAt) : 'mai eseguito'}</p>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-crit-text hover:text-crit-text"
                              aria-label={`Elimina il report pianificato «${r.name}»`}
                              onClick={() => setDeleteTarget(r)}
                              disabled={remove.isPending}
                            >
                              <Trash2 className="size-4" aria-hidden />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {page.data ? <AsOf ts={page.data.asOf} className="mt-4" /> : null}
              </CardContent>
            </Card>
          )}
        </>
      )}

      <CreateScheduledReportDialog open={createOpen} onOpenChange={setCreateOpen} />

      {/* Conferma eliminazione (focus trap gestito da Radix AlertDialog) */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !remove.isPending) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Elimina report pianificato</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Confermi l&apos;eliminazione di «{deleteTarget?.name}»? La pianificazione viene rimossa
              dal DB reale insieme ai suoi artefatti; l&apos;azione è registrata nell&apos;audit del server.
              In riproduzione gli artefatti sono 0 (D2): la rimozione riguarderà solo la
              pianificazione.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-crit-solid text-white hover:bg-crit-solid/90"
              disabled={remove.isPending}
              onClick={(e) => {
                e.preventDefault() /* resta aperto finché la risposta reale non arriva */
                if (!deleteTarget || remove.isPending) return
                remove.mutate(deleteTarget.id)
              }}
            >
              {remove.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Trash2 className="size-4" aria-hidden />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  )
}

/* ---------------- Dialog «Pianifica report» (creazione reale) ----------------
 * Validazione client leggera (campi obbligatori, e-mail per riga,
 * max 20 destinatari): l'autorità resta il backend, i cui errori 422
 * (es. BAD_FREQUENCY) sono mostrati nel toast di errore.
 * ------------------------------------------------------------------------- */

function CreateScheduledReportDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const queryClient = useQueryClient()

  const [name, setName] = useState('')
  const [frequency, setFrequency] = useState<'HOURLY' | 'DAILY' | 'WEEKLY' | 'MONTHLY'>('DAILY')
  const [hourText, setHourText] = useState('08')
  const [dayOfWeek, setDayOfWeek] = useState('1')
  const [dayOfMonthText, setDayOfMonthText] = useState('1')
  const [channels, setChannels] = useState<ChannelOption[]>([])
  const [sections, setSections] = useState<SectionOption[]>([])
  const [recipientsText, setRecipientsText] = useState('')
  const [formError, setFormError] = useState<string | null>(null)

  const create = useMutation({
    mutationFn: (input: CreateScheduledReportInput) => api.createScheduledReport(input),
    onSuccess: (_data, vars) => {
      toast.success('Report pianificato', {
        description: `«${vars.name.slice(0, 60)}${vars.name.length > 60 ? '…' : ''}» — salvato nel DB reale con audit. Il motore non esegue in riproduzione (D2): runCount resterà 0 finché non arriva il motore di produzione.`,
      })
      resetForm()
      onOpenChange(false)
      void queryClient.invalidateQueries({ queryKey: ['scheduled-reports'] })
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Pianificazione non riuscita', { description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}` })
    },
  })

  const resetForm = () => {
    setName('')
    setFrequency('DAILY')
    setHourText('08')
    setDayOfWeek('1')
    setDayOfMonthText('1')
    setChannels([])
    setSections([])
    setRecipientsText('')
    setFormError(null)
  }

  const submit = () => {
    /* Validazione client leggera: l'autorità è il backend (422 espliciti). */
    const n = name.trim()
    if (n.length < 2 || n.length > 80) { setFormError('Il nome richiede da 2 a 80 caratteri.'); return }
    const hour = Number(hourText)
    if (!Number.isInteger(hour) || hour < 0 || hour > 23) { setFormError('L\'ora deve essere un numero intero tra 0 e 23.'); return }
    if (frequency === 'MONTHLY') {
      const dom = Number(dayOfMonthText)
      if (!Number.isInteger(dom) || dom < 1 || dom > 31) { setFormError('Il giorno del mese deve essere un numero intero tra 1 e 31.'); return }
    }
    if (channels.length === 0) { setFormError('Seleziona almeno un canale (e-mail, Telegram o PDF).'); return }
    const recipients = recipientsText.split('\n').map((l) => l.trim()).filter((l) => l.length > 0)
    if (recipients.length > 20) { setFormError('Massimo 20 destinatari (uno per riga).'); return }
    const invalid = recipients.filter((r) => !EMAIL_RE.test(r))
    if (invalid.length > 0) {
      setFormError(`Destinatario non valido: ${invalid.slice(0, 2).join(', ')}${invalid.length > 2 ? '…' : ''} — una e-mail per riga.`)
      return
    }
    if (sections.length === 0) { setFormError('Seleziona almeno una sezione del report.'); return }
    setFormError(null)
    create.mutate({
      name: n,
      frequency,
      hour,
      dayOfWeek: frequency === 'WEEKLY' ? Number(dayOfWeek) : undefined,
      dayOfMonth: frequency === 'MONTHLY' ? Number(dayOfMonthText) : undefined,
      channels,
      recipients,
      includeSections: sections,
    })
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o && !create.isPending) { onOpenChange(false); resetForm() }
        else if (o) onOpenChange(true)
      }}
    >
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Pianifica report</DialogTitle>
          <DialogDescription className="text-left leading-relaxed">
            Crea una pianificazione REALE nel DB (audit REPORT_SCHEDULED_CREATE): frequenza, orario,
            canali, destinatari e sezioni. Il backend valida tutto con errori espliciti; in
            riproduzione il motore non esegue (D2).
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          {formError ? (
            <p role="alert" className="rounded-md border border-crit/40 bg-crit-soft px-3 py-2 text-xs text-crit-text">
              {formError}
            </p>
          ) : null}

          <div className="grid gap-1.5">
            <label htmlFor="sched-name" className="text-xs font-medium text-text-2">
              Nome (2–80 caratteri)
            </label>
            <Input
              id="sched-name"
              value={name}
              maxLength={80}
              onChange={(e) => setName(e.target.value)}
              placeholder="es. Report SLA mensile direzione"
              aria-required="true"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <label htmlFor="sched-freq" className="text-xs font-medium text-text-2">Frequenza</label>
              <Select value={frequency} onValueChange={(v) => { setFrequency(v as 'HOURLY' | 'DAILY' | 'WEEKLY' | 'MONTHLY') }}>
                <SelectTrigger id="sched-freq" aria-label="Frequenza della pianificazione" className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HOURLY">Oraria</SelectItem>
                  <SelectItem value="DAILY">Giornaliera</SelectItem>
                  <SelectItem value="WEEKLY">Settimanale</SelectItem>
                  <SelectItem value="MONTHLY">Mensile</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <label htmlFor="sched-hour" className="text-xs font-medium text-text-2">Ora (0–23)</label>
              <Input
                id="sched-hour"
                type="number"
                min={0}
                max={23}
                step={1}
                value={hourText}
                onChange={(e) => setHourText(e.target.value)}
                className="h-9"
                aria-required="true"
              />
            </div>
          </div>

          {frequency === 'WEEKLY' ? (
            <div className="grid gap-1.5">
              <label htmlFor="sched-dow" className="text-xs font-medium text-text-2">Giorno della settimana</label>
              <Select value={dayOfWeek} onValueChange={setDayOfWeek}>
                <SelectTrigger id="sched-dow" aria-label="Giorno della settimana della pianificazione" className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {WEEKDAY_LABELS.map((w, i) => (
                    <SelectItem key={w} value={String(i)}>{w.charAt(0).toUpperCase() + w.slice(1)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-text-2">0 = domenica … 6 = sabato (come il contratto del server).</p>
            </div>
          ) : null}

          {frequency === 'MONTHLY' ? (
            <div className="grid gap-1.5">
              <label htmlFor="sched-dom" className="text-xs font-medium text-text-2">Giorno del mese (1–31)</label>
              <Input
                id="sched-dom"
                type="number"
                min={1}
                max={31}
                step={1}
                value={dayOfMonthText}
                onChange={(e) => setDayOfMonthText(e.target.value)}
                className="h-9"
                aria-required="true"
              />
              <p className="text-[11px] text-text-2">Il server rifiuta i valori fuori range con un errore esplicito.</p>
            </div>
          ) : null}

          <div className="grid gap-1.5">
            <span className="text-xs font-medium text-text-2">Canali (almeno uno)</span>
            <div className="flex flex-wrap gap-x-6 gap-y-2">
              {CHANNEL_OPTIONS.map((c) => (
                <div key={c} className="flex items-center gap-2">
                  <Checkbox
                    id={`sched-chan-${c}`}
                    checked={channels.includes(c)}
                    onCheckedChange={(v) => { setChannels((prev) => toggleIn(prev, c, v === true)) }}
                    aria-label={`Canale ${CHANNEL_LABELS[c]}`}
                  />
                  <label htmlFor={`sched-chan-${c}`} className="text-xs text-text-2">{CHANNEL_LABELS[c]}</label>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-1.5">
            <label htmlFor="sched-recipients" className="text-xs font-medium text-text-2">
              Destinatari (una e-mail per riga, max 20)
            </label>
            <Textarea
              id="sched-recipients"
              value={recipientsText}
              rows={3}
              maxLength={2000}
              onChange={(e) => setRecipientsText(e.target.value)}
              placeholder={'es.\nnome.cognome@azienda.it\ndirezione@azienda.it'}
              aria-describedby="sched-recipients-hint"
            />
            <p id="sched-recipients-hint" className="text-[11px] text-text-2">
              Puoi lasciare vuoto solo per pianificazioni con il solo canale PDF (nessun invio); il
              formato è validato qui e di nuovo dal server.
            </p>
          </div>

          <div className="grid gap-1.5">
            <span className="text-xs font-medium text-text-2">Sezioni del report (almeno una)</span>
            <div className="flex flex-wrap gap-x-6 gap-y-2">
              {SECTION_OPTIONS.map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <Checkbox
                    id={`sched-sec-${s}`}
                    checked={sections.includes(s)}
                    onCheckedChange={(v) => { setSections((prev) => toggleIn(prev, s, v === true)) }}
                    aria-label={`Sezione ${SECTION_LABELS[s]}`}
                  />
                  <label htmlFor={`sched-sec-${s}`} className="text-xs text-text-2">{SECTION_LABELS[s]}</label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" disabled={create.isPending} onClick={() => { onOpenChange(false); resetForm() }}>
            Annulla
          </Button>
          <Button disabled={create.isPending} onClick={submit}>
            {create.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Plus className="size-4" aria-hidden />}
            Crea pianificazione
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
