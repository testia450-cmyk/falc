/* ================================================================
 * FALCO-OS v16 — Vista «Telecamere» (§5, famiglia CAMERA/LPR/NVR)
 * Due sezioni in TAB (pattern della vista Rete, 16.3 additivo):
 *  · «Flussi»: stato apparati video e flusso RTSP dall'ULTIMO campione
 *    reale di cameraStreamAlive («Attivo» / «Fermo» / «n.d.» se mai
 *    campionato);
 *  · «Registro flussi»: serie cameraStreamAlive sulla finestra analizzata
 *    dichiarata dal server (uptime 24h/finestra, ultimo cambio stato,
 *    campioni, RTT) — zero campioni → «n.d.», MAI 0% inventato.
 * Filtro «Sede» condiviso (opzioni REALI da /api/v2/locations).
 * Nessun colore senza testo, nessun numero hardcoded: tutto da
 * /api/v2/cameras, /api/v2/cameras/streams e /api/v2/noc/summary.
 * Paginazione server-side; il filtro tipo è client-side (il backend
 * non filtra per tipo su questa rotta: nota onesta in UI).
 * ================================================================ */

'use client'

import { useEffect, useRef, useState } from 'react'
import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  ChevronLeft, ChevronRight, Eye, HelpCircle, Loader2, MoreHorizontal,
  RefreshCw, Search, Video, VideoOff,
} from 'lucide-react'

import { PageHeader } from '@/components/page-header'
import { KpiCard } from '@/components/kpi-card'
import { StatusBadge } from '@/components/status-badge'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { api, ApiError, type StreamRegistryRow } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { subscribeRealtime } from '@/lib/client/socket'
import { fmtDateTime, fmtNumber, fmtRelative, typeLabel } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Costanti vista ---------------- */

const PAGE_SIZE = 50
const REG_PAGE_SIZE = 25 // registro flussi (default dello schema v2)

type StreamFilterKey = 'all' | 'down' | 'unknown' | 'alive'
const STREAM_API: Record<StreamFilterKey, 'all' | 'down' | 'unknown' | 'alive'> = {
  all: 'all',
  down: 'down',
  unknown: 'unknown',
  alive: 'alive',
}
const STREAM_FILTERS: Array<{ value: StreamFilterKey; label: string }> = [
  { value: 'all', label: 'Tutti' },
  { value: 'down', label: 'Flusso fermo' },
  { value: 'unknown', label: 'Mai campionato' },
  { value: 'alive', label: 'Flusso attivo' },
]

type TypeFilterKey = 'all' | 'CAMERA' | 'LPR' | 'NVR'
const TYPE_FILTERS: Array<{ value: TypeFilterKey; label: string }> = [
  { value: 'all', label: 'Tutte' },
  { value: 'CAMERA', label: 'Telecamera' },
  { value: 'LPR', label: 'Telecamera LPR' },
  { value: 'NVR', label: 'NVR' },
]

/** Sede: 'all' = nessun filtro (valore vuoto non ammesso dal Select). */
const LOC_ALL = 'all'

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/** Uptime in percentuale con onestà §2: null → «n.d.» (zero campioni),
 *  MAI 0% per mancanza di dato — 0% è una misura REALE di flusso sempre
 *  fermo nella finestra (per questo fmtPct non è riusabile: manda a «n.d.»
 *  anche lo zero misurato). */
function fmtUptimePct(v: number | null | undefined): string {
  if (v == null) return 'n.d.'
  return `${v.toLocaleString('it-IT')}%`
}

/* ================================================================
 * TelecamereView
 * ================================================================ */

export default function TelecamereView() {
  const queryClient = useQueryClient()
  const openDevice = useApp((s) => s.openDevice)

  /* Tab attiva (pattern vista Rete, stato locale) */
  const [tab, setTab] = useState<'flussi' | 'registro'>('flussi')

  /* Filtri condivisi dai due tab (q inizializzato dal deep link ?q=) */
  const [streamKey, setStreamKey] = useState<StreamFilterKey>('all')
  const [locKey, setLocKey] = useState<string>(LOC_ALL)
  const [qInput, setQInput] = useState(() => useApp.getState().q ?? '')
  const [q, setQ] = useState(() => useApp.getState().q ?? '')
  const [page, setPage] = useState(1)
  const [regPage, setRegPage] = useState(1)

  /* Filtro tipo: client-side, solo tab «Flussi» */
  const [typeKey, setTypeKey] = useState<TypeFilterKey>('all')

  /* Ricerca testuale con debounce (300 ms): pagina 1 su entrambi i tab */
  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim())
      setPage(1)
      setRegPage(1)
    }, 300)
    return () => clearTimeout(t)
  }, [qInput])

  /* --- Dati --- */

  const summary = useQuery({
    queryKey: ['noc-summary'],
    queryFn: () => api.summary(),
    refetchInterval: 120_000,
    staleTime: 60_000,
  })
  /* importedAt della modalità riproduzione (chiave condivisa con AppShell) */
  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    refetchInterval: 60_000,
  })
  /* Sedi REALI per il filtro sede (chiave condivisa con la vista Rete) */
  const locations = useQuery({
    queryKey: ['map-locations'],
    queryFn: () => api.locations(),
    staleTime: 60_000,
  })

  const locationId = locKey === LOC_ALL ? undefined : locKey

  const cameras = useQuery({
    queryKey: ['cameras', streamKey, q, locKey, page],
    queryFn: async () => {
      const filters = {
        stream: STREAM_API[streamKey],
        q: q || undefined,
        locationId,
        page,
        pageSize: PAGE_SIZE,
      }
      const res = await api.cameras(filters)
      /* Pagina oltre l'ultima (dati ridotti da realtime/filtri): il backend
       * risponde con 0 righe ma con i totali reali → ripete l'ultima pagina.
       * La pagina mostrata è sempre quella dichiarata dal server (res.data.page). */
      if (res.data.items.length === 0 && res.data.page > 1 && res.data.page > res.data.pageCount) {
        return api.cameras({ ...filters, page: res.data.pageCount })
      }
      return res
    },
    placeholderData: keepPreviousData,
    staleTime: 15_000,
  })

  /* Registro flussi: caricato SOLO quando il tab è aperto (aggregazione
   * server-side onerosa sulla serie reale cameraStreamAlive). */
  const streams = useQuery({
    queryKey: ['cameras-streams', { q, stream: streamKey, locationId: locKey, page: regPage }],
    queryFn: async () => {
      const filters = {
        q: q || undefined,
        stream: streamKey === 'all' ? undefined : streamKey,
        locationId,
        page: regPage,
        pageSize: REG_PAGE_SIZE,
      }
      const res = await api.camerasStreams(filters)
      /* Pagina oltre l'ultima: stessa difesa del tab Flussi */
      if (res.data.items.length === 0 && res.data.page > 1 && res.data.page > res.data.pageCount) {
        return api.camerasStreams({ ...filters, page: res.data.pageCount })
      }
      return res
    },
    enabled: tab === 'registro',
    placeholderData: keepPreviousData,
    staleTime: 15_000,
  })

  const pageData = cameras.data?.data
  const rawItems = pageData?.items ?? []
  /* Filtro tipo: client-side sugli elementi della pagina (nota onesta in UI) */
  const items = typeKey === 'all' ? rawItems : rawItems.filter((c) => c.type === typeKey)
  const total = pageData?.total ?? 0
  const shownPage = pageData?.page ?? 1
  const pageCount = pageData?.pageCount ?? 1

  const regData = streams.data?.data
  const regItems = regData?.items ?? []
  const regTotal = regData?.total ?? 0
  const regShownPage = regData?.page ?? 1
  const regPageCount = regData?.pageCount ?? 1
  /* Finestra realmente analizzata, DICHIARATA dal server (può essere < di
   * quella richiesta: riduzione onesta per volume di campioni). */
  const regWindowHours = regData?.windowHours ?? null
  const winLabel = regWindowHours == null ? '…' : regWindowHours === 168 ? '7g' : `${regWindowHours}h`

  /* --- Realtime: refresh ogni 2 tick (nessun polling aggressivo) --- */
  const tickCount = useRef(0)
  useEffect(() => {
    const dispose = subscribeRealtime({
      onTick: () => {
        tickCount.current += 1
        if (tickCount.current % 2 === 0) {
          void queryClient.invalidateQueries({ queryKey: ['cameras'] })
          void queryClient.invalidateQueries({ queryKey: ['cameras-streams'] })
        }
      },
    })
    return dispose
  }, [queryClient])

  /* --- KPI (dal summary reale, famiglia CAMERA/LPR/NVR) --- */
  const cams = summary.data?.data.cameras
  const asOf = summary.data?.asOf
  const streamsAlive = cams != null ? cams.total - cams.streamDown - cams.streamUnknown : undefined

  const filtersBusy = cameras.isFetching || streams.isFetching

  return (
    <div>
      <PageHeader
        title="Telecamere"
        subtitle="Stato apparati video, flusso RTSP (metrica reale cameraStreamAlive) e registro flussi per sede"
        mode={summary.data?.mode}
        importedAt={health.data?.data.replay.importedAt}
      />

      {/* KPI: 5 card (dati reali del summary, con asOf) — comuni ai due tab */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <KpiCard
          label="Totale"
          value={cams?.total ?? '…'}
          asOf={asOf}
          definition="Apparati della famiglia video: telecamere, telecamere LPR e NVR (convenzione unica v2)."
        />
        <KpiCard
          label="Online"
          value={cams?.online ?? '…'}
          asOf={asOf}
          accent={cams ? (cams.online === cams.total ? 'ok' : 'none') : 'none'}
          definition="Apparati video con stato ONLINE derivato dal motore (autorità duale ping/SNMP)."
        />
        <KpiCard
          label="Flussi attivi"
          value={streamsAlive ?? '…'}
          asOf={asOf}
          accent={cams && streamsAlive === cams.total ? 'ok' : 'none'}
          definition="Totale meno flussi fermi meno mai campionati: ultimo campione reale di cameraStreamAlive attivo."
        />
        <KpiCard
          label="Flussi fermi"
          value={cams?.streamDown ?? '…'}
          asOf={asOf}
          accent={cams && cams.streamDown > 0 ? 'crit' : 'ok'}
          definition="Ultimo campione reale di cameraStreamAlive = 0: flusso RTSP giù all'ultimo controllo del motore."
        />
        <KpiCard
          label="Mai campionati"
          value={cams?.streamUnknown ?? '…'}
          asOf={asOf}
          accent={cams && cams.streamUnknown > 0 ? 'warn' : 'none'}
          definition="cameraStreamAlive mai raccolto: il flusso non è mai stato verificato dal motore (onesto, non «attivo»)."
        />
      </div>

      {/* Errore del summary: visibile ma non blocca le tabelle */}
      {summary.isError ? (
        <ErrorPanel
          className="mt-3"
          message={errInfo(summary.error).message}
          code={errInfo(summary.error).code}
          onRetry={() => void summary.refetch()}
        />
      ) : null}

      {/* Filtri condivisi dai due tab: ricerca, stato flusso, sede */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-[180px] flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-text-2" aria-hidden />
          <Input
            type="search"
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            placeholder="Cerca nome, IP, sede…"
            aria-label="Ricerca testuale tra le telecamere"
            className="pl-8"
          />
        </div>

        <Select
          value={streamKey}
          onValueChange={(v) => { setStreamKey(v as StreamFilterKey); setPage(1); setRegPage(1) }}
        >
          <SelectTrigger className="w-[160px]" aria-label="Filtro stato flusso RTSP">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STREAM_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={locKey} onValueChange={(v) => { setLocKey(v); setPage(1); setRegPage(1) }}>
          <SelectTrigger className="w-[190px]" aria-label="Filtro sede">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={LOC_ALL}>Tutte le sedi</SelectItem>
            {locations.data?.data.map((l) => (
              <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button
          variant="outline"
          className="h-11 sm:h-9"
          onClick={() => { void cameras.refetch(); void streams.refetch(); void summary.refetch() }}
          disabled={filtersBusy}
        >
          <RefreshCw className={cn('size-3.5', filtersBusy && 'animate-spin')} aria-hidden />
          Aggiorna
        </Button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v === 'registro' ? 'registro' : 'flussi')} className="mt-2">
        <TabsList aria-label="Sezioni della vista Telecamere">
          <TabsTrigger value="flussi">Flussi</TabsTrigger>
          <TabsTrigger value="registro">Registro flussi</TabsTrigger>
        </TabsList>

        {/* ---------------- Tab Flussi: tabella attuale ---------------- */}
        <TabsContent value="flussi" className="mt-2">
          {/* Filtro tipo client-side (solo questo tab) + nota onesta */}
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <Select
              value={typeKey}
              onValueChange={(v) => setTypeKey(v as TypeFilterKey)}
            >
              <SelectTrigger className="w-[160px]" aria-label="Filtro tipo apparato">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TYPE_FILTERS.map((f) => (
                  <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {cameras.isFetching && !cameras.isPending ? (
              <span className="flex items-center gap-1 text-xs text-text-2">
                <Loader2 className="size-3 animate-spin" aria-hidden />
                aggiornamento…
              </span>
            ) : null}
          </div>

          {typeKey !== 'all' ? (
            <p className="mb-2 text-xs text-text-2">
              Filtro tipo <span className="font-medium text-foreground">{typeLabel(typeKey)}</span> applicato alla pagina
              corrente: <span className="num">{fmtNumber(items.length)}</span> di{' '}
              <span className="num">{fmtNumber(rawItems.length)}</span> elementi della pagina (il tipo non è filtrabile
              lato server su questa rotta).
            </p>
          ) : null}

          {cameras.isPending ? (
            <LoadingRows rows={8} />
          ) : cameras.isError ? (
            <ErrorPanel
              message={errInfo(cameras.error).message}
              code={errInfo(cameras.error).code}
              onRetry={() => void cameras.refetch()}
            />
          ) : items.length === 0 ? (
            <EmptyState
              title="Nessuna telecamera con questi filtri"
              description="Prova a modificare ricerca, stato del flusso, tipo di apparato o sede."
            />
          ) : (
            <div
              className={cn(
                'overflow-hidden rounded-lg border border-border/70 bg-surface transition-opacity',
                cameras.isFetching && 'opacity-70',
              )}
              aria-busy={cameras.isFetching}
            >
              <TooltipProvider delayDuration={150}>
                <Table>
                  <TableCaption className="sr-only">
                    Telecamere: stato, tipo, indirizzo IP, sede, flusso RTSP, RTT, ultimo controllo e NVR di riferimento
                  </TableCaption>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead scope="col">Stato</TableHead>
                      <TableHead scope="col">Nome</TableHead>
                      <TableHead scope="col">Tipo</TableHead>
                      <TableHead scope="col">IP</TableHead>
                      <TableHead scope="col">Sede</TableHead>
                      <TableHead scope="col">Flusso RTSP</TableHead>
                      <TableHead scope="col">RTT</TableHead>
                      <TableHead scope="col">Ultimo controllo</TableHead>
                      <TableHead scope="col">NVR di riferimento</TableHead>
                      <TableHead scope="col">
                        <span className="sr-only">Azioni</span>
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((c) => (
                      <TableRow
                        key={c.id}
                        className="cursor-pointer"
                        onClick={() => openDevice(c.id)}
                        title={`Apri ${c.hostname}`}
                      >
                        <TableCell>
                          <div className="flex min-w-0 flex-col items-start gap-1">
                            {c.statusReason ? (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="inline-flex cursor-help">
                                    <StatusBadge status={c.uiStatus} size="xs" />
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent side="top" className="max-w-64 text-xs leading-relaxed">
                                  {c.statusReason}
                                </TooltipContent>
                              </Tooltip>
                            ) : (
                              <StatusBadge status={c.uiStatus} size="xs" />
                            )}
                            {/* v16.18 W19 — telecamera dichiarata «presenza» (ping) */}
                            {c.monitorMode === 'ping' ? (
                              <Badge
                                variant="outline"
                                className="h-4 gap-0.5 border-border bg-raised px-1.5 text-[10px] leading-none text-text-2"
                                title="monitoraggio presenza: online/offline"
                              >
                                ping
                              </Badge>
                            ) : null}
                          </div>
                        </TableCell>
                        <TableCell className="max-w-[220px]">
                          <button
                            type="button"
                            className="truncate text-left font-medium hover:text-link hover:underline"
                            onClick={(e) => { e.stopPropagation(); openDevice(c.id) }}
                            title={c.hostname}
                          >
                            {c.hostname}
                          </button>
                        </TableCell>
                        <TableCell className="text-xs text-text-2">{typeLabel(c.type)}</TableCell>
                        <TableCell className="num text-xs">{c.ip || 'n.d.'}</TableCell>
                        <TableCell className="max-w-[160px] truncate text-xs text-text-2" title={c.locationName ?? undefined}>
                          {c.locationName ?? 'n.d.'}
                        </TableCell>
                        <TableCell>
                          <StreamBadge alive={c.streamAlive} />
                        </TableCell>
                        <TableCell className="num text-xs">
                          {c.rttMs != null ? `${Math.round(c.rttMs)} ms` : 'n.d.'}
                        </TableCell>
                        <TableCell className="text-xs text-text-2">
                          {fmtRelative(c.lastStreamCheck)}
                        </TableCell>
                        <TableCell className="max-w-[160px] truncate text-xs text-text-2" title={c.nvrHostname ?? undefined}>
                          {c.nvrHostname ?? '—'}
                        </TableCell>
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-text-2 hover:text-foreground"
                                aria-label={`Azioni per ${c.hostname}`}
                              >
                                <MoreHorizontal className="size-4" aria-hidden />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openDevice(c.id)}>
                                <Eye className="size-3.5" aria-hidden />
                                Quick-look
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TooltipProvider>
            </div>
          )}

          {/* Paginazione tab Flussi */}
          {!cameras.isPending && !cameras.isError && total > 0 ? (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs text-text-2" aria-live="polite">
                Pagina <span className="num">{shownPage}</span> di <span className="num">{pageCount}</span> ·{' '}
                <span className="num">{fmtNumber(total)}</span> telecamere
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-11 sm:h-9"
                  disabled={shownPage <= 1 || cameras.isFetching}
                  onClick={() => setPage(shownPage - 1)}
                >
                  <ChevronLeft className="size-3.5" aria-hidden />
                  Precedente
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-11 sm:h-9"
                  disabled={shownPage >= pageCount || cameras.isFetching}
                  onClick={() => setPage(shownPage + 1)}
                >
                  Successiva
                  <ChevronRight className="size-3.5" aria-hidden />
                </Button>
              </div>
            </div>
          ) : null}
        </TabsContent>

        {/* ---------------- Tab Registro flussi (16.3) ---------------- */}
        <TabsContent value="registro" className="mt-2">
          {/* Nota onesta sulla finestra dichiarata dal server */}
          {regData ? (
            <p className="mb-2 text-xs text-text-2">
              Finestra analizzata:{' '}
              <span className="num font-medium text-foreground">{regWindowHours} h</span>
              {regWindowHours != null && regWindowHours < 168
                ? ' (finestra ridotta e dichiarata dal server: la serie completa supera il limite di carico)'
                : ''}
              . Uptime e ultimo cambio sono calcolati SOLO sui campioni reali presenti:{' '}
              «n.d.» = zero campioni nel periodo, «nessun cambio» = nessuna transizione osservata.
              <AsOf ts={streams.data?.asOf} prefix="· ultimo dato" className="ml-1" />
            </p>
          ) : null}

          {streams.isPending ? (
            <LoadingRows rows={8} />
          ) : streams.isError ? (
            <ErrorPanel
              message={errInfo(streams.error).message}
              code={errInfo(streams.error).code}
              onRetry={() => void streams.refetch()}
            />
          ) : regItems.length === 0 ? (
            <EmptyState
              title="Nessun apparato video nel registro con questi filtri"
              description="Prova a modificare ricerca, stato del flusso o sede: il registro copre telecamere, telecamere LPR e NVR."
            />
          ) : (
            <div
              className={cn(
                'overflow-hidden rounded-lg border border-border/70 bg-surface transition-opacity',
                streams.isFetching && 'opacity-70',
              )}
              aria-busy={streams.isFetching}
            >
              <Table>
                <TableCaption className="sr-only">
                  Registro flussi per apparato video: sede, stato del flusso, ultimo controllo, ultimo cambio stato,
                  uptime 24h e sulla finestra analizzata ({regWindowHours ?? '…'} ore), campioni e RTT — pagina{' '}
                  {regShownPage} di {regPageCount} su {fmtNumber(regTotal)} risultati totali
                </TableCaption>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead scope="col">Telecamera</TableHead>
                    <TableHead scope="col">Sede</TableHead>
                    <TableHead scope="col">Stato flusso</TableHead>
                    <TableHead scope="col">Ultimo controllo</TableHead>
                    <TableHead scope="col">Ultimo cambio stato</TableHead>
                    <TableHead scope="col">Uptime 24h</TableHead>
                    <TableHead scope="col">Uptime {winLabel}</TableHead>
                    <TableHead scope="col">Campioni</TableHead>
                    <TableHead scope="col">RTT</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {regItems.map((r) => (
                    <StreamRegistryRowView key={r.deviceId} row={r} onOpen={openDevice} />
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Paginazione registro (solo se più di una pagina) */}
          {!streams.isPending && !streams.isError && regTotal > REG_PAGE_SIZE ? (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs text-text-2" aria-live="polite">
                Pagina <span className="num">{regShownPage}</span> di <span className="num">{regPageCount}</span> su{' '}
                <span className="num">{fmtNumber(regTotal)}</span> risultati totali
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-11 sm:h-9"
                  disabled={regShownPage <= 1 || streams.isFetching}
                  onClick={() => setRegPage(regShownPage - 1)}
                >
                  <ChevronLeft className="size-3.5" aria-hidden />
                  Precedente
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-11 sm:h-9"
                  disabled={regShownPage >= regPageCount || streams.isFetching}
                  onClick={() => setRegPage(regShownPage + 1)}
                >
                  Successiva
                  <ChevronRight className="size-3.5" aria-hidden />
                </Button>
              </div>
            </div>
          ) : null}
        </TabsContent>
      </Tabs>
    </div>
  )
}

/* ================================================================
 * Sotto-componenti
 * ================================================================ */

/** Riga del registro flussi (tab «Registro flussi»). */
function StreamRegistryRowView({
  row, onOpen,
}: {
  row: StreamRegistryRow
  onOpen: (id: string) => void
}) {
  const noChangeTitle =
    'Nessuna transizione di cameraStreamAlive osservata nella finestra analizzata (o zero campioni)'
  return (
    <TableRow
      className="cursor-pointer"
      onClick={() => onOpen(row.deviceId)}
      title={`Apri ${row.hostname}`}
    >
      <TableCell className="max-w-[220px]">
        <button
          type="button"
          className="truncate text-left font-medium hover:text-link hover:underline"
          onClick={(e) => { e.stopPropagation(); onOpen(row.deviceId) }}
          title={row.hostname}
        >
          {row.hostname}
        </button>
      </TableCell>
      <TableCell className="max-w-[160px] truncate text-xs text-text-2" title={row.locationName ?? undefined}>
        {row.locationName ?? 'n.d.'}
      </TableCell>
      <TableCell>
        <StreamBadge alive={row.streamAlive} />
      </TableCell>
      <TableCell className="text-xs text-text-2">
        {fmtRelative(row.lastCheck)}
      </TableCell>
      <TableCell className="text-xs text-text-2" title={row.lastChange ? fmtDateTime(row.lastChange) : noChangeTitle}>
        {row.lastChange ? fmtDateTime(row.lastChange) : 'nessun cambio (finestra)'}
      </TableCell>
      <TableCell className="num text-xs">
        <span className={uptimeCls(row.uptime24h)}>{fmtUptimePct(row.uptime24h)}</span>
      </TableCell>
      <TableCell className="num text-xs">
        <span className={uptimeCls(row.uptime7d)}>{fmtUptimePct(row.uptime7d)}</span>
      </TableCell>
      <TableCell className="num text-xs text-text-2">{fmtNumber(row.samples)}</TableCell>
      <TableCell className="num text-xs">
        {row.rttMs != null ? `${Math.round(row.rttMs)} ms` : 'n.d.'}
      </TableCell>
    </TableRow>
  )
}

/** Colore dell'uptime SOLO con testo inequivocabile accanto (il valore
 *  numerico resta sempre visibile: il colore è rinforzo, mai l'unica
 *  informazione). null resta neutro («n.d.» NON è un problema, è un
 *  dato mancante: regola §2). */
function uptimeCls(v: number | null | undefined): string {
  if (v == null) return 'text-text-2'
  if (v < 50) return 'text-crit font-medium'
  if (v < 90) return 'text-warn'
  return ''
}

/** Flusso RTSP: icona + testo, mai solo colore (§4.2). */
function StreamBadge({ alive }: { alive: boolean | null }) {
  if (alive === true) {
    return (
      <Badge variant="outline" className="gap-1.5 border-ok/40 bg-ok-soft font-medium text-ok">
        <Video className="size-3.5" aria-hidden />
        Attivo
      </Badge>
    )
  }
  if (alive === false) {
    return (
      <Badge variant="outline" className="gap-1.5 border-crit/40 bg-crit-soft font-medium text-crit-text">
        <VideoOff className="size-3.5" aria-hidden />
        Fermo
      </Badge>
    )
  }
  return (
    <Badge variant="outline" className="gap-1.5 border-border bg-raised font-normal text-text-2" title="cameraStreamAlive mai campionato">
      <HelpCircle className="size-3.5" aria-hidden />
      n.d.
      <span className="sr-only">flusso mai campionato</span>
    </Badge>
  )
}
