/* ================================================================
 * FALCO-OS v16 — Vista «Allarmi» (§6.6)
 * Eventi di allarme REALI del motore esistente (alert-engine v15):
 * causa radice e soppressioni visibili, deduplicazione onesta
 * (occurrenceCount del DB), ACK con audit trail.
 * Nessun numero hardcoded: tutto arriva da /api/v2/alarms e
 * /api/v2/noc/summary (pagination server-side, ordinamento per
 * severità decrescente fatto dal backend).
 * 16.7 ondata W3.5: due tab — «Allarmi» (contenuto storico, qui
 * sotto intatto) e «Regole evento» (regole SYS:* del motore + regole
 * utente, in src/components/regole-evento.tsx per non far esplodere
 * questo file).
 * ================================================================ */

'use client'

import { useEffect, useRef, useState } from 'react'
import { useSession } from 'next-auth/react'
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  BellRing, ChevronDown, ChevronLeft, ChevronRight, CircleAlert, CircleCheck,
  Info, Loader2, Monitor, OctagonAlert, RefreshCw, Search, TrendingUp,
  TriangleAlert, UserCheck, VolumeX, type LucideIcon,
} from 'lucide-react'

import { PageHeader } from '@/components/page-header'
import { KpiCard } from '@/components/kpi-card'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import RegoleEventoSection from '@/components/regole-evento'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { CvePanel } from '@/components/cve-panel'
import { api, ApiError, type AlarmRow } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { subscribeRealtime } from '@/lib/client/socket'
import { fmtAgeMinutes, fmtDateTimeFull, fmtNumber, fmtTime, SEVERITY_META } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* ---------------- Costanti vista ---------------- */

const PAGE_SIZE = 25

type StatusFilterKey = 'open' | 'all' | 'closed' | 'suppressed'
const STATUS_FILTERS: Array<{ value: StatusFilterKey; label: string; api?: string }> = [
  { value: 'open', label: 'Aperti', api: 'OPEN,ACK,ESCALATED' }, // default
  { value: 'all', label: 'Tutti', api: undefined },
  { value: 'closed', label: 'Solo chiusi', api: 'CLOSED' },
  { value: 'suppressed', label: 'Soppressi', api: 'SUPPRESSED' },
]

type SeverityFilterKey = 'all' | 'CRITICAL' | 'HIGH' | 'AVERAGE' | 'WARNING'
const SEVERITY_FILTERS: Array<{ value: SeverityFilterKey; label: string; api?: string }> = [
  { value: 'all', label: 'Tutte', api: undefined },
  { value: 'CRITICAL', label: 'Critici', api: 'CRITICAL' },
  { value: 'HIGH', label: 'Alti', api: 'HIGH' },
  { value: 'AVERAGE', label: 'Medi', api: 'AVERAGE' },
  { value: 'WARNING', label: 'Attenzione', api: 'WARNING' },
]

/** Severità: icona + testo (mai solo colore, §4.2) */
const SEVERITY_ICONS: Record<string, LucideIcon> = {
  CRITICAL: OctagonAlert,
  HIGH: TriangleAlert,
  AVERAGE: CircleAlert,
  WARNING: CircleAlert,
  INFO: Info,
}

/** Stato allarme (vocabolario UI; lo stato è del motore, non ridefinito) */
const ALARM_STATUS_META: Record<string, { label: string; cls: string; Icon: LucideIcon }> = {
  OPEN: { label: 'Aperto', cls: 'bg-warn-soft text-warn border-warn/40', Icon: BellRing },
  ACK: { label: 'Preso in carico', cls: 'bg-info-soft text-info border-info/40', Icon: UserCheck },
  CLOSED: { label: 'Chiuso', cls: 'bg-raised text-text-2 border-border', Icon: CircleCheck },
  SUPPRESSED: { label: 'Soppresso', cls: 'bg-raised text-text-2 border-border', Icon: VolumeX },
  ESCALATED: { label: 'Escalato', cls: 'bg-crit-soft text-crit-text border-crit/40', Icon: TrendingUp },
}

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

/* ================================================================
 * AllarmiView
 * ================================================================ */

export default function AllarmiView() {
  const { data: session } = useSession()
  const queryClient = useQueryClient()
  const openDevice = useApp((s) => s.openDevice)
  const alarmIdFromUrl = useApp((s) => s.alarmId)

  /* Ruolo: il CLIENTE è in sola lettura (il backend resta l'autorità) */
  const role = session?.user?.role
  const canAck = !!role && role !== 'CLIENTE'

  /* Filtri (q inizializzato dal deep link ?q=, se presente) */
  const [statusKey, setStatusKey] = useState<StatusFilterKey>('open')
  const [severityKey, setSeverityKey] = useState<SeverityFilterKey>('all')
  const [qInput, setQInput] = useState(() => useApp.getState().q ?? '')
  const [q, setQ] = useState(() => useApp.getState().q ?? '')
  const [page, setPage] = useState(1)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [deepLinkApplied, setDeepLinkApplied] = useState(false)
  const [ackTarget, setAckTarget] = useState<AlarmRow | null>(null)
  const [ackNote, setAckNote] = useState('')

  /* Ricerca testuale con debounce (300 ms) sul messaggio */
  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim())
      setPage(1)
    }, 300)
    return () => clearTimeout(t)
  }, [qInput])

  /* --- Dati --- */

  const summary = useQuery({
    queryKey: ['noc-summary'],
    queryFn: () => api.summary(),
    refetchInterval: 120_000,
    staleTime: 60_000,
  })
  /* importedAt della modalità riproduzione (chiave condivisa con AppShell) */
  const health = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.systemHealth(),
    refetchInterval: 60_000,
  })

  const statusApi = STATUS_FILTERS.find((f) => f.value === statusKey)?.api
  const severityApi = SEVERITY_FILTERS.find((f) => f.value === severityKey)?.api

  const alarms = useQuery({
    queryKey: ['alarms', statusKey, severityKey, q, page],
    queryFn: async () => {
      const res = await api.alarms({
        status: statusApi,
        severity: severityApi,
        q: q || undefined,
        page,
        pageSize: PAGE_SIZE,
      })
      /* Pagina oltre l'ultima (dati ridotti da realtime/filtri): il backend
       * risponde con 0 righe ma con i totali reali → ripete l'ultima pagina.
       * La pagina mostrata è sempre quella dichiarata dal server (res.data.page). */
      if (res.data.items.length === 0 && res.data.page > 1 && res.data.page > res.data.pageCount) {
        return api.alarms({
          status: statusApi,
          severity: severityApi,
          q: q || undefined,
          page: res.data.pageCount,
          pageSize: PAGE_SIZE,
        })
      }
      return res
    },
    placeholderData: keepPreviousData,
    staleTime: 15_000,
  })

  const pageData = alarms.data?.data
  const items = pageData?.items ?? []
  const total = pageData?.total ?? 0
  const shownPage = pageData?.page ?? 1
  const pageCount = pageData?.pageCount ?? 1

  /* --- Realtime: nuovi allarmi → invalidate mirato + toast ---
   * (il toast arriva solo dopo il primo render e solo con eventi reali) */
  const firstRender = useRef(true)
  useEffect(() => { firstRender.current = false }, [])

  useEffect(() => {
    const dispose = subscribeRealtime({
      onAlarms: (updated) => {
        void queryClient.invalidateQueries({ queryKey: ['alarms'] })
        void queryClient.invalidateQueries({ queryKey: ['noc-summary'] })
        if (updated.length > 0 && !firstRender.current) {
          toast.info(`${fmtNumber(updated.length)} allarmi aggiornati`, {
            description: 'Nuovi eventi del motore: elenco e contatori ricalcolati.',
          })
        }
      },
    })
    return dispose
  }, [queryClient])

  /* --- Deep link ?alarm=ID: espanso appena visibile con i filtri correnti
   * (derivato durante il render; la prima interazione utente prende il posto
   * dell'espansione automatica, senza setState in effect) --- */
  const deepLinkExpanded = !deepLinkApplied
    && alarmIdFromUrl != null
    && items.some((a) => a.id === alarmIdFromUrl)
  const effectiveExpandedId = deepLinkExpanded ? alarmIdFromUrl : expandedId

  /* --- ACK (solo OPEN; conferma con AlertDialog; esito reale) --- */
  const ackMutation = useMutation({
    mutationFn: (v: { id: string; note?: string }) => api.ackAlarm(v.id, v.note),
    onSuccess: (row) => {
      toast.success('Allarme preso in carico', {
        description: `Stato ${row.status} · riconosciuto da ${row.acknowledgedBy ?? 'n.d.'}${row.acknowledgedAt ? ` alle ${fmtTime(row.acknowledgedAt)}` : ''}`,
      })
      setAckTarget(null)
      setAckNote('')
      void queryClient.invalidateQueries({ queryKey: ['alarms'] })
      void queryClient.invalidateQueries({ queryKey: ['noc-summary'] })
      void queryClient.invalidateQueries({ queryKey: ['device-overview'] }) // openAlerts nel quick-look
    },
    onError: (err) => {
      const e = errInfo(err)
      toast.error('Presa in carico non riuscita', {
        description: `${e.message}${e.code ? ` (codice ${e.code})` : ''}`,
      })
    },
  })

  /* --- KPI (dal summary reale) --- */
  const al = summary.data?.data.alarms
  const openCount = al?.open
  const criticalCount = al?.bySeverity.CRITICAL ?? 0
  const highCount = al?.bySeverity.HIGH ?? 0
  const asOf = summary.data?.asOf
  const openAccent = openCount == null ? 'none' : criticalCount > 0 ? 'crit' : openCount > 0 ? 'warn' : 'ok'

  return (
    <div>
      <PageHeader
        title="Allarmi"
        subtitle="Eventi di allarme reali del motore esistente, con causa radice e soppressioni visibili"
        mode={summary.data?.mode}
        importedAt={health.data?.data.replay.importedAt}
      />

      {/* Due tab (16.7 W3.5): «Allarmi» = contenuto storico intatto;
       * «Regole evento» = regole SYS:* + regole utente. La lista scorre
       * orizzontalmente su mobile (stesso pattern della vista
       * Operazioni); da sm in poi torna inline centrata. */}
      <Tabs defaultValue="eventi">
        <TabsList
          aria-label="Sezioni della vista Allarmi"
          className="w-full justify-start overflow-x-auto scroll-thin sm:w-fit sm:justify-center"
        >
          <TabsTrigger value="eventi" className="shrink-0">Allarmi</TabsTrigger>
          <TabsTrigger value="regole" className="shrink-0">Regole evento</TabsTrigger>
          <TabsTrigger value="cve" className="shrink-0">CVE</TabsTrigger>
        </TabsList>

        <TabsContent value="eventi" className="mt-4">
      {/* KPI strip: 4 card compatte, dati reali del summary */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {/* Contatore allarmi aperti: aria-live (i nuovi allarmi vengono annunciati) */}
        <div role="status" aria-live="polite">
          <KpiCard
            label="Aperti"
            value={openCount ?? '…'}
            asOf={asOf}
            accent={openAccent}
            definition="Allarmi con stato diverso da CLOSED: include aperti, presi in carico, escalati e soppressi (questi ultimi sono contati anche a parte)."
            foot={al ? <>di cui <span className="num font-medium text-foreground">{fmtNumber(al.suppressed)}</span> soppressi per causa radice</> : undefined}
          />
        </div>
        <KpiCard
          label="Critici + alti"
          value={al ? criticalCount + highCount : '…'}
          asOf={asOf}
          accent={al ? (criticalCount > 0 ? 'crit' : highCount > 0 ? 'warn' : 'ok') : 'none'}
          definition="Somma degli allarmi non chiusi con severità CRITICAL e HIGH."
          foot={al && criticalCount > 0 ? <>di cui <span className="num font-medium text-crit">{fmtNumber(criticalCount)}</span> critici</> : undefined}
        />
        <KpiCard
          label="Soppressi"
          value={al?.suppressed ?? '…'}
          asOf={asOf}
          definition="Soppressi dal motore RCA: allarme generato da un guasto a monte già segnalato da un altro allarme (causa radice identificata)."
        />
        <KpiCard
          label="Il più vecchio aperto da"
          value={al?.oldestOpenMinutes != null ? fmtAgeMinutes(al.oldestOpenMinutes) : al ? 'n.d.' : '…'}
          asOf={asOf}
          definition="Età dell'allarme non chiuso più vecchio dell'impianto (nessun allarme aperto → n.d.)."
        />
      </div>

      {/* Errore del summary: visibile ma non blocca l'elenco */}
      {summary.isError ? (
        <ErrorPanel
          className="mt-3"
          message={errInfo(summary.error).message}
          code={errInfo(summary.error).code}
          onRetry={() => void summary.refetch()}
        />
      ) : null}

      {/* Filtri */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Select
          value={statusKey}
          onValueChange={(v) => { setStatusKey(v as StatusFilterKey); setPage(1) }}
        >
          <SelectTrigger className="w-[150px]" aria-label="Filtro stato allarme">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STATUS_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={severityKey}
          onValueChange={(v) => { setSeverityKey(v as SeverityFilterKey); setPage(1) }}
        >
          <SelectTrigger className="w-[140px]" aria-label="Filtro severità">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SEVERITY_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="relative min-w-[180px] flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-text-2" aria-hidden />
          <Input
            type="search"
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            placeholder="Cerca nel messaggio…"
            aria-label="Ricerca testuale nel messaggio dell'allarme"
            className="pl-8"
          />
        </div>

        <Button
          variant="outline"
          className="h-9"
          onClick={() => { void alarms.refetch(); void summary.refetch() }}
          disabled={alarms.isFetching}
        >
          <RefreshCw className={cn('size-3.5', alarms.isFetching && 'animate-spin')} aria-hidden />
          Aggiorna
        </Button>
      </div>

      {/* Nota ordinamento (server-side, per gravità) */}
      <div className="mt-3 mb-2 flex items-center justify-between gap-2">
        <p className="text-xs text-text-2">Ordinati per gravità decrescente, poi i più recenti prima</p>
        {alarms.isFetching && !alarms.isPending ? (
          <span className="flex items-center gap-1 text-xs text-text-2">
            <Loader2 className="size-3 animate-spin" aria-hidden />
            aggiornamento…
          </span>
        ) : null}
      </div>

      {/* Elenco */}
      {alarms.isPending ? (
        <LoadingRows rows={6} />
      ) : alarms.isError ? (
        <ErrorPanel
          message={errInfo(alarms.error).message}
          code={errInfo(alarms.error).code}
          onRetry={() => void alarms.refetch()}
        />
      ) : items.length === 0 ? (
        statusKey === 'open' ? (
          <EmptyState
            icon={<CircleCheck className="size-10 text-ok" aria-hidden />}
            title="Nessun allarme aperto"
            description="Nessun allarme con stato aperto, preso in carico o escalato: nessun evento attivo del motore da segnalare."
          />
        ) : (
          <EmptyState
            title="Nessun allarme con questi filtri"
            description="Prova a modificare stato, severità o ricerca testuale."
          />
        )
      ) : (
        <div
          className={cn('space-y-2 transition-opacity', alarms.isFetching && 'opacity-70')}
          aria-busy={alarms.isFetching}
          aria-label="Elenco allarmi"
        >
          {items.map((a) => (
            <AlarmItem
              key={a.id}
              alarm={a}
              canAck={canAck}
              expanded={effectiveExpandedId === a.id}
              onToggleDetails={() => {
                if (!deepLinkApplied) setDeepLinkApplied(true)
                setExpandedId(effectiveExpandedId === a.id ? null : a.id)
              }}
              onAck={(alarm) => { setAckTarget(alarm); setAckNote('') }}
              onOpenDevice={openDevice}
            />
          ))}
        </div>
      )}

      {/* Paginazione */}
      {!alarms.isPending && !alarms.isError && total > 0 ? (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-text-2">
            Pagina <span className="num">{shownPage}</span> di <span className="num">{pageCount}</span> ·{' '}
            <span className="num">{fmtNumber(total)}</span> allarmi
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={shownPage <= 1 || alarms.isFetching}
              onClick={() => setPage(shownPage - 1)}
            >
              <ChevronLeft className="size-3.5" aria-hidden />
              Precedente
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-9"
              disabled={shownPage >= pageCount || alarms.isFetching}
              onClick={() => setPage(shownPage + 1)}
            >
              Successiva
              <ChevronRight className="size-3.5" aria-hidden />
            </Button>
          </div>
        </div>
      ) : null}

      {/* Conferma ACK (focus trap gestito da Radix AlertDialog) */}
      <AlertDialog
        open={!!ackTarget}
        onOpenChange={(open) => {
          if (!open && !ackMutation.isPending) {
            setAckTarget(null)
            setAckNote('')
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Prendi in carico l'allarme</AlertDialogTitle>
            <AlertDialogDescription className="text-left leading-relaxed">
              Confermi la presa in carico dell'allarme{' '}
              <strong className="text-foreground">
                {ackTarget ? (SEVERITY_META[ackTarget.severity]?.label ?? ackTarget.severity) : ''}
              </strong>{' '}
              su <strong className="text-foreground">{ackTarget?.deviceHostname ?? 'nessun dispositivo'}</strong>?{' '}
              L'azione registra chi, quando e una voce di audit.
            </AlertDialogDescription>
          </AlertDialogHeader>

          {ackTarget ? (
            <p className="line-clamp-3 break-words rounded-md bg-raised/50 px-3 py-2 text-xs text-text-2" title={ackTarget.message}>
              {ackTarget.message}
            </p>
          ) : null}

          <div className="grid gap-1.5">
            <label htmlFor="ack-note" className="text-xs font-medium text-text-2">
              Nota (opzionale, max 500 caratteri)
            </label>
            <Input
              id="ack-note"
              value={ackNote}
              maxLength={500}
              onChange={(e) => setAckNote(e.target.value)}
              placeholder="es. ticket assegnato, intervento programmato…"
            />
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel disabled={ackMutation.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              disabled={ackMutation.isPending}
              onClick={(e) => {
                e.preventDefault() // resta aperto finché la risposta reale non arriva
                if (!ackTarget || ackMutation.isPending) return
                ackMutation.mutate({ id: ackTarget.id, note: ackNote.trim() || undefined })
              }}
            >
              {ackMutation.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
              Prendi in carico
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
        </TabsContent>

        <TabsContent value="regole" className="mt-4">
          {/* Regole evento (16.7 W3.5): 10 SYS:* reali del DB egidio +
           * regole utente (0 ora: empty state onesto). */}
          <RegoleEventoSection />
        </TabsContent>
        <TabsContent value="cve" className="mt-4">
          {/* CVE (16.9 W4): catalogo importabile + scan REALE per pattern
           * brand/model/firmware sui 200 dispositivi del DB. */}
          <CvePanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}

/* ================================================================
 * Sotto-componenti
 * ================================================================ */

function AlarmSeverityBadge({ severity }: { severity: string }) {
  const meta = SEVERITY_META[severity] ?? { label: severity, cls: 'bg-info-soft text-info border-info/40' }
  const Icon = SEVERITY_ICONS[severity] ?? CircleAlert
  return (
    <Badge variant="outline" className={cn('gap-1.5 font-medium', meta.cls)}>
      <Icon className="size-3.5" aria-hidden />
      {meta.label}
    </Badge>
  )
}

function AlarmStatusBadge({ status }: { status: string }) {
  const meta = ALARM_STATUS_META[status] ?? { label: status, cls: 'bg-raised text-text-2 border-border', Icon: CircleAlert }
  return (
    <Badge variant="outline" className={cn('gap-1.5 font-medium', meta.cls)}>
      <meta.Icon className="size-3.5" aria-hidden />
      {meta.label}
    </Badge>
  )
}

function AlarmItem({
  alarm, canAck, expanded, onToggleDetails, onAck, onOpenDevice,
}: {
  alarm: AlarmRow
  canAck: boolean
  expanded: boolean
  onToggleDetails: () => void
  onAck: (alarm: AlarmRow) => void
  onOpenDevice: (id: string) => void
}) {
  const deviceId = alarm.deviceId // const: narrowing valido dentro le closure
  const detailsId = `alarm-details-${alarm.id}`
  const severityLabel = SEVERITY_META[alarm.severity]?.label ?? alarm.severity

  return (
    <article
      className="rounded-lg border border-border/70 bg-surface"
      aria-label={`Allarme ${severityLabel.toLowerCase()}${alarm.deviceHostname ? ` su ${alarm.deviceHostname}` : ''}`}
    >
      <div className="p-4">
        {/* Meta: severità · stato · occorrenze · causa radice · età */}
        <div className="flex flex-wrap items-center gap-2">
          <AlarmSeverityBadge severity={alarm.severity} />
          <AlarmStatusBadge status={alarm.status} />
          {alarm.occurrenceCount > 1 ? (
            <Badge
              variant="outline"
              className="num border-border bg-raised text-text-2 font-normal"
              title="deduplicati dal motore"
            >
              ×{fmtNumber(alarm.occurrenceCount)}
              <span className="sr-only"> occorrenze deduplicate dal motore</span>
            </Badge>
          ) : null}
          {alarm.suppressedByRootCause ? (
            <Badge
              variant="outline"
              className="border-border bg-raised font-normal text-text-2"
              title="Il motore ha soppresso questo allarme perché la causa radice è già segnalata da un altro allarme"
            >
              SOPPRESSO: causa radice {alarm.rootCauseHostname ?? 'n.d.'}
            </Badge>
          ) : null}
          <span
            className="num ml-auto shrink-0 text-xs text-text-2"
            title={`Aperto ${fmtDateTimeFull(alarm.openedAt)}`}
          >
            <span className="sr-only">aperto </span>da {fmtAgeMinutes(alarm.ageMinutes)}
          </span>
        </div>

        {/* Messaggio (max 3 righe; titolo col testo completo) */}
        <p className="mt-2 line-clamp-3 break-words text-sm leading-relaxed" title={alarm.message}>
          {alarm.message}
        </p>

        {/* Dispositivo + azioni */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {deviceId ? (
            <span className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1 text-xs text-text-2">
              <Monitor className="size-3.5 shrink-0" aria-hidden />
              <button
                type="button"
                className="truncate font-medium text-link hover:underline"
                onClick={() => onOpenDevice(deviceId)}
                title={`Apri ${alarm.deviceHostname ?? 'dispositivo'}`}
              >
                {alarm.deviceHostname ?? alarm.deviceIp ?? 'Dispositivo'}
              </button>
              {alarm.deviceIp ? <span className="num shrink-0">{alarm.deviceIp}</span> : null}
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-xs text-text-2">
              <Monitor className="size-3.5 shrink-0" aria-hidden />
              nessun dispositivo
            </span>
          )}

          <div className="ml-auto flex items-center gap-2">
            {canAck && alarm.status === 'OPEN' ? (
              <Button variant="outline" size="sm" className="h-9" onClick={() => onAck(alarm)}>
                <UserCheck className="size-3.5" aria-hidden />
                Prendi in carico
              </Button>
            ) : null}
            <Button
              variant="ghost"
              size="sm"
              className="h-9 gap-1 px-2 text-text-2"
              onClick={onToggleDetails}
              aria-expanded={expanded}
              aria-controls={detailsId}
            >
              <ChevronDown className={cn('size-3.5 transition-transform', expanded && 'rotate-180')} aria-hidden />
              Dettaglio
            </Button>
          </div>
        </div>
      </div>

      {/* Dettaglio espandibile: cronologia + regola + messaggio completo */}
      {expanded ? (
        <div id={detailsId} className="border-t border-border/70 bg-raised/25 px-4 py-3">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-dim">Cronologia</p>
          <dl className="mt-1.5 grid gap-x-6 gap-y-1.5 text-xs sm:grid-cols-2">
            <Hist label="Aperto" value={fmtDateTimeFull(alarm.openedAt)} />
            {alarm.escalatedAt != null ? <Hist label="Escalato" value={fmtDateTimeFull(alarm.escalatedAt)} /> : null}
            {alarm.acknowledgedAt != null ? (
              <Hist
                label="Riconosciuto"
                value={`${fmtDateTimeFull(alarm.acknowledgedAt)} · da ${alarm.acknowledgedBy ?? 'n.d.'}`}
              />
            ) : null}
            {alarm.closedAt != null ? <Hist label="Chiuso" value={fmtDateTimeFull(alarm.closedAt)} /> : null}
            <Hist label="Regola" value={alarm.ruleName ?? 'n.d.'} />
            <Hist label="Dispositivo (ID)" value={deviceId ?? 'n.d.'} breakAll />
          </dl>
          <p className="mt-3 text-[10px] font-semibold uppercase tracking-wider text-dim">Messaggio completo</p>
          <p className="mt-1 break-words text-xs leading-relaxed">{alarm.message}</p>
        </div>
      ) : null}
    </article>
  )
}

function Hist({ label, value, breakAll }: { label: string; value: React.ReactNode; breakAll?: boolean }) {
  return (
    <div className="flex gap-2 sm:block">
      <dt className="shrink-0 text-text-2">{label}</dt>
      <dd className={cn('num', breakAll && 'break-all')}>{value}</dd>
    </div>
  )
}
