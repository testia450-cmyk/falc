/* ================================================================
 * Dashboard NOC (§6.1) — «Con pochi clic devo sapere cosa non funziona,
 * dove si trova il problema, quali apparati sono coinvolti e quale
 * azione posso intraprendere.»
 * Ogni elemento risponde a una domanda (scritta nel commento del
 * componente corrispondente). Nessun dato inventato: KPI reali,
 * mappa reale, criticità reali, link deboli reali, eventi reali.
 * Aggiornamento: realtime via socket (invalidate) + asOf visibile.
 * ================================================================ */

'use client'

import { useEffect, useRef, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  MonitorSmartphone, Cctv, Radio as RadioIcon, Siren, Layers, MapPin,
  Signal, ArrowUpRight, Network, type LucideIcon,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { KpiCard } from '@/components/kpi-card'
import { PageHeader } from '@/components/page-header'
import { StatusBadge } from '@/components/status-badge'
import { EmptyState, ErrorPanel } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { MapView } from '@/components/map-view'
import { TrafficChart } from '@/components/traffic-chart'
import { api } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { subscribeRealtime } from '@/lib/client/socket'
import { usePalette } from '@/lib/client/theme-palette'
import {
  fmtDbm, fmtRelative, fmtDateTime, fmtNumber, fmtAgeMinutes, typeLabel,
} from '@/lib/client/format'
import { cn } from '@/lib/utils'

/* Domanda KPI 1: «Quanti apparati ho e in che stato sono?» */
/* Domanda KPI 2: «Le telecamere funzionano? Quanti flussi fermi?» */
/* Domanda KPI 3: «La radio regge? Quali link sono deboli?» */
/* Domanda KPI 4: «Quanti allarmi aperti e quanto gravi?» */
/* (Tunnel VPN: assente finché non esiste un dato reale — regola §1.4) */

export default function DashboardView() {
  const navigate = useApp((s) => s.navigate)
  const set = useApp((s) => s.set)
  const openDevice = useApp((s) => s.openDevice)
  const queryClient = useQueryClient()
  const [mapProvider, setMapProvider] = useState<'osm' | 'sat'>('osm')
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null)
  const firstAlarmsToast = useRef(true)

  /* Sintesi NOC (KPI + criticità + pipeline) */
  const summary = useQuery({
    queryKey: ['noc-summary'],
    queryFn: () => api.summary(),
    staleTime: 60_000,
  })

  /* Link più deboli (semantica uplink, dati reali) */
  const weak = useQuery({
    queryKey: ['weak-links'],
    queryFn: () => api.weakLinks(6),
    staleTime: 60_000,
  })

  /* Eventi recenti */
  const events = useQuery({
    queryKey: ['recent-events'],
    queryFn: () => api.events({ limit: 10 }),
    staleTime: 30_000,
  })

  /* Realtime: refetch mirato (niente polling aggressivo) */
  useEffect(() => {
    const dispose = subscribeRealtime({
      onTick: () => {
        void queryClient.invalidateQueries({ queryKey: ['noc-summary'] })
        void queryClient.invalidateQueries({ queryKey: ['recent-events'] })
      },
      onAlarms: (alarms) => {
        void queryClient.invalidateQueries({ queryKey: ['alarms'] })
        if (firstAlarmsToast.current) {
          firstAlarmsToast.current = false
          return
        }
        if (alarms.length > 0) {
          toast(`${alarms.length} allarmi aggiornati`, {
            description: alarms[0].message.slice(0, 90) + '…',
          })
        }
      },
    })
    return dispose
  }, [queryClient])

  const s = summary.data?.data

  if (summary.isLoading) {
    return (
      <div className="space-y-4">
        <div className="grid min-w-0 grid-cols-2 gap-4 xl:grid-cols-4">
          {[...Array(4)].map((_, i) => <div key={i} className="h-[118px] animate-pulse rounded-lg bg-surface" />)}
        </div>
        <div className="h-[420px] animate-pulse rounded-lg bg-surface" />
        <p className="text-center text-xs text-text-2" aria-busy="true">Caricamento dati impianto…</p>
      </div>
    )
  }

  if (summary.isError || !summary.data || !s) {
    return <ErrorPanel message={(summary.error as Error)?.message ?? 'Dati non disponibili'} code="SUMMARY" onRetry={() => void summary.refetch()} />
  }

  const env = summary.data
  const mode = env.mode
  const importedAt = env.asOf
  const byState = s.devices.byState
  const cams = s.cameras

  return (
    <div className="space-y-4">
      <PageHeader
        title={`Dashboard · ${s.plant.name}`}
        subtitle={`${s.plant.comune !== '—' ? s.plant.comune : 'Impianto'} — sintesi operativa in tempo reale`}
        mode={mode}
        importedAt={importedAt}
      />

      {/* ============ KPI (solo dati reali; VPN assente per regola §1.4) ============ */}
      <div className="grid min-w-0 grid-cols-2 gap-4 xl:grid-cols-4">
        <KpiCard
          label="Dispositivi"
          value={fmtNumber(s.devices.total)}
          segments={byState}
          asOf={env.asOf}
          definition={`Totale monitorati nell'impianto = online + degradati + offline + manutenzione + sconosciuti + non monitorati (gli allarmi sono un'altra dimensione e non entrano nella somma). ${byState.online} online · ${byState.degraded} degradati · ${byState.unknown} sconosciuti · ${byState.notMonitored} non monitorati.`}
          icon={<MonitorSmartphone className="size-4" aria-hidden />}
          onClick={() => navigate('dispositivi')}
          foot={<span>{byState.online} online · {byState.notMonitored} non monitorati</span>}
        />
        <KpiCard
          label="Telecamere"
          value={fmtNumber(cams.total)}
          asOf={env.asOf}
          accent={cams.streamDown > 0 ? 'crit' : 'none'}
          definition={`Apparati video (CAMERA, LPR, NVR). Flusso RTSP verificato dalla metrica reale cameraStreamAlive: ${cams.streamDown} flussi fermi all'ultimo campione, ${cams.streamUnknown} mai campionati (n.d.).`}
          icon={<Cctv className="size-4" aria-hidden />}
          onClick={() => navigate('telecamere')}
          foot={
            cams.streamDown > 0
              ? <span className="text-crit font-medium">{cams.streamDown} flussi fermi</span>
              : <span>{cams.online} online</span>
          }
        />
        <KpiCard
          label="Link wireless"
          value={fmtNumber(s.wirelessLinks.total)}
          asOf={env.asOf}
          accent={s.wirelessLinks.weak > 0 ? 'warn' : 'none'}
          definition={`Collegamenti radio (WIRELESS/RADIO) della tabella topologica: ${s.wirelessLinks.active} attivi, ${s.wirelessLinks.unknown} non attivi/sconosciuti. «Deboli» = endpoint con segnale uplink ≤ −75 dBm (semantica STA=uplink, AP=stazione più debole).`}
          icon={<RadioIcon className="size-4" aria-hidden />}
          onClick={() => { set({ reteTab: 'topologia' }); navigate('rete') }}
          foot={<span>{s.wirelessLinks.active} attivi · {s.wirelessLinks.weak} deboli</span>}
        />
        <KpiCard
          label="Allarmi aperti"
          value={fmtNumber(s.alarms.open)}
          asOf={env.asOf}
          accent={(s.alarms.bySeverity.CRITICAL ?? 0) > 0 ? 'crit' : (s.alarms.bySeverity.HIGH ?? 0) > 0 ? 'warn' : 'none'}
          definition={`Eventi AlertEvent con status non CLOSED (include ${s.alarms.suppressed} soppressi dal motore di correlazione: sono conseguenze già spiegate da una causa radice). Distribuzione: ${Object.entries(s.alarms.bySeverity).map(([k, v]) => `${k} ${v}`).join(' · ')}.`}
          icon={<Siren className="size-4" aria-hidden />}
          onClick={() => navigate('allarmi')}
          foot={
            s.alarms.oldestOpenMinutes != null
              ? <span>il più vecchio da {fmtAgeMinutes(s.alarms.oldestOpenMinutes)}</span>
              : null
          }
        />
      </div>

      {/* ============ Corpo: mappa + colonna destra ============ */}
      {/* minmax(0,…) + min-w-0: le track non si allargano al min-content
       * dei testi truncati dentro le card (fix overflow mobile) */}
      <div className="grid min-w-0 gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        {/* Pannello mappa (domanda: «DOVE stanno le criticità?») */}
        <Card className="min-w-0 overflow-hidden">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <MapPin className="size-4 text-text-2" aria-hidden />
              Distribuzione geografica delle sedi
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="h-8" onClick={() => { set({ reteTab: 'mappa' }); navigate('rete') }}>
                <ArrowUpRight className="mr-1 size-3.5" aria-hidden /> Mappa completa
              </Button>
              <Button variant="outline" size="sm" className="h-8" onClick={() => { set({ reteTab: 'topologia' }); navigate('rete') }}>
                <Network className="mr-1 size-3.5" aria-hidden /> Topologia
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[380px] border-t border-border">
              <MapView
                provider={mapProvider}
                onProviderChange={setMapProvider}
                selectedLocationId={selectedLocation}
                onSelectLocation={setSelectedLocation}
                compact
              />
            </div>
          </CardContent>
        </Card>

        {/* Colonna destra: stato + traffico (domande: «come sta la rete adesso?» «quanto traffico passa?») */}
        <div className="min-w-0 space-y-4">
          {/* Stato impianto: anello % + conteggi (mockup 1) */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center justify-between text-base">
                Stato impianto
                <AsOf ts={env.asOf} prefix="alle" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-5">
                <StatusRing total={s.devices.total} online={byState.online} degraded={byState.degraded} />
                <ul className="flex-1 space-y-1.5 text-xs">
                  <StateRow label="Online" value={byState.online} total={s.devices.total} cls="bg-ok text-ok" />
                  <StateRow label="Degradati" value={byState.degraded} total={s.devices.total} cls="bg-warn text-warn" />
                  <StateRow label="Sconosciuti" value={byState.unknown} total={s.devices.total} cls="bg-warn/60 text-warn" />
                  <StateRow label="Non monitorati" value={byState.notMonitored} total={s.devices.total} cls="bg-crit/60 text-crit" />
                  <StateRow label="Offline · manutenzione" value={byState.offline + byState.maintenance} total={s.devices.total} cls="bg-crit text-crit" />
                </ul>
              </div>
              {/* Qualità del dato (§1.5: la dashboard NON nasconde i limiti) */}
              {s.coverage ? (
                <div className="mt-3 rounded-md border border-border/70 bg-raised/40 px-3 py-2 text-[11px] leading-relaxed text-text-2">
                  <span className="font-medium text-foreground">Qualità del dato:</span>{' '}
                  copertura topologica certa {s.coverage.coveragePct.toFixed(1)}% (obiettivo {s.coverage.goalPct}%
                  {s.coverage.goalMet ? ' raggiunto' : ' non raggiunto'}) · {s.coverage.uncertain} collegamenti incerti su {s.coverage.certain + s.coverage.uncertain}
                </div>
              ) : null}
            </CardContent>
          </Card>

          {/* Traffico di rete 24h (definizione D3 dichiarata nel tooltip) */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Traffico di rete · 24 h</CardTitle>
            </CardHeader>
            <CardContent>
              <TrafficChart hours={24} />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ============ Riga inferiore: link deboli + eventi recenti ============ */}
      <div className="grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        {/* Link più deboli (domanda: «quali radio devo guardare per prime?») */}
        <Card className="min-w-0">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Signal className="size-4 text-text-2" aria-hidden />
              Link più deboli
            </CardTitle>
            <AsOf ts={env.asOf} prefix="alle" />
          </CardHeader>
          <CardContent className="pt-0">
            {weak.isLoading ? (
              <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-10 animate-pulse rounded-md bg-raised/50" />)}</div>
            ) : weak.isError ? (
              <ErrorPanel message={(weak.error as Error).message} className="border-0 bg-transparent px-0 py-2" />
            ) : !weak.data?.data.length ? (
              <EmptyState title="Nessun link radio con segnale campionato" description="Nessuna STA/AP con segnale presente: nessun valore inventato." className="py-8" />
            ) : (
              <ul className="divide-y divide-border/60" aria-label="Link wireless più deboli">
                {weak.data.data.map((w) => (
                  <li key={w.deviceId}>
                    <button
                      className="flex w-full items-center gap-3 py-2.5 text-left transition-colors hover:bg-raised/30"
                      onClick={() => openDevice(w.deviceId)}
                      title={`Apri ${w.hostname}`}
                    >
                      <Badge variant="outline" className={cn('num w-[72px] justify-center shrink-0 font-semibold',
                        w.signalDbm <= -85 ? 'border-crit/40 bg-crit-soft text-crit' :
                        w.signalDbm <= -75 ? 'border-warn/40 bg-warn-soft text-warn' : 'border-ok/40 bg-ok-soft text-ok')}>
                        {w.signalDbm} dBm
                      </Badge>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-medium">{w.hostname}</p>
                        <p className="truncate text-xs text-text-2">
                          {typeLabel(w.type)} · via {w.uplinkApHostname ?? 'n.d.'}{w.locationName ? ` · ${w.locationName}` : ''}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <StatusBadge status={w.uiStatus} size="xs" />
                        <p className="mt-0.5 text-[10px] text-text-2 num">{fmtRelative(w.lastSeenAt)}</p>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        {/* Eventi recenti (domanda: «cosa è successo ultimamente?») */}
        <Card className="min-w-0">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Layers className="size-4 text-text-2" aria-hidden />
              Eventi recenti
            </CardTitle>
            <AsOf ts={events.data?.asOf ?? env.asOf} prefix="alle" />
          </CardHeader>
          <CardContent className="pt-0">
            {events.isLoading ? (
              <div className="space-y-2">{[...Array(6)].map((_, i) => <div key={i} className="h-9 animate-pulse rounded-md bg-raised/50" />)}</div>
            ) : events.isError ? (
              <ErrorPanel message={(events.error as Error).message} className="border-0 bg-transparent px-0 py-2" />
            ) : !events.data?.data.items.length ? (
              <EmptyState title="Nessun evento registrato" className="py-8" />
            ) : (
              <ul className="max-h-80 space-y-0 overflow-y-auto scroll-thin divide-y divide-border/60" aria-label="Eventi recenti">
                {events.data.data.items.map((e) => (
                  <li key={e.id} className="flex items-center gap-3 py-2">
                    <span className="w-[92px] shrink-0 text-[10px] uppercase tracking-wide text-text-2 num">
                      {fmtRelative(e.createdAt)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs">
                        <span className="font-medium">{e.deviceHostname ?? 'Sistema'}</span>
                        {' '}
                        <span className="text-text-2">
                          {eventLabel(e.eventType)}
                          {e.oldValue && e.newValue && e.eventType === 'STATUS_CHANGE' ? ` ${e.oldValue} → ${e.newValue}` : ''}
                        </span>
                      </p>
                      <p className="text-[10px] text-text-2">fonte {e.source.toLowerCase()}</p>
                    </div>
                    {e.deviceId ? (
                      <Button variant="ghost" size="sm" className="h-7 shrink-0 px-2 text-xs text-link hover:text-link" onClick={() => openDevice(e.deviceId!)}>
                        Apri
                      </Button>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

/* Anello di stato (mockup 1: «Stato impianto» con %) — la % è la quota
 * di dispositivi ONLINE sul totale (definizione dichiarata nel title). */
function StatusRing({ total, online, degraded }: { total: number; online: number; degraded: number }) {
  const p = usePalette()
  const pct = total > 0 ? Math.round((online / total) * 100) : 0
  const good = total > 0 ? ((online + degraded) / total) * 100 : 0
  const r = 52
  const c = 2 * Math.PI * r
  return (
    <div
      className="relative size-[132px] shrink-0"
      role="img"
      aria-label={`Online ${online} su ${total} dispositivi (${pct}%); degradati ${degraded}`}
      title={`% = dispositivi online sul totale monitorato`}
    >
      <svg viewBox="0 0 120 120" className="size-full -rotate-90">
        <circle cx="60" cy="60" r={r} fill="none" stroke={p.raised} strokeWidth="10" />
        <circle cx="60" cy="60" r={r} fill="none" stroke={p.warn} strokeWidth="10" strokeDasharray={`${(good / 100) * c} ${c}`} strokeLinecap="round" opacity="0.9" />
        <circle cx="60" cy="60" r={r} fill="none" stroke={p.ok} strokeWidth="10" strokeDasharray={`${(pct / 100) * c} ${c}`} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="num text-2xl font-semibold">{pct}%</span>
        <span className="text-[10px] text-text-2">online</span>
      </div>
    </div>
  )
}

function StateRow({ label, value, total, cls }: { label: string; value: number; total: number; cls: string }) {
  if (value <= 0) return null
  return (
    <li className="flex items-center gap-2">
      <span className={cn('inline-block size-2 rounded-full', cls.split(' ')[0])} aria-hidden />
      <span className="flex-1 text-text-2">{label}</span>
      <span className={cn('num font-semibold', cls.split(' ')[1])}>{value}</span>
      <span className="num text-[10px] text-text-2">{total > 0 ? Math.round((value / total) * 100) : 0}%</span>
    </li>
  )
}

function eventLabel(t: string): string {
  switch (t) {
    case 'STATUS_CHANGE': return 'cambio stato'
    case 'FREQ_CHANGE': return 'cambio frequenza'
    case 'REBOOT': return 'riavvio'
    case 'FIRMWARE_UPDATE': return 'aggiornamento firmware'
    case 'CONFIG_CHANGE': return 'cambio configurazione'
    case 'ALARM': return 'allarme'
    default: return t.toLowerCase().replace(/_/g, ' ')
  }
}
