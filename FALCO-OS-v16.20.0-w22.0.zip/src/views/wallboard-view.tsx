/* ================================================================
 * FALCO-OS v16 — Wallboard «TV» (16.2 — residua W2 consegnata)
 * Vista per monitor dedicato (sala operazioni / stadio): overlay a
 * tutto schermo sopra la shell con i KPI del NOC in tipografia larga,
 * allarmi aperti in evidenza, link radio deboli, orologio grande.
 *  · dati REALI: stessi endpoint delle viste operative (summary,
 *    allarmi, link deboli) + tick realtime (socket, nessun polling
 *    aggressivo);
 *  · onestà: badge modalità riproduzione, asOf visibile, «n.d.» dove
 *    manca il dato, zero numeri inventati;
 *  · uscita: tasto Esc o bottone «Esci» (→ dashboard); Fullscreen API
 *    con fallback grazioso (se negata, la vista resta comunque usabile);
 *  · a11y: regione nominata, contrasto con token di tema (chiaro e
 *    scuro), nessun movimento se prefers-reduced-motion (live-dot).
 * IA: NON è una nona voce di menu — è una MODALITÀ di presentazione
 * raggiungibile dal bottone monitor in topbar o dal deep link
 * ?view=wallboard (le 8 voci operative restano invariate).
 * ================================================================ */

'use client'

import { useEffect, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Camera, Maximize2, Minimize2, RadioTower, TriangleAlert, Wifi, X,
} from 'lucide-react'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { api } from '@/lib/client/api'
import { useApp } from '@/lib/client/store'
import { subscribeRealtime, type NocTickPayload } from '@/lib/client/socket'
import { SEVERITY_META, fmtDbm, fmtNumber, fmtRelative, typeLabel } from '@/lib/client/format'
import { cn } from '@/lib/utils'

/** Ordine di gravità client-side (stessa semantica del backend). */
const SEV_RANK: Record<string, number> = { INFO: 1, WARNING: 2, AVERAGE: 3, HIGH: 4, CRITICAL: 5 }

export default function WallboardView() {
  const navigate = useApp((s) => s.navigate)
  const queryClient = useQueryClient()

  /* Tick realtime: contatori aggiornati al volo (30 s) + refetch summary. */
  const [tick, setTick] = useState<NocTickPayload | null>(null)
  const [realtimeUp, setRealtimeUp] = useState<boolean | null>(null)
  const [clock, setClock] = useState('')
  const [fullscreen, setFullscreen] = useState(false)

  useEffect(() => {
    const dispose = subscribeRealtime({
      onConnect: () => setRealtimeUp(true),
      onDisconnect: () => setRealtimeUp(false),
      onTick: (p) => {
        setTick(p)
        void queryClient.invalidateQueries({ queryKey: ['noc-summary'] })
      },
    })
    return dispose
  }, [queryClient])

  /* Orologio grande (client-only: nessun mismatch di idratazione). */
  useEffect(() => {
    const update = () => setClock(new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' }))
    update()
    const t = setInterval(update, 1000)
    return () => clearInterval(t)
  }, [])

  /* Esc = uscita dal wallboard (tornare alla dashboard). */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') navigate('dashboard')
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [navigate])

  /* Stato Fullscreen API (mai richiesto automaticamente: sempre su click). */
  useEffect(() => {
    const onChange = () => setFullscreen(Boolean(document.fullscreenElement))
    document.addEventListener('fullscreenchange', onChange)
    return () => document.removeEventListener('fullscreenchange', onChange)
  }, [])

  const toggleFullscreen = () => {
    try {
      if (document.fullscreenElement) void document.exitFullscreen()
      else void document.documentElement.requestFullscreen()
    } catch {
      /* Fullscreen negato (sandbox/iframe): la vista resta comunque
       * a tutto schermo di fatto — nessun errore mostrato all'operatore. */
    }
  }

  const summary = useQuery({
    queryKey: ['noc-summary'],
    queryFn: () => api.summary(),
    refetchInterval: 60_000,
    staleTime: 45_000,
  })
  const alarms = useQuery({
    queryKey: ['alarms-wallboard'],
    queryFn: () => api.alarms({ status: 'OPEN,ACK,ESCALATED', page: 1, pageSize: 50 }),
    refetchInterval: 60_000,
    staleTime: 45_000,
  })
  const weak = useQuery({
    queryKey: ['weak-links-wallboard'],
    queryFn: () => api.weakLinks(6),
    refetchInterval: 120_000,
    staleTime: 90_000,
  })

  const s = summary.data?.data
  const openAlarms = (alarms.data?.data.items ?? [])
    .filter((a) => a.status !== 'SUPPRESSED')
    .sort((a, b) => (SEV_RANK[b.severity] ?? 0) - (SEV_RANK[a.severity] ?? 0) || b.openedAt - a.openedAt)
    .slice(0, 10)
  const weakLinks = weak.data?.data ?? []

  /* Contatori: priorità al tick realtime (se arrivato), altrimenti summary. */
  const online = tick?.devicesOnline ?? s?.devices.byState.online
  const degraded = tick?.devicesDegraded ?? s?.devices.byState.degraded
  const unknownDev = tick?.devicesUnknown ?? s?.devices.byState.unknown
  const total = s?.devices.total
  const notMonitored = s?.devices.byState.notMonitored

  const crit = s?.alarms.bySeverity.CRITICAL ?? 0
  const high = s?.alarms.bySeverity.HIGH ?? 0
  const open = s?.alarms.open

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-background p-4 sm:p-6"
      role="region"
      aria-label="Wallboard NOC a tutto schermo per monitor dedicato"
    >
      <div className="mx-auto flex min-h-full max-w-7xl flex-col gap-4">
        {/* --- Testata: titolo, orologio, stati, uscita --- */}
        <header className="flex flex-wrap items-center gap-3">
          <div className="min-w-0">
            <h1 className="truncate text-xl font-semibold tracking-tight sm:text-2xl">
              Wallboard · {s?.plant.name ?? '…'}
            </h1>
            <p className="text-xs text-text-2">
              Monitor dedicato — dati reali del DB
              {summary.data ? <> · aggiornato alle <span className="num">{new Date(summary.data.asOf).toLocaleTimeString('it-IT')}</span></> : null}
            </p>
          </div>

          <div className="ml-auto flex flex-wrap items-center gap-2">
            {/* Badge connessione realtime (tre stati onesti, come la topbar) */}
            <Badge variant="outline" className={cn(
              'gap-1.5 font-semibold',
              realtimeUp === true && 'border-ok/40 bg-ok-soft text-ok',
              realtimeUp === null && 'border-border bg-raised text-text-2',
              realtimeUp === false && 'border-warn/40 bg-warn-soft text-warn',
            )}>
              <span className={cn(
                'inline-block size-1.5 rounded-full',
                realtimeUp === true && 'live-dot bg-ok',
                realtimeUp === null && 'bg-text-2',
                realtimeUp === false && 'bg-warn',
              )} aria-hidden />
              {realtimeUp === true ? 'Live' : realtimeUp === null ? 'Connessione…' : 'Realtime disconnesso'}
            </Badge>
            {summary.data?.mode === 'replay' ? (
              <Badge variant="outline" className="border-info/40 bg-info-soft text-info">Riproduzione</Badge>
            ) : null}
            <span className="num text-2xl font-semibold tabular-nums sm:text-3xl" aria-label="Ora corrente">{clock || '··:··:··'}</span>
            <Button
              variant="outline" size="icon" className="size-9"
              onClick={toggleFullscreen}
              aria-label={fullscreen ? 'Esci da tutto schermo' : 'Attiva tutto schermo'}
              title={fullscreen ? 'Esci da tutto schermo' : 'Attiva tutto schermo'}
            >
              {fullscreen ? <Minimize2 className="size-4" aria-hidden /> : <Maximize2 className="size-4" aria-hidden />}
            </Button>
            <Button variant="outline" size="sm" className="h-9" onClick={() => navigate('dashboard')}>
              <X className="size-4" aria-hidden />
              Esci <kbd className="ml-1 hidden text-[10px] text-text-2 sm:inline">Esc</kbd>
            </Button>
          </div>
        </header>

        {/* --- KPI grandi --- */}
        <section aria-label="Indicatori principali" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Tile
            icon={<RadioTower className="size-5" aria-hidden />}
            label="Dispositivi"
            value={total != null ? fmtNumber(total) : 'n.d.'}
            sub={
              <>
                {online != null ? <><span className="num text-ok">{fmtNumber(online)}</span> online</> : null}
                {degraded != null ? <> · <span className={cn('num', degraded > 0 ? 'text-warn' : '')}>{fmtNumber(degraded)}</span> degradati</> : null}
                {notMonitored != null ? <> · {fmtNumber(notMonitored)} non monitorati</> : null}
                {unknownDev != null && unknownDev > 0 ? <> · <span className="num">{fmtNumber(unknownDev)}</span> sconosciuti</> : null}
              </>
            }
          />
          <Tile
            icon={<Camera className="size-5" aria-hidden />}
            label="Telecamere"
            value={s ? fmtNumber(s.cameras.total) : 'n.d.'}
            sub={
              s ? (
                <>
                  flussi fermi:{' '}
                  <span className={cn('num', s.cameras.streamDown > 0 ? 'text-crit' : 'text-ok')}>{fmtNumber(s.cameras.streamDown)}</span>
                  {' '}· mai campionati {fmtNumber(s.cameras.streamUnknown)}
                </>
              ) : null
            }
          />
          <Tile
            icon={<TriangleAlert className={cn('size-5', crit > 0 ? 'text-crit' : 'text-text-2')} aria-hidden />}
            label="Allarmi aperti"
            value={open != null ? fmtNumber(open) : 'n.d.'}
            sub={open != null ? <><span className="num text-crit">{fmtNumber(crit)}</span> critici · <span className="num text-warn">{fmtNumber(high)}</span> alti</> : null}
            accent={crit > 0 ? 'crit' : undefined}
          />
          <Tile
            icon={<Wifi className="size-5" aria-hidden />}
            label="Link wireless"
            value={s ? fmtNumber(s.wirelessLinks.total) : 'n.d.'}
            sub={s ? <><span className="num text-ok">{fmtNumber(s.wirelessLinks.active)}</span> attivi · <span className={cn('num', s.wirelessLinks.weak > 0 ? 'text-warn' : '')}>{fmtNumber(s.wirelessLinks.weak)}</span> deboli</> : null}
          />
        </section>

        {/* --- Allarmi + link deboli --- */}
        <div className="grid flex-1 gap-3 lg:grid-cols-3">
          <section aria-label="Allarmi aperti più gravi" className="lg:col-span-2">
            <h2 className="mb-2 text-sm font-semibold text-text-2">Allarmi aperti (i più gravi)</h2>
            {alarms.isPending ? (
              <div className="h-64 animate-pulse rounded-lg bg-surface" aria-busy="true" />
            ) : alarms.isError ? (
              <p className="rounded-lg border border-warn/40 bg-warn-soft p-4 text-sm text-warn" role="alert">
                Allarmi non caricati: controllare la connessione.
              </p>
            ) : openAlarms.length === 0 ? (
              <p className="rounded-lg border border-ok/40 bg-ok-soft p-4 text-sm text-ok">Nessun allarme aperto: tutto silenzioso.</p>
            ) : (
              <ul className="divide-y divide-border/60 overflow-hidden rounded-lg border border-border/70 bg-surface">
                {openAlarms.map((a) => {
                  const sev = SEVERITY_META[a.severity]
                  return (
                    <li key={a.id} className="flex items-center gap-3 px-4 py-2.5">
                      <Badge variant="outline" className={cn('shrink-0 whitespace-nowrap font-semibold', sev?.cls ?? 'border-border bg-raised text-text-2')}>
                        {sev?.label ?? a.severity}
                      </Badge>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm" title={a.message}>{a.message}</p>
                        <p className="text-xs text-text-2">
                          {a.deviceHostname ?? 'n.d.'}
                          {a.deviceIp ? <span className="num"> · {a.deviceIp}</span> : null}
                          {a.occurrenceCount > 1 ? <> · {fmtNumber(a.occurrenceCount)} occorrenze</> : null}
                        </p>
                      </div>
                      <span className="num shrink-0 text-xs text-text-2" title={new Date(a.openedAt).toLocaleString('it-IT')}>
                        {fmtRelative(a.openedAt)}
                      </span>
                    </li>
                  )
                })}
              </ul>
            )}
          </section>

          <section aria-label="Link radio più deboli">
            <h2 className="mb-2 text-sm font-semibold text-text-2">Link radio deboli</h2>
            {weak.isPending ? (
              <div className="h-40 animate-pulse rounded-lg bg-surface" aria-busy="true" />
            ) : weak.isError ? (
              <p className="rounded-lg border border-warn/40 bg-warn-soft p-4 text-sm text-warn" role="alert">Link non caricati.</p>
            ) : weakLinks.length === 0 ? (
              <p className="rounded-lg border border-ok/40 bg-ok-soft p-4 text-sm text-ok">Nessun link radio debole rilevato.</p>
            ) : (
              <ul className="space-y-2">
                {weakLinks.map((w) => (
                  <li key={w.deviceId} className="rounded-lg border border-border/70 bg-surface px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <span className="min-w-0 flex-1 truncate text-sm font-medium" title={w.hostname}>{w.hostname}</span>
                      <Badge variant="outline" className={cn(
                        'num shrink-0 font-semibold',
                        w.signalDbm <= -85 ? 'border-crit/40 bg-crit-soft text-crit-text' : 'border-warn/40 bg-warn-soft text-warn',
                      )}>
                        {fmtDbm(w.signalDbm)}
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-text-2">
                      {typeLabel(w.type)} · {w.locationName ?? 'n.d.'}
                      {w.uplinkApHostname ? <> · verso {w.uplinkApHostname}</> : null}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        {/* --- Piè di pagina wallboard --- */}
        <footer className="mt-auto flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-border/70 pt-3 text-[11px] text-text-2">
          <span>FALCO-OS v16.2 — dati reali del DB, nessun dato di esempio</span>
          {s?.coverage ? (
            <span className="num">copertura topologica {s.coverage.coveragePct.toFixed(1).replace('.', ',')}%</span>
          ) : null}
          <span className="ml-auto">Esc per uscire · aggiornamento automatico 30–60 s</span>
        </footer>
      </div>
    </div>
  )
}

/* ---------------- Tile KPI grande ---------------- */

function Tile({
  icon, label, value, sub, accent,
}: {
  icon: React.ReactNode
  label: string
  value: string
  sub: React.ReactNode
  accent?: 'crit'
}) {
  return (
    <div className={cn(
      'rounded-xl border bg-surface p-4 sm:p-5',
      accent === 'crit' ? 'border-crit/50' : 'border-border/70',
    )}>
      <div className="flex items-center gap-2 text-text-2">
        {icon}
        <span className="text-xs font-semibold uppercase tracking-wider">{label}</span>
      </div>
      <p className={cn(
        'num mt-1.5 text-4xl font-bold tabular-nums leading-none sm:text-5xl',
        accent === 'crit' && 'text-crit',
      )}>{value}</p>
      <p className="mt-2 min-h-4 text-xs text-text-2">{sub}</p>
    </div>
  )
}
