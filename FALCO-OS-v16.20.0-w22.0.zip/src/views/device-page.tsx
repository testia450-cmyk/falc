/* ================================================================
 * FALCO-OS v16 — Scheda apparato a pagina intera (§6.4)
 * Rende visibile «cosa c'è dietro» un apparato: percorso verso il
 * gateway con primo punto guasto, impatto a valle, metriche chiave,
 * collegamenti (con confidenza della ricostruzione), serie 24h
 * (solo punti reali) e identità estesa.
 * Regole di onestà (§2.1): «n.d.» per i valori mancanti; MAI colori
 * da soli (badge icona+testo, title sulle soglie); i campi segreti
 * non esistono nel contratto API e non vengono mai inviati al browser.
 * Deep link: ?device=ID&tab=metriche (deviceTab nello store).
 * ================================================================ */

'use client'

import { useEffect, useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useSession } from 'next-auth/react'
import { toast } from 'sonner'
import {
  CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis,
} from 'recharts'
import {
  Activity, ArrowDown, ArrowLeft, ArrowLeftRight, ArrowUp, Cable, ChevronDown, ChevronRight, Clock, Cpu,
  Gauge, HelpCircle, History, Loader2, Lock, MapPin, Network, Radio, RadioTower, Router, Server,
  ShieldCheck, ShieldOff, ShieldX, Signal, Siren, TriangleAlert, Video,
  type LucideIcon,
} from 'lucide-react'

import { api, ApiError } from '@/lib/client/api'
import type { DeviceOverview, DevicePortRow, DevicePortsPage } from '@/lib/v2/contracts'
import { subscribeRealtime } from '@/lib/client/socket'
import { usePalette } from '@/lib/client/theme-palette'
import { useApp } from '@/lib/client/store'
import {
  SEVERITY_META, fmtDateTime, fmtDateTimeFull, fmtDbm, fmtMbps, fmtPct, fmtRelative,
  fmtUptime, typeLabel,
} from '@/lib/client/format'
import { EmptyState, ErrorPanel } from '@/components/states'
import { KpiCard } from '@/components/kpi-card'
import { StaleIndicator } from '@/components/stale-indicator'
import { StatusBadge } from '@/components/status-badge'
import { SNMP_STATE_LABELS, SnmpEnableDialog } from '@/components/snmp-enable-dialog'
import { RadioTelemetryDialog } from '@/components/radio-telemetry-dialog'
import { LocateDialog } from '@/components/locate-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table, TableBody, TableCell, TableCaption, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'

/* ---------------- Costanti / vocabolario ---------------- */

const DEVICE_TABS = [
  { value: 'panoramica', label: 'Panoramica' },
  { value: 'collegamenti', label: 'Collegamenti' },
  { value: 'porte', label: 'Porte' },
  { value: 'metriche', label: 'Metriche' },
  { value: 'configurazione', label: 'Configurazione' },
  { value: 'storico', label: 'Storico' },
] as const
type DeviceTab = (typeof DEVICE_TABS)[number]['value']

const METRIC_META: Record<string, { label: string; unit: string }> = {
  pingLatency: { label: 'Latenza ping', unit: 'ms' },
  packetLoss: { label: 'Perdita pacchetti', unit: '%' },
  signalStrength: { label: 'Segnale', unit: 'dBm' },
  linkQuality: { label: 'Qualità link', unit: '%' },
  cameraRtt: { label: 'RTT flusso video', unit: 'ms' },
}

/** Icona per tipo evento (il testo è SEMPRE presente accanto all'icona). */
const EVENT_ICONS: Record<string, LucideIcon> = {
  STATUS_CHANGE: ArrowLeftRight,
  FREQ_CHANGE: Radio,
  LINK_CHANGE: Network,
  PORT_MOVED: Cable,
}

const EVENT_LABELS: Record<string, string> = {
  STATUS_CHANGE: 'Cambio stato',
  FREQ_CHANGE: 'Cambio frequenza',
  LINK_CHANGE: 'Cambio collegamento',
  PORT_MOVED: 'Porta spostata',
}

/** Confidenza della ricostruzione topologica (badge con testo). */
const CONFIDENCE_CLS: Record<string, string> = {
  HIGH: 'bg-ok-soft text-ok border-ok/40',
  MEDIUM: 'bg-info-soft text-info border-info/40',
  LOW: 'bg-warn-soft text-warn border-warn/40',
}

const CREDENTIAL_CLS: Record<string, string> = {
  OK: 'bg-ok-soft text-ok border-ok/40',
  WRONG: 'bg-crit-soft text-crit-text border-crit/40',
  MISSING: 'bg-warn-soft text-warn border-warn/40',
  UNKNOWN: 'bg-warn-soft text-warn border-warn/40',
}

/** v16.18 W19 — chip di attivazione SNMP nell'intestazione (info per
 * tutti, CLIENTE incluso): colore + testo, mai colore da solo. */
const SNMP_CHIP_META: Record<string, { label: string; cls: string; title: string }> = {
  ENABLED: { label: 'SNMP attivo', cls: 'bg-ok-soft text-ok border-ok/40', title: 'Attivazione applicata e verificata con la sonda' },
  ENABLED_UNVERIFIED: { label: 'SNMP non verificato', cls: 'bg-warn-soft text-warn border-warn/40', title: 'Comandi applicati ma la sonda non ha ancora confermato l’agente' },
  FAILED: { label: 'SNMP KO', cls: 'bg-crit-soft text-crit-text border-crit/40', title: 'Ultimo tentativo di attivazione non riuscito' },
  MANUAL_REQUIRED: { label: 'SNMP manuale', cls: 'bg-warn-soft text-warn border-warn/40', title: 'Nessuna automazione: attivare dal pannello vendor (istruzioni in scheda)' },
}

/** v16.15 W13 — stato STP della porta (dot1dStpPortState): forwarding =
 *  in servizio; blocking/listening/learning = trattenuta dal protocollo
 *  (normale con ridondanza); disabled/broken = ferma. Stati non noti →
 *  neutro (l'assenza di giudizio non è un errore). */
const STP_STATE_CLS: Record<string, string> = {
  forwarding: 'bg-ok-soft text-ok border-ok/40',
  blocking: 'bg-warn-soft text-warn border-warn/40',
  listening: 'bg-warn-soft text-warn border-warn/40',
  learning: 'bg-warn-soft text-warn border-warn/40',
  disabled: 'bg-crit-soft text-crit-text border-crit/40',
  broken: 'bg-crit-soft text-crit-text border-crit/40',
}

/* ---------------- Helper ---------------- */

function typeIcon(type: string): LucideIcon {
  switch (type?.toUpperCase()) {
    case 'AP': case 'STA': return Radio
    case 'CAMERA': case 'LPR': case 'NVR': return Video
    case 'GATEWAY': case 'ROUTER': return Router
    case 'SERVER': return Server
    case 'SWITCH': return Network
    default: return HelpCircle
  }
}

/** Soglie segnale radio (port link-detail: −65/−75/−85 dBm).
 * MAI solo colore: sempre anche testo + title esplicativo. */
function signalTone(v: number): { cls: string; label: string } {
  if (v >= -65) return { cls: 'text-ok', label: 'buono (≥ −65 dBm)' }
  if (v >= -75) return { cls: 'text-foreground', label: 'fascia di attenzione (−75…−65 dBm)' }
  if (v >= -85) return { cls: 'text-warn', label: 'debole (sotto −75 dBm)' }
  return { cls: 'text-crit', label: 'molto debole (sotto −85 dBm)' }
}

function signalAccent(v: number): 'ok' | 'warn' | 'crit' | 'none' {
  if (v >= -65) return 'ok'
  if (v >= -75) return 'none'
  if (v >= -85) return 'warn'
  return 'crit'
}

/* ================================================================
 * DevicePage
 * ================================================================ */

export default function DevicePage({ deviceId }: { deviceId: string }) {
  const openDevice = useApp((s) => s.openDevice)
  const navigate = useApp((s) => s.navigate)
  const set = useApp((s) => s.set)
  const deviceTab = useApp((s) => s.deviceTab)
  const queryClient = useQueryClient()

  /* api.deviceOverview ritorna la busta { ok, asOf, mode, data }:
   * con select estraggo direttamente il payload (tipizzato da contracts). */
  const ov = useQuery({
    queryKey: ['device-overview', deviceId],
    queryFn: () => api.deviceOverview(deviceId),
    select: (env) => env.data,
    staleTime: 30_000,
  })

  /* realtime: a ogni tick la scheda si aggiorna con i campioni nuovi */
  useEffect(() => {
    const dispose = subscribeRealtime({
      onTick: () => { void queryClient.invalidateQueries({ queryKey: ['device-overview'] }) },
    })
    return dispose
  }, [queryClient])

  /* --- 16.18 W19 — attivazione SNMP assistita: il CLIENTE è in sola
   * lettura (autorità permessi = backend), TECNICO+ può agire. --- */
  const { data: session } = useSession()
  const canAct = !!session?.user?.role && session.user.role !== 'CLIENTE'
  const [snmpDlgOpen, setSnmpDlgOpen] = useState(false)
  /* v16.18 W20 — sonda telemetria radio & salute + «dove è collegato» */
  const [telemetryDlgOpen, setTelemetryDlgOpen] = useState(false)
  const [locateDlgOpen, setLocateDlgOpen] = useState(false)

  /* Riverifica SNMP (ENABLED / ENABLED_UNVERIFIED): sonda read-only
   * con la community CIFRATA del dispositivo. */
  const snmpVerify = useMutation({
    mutationFn: () => api.snmpEnableVerify(deviceId),
    onSuccess: (res) => {
      if (res.reachable) {
        toast.success(`SNMP raggiungibile (sysName «${res.sysName ?? 'n.d.'}»)`)
      } else {
        toast.warning('Sonda ancora muta', {
          description: res.error ?? 'L\'agente SNMP non risponde ancora: riprovare tra qualche secondo.',
        })
      }
      void queryClient.invalidateQueries({ queryKey: ['device-overview'] })
    },
    onError: (e) => {
      const info = e instanceof ApiError ? { message: e.message, code: e.code as string } : { message: e instanceof Error ? e.message : 'Errore sconosciuto' }
      toast.error('Riverifica non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  /* Spazzata ping sul SINGOLO apparato (monitorMode='ping'): campioni
   * di presenza + stato online/offline onesto. */
  const pingSweepOne = useMutation({
    mutationFn: () => api.monitorPingSweep({ deviceId }),
    onSuccess: (res) => {
      const r = res.results[0]
      if (r && r.alive) {
        toast.success(r.latencyMs != null ? `Online (${Math.round(r.latencyMs)} ms)` : 'Online')
      } else {
        toast.warning('Offline — nessuna risposta')
      }
      void queryClient.invalidateQueries({ queryKey: ['device-overview'] })
      void queryClient.invalidateQueries({ queryKey: ['devices'] })
    },
    onError: (e) => {
      const info = e instanceof ApiError ? { message: e.message, code: e.code as string } : { message: e instanceof Error ? e.message : 'Errore sconosciuto' }
      toast.error('Spazzata ping non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  /* tab attiva dallo store (deep link ?tab=…) */
  const activeTab: DeviceTab = DEVICE_TABS.some((t) => t.value === deviceTab)
    ? (deviceTab as DeviceTab)
    : 'panoramica'

  /* --- 16.5.0 tab «Porte»: caricata SOLO col tab aperto (dati reali
   * per porta: topologia + FDB + serie utilizzazione). Il deep link
   * ?tab=porte su un non-switch resta onesto: l'API risponde ports=[]
   * e la UI mostra l'empty state («porte disponibili solo sugli
   * switch con dati FDB/topologia»). --- */
  const portsQuery = useQuery({
    queryKey: ['device-ports', deviceId],
    queryFn: () => api.devicePorts(deviceId),
    select: (env) => env.data,
    enabled: activeTab === 'porte',
    staleTime: 60_000,
  })

  /* «Eventi» nell'intestazione: passa alla scheda Storico e la scorre */
  const storicoRef = useRef<HTMLDivElement>(null)
  const [eventsNonce, setEventsNonce] = useState(0)
  useEffect(() => {
    if (eventsNonce > 0 && activeTab === 'storico') {
      storicoRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }, [eventsNonce, activeTab])
  const gotoEvents = () => {
    set({ deviceTab: 'storico' })
    setEventsNonce((n) => n + 1)
  }

  /* --- stati: caricamento / errore --- */
  if (ov.isLoading) {
    return (
      <div role="status" aria-busy="true" className="space-y-4">
        <span className="sr-only">Caricamento scheda dispositivo</span>
        <Skeleton className="h-9 w-48 rounded-md" />
        <div className="flex items-start gap-3">
          <Skeleton className="size-12 shrink-0 rounded-lg" />
          <div className="space-y-2">
            <Skeleton className="h-8 w-72 rounded-md" />
            <Skeleton className="h-4 w-56 rounded-md" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-lg" />)}
        </div>
        <Skeleton className="h-10 w-full max-w-xl rounded-lg" />
        <Skeleton className="h-72 w-full rounded-lg" />
      </div>
    )
  }

  const data = ov.data
  if (!data) {
    return (
      <div className="space-y-3">
        <Button variant="outline" size="sm" className="h-11 sm:h-9" onClick={() => openDevice(null)}>
          <ArrowLeft className="mr-1.5 size-3.5" aria-hidden /> Elenco dispositivi
        </Button>
        <ErrorPanel
          message={(ov.error as Error | undefined)?.message ?? 'Dati non disponibili'}
          code={ov.error instanceof ApiError ? ov.error.code : undefined}
          onRetry={() => { void ov.refetch() }}
        />
      </div>
    )
  }

  const d = data.identity
  const isRadio = d.type === 'AP' || d.type === 'STA'
  const hasCameraData = data.camera != null
  const maxMetricTs = data.keyMetrics.length > 0
    ? Math.max(...data.keyMetrics.map((m) => m.timestamp))
    : null

  /* --- riga KPI (per tipo apparato; asOf = ultimo campione metrica) --- */
  type Kpi = {
    key: string
    label: string
    value: string
    icon?: React.ReactNode
    accent?: 'ok' | 'warn' | 'crit' | 'info' | 'none'
    definition?: string
  }
  const kpis: Kpi[] = []
  if (isRadio) {
    kpis.push({
      key: 'segnale',
      label: 'Segnale',
      value: fmtDbm(d.signalStrength),
      icon: <Signal className="size-3.5" aria-hidden />,
      accent: d.signalPresent ? signalAccent(d.signalStrength) : 'none',
      definition: 'Segnale radio verso l\'apparato di uplink. Soglie: buono ≥ −65 dBm · attenzione −75…−65 · debole < −75 · molto debole < −85.',
    })
    kpis.push({
      key: 'qualita',
      label: 'Qualità link',
      value: fmtPct(d.linkQuality),
      icon: <Gauge className="size-3.5" aria-hidden />,
      definition: 'Qualità del collegamento radio dichiarata dall\'apparato (linkQuality).',
    })
  }
  if (hasCameraData && data.camera) {
    kpis.push({
      key: 'flusso',
      label: 'Flusso video',
      value: data.camera.streamAlive == null ? 'n.d.' : data.camera.streamAlive ? 'Attivo' : 'Fermo',
      icon: <Video className="size-3.5" aria-hidden />,
      accent: data.camera.streamAlive === false ? 'crit' : data.camera.streamAlive === true ? 'ok' : 'none',
      definition: 'Stato del flusso dal controllo cameraStreamAlive (ultimo campione). «n.d.» = mai campionato.',
    })
    kpis.push({
      key: 'rtt',
      label: 'RTT',
      value: data.camera.rttMs != null ? `${Math.round(data.camera.rttMs)} ms` : 'n.d.',
      icon: <Gauge className="size-3.5" aria-hidden />,
      definition: 'Ritardo di andata e ritorno del flusso video (cameraRtt).',
    })
  }
  kpis.push({
    key: 'uptime',
    label: 'Uptime',
    value: fmtUptime(d.uptimeSeconds),
    icon: <Clock className="size-3.5" aria-hidden />,
    definition: 'Tempo trascorso dall\'ultimo riavvio dichiarato dall\'apparato.',
  })
  kpis.push({
    key: 'cpu',
    label: 'CPU',
    value: d.cpuLoad ? `${d.cpuLoad}%` : 'n.d.',
    icon: <Cpu className="size-3.5" aria-hidden />,
    accent: d.cpuLoad > 90 ? 'crit' : 'none',
    definition: 'Carico CPU dichiarato dall\'apparato (cpuLoad). «n.d.» = mai letto.',
  })
  /* v16.18 W20 — RAM live dalla telemetria (0 = mai letta → n.d.) */
  kpis.push({
    key: 'ram',
    label: 'RAM',
    value: d.ramTotal > 0 && d.ramUsed > 0
      ? `${Math.round(d.ramUsed / 1024)} / ${Math.round(d.ramTotal / 1024)} MB`
      : 'n.d.',
    icon: <Gauge className="size-3.5" aria-hidden />,
    accent: d.ramTotal > 0 && d.ramUsed / d.ramTotal > 0.9 ? 'warn' : 'none',
    definition: 'Memoria usata / totale dichiarata dall\'apparato (telemetria radio & salute). «n.d.» = mai letta.',
  })
  if (!isRadio && !hasCameraData) {
    /* apparati di rete: latenza/perdita dall'ultimo campione REALE */
    const lat = data.keyMetrics.find((m) => m.metric === 'pingLatency')
    if (lat) kpis.push({
      key: 'ping',
      label: 'Latenza ping',
      value: `${Math.round(lat.value)} ms`,
      icon: <Activity className="size-3.5" aria-hidden />,
      definition: 'Latenza ping dell\'ultimo campione reale (pingLatency).',
    })
    const loss = data.keyMetrics.find((m) => m.metric === 'packetLoss')
    if (loss) kpis.push({
      key: 'loss',
      label: 'Perdita pacchetti',
      value: `${loss.value}%`,
      icon: <Activity className="size-3.5" aria-hidden />,
      accent: loss.value >= 5 ? 'warn' : 'none',
      definition: 'Perdita pacchetti dell\'ultimo campione reale (packetLoss).',
    })
  }

  const marcaModello = [d.brand, d.model].filter(Boolean).join(' ') || 'n.d.'
  const freqLink = isRadio
    ? [d.currentFrequency ? `${d.currentFrequency} MHz` : null, d.linkMode || null].filter(Boolean).join(' · ') || 'n.d.'
    : null

  return (
    <div className="space-y-4">
      {/* ============ Intestazione ============ */}
      <header className="space-y-3">
        <Button variant="outline" size="sm" className="h-11 sm:h-9" onClick={() => openDevice(null)}>
          <ArrowLeft className="mr-1.5 size-3.5" aria-hidden /> Elenco dispositivi
        </Button>

        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            <TypeIconBox type={d.type} />
            <div className="min-w-0">
              <h1 className="truncate text-[28px] font-semibold leading-tight tracking-tight">{d.hostname}</h1>
              <p className="mt-0.5 text-[13px] text-text-2">
                {typeLabel(d.type)}{marcaModello !== 'n.d.' ? ` · ${marcaModello}` : ''}
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <StatusBadge status={d.uiStatus} />
                <span className="text-xs text-text-2">
                  {d.lastSeenAt ? `visto ${fmtRelative(d.lastSeenAt)}` : 'mai visto'}
                </span>
                <StaleIndicator stale={d.stale} lastSeenAt={d.lastSeenAt} />
                {/* v16.18 W19 — modalità di monitoraggio e stato SNMP (info per tutti) */}
                {d.monitorMode === 'ping' ? (
                  <Badge
                    variant="outline"
                    className="gap-1.5 border-border bg-raised text-text-2"
                    title="presenza ICMP: online/offline, nessun valore SNMP"
                  >
                    <RadioTower className="size-3" aria-hidden /> Monitoraggio ping
                  </Badge>
                ) : null}
                {d.snmpEnableState && SNMP_CHIP_META[d.snmpEnableState] ? (
                  <Badge variant="outline" className={SNMP_CHIP_META[d.snmpEnableState].cls} title={SNMP_CHIP_META[d.snmpEnableState].title}>
                    {SNMP_CHIP_META[d.snmpEnableState].label}
                  </Badge>
                ) : null}
              </div>
              {d.statusReason ? (
                <p className="mt-2 flex max-w-xl items-start gap-1.5 rounded-md bg-raised/50 px-2.5 py-2 text-xs leading-relaxed text-text-2">
                  <TriangleAlert className="mt-0.5 size-3.5 shrink-0 text-warn" aria-hidden />
                  {d.statusReason}
                </p>
              ) : null}
              <dl className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs">
                <MetaItem dt="IP" dd={<span className="num">{d.ip || 'n.d.'}</span>} />
                {d.locationName ? <MetaItem dt="Sede" dd={d.locationName} /> : null}
                <MetaItem dt="Marca / modello" dd={marcaModello} />
                <MetaItem dt="MAC" dd={<span className="num">{d.macAddress || 'n.d.'}</span>} />
                <MetaItem dt="Uptime" dd={<span className="num">{fmtUptime(d.uptimeSeconds)}</span>} />
                {freqLink ? <MetaItem dt="Frequenza · link" dd={<span className="num">{freqLink}</span>} /> : null}
              </dl>
            </div>
          </div>

          {/* azioni */}
          <div className="flex flex-wrap gap-2">
            {d.lat != null && d.lng != null ? (
              <Button
                variant="outline"
                size="sm"
                className="h-11 sm:h-9"
                onClick={() => { set({ reteTab: 'mappa' }); navigate('rete') }}
                title={`Mostra la sede ${d.locationName ?? ''} sulla mappa dell'impianto`}
              >
                <MapPin className="mr-1.5 size-3.5" aria-hidden /> Vedi su mappa
              </Button>
            ) : null}
            <Button
              variant="outline"
              size="sm"
              className="h-11 sm:h-9"
              onClick={() => { set({ alarmId: null }); navigate('allarmi') }}
              title={data.openAlerts.length > 0
                ? `${data.openAlerts.length} allarmi aperti su questo apparato`
                : 'Nessun allarme aperto su questo apparato'}
            >
              <Siren className="mr-1.5 size-3.5" aria-hidden /> Allarmi aperti
              <Badge variant="secondary" className="num ml-1.5 h-5 min-w-5 px-1 text-[11px]">
                {data.openAlerts.length}
              </Badge>
            </Button>
            <Button variant="outline" size="sm" className="h-11 sm:h-9" onClick={gotoEvents}>
              <History className="mr-1.5 size-3.5" aria-hidden /> Eventi
            </Button>
            {/* v16.18 W20 — «dove è collegato»: disponibile per TUTTI
                (lettura pura) e precompilata con i dati di questo apparato */}
            <Button
              variant="outline"
              size="sm"
              className="h-11 sm:h-9"
              onClick={() => setLocateDlgOpen(true)}
              title="Su quale switch e quale porta è collegato questo apparato (FDB + topologia)"
            >
              <MapPin className="mr-1.5 size-3.5" aria-hidden /> Dove è collegato
            </Button>
          </div>
        </div>
      </header>

      {/* ============ Riga KPI ============ */}
      <section aria-label="Metriche chiave">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {kpis.map((k) => (
            <KpiCard
              key={k.key}
              label={k.label}
              value={k.value}
              icon={k.icon}
              accent={k.accent}
              definition={k.definition}
              asOf={maxMetricTs}
            />
          ))}
        </div>
      </section>

      {/* ============ Striscia «catena di collegamento» ============ */}
      {data.parentChain.length > 1 ? (
        <nav
          aria-label="Catena di collegamento verso il gateway (dal dispositivo a monte)"
          className="rounded-lg border border-border bg-surface p-2"
        >
          <div className="flex items-center gap-1.5 overflow-x-auto scroll-thin">
            {data.parentChain.map((n, i) => {
              const isRootCause = data.rootCause?.id === n.id
              return (
                <span key={n.id} className="flex shrink-0 items-center gap-1.5">
                  {i > 0 ? <ChevronRight className="size-3.5 shrink-0 text-text-2" aria-hidden /> : null}
                  <button
                    onClick={() => openDevice(n.id)}
                    className={cn(
                      'flex min-h-11 items-center gap-1.5 rounded-md border px-2 py-1.5 text-xs font-medium transition-colors hover:border-link/50 hover:text-link',
                      isRootCause ? 'border-crit/50 bg-crit-soft' : 'border-border bg-raised/40',
                    )}
                    title={isRootCause
                      ? `${n.hostname} — primo punto guasto: non raggiungibile a monte`
                      : `${n.hostname} (${n.ip})`}
                  >
                    <StatusBadge status={n.uiStatus} size="xs" />
                    <span className="max-w-44 truncate">{n.hostname}</span>
                    {isRootCause ? (
                      <span className="shrink-0 text-[10px] font-semibold uppercase tracking-wide text-crit">
                        primo punto guasto
                      </span>
                    ) : null}
                  </button>
                </span>
              )
            })}
          </div>
          <p className="mt-1.5 px-1 text-[11px] text-text-2">
            Percorso del problema: dal dispositivo al gateway (albero di raggiungibilità, port rca-engine).
          </p>
        </nav>
      ) : null}

      {/* ============ Sezioni (Tabs) ============ */}
      <Tabs value={activeTab} onValueChange={(v) => set({ deviceTab: v })}>
        <TabsList className="w-full justify-start overflow-x-auto scroll-thin">
          {DEVICE_TABS.map((t) => (
            <TabsTrigger
              key={t.value}
              value={t.value}
              className="flex-none px-3"
              disabled={t.value === 'porte' && d.type !== 'SWITCH'}
              title={t.value === 'porte' && d.type !== 'SWITCH'
                ? 'Porte disponibili solo sugli switch (dati FDB/topologia)'
                : undefined}
            >
              {t.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* ---- Panoramica ---- */}
        <TabsContent value="panoramica" className="mt-3">
          <Card>
            <CardContent className="space-y-6 p-4 sm:p-6">
              <section aria-label="Stato e motivo" className="space-y-1.5">
                <h2 className="text-sm font-medium">Stato</h2>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge status={d.uiStatus} />
                  <span className="text-xs text-text-2">
                    {d.lastSeenAt ? `visto ${fmtRelative(d.lastSeenAt)}` : 'mai visto'}
                  </span>
                </div>
                {d.statusReason ? (
                  <p className="flex max-w-xl items-start gap-1.5 rounded-md bg-raised/50 px-2.5 py-2 text-xs leading-relaxed text-text-2">
                    <TriangleAlert className="mt-0.5 size-3.5 shrink-0 text-warn" aria-hidden />
                    {d.statusReason}
                  </p>
                ) : (
                  <p className="text-xs text-text-2">Nessun motivo di stato segnalato dall&apos;engine di monitoraggio.</p>
                )}
              </section>

              <section aria-label="Impatto a valle" className="space-y-1.5">
                <h2 className="text-sm font-medium">Impatto a valle</h2>
                {data.impact.devicesDownstream > 0 ? (
                  <p className="rounded-md bg-raised/50 px-2.5 py-2 text-xs leading-relaxed text-text-2">
                    <span className="num font-medium text-foreground">{data.impact.devicesDownstream}</span> dispositivi a valle
                    {data.impact.camerasDownstream > 0 ? (
                      <> · <span className="num font-medium text-foreground">{data.impact.camerasDownstream}</span> telecamere</>
                    ) : null}
                    {data.impact.offlineDownstream > 0 ? (
                      <> · <span className="num font-medium text-crit">{data.impact.offlineDownstream}</span> già offline</>
                    ) : null}
                  </p>
                ) : (
                  <p className="text-xs text-text-2">Nessun dispositivo a valle noto per questo apparato.</p>
                )}
              </section>

              <section aria-label="Allarmi aperti" className="space-y-1.5">
                <h2 className="text-sm font-medium">
                  Allarmi aperti <span className="num text-xs text-text-2">({data.openAlerts.length})</span>
                </h2>
                {data.openAlerts.length === 0 ? (
                  <p className="rounded-md bg-ok-soft px-2.5 py-2 text-xs text-ok">
                    Nessun allarme aperto su questo apparato.
                  </p>
                ) : (
                  <ul className="space-y-1.5">
                    {data.openAlerts.map((a) => (
                      <li key={a.id}>
                        <button
                          className="w-full rounded-md border border-border bg-raised/40 px-2.5 py-2 text-left transition-colors hover:border-link/50"
                          onClick={() => { set({ alarmId: a.id }); navigate('allarmi') }}
                          title="Apri nella vista Allarmi"
                        >
                          <div className="flex flex-wrap items-center gap-2">
                            <Badge variant="outline" className={SEVERITY_META[a.severity]?.cls ?? ''}>
                              {SEVERITY_META[a.severity]?.label ?? a.severity}
                            </Badge>
                            <span className="num text-[11px] text-text-2">aperto {fmtRelative(a.openedAt)}</span>
                            {a.occurrenceCount > 1 ? (
                              <span className="num text-[11px] text-text-2">× {a.occurrenceCount} occorrenze</span>
                            ) : null}
                          </div>
                          <p className="mt-1 text-xs leading-relaxed">{a.message}</p>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </section>

              <section aria-label="Eventi recenti" className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <h2 className="text-sm font-medium">Eventi recenti</h2>
                  {data.recentEvents.length > 0 ? (
                    <button
                      className="rounded text-xs text-link hover:underline"
                      onClick={() => set({ deviceTab: 'storico' })}
                    >
                      Vedi storico completo
                    </button>
                  ) : null}
                </div>
                {data.recentEvents.length === 0 ? (
                  <p className="text-xs text-text-2">Nessun evento registrato per questo apparato.</p>
                ) : (
                  <ul className="space-y-2">
                    {data.recentEvents.slice(0, 5).map((e) => <EventItem key={e.id} e={e} />)}
                  </ul>
                )}
              </section>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---- Collegamenti ---- */}
        <TabsContent value="collegamenti" className="mt-3">
          <Card>
            <CardContent className="space-y-6 p-4 sm:p-6">
              {data.links.length === 0 && data.stations.length === 0 && !data.uplinkAp ? (
                <EmptyState
                  title="Nessun collegamento noto"
                  description="Nessun TopologyLink coinvolge questo apparato: la copertura topologica dell'impianto non lo copre ancora."
                />
              ) : (
                <>
                  {data.links.length > 0 ? (
                    <section aria-label="Collegamenti" className="space-y-2">
                      <h2 className="text-sm font-medium">
                        Collegamenti <span className="num text-xs text-text-2">({data.links.length})</span>
                      </h2>
                      <p className="text-[11px] text-text-2">
                        ↑ verso monte (upstream) · ↓ verso valle (downstream). La confidenza dichiara come è stato ricostruito il collegamento.
                      </p>
                      <Table>
                        <TableCaption className="sr-only">
                          Collegamenti di {d.hostname}: direzione, peer, tipo, stato, confidenza, velocità e traffico
                        </TableCaption>
                        <TableHeader>
                          <TableRow>
                            <TableHead scope="col" className="w-[64px]">Verso</TableHead>
                            <TableHead scope="col">Peer</TableHead>
                            <TableHead scope="col">Tipo</TableHead>
                            <TableHead scope="col">Stato</TableHead>
                            <TableHead scope="col">Confidenza</TableHead>
                            <TableHead scope="col">Velocità</TableHead>
                            <TableHead scope="col">Traffico in / out</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {data.links.map((l) => (
                            <TableRow key={l.id} title={l.evidence || undefined}>
                              <TableCell>
                                <span
                                  className="flex items-center gap-1"
                                  title={l.direction === 'upstream' ? 'Verso monte (upstream)' : 'Verso valle (downstream)'}
                                >
                                  {l.direction === 'upstream' ? (
                                    <ArrowUp className="size-3.5" aria-hidden />
                                  ) : (
                                    <ArrowDown className="size-3.5" aria-hidden />
                                  )}
                                  <span className="sr-only">
                                    {l.direction === 'upstream' ? 'verso monte' : 'verso valle'}
                                  </span>
                                </span>
                              </TableCell>
                              <TableCell>
                                {l.peerId ? (
                                  <button
                                    className="text-left font-medium hover:text-link hover:underline"
                                    onClick={() => openDevice(l.peerId!)}
                                    title={`Apri ${l.peerHostname}`}
                                  >
                                    {l.peerHostname || 'n.d.'}
                                  </button>
                                ) : (
                                  <span className="text-text-2" title="Peer non inventariato nel DB">
                                    {l.peerHostname || 'n.d.'}
                                  </span>
                                )}
                              </TableCell>
                              <TableCell className="text-text-2">{l.linkType || 'n.d.'}</TableCell>
                              <TableCell className="text-text-2">{l.linkStatus || 'n.d.'}</TableCell>
                              <TableCell>
                                {l.confidence ? (
                                  <Badge variant="outline" className={CONFIDENCE_CLS[l.confidence] ?? ''}>
                                    {l.confidence}
                                  </Badge>
                                ) : (
                                  <span className="text-text-2">n.d.</span>
                                )}
                              </TableCell>
                              <TableCell className="num">
                                {l.speedMbps > 0 ? fmtMbps(l.speedMbps) : <span title="Velocità non nota">n.d.</span>}
                              </TableCell>
                              <TableCell>
                                {l.trafficUpdatedAt != null ? (
                                  <span className="flex flex-col">
                                    <span className="num">{fmtMbps(l.trafficInMbps)} / {fmtMbps(l.trafficOutMbps)}</span>
                                    <span className="num text-[10px] text-text-2" title={`Ultimo campione di traffico: ${fmtDateTimeFull(l.trafficUpdatedAt)}`}>
                                      {fmtRelative(l.trafficUpdatedAt)}
                                    </span>
                                  </span>
                                ) : (
                                  <span title="Traffico mai campionato su questo collegamento">n.d.</span>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </section>
                  ) : null}

                  {d.type === 'AP' ? (
                    <section aria-label="Stazioni agganciate" className="space-y-2">
                      <h2 className="text-sm font-medium">
                        Stazioni agganciate <span className="num text-xs text-text-2">({data.stations.length})</span>
                      </h2>
                      {data.stations.length === 0 ? (
                        <p className="text-xs text-text-2">Nessuna stazione agganciata a questo punto di accesso.</p>
                      ) : (
                        <ul className="divide-y divide-border rounded-lg border border-border">
                          {data.stations.map((st) => {
                            const tone = st.signalStrength != null ? signalTone(st.signalStrength) : null
                            return (
                              <li key={st.id} className="flex flex-wrap items-center gap-2 px-3 py-2 text-xs">
                                <StatusBadge status={st.uiStatus} size="xs" />
                                <button
                                  className="min-w-0 truncate font-medium hover:text-link hover:underline"
                                  onClick={() => openDevice(st.id)}
                                  title={`Apri ${st.hostname}`}
                                >
                                  {st.hostname}
                                </button>
                                <span
                                  className={cn('num ml-auto', tone?.cls)}
                                  title={tone
                                    ? `Segnale ${st.signalStrength} dBm — ${tone.label}`
                                    : 'Segnale non letto (n.d.)'}
                                >
                                  {fmtDbm(st.signalStrength)}
                                </span>
                                <span className="num text-text-2" title="Qualità link dichiarata dalla stazione">
                                  {fmtPct(st.linkQuality)}
                                </span>
                              </li>
                            )
                          })}
                        </ul>
                      )}
                    </section>
                  ) : null}

                  {d.type === 'STA' && data.uplinkAp ? (
                    <section aria-label="AP di uplink" className="space-y-1.5">
                      <h2 className="text-sm font-medium">AP di uplink</h2>
                      <p className="text-xs text-text-2">
                        <button
                          className="font-medium text-foreground hover:text-link hover:underline"
                          onClick={() => openDevice(data.uplinkAp!.id)}
                          title={`Apri ${data.uplinkAp.hostname}`}
                        >
                          {data.uplinkAp.hostname}
                        </button>
                        {' · segnale '}
                        <span
                          className={cn('num', data.uplinkAp.signalStrength != null ? signalTone(data.uplinkAp.signalStrength).cls : '')}
                          title={data.uplinkAp.signalStrength != null
                            ? `Segnale ${data.uplinkAp.signalStrength} dBm — ${signalTone(data.uplinkAp.signalStrength).label}`
                            : 'Segnale non letto (n.d.)'}
                        >
                          {fmtDbm(data.uplinkAp.signalStrength)}
                        </span>
                      </p>
                    </section>
                  ) : null}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---- Porte (16.5.0, W3-proroga: solo dati reali DB) ---- */}
        <TabsContent value="porte" className="mt-3">
          <PortsPanel
            hostname={d.hostname}
            isSwitch={d.type === 'SWITCH'}
            query={portsQuery}
            onOpenDevice={openDevice}
          />
        </TabsContent>

        {/* ---- Metriche ---- */}
        <TabsContent value="metriche" className="mt-3">
          <Card>
            <CardContent className="p-4 sm:p-6">
              {data.series.length === 0 ? (
                <EmptyState
                  icon={<Activity className="size-10" aria-hidden />}
                  title="Nessuna metrica campionata nelle ultime 24 h"
                  description="Nessun punto inventato: i grafici compariranno quando ci saranno campioni reali per questo apparato."
                />
              ) : (
                <div className="space-y-8">
                  {data.series.map((s) => <MetricChart key={s.metric} metric={s.metric} points={s.points} />)}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---- Configurazione ---- */}
        <TabsContent value="configurazione" className="mt-3">
          <Card>
            <CardContent className="p-4 sm:p-6">
              <dl className="grid grid-cols-1 gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
                <ConfigRow label="Firmware" value={d.firmwareVersion || 'n.d.'} />
                <ConfigRow label="Seriale" value="n.d." note="Campo non esposto dal contratto API v2." />
                <ConfigRow label="SSID" value={d.ssid || 'n.d.'} />
                <ConfigRow label="Modalità radio" value={d.radioMode || 'n.d.'} />
                <ConfigRow label="Canale / frequenza" value={d.currentFrequency ? `${d.currentFrequency} MHz` : 'n.d.'} />
                <ConfigRow label="Modalità link" value={d.linkMode || 'n.d.'} />
                <ConfigRow label="Tipo di collegamento" value={d.connectionType || 'n.d.'} />
                <ConfigRow label="Antenna" value={d.antennaType || 'n.d.'} />
                <ConfigRow label="Monitorato" value={d.monitored ? 'Sì' : 'No'} />
                <div className="flex flex-col gap-1 border-b border-border/60 pb-3">
                  <dt className="text-[11px] uppercase tracking-wide text-text-2">Stato credenziali</dt>
                  <dd className="flex flex-wrap items-center gap-2">
                    <CredentialBadge />
                    <span className="text-[11px] text-text-2">non verificabile dal browser</span>
                  </dd>
                </div>
                <ConfigRow label="Ultima sonda autenticata" value="n.d." note="Campo non esposto dal contratto API v2." />
              </dl>
              <p className="mt-4 flex max-w-2xl items-start gap-1.5 rounded-md bg-raised/50 px-2.5 py-2 text-[11px] leading-relaxed text-text-2">
                <Lock className="mt-0.5 size-3.5 shrink-0" aria-hidden />
                Le password e gli altri segreti non vengono mai inviati al browser: nessun campo
                segreto esiste nel contratto API.
              </p>
            </CardContent>
          </Card>

          {/* ---- v16.18 W19 — Attivazione SNMP assistita ---- */}
          <Card className="mt-3">
            <CardHeader className="px-4 sm:px-6">
              <CardTitle className="text-sm">Attivazione SNMP assistita</CardTitle>
              <CardDescription className="text-xs">
                Ricetta per-vendor scelta su marca, modello e tipo dell&apos;inventario: i comandi
                vengono mostrati in chiaro PRIMA della conferma.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 px-4 sm:px-6">
              <dl className="grid grid-cols-1 gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
                <ConfigRow
                  label="Stato"
                  value={
                    <span className="flex flex-wrap items-center gap-2">
                      <Badge
                        variant="outline"
                        className={SNMP_CHIP_META[data.snmpActivation.state]?.cls ?? 'bg-raised text-text-2 border-border'}
                        title={SNMP_CHIP_META[data.snmpActivation.state]?.title ?? 'Nessuna attivazione tentata su questo apparato'}
                      >
                        {SNMP_STATE_LABELS[data.snmpActivation.state] ?? data.snmpActivation.state}
                      </Badge>
                      {d.monitorMode === 'ping' ? (
                        <span className="text-[11px] text-text-2" title="presenza ICMP: online/offline, nessun valore SNMP">
                          monitoraggio ping
                        </span>
                      ) : null}
                    </span>
                  }
                />
                <ConfigRow label="Metodo" value={data.snmpActivation.method || '—'} />
                <ConfigRow
                  label="Ultimo tentativo"
                  value={<span className="num">{fmtDateTime(data.snmpActivation.at)}</span>}
                  note={data.snmpActivation.at ? fmtRelative(data.snmpActivation.at) : undefined}
                />
                <div className="flex flex-col gap-1 border-b border-border/60 pb-3 sm:col-span-2 lg:col-span-3">
                  <dt className="text-[11px] uppercase tracking-wide text-text-2">Nota</dt>
                  <dd className="text-sm">
                    {data.snmpActivation.note ? (
                      <span title={data.snmpActivation.note}>
                        {data.snmpActivation.note.length > 220
                          ? `${data.snmpActivation.note.slice(0, 220)}…`
                          : data.snmpActivation.note}
                      </span>
                    ) : '—'}
                  </dd>
                </div>
              </dl>

              {canAct ? (
                <div className="flex flex-wrap items-center gap-2">
                  {/* v16.18 W20 — sonda telemetria radio & salute (sola lettura):
                      CPU/RAM/SSID/segnale/CCQ/client/porte con provenance */}
                  <Button
                    variant="outline"
                    className="h-11 sm:h-9"
                    onClick={() => setTelemetryDlgOpen(true)}
                    title="Leggi via SNMP: CPU, RAM, SSID, segnale, CCQ, frequenza, velocità radio, client associati, porte ethernet — con la provenance di ogni valore"
                  >
                    <RadioTower className="mr-1.5 size-3.5" aria-hidden /> Sonda telemetria…
                  </Button>
                  <Button
                    className="h-11 sm:h-9"
                    onClick={() => setSnmpDlgOpen(true)}
                    title="Apre la finestra con la ricetta e i comandi in chiaro: nessun contatto con l'apparato prima della conferma"
                  >
                    Attiva SNMP assistita…
                  </Button>
                  {data.snmpActivation.state === 'ENABLED' || data.snmpActivation.state === 'ENABLED_UNVERIFIED' ? (
                    <Button
                      variant="outline"
                      className="h-11 sm:h-9"
                      disabled={snmpVerify.isPending}
                      onClick={() => snmpVerify.mutate()}
                      title="Sonda read-only con la community cifrata del dispositivo"
                    >
                      {snmpVerify.isPending ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden /> : null}
                      Riverifica SNMP
                    </Button>
                  ) : null}
                  {d.monitorMode === 'ping' ? (
                    <Button
                      variant="outline"
                      className="h-11 sm:h-9"
                      disabled={pingSweepOne.isPending}
                      onClick={() => pingSweepOne.mutate()}
                      title="Sonda di presenza su questo apparato: aggiorna online/offline e scrive i campioni di latenza"
                    >
                      {pingSweepOne.isPending ? <Loader2 className="mr-1.5 size-3.5 animate-spin" aria-hidden /> : null}
                      Spazzata ping
                    </Button>
                  ) : null}
                </div>
              ) : (
                <p className="text-[11px] text-text-2" role="note">
                  Sola lettura: l&apos;attivazione SNMP e le sonde di presenza sono azioni riservate
                  ai tecnici (l&apos;autorità resta al backend).
                </p>
              )}

              <p className="max-w-2xl rounded-md bg-raised/50 px-2.5 py-2 text-[11px] leading-relaxed text-text-2">
                La sonda FALCO-OS è in sola lettura: l&apos;attivazione è un attuatore separato che
                esegue i comandi del vendor SOLO dopo la tua conferma esplicita. Telecamere: basta
                il ping (online/offline).
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---- Storico ---- */}
        <TabsContent value="storico" className="mt-3">
          <div ref={storicoRef} className="scroll-mt-4">
            <Card>
              <CardContent className="p-4 sm:p-6">
                <div className="mb-4 flex flex-wrap items-baseline justify-between gap-2">
                  <h2 className="text-sm font-medium">Eventi del dispositivo</h2>
                  <p className="num text-[11px] text-text-2">
                    ultimi {data.recentEvents.length} eventi registrati
                  </p>
                </div>
                {data.recentEvents.length === 0 ? (
                  <EmptyState
                    title="Nessun evento registrato"
                    description="Nessun DeviceEvent presente per questo apparato nel database reale."
                  />
                ) : (
                  <ol className="space-y-4">
                    {data.recentEvents.map((e, i) => (
                      <li key={e.id} className="flex gap-3">
                        <span className="flex flex-col items-center">
                          <EventMarker eventType={e.eventType} />
                          {i < data.recentEvents.length - 1 ? (
                            <span className="w-px flex-1 bg-border" aria-hidden />
                          ) : null}
                        </span>
                        <div className="min-w-0 flex-1 pb-1">
                          <EventItem e={e} />
                        </div>
                      </li>
                    ))}
                  </ol>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* v16.18 W19 — finestra «Attivazione SNMP assistita» (controllata:
          la apre il pulsante della scheda; onDone invalida le query) */}
      <SnmpEnableDialog
        open={snmpDlgOpen}
        onOpenChange={setSnmpDlgOpen}
        deviceId={deviceId}
        onDone={() => {
          void queryClient.invalidateQueries({ queryKey: ['device-overview'] })
          void queryClient.invalidateQueries({ queryKey: ['devices'] })
        }}
      />

      {/* v16.18 W20 — finestra «Sonda telemetria radio & salute»:
          parte DA SOLA all'apertura; onDone invalida le query perché i
          KPI (CPU/RAM/segnale/SSID) si aggiornano con i valori letti. */}
      <RadioTelemetryDialog
        open={telemetryDlgOpen}
        onOpenChange={setTelemetryDlgOpen}
        deviceId={deviceId}
        onDone={() => {
          void queryClient.invalidateQueries({ queryKey: ['device-overview'] })
          void queryClient.invalidateQueries({ queryKey: ['devices'] })
        }}
      />

      {/* v16.18 W20 — finestra «Dove è collegato?» precompilata con i
          dati di QUESTO apparato (MAC → FDB → switch+porta). */}
      <LocateDialog
        open={locateDlgOpen}
        onOpenChange={setLocateDlgOpen}
        initialQuery={d.macAddress || d.ip || ''}
        onOpenDevice={openDevice}
      />
    </div>
  )
}

/* ---------------- Sotto-componenti ---------------- */

/** Icona di tipo apparato come nodo React (helper minuscolo: non è un
 * componente, evita la regola react-hooks/static-components). */
function typeIconNode(type: string, cls = 'size-3.5'): React.ReactNode {
  const Icon = typeIcon(type)
  return <Icon className={cls} aria-hidden />
}

/** Contenitore dell'icona di tipo (icona + bordo: il testo con il tipo
 * è nell'intestazione accanto, mai icona da sola). */
function TypeIconBox({ type }: { type: string }) {
  return (
    <span className="flex size-12 shrink-0 items-center justify-center rounded-lg border border-border bg-raised/60 text-text-2">
      {typeIconNode(type, 'size-5')}
    </span>
  )
}

function MetaItem({ dt, dd }: { dt: string; dd: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1.5">
      <dt className="text-text-2">{dt}</dt>
      <dd className="min-w-0 truncate font-medium">{dd}</dd>
    </div>
  )
}

function ConfigRow({ label, value, note }: { label: string; value: React.ReactNode; note?: string }) {
  return (
    <div className="flex flex-col gap-1 border-b border-border/60 pb-3">
      <dt className="text-[11px] uppercase tracking-wide text-text-2">{label}</dt>
      <dd className="text-sm">{value}</dd>
      {note ? <p className="text-[11px] text-text-2">{note}</p> : null}
    </div>
  )
}

/** Badge onesto dello stato credenziali. Il contratto API non espone MAI
 * credentialState (il campo esiste solo nel DB, lato server): l'unico
 * valore onesto renderizzabile dal browser è UNKNOWN. */
function CredentialBadge({ state }: { state?: string }) {
  const s = state ?? 'UNKNOWN'
  const Icon = s === 'OK' ? ShieldCheck : s === 'WRONG' ? ShieldX : s === 'MISSING' ? ShieldOff : HelpCircle
  return (
    <Badge
      variant="outline"
      className={CREDENTIAL_CLS[s] ?? CREDENTIAL_CLS.UNKNOWN}
      title="Lo stato delle credenziali non è disponibile nel contratto API: non verificabile dal browser"
    >
      <Icon className="size-3" aria-hidden /> {s}
    </Badge>
  )
}

function EventMarker({ eventType }: { eventType: string }) {
  const Icon = EVENT_ICONS[eventType] ?? Activity
  return (
    <span
      className="flex size-6 shrink-0 items-center justify-center rounded-full border border-border bg-raised text-text-2"
      title={eventType}
    >
      <Icon className="size-3" aria-hidden />
    </span>
  )
}

/** Voce di evento: icona + etichetta (mai icona da sola), transizione
 * oldValue → newValue quando presente, fonte e data completa. */
function EventItem({
  e,
}: {
  e: { id: string; eventType: string; oldValue: string; newValue: string; source: string; createdAt: number }
}) {
  const hasChange = !!(e.oldValue || e.newValue)
  return (
    <div className="min-w-0">
      <p className="text-xs font-medium">{EVENT_LABELS[e.eventType] ?? e.eventType}</p>
      {hasChange ? (
        <p className="num mt-0.5 text-xs text-text-2">
          <span>{e.oldValue || '—'}</span>
          {' → '}
          <span className="text-foreground">{e.newValue || '—'}</span>
        </p>
      ) : null}
      <p className="num mt-0.5 text-[11px] text-text-2">
        {fmtDateTimeFull(e.createdAt)}{e.source ? ` · fonte ${e.source}` : ''}
      </p>
    </div>
  )
}

/** Grafico di una metrica: SOLO punti reali della finestra 24h
 * (bucket 30 minuti lato server). Nessun punto inventato. */
function MetricChart({ metric, points }: { metric: string; points: Array<{ t: number; v: number }> }) {
  const p = usePalette()
  const meta = METRIC_META[metric] ?? { label: metric, unit: '' }
  return (
    <figure>
      <figcaption className="mb-1 flex flex-wrap items-baseline justify-between gap-2">
        <span className="text-sm font-medium">
          {meta.label}
          {meta.unit ? <span className="ml-1.5 text-xs font-normal text-text-2 num">({meta.unit})</span> : null}
        </span>
        <span className="num text-[11px] text-text-2">
          {points.length} campioni reali · bucket 30 min · 24 h
        </span>
      </figcaption>
      <div
        className="h-[180px]"
        role="img"
        aria-label={`${meta.label}: ${points.length} campioni reali nelle ultime 24 ore, in ${meta.unit || 'valori'}`}
      >
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={points} margin={{ top: 6, right: 12, bottom: 0, left: 0 }}>
            <CartesianGrid stroke={p.border} strokeDasharray="3 3" vertical={false} />
            <XAxis
              dataKey="t"
              type="number"
              scale="time"
              domain={['dataMin', 'dataMax']}
              tickFormatter={(t) => new Date(t).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}
              stroke={p.text2}
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: p.border }}
              tickMargin={6}
            />
            <YAxis width={48} stroke={p.text2} fontSize={10} tickLine={false} axisLine={false} unit={meta.unit} />
            <RTooltip
              cursor={{ stroke: p.controlBorder, strokeDasharray: '4 4' }}
              contentStyle={{
                background: p.surface, border: `1px solid ${p.border}`, borderRadius: 8,
                fontSize: 11, color: p.text, boxShadow: '0 8px 24px rgba(0,0,0,.45)',
              }}
              labelFormatter={(t) => fmtDateTime(Number(t))}
              formatter={(value) =>
                [value == null ? 'n.d.' : `${value} ${meta.unit}`, meta.label] as [string, string]}
            />
            <Line
              dataKey="v"
              type="monotone"
              stroke={p.info}
              strokeWidth={1.6}
              dot={{ r: 2 }}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </figure>
  )
}

/* ================================================================
 * Tab «Porte» (16.5.0, W3-proroga — parità v15 G3)
 * Dati REALI del DB per porta (union: topologia + FDB + utilizzazione).
 * Onestà: «n.d.» dove il dato non c'è; stato live/velocità corrente/
 * PoE richiedono SNMP (dichiarato); MAC elenco limitato a 20/porta
 * col conteggio REALE sempre visibile; serie congelata dichiarata.
 * ================================================================ */

function PortsPanel({
  hostname, isSwitch, query, onOpenDevice,
}: {
  hostname: string
  isSwitch: boolean
  query: {
    isLoading: boolean
    isError: boolean
    error: Error | null
    refetch: () => void
    data: DevicePortsPage | undefined
  }
  onOpenDevice: (id: string) => void
}) {
  if (!isSwitch) {
    return (
      <Card>
        <CardContent className="p-4 sm:p-6">
          <EmptyState
            icon={<Cable className="size-10" aria-hidden />}
            title="Porte disponibili solo sugli switch"
            description="La tabella per porta nasce da dati reali (topologia per porta, tabella MAC/FDB e serie di utilizzazione) che esistono solo per gli switch dell'impianto."
          />
        </CardContent>
      </Card>
    )
  }

  if (query.isLoading) {
    return (
      <Card>
        <CardContent className="p-4 sm:p-6 space-y-3">
          <div role="status" aria-busy="true" className="space-y-3">
            <span className="sr-only">Caricamento porte</span>
            <Skeleton className="h-5 w-72 rounded-md" />
            <Skeleton className="h-40 w-full rounded-lg" />
          </div>
        </CardContent>
      </Card>
    )
  }

  if (query.isError || !query.data) {
    return (
      <Card>
        <CardContent className="p-4 sm:p-6">
          <ErrorPanel
            message={(query.error as Error | undefined)?.message ?? 'Dati porte non disponibili'}
            onRetry={() => { void query.refetch() }}
          />
        </CardContent>
      </Card>
    )
  }

  const { ports, summary } = query.data
  const wd = summary.windowDeclared
  const utilCov = wd.utilCoverage
  const fdbFrozen = wd.fdbLastSeenAt != null && Date.now() - wd.fdbLastSeenAt > 24 * 3_600_000
  const unresolved = summary.macsTotal - summary.resolvedCount

  if (ports.length === 0) {
    return (
      <Card>
        <CardContent className="p-4 sm:p-6">
          <EmptyState
            icon={<Cable className="size-10" aria-hidden />}
            title="Nessuna porta con dati reali"
            description="Questo switch non ha né collegamenti con porta nota (TopologyLink), né osservazioni MAC (FdbObservation), né serie di utilizzazione: nessuna porta inventata."
          />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="p-4 sm:p-6 space-y-4">
        {/* Sintesi onesta dei numeri REALI */}
        <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 text-xs text-text-2">
          <span><strong className="num text-foreground">{summary.totalPorts}</strong> porte reali (union topologia + FDB + utilizzazione)</span>
          <span><strong className="num text-foreground">{summary.portsWithMacs}</strong> con MAC visti</span>
          <span><strong className="num text-foreground">{summary.macsTotal}</strong> osservazioni MAC</span>
          <span><strong className="num text-foreground">{summary.resolvedCount}</strong> in inventario · <strong className="num text-foreground">{unresolved}</strong> non in inventario</span>
          <span><strong className="num text-foreground">{summary.unattachedMacs}</strong> MAC su porte senza collegamento noto</span>
        </div>

        {fdbFrozen ? (
          <p className="rounded-md border border-warn/40 bg-warn-soft px-2.5 py-1.5 text-xs text-warn" role="note">
            Le osservazioni MAC (FDB) terminano al{' '}
            <span className="num">{fmtDateTimeFull(wd.fdbLastSeenAt ?? 0)}</span>: il prelievo reale è finito lì.
          </p>
        ) : null}

        <div
          className="max-h-96 overflow-y-auto scroll-thin [&_[data-slot=table-container]]:overflow-x-visible"
          role="region"
          aria-label={`Tabella porte di ${hostname}`}
          tabIndex={0}
        >
          <Table>
            <TableCaption className="sr-only">
              Porte di {hostname}: collegamento, evidenza, confidenza, velocità, MAC visti, utilizzazione e stato STP
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead scope="col" className="min-w-[110px]">Porta</TableHead>
                <TableHead scope="col" className="min-w-[150px]">Collegato a</TableHead>
                <TableHead scope="col" className="min-w-[130px]">Evidenza · confidenza</TableHead>
                <TableHead scope="col" className="min-w-[100px]">Velocità / duplex</TableHead>
                <TableHead scope="col" className="min-w-[90px]">MAC visti</TableHead>
                <TableHead scope="col" className="min-w-[110px]">Utilizzazione</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ports.map((row) => (
                <PortRowItem key={row.portName} row={row} onOpenDevice={onOpenDevice} />
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Dichiarazioni oneste */}
        <div className="space-y-1.5 rounded-md bg-raised/50 px-2.5 py-2 text-[11px] leading-relaxed text-text-2">
          <p>
            Stato della porta (up/down), velocità corrente e PoE richiedono lettura SNMP: in modalità
            riproduzione non sono disponibili. La velocità mostrata, quando presente, è quella{' '}
            <strong className="text-foreground">negoziata storicamente</strong> sul collegamento (dato del
            link, non lettura live); duplex e stato live restano «n.d.» senza lettura SNMP.
          </p>
          <p>
            Dati reali del DB: topologia per porta (TopologyLink, con evidenza e confidenza della
            ricostruzione) + tabella MAC (FdbObservation{wd.fdbLastSeenAt ? <> fino al <span className="num">{fmtDateTimeFull(wd.fdbLastSeenAt)}</span></> : ''})
            + STP (dot1dStp, dalla sonda Layer-2: stato della porta compare solo dove l&apos;ha letto la sonda — assenza = mai letto, non un errore)
            {utilCov ? (
              <> + serie utilizzazione con copertura reale <span className="num">{fmtDateTimeFull(utilCov.from)}</span> → <span className="num">{fmtDateTimeFull(utilCov.to)}</span></>
            ) : (
              <> + nessuna serie di utilizzazione per questo switch</>
            )}
            . Il produttore del MAC (OUI) non è incluso: risoluzione solo verso l&apos;inventario.
          </p>
          <p>Elenco MAC limitato a 20 per porta (il conteggio «MAC visti» è sempre il totale reale).</p>
        </div>
      </CardContent>
    </Card>
  )
}

/** Riga porta con elenco MAC espandibile (max 20, dichiarato). */
function PortRowItem({
  row, onOpenDevice,
}: {
  row: DevicePortRow
  onOpenDevice: (id: string) => void
}) {
  const [open, setOpen] = useState(false)
  const util = row.utilization
  return (
    <>
      <TableRow className={row.uplink ? 'bg-info-soft/40' : undefined}>
        <TableCell>
          <span className="flex flex-col items-start gap-1">
            <span className="num font-medium">{row.portName}</span>
            {row.uplink ? (
              <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40">Uplink</Badge>
            ) : null}
            {row.stp ? (
              <span className="flex flex-wrap items-center gap-1">
                <Badge
                  variant="outline"
                  className={STP_STATE_CLS[row.stp.portState] ?? 'border-border bg-raised text-text-2'}
                  title={`STP ${row.stp.portState || 'n.d.'} · bridge designato ${row.stp.designatedBridgeMac || 'n.d.'}`}
                >
                  STP {row.stp.portState || 'n.d.'}
                </Badge>
                {row.stp.isRootPort ? (
                  <Badge
                    variant="outline"
                    className="bg-info-soft text-info border-info/40"
                    title="Porta verso la root bridge dello spanning tree"
                  >
                    root port
                  </Badge>
                ) : null}
              </span>
            ) : null}
          </span>
        </TableCell>
        <TableCell>
          {row.connectedTo ? (
            <button
              type="button"
              className="text-left font-medium hover:text-link hover:underline"
              onClick={() => onOpenDevice(row.connectedTo!.deviceId)}
              title={`Apri ${row.connectedTo.hostname} (${typeLabel(row.connectedTo.type)})${row.connectedTo.ip ? ` · ${row.connectedTo.ip}` : ''}`}
            >
              {row.connectedTo.hostname}
            </button>
          ) : (
            <span className="text-text-2" title="Nessun collegamento noto per questa porta (topologia non coperta)">n.d.</span>
          )}
        </TableCell>
        <TableCell>
          <span className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-text-2">{row.evidence || 'n.d.'}</span>
            {row.confidence ? (
              <Badge variant="outline" className={CONFIDENCE_CLS[row.confidence] ?? ''}>
                {row.confidence}
              </Badge>
            ) : null}
          </span>
        </TableCell>
        <TableCell className="num text-text-2">
          {row.speedMbps > 0 || row.duplex ? (
            <span>
              {row.speedMbps > 0 ? fmtMbps(row.speedMbps) : 'n.d.'}
              {row.duplex ? <span title="Duplex dal collegamento (dato del link)"> · {row.duplex}</span> : ''}
            </span>
          ) : (
            <span title="Velocità non nota: la lettura live richiede SNMP">n.d.</span>
          )}
        </TableCell>
        <TableCell>
          {row.macsSeen > 0 ? (
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              aria-expanded={open}
              className="inline-flex min-h-8 items-center gap-1 rounded px-1.5 font-medium text-link transition-colors hover:underline"
              title={open ? 'Nascondi i MAC visti su questa porta' : `Mostra i MAC visti sulla porta ${row.portName} (max 20)`}
            >
              <span className="num">{row.macsSeen}</span>
              <ChevronDown className={cn('size-3.5 transition-transform', open && 'rotate-180')} aria-hidden />
              <span className="sr-only">MAC visti sulla porta {row.portName}</span>
            </button>
          ) : (
            <span className="num text-text-2" title="Nessun MAC appreso su questa porta (FDB)">0</span>
          )}
        </TableCell>
        <TableCell>
          {util ? (
            <span className="flex flex-col">
              <span className="num" title={`Ultimo campione della serie port_utilization:${row.portName} (valore descrittivo, nessuna soglia)`}>
                {util.last.toFixed(2)}%
              </span>
              <span className="num text-[10px] text-text-2" title={fmtDateTimeFull(util.at)}>
                {fmtRelative(util.at)}
              </span>
            </span>
          ) : (
            <span className="text-text-2" title="Nessun campione della serie utilizzazione per questa porta">n.d.</span>
          )}
        </TableCell>
      </TableRow>
      {open ? (
        <TableRow className="bg-raised/30 hover:bg-raised/30">
          <TableCell colSpan={6}>
            <p className="mb-1.5 text-[11px] font-medium uppercase tracking-wide text-text-2">
              MAC visti sulla porta <span className="num">{row.portName}</span> — {row.macsSeen} totali,
              elenco limitato a {row.macs.length}
            </p>
            <ul className="divide-y divide-border/60">
              {row.macs.map((m) => (
                <li key={m.mac} className="flex flex-wrap items-center gap-2 py-1.5 text-xs">
                  <span className="num font-medium">{m.display}</span>
                  {m.resolved && m.hostname ? (
                    m.deviceId ? (
                      <button
                        type="button"
                        className="font-medium hover:text-link hover:underline"
                        onClick={() => onOpenDevice(m.deviceId!)}
                        title={`Apri ${m.hostname} (MAC risolto nell'inventario)`}
                      >
                        {m.hostname}
                      </button>
                    ) : (
                      <span>{m.hostname}</span>
                    )
                  ) : (
                    <span className="text-text-2" title="MAC non presente in Device.macAddress/extraMacs dell'inventario">
                      non in inventario
                    </span>
                  )}
                  <span className="num ml-auto text-[11px] text-text-2" title="Ultima osservazione FDB su questa porta">
                    {fmtRelative(m.lastSeenAt)}
                  </span>
                </li>
              ))}
            </ul>
          </TableCell>
        </TableRow>
      ) : null}
    </>
  )
}
