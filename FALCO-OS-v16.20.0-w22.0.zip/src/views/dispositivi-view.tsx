/* ================================================================
 * FALCO-OS v16 — Vista «Dispositivi» (§6.5)
 * Inventario dell'impianto: ricerca testuale, famiglia, stato e
 * ordinamento filtrati LATO SERVER (API /devices), paginazione
 * server-side, tabella virtualizzata (TanStack Table + Virtual).
 * Se lo store ha un deviceId la vista mostra la SCHEA INTERA
 * (DevicePage §6.4) al posto della tabella; il quick-look, emettendo
 * l'evento window 'falco:open-device-page', forza il passaggio.
 * Realtime (§2.2): ogni 'noc:tick' invalida ['devices'] e
 * ['noc-summary'] — nessun polling aggressivo.
 * Onestà del dato: «n.d.» per i valori mancanti, MAI colori da soli
 * (sempre title/badge con testo), CSV dichiarato «pagina corrente».
 * ================================================================ */

'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  flexRender, getCoreRowModel, useReactTable,
  type ColumnDef, type OnChangeFn, type SortingState,
} from '@tanstack/react-table'
import { useVirtualizer } from '@tanstack/react-virtual'
import { useSession } from 'next-auth/react'
import {
  ArrowDown, ArrowUp, ArrowUpDown, ArrowUpRight, ChevronLeft, ChevronRight, Download, Eye,
  HelpCircle, Loader2, MoreHorizontal, Network, Radio, Router, Search, Server, Video,
  type LucideIcon,
} from 'lucide-react'
import { toast } from 'sonner'

import { api, ApiError, type DeviceRow } from '@/lib/client/api'
import { subscribeRealtime } from '@/lib/client/socket'
import { useApp } from '@/lib/client/store'
import {
  STATUS_META, fmtDateTimeFull, fmtDbm, fmtNumber, fmtPct, fmtRelative, fmtUptime, typeLabel,
} from '@/lib/client/format'
import { PageHeader } from '@/components/page-header'
import { StaleIndicator } from '@/components/stale-indicator'
import { EmptyState, ErrorPanel, LoadingRows } from '@/components/states'
import { StatusBadge } from '@/components/status-badge'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { TableCell, TableHead, TableRow } from '@/components/ui/table'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import DevicePage from '@/views/device-page'
import { cn } from '@/lib/utils'

/* ---------------- Costanti ---------------- */

const PAGE_SIZE = 50
const ROW_HEIGHT = 56
const SORT_KEYS = ['hostname', 'ip', 'type', 'status', 'signal', 'lastSeen', 'uptime'] as const
type SortKey = (typeof SORT_KEYS)[number]

type Family = 'all' | 'network' | 'radio' | 'cameras'

const FAMILY_OPTIONS: Array<{ value: Family; label: string }> = [
  { value: 'all', label: 'Tutti' },
  { value: 'network', label: 'Apparati di rete' },
  { value: 'radio', label: 'Radio' },
  { value: 'cameras', label: 'Telecamere' },
]

const STATUS_OPTIONS: Array<{ value: string; label: string }> = [
  { value: 'all', label: 'Tutti gli stati' },
  { value: 'ONLINE', label: 'Online' },
  { value: 'DEGRADED', label: 'Degradato' },
  { value: 'OFFLINE', label: 'Offline' },
  { value: 'UNKNOWN', label: 'Sconosciuto' },
  { value: 'NOT_MONITORED', label: 'Non monitorato' },
]

/** Larghezze colonna (table-fixed): «Nome» assorbe lo spazio residuo. */
const COL_WIDTH: Record<string, string> = {
  status: 'w-[124px]',
  type: 'w-[138px]',
  ip: 'w-[116px]',
  model: 'w-[150px]',
  uptime: 'w-[100px]',
  signal: 'w-[104px]',
  lastSeen: 'w-[138px]',
  actions: 'w-[64px]',
}

/* ---------------- Helper ---------------- */

function toSortKey(id: string | undefined): SortKey {
  return (SORT_KEYS as readonly string[]).includes(id ?? '') ? (id as SortKey) : 'hostname'
}

function typeIcon(type: string): LucideIcon {
  switch (type?.toUpperCase()) {
    case 'AP': case 'STA': return Radio
    case 'CAMERA': case 'LPR': case 'NVR': return Video
    case 'GATEWAY': case 'ROUTER': return Router
    case 'SERVER': return Server
    case 'SWITCH': return Network
    default: return HelpCircle
  }
}

/** Soglie segnale radio (port link-detail: −65/−75/−85 dBm).
 * MAI solo colore: ogni valore porta anche un title esplicativo. */
function signalTone(v: number): { cls: string; label: string } {
  if (v >= -65) return { cls: 'text-ok', label: 'buono (≥ −65 dBm)' }
  if (v >= -75) return { cls: 'text-foreground', label: 'fascia di attenzione (−75…−65 dBm)' }
  if (v >= -85) return { cls: 'text-warn', label: 'debole (sotto −75 dBm)' }
  return { cls: 'text-crit', label: 'molto debole (sotto −85 dBm)' }
}

/** v16.18 W19 — chip compatte sotto lo stato (attivazione SNMP /
 * monitoraggio ping): testo + title, mai colore da solo. Dimensioni
 * volutamente minuscole per non rompere la densità della tabella. */
function SnmpMiniChip({ label, cls, title }: { label: string; cls: string; title: string }) {
  return (
    <Badge variant="outline" className={cn('h-4 gap-0.5 px-1.5 text-[10px] leading-none', cls)} title={title}>
      {label}
    </Badge>
  )
}

const CSV_HEADERS = [
  'Hostname', 'IP', 'Tipo', 'Stato', 'Motivo stato', 'Marca', 'Modello',
  'Segnale (dBm)', 'Qualità link', 'Uptime', 'Ultima vista', 'Sede',
]

function csvEscape(v: string): string {
  return `"${v.replace(/"/g, '""')}"`
}

/** Esporta SOLO i dispositivi della pagina corrente (dati REALI caricati):
 * dichiarato nel title del pulsante e nel toast di conferma. */
function exportDevicesCsv(items: DeviceRow[], page: number) {
  const lines = [CSV_HEADERS.map(csvEscape).join(';')]
  for (const d of items) {
    lines.push([
      d.hostname,
      d.ip || 'n.d.',
      typeLabel(d.type),
      STATUS_META[d.uiStatus]?.label ?? d.uiStatus,
      d.statusReason ?? 'n.d.',
      d.brand || 'n.d.',
      d.model || 'n.d.',
      d.signalPresent ? String(d.signalStrength) : 'n.d.',
      fmtPct(d.linkQuality),
      fmtUptime(d.uptimeSeconds),
      d.lastSeenAt ? fmtDateTimeFull(d.lastSeenAt) : 'mai',
      d.locationName ?? 'n.d.',
    ].map(csvEscape).join(';'))
  }
  const blob = new Blob([`\ufeff${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '')
  a.href = url
  a.download = `falco-dispositivi-pagina-${page}-${stamp}.csv`
  document.body.appendChild(a)
  a.click()
  a.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 5_000)
  toast.success(`CSV esportato: ${items.length} dispositivi della pagina ${page} (dati reali caricati)`)
}

/* ---------------- Vista ---------------- */

export default function DispositiviView() {
  const deviceId = useApp((s) => s.deviceId)

  /* Il quick-look (renderizzato a livello pagina) emette 'falco:open-device-page'
   * quando l'utente chiede la scheda intera: il listener acconsente al
   * passaggio. Nessun reset necessario: la scheda richiede comunque un
   * deviceId, che lo store azzera già con openDevice(null). */
  const [schedaForced, setSchedaForced] = useState(false)
  useEffect(() => {
    const onOpenScheda = () => setSchedaForced(true)
    window.addEventListener('falco:open-device-page', onOpenScheda)
    return () => window.removeEventListener('falco:open-device-page', onOpenScheda)
  }, [])

  const showScheda = deviceId != null || schedaForced
  if (showScheda && deviceId != null) return <DevicePage deviceId={deviceId} />
  return <DevicesInventory />
}

/* ---------------- Inventario (tabella) ---------------- */

function DevicesInventory() {
  const openDevice = useApp((s) => s.openDevice)
  const queryClient = useQueryClient()

  /* --- v16.18 W19 — ruolo: il CLIENTE è in sola lettura (autorità
   * permessi = backend); la spazzata ping è azione da TECNICO+. --- */
  const { data: session } = useSession()
  const canAct = !!session?.user?.role && session.user.role !== 'CLIENTE'

  /* Spazzata ping di TUTTI i dispositivi monitorMode='ping' del plant
   * attivo (telecamere): campioni reali + stato online/offline onesto. */
  const pingSweep = useMutation({
    mutationFn: () => api.monitorPingSweep({}),
    onSuccess: (res) => {
      if (res.swept === 0) {
        toast.info('Nessun apparato in modalità ping', {
          description: 'Nessuna telecamera dichiarata «presenza» in questo impianto: nulla da sondare.',
        })
      } else {
        toast.success(`Spazzata ping: ${res.swept} apparati, ${res.alive} online`)
      }
      void queryClient.invalidateQueries({ queryKey: ['devices'] })
    },
    onError: (e) => {
      const info = e instanceof ApiError ? { message: e.message, code: e.code as string } : { message: e instanceof Error ? e.message : 'Errore sconosciuto' }
      toast.error('Spazzata ping non riuscita', {
        description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}`,
      })
    },
  })

  /* --- filtri, ordinamento e pagina (stato UI locale) --- */
  const [qInput, setQInput] = useState('')
  const [q, setQ] = useState('')
  const [family, setFamily] = useState<Family>('all')
  const [status, setStatus] = useState('all')
  const [page, setPage] = useState(1)
  const [sorting, setSorting] = useState<SortingState>([{ id: 'hostname', desc: false }])
  const sort = toSortKey(sorting[0]?.id)
  const dir: 'asc' | 'desc' = sorting[0]?.desc ? 'desc' : 'asc'

  /* ricerca testuale con debounce 300 ms (filtra lato SERVER) */
  useEffect(() => {
    const t = window.setTimeout(() => { setQ(qInput); setPage(1) }, 300)
    return () => window.clearTimeout(t)
  }, [qInput])

  /* --- intestazione: impianto, totale e modalità dal summary (reali) --- */
  const summary = useQuery({ queryKey: ['noc-summary'], queryFn: () => api.summary(), staleTime: 30_000 })
  const health = useQuery({ queryKey: ['system-health'], queryFn: () => api.systemHealth(), staleTime: 60_000 })

  /* --- dispositivi: filtri/ordinamento/pagina passati all'API --- */
  const devices = useQuery({
    queryKey: ['devices', { q, family, status, page, sort, dir, pageSize: PAGE_SIZE }],
    queryFn: () => api.devices({
      q: q || undefined,
      family,
      status: status === 'all' ? undefined : status,
      page,
      pageSize: PAGE_SIZE,
      sort,
      dir,
    }),
    placeholderData: keepPreviousData,
    staleTime: 15_000,
  })

  const items = devices.data?.data.items ?? []
  const total = devices.data?.data.total ?? 0
  const pageCount = devices.data?.data.pageCount ?? 1

  /* --- realtime: ogni tick invalida le query di questa vista --- */
  useEffect(() => {
    const dispose = subscribeRealtime({
      onTick: () => {
        void queryClient.invalidateQueries({ queryKey: ['devices'] })
        void queryClient.invalidateQueries({ queryKey: ['noc-summary'] })
      },
    })
    return dispose
  }, [queryClient])

  /* --- colonne (TanStack Table, ordinamento manuale = server) --- */
  const columns = useMemo<ColumnDef<DeviceRow>[]>(() => [
    {
      id: 'status',
      accessorKey: 'uiStatus',
      header: 'Stato',
      cell: ({ row }) => {
        const d = row.original
        /* v16.18 W19 — chip compatte di attivazione SNMP / ping SOLO
         * quando significative (stato diverso da '' o modalità ping). */
        const chips = (
          <div className="inline-flex flex-wrap gap-1">
            {d.snmpEnableState === 'MANUAL_REQUIRED' ? (
              <SnmpMiniChip
                label="SNMP manuale"
                cls="border-warn/40 bg-warn-soft text-warn"
                title="attivazione da fare dal pannello vendor — vedi scheda"
              />
            ) : null}
            {d.snmpEnableState === 'FAILED' ? (
              <SnmpMiniChip
                label="SNMP KO"
                cls="border-crit/40 bg-crit-soft text-crit-text"
                title="ultimo tentativo di attivazione SNMP non riuscito — vedi scheda"
              />
            ) : null}
            {d.monitorMode === 'ping' ? (
              <SnmpMiniChip
                label="ping"
                cls="border-border bg-raised text-text-2"
                title="monitoraggio presenza"
              />
            ) : null}
          </div>
        )
        const hasChips = d.snmpEnableState === 'MANUAL_REQUIRED'
          || d.snmpEnableState === 'FAILED'
          || d.monitorMode === 'ping'
        return d.statusReason ? (
          <div className="flex min-w-0 flex-col items-start gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <span className="inline-flex cursor-help">
                  <StatusBadge status={d.uiStatus} />
                </span>
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-64 font-normal leading-relaxed">
                {d.statusReason}
              </TooltipContent>
            </Tooltip>
            {hasChips ? chips : null}
          </div>
        ) : (
          <div className="flex min-w-0 flex-col items-start gap-1">
            <StatusBadge status={d.uiStatus} />
            {hasChips ? chips : null}
          </div>
        )
      },
    },
    {
      id: 'hostname',
      accessorKey: 'hostname',
      header: 'Nome',
      cell: ({ row }) => {
        const d = row.original
        return (
          <div className="min-w-0">
            <p className="truncate font-medium">{d.hostname}</p>
            <p className="num truncate text-xs text-text-2">{d.macAddress || 'n.d.'}</p>
          </div>
        )
      },
    },
    {
      id: 'type',
      accessorKey: 'type',
      header: 'Tipo',
      cell: ({ row }) => {
        const d = row.original
        const Icon = typeIcon(d.type)
        return (
          <span className="flex items-center gap-1.5">
            <Icon className="size-3.5 shrink-0 text-text-2" aria-hidden />
            <span className="truncate">{typeLabel(d.type)}</span>
          </span>
        )
      },
    },
    {
      id: 'ip',
      accessorKey: 'ip',
      header: 'IP',
      cell: ({ row }) => <span className="num">{row.original.ip || 'n.d.'}</span>,
    },
    {
      id: 'model',
      accessorFn: (d) => [d.brand, d.model].filter(Boolean).join(' '),
      header: 'Modello',
      enableSorting: false,
      cell: ({ row }) => {
        const d = row.original
        const m = [d.brand, d.model].filter(Boolean).join(' ')
        return <span className="truncate text-text-2">{m || 'n.d.'}</span>
      },
    },
    {
      id: 'uptime',
      accessorKey: 'uptimeSeconds',
      header: 'Uptime',
      cell: ({ row }) => <span className="num">{fmtUptime(row.original.uptimeSeconds)}</span>,
    },
    {
      id: 'signal',
      accessorKey: 'signalStrength',
      header: 'Segnale',
      cell: ({ row }) => {
        const d = row.original
        if (d.type !== 'AP' && d.type !== 'STA') {
          return (
            <span className="text-text-2" title="Segnale radio non applicabile a questo tipo di apparato">—</span>
          )
        }
        if (!d.signalPresent) {
          return <span title="Segnale non letto (n.d.)">n.d.</span>
        }
        const tone = signalTone(d.signalStrength)
        return (
          <span className={cn('num', tone.cls)} title={`Segnale ${d.signalStrength} dBm — ${tone.label}`}>
            {fmtDbm(d.signalStrength)}
          </span>
        )
      },
    },
    {
      id: 'lastSeen',
      accessorKey: 'lastSeenAt',
      header: 'Ultimo agg.',
      cell: ({ row }) => {
        const d = row.original
        return (
          <div className="flex min-w-0 flex-col items-start gap-0.5">
            <span className="num">{d.lastSeenAt ? fmtRelative(d.lastSeenAt) : 'mai visto'}</span>
            {d.lastSeenAt ? <StaleIndicator stale={d.stale} lastSeenAt={d.lastSeenAt} /> : null}
          </div>
        )
      },
    },
    {
      id: 'actions',
      header: () => <span className="sr-only">Azioni</span>,
      enableSorting: false,
      cell: ({ row }) => {
        const d = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-8"
                aria-label={`Azioni per ${d.hostname}`}
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="size-4" aria-hidden />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onSelect={() => {
                  openDevice(d.id)
                  window.dispatchEvent(new CustomEvent('falco:open-device-page'))
                }}
              >
                <ArrowUpRight className="size-4" aria-hidden /> Apri scheda
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => openDevice(d.id)}>
                <Eye className="size-4" aria-hidden /> Quick-look
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      },
    },
  ], [openDevice])

  const handleSortingChange: OnChangeFn<SortingState> = (updater) => {
    setSorting((prev) => (typeof updater === 'function' ? updater(prev) : updater))
  }

  const table = useReactTable({
    data: items,
    columns,
    state: { sorting },
    onSortingChange: handleSortingChange,
    getCoreRowModel: getCoreRowModel(),
    manualSorting: true,
    manualPagination: true,
    rowCount: total,
  })

  /* --- virtualizzazione righe --- */
  const containerRef = useRef<HTMLDivElement>(null)
  const rows = table.getRowModel().rows
  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => containerRef.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 8,
  })
  const virtualRows = rowVirtualizer.getVirtualItems()
  const paddingTop = virtualRows.length > 0 ? virtualRows[0]?.start ?? 0 : 0
  const paddingBottom = virtualRows.length > 0
    ? rowVirtualizer.getTotalSize() - (virtualRows[virtualRows.length - 1]?.end ?? 0)
    : 0

  /* scroll in cima quando cambiano filtri, ordinamento o pagina */
  useEffect(() => {
    containerRef.current?.scrollTo({ top: 0 })
  }, [page, q, family, status, sort, dir])

  const resetFilters = () => {
    setQInput('')
    setQ('')
    setFamily('all')
    setStatus('all')
    setPage(1)
    setSorting([{ id: 'hostname', desc: false }])
  }

  /* sottotitolo: totale dell'impianto dal summary (senza filtri attivi
   * accetta anche il totale della pagina dispositivi come ripiego) */
  const plant = summary.data?.data.plant
  const noFilters = !q && family === 'all' && status === 'all'
  const headerTotal = summary.data?.data.devices.total ?? (noFilters ? total : null)
  const subtitle = plant && headerTotal != null
    ? `${fmtNumber(headerTotal)} dispositivi · impianto ${plant.name} (${plant.comune})`
    : plant
      ? `Impianto ${plant.name} (${plant.comune})`
      : 'Inventario dispositivi'

  return (
    <div>
      <PageHeader
        title="Dispositivi"
        subtitle={subtitle}
        mode={summary.data?.mode}
        importedAt={health.data?.data.replay.importedAt ?? null}
      />

      {/* --- Filtri sopra la tabella --- */}
      <div className="mb-3 flex flex-wrap items-center gap-2" aria-label="Filtri dell'inventario">
        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-text-2" aria-hidden />
          <Input
            type="search"
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            placeholder="Cerca hostname, IP, MAC, modello…"
            aria-label="Cerca dispositivi per testo"
            className="h-11 pl-8 sm:h-9"
          />
        </div>

        <ToggleGroup
          type="single"
          variant="outline"
          value={family}
          onValueChange={(v) => {
            if (v === 'all' || v === 'network' || v === 'radio' || v === 'cameras') {
              setFamily(v)
              setPage(1)
            }
          }}
          aria-label="Filtro famiglia di apparati"
        >
          {FAMILY_OPTIONS.map((o) => (
            <ToggleGroupItem
              key={o.value}
              value={o.value}
              aria-label={o.label}
              className="h-11 px-3 text-xs sm:h-9"
            >
              {o.label}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>

        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1) }}>
          <SelectTrigger
            size="sm"
            className="h-11 w-[180px] sm:h-9"
            aria-label="Filtro stato dispositivo"
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="ml-auto flex flex-wrap items-center justify-end gap-2">
          {/* v16.18 W19 — spazzata ping (TECNICO+): etichetta compatta su mobile */}
          {canAct ? (
            <Button
              variant="outline"
              size="sm"
              className="h-11 sm:h-9"
              disabled={pingSweep.isPending}
              onClick={() => pingSweep.mutate()}
              title="Sonda di presenza ICMP sui dispositivi dichiarati in modalità ping (telecamere): aggiorna online/offline e scrive i campioni di latenza"
            >
              {pingSweep.isPending
                ? <Loader2 className="size-3.5 animate-spin" aria-hidden />
                : <Radio className="size-3.5" aria-hidden />}
              <span className="hidden sm:inline">Spazzata ping</span>
              <span className="sr-only sm:hidden">Spazzata ping sui dispositivi in modalità ping</span>
            </Button>
          ) : null}
          <Button
            variant="outline"
            size="sm"
            className="h-11 sm:h-9"
            disabled={items.length === 0}
            onClick={() => exportDevicesCsv(items, page)}
            title="Esporta in CSV i dispositivi della PAGINA CORRENTE (dati reali caricati, non l'intero inventario)"
          >
            <Download className="mr-1.5 size-3.5" aria-hidden /> Esporta CSV
          </Button>
        </div>
      </div>

      {/* --- Tabella --- */}
      <div className="rounded-lg border border-border bg-surface">
        {devices.isLoading ? (
          <LoadingRows rows={10} className="p-4" />
        ) : devices.isError ? (
          <div className="p-4">
            <ErrorPanel
              message={(devices.error as Error).message}
              code={devices.error instanceof ApiError ? devices.error.code : undefined}
              onRetry={() => { void devices.refetch() }}
            />
          </div>
        ) : items.length === 0 ? (
          <div className="p-4">
            <EmptyState
              title="Nessun dispositivo con questi filtri"
              description="Nessuna corrispondenza nell'inventario dell'impianto per ricerca, famiglia o stato selezionati."
              action={
                <Button variant="outline" size="sm" className="h-11 sm:h-9" onClick={resetFilters}>
                  Azzera filtri
                </Button>
              }
            />
          </div>
        ) : (
          <div
            ref={containerRef}
            className={cn(
              'relative max-h-[calc(100vh-320px)] overflow-auto scroll-thin',
              devices.isFetching && 'opacity-60 transition-opacity',
            )}
          >
            <table
              className="w-full min-w-[1000px] table-fixed caption-bottom text-sm"
              aria-rowcount={total}
            >
              <caption className="sr-only">
                Inventario dispositivi dell&apos;impianto, pagina {page} di {pageCount} su {total} risultati totali
              </caption>
              <thead>
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((header) => {
                      const canSort = header.column.getCanSort()
                      const sorted = header.column.getIsSorted()
                      const isActions = header.column.id === 'actions'
                      return (
                        <TableHead
                          key={header.id}
                          scope="col"
                          aria-sort={sorted === 'asc' ? 'ascending' : sorted === 'desc' ? 'descending' : undefined}
                          className={cn(
                            'sticky top-0 z-10 border-b border-border bg-surface',
                            COL_WIDTH[header.column.id],
                            isActions && 'text-right',
                          )}
                        >
                          {canSort ? (
                            <button
                              type="button"
                              className="flex h-8 items-center gap-1 rounded px-1 font-medium transition-colors hover:text-link"
                              onClick={header.column.getToggleSortingHandler()}
                              title={`Ordina per ${String(header.column.columnDef.header ?? header.column.id)}`}
                            >
                              {flexRender(header.column.columnDef.header, header.getContext())}
                              {sorted === 'asc' ? (
                                <ArrowUp className="size-3" aria-hidden />
                              ) : sorted === 'desc' ? (
                                <ArrowDown className="size-3" aria-hidden />
                              ) : (
                                <ArrowUpDown className="size-3 opacity-40" aria-hidden />
                              )}
                              <span className="sr-only">
                                {sorted === 'asc'
                                  ? '(ordinamento crescente)'
                                  : sorted === 'desc'
                                    ? '(ordinamento decrescente)'
                                    : '(clic per ordinare)'}
                              </span>
                            </button>
                          ) : (
                            flexRender(header.column.columnDef.header, header.getContext())
                          )}
                        </TableHead>
                      )
                    })}
                  </tr>
                ))}
              </thead>
              <tbody>
                {paddingTop > 0 && (
                  <tr aria-hidden style={{ height: paddingTop }}>
                    <td colSpan={columns.length} className="p-0" />
                  </tr>
                )}
                {virtualRows.map((vr) => {
                  const row = rows[vr.index]
                  if (!row) return null
                  const d = row.original
                  return (
                    <TableRow
                      key={d.id}
                      tabIndex={0}
                      className="h-14 cursor-pointer hover:bg-raised/40 focus-visible:bg-raised/40"
                      onClick={() => openDevice(d.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault()
                          openDevice(d.id)
                        }
                      }}
                      aria-label={`Apri il dettaglio di ${d.hostname}`}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id} className={cn(cell.column.id === 'actions' && 'text-right')}>
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </TableCell>
                      ))}
                    </TableRow>
                  )
                })}
                {paddingBottom > 0 && (
                  <tr aria-hidden style={{ height: paddingBottom }}>
                    <td colSpan={columns.length} className="p-0" />
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* --- Paginazione server-side --- */}
        {!devices.isLoading && !devices.isError ? (
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-3 py-2">
            <p className="text-xs text-text-2" aria-live="polite">
              Pagina <span className="num">{page}</span> di <span className="num">{pageCount}</span>
              {' · '}
              <span className="num">{fmtNumber(total)}</span> dispositivi
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="h-11 sm:h-9"
                disabled={page <= 1 || devices.isFetching}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                <ChevronLeft className="mr-0.5 size-3.5" aria-hidden /> Precedente
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-11 sm:h-9"
                disabled={page >= pageCount || devices.isFetching}
                onClick={() => setPage((p) => p + 1)}
              >
                Successiva <ChevronRight className="ml-0.5 size-3.5" aria-hidden />
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  )
}
