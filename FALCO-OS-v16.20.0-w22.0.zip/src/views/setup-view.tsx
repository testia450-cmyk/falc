/* ================================================================
 * FALCO-OS v16.19 — Vista «Setup impianto» (W21, wizard a 7 fasi)
 * ================================================================
 * Il flusso richiesto dall'operatore, dall'inizio alla fine:
 *   1. Impianto & Import — crea l'impianto, importa Excel (rete
 *      ipotetica, con credenziali) e KMZ (sedi/coordinate);
 *   2. Scansione — sweep TCP + identificazione batch (SNMP/banner/
 *      OUI), job persistito, confronto dichiarato vs visto;
 *   3. Credenziali — verifica PER APPARATO (SNMP multi-community,
 *      login SSH reale, presenza ping per i TLC);
 *   4. Adozione — i candidati visti diventano Device nel DB (con
 *      l'evidenza della scansione; la sede resta umana);
 *   5. Telemetria — sonde radio sulle antenne, sonda L2 batch sugli
 *      switch (costruisce la topologia), spazzata ping sulle TLC;
 *   6. Allarmi — regole assicurate sul plant + valutazione ORA sui
 *      dati reali (segnale, offline, orfani, topologia);
 *   7. Riepilogo — verifica globale contata dal DB e dai motori.
 *
 * Regola d'oro UI (ereditata): ogni fase dichiara cosa ha FATTO
 * davvero; «n.d.» sui valori mancanti; nessun successo inventato.
 * ================================================================ */

'use client'

import { useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Activity, ArrowRight, BellRing, Building2, Check, CheckCircle2, ClipboardCheck, Database,
  FileSpreadsheet, KeyRound, Loader2, MapPin, Radar, Radio, Rocket, ScanSearch, Wifi,
  CircleCheck, CircleX, CircleAlert,
  type LucideIcon,
} from 'lucide-react'

import { KpiCard } from '@/components/kpi-card'
import { EmptyState, ErrorPanel } from '@/components/states'
import { AsOf } from '@/components/stale-indicator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { api, ApiError, setActivePlantId } from '@/lib/client/api'
import type {
  SetupScanResult, SetupVerifyResult, SetupAdoptResult, SetupAlarmsResult, SetupSummaryResult,
  XlsxPreview, XlsxApplyResult, KmzPreview, KmzApplyResult, PlantRow, EngineStatusRow,
} from '@/lib/v2/contracts'
import { useApp } from '@/lib/client/store'
import { cn } from '@/lib/utils'

/* ---------------- Costanti ---------------- */

const STEPS: Array<{ n: number; label: string; icon: LucideIcon }> = [
  { n: 1, label: 'Impianto & Import', icon: Building2 },
  { n: 2, label: 'Scansione rete', icon: Radar },
  { n: 3, label: 'Credenziali', icon: KeyRound },
  { n: 4, label: 'Adozione & DB', icon: Database },
  { n: 5, label: 'Telemetria', icon: Activity },
  { n: 6, label: 'Allarmi', icon: BellRing },
  { n: 7, label: 'Riepilogo', icon: ClipboardCheck },
]

function errInfo(e: unknown): { message: string; code?: string } {
  if (e instanceof ApiError) return { message: e.message, code: e.code }
  if (e instanceof Error) return { message: e.message }
  return { message: 'Errore sconosciuto' }
}

function toastErr(title: string, e: unknown) {
  const info = errInfo(e)
  toast.error(title, { description: `${info.message}${info.code ? ` (codice ${info.code})` : ''}` })
}

/** Badge di stato credenziali (colori coerenti al design system). */
function CredBadge({ state }: { state: string }) {
  const map: Record<string, { cls: string; label: string }> = {
    OK: { cls: 'bg-ok-soft text-ok border-ok/40', label: 'OK' },
    WRONG: { cls: 'bg-crit-soft text-crit-text border-crit/40', label: 'SBAGLIATE' },
    MISSING: { cls: 'bg-warn-soft text-warn border-warn/40', label: 'ASSENTI' },
    UNKNOWN: { cls: 'bg-raised text-text-2 border-border', label: 'NON VERIFICABILI' },
  }
  const m = map[state] ?? map.UNKNOWN
  return <Badge variant="outline" className={m.cls}>{m.label}</Badge>
}

function fmtMs(ms: number): string {
  return `${(ms / 1000).toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} s`
}

/* ================================================================
 * Vista radice: stepper + fasi
 * ================================================================ */

export default function SetupView() {
  const [step, setStep] = useState(1)
  const activePlantId = useApp((s) => s.activePlantId)
  /* Contesto condiviso tra le fasi: il risultato della scansione e le
   * porte dichiarate dall'operatore (la fase credenziali le precompila:
   * SNMP, SSH e la porta HTTP di gestione dei TLC). */
  const [scanResult, setScanResult] = useState<SetupScanResult | null>(null)
  const [snmpPortHint, setSnmpPortHint] = useState<number | null>(null)
  const [httpPortHint, setHttpPortHint] = useState<number | null>(null)

  return (
    <div className="space-y-4">
      {/* Intestazione */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="flex items-center gap-2 text-lg font-semibold tracking-tight">
            <Rocket className="size-5 text-text-2" aria-hidden />
            Setup guidato impianto
          </h1>
          <p className="mt-0.5 text-sm text-text-2">
            Dall&apos;impianto vuoto al monitoraggio attivo: import, scansione, credenziali verificate,
            adozione, telemetria, allarmi e verifica finale — ogni fase dichiara cosa ha fatto davvero.
          </p>
        </div>
        {activePlantId ? (
          <Badge variant="outline" className="gap-1.5 bg-raised text-text-2">
            <Building2 className="size-3" aria-hidden />
            impianto attivo: <span className="font-mono text-xs">{activePlantId.slice(0, 10)}…</span>
          </Badge>
        ) : null}
      </div>

      {/* Stepper (scroll orizzontale su mobile) */}
      <nav aria-label="Fasi del setup" className="overflow-x-auto scroll-thin">
        <ol className="flex min-w-max items-center gap-1.5 rounded-lg border border-border bg-surface p-1.5">
          {STEPS.map((s, i) => {
            const done = s.n < step
            const current = s.n === step
            return (
              <li key={s.n} className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setStep(s.n)}
                  className={cn(
                    'flex items-center gap-2 rounded-md px-3 py-1.5 text-xs font-medium transition-colors',
                    current ? 'bg-primary text-primary-foreground' : done ? 'bg-ok-soft text-ok hover:bg-ok-soft/70' : 'text-text-2 hover:bg-raised',
                  )}
                  aria-current={current ? 'step' : undefined}
                >
                  {done ? <Check className="size-3.5" aria-hidden /> : <s.icon className="size-3.5" aria-hidden />}
                  <span className="whitespace-nowrap">{s.n}. {s.label}</span>
                </button>
                {i < STEPS.length - 1 ? <ArrowRight className="size-3 shrink-0 text-text-3" aria-hidden /> : null}
              </li>
            )
          })}
        </ol>
      </nav>

      {step === 1 ? <PhaseImpiantoImport onNext={() => setStep(2)} /> : null}
      {step === 2 ? <PhaseScansione onNext={() => setStep(3)} onResult={(r, snmpPort, httpPort) => { setScanResult(r); setSnmpPortHint(snmpPort); setHttpPortHint(httpPort) }} /> : null}
      {step === 3 ? <PhaseCredenziali onNext={() => setStep(4)} snmpPortHint={snmpPortHint} httpPortHint={httpPortHint} /> : null}
      {step === 4 ? <PhaseAdozione onNext={() => setStep(5)} scanResult={scanResult} /> : null}
      {step === 5 ? <PhaseTelemetria onNext={() => setStep(6)} /> : null}
      {step === 6 ? <PhaseAllarmi onNext={() => setStep(7)} /> : null}
      {step === 7 ? <PhaseRiepilogo /> : null}
    </div>
  )
}

/* ================================================================
 * FASE 1 — Impianto & Import (Excel + KMZ)
 * ================================================================ */

function PhaseImpiantoImport({ onNext }: { onNext: () => void }) {
  const queryClient = useQueryClient()
  const setActivePlant = useApp((s) => s.setActivePlant)
  const activePlantId = useApp((s) => s.activePlantId)

  const [name, setName] = useState('')
  const [comune, setComune] = useState('')
  const [snmpCommunities, setSnmpCommunities] = useState('public')
  const [created, setCreated] = useState<PlantRow | null>(null)

  const createMut = useMutation({
    mutationFn: () => api.createPlant({
      name: name.trim(),
      comune: comune.trim(),
      snmpCommunities: snmpCommunities.trim() || undefined,
    }),
    onSuccess: (plant) => {
      setCreated(plant)
      /* L'impianto NUOVO diventa l'impianto ATTIVO: tutte le chiamate
       * seguenti del wizard operano su di esso. */
      setActivePlantId(plant.id)
      setActivePlant(plant.id)
      void queryClient.invalidateQueries()
      toast.success('Impianto creato', {
        description: `${plant.name} (${plant.comune}) — vuoto: il wizard lo popola nelle fasi successive.`,
      })
    },
    onError: (e) => toastErr('Creazione impianto non riuscita', e),
  })

  const plantId = created?.id ?? activePlantId

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Building2 className="size-4 text-text-2" aria-hidden />
            1a — Crea l&apos;impianto
          </CardTitle>
          <CardDescription>Il contenitore isolato: sedi, dispositivi, allarmi e mappa propri.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {created ? (
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="gap-1.5 bg-ok-soft text-ok border-ok/40">
                <CheckCircle2 className="size-3" aria-hidden />
                {created.name} · {created.comune}
              </Badge>
              <span className="text-xs text-text-2">community SNMP dell&apos;impianto: <span className="font-mono">{created.snmpCommunities || '—'}</span></span>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-[1fr_1fr_1fr_auto]">
              <div className="grid gap-1.5">
                <Label htmlFor="setup-plant-name">Nome impianto</Label>
                <Input id="setup-plant-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="es. Verona Sud" autoComplete="off" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="setup-plant-comune">Comune</Label>
                <Input id="setup-plant-comune" value={comune} onChange={(e) => setComune(e.target.value)} placeholder="es. Verona" autoComplete="off" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="setup-plant-comm">Community SNMP (CSV)</Label>
                <Input id="setup-plant-comm" value={snmpCommunities} onChange={(e) => setSnmpCommunities(e.target.value)} placeholder="public,altre" autoComplete="off" />
              </div>
              <div className="flex items-end">
                <Button className="w-full sm:w-auto" onClick={() => createMut.mutate()} disabled={!name.trim() || !comune.trim() || createMut.isPending}>
                  {createMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <Building2 className="size-3.5" aria-hidden />}
                  Crea impianto
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {plantId ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <ExcelImportCard plantId={plantId} />
          <KmzImportCard plantId={plantId} />
        </div>
      ) : (
        <EmptyState
          icon={<FileSpreadsheet className="size-10" aria-hidden />}
          title="Crea prima l'impianto"
          description="L'import Excel (rete ipotetica con credenziali) e il KMZ (sedi) richiedono un impianto di destinazione."
        />
      )}

      <div className="flex justify-end">
        <Button onClick={onNext} disabled={!plantId} variant="outline" className="gap-1.5">
          Avanti: scansione della rete
          <ArrowRight className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  )
}

/** Import Excel (formato SETI) — due fasi preview → conferma. */
function ExcelImportCard({ plantId }: { plantId: string }) {
  const queryClient = useQueryClient()
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<XlsxPreview | null>(null)
  const [applied, setApplied] = useState<XlsxApplyResult | null>(null)
  /* Link LAN «ipotetici» dall'Excel: SPENTI di default — la rete REALE
   * la costruisce la sonda L2 della fase telemetria con FDB/LLDP/STP
   * (porte, velocità, evidenza). I link RADIO (SSID) arrivano comunque. */
  const [lanLinks, setLanLinks] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const previewMut = useMutation({
    mutationFn: () => api.xlsxPreview(plantId, file as File),
    onSuccess: (data) => setPreview(data),
    onError: (e) => toastErr('Anteprima Excel non riuscita', e),
  })
  const applyMut = useMutation({
    mutationFn: () => {
      const pv = preview
      if (!pv) throw new Error('anteprima assente')
      return api.xlsxApply({
        fileId: pv.fileId,
        plantId,
        sections: pv.sections.map((s) => ({ sectionIndex: s.sectionIndex, locationId: s.locationId ?? null })),
        createLinks: true,
        createLanLinks: lanLinks,
        synthetic: [],
        purgeAutoLinks: false,
      })
    },
    onSuccess: (r) => {
      setApplied(r)
      setPreview(null)
      setFile(null)
      if (fileRef.current) fileRef.current.value = ''
      void queryClient.invalidateQueries()
      toast.success('Excel applicato', {
        description: `${r.locationsCreated} sedi · ${r.devicesCreated} apparati · ${r.linksCreated} collegamenti · credenziali cifrate AES-256-GCM`,
      })
    },
    onError: (e) => toastErr('Applicazione Excel non riuscita', e),
  })

  const deviceCount = preview ? preview.sections.reduce((acc, s) => acc + s.devices.length, 0) : 0

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileSpreadsheet className="size-4 text-text-2" aria-hidden />
          1b — Import Excel (rete ipotetica)
        </CardTitle>
        <CardDescription>Sezioni → sedi · righe → apparati con credenziali cifrate · gruppi SSID → link radio.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {applied ? (
          <div className="space-y-2">
            <Badge className="gap-1.5 bg-ok-soft text-ok border-ok/40">
              <CheckCircle2 className="size-3" aria-hidden />
              Import completato
            </Badge>
            <div className="grid grid-cols-2 gap-2 text-xs text-text-2 sm:grid-cols-4">
              <span><span className="num font-semibold text-foreground">{applied.locationsCreated}</span> sedi</span>
              <span><span className="num font-semibold text-foreground">{applied.devicesCreated}</span> apparati</span>
              <span><span className="num font-semibold text-foreground">{applied.devicesUpdated}</span> aggiornati</span>
              <span><span className="num font-semibold text-foreground">{applied.linksCreated}</span> link</span>
            </div>
          </div>
        ) : (
          <>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx"
              className="block w-full text-xs text-text-2 file:mr-3 file:cursor-pointer file:rounded-md file:border file:border-border file:bg-raised file:px-3 file:py-1.5 file:text-xs file:text-foreground hover:file:bg-raised/70"
              onChange={(e) => { setFile(e.target.files?.[0] ?? null); setPreview(null) }}
              aria-label="File Excel di installazione"
            />
            {file && !preview ? (
              <Button size="sm" variant="outline" onClick={() => previewMut.mutate()} disabled={previewMut.isPending}>
                {previewMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                Anteprima (nessuna scrittura)
              </Button>
            ) : null}
            {preview ? (
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2 text-xs text-text-2">
                  <Badge variant="outline" className="bg-raised">{preview.sections.length} sezioni/sedi</Badge>
                  <Badge variant="outline" className="bg-raised">{deviceCount} apparati</Badge>
                  <Badge variant="outline" className="bg-raised">{preview.links.length} link radio</Badge>
                </div>
                <div className="max-h-56 overflow-auto scroll-thin rounded-md border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="h-8 text-xs">Sede (sezione)</TableHead>
                        <TableHead className="h-8 text-xs">Apparati</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {preview.sections.map((s) => (
                        <TableRow key={s.sectionIndex}>
                          <TableCell className="py-1.5 text-xs font-medium">{s.sectionName}</TableCell>
                          <TableCell className="py-1.5 text-xs text-text-2">
                            {s.devices.map((d) => (
                              <span key={d.ip} className="mr-2 inline-flex items-center gap-1">
                                <span className="font-mono">{d.ip}</span>
                                <span className="font-medium text-foreground">{d.name}</span>
                                <span className="text-text-3">({d.type})</span>
                              </span>
                            ))}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <div className="flex items-start gap-2 rounded-md border border-border bg-raised/40 p-2 text-xs text-text-2">
                  <Checkbox id="setup-lanlinks" checked={lanLinks} onCheckedChange={(c) => setLanLinks(c === true)} className="mt-0.5" />
                  <label htmlFor="setup-lanlinks">
                    Crea anche i link LAN «ipotetici» dall&apos;Excel
                    <span className="mt-0.5 block text-text-3">
                      Spento di default: i collegamenti REALI (porte, velocità, evidenza FDB/LLDP/STP) li costruisce la
                      sonda Layer-2 della fase telemetria. I link radio SSID arrivano comunque dall&apos;Excel.
                    </span>
                  </label>
                </div>
                <Button size="sm" onClick={() => applyMut.mutate()} disabled={applyMut.isPending}>
                  {applyMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                  Conferma import ({deviceCount} apparati, credenziali cifrate)
                </Button>
              </div>
            ) : null}
          </>
        )}
      </CardContent>
    </Card>
  )
}

/** Import KMZ — due fasi preview → conferma. */
function KmzImportCard({ plantId }: { plantId: string }) {
  const queryClient = useQueryClient()
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<KmzPreview | null>(null)
  const [applied, setApplied] = useState<KmzApplyResult | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const previewMut = useMutation({
    mutationFn: () => api.kmzPreview(plantId, file as File),
    onSuccess: (data) => setPreview(data),
    onError: (e) => toastErr('Anteprima KMZ non riuscita', e),
  })
  const applyMut = useMutation({
    mutationFn: () => {
      const pv = preview
      if (!pv) throw new Error('anteprima assente')
      return api.kmzApply({
        fileId: pv.fileId,
        plantId,
        points: pv.points.map((p) => ({
          placemarkIndex: p.placemarkIndex,
          action: p.action,
          existingLocationId: p.existingLocationId ?? null,
        })),
      })
    },
    onSuccess: (r) => {
      setApplied(r)
      setPreview(null)
      setFile(null)
      if (fileRef.current) fileRef.current.value = ''
      void queryClient.invalidateQueries()
      toast.success('KMZ applicato', { description: `${r.created} sedi create · ${r.updated} coordinate aggiornate` })
    },
    onError: (e) => toastErr('Applicazione KMZ non riuscita', e),
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <MapPin className="size-4 text-text-2" aria-hidden />
          1c — Import KMZ (sedi sulla mappa)
        </CardTitle>
        <CardDescription>Placemark → sedi con coordinate reali (match col nome delle sezioni Excel).</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {applied ? (
          <div className="space-y-2">
            <Badge className="gap-1.5 bg-ok-soft text-ok border-ok/40">
              <CheckCircle2 className="size-3" aria-hidden />
              KMZ importato
            </Badge>
            <p className="text-xs text-text-2">
              <span className="num font-semibold text-foreground">{applied.created}</span> sedi create ·{' '}
              <span className="num font-semibold text-foreground">{applied.updated}</span> aggiornate · file <span className="font-mono">{applied.plantKmzFile}</span>
            </p>
          </div>
        ) : (
          <>
            <input
              ref={fileRef}
              type="file"
              accept=".kmz,.kml"
              className="block w-full text-xs text-text-2 file:mr-3 file:cursor-pointer file:rounded-md file:border file:border-border file:bg-raised file:px-3 file:py-1.5 file:text-xs file:text-foreground hover:file:bg-raised/70"
              onChange={(e) => { setFile(e.target.files?.[0] ?? null); setPreview(null) }}
              aria-label="File KMZ della mappa impianto"
            />
            {file && !preview ? (
              <Button size="sm" variant="outline" onClick={() => previewMut.mutate()} disabled={previewMut.isPending}>
                {previewMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                Anteprima (nessuna scrittura)
              </Button>
            ) : null}
            {preview ? (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-2 text-xs">
                  <Badge variant="outline" className="bg-raised">{preview.points.length} placemark</Badge>
                  <Badge variant="outline" className="bg-raised">{preview.created} da creare</Badge>
                  <Badge variant="outline" className="bg-raised">{preview.updated} da aggiornare</Badge>
                </div>
                <ul className="max-h-40 space-y-1 overflow-y-auto scroll-thin rounded-md border border-border p-2 text-xs">
                  {preview.points.map((p) => (
                    <li key={p.placemarkIndex} className="flex items-center justify-between gap-2">
                      <span className="min-w-0 truncate font-medium">{p.name}</span>
                      <span className="shrink-0 text-text-2">{p.lat.toFixed(5)}, {p.lng.toFixed(5)} · {p.action}</span>
                    </li>
                  ))}
                </ul>
                <Button size="sm" onClick={() => applyMut.mutate()} disabled={applyMut.isPending}>
                  {applyMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                  Conferma sedi
                </Button>
              </div>
            ) : null}
          </>
        )}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * FASE 2 — Scansione della rete
 * ================================================================ */

/* Porte TCP standard dello sweep (le stesse del motore v16.8): le
 * «extra» del wizard si AGGIUNGONO a queste, non le sostituiscono. */
const STANDARD_TCP_PORTS = [22, 80, 161, 443, 554, 631, 5000, 5060, 7547, 8080, 8291, 8899, 9100, 34567, 37777]

function PhaseScansione({ onNext, onResult }: { onNext: () => void; onResult: (result: SetupScanResult, snmpPort: number | null, httpPort: number | null) => void }) {
  const [cidr, setCidr] = useState('127.0.0.0/29')
  const [portsRaw, setPortsRaw] = useState('')
  const [communitiesRaw, setCommunitiesRaw] = useState('public')
  const [snmpPortRaw, setSnmpPortRaw] = useState('')
  const [httpPortRaw, setHttpPortRaw] = useState('')
  const [result, setResult] = useState<SetupScanResult | null>(null)

  const scanMut = useMutation({
    mutationFn: () => {
      const extra = portsRaw.trim()
        ? portsRaw.split(/[\s,;]+/).map(Number).filter((n) => Number.isInteger(n) && n > 0 && n < 65536)
        : []
      const ports = extra.length > 0 ? Array.from(new Set([...STANDARD_TCP_PORTS, ...extra])) : undefined
      const communities = communitiesRaw.trim() ? communitiesRaw.split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean).slice(0, 8) : undefined
      const snmpPort = snmpPortRaw.trim() ? Number(snmpPortRaw.trim()) : undefined
      const httpPort = httpPortRaw.trim() ? Number(httpPortRaw.trim()) : undefined
      return api.setupScan({
        cidr: cidr.trim(),
        ...(ports && ports.length > 0 ? { ports } : {}),
        ...(communities && communities.length > 0 ? { communities } : {}),
        ...(snmpPort && Number.isInteger(snmpPort) ? { snmpPort } : {}),
        ...(httpPort && Number.isInteger(httpPort) ? { httpPort } : {}),
      })
    },
    onSuccess: (data) => {
      setResult(data)
      const snmpPort = snmpPortRaw.trim() ? Number(snmpPortRaw.trim()) : null
      const httpPort = httpPortRaw.trim() ? Number(httpPortRaw.trim()) : null
      onResult(data, snmpPort && Number.isInteger(snmpPort) ? snmpPort : null, httpPort && Number.isInteger(httpPort) ? httpPort : null)
      toast.success('Scansione completata', {
        description: `${data.up} host vivi su ${data.scanned} · ${data.identified} identificati · ${data.comparison.newSeen} nuovi non in inventario`,
      })
    },
    onError: (e) => toastErr('Scansione non riuscita', e),
  })

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Radar className="size-4 text-text-2" aria-hidden />
            2 — Scansione della rete dell&apos;impianto
          </CardTitle>
          <CardDescription>
            Sweep TCP sul CIDR + identificazione (SNMP multi-community, banner HTTP, OUI). Il job viene
            PERSISTITO e confrontato con l&apos;inventario dichiarato in Excel.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_1fr_1fr_auto]">
            <div className="grid gap-1.5">
              <Label htmlFor="scan-cidr">Rete (CIDR)</Label>
              <Input id="scan-cidr" value={cidr} onChange={(e) => setCidr(e.target.value)} placeholder="192.168.88.0/24" autoComplete="off" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="scan-ports" title="Porte TCP aggiuntive oltre lo standard (in laboratorio i servizi simulati usano porte alte)">Porte TCP extra</Label>
              <Input id="scan-ports" value={portsRaw} onChange={(e) => setPortsRaw(e.target.value)} placeholder="es. 2222,8081" autoComplete="off" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="scan-comm">Community SNMP</Label>
              <Input id="scan-comm" value={communitiesRaw} onChange={(e) => setCommunitiesRaw(e.target.value)} placeholder="public" autoComplete="off" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="scan-snmpport" title="Se gli agenti SNMP non stanno sulla 161 standard (NAT/laboratorio)">Porta SNMP</Label>
              <Input id="scan-snmpport" value={snmpPortRaw} onChange={(e) => setSnmpPortRaw(e.target.value)} placeholder="default 161" autoComplete="off" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="scan-httpport" title="Pannello web su porta non standard per il banner HTTP">Porta HTTP</Label>
              <Input id="scan-httpport" value={httpPortRaw} onChange={(e) => setHttpPortRaw(e.target.value)} placeholder="default 80/8080" autoComplete="off" />
            </div>
            <div className="flex items-end">
              <Button className="w-full sm:w-auto" onClick={() => scanMut.mutate()} disabled={!cidr.trim() || scanMut.isPending}>
                {scanMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <ScanSearch className="size-3.5" aria-hidden />}
                Avvia scansione
              </Button>
            </div>
          </div>
          <p className="text-xs text-text-2">
            In produzione: CIDR dell&apos;impianto, porte standard (22/80/161/443…), community reali. In questo ambiente
            dimostrativo gli apparati simulati rispondono su porte dichiarate nei campi sopra.
          </p>
        </CardContent>
      </Card>

      {result ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <KpiCard label="IP scansionati" value={result.scanned} accent="none" />
            <KpiCard label="Host vivi" value={result.up} accent="ok" />
            <KpiCard label="Identificati" value={result.identified} accent="info" />
            <KpiCard label="Confermati (in inventario)" value={result.comparison.confirmed} accent="ok" definition="dichiarati in Excel E visti in rete" />
            <KpiCard label="Nuovi (non in inventario)" value={result.comparison.newSeen} accent="warn" definition="visti in rete ma assenti dall'Excel" />
          </div>

          {result.comparison.missingIps.length > 0 ? (
            <div role="alert" className="flex items-start gap-2.5 rounded-lg border border-warn/40 bg-warn-soft px-3 py-2 text-sm text-warn">
              <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
              <p>
                <span className="font-semibold">{result.comparison.missing} IP dichiarati in Excel non visti in rete:</span>{' '}
                <span className="font-mono text-xs">{result.comparison.missingIps.join(' · ')}</span> — restano a libro
                (nessuna cancellazione automatica): verificare se spenti o fuori range.
              </p>
            </div>
          ) : null}

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Candidati visti ({result.candidates.length})</CardTitle>
              <CardDescription>Evidenza grezza delle sonde: ciò che la rete dice, non ciò che l&apos;Excel dichiara.</CardDescription>
              <CardAction><AsOf ts={Date.now()} prefix="scansione del" /></CardAction>
            </CardHeader>
            <CardContent>
              <div className="max-h-96 overflow-auto scroll-thin rounded-md border border-border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="h-8 text-xs">IP</TableHead>
                      <TableHead className="h-8 text-xs">Vivo</TableHead>
                      <TableHead className="h-8 text-xs">Porte aperte</TableHead>
                      <TableHead className="h-8 text-xs">SNMP</TableHead>
                      <TableHead className="h-8 text-xs">Identità</TableHead>
                      <TableHead className="h-8 text-xs">MAC</TableHead>
                      <TableHead className="h-8 text-xs">Inventario</TableHead>
                      <TableHead className="h-8 text-xs">Suggerimento</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.candidates.map((c) => (
                      <TableRow key={c.ip}>
                        <TableCell className="py-1.5 font-mono text-xs">{c.ip}</TableCell>
                        <TableCell className="py-1.5">
                          {c.alive
                            ? <CircleCheck className="size-3.5 text-ok" aria-label="vivo" />
                            : <CircleX className="size-3.5 text-crit-text" aria-label="muto" />}
                        </TableCell>
                        <TableCell className="py-1.5 text-xs text-text-2">{c.openPorts.length > 0 ? c.openPorts.join(', ') : 'n.d.'}</TableCell>
                        <TableCell className="py-1.5 text-xs">
                          {c.snmp.reachable ? (
                            <span className="inline-flex items-center gap-1">
                              <CircleCheck className="size-3 text-ok" aria-hidden />
                              <span className="font-mono">{c.snmp.matchedCommunity ?? '—'}</span>
                              {c.snmp.sysName ? <span className="text-text-2">({c.snmp.sysName})</span> : null}
                            </span>
                          ) : <span className="text-text-2">—</span>}
                        </TableCell>
                        <TableCell className="py-1.5 text-xs">
                          <span className="font-medium">{c.classification.type}</span>
                          {c.classification.brand ? <span className="text-text-2"> · {c.classification.brand}{c.classification.model ? ` ${c.classification.model}` : ''}</span> : null}
                        </TableCell>
                        <TableCell className="py-1.5 font-mono text-xs text-text-2">{c.snmp.mac ?? 'n.d.'}</TableCell>
                        <TableCell className="py-1.5 text-xs">
                          {c.inInventory
                            ? <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40">{c.deviceHostname}</Badge>
                            : <Badge variant="outline" className="bg-warn-soft text-warn border-warn/40">nuovo</Badge>}
                        </TableCell>
                        <TableCell className="py-1.5 text-xs text-text-2">
                          {c.suggestedType} · {c.suggestedMonitorMode === 'ping' ? 'ping-only' : 'full'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {result.warnings.length > 0 ? (
                <ul className="mt-2 space-y-1 text-xs text-warn">
                  {result.warnings.map((w, i) => <li key={i}>· {w}</li>)}
                </ul>
              ) : null}
            </CardContent>
          </Card>
        </>
      ) : null}

      <div className="flex justify-end">
        <Button onClick={onNext} variant="outline" className="gap-1.5">
          Avanti: credenziali
          <ArrowRight className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  )
}

/* ================================================================
 * FASE 3 — Credenziali (verifica per apparato)
 * ================================================================ */

function PhaseCredenziali({ onNext, snmpPortHint, httpPortHint }: { onNext: () => void; snmpPortHint: number | null; httpPortHint: number | null }) {
  const queryClient = useQueryClient()
  const [snmpPortRaw, setSnmpPortRaw] = useState(snmpPortHint != null ? String(snmpPortHint) : '')
  const [sshPortRaw, setSshPortRaw] = useState('')
  const [httpPortRaw, setHttpPortRaw] = useState(httpPortHint != null ? String(httpPortHint) : '')
  const [result, setResult] = useState<SetupVerifyResult | null>(null)
  /* Dispositivi dell'impianto: per la dichiarazione TLC (ping-only)
   * PRIMA della verifica — decisione umana, ricetta camera-ping-only. */
  const devices = useQuery({
    queryKey: ['setup-verify-devices'],
    queryFn: () => api.devices({ pageSize: 200 }),
  })
  const tlcCandidates = (devices.data?.data.items ?? []).filter((d) => ['CAMERA', 'LPR', 'ONT'].includes(d.type) && d.monitorMode !== 'ping')

  const declarePingOnly = useMutation({
    mutationFn: (deviceId: string) => api.snmpEnableExecute({ deviceId, recipeId: 'camera-ping-only', community: 'public', contact: '', location: '' }),
    onSuccess: (_r, deviceId) => {
      void queryClient.invalidateQueries({ queryKey: ['setup-verify-devices'] })
      toast.success('Dichiarato ping-only', { description: 'TLC/endpoint: conterà la presenza (ping), non i valori. Nessun contatto con l\'apparato.' })
      void deviceId
    },
    onError: (e) => toastErr('Dichiarazione ping-only non riuscita', e),
  })

  const verifyMut = useMutation({
    mutationFn: () => {
      const snmpPort = snmpPortRaw.trim() ? Number(snmpPortRaw.trim()) : undefined
      const sshPort = sshPortRaw.trim() ? Number(sshPortRaw.trim()) : undefined
      const httpPort = httpPortRaw.trim() ? Number(httpPortRaw.trim()) : undefined
      return api.setupVerify({
        ...(snmpPort && Number.isInteger(snmpPort) ? { snmpPort } : {}),
        ...(sshPort && Number.isInteger(sshPort) ? { sshPort } : {}),
        ...(httpPort && Number.isInteger(httpPort) ? { httpPort } : {}),
      })
    },
    onSuccess: (data) => {
      setResult(data)
      toast.success('Verifica completata', {
        description: `${data.summary.credentialsOk} OK · ${data.summary.credentialsWrong} sbagliate · ${data.summary.credentialsUnknown} non verificabili · ${data.summary.pingAlive} TLC vivi`,
      })
    },
    onError: (e) => toastErr('Verifica credenziali non riuscita', e),
  })

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <KeyRound className="size-4 text-text-2" aria-hidden />
            3 — Credenziali: verifica per OGNI apparato
          </CardTitle>
          <CardDescription>
            SNMP multi-community (cifrata dell&apos;apparato → CSV impianto → public) + login SSH reale
            (nessun comando eseguito) + presenza ping per i TLC. Un timeout NON è «sbagliato»: resta onesto.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {tlcCandidates.length > 0 ? (
            <div className="rounded-lg border border-border bg-raised/40 p-3">
              <p className="text-xs font-medium">Prima di verificare: dichiara i TLC (ping-only)</p>
              <p className="mt-0.5 text-xs text-text-2">
                «Se sono TLC evitiamo, va bene solo ping»: gli endpoint sotto non verranno interrogati con
                SNMP/SSH — conterà la presenza. Decisione tua, per apparato.
              </p>
              <ul className="mt-2 space-y-1.5">
                {tlcCandidates.map((d) => (
                  <li key={d.id} className="flex items-center justify-between gap-2 text-xs">
                    <span className="min-w-0 truncate">
                      <span className="font-medium">{d.hostname}</span>
                      <span className="ml-1 font-mono text-text-2">{d.ip}</span>
                      <span className="ml-1 text-text-3">({d.type})</span>
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs"
                      onClick={() => declarePingOnly.mutate(d.id)}
                      disabled={declarePingOnly.isPending && declarePingOnly.variables === d.id}
                    >
                      {declarePingOnly.isPending && declarePingOnly.variables === d.id
                        ? <Loader2 className="size-3 animate-spin" aria-hidden />
                        : <Activity className="size-3" aria-hidden />}
                      Solo ping
                    </Button>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
          <div className="grid gap-3 sm:grid-cols-[200px_200px_200px_auto]">
            <div className="grid gap-1.5">
              <Label htmlFor="verify-snmpport" title="La porta dichiarata nella fase scansione vince sulla 161 di default">Porta SNMP (se non standard)</Label>
              <Input id="verify-snmpport" value={snmpPortRaw} onChange={(e) => setSnmpPortRaw(e.target.value)} placeholder="default: per apparato" autoComplete="off" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="verify-sshport" title="Porta SSH se non 22 (laboratori/NAT)">Porta SSH (se non standard)</Label>
              <Input id="verify-sshport" value={sshPortRaw} onChange={(e) => setSshPortRaw(e.target.value)} placeholder="default: 22" autoComplete="off" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="verify-httpport" title="Porta di gestione dei TLC (ping-only) quando non è la 80">Porta gestione TLC</Label>
              <Input id="verify-httpport" value={httpPortRaw} onChange={(e) => setHttpPortRaw(e.target.value)} placeholder="default: 80" autoComplete="off" />
            </div>
            <div className="flex items-end">
              <Button onClick={() => verifyMut.mutate()} disabled={verifyMut.isPending}>
                {verifyMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <KeyRound className="size-3.5" aria-hidden />}
                Verifica tutte le credenziali
              </Button>
            </div>
          </div>
          <p className="text-xs text-text-2">
            Le credenziali arrivano dall&apos;import Excel (cifrate AES-256-GCM). Al successo: community salvata
            cifrata, snmpEnableState → ENABLED, MAC letto salvato se mancante, snmpPort aggiornata a quella che risponde.
          </p>
        </CardContent>
      </Card>

      {result ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <KpiCard label="Credenziali OK" value={result.summary.credentialsOk} accent="ok" definition="SNMP o SSH verificati" />
            <KpiCard label="Sbagliate" value={result.summary.credentialsWrong} accent="crit" definition="rifiutate (es. SSH AUTH_FAILED)" />
            <KpiCard label="Non verificabili" value={result.summary.credentialsUnknown} accent="warn" definition="mute/timeout — mai dette «sbagliate»" />
            <KpiCard label="TLC vivi (ping)" value={`${result.summary.pingAlive}/${result.summary.pingAlive + result.summary.pingMute}`} accent="info" />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Esito per apparato ({result.devices.length})</CardTitle>
              <CardDescription>La prova, dispositivo per dispositivo: {fmtMs(result.durationMs)} di sonde reali.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="max-h-96 overflow-auto scroll-thin rounded-md border border-border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="h-8 text-xs">Apparato</TableHead>
                      <TableHead className="h-8 text-xs">Modalità</TableHead>
                      <TableHead className="h-8 text-xs">SNMP</TableHead>
                      <TableHead className="h-8 text-xs">SSH</TableHead>
                      <TableHead className="h-8 text-xs">Ping</TableHead>
                      <TableHead className="h-8 text-xs">Stato</TableHead>
                      <TableHead className="h-8 text-xs">Motivo (leggibile)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.devices.map((d) => (
                      <TableRow key={d.deviceId}>
                        <TableCell className="py-1.5 text-xs">
                          <span className="font-medium">{d.hostname}</span>
                          <span className="ml-1 font-mono text-text-2">{d.ip}</span>
                        </TableCell>
                        <TableCell className="py-1.5 text-xs text-text-2">{d.monitorMode === 'ping' ? 'ping-only' : 'full'}</TableCell>
                        <TableCell className="py-1.5 text-xs">
                          {d.snmp.tried ? (
                            d.snmp.reachable
                              ? <span className="inline-flex items-center gap-1"><CircleCheck className="size-3 text-ok" aria-hidden /><span className="font-mono">{d.snmp.matchedCommunity ?? '—'}</span></span>
                              : <span className="text-text-2">{d.snmp.error ?? 'muto'}</span>
                          ) : <span className="text-text-3">—</span>}
                        </TableCell>
                        <TableCell className="py-1.5 text-xs">
                          {d.ssh.tried ? (
                            d.ssh.authenticated
                              ? <CircleCheck className="size-3.5 text-ok" aria-label="login accettato" />
                              : <span className="inline-flex items-center gap-1"><CircleX className="size-3.5 text-crit-text" aria-label="login rifiutato" /><span className="text-text-2">{d.ssh.error ?? ''}</span></span>
                          ) : <span className="text-text-3">—</span>}
                        </TableCell>
                        <TableCell className="py-1.5 text-xs">
                          {d.ping.tried ? (
                            d.ping.alive
                              ? <span className="inline-flex items-center gap-1"><CircleCheck className="size-3 text-ok" aria-hidden /><span className="num text-text-2">{d.ping.latencyMs} ms</span></span>
                              : <CircleX className="size-3.5 text-crit-text" aria-label="muto" />
                          ) : <span className="text-text-3">—</span>}
                        </TableCell>
                        <TableCell className="py-1.5"><CredBadge state={d.credentialState} /></TableCell>
                        <TableCell className="max-w-[320px] py-1.5 text-xs text-text-2">{d.credentialReason}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {result.warnings.length > 0 ? (
                <ul className="mt-2 space-y-1 text-xs text-warn">
                  {result.warnings.map((w, i) => <li key={i}>· {w}</li>)}
                </ul>
              ) : null}
            </CardContent>
          </Card>
        </>
      ) : null}

      <div className="flex justify-end">
        <Button onClick={onNext} variant="outline" className="gap-1.5">
          Avanti: adozione nel database
          <ArrowRight className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  )
}

/* ================================================================
 * FASE 4 — Adozione (scrittura DB + confronto)
 * ================================================================ */

function PhaseAdozione({ onNext, scanResult }: { onNext: () => void; scanResult: SetupScanResult | null }) {
  const navigate = useApp((s) => s.navigate)
  const queryClient = useQueryClient()
  const [result, setResult] = useState<SetupAdoptResult | null>(null)
  /* Selezione per candidato nuovo: incluso? tipo? modalità? */
  const [include, setInclude] = useState<Record<string, boolean>>({})
  const [typeSel, setTypeSel] = useState<Record<string, string>>({})
  const [modeSel, setModeSel] = useState<Record<string, 'full' | 'ping'>>({})

  const newCandidates = (scanResult?.candidates ?? []).filter((c) => !c.inInventory && c.alive)

  const adoptMut = useMutation({
    mutationFn: () => api.setupAdopt({
      jobId: scanResult?.jobId,
      overrides: newCandidates
        .filter((c) => include[c.ip] !== false)
        .map((c) => ({
          ip: c.ip,
          ...(typeSel[c.ip] && typeSel[c.ip] !== c.suggestedType ? { type: typeSel[c.ip] } : {}),
          ...(modeSel[c.ip] && modeSel[c.ip] !== c.suggestedMonitorMode ? { monitorMode: modeSel[c.ip] } : {}),
        })),
      skipIps: newCandidates.filter((c) => include[c.ip] === false).map((c) => c.ip),
      note: 'wizard setup impianto',
    }),
    onSuccess: (data) => {
      setResult(data)
      void queryClient.invalidateQueries()
      toast.success('Adozione completata', {
        description: `${data.comparison.adoptedNow} apparati scritti nel DB · ${data.orphansAfter} orfani in coda sede · ${data.comparison.missing} dichiarati non visti`,
      })
    },
    onError: (e) => toastErr('Adozione non riuscita', e),
  })

  if (!scanResult && !result) {
    return (
      <EmptyState
        icon={<Database className="size-10" aria-hidden />}
        title="Nessuna scansione in memoria"
        description="Torna alla fase 2 e lancia una scansione: l'adozione riprende i candidati da lì (job persistito)."
      />
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Database className="size-4 text-text-2" aria-hidden />
            4 — Adozione: scriviamo nel DB e confrontiamo la rete
          </CardTitle>
          <CardDescription>
            I nuovi visti diventano Device con l&apos;evidenza della scansione (hostname da sysName, MAC letto,
            community cifrata, baseline 24 h anti falsi allarmi). La SEDE resta una decisione umana.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {newCandidates.length === 0 && !result ? (
            <p className="text-sm text-text-2">Nessun candidato nuovo: tutta la rete vista era già in inventario.</p>
          ) : null}
          {newCandidates.length > 0 && !result ? (
            <>
              <div className="max-h-80 overflow-auto scroll-thin rounded-md border border-border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="h-8 w-8 text-xs">Includi</TableHead>
                      <TableHead className="h-8 text-xs">IP</TableHead>
                      <TableHead className="h-8 text-xs">Identità letta</TableHead>
                      <TableHead className="h-8 text-xs">Tipo</TableHead>
                      <TableHead className="h-8 text-xs">Monitoraggio</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {newCandidates.map((c) => (
                      <TableRow key={c.ip}>
                        <TableCell className="py-1.5">
                          <Checkbox
                            checked={include[c.ip] !== false}
                            onCheckedChange={(v) => setInclude((s) => ({ ...s, [c.ip]: v === true }))}
                            aria-label={`Includi ${c.ip} nell'adozione`}
                          />
                        </TableCell>
                        <TableCell className="py-1.5 font-mono text-xs">{c.ip}</TableCell>
                        <TableCell className="py-1.5 text-xs">
                          <span className="font-medium">{c.snmp.sysName ?? c.classification.type}</span>
                          {c.classification.brand ? <span className="text-text-2"> · {c.classification.brand}</span> : null}
                          {c.snmp.mac ? <span className="ml-1 font-mono text-text-2">{c.snmp.mac}</span> : null}
                        </TableCell>
                        <TableCell className="py-1.5">
                          <Select value={typeSel[c.ip] ?? c.suggestedType} onValueChange={(v) => setTypeSel((s) => ({ ...s, [c.ip]: v }))}>
                            <SelectTrigger className="h-7 w-32 text-xs" aria-label={`Tipo per ${c.ip}`}><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {['SWITCH', 'GATEWAY', 'AP', 'STA', 'CAMERA', 'NVR', 'LPR', 'ONT', 'SERVER'].map((t) => (
                                <SelectItem key={t} value={t} className="text-xs">{t}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="py-1.5">
                          <Select value={modeSel[c.ip] ?? c.suggestedMonitorMode} onValueChange={(v) => setModeSel((s) => ({ ...s, [c.ip]: v as 'full' | 'ping' }))}>
                            <SelectTrigger className="h-7 w-28 text-xs" aria-label={`Modalità monitoraggio per ${c.ip}`}><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="full" className="text-xs">full (SNMP)</SelectItem>
                              <SelectItem value="ping" className="text-xs">ping-only</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <div className="flex items-center gap-3">
                <Button onClick={() => adoptMut.mutate()} disabled={adoptMut.isPending}>
                  {adoptMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                  Adotta nel database
                </Button>
                <p className="text-xs text-text-2">
                  {newCandidates.filter((c) => include[c.ip] !== false).length} da adottare ·{' '}
                  {newCandidates.filter((c) => include[c.ip] === false).length} esclusi
                </p>
              </div>
            </>
          ) : null}

          {result ? (
            <div className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <KpiCard label="Adottati ora" value={result.comparison.adoptedNow} accent="ok" />
                <KpiCard label="Confermati totali" value={result.comparison.confirmed} accent="info" definition="in inventario e visti in rete" />
                <KpiCard label="Dichiarati non visti" value={result.comparison.missing} accent="warn" />
                <KpiCard label="Orfani (senza sede)" value={result.orphansAfter} accent="warn" definition="la sede si assegna a mano: mai auto" />
              </div>
              {result.created.length > 0 ? (
                <div className="max-h-64 overflow-auto scroll-thin rounded-md border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="h-8 text-xs">Hostname</TableHead>
                        <TableHead className="h-8 text-xs">IP</TableHead>
                        <TableHead className="h-8 text-xs">Tipo</TableHead>
                        <TableHead className="h-8 text-xs">Monitoraggio</TableHead>
                        <TableHead className="h-8 text-xs">MAC</TableHead>
                        <TableHead className="h-8 text-xs">SNMP</TableHead>
                        <TableHead className="h-8 text-xs">Baseline</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {result.created.map((d) => (
                        <TableRow key={d.deviceId}>
                          <TableCell className="py-1.5 text-xs font-medium">{d.hostname}</TableCell>
                          <TableCell className="py-1.5 font-mono text-xs">{d.ip}</TableCell>
                          <TableCell className="py-1.5 text-xs">{d.type}</TableCell>
                          <TableCell className="py-1.5 text-xs text-text-2">{d.monitorMode === 'ping' ? 'ping-only' : 'full'}</TableCell>
                          <TableCell className="py-1.5 font-mono text-xs text-text-2">{d.macAddress || 'n.d.'}</TableCell>
                          <TableCell className="py-1.5 text-xs">
                            {d.snmpEnabled ? <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40">ENABLED</Badge> : <span className="text-text-2">—</span>}
                          </TableCell>
                          <TableCell className="py-1.5 text-xs text-text-2">24 h</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : null}
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => navigate('operazioni')}>
                  Coda adozione: assegna le sedi (umano)
                </Button>
              </div>
              {result.warnings.map((w, i) => (
                <p key={i} className="text-xs text-text-2">· {w}</p>
              ))}
            </div>
          ) : null}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={onNext} variant="outline" className="gap-1.5">
          Avanti: telemetria
          <ArrowRight className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  )
}

/* ================================================================
 * FASE 5 — Telemetria (radio, L2, ping)
 * ================================================================ */

interface RadioRow {
  deviceId: string
  hostname: string
  ip: string
  reachable: boolean
  sysName: string | null
  cpu: number | null
  ramPct: number | null
  ssid: string | null
  signal: number | null
  ccq: number | null
  linkMode: string | null
  ports: number
  metricsSaved: number
  error: string | null
}

function PhaseTelemetria({ onNext }: { onNext: () => void }) {
  const queryClient = useQueryClient()
  const [radioRows, setRadioRows] = useState<RadioRow[]>([])
  const [radioBusy, setRadioBusy] = useState<string | null>(null)
  const [l2Result, setL2Result] = useState<{ reachable: number; switchLinks: number; persistence: { linksCreated: number; linksUpdated: number; observationsSaved: number; arpSaved: number; stpSaved: number; vlanSaved: number }; arpCandidates: number; warnings: string[] } | null>(null)
  const [pingResult, setPingResult] = useState<{ swept: number; alive: number; results: Array<{ hostname: string; ip: string; alive: boolean; latencyMs: number | null }> } | null>(null)

  const devices = useQuery({
    queryKey: ['setup-devices'],
    queryFn: () => api.devices({ pageSize: 200 }),
  })

  const radioTargets = (devices.data?.data.items ?? []).filter((d) => ['AP', 'STA', 'GATEWAY'].includes(d.type))
  const l2Targets = (devices.data?.data.items ?? []).filter((d) => ['SWITCH', 'GATEWAY', 'ROUTER', 'FIREWALL'].includes(d.type))
  const pingCount = (devices.data?.data.items ?? []).filter((d) => d.monitorMode === 'ping').length

  /* Radio: sequenziale onesto (una sonda alla volta, risultato per riga). */
  const runRadio = async () => {
    const rows: RadioRow[] = []
    for (const d of radioTargets) {
      setRadioBusy(`${d.hostname} (${d.ip})…`)
      try {
        const r = await api.radioTelemetry({ deviceId: d.id })
        rows.push({
          deviceId: d.id,
          hostname: d.hostname,
          ip: d.ip,
          reachable: r.reachable,
          sysName: r.sysName,
          cpu: r.health.cpuLoadPct,
          ramPct: r.health.ramTotalKb && r.health.ramTotalKb > 0 ? Math.round((r.health.ramUsedKb! / r.health.ramTotalKb) * 100) : null,
          ssid: r.radios[0]?.ssid ?? null,
          signal: r.radios[0]?.signalDbm ?? null,
          ccq: r.radios[0]?.ccqPercent ?? null,
          linkMode: r.derived.linkMode,
          ports: r.ports.length,
          metricsSaved: r.persisted.metricsSaved,
          error: r.reachable ? null : (r.error ?? 'timeout'),
        })
      } catch (e) {
        rows.push({ deviceId: d.id, hostname: d.hostname, ip: d.ip, reachable: false, sysName: null, cpu: null, ramPct: null, ssid: null, signal: null, ccq: null, linkMode: null, ports: 0, metricsSaved: 0, error: errInfo(e).message })
      }
      setRadioRows([...rows])
    }
    setRadioBusy(null)
    void queryClient.invalidateQueries()
    toast.success('Sonde radio completate', { description: `${rows.filter((r) => r.reachable).length}/${rows.length} antenne hanno parlato (dati scritti: Device + MetricValue).` })
  }

  const l2Mut = useMutation({
    mutationFn: () => api.discoveryL2Batch({}),
    onSuccess: (r) => {
      setL2Result({
        reachable: r.reachable,
        switchLinks: r.switchLinks.length,
        persistence: r.persistence,
        arpCandidates: r.arpCandidates.length,
        warnings: r.warnings,
      })
      void queryClient.invalidateQueries()
      toast.success('Sonda L2 completata', {
        description: `${r.reachable} switch raggiunti · ${r.persistence.linksCreated + r.persistence.linksUpdated} link scritti · ${r.persistence.observationsSaved} MAC osservati`,
      })
    },
    onError: (e) => toastErr('Sonda L2 non riuscita', e),
  })

  const pingMut = useMutation({
    mutationFn: () => api.monitorPingSweep({}),
    onSuccess: (r) => {
      setPingResult({ swept: r.swept, alive: r.alive, results: r.results.map((x) => ({ hostname: x.hostname, ip: x.ip, alive: x.alive, latencyMs: x.latencyMs })) })
      void queryClient.invalidateQueries()
      toast.success('Spazzata ping completata', { description: `${r.alive}/${r.swept} TLC vivi — campioni pingLatency/packetLoss scritti.` })
    },
    onError: (e) => toastErr('Spazzata ping non riuscita', e),
  })

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="size-4 text-text-2" aria-hidden />
            5 — Telemetria: raccogliamo i dati DAVVERO
          </CardTitle>
          <CardDescription>
            Le tre sonde dell&apos;impianto: radio (SSID, segnale, CPU, RAM, porte) sulle antenne ·
            Layer-2 (FDB/ARP/STP/VLAN → topologia) sugli switch · presenza (ping) sulle TLC.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          <div className="flex flex-col gap-2 rounded-lg border border-border p-3">
            <div className="flex items-center gap-1.5 text-xs font-medium"><Radio className="size-3.5 text-text-2" aria-hidden /> Radio · {radioTargets.length} antenne</div>
            <Button size="sm" onClick={() => void runRadio()} disabled={radioTargets.length === 0 || radioBusy != null}>
              {radioBusy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
              Sonde radio
            </Button>
            {radioBusy ? <p className="text-xs text-text-2">{radioBusy}</p> : null}
          </div>
          <div className="flex flex-col gap-2 rounded-lg border border-border p-3">
            <div className="flex items-center gap-1.5 text-xs font-medium"><Wifi className="size-3.5 text-text-2" aria-hidden /> Layer-2 · {l2Targets.length} switch</div>
            <Button size="sm" onClick={() => l2Mut.mutate()} disabled={l2Targets.length === 0 || l2Mut.isPending}>
              {l2Mut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
              Sonda L2 batch
            </Button>
            {l2Mut.isPending ? <p className="text-xs text-text-2">walk multipli in corso…</p> : null}
          </div>
          <div className="flex flex-col gap-2 rounded-lg border border-border p-3">
            <div className="flex items-center gap-1.5 text-xs font-medium"><Activity className="size-3.5 text-text-2" aria-hidden /> Presenza · {pingCount} TLC</div>
            <Button size="sm" onClick={() => pingMut.mutate()} disabled={pingCount === 0 || pingMut.isPending}>
              {pingMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
              Spazzata ping
            </Button>
          </div>
        </CardContent>
      </Card>

      {radioRows.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Telemetria radio ({radioRows.length})</CardTitle>
            <CardDescription>Valori LETTI e scritti sul DB — provenance per campo nella scheda apparato.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="max-h-72 overflow-auto scroll-thin rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="h-8 text-xs">Antenna</TableHead>
                    <TableHead className="h-8 text-xs">SNMP</TableHead>
                    <TableHead className="h-8 text-xs">SSID</TableHead>
                    <TableHead className="h-8 text-xs">Segnale</TableHead>
                    <TableHead className="h-8 text-xs">CCQ</TableHead>
                    <TableHead className="h-8 text-xs">CPU</TableHead>
                    <TableHead className="h-8 text-xs">RAM</TableHead>
                    <TableHead className="h-8 text-xs">Link</TableHead>
                    <TableHead className="h-8 text-xs">Porte</TableHead>
                    <TableHead className="h-8 text-xs">Campioni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {radioRows.map((r) => (
                    <TableRow key={r.deviceId}>
                      <TableCell className="py-1.5 text-xs"><span className="font-medium">{r.hostname}</span> <span className="font-mono text-text-2">{r.ip}</span></TableCell>
                      <TableCell className="py-1.5 text-xs">
                        {r.reachable
                          ? <CircleCheck className="size-3.5 text-ok" aria-label="risponde" />
                          : <span className="text-crit-text">{r.error ?? 'muto'}</span>}
                      </TableCell>
                      <TableCell className="py-1.5 text-xs">{r.ssid ?? <span className="text-text-2">n.d.</span>}</TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.signal != null ? `${r.signal} dBm` : 'n.d.'}</TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.ccq != null ? `${r.ccq}%` : 'n.d.'}</TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.cpu != null ? `${r.cpu}%` : 'n.d.'}</TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.ramPct != null ? `${r.ramPct}%` : 'n.d.'}</TableCell>
                      <TableCell className="py-1.5 text-xs">{r.linkMode ?? '—'}</TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.ports}</TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.metricsSaved}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {l2Result ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sonda Layer-2 e costruzione della rete</CardTitle>
            <CardDescription>La rete in bridge si ricompone dalle evidenze (FDB reciproco, LLDP/CDP, STP).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-3 lg:grid-cols-6">
              <span>switch raggiunti: <span className="num font-semibold text-foreground">{l2Result.reachable}</span></span>
              <span>link switch↔switch: <span className="num font-semibold text-foreground">{l2Result.switchLinks}</span></span>
              <span>link scritti: <span className="num font-semibold text-foreground">{l2Result.persistence.linksCreated + l2Result.persistence.linksUpdated}</span></span>
              <span>MAC osservati: <span className="num font-semibold text-foreground">{l2Result.persistence.observationsSaved}</span></span>
              <span>voci ARP: <span className="num font-semibold text-foreground">{l2Result.persistence.arpSaved}</span></span>
              <span>candidati ARP: <span className="num font-semibold text-foreground">{l2Result.arpCandidates}</span></span>
            </div>
            {l2Result.warnings.slice(0, 4).map((w, i) => <p key={i} className="text-xs text-text-2">· {w}</p>)}
          </CardContent>
        </Card>
      ) : null}

      {pingResult ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Presenza TLC ({pingResult.alive}/{pingResult.swept} vivi)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-48 overflow-auto scroll-thin rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="h-8 text-xs">TLC</TableHead>
                    <TableHead className="h-8 text-xs">Esito</TableHead>
                    <TableHead className="h-8 text-xs">Latenza</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pingResult.results.map((r) => (
                    <TableRow key={r.ip + r.hostname}>
                      <TableCell className="py-1.5 text-xs"><span className="font-medium">{r.hostname}</span> <span className="font-mono text-text-2">{r.ip}</span></TableCell>
                      <TableCell className="py-1.5 text-xs">
                        {r.alive ? <CircleCheck className="size-3.5 text-ok" aria-label="vivo" /> : <CircleX className="size-3.5 text-crit-text" aria-label="muto" />}
                      </TableCell>
                      <TableCell className="py-1.5 text-xs num">{r.latencyMs != null ? `${r.latencyMs} ms` : '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* Il «puller» continuo: la telemetria che parte e NON si ferma */}
      <EngineCard />

      <div className="flex justify-end">
        <Button onClick={onNext} variant="outline" className="gap-1.5">
          Avanti: allarmi
          <ArrowRight className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  )
}

/* ================================================================
 * Motore di monitoraggio continuo (W21-bis) — il «puller»
 * ================================================================ */

function EngineCard() {
  const queryClient = useQueryClient()
  const [intervalRaw, setIntervalRaw] = useState('30')
  const [radioEveryRaw, setRadioEveryRaw] = useState('3')
  const actionMut = useMutation({
    mutationFn: (action: 'start' | 'stop') => {
      const intervalSec = action === 'start' && intervalRaw.trim() ? Number(intervalRaw.trim()) : undefined
      const radioEvery = action === 'start' && radioEveryRaw.trim() ? Number(radioEveryRaw.trim()) : undefined
      return api.setupEngineAction({
        action,
        ...(intervalSec && Number.isInteger(intervalSec) ? { intervalSec } : {}),
        ...(radioEvery && Number.isInteger(radioEvery) ? { radioEvery } : {}),
      })
    },
    onSuccess: (r) => {
      void queryClient.invalidateQueries({ queryKey: ['setup-engine'] })
      toast.success(r.action === 'start' ? 'Motore di monitoraggio avviato' : 'Motore arrestato', {
        description: r.action === 'start'
          ? `Tick ogni ${r.engine?.intervalSec ?? '?'} s · radio ogni ${r.engine?.radioEvery ?? '?'} cicli · primo ciclo già in corso`
          : 'Le sonde on-demand del wizard restano disponibili.',
      })
    },
    onError: (e) => toastErr('Comando motore non riuscito', e),
  })
  /* Stato vivo: refresh rapido quando gira (i contatori crescono a ogni tick). */
  const status = useQuery({
    queryKey: ['setup-engine'],
    queryFn: () => api.setupEngineStatus(),
    refetchInterval: (q) => {
      const running = q.state.data?.data.engines.some((x) => x.running)
      return running ? 6000 : 30_000
    },
  })
  const activePlantId = useApp((s) => s.activePlantId)
  /* SOLO il motore dell'impianto attivo: mai mostrare quello di un
   * altro impianto come se fosse questo (fallback sarebbe disonesto). */
  const engine: EngineStatusRow | undefined = status.data?.data.engines.find((x) => x.plantId === activePlantId)
  const running = engine?.running ?? false
  /* v16.20 W22: riga persistita dell'impianto attivo (auto-resume). */
  const runtime = status.data?.data.runtimes.find((x) => x.plantId === activePlantId)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Activity className="size-4 text-text-2" aria-hidden />
          Monitoraggio continuo (il puller)
        </CardTitle>
        <CardDescription>
          Ogni tick: presenza ping + liveness SNMP + <span className="text-foreground">valutazione allarmi con dedup</span> → eventi aperti/chiusi
          e notifiche Telegram (se configurate). La telemetria radio ogni N cicli. Isteresi 2 giù / 2 su: un micro-riavvio non genera allarme.
        </CardDescription>
        <CardAction>
          {engine ? <AsOf ts={engine.lastCycleAt ?? status.data?.asOf ?? 0} prefix="ultimo ciclo" /> : null}
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-[140px_140px_auto_auto]">
          <div className="grid gap-1.5">
            <Label htmlFor="engine-interval" title="Ogni quanti secondi gira un ciclo (presenza + liveness + allarmi)">Intervallo (s)</Label>
            <Input id="engine-interval" value={intervalRaw} onChange={(e) => setIntervalRaw(e.target.value)} disabled={running} placeholder="30" autoComplete="off" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="engine-radio" title="Ogni quanti cicli parte la sonda radio completa (SSID/segnale/CCQ/CPU/RAM)">Radio ogni N cicli</Label>
            <Input id="engine-radio" value={radioEveryRaw} onChange={(e) => setRadioEveryRaw(e.target.value)} disabled={running} placeholder="3" autoComplete="off" />
          </div>
          <div className="flex items-end">
            <Button onClick={() => actionMut.mutate('start')} disabled={running || actionMut.isPending}>
              {actionMut.isPending && actionMut.variables === 'start' ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
              Avvia motore
            </Button>
          </div>
          <div className="flex items-end">
            <Button variant="outline" onClick={() => actionMut.mutate('stop')} disabled={!running || actionMut.isPending}>
              {actionMut.isPending && actionMut.variables === 'stop' ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
              Arresta
            </Button>
          </div>
        </div>

        {engine ? (
          <div className="space-y-2 rounded-lg border border-border bg-raised/40 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className={running ? 'bg-ok-soft text-ok border-ok/40' : 'bg-raised text-text-2'}>
                {running ? <><CircleCheck className="size-3" aria-hidden /> attivo · tick {engine.intervalSec}s</> : 'fermo'}
              </Badge>
              {running ? (
                <Badge variant="outline" className="max-w-full whitespace-normal text-left leading-snug bg-ok-soft text-ok border-ok/40" title="Chi ha avviato questa sessione del motore">
                  avvio: {engine.startedVia === 'AUTO_RESUME' ? 'AUTO-RESUME (riavvio server)' : engine.startedVia}
                </Badge>
              ) : null}
              <Badge variant="outline" className="max-w-full whitespace-normal text-left leading-snug bg-ok-soft text-ok border-ok/40" title="Configurazione persistita in EngineRuntime: al riavvio del server il motore si riattiva da solo">
                <CircleCheck className="size-3 shrink-0" aria-hidden /> <span>auto-resume persistito</span>
              </Badge>
              <Badge variant="outline" className="bg-raised text-text-2">cicli: <span className="num">{engine.cycles}</span></Badge>
              <Badge variant="outline" className="bg-raised text-text-2">campioni scritti: <span className="num">{engine.metricsWritten}</span></Badge>
              <Badge variant="outline" className="bg-raised text-text-2">eventi: <span className="num">{engine.eventsOpened}</span> aperti / <span className="num">{engine.eventsClosed}</span> chiusi</Badge>
              <Badge variant="outline" className="bg-raised text-text-2">notifiche: <span className="num">{engine.notificationsSent}</span> inviate · <span className="num">{engine.notificationsSkipped}</span> saltate</Badge>
            </div>
            <p className="text-xs text-text-2">
              ultimo ciclo {engine.lastCycleAt ? new Date(engine.lastCycleAt).toLocaleTimeString('it-IT') : '—'} in{' '}
              <span className="num">{engine.lastCycleDurationMs != null ? `${(engine.lastCycleDurationMs / 1000).toFixed(1)} s` : '—'}</span>
              {' '}· sonde: <span className="num">{engine.pingSweeps}</span> ping · <span className="num">{engine.snmpProbes}</span> SNMP · <span className="num">{engine.radioProbes}</span> radio
            </p>
            {engine.errors.length > 0 ? (
              <ul className="space-y-0.5 text-xs text-warn">
                {engine.errors.slice(-3).map((err, i) => <li key={i}>· {err}</li>)}
              </ul>
            ) : (
              <p className="text-xs text-text-3">nessun errore di ciclo</p>
            )}
            <p className="text-xs text-text-3">
              AUTO-RESUME ENTERPRISE: la configurazione è persistita nel database — al riavvio del server il motore si RIATTIVA da solo (stessi parametri). L'arresto volontario resta volontario: non viene resuscitato.
            </p>
          </div>
        ) : runtime?.enabled ? (
          <div className="space-y-2 rounded-lg border border-border bg-raised/40 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="bg-warn-soft text-warn border-warn/40">
                <CircleAlert className="size-3" aria-hidden /> sessione non attiva in questo processo
              </Badge>
              <Badge variant="outline" className="max-w-full whitespace-normal text-left leading-snug bg-ok-soft text-ok border-ok/40">auto-resume armato · tick {runtime.intervalSec}s</Badge>
              <Badge variant="outline" className="bg-raised text-text-2">cicli storici: <span className="num">{runtime.totalCycles}</span></Badge>
            </div>
            <p className="text-xs text-text-3">
              Configurazione PERSISTITA nel DB (EngineRuntime.enabled=true): al prossimo avvio del server il motore riparte da solo — oppure riavvialo ora da qui.
              {runtime.lastHeartbeatAt ? ` Ultimo heartbeat: ${new Date(runtime.lastHeartbeatAt).toLocaleTimeString('it-IT')}.` : ''}
            </p>
          </div>
        ) : (
          <p className="text-xs text-text-2">Motore mai avviato in questa sessione: le sonde on-demand qui sopra restano comunque disponibili.</p>
        )}
      </CardContent>
    </Card>
  )
}

/* ================================================================
 * FASE 6 — Allarmi
 * ================================================================ */

function PhaseAllarmi({ onNext }: { onNext: () => void }) {
  const [threshold, setThreshold] = useState('-75')
  const [result, setResult] = useState<SetupAlarmsResult | null>(null)

  const alarmsMut = useMutation({
    mutationFn: () => api.setupAlarms({ signalThresholdDbm: Number(threshold) || -75 }),
    onSuccess: (data) => {
      setResult(data)
      toast.success('Allarmi attivati', {
        description: `${data.rules.length} regole sul plant · ${data.events.filter((e) => !e.deduplicated).length} eventi aperti sui dati reali`,
      })
    },
    onError: (e) => toastErr('Attivazione allarmi non riuscita', e),
  })

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <BellRing className="size-4 text-text-2" aria-hidden />
            6 — Allarmi: regole abbinate ai dispositivi
          </CardTitle>
          <CardDescription>
            Segnale scarso · porta che cambia stato · dispositivo offline · rete che cambia alberatura ·
            nuovi dispositivi non adottati · nuovi apparati visti. Poi la valutazione ONE-SHOT sui dati appena raccolti.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-[200px_auto]">
            <div className="grid gap-1.5">
              <Label htmlFor="alarm-threshold">Soglia segnale (dBm)</Label>
              <Input id="alarm-threshold" value={threshold} onChange={(e) => setThreshold(e.target.value)} placeholder="-75" autoComplete="off" />
            </div>
            <div className="flex items-end">
              <Button onClick={() => alarmsMut.mutate()} disabled={alarmsMut.isPending}>
                {alarmsMut.isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
                Attiva regole e valuta ORA
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {result ? (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Regole assicurate sul plant ({result.rules.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-64 overflow-auto scroll-thin rounded-md border border-border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="h-8 text-xs">Regola</TableHead>
                      <TableHead className="h-8 text-xs">Metrica</TableHead>
                      <TableHead className="h-8 text-xs">Soglia</TableHead>
                      <TableHead className="h-8 text-xs">Severità</TableHead>
                      <TableHead className="h-8 text-xs">Stato</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.rules.map((r) => (
                      <TableRow key={r.systemKey}>
                        <TableCell className="py-1.5 text-xs"><span className="font-medium">{r.name}</span> <span className="font-mono text-text-3">{r.systemKey}</span></TableCell>
                        <TableCell className="py-1.5 font-mono text-xs text-text-2">{r.metric}</TableCell>
                        <TableCell className="py-1.5 text-xs num">{r.threshold ?? '—'}</TableCell>
                        <TableCell className="py-1.5 text-xs">{r.severity}</TableCell>
                        <TableCell className="py-1.5 text-xs">
                          <Badge variant="outline" className={r.enabled ? 'bg-ok-soft text-ok border-ok/40' : ''}>
                            {r.enabled ? 'attiva' : 'spenta'}{r.justCreated ? ' · nuova' : ''}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Valutazione ORA: eventi aperti ({result.events.length})</CardTitle>
              <CardDescription>
                Controllati {result.evaluated.devicesChecked} apparati · {result.evaluated.signalLow} segnali bassi ·{' '}
                {result.evaluated.offline} offline · {result.evaluated.orphansNew} orfani nuovi ·{' '}
                {result.evaluated.topologyLinksFresh} link di topologia freschi.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {result.events.length > 0 ? (
                <ul className="max-h-56 space-y-1.5 overflow-y-auto scroll-thin rounded-md border border-border p-2">
                  {result.events.map((e) => (
                    <li key={e.eventId} className="text-xs">
                      <Badge variant="outline" className="mr-1.5 bg-raised text-text-2">{e.severity}</Badge>
                      <span className="font-medium">{e.systemKey}</span>
                      {e.deviceHostname ? <span className="text-text-2"> · {e.deviceHostname}</span> : null}
                      {e.deduplicated ? <span className="ml-1 text-text-3">(deduplicato)</span> : null}
                      <span className="ml-1 text-text-2">— {e.message}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-text-2">Nessun allarme sui dati attuali: tutto entro soglia (verità, non promessa).</p>
              )}
              {result.honestNotes.map((n, i) => (
                <p key={i} className="text-xs text-text-2">· {n}</p>
              ))}
            </CardContent>
          </Card>
        </>
      ) : null}

      <div className="flex justify-end">
        <Button onClick={onNext} variant="outline" className="gap-1.5">
          Avanti: riepilogo finale
          <ArrowRight className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  )
}

/* ================================================================
 * FASE 7 — Riepilogo (verifica globale)
 * ================================================================ */

function PhaseRiepilogo() {
  const queryClient = useQueryClient()
  const summary = useQuery({
    queryKey: ['setup-summary'],
    queryFn: () => api.setupSummary(),
  })
  const s = summary.data?.data

  const runVerify = () => {
    void queryClient.invalidateQueries({ queryKey: ['setup-summary'] })
    void summary.refetch()
  }

  if (summary.isPending) {
    return <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-20 animate-pulse rounded-lg bg-surface" />)}</div>
  }
  if (summary.isError) {
    return <ErrorPanel message={`Verifica globale non riuscita: ${errInfo(summary.error).message}`} onRetry={() => void summary.refetch()} />
  }
  if (!s) return null

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ClipboardCheck className="size-4 text-text-2" aria-hidden />
            7 — Riepilogo finale: la verifica globale
          </CardTitle>
          <CardDescription>
            Ogni numero qui è contato dal DB e dai servizi reali — l&apos;impianto «{s.plant.name}» ({s.plant.comune}).
          </CardDescription>
          <CardAction>
            <Button size="sm" variant="outline" onClick={runVerify} disabled={summary.isFetching}>
              {summary.isFetching ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : null}
              Riverifica
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="bg-raised text-text-2">
              <CheckCircle2 className="size-3" aria-hidden /> impianto {s.plant.criticalityLevel === 'SENSIBILE' ? 'SENSIBILE' : 'standard'}
            </Badge>
            <Badge variant="outline" className="bg-raised text-text-2">sedi: <span className="num">{s.importPhase.locations}</span></Badge>
            <Badge variant="outline" className="bg-raised text-text-2">
              <span className="max-w-[10rem] truncate sm:max-w-[16rem]" title={s.plant.kmzFile || undefined}>KMZ: {s.plant.kmzFile || 'non importato'}</span>
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* La «chiusura» richiesta: apparati visti, per famiglia, con stato */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard label="Apparati in inventario" value={s.importPhase.devicesInInventory} accent="info" definition="scritti nel DB (Excel + adozione)" foot={s.importPhase.devicesByType.map((t) => `${t.count} ${t.type}`).join(' · ')} />
        <KpiCard label="Visti in scansione" value={s.scanPhase.lastJob?.devicesFound ?? 0} accent="ok" definition={s.scanPhase.lastJob ? `job ${s.scanPhase.lastJob.status} su ${s.scanPhase.lastJob.subnet}` : 'nessun job'} foot={s.scanPhase.candidatesNew > 0 ? `${s.scanPhase.candidatesNew} nuovi non in inventario` : 'tutti noti'} />
        <KpiCard label="Credenziali OK" value={s.verifyPhase.credentialsOk} accent="ok" definition={`su ${s.importPhase.devicesInInventory} apparati`} foot={`${s.verifyPhase.credentialsWrong} sbagliate · ${s.verifyPhase.credentialsUnknown} non verificabili`} />
        <KpiCard label="SNMP attivo (ENABLED)" value={s.verifyPhase.snmpEnabled} accent="ok" foot={`${s.verifyPhase.pingMode} in modalità ping-only (TLC)`} />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard label="Sonde radio (2 h)" value={s.telemetryPhase.radioProbed} accent="info" foot={`${s.telemetryPhase.radioMetrics2h} campioni radio scritti`} />
        <KpiCard label="Switch sondati L2 (2 h)" value={s.telemetryPhase.l2Probed} accent="info" foot={`${s.telemetryPhase.metricSamples2h} campioni totali`} />
        <KpiCard label="TLC monitorati" value={`${s.telemetryPhase.devicesOnline} online`} accent={s.telemetryPhase.devicesOffline > 0 ? 'warn' : 'ok'} foot={`${s.telemetryPhase.devicesOffline} offline · ${s.telemetryPhase.pingSwept} spazzate ping`} />
        <KpiCard label="Online / visti (2 h)" value={`${s.telemetryPhase.devicesOnline}/${s.telemetryPhase.devicesSeen2h}`} accent="ok" definition="lastSeenAt reale" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Topologia, MAC e vendor</CardTitle>
          <CardDescription>La rete costruita dal DB: link per evidenza, MAC confrontati, vendor letti o da specificare.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-3 lg:grid-cols-6">
            <span>link totali: <span className="num font-semibold text-foreground">{s.topologyPhase.links}</span></span>
            <span>FDB: <span className="num font-semibold text-foreground">{s.topologyPhase.fdbObservations}</span></span>
            <span>ARP: <span className="num font-semibold text-foreground">{s.topologyPhase.arpEntries}</span></span>
            <span>STP: <span className="num font-semibold text-foreground">{s.topologyPhase.stpObservations}</span></span>
            <span>VLAN: <span className="num font-semibold text-foreground">{s.topologyPhase.vlans}</span></span>
            <span>MAC in inventario: <span className="num font-semibold text-foreground">{s.topologyPhase.macKnownInInventory}</span></span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {s.topologyPhase.linksByEvidence.map((e) => (
              <Badge key={e.evidence} variant="outline" className="bg-raised text-text-2">{e.evidence}: <span className="num">{e.count}</span></Badge>
            ))}
          </div>
          <div className="grid gap-2 text-xs sm:grid-cols-2">
            <p className="text-text-2">
              MAC visti in rete e NON in inventario: <span className="num font-semibold text-foreground">{s.topologyPhase.macSeenNotInInventory}</span>{' '}
              (candidati da adottare o specificare)
            </p>
            <p className="text-text-2">
              Vendor sconosciuti da specificare: <span className="num font-semibold text-foreground">{s.topologyPhase.vendorUnknown}</span>
              {s.topologyPhase.vendorUnknownDevices.length > 0 ? (
                <span className="ml-1 font-mono">({s.topologyPhase.vendorUnknownDevices.map((d) => d.hostname).join(', ')})</span>
              ) : null}
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Allarmi</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <span>regole sul plant: <span className="num font-semibold text-foreground">{s.alarmsPhase.rulesEnabled}/{s.alarmsPhase.rulesTotal} attive</span></span>
              <span>eventi aperti: <span className="num font-semibold text-foreground">{s.alarmsPhase.eventsOpen}</span></span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {s.alarmsPhase.eventsBySeverity.map((e) => (
                <Badge key={e.severity} variant="outline" className="bg-raised text-text-2">{e.severity}: <span className="num">{e.count}</span></Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Motori e servizi</CardTitle>
            <CardDescription>Stato REALE dei componenti al momento della verifica.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid gap-1.5 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-text-2">Servizio discovery (:3002)</span>
                {s.engines.discoveryService.reachable ? (
                  <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40">
                    <CircleCheck className="size-3" aria-hidden />
                    v{s.engines.discoveryService.version} · {s.engines.discoveryService.capabilities} capacità · OUI {s.engines.discoveryService.ouiPrefixes}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-crit-soft text-crit-text border-crit/40"><CircleX className="size-3" aria-hidden /> non raggiungibile</Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-text-2">Motore realtime (:3001)</span>
                <Badge variant="outline" className="bg-raised text-text-2">
                  {s.engines.realtimeService.mode === 'replay'
                    ? <><CircleCheck className="size-3 text-ok" aria-hidden /> replay attivo · tick {s.engines.realtimeService.intervalSec}s</>
                    : <><CircleAlert className="size-3 text-warn" aria-hidden /> static (tick fermo)</>}
                </Badge>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-text-2">Motore di monitoraggio (puller)</span>
                {s.engines.monitoringEngine.running ? (
                  <Badge variant="outline" className="max-w-full whitespace-normal text-left leading-snug bg-ok-soft text-ok border-ok/40">
                    <CircleCheck className="size-3 shrink-0" aria-hidden />
                    <span>attivo · {s.engines.monitoringEngine.cycles} cicli · {s.engines.monitoringEngine.metricsWritten} campioni · {s.engines.monitoringEngine.eventsOpened} eventi aperti
                    {s.engines.monitoringEngine.startedVia === 'AUTO_RESUME' ? ' · AUTO-RESUME' : ''}</span>
                  </Badge>
                ) : s.engines.monitoringEngine.autoResume ? (
                  <Badge variant="outline" className="max-w-full whitespace-normal text-left leading-snug bg-warn-soft text-warn border-warn/40">
                    <CircleAlert className="size-3 shrink-0" aria-hidden /> <span>sessione non attiva — auto-resume armato (riparte al riavvio del server)</span>
                  </Badge>
                ) : (
                  <Badge variant="outline" className="max-w-full whitespace-normal text-left leading-snug bg-warn-soft text-warn border-warn/40">
                    <CircleAlert className="size-3 shrink-0" aria-hidden /> <span>fermo — avviarlo dalla fase Telemetria</span>
                  </Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-text-2">Database</span>
                <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40"><CircleCheck className="size-3" aria-hidden /> raggiungibile (query eseguite)</Badge>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-text-2">API v2</span>
                <Badge variant="outline" className="bg-ok-soft text-ok border-ok/40"><CircleCheck className="size-3" aria-hidden /> questa risposta è la prova</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Note oneste di chiusura */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Onestà di chiusura</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-1.5">
            {s.honestNotes.map((n, i) => (
              <li key={i} className="text-xs text-text-2">· {n}</li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Il «tutto avviato?» finale, verificato riga per riga */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Il motore è avviato?</CardTitle>
          <CardDescription>Verdetto riga per riga, derivato SOLO dai numeri sopra.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-1.5 text-sm">
            <Verdict ok={s.importPhase.devicesInInventory > 0} label={`Inventario scritto: ${s.importPhase.devicesInInventory} apparati in ${s.importPhase.locations} sedi`} />
            <Verdict ok={(s.scanPhase.lastJob?.status ?? '') === 'COMPLETED'} label={`Scansione della rete: ${s.scanPhase.lastJob ? `job ${s.scanPhase.lastJob.status} (${s.scanPhase.lastJob.devicesFound} visti)` : 'mai eseguita'}`} />
            <Verdict ok={s.verifyPhase.credentialsOk > 0} label={`Credenziali verificate: ${s.verifyPhase.credentialsOk} OK · ${s.verifyPhase.credentialsWrong} sbagliate · ${s.verifyPhase.credentialsUnknown} non verificabili`} />
            <Verdict ok={s.verifyPhase.snmpEnabled > 0} label={`SNMP attivo su ${s.verifyPhase.snmpEnabled} apparati · ${s.verifyPhase.pingMode} TLC in ping-only`} />
            <Verdict ok={s.telemetryPhase.radioMetrics2h + s.telemetryPhase.pingMetrics2h > 0} label={`Telemetria raccolta: ${s.telemetryPhase.radioMetrics2h} campioni radio · ${s.telemetryPhase.pingMetrics2h} campioni ping (ultime 2 h)`} />
            <Verdict ok={s.telemetryPhase.l2Probed > 0} label={`Sonde L2 eseguite su ${s.telemetryPhase.l2Probed} switch · ${s.topologyPhase.fdbObservations} MAC osservati`} />
            <Verdict ok={s.topologyPhase.links > 0} label={`Rete topologica costruita: ${s.topologyPhase.links} link (${s.topologyPhase.linksByEvidence.map((e) => `${e.count} ${e.evidence}`).join(', ') || 'nessuno'})`} />
            <Verdict ok={s.alarmsPhase.rulesEnabled > 0} label={`Allarmi armati: ${s.alarmsPhase.rulesEnabled} regole · ${s.alarmsPhase.eventsOpen} eventi aperti`} />
            <Verdict ok={s.engines.monitoringEngine.running} label={`Monitoraggio continuo (puller): ${s.engines.monitoringEngine.running ? `attivo${s.engines.monitoringEngine.startedVia === 'AUTO_RESUME' ? ' (riattivato dall\'auto-resume dopo il riavvio del server)' : ''} — ${s.engines.monitoringEngine.cycles} cicli, ${s.engines.monitoringEngine.metricsWritten} campioni scritti dal motore, ${s.engines.monitoringEngine.eventsOpened} eventi aperti / ${s.engines.monitoringEngine.eventsClosed} chiusi, ${s.engines.monitoringEngine.notificationsSent} notifiche inviate; AUTO-RESUME: al riavvio del server riparte da solo (configurazione persistita)` : s.engines.monitoringEngine.autoResume ? 'sessione non attiva ma AUTO-RESUME ARMATO: al riavvio del server riparte da solo (configurazione persistita nel DB)' : 'FERMO — avviarlo dalla fase Telemetria (dopo l\'avvio l\'auto-resume lo mantiene vivo attraverso i riavvi del server)'}`} />
            <Verdict ok={s.engines.discoveryService.reachable} label={`Motore discovery: ${s.engines.discoveryService.reachable ? `attivo (v${s.engines.discoveryService.version}, ${s.engines.discoveryService.ouiPrefixes} prefissi OUI)` : 'FERMO — avviare il servizio :3002'}`} />
            <Verdict ok={s.engines.realtimeService.mode === 'replay'} label={`Motore realtime: ${s.engines.realtimeService.mode === 'replay' ? 'tick attivo (riproduzione demo)' : 'static — il tick demo non gira'}`} />
            <Verdict ok label="API e DB rispondono: questa pagina è generata da una query reale" />
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

function Verdict({ ok, label }: { ok: boolean; label: string }) {
  return (
    <li className="flex items-start gap-2">
      {ok
        ? <CircleCheck className="mt-0.5 size-4 shrink-0 text-ok" aria-hidden />
        : <CircleAlert className="mt-0.5 size-4 shrink-0 text-warn" aria-hidden />}
      <span className={ok ? 'text-foreground' : 'text-text-2'}>{label}</span>
    </li>
  )
}
