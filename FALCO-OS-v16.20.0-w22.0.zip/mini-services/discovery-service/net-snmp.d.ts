/* Dichiarazione ambientale minimale per net-snmp (il pacchetto non
 * pubblica tipi TypeScript). Bun NON typechecka (esegue e basta), ma
 * con questa dichiarazione anche tsc/editor non segnalano il modulo
 * come mancante. Il contratto reale è quello del README net-snmp 3.x:
 * createSession / createV3Session / get / subtree / varbind / errori. */

declare module 'net-snmp' {
  interface Varbind {
    oid: string
    type: number
    value: unknown
  }
  interface SessionOptions {
    port?: number
    timeout?: number
    retries?: number
    version?: number
    [key: string]: unknown
  }
  interface Session {
    get(oids: string[], callback: (err: Error | null, varbinds?: Varbind[]) => void): void
    subtree(
      oid: string,
      maxRepetitions: number,
      feedCallback: (varbinds: Varbind[]) => void,
      doneCallback: (err: Error | null) => void,
    ): void
    close(): void
  }
  const snmp: {
    Version1: number
    Version2c: number
    SecurityLevel: Record<string, number>
    AuthProtocols: Record<string, number>
    PrivProtocols: Record<string, number>
    RequestTimedOutError: new (message: string) => Error
    isVarbindError(varbind: Varbind): boolean
    createSession(target: string, community: string, options: SessionOptions): Session
    createV3Session(target: string, user: Record<string, unknown>, options: SessionOptions): Session
  }
  export default snmp
}
