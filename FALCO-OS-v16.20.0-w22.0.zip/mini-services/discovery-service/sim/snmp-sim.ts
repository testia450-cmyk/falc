/* ================================================================
 * SNMP Switch Simulator — verifica end-to-end del motore L2 FALCO-OS
 * ================================================================
 * Agente SNMP v1/v2c MINIMALE con BER scritto a mano (zero dipendenze):
 * risponde a Get e GetBulk (net-snmp v2c usa GetBulk per i walk).
 *
 * USO: bun sim/snmp-sim.ts [porta] [scenario]
 *   · scenario "centrale"     (default, porta 1161): SW-CENTRALE MikroTik
 *     CRS317 — 6 interfacce (ether1..6 + bridge), ether4 down;
 *   · scenario "distribuzione" (porta 1162): SW-DISTRIBUZIONE MikroTik
 *     CSS326 — 4 interfacce + bridge, NESSUN vicino LLDP/CDP (il punto
 *     del test W14: correlazione solo via FDB mutua + STP);
 *   · scenario "radio"        (porta 1163): ANT-PTP-LINK MikroTik SXT
 *     SA 5 ac — telemetria radio W20: tabelle wireless mtxrWl (stat:
 *     SSID/segnale/CCQ/SNR/frequenza/tx-rx/noise floor; registration:
 *     UN client → linkMode PTP dedotto dalla sonda), salute (mtxrHl +
 *     HOST-RESOURCES: CPU 23%, RAM 64/128 MB), ether1 1000 full-duplex
 *     (EtherLike-MIB). I valori NEGATIVI (dBm) esercitano l'encoding
 *     BER con segno del simulatore.
 *
 * Scenario CENTRALE (v16.15 W13):
 *  · 2 vicini LLDP (GW-PRINCIPALE su porta 1, NVR-SCALA su porta 2);
 *  · 1 vicino CDP su ifIndex 3 (CAM-1-IPCAM, piattaforma Hikvision);
 *  · dot1dBasePortIfIndex 1:1 (porte bridge 1..6 → ifIndex 1..6);
 *  · FDB classica: 7 MAC (1 multicast da scartare, 2 su porta 5
 *    = segmento condiviso, 1 su porta 4, SW-DISTRIBUZIONE su porta 6);
 *  · FDB Q-BRIDGE: 1 MAC solo-VLAN (vlan 20, porta 4);
 *  · STP (BRIDGE-MIB): root = GW-PRINCIPALE (8000.AA:BB:CC:11:22:33),
 *    rootPort=1 (verso GW), porta 4 disabled, porte 2/3/5/6 designate
 *    a SE STESSE ( siamo il designato dei segmenti downstream);
 *  · ARP legacy (ipNetToMedia): 5 voci IPv4 sul bridge (ifIndex 7);
 *  · VLAN statiche: 1 "default" (porte 1..6) e 20 "SRV2" (porta 4),
 *    PVID 1 su tutte le porte bridge.
 *
 * Scenario DISTRIBUZIONE (v16.15 W14 — il secondo switch):
 *  · FDB: MAC bridge di SW-CENTRALE su porta 1 (avvistamento MUTUO)
 *    + 2 endpoint (porte 2 e 3) + 1 multicast;
 *  · STP: stessa root (GW), rootPort=1 (verso SW-CENTRALE), porta 1
 *    designata da 8000.CC:CC:CC:00:00:01 (SW-CENTRALE): l'albero STP
 *    DICE chi è a monte senza alcun LLDP;
 *  · ARP MODERNA (ipNetToPhysical, RFC 4293): 3 voci — testa il
 *    parser della tabella nuova oltre alla legacy;
 *  · VLAN: solo la 1 default (porte 1..4).
 *
 * Community: SOLO "public" (le altre vengono scartate in silenzio:
 * testa il fallback multi-community del discovery).
 * ================================================================ */

import dgram from 'node:dgram'

const PORT = Number(process.argv[2] ?? 1161)
const SCENARIO = process.argv[3] === 'radio' ? 'radio' : process.argv[3] === 'distribuzione' ? 'distribuzione' : 'centrale'
/* v16.19 W21 (setup impianto): host di bind opzionale (argv[4], default
 * 0.0.0.0 = comportamento storico). Permette scenari «un apparato per
 * IP» sui molti indirizzi di loopback 127.0.0.x, così lo sweep TCP del
 * wizard vede apparati DISTINTI su porte standard (161, 22, 80). */
const BIND_HOST = process.argv[4] ?? '0.0.0.0'

/* ---------------- BER: encoder ---------------- */

function encodeLength(len: number): number[] {
  if (len < 0x80) return [len]
  const bytes: number[] = []
  let v = len
  while (v > 0) {
    bytes.unshift(v & 0xff)
    v = Math.floor(v / 256)
  }
  return [0x80 | bytes.length, ...bytes]
}

function tlv(type: number, content: Buffer): Buffer {
  return Buffer.concat([Buffer.from([type, ...encodeLength(content.length)]), content])
}

function encodeInt(value: number): Buffer {
  let v = value
  const bytes: number[] = []
  do {
    bytes.unshift(v & 0xff)
    v = Math.floor(v / 256)
  } while (v > 0)
  if (bytes[0] > 0x7f) bytes.unshift(0)
  return tlv(0x02, Buffer.from(bytes))
}

function encodeOctetString(bytes: Buffer | string): Buffer {
  const b = typeof bytes === 'string' ? Buffer.from(bytes, 'latin1') : bytes
  return tlv(0x04, b)
}

function encodeOidValue(oid: string): Buffer {
  const arcs = oid.split('.').map((a) => Number(a))
  if (arcs.length < 2) throw new Error(`oid non valido: ${oid}`)
  const out: number[] = [arcs[0] * 40 + arcs[1]]
  for (let i = 2; i < arcs.length; i++) {
    let v = arcs[i]
    const chunk: number[] = [v & 0x7f]
    v = Math.floor(v / 128)
    while (v > 0) {
      chunk.unshift((v & 0x7f) | 0x80)
      v = Math.floor(v / 128)
    }
    out.push(...chunk)
  }
  return tlv(0x06, Buffer.from(out))
}

/** Valore tipizzato SNMP: type + contenuto GREZZO (senza TLV). */
interface MibValue {
  type: number
  raw: Buffer
}

function mkInt(v: number, type = 0x02): MibValue {
  if (v < 0) {
    /* W20 — interi NEGATIVI (segnale/noise floor in dBm): complemento a
     * due MINIMALE (BER): -58 → 0xC6. Senza questo i dBm uscivano come
     * interi senza segno (198) e la validazione di intervallo della
     * sonda li scartava — silenzio disonesto, non tollerato. */
    let mag = -v
    const magBytes: number[] = []
    do {
      magBytes.unshift(mag & 0xff)
      mag = Math.floor(mag / 256)
    } while (mag > 0)
    const out = magBytes.map((b) => ~b & 0xff)
    for (let i = out.length - 1; i >= 0; i--) {
      out[i] = (out[i] + 1) & 0xff
      if (out[i] !== 0) break
    }
    return { type, raw: Buffer.from(out) }
  }
  let val = v
  const bytes: number[] = []
  do {
    bytes.unshift(val & 0xff)
    val = Math.floor(val / 256)
  } while (val > 0)
  if (bytes[0] > 0x7f) bytes.unshift(0)
  return { type, raw: Buffer.from(bytes) }
}
const STRING = (s: string): MibValue => ({ type: 0x04, raw: Buffer.from(s, 'latin1') })
const BYTES = (b: Buffer): MibValue => ({ type: 0x04, raw: b })
const OIDVAL = (oid: string): MibValue => {
  const full = encodeOidValue(oid)
  const lenBytes = encodeLength(full.length - 2 - (full.length - 2 - (full[1] & 0x7f)))
  const hdrLen = 2 + ((full[1] & 0x80) ? (full[1] & 0x7f) + 1 : 0)
  return { type: 0x06, raw: full.subarray(hdrLen) }
}
const END_OF_MIB: MibValue = { type: 0x82, raw: Buffer.alloc(0) }
const NO_SUCH_OBJECT: MibValue = { type: 0x80, raw: Buffer.alloc(0) }

function varbind(name: string, value: MibValue): Buffer {
  const nameTlv = encodeOidValue(name)
  const valueTlv = tlv(value.type, value.raw)
  return tlv(0x30, Buffer.concat([nameTlv, valueTlv]))
}

/* ---------------- BER: decoder ---------------- */

interface ParsedTlv {
  type: number
  start: number
  len: number
  next: number
}

function parseTlv(buf: Buffer, off: number): ParsedTlv {
  const type = buf[off]
  let len = buf[off + 1]
  let hdr = 2
  if (len & 0x80) {
    const n = len & 0x7f
    len = 0
    for (let i = 0; i < n; i++) len = len * 256 + buf[off + 2 + i]
    hdr = 2 + n
  }
  return { type, start: off + hdr, len, next: off + hdr + len }
}

function decodeOidBytes(bytes: Buffer): string {
  if (bytes.length === 0) return ''
  const arcs: number[] = [Math.floor(bytes[0] / 40), bytes[0] % 40]
  let val = 0
  for (let i = 1; i < bytes.length; i++) {
    val = val * 128 + (bytes[i] & 0x7f)
    if ((bytes[i] & 0x80) === 0) {
      arcs.push(val)
      val = 0
    }
  }
  return arcs.join('.')
}

function decodeIntBytes(bytes: Buffer): number {
  let v = 0
  for (const b of bytes) v = v * 256 + b
  return v
}

/* ---------------- MIB virtuale ---------------- */

const mib = new Map<string, MibValue>()

function macBytes(mac: string): Buffer {
  return Buffer.from(mac.replace(/:/g, ''), 'hex')
}

function macArcs(mac: string): string {
  return mac.replace(/:/g, '').match(/.{2}/g)!.map((h) => Number.parseInt(h, 16)).join('.')
}

/** BridgeId 8 ottetti: 2 di priorità + MAC. */
function bridgeIdBytes(priority: number, mac: string): Buffer {
  return Buffer.concat([Buffer.from([(priority >> 8) & 0xff, priority & 0xff]), macBytes(mac)])
}

/** PortId 2 ottetti: priorità + numero porta. */
function portIdBytes(priority: number, port: number): Buffer {
  return Buffer.from([priority & 0xff, port & 0xff])
}

/** Bitmap porte egress (Q-BRIDGE): la porta N → bit 7-((N-1)%8) dell'ottetto (N-1)/8. */
function portBitmap(ports: number[]): Buffer {
  const max = Math.max(...ports, 0)
  const buf = Buffer.alloc(Math.ceil(max / 8))
  for (const p of ports) {
    if (p < 1) continue
    buf[Math.floor((p - 1) / 8)] |= 0x80 >> ((p - 1) % 8)
  }
  return buf
}

/** Identità dei due switch simulati (condivise tra gli scenari). */
const CENTRALE = {
  name: 'SW-CENTRALE',
  bridgeMac: 'CC:CC:CC:00:00:01',
  priority: 0x8000,
  ifCount: 6, // ether1..6 = ifIndex 1..6, bridge = ifIndex 7
  bridgeIf: 7,
}
const DISTRIBUZIONE = {
  name: 'SW-DISTRIBUZIONE',
  bridgeMac: 'DC:DD:DD:00:00:02',
  priority: 0x8000,
  ifCount: 4, // ether1..4 = ifIndex 1..4, bridge = ifIndex 5
  bridgeIf: 5,
}
const GW = { name: 'GW-PRINCIPALE', mac: 'AA:BB:CC:11:22:33', priority: 0x8000 }

if (SCENARIO === 'radio') {
  /* ===================== SCENARIO RADIO (W20) =====================
   * Antenna PTP MikroTik: la sonda snmp-radio.ts deve leggere SSID,
   * segnale, CCQ, SNR, frequenza, tx/rx rate, noise floor, UN client
   * associato (→ AP con linkMode PTP), CPU/RAM e la porta ethernet
   * con duplex. Le colonne seguono le firme attese dal parser (vedi
   * snmp-radio.ts: ssid [5,4,6,7] · signal [3,4,7,8,9] · snr [4,6,10]
   * · ccq [12,13,11,10] · tx [1] rx [2] · freq [7,9,8]). */
  mib.set('1.3.6.1.2.1.1.1.0', STRING('RouterOS 7.15.2 (stable) SXT SA 5 ac'))
  mib.set('1.3.6.1.2.1.1.2.0', OIDVAL('1.3.6.1.4.1.14988.1'))
  mib.set('1.3.6.1.2.1.1.3.0', mkInt(7_776_600, 0x43)) // TimeTicks
  mib.set('1.3.6.1.2.1.1.5.0', STRING('ANT-PTP-LINK'))
  mib.set('1.3.6.1.2.1.1.6.0', STRING('Tetto Sede — link PTP'))

  /* --- ifTable: ether1 (ethernet) + wlan1 (radio) + bridge --- */
  const ifNames = ['ether1', 'wlan1', 'bridge']
  const ifTypes = [6, 71, 1] // ethernetCsmacd, ieee80211, other
  /* W21: ifPhysAddress dell'ether1 — il MAC VERO che la sonda vendor legge
   * (includeIfPhysAddress) e che l'adozione scrive sull'inventario. */
  mib.set('1.3.6.1.2.1.2.2.1.6.1', BYTES(Buffer.from('DEADBEEF0055', 'hex')))
  for (let i = 1; i <= 3; i++) {
    const s = String(i)
    mib.set(`1.3.6.1.2.1.2.2.1.2.${s}`, STRING(ifNames[i - 1]))
    mib.set(`1.3.6.1.2.1.2.2.1.3.${s}`, mkInt(ifTypes[i - 1]))
    mib.set(`1.3.6.1.2.1.2.2.1.5.${s}`, mkInt(i === 2 ? 866_000_000 : 1_000_000_000, 0x42)) // Gauge
    mib.set(`1.3.6.1.2.1.2.2.1.7.${s}`, mkInt(1)) // ifAdminStatus up
    mib.set(`1.3.6.1.2.1.2.2.1.8.${s}`, mkInt(1)) // ifOperStatus up
    mib.set(`1.3.6.1.2.1.31.1.1.1.1.${s}`, STRING(ifNames[i - 1])) // ifName
    mib.set(`1.3.6.1.2.1.31.1.1.1.15.${s}`, mkInt(i === 2 ? 866 : 1000, 0x42)) // ifHighSpeed
  }
  /* duplex negozziato della porta ethernet (EtherLike-MIB: 3=full) */
  mib.set('1.3.6.1.2.1.10.7.2.1.19.1', mkInt(3))

  /* --- salute: mtxrHl (MikroTik) + HOST-RESOURCES (standard) --- */
  mib.set('1.3.6.1.4.1.14988.1.1.4.3.0', mkInt(23)) // mtxrHlCpuLoad 23%
  mib.set('1.3.6.1.4.1.14988.1.1.4.4.0', mkInt(65_536)) // mtxrHl mem usata (KB)
  mib.set('1.3.6.1.4.1.14988.1.1.4.5.0', mkInt(131_072)) // mtxrHl mem totale (KB)
  mib.set('1.3.6.1.2.1.25.3.3.1.2.1', mkInt(23)) // hrProcessorLoad
  /* hrStorageTable — riga RAM (indice 1): 2=type 3=descr 4=units 5=size 6=used */
  mib.set('1.3.6.1.2.1.25.2.3.1.2.1', OIDVAL('1.3.6.1.2.1.25.2.1.2')) // hrStorageRam
  mib.set('1.3.6.1.2.1.25.2.3.1.3.1', STRING('RAM'))
  mib.set('1.3.6.1.2.1.25.2.3.1.4.1', mkInt(1024)) // allocationUnits (byte)
  mib.set('1.3.6.1.2.1.25.2.3.1.5.1', mkInt(131_072)) // size → 128 MB
  mib.set('1.3.6.1.2.1.25.2.3.1.6.1', mkInt(65_536)) // used → 64 MB

  /* --- wireless MikroTik (mtxrWl 14988.1.1.1) ---
   * tabella 3 = STAT della radio dell'apparato (indice 1 = wlan1) */
  const STAT = '1.3.6.1.4.1.14988.1.1.1.3.1'
  mib.set(`${STAT}.1.1`, mkInt(433_000)) // txRate (Kbps → 433 Mbps)
  mib.set(`${STAT}.2.1`, mkInt(407_000)) // rxRate (Kbps → 407 Mbps)
  mib.set(`${STAT}.3.1`, mkInt(-58)) // segnale dBm (NEGATIVO → BER col segno)
  mib.set(`${STAT}.4.1`, mkInt(42)) // SNR dB
  mib.set(`${STAT}.5.1`, STRING('FALCO-PTP-EGIDIO')) // SSID
  mib.set(`${STAT}.6.1`, STRING('5GHz-AC')) // banda
  mib.set(`${STAT}.7.1`, mkInt(5580)) // frequenza MHz
  mib.set(`${STAT}.8.1`, mkInt(-96)) // noise floor dBm
  mib.set(`${STAT}.12.1`, mkInt(92)) // CCQ %

  /* tabella 2 = REGISTRATION table (client associati; INDICE = MAC) */
  const REG = '1.3.6.1.4.1.14988.1.1.1.2.1'
  const CLIENT_MAC = 'D4:CA:6D:00:00:22'
  const regIdx = macArcs(CLIENT_MAC)
  mib.set(`${REG}.1.${regIdx}`, mkInt(433_000)) // txRate verso il client
  mib.set(`${REG}.2.${regIdx}`, mkInt(407_000)) // rxRate dal client
  mib.set(`${REG}.3.${regIdx}`, mkInt(-55)) // segnale del client dBm
  mib.set(`${REG}.5.${regIdx}`, STRING('192.168.88.22')) // ultimo IP visto
} else if (SCENARIO === 'centrale') {
  /* --- system --- */
  mib.set('1.3.6.1.2.1.1.1.0', STRING('RouterOS 7.15.2 (stable) CRS317-1G-16S+'))
  mib.set('1.3.6.1.2.1.1.2.0', OIDVAL('1.3.6.1.4.1.14988.1'))
  mib.set('1.3.6.1.2.1.1.3.0', mkInt(12_345_600, 0x43)) // TimeTicks
  mib.set('1.3.6.1.2.1.1.5.0', STRING(CENTRALE.name))
  mib.set('1.3.6.1.2.1.1.6.0', STRING('Sala Tecnica'))

  /* --- ifTable (ether1..6 = ifIndex 1..6, bridge = 7) --- */
  const ifNames = ['ether1', 'ether2', 'ether3', 'ether4', 'ether5', 'ether6', 'bridge']
  /* W21: MAC dell'ether1 (bridge) — è il MAC che lo scenario «distribuzione"
   * dichiara nella propria FDB: con questo la correlazione FDB_MUTUAL
   * costruisce il link switch↔switch con le porte di entrambi i lati. */
  mib.set('1.3.6.1.2.1.2.2.1.6.1', BYTES(Buffer.from('CCCCCC000001', 'hex')))
  for (let i = 1; i <= 7; i++) {
    const s = String(i)
    mib.set(`1.3.6.1.2.1.2.2.1.2.${s}`, STRING(ifNames[i - 1])) // ifDescr
    mib.set(`1.3.6.1.2.1.2.2.1.3.${s}`, mkInt(i === 7 ? 1 : 6)) // ifType
    mib.set(`1.3.6.1.2.1.2.2.1.5.${s}`, mkInt(1_000_000_000, 0x42)) // ifSpeed Gauge
    mib.set(`1.3.6.1.2.1.2.2.1.7.${s}`, mkInt(1)) // ifAdminStatus up
    mib.set(`1.3.6.1.2.1.2.2.1.8.${s}`, mkInt(i === 4 ? 2 : 1)) // ifOperStatus (ether4 down)
    mib.set(`1.3.6.1.2.1.31.1.1.1.1.${s}`, STRING(ifNames[i - 1])) // ifName
    mib.set(`1.3.6.1.2.1.31.1.1.1.15.${s}`, mkInt(1000, 0x42)) // ifHighSpeed
  }

  /* --- LLDP (lldpRemTable): GW-PRINCIPALE su porta 1, NVR-SCALA su porta 2 --- */
  const LLDP_BASE = '1.0.8802.1.1.2.1.4.1.1'
  const lldpRows: Array<{ port: number; chassisId: Buffer; chassisSubtype: number; sysName: string; sysDesc: string; portId: string; portSubtype: number; portDesc: string }> = [
    {
      port: 1,
      chassisId: macBytes(GW.mac),
      chassisSubtype: 3, // macAddress
      sysName: GW.name,
      sysDesc: 'MikroTik hEX Refresh',
      portId: 'ether3',
      portSubtype: 5, // interfaceName
      portDesc: 'ether3',
    },
    {
      port: 2,
      chassisId: Buffer.from([0x01, 192, 168, 88, 10]), // networkAddress IPv4
      chassisSubtype: 4,
      sysName: 'NVR-SCALA',
      sysDesc: 'Linux nvr 5.15.0-91-generic',
      portId: 'eth0',
      portSubtype: 5,
      portDesc: 'eth0',
    },
  ]
  for (const r of lldpRows) {
    const row = (col: number) => `${LLDP_BASE}.${col}.0.${r.port}.1`
    mib.set(row(4), BYTES(r.chassisId))
    mib.set(row(5), mkInt(r.chassisSubtype))
    mib.set(row(6), STRING(r.sysName))
    mib.set(row(7), STRING(r.sysDesc))
    mib.set(row(8), STRING(r.portId))
    mib.set(row(9), mkInt(r.portSubtype))
    mib.set(row(10), STRING(r.portDesc))
  }

  /* --- CDP (cdpCacheTable): CAM-1-IPCAM su ifIndex 3 --- */
  const CDP_BASE = '1.3.6.1.4.1.9.9.23.1.2.1.1'
  const cdpOid = (col: number) => `${CDP_BASE}.${col}.3.1`
  mib.set(cdpOid(3), STRING('CAM-1-IPCAM'))
  mib.set(cdpOid(4), STRING('Port 01'))
  mib.set(cdpOid(5), STRING('V5.7.1 build 250108'))
  mib.set(cdpOid(6), STRING('HIKVISION DS-2CD2143G2-I'))

  /* --- BRIDGE-MIB: dot1dBasePortIfIndex (porte bridge 1..6 → ifIndex 1..6) --- */
  for (let p = 1; p <= 6; p++) {
    mib.set(`1.3.6.1.2.1.17.1.4.1.2.${p}`, mkInt(p))
  }

  /* --- BRIDGE-MIB: FDB (dot1dTpFdbPort: MAC (indice) → porta) --- */
  const fdbEntries: Array<{ mac: string; port: number }> = [
    { mac: GW.mac, port: 1 }, // GW-PRINCIPALE (anche LLDP)
    { mac: 'DE:AD:BE:EF:00:11', port: 3 }, // CAM-1-IPCAM (anche CDP)
    { mac: 'DE:AD:BE:EF:00:22', port: 5 }, // CAM-2-GARDEN (segmento condiviso)
    { mac: 'DE:AD:BE:EF:00:33', port: 5 }, // AP-TETTO (segmento condiviso)
    { mac: 'DE:AD:BE:EF:00:44', port: 4 }, // SRV-UTILITY (endpoint diretto)
    { mac: DISTRIBUZIONE.bridgeMac, port: 6 }, // SW-DISTRIBUZIONE (uplink L2!)
    { mac: '01:00:5E:00:00:01', port: 1 }, // multicast: da scartare
  ]
  for (const e of fdbEntries) {
    mib.set(`1.3.6.1.2.1.17.4.3.1.2.${macArcs(e.mac)}`, mkInt(e.port))
  }

  /* --- Q-BRIDGE: dot1qTpFdbPort (indice: vlan + MAC) --- */
  mib.set(`1.3.6.1.2.1.17.7.1.2.2.1.2.20.${macArcs('DE:AD:BE:EF:00:55')}`, mkInt(4))

  /* --- v16.15 W13 — STP (BRIDGE-MIB dot1dStp) --- */
  const SELF_ID = bridgeIdBytes(CENTRALE.priority, CENTRALE.bridgeMac)
  const ROOT_ID = bridgeIdBytes(GW.priority, GW.mac)
  mib.set('1.3.6.1.2.1.17.1.1.0', BYTES(macBytes(CENTRALE.bridgeMac))) // dot1dBaseBridgeAddress
  mib.set('1.3.6.1.2.1.17.2.1.0', mkInt(3)) // dot1dStpProtocolSpecification: ieee8021d(3)
  mib.set('1.3.6.1.2.1.17.2.5.0', BYTES(ROOT_ID)) // dot1dStpDesignatedRoot = GW
  mib.set('1.3.6.1.2.1.17.2.7.0', mkInt(1)) // dot1dStpRootPort = porta 1 (verso GW)
  const STP_PORT_BASE = '1.3.6.1.2.1.17.2.15.1'
  for (let p = 1; p <= 6; p++) {
    const isUpstream = p === 1 // verso GW: il designato è lui
    const desBridge = isUpstream ? ROOT_ID : SELF_ID // downstream: siamo NOI il designato
    mib.set(`${STP_PORT_BASE}.1.${p}`, mkInt(p)) // dot1dStpPort
    mib.set(`${STP_PORT_BASE}.2.${p}`, mkInt(0x80)) // dot1dStpPortPriority
    mib.set(`${STP_PORT_BASE}.3.${p}`, mkInt(p === 4 ? 1 : 5)) // stato: disabled(1) | forwarding(5)
    mib.set(`${STP_PORT_BASE}.4.${p}`, mkInt(p === 4 ? 2 : 1)) // enable
    mib.set(`${STP_PORT_BASE}.5.${p}`, mkInt(isUpstream ? 4 : 10)) // pathCost
    mib.set(`${STP_PORT_BASE}.6.${p}`, BYTES(ROOT_ID)) // designatedRoot del segmento
    mib.set(`${STP_PORT_BASE}.7.${p}`, mkInt(isUpstream ? 0 : 4)) // designatedCost
    mib.set(`${STP_PORT_BASE}.8.${p}`, BYTES(desBridge)) // designatedBridge ← LA CHIAVE
    mib.set(`${STP_PORT_BASE}.9.${p}`, BYTES(portIdBytes(0x80, isUpstream ? 3 : p))) // designatedPort (GW: sua ether3)
    mib.set(`${STP_PORT_BASE}.11.${p}`, mkInt(isUpstream ? 4 : 10)) // pathCost32
  }

  /* --- v16.15 W13 — ARP legacy (ipNetToMedia, ifIndex = bridge 7) --- */
  const ARP_LEGACY_BASE = '1.3.6.1.2.1.4.22.1'
  const arpEntries: Array<{ ip: string; mac: string; type: number }> = [
    { ip: '192.168.88.1', mac: GW.mac, type: 3 }, // dynamic
    { ip: '192.168.88.2', mac: DISTRIBUZIONE.bridgeMac, type: 3 },
    { ip: '192.168.88.50', mac: 'DE:AD:BE:EF:00:44', type: 3 }, // SRV-UTILITY
    { ip: '192.168.88.51', mac: 'DE:AD:BE:EF:00:22', type: 3 }, // CAM-2-GARDEN
    { ip: '192.168.88.52', mac: 'DE:AD:BE:EF:00:33', type: 3 }, // AP-TETTO
    /* v16.16 W17-a: endpoint NON in inventario (prefisso IEEE reale
     * HP Inc.) — il report batch lo elenca tra i candidati adozione e
     * il pulsante «Adotta» lo promuove a dispositivo. */
    { ip: '192.168.88.61', mac: '00:1F:29:61:14:61', type: 3 },
  ]
  for (const e of arpEntries) {
    const idx = `7.${e.ip.split('.').join('.')}` // ifIndex.7 + IP nell'indice
    mib.set(`${ARP_LEGACY_BASE}.2.${idx}`, BYTES(macBytes(e.mac))) // PhysAddress
    mib.set(`${ARP_LEGACY_BASE}.4.${idx}`, mkInt(e.type)) // Type
  }

  /* --- v16.15 W13 — VLAN statiche (dot1qVlanStaticTable) --- */
  const VLAN_BASE = '1.3.6.1.2.1.17.7.1.4.3.1'
  mib.set(`${VLAN_BASE}.1.1`, STRING('default')) // VLAN 1
  mib.set(`${VLAN_BASE}.2.1`, BYTES(portBitmap([1, 2, 3, 4, 5, 6])))
  mib.set(`${VLAN_BASE}.5.1`, mkInt(1)) // RowStatus active
  mib.set(`${VLAN_BASE}.1.20`, STRING('SRV2')) // VLAN 20
  mib.set(`${VLAN_BASE}.2.20`, BYTES(portBitmap([4])))
  mib.set(`${VLAN_BASE}.5.20`, mkInt(1))
  /* PVID per porta bridge (dot1qPvid) */
  for (let p = 1; p <= 6; p++) {
    mib.set(`1.3.6.1.2.1.17.7.1.4.5.1.1.${p}`, mkInt(1))
  }
} else {
  /* ===================== SCENARIO DISTRIBUZIONE ===================== */
  mib.set('1.3.6.1.2.1.1.1.0', STRING('RouterOS 7.15.2 (stable) CSS326-24G-2S+'))
  mib.set('1.3.6.1.2.1.1.2.0', OIDVAL('1.3.6.1.4.1.14988.1'))
  mib.set('1.3.6.1.2.1.1.3.0', mkInt(9_876_500, 0x43))
  mib.set('1.3.6.1.2.1.1.5.0', STRING(DISTRIBUZIONE.name))
  mib.set('1.3.6.1.2.1.1.6.0', STRING('Ripostiglio Piano 2'))

  /* --- ifTable (ether1..4 = ifIndex 1..4, bridge = 5) --- */
  const ifNames = ['ether1', 'ether2', 'ether3', 'ether4', 'bridge']
  /* W21: MAC dell'ether1 (bridge) — avvistato dalla FDB di «centrale»:
   * con questo la correlazione FDB_MUTUAL chiude il link switch↔switch. */
  mib.set('1.3.6.1.2.1.2.2.1.6.1', BYTES(Buffer.from('DCDDDD000002', 'hex')))
  for (let i = 1; i <= 5; i++) {
    const s = String(i)
    mib.set(`1.3.6.1.2.1.2.2.1.2.${s}`, STRING(ifNames[i - 1]))
    mib.set(`1.3.6.1.2.1.2.2.1.3.${s}`, mkInt(i === 5 ? 1 : 6))
    mib.set(`1.3.6.1.2.1.2.2.1.5.${s}`, mkInt(1_000_000_000, 0x42))
    mib.set(`1.3.6.1.2.1.2.2.1.7.${s}`, mkInt(1))
    mib.set(`1.3.6.1.2.1.2.2.1.8.${s}`, mkInt(1))
    mib.set(`1.3.6.1.2.1.31.1.1.1.1.${s}`, STRING(ifNames[i - 1]))
    mib.set(`1.3.6.1.2.1.31.1.1.1.15.${s}`, mkInt(1000, 0x42))
  }

  /* --- NESSUN LLDP / CDP: la correlazione W14 deve passare da FDB+STP --- */

  /* --- dot1dBasePortIfIndex (porte bridge 1..4 → ifIndex 1..4) --- */
  for (let p = 1; p <= 4; p++) {
    mib.set(`1.3.6.1.2.1.17.1.4.1.2.${p}`, mkInt(p))
  }

  /* --- FDB: SW-CENTRALE (MAC bridge) su porta 1 + 2 endpoint --- */
  const fdbEntries: Array<{ mac: string; port: number }> = [
    { mac: CENTRALE.bridgeMac, port: 1 }, // avvistamento MUTUO di SW-CENTRALE
    { mac: 'EE:EE:EE:00:00:0A', port: 2 }, // CAM-3-CORTILE
    { mac: 'EE:EE:EE:00:00:0B', port: 3 }, // AP-MAGAZZINO
    { mac: '01:00:5E:00:00:01', port: 1 }, // multicast: da scartare
  ]
  for (const e of fdbEntries) {
    mib.set(`1.3.6.1.2.1.17.4.3.1.2.${macArcs(e.mac)}`, mkInt(e.port))
  }

  /* --- STP: root = GW; porta 1 designata da SW-CENTRALE (upstream) --- */
  const SELF_ID = bridgeIdBytes(DISTRIBUZIONE.priority, DISTRIBUZIONE.bridgeMac)
  const ROOT_ID = bridgeIdBytes(GW.priority, GW.mac)
  const UPSTREAM_ID = bridgeIdBytes(CENTRALE.priority, CENTRALE.bridgeMac)
  mib.set('1.3.6.1.2.1.17.1.1.0', BYTES(macBytes(DISTRIBUZIONE.bridgeMac)))
  mib.set('1.3.6.1.2.1.17.2.1.0', mkInt(3)) // ieee8021d
  mib.set('1.3.6.1.2.1.17.2.5.0', BYTES(ROOT_ID)) // root = GW (due hop su)
  mib.set('1.3.6.1.2.1.17.2.7.0', mkInt(1)) // rootPort = 1 (verso SW-CENTRALE)
  const STP_PORT_BASE = '1.3.6.1.2.1.17.2.15.1'
  for (let p = 1; p <= 4; p++) {
    const isUpstream = p === 1
    const desBridge = isUpstream ? UPSTREAM_ID : SELF_ID
    mib.set(`${STP_PORT_BASE}.1.${p}`, mkInt(p))
    mib.set(`${STP_PORT_BASE}.2.${p}`, mkInt(0x80))
    mib.set(`${STP_PORT_BASE}.3.${p}`, mkInt(5)) // forwarding
    mib.set(`${STP_PORT_BASE}.4.${p}`, mkInt(1))
    mib.set(`${STP_PORT_BASE}.5.${p}`, mkInt(isUpstream ? 4 : 10))
    mib.set(`${STP_PORT_BASE}.6.${p}`, BYTES(ROOT_ID))
    mib.set(`${STP_PORT_BASE}.7.${p}`, mkInt(isUpstream ? 4 : 4))
    mib.set(`${STP_PORT_BASE}.8.${p}`, BYTES(desBridge))
    mib.set(`${STP_PORT_BASE}.9.${p}`, BYTES(portIdBytes(0x80, isUpstream ? 6 : p))) // centrale ether6
    mib.set(`${STP_PORT_BASE}.11.${p}`, mkInt(isUpstream ? 4 : 10))
  }

  /* --- ARP MODERNA (ipNetToPhysical RFC 4293, ifIndex = bridge 5) --- */
  const ARP_PHYS_BASE = '1.3.6.1.2.1.4.35.1'
  const arpEntries: Array<{ ip: string; mac: string; type: number }> = [
    { ip: '192.168.88.1', mac: GW.mac, type: 3 },
    { ip: '192.168.88.3', mac: CENTRALE.bridgeMac, type: 3 },
    { ip: '192.168.88.10', mac: 'EE:EE:EE:00:00:0A', type: 3 },
    { ip: '192.168.88.11', mac: 'EE:EE:EE:00:00:0B', type: 3 },
  ]
  for (const e of arpEntries) {
    // indice: ifIndex(5) + addressType(1=IPv4) + indirizzo
    const idx = `5.1.${e.ip.split('.').join('.')}`
    mib.set(`${ARP_PHYS_BASE}.4.${idx}`, BYTES(macBytes(e.mac))) // PhysAddress
    mib.set(`${ARP_PHYS_BASE}.6.${idx}`, mkInt(e.type)) // Type
  }

  /* --- VLAN: solo la 1 default --- */
  const VLAN_BASE = '1.3.6.1.2.1.17.7.1.4.3.1'
  mib.set(`${VLAN_BASE}.1.1`, STRING('default'))
  mib.set(`${VLAN_BASE}.2.1`, BYTES(portBitmap([1, 2, 3, 4])))
  mib.set(`${VLAN_BASE}.5.1`, mkInt(1))
  for (let p = 1; p <= 4; p++) {
    mib.set(`1.3.6.1.2.1.17.7.1.4.5.1.1.${p}`, mkInt(1))
  }
}

/* ---------------- Ordinamento numerico degli OID ---------------- */

function arcsOf(oid: string): number[] {
  return oid.split('.').map(Number)
}

function compareOid(a: string, b: string): number {
  const aa = arcsOf(a)
  const bb = arcsOf(b)
  const n = Math.min(aa.length, bb.length)
  for (let i = 0; i < n; i++) {
    if (aa[i] !== bb[i]) return aa[i] - bb[i]
  }
  return aa.length - bb.length
}

const sortedOids = [...mib.keys()].sort(compareOid)

/** Primo OID della MIB strettamente > start (confronto numerico). */
function firstAfter(start: string): number {
  let lo = 0
  let hi = sortedOids.length
  while (lo < hi) {
    const mid = (lo + hi) >> 1
    if (compareOid(sortedOids[mid], start) <= 0) lo = mid + 1
    else hi = mid
  }
  return lo
}

/* ---------------- Gestione richieste ---------------- */

const CHUNK = 20 // varbind per risposta GetBulk: testa anche il walk a più passi

function handleGet(reqid: number, community: string, requestOids: string[]): Buffer {
  const vbs: Buffer[] = []
  for (const oid of requestOids) {
    const val = mib.get(oid)
    vbs.push(varbind(oid, val ?? NO_SUCH_OBJECT))
  }
  return buildResponse(reqid, community, vbs)
}

function handleGetBulk(reqid: number, community: string, startOids: string[], maxRepetitions: number): Buffer {
  // net-snmp walk: UN varbind di partenza, non-repeaters=0
  const vbs: Buffer[] = []
  const start = startOids[0] ?? '1.3.6.1'
  const idx = firstAfter(start)
  const count = Math.min(CHUNK, Math.max(1, maxRepetitions))
  let n = 0
  for (let i = idx; i < sortedOids.length && n < count; i++, n++) {
    const oid = sortedOids[i]
    vbs.push(varbind(oid, mib.get(oid)!))
  }
  if (n === 0 || n < count) {
    vbs.push(varbind('1.3.6.1', END_OF_MIB)) // segnale di fine MIB
  }
  return buildResponse(reqid, community, vbs)
}

function buildResponse(reqid: number, community: string, varbinds: Buffer[]): Buffer {
  const pduBody = Buffer.concat([
    encodeInt(reqid),
    encodeInt(0), // error-status
    encodeInt(0), // error-index
    tlv(0x30, Buffer.concat(varbinds)),
  ])
  const message = tlv(0x30, Buffer.concat([
    encodeInt(1), // v2c
    encodeOctetString(community),
    tlv(0xa2, pduBody), // ResponsePDU
  ]))
  return message
}

/* ---------------- Server UDP ---------------- */

const sock = dgram.createSocket({ type: 'udp4' })
sock.on('message', (msg: Buffer, rinfo: { address: string; port: number }) => {
  try {
    // messaggio: SEQ { INT version, STR community, PDU { ... } }
    const outer = parseTlv(msg, 0)
    if (outer.type !== 0x30) return
    let off = outer.start
    const verTlv = parseTlv(msg, off)
    const version = decodeIntBytes(msg.subarray(verTlv.start, verTlv.start + verTlv.len))
    off = verTlv.next
    const comTlv = parseTlv(msg, off)
    const community = msg.subarray(comTlv.start, comTlv.start + comTlv.len).toString('latin1')
    off = comTlv.next

    // community sbagliata: scarta in silenzio (come un agente reale)
    if (community !== 'public') {
      console.log(`[sim:${SCENARIO}] scartata richiesta community="${community}" (silenzio onesto)`)
      return
    }
    // accettiamo v1 (0) e v2c (1): la risposta v2c è accettata da entrambe
    if (version !== 0 && version !== 1) return

    const pdu = parseTlv(msg, off)
    let p = pdu.start
    const reqidTlv = parseTlv(msg, p)
    const reqid = decodeIntBytes(msg.subarray(reqidTlv.start, reqidTlv.start + reqidTlv.len))
    p = reqidTlv.next
    const p2 = parseTlv(msg, p)
    const p2val = decodeIntBytes(msg.subarray(p2.start, p2.start + p2.len))
    p = p2.next
    const p3 = parseTlv(msg, p)
    const p3val = decodeIntBytes(msg.subarray(p3.start, p3.start + p3.len))
    p = p3.next
    const vbl = parseTlv(msg, p)

    // varbind della richiesta: nome + valore (il valore non ci serve)
    const requestOids: string[] = []
    let vo = vbl.start
    while (vo < vbl.start + vbl.len) {
      const vb = parseTlv(msg, vo)
      const nameTlv = parseTlv(msg, vb.start)
      if (nameTlv.type === 0x06) {
        requestOids.push(decodeOidBytes(msg.subarray(nameTlv.start, nameTlv.start + nameTlv.len)))
      }
      vo = vb.next
    }

    let response: Buffer
    if (pdu.type === 0xa0) {
      // Get: p2 = error-status, p3 = error-index (della richiesta, ignorati)
      response = handleGet(reqid, community, requestOids)
    } else if (pdu.type === 0xa5) {
      // GetBulk: p2 = non-repeaters, p3 = max-repetitions
      const maxRep = p3val > 0 ? p3val : CHUNK
      const nonRep = p2val
      const repeaters = requestOids.slice(nonRep)
      response = nonRep === 0
        ? handleGetBulk(reqid, community, repeaters, maxRep)
        : handleGet(reqid, community, requestOids) // fallback semplice
    } else {
      return
    }

    sock.send(response, rinfo.port, rinfo.address)
  } catch (e) {
    console.log(`[sim:${SCENARIO}] errore parsing: ${e instanceof Error ? e.message : String(e)}`)
  }
})

sock.bind(PORT, BIND_HOST, () => {
  console.log(`[sim:${SCENARIO}] agente SNMP di test su ${BIND_HOST}:${PORT} (community "public", ${mib.size} OID)`)
  if (SCENARIO === 'radio') {
    console.log(`[sim:radio] ANT-PTP-LINK: 1 radio (SSID, segnale -58 dBm, CCQ 92%, SNR 42, 5580 MHz, tx/rx 433/407) · 1 client (→ linkMode PTP) · CPU 23% · RAM 64/128 MB · ether1 1000 full-duplex`)
  } else if (SCENARIO === 'centrale') {
    console.log(`[sim:${SCENARIO}] ${CENTRALE.name}: 7 if · 2 LLDP · 1 CDP · 7 FDB (1 multicast) · 1 Q-BRIDGE · STP (root GW, rootPort 1) · 5 ARP legacy · 2 VLAN · PVID`)
  } else {
    console.log(`[sim:${SCENARIO}] ${DISTRIBUZIONE.name}: 5 if · 0 LLDP/CDP · 4 FDB (MAC ${CENTRALE.name} su porta 1) · STP (root GW via ${CENTRALE.name}) · 4 ARP moderna (RFC 4293) · 1 VLAN`)
  }
})
