/* ================================================================
 * sim/http-sim.ts — v16.19 W21 (setup impianto, demo wizard)
 * ================================================================
 * Micro server HTTP per simulare un apparato «TLC» (ONT/operator
 * modem) sulla rete di test del wizard: pagina di gestione minimal
 * con Server header realistico, così la scansione TCP (porta 80) lo
 * trova VIVO e la sonda vendor legge il banner.
 *
 * Uso: bun sim/http-sim.ts <host> <porta> [nome]
 *   es. bun sim/http-sim.ts 127.0.0.5 80 "TLC-ONT"
 * Nessuna variabile d'ambiente. Nessun dato inventato oltre la pagina.
 * ================================================================ */

import { createServer } from 'node:http'

const HOST = process.argv[2] ?? '127.0.0.5'
const PORT = Number(process.argv[3] ?? 80)
const NAME = process.argv[4] ?? 'TLC-ONT'

const log = (...args: unknown[]) => console.log(`[${new Date().toISOString()}]`, ...args)

const server = createServer((req, res) => {
  if (req.url === '/' || req.url === '' || req.url === '/index.html') {
    res.writeHead(200, {
      'content-type': 'text/html; charset=utf-8',
      server: 'Alcatel-Lucent I-240W-Q ONT',
    })
    res.end(
      `<!doctype html><html><head><title>${NAME}</title></head>` +
      `<body><h1>${NAME}</h1>` +
      `<p>ONT fibra — gestione operatore (readonly).</p></body></html>`,
    )
    return
  }
  res.writeHead(404, { server: 'Alcatel-Lucent I-240W-Q ONT' })
  res.end('not found')
})

server.listen(PORT, HOST, () => {
  log(`http-sim «${NAME}» in ascolto su ${HOST}:${PORT} — banner Alcatel-Lucent ONT`)
})
