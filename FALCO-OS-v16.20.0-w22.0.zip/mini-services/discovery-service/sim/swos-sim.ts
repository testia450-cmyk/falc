/* ================================================================
 * SwOS Switch Simulator — verifica end-to-end dell'«Attivazione
 * SNMP assistita» di FALCO-OS (Task 2-b)
 * ================================================================
 * SIMULATORE ONESTO: non è uno switch MikroTik SwOS reale. Riproduce
 * il mini HTTP API di SwOS (quella di un RB260GSP) che serve alla
 * ricetta di attivazione SNMP:
 *
 *   · HTTP Digest Authentication MD5 (RFC 2617) implementata a mano
 *     con node:crypto — utente «admin», password VUOTA (default
 *     tipico di SwOS);
 *   · formato «JSON rotto» di SwOS: chiavi non quotate, stringhe
 *     hex fra apici singoli, numeri in forma 0x..;
 *   · rotte (TUTTE dietro digest): GET/POST /snmp.b, GET /link.b,
 *     GET /sys.b; qualsiasi altro path → 404 body vuoto.
 *
 * USO: bun sim/swos-sim.ts
 *   · porta FISSA 8080 su 127.0.0.1 (nessuna variabile d'ambiente);
 *   · stato iniziale: SNMP DISABILITATO
 *       en:0x00, com:'7075626c6963' (hex di "public"), ci:'', loc:''
 *
 * Digest: ogni 401 genera un nonce NUOVO. La verifica accetta sia
 * la forma con qop (response = MD5(HA1:nonce:nc:cnonce:qop:HA2))
 * sia quella legacy senza qop (response = MD5(HA1:nonce:HA2));
 * HA1 = MD5(user:realm:pass), HA2 = MD5(metodo:uri).
 *
 * Dipendenze: solo node:builtin (node:http + node:crypto).
 * ================================================================ */

import http from 'node:http'
import { createHash, randomBytes } from 'node:crypto'

/* ---------------- Costanti fisse (spec Task 2-b) ---------------- */

const HOST = '127.0.0.1'
const PORT = 8080 // PORTA FISSA: niente variabili d'ambiente
const REALM = 'SwOS'
const DIGEST_USER = 'admin'
const DIGEST_PASS = '' // password VUOTA: default tipico SwOS

const log = (...args: unknown[]) => console.log(`[${new Date().toISOString()}]`, ...args)

/* ---------------- Stato SNMP (i valori sono hex SwOS) ---------------- */

const state = {
  en: 0x00, // 0x00 = disabilitato, 0x01 = abilitato
  com: '7075626c6963', // hex ascii di "public"
  ci: '', // contact (hex, vuoto)
  loc: '', // location (hex, vuoto)
}

const hexByte = (n: number) => n.toString(16).padStart(2, '0')

/** Body GET /snmp.b: lo stato corrente nel «JSON rotto» di SwOS. */
function snmpBody(): string {
  return `{en:0x${hexByte(state.en)},com:'${state.com}',ci:'${state.ci}',loc:'${state.loc}'}`
}

/* ---------------- Digest auth MD5 (RFC 2617) ---------------- */

const md5 = (s: string) => createHash('md5').update(s).digest('hex')

/** Header WWW-Authenticate: il nonce è NUOVO a ogni 401. */
function challenge(): string {
  const nonce = randomBytes(8).toString('hex') // 16 caratteri hex
  const opaque = randomBytes(4).toString('hex') // 8 caratteri hex
  return `Digest realm="${REALM}", qop="auth", nonce="${nonce}", opaque="${opaque}"`
}

/** Parsing tollerante dei parametri dell'header Authorization. */
function parseDigestParams(header: string): Map<string, string> {
  const params = new Map<string, string>()
  const re = /([a-zA-Z0-9_-]+)\s*=\s*(?:"([^"]*)"|([^\s,]+))/g
  let m: RegExpExecArray | null
  while ((m = re.exec(header)) !== null) {
    params.set(m[1]!.toLowerCase(), m[2] ?? m[3] ?? '')
  }
  return params
}

/**
 * Verifica l'header Authorization Digest, sia nella forma con qop
 * (nc/cnonce) sia nella forma legacy senza qop. Restituisce false
 * se l'header manca, se lo username non è «admin» o se il response
 * non torna (→ 401 con nonce nuovo).
 */
function digestOk(method: string, authHeader: string | undefined): boolean {
  if (!authHeader || !/^Digest\s/i.test(authHeader)) return false
  const p = parseDigestParams(authHeader)
  const username = p.get('username')
  const nonce = p.get('nonce')
  const response = p.get('response')
  const uri = p.get('uri')
  if (!username || !nonce || !response || !uri) return false
  if (username !== DIGEST_USER) return false

  const ha1 = md5(`${username}:${REALM}:${DIGEST_PASS}`)
  const ha2 = md5(`${method}:${uri}`)
  const qop = p.get('qop')
  const expected = qop
    ? md5(`${ha1}:${nonce}:${p.get('nc') ?? ''}:${p.get('cnonce') ?? ''}:${qop}:${ha2}`)
    : md5(`${ha1}:${nonce}:${ha2}`)
  return expected === response.toLowerCase()
}

/* ---------------- POST /snmp.b ---------------- */

/**
 * Applica il body (notazione JS-object di SwOS) allo stato.
 * Ritorna null se tutto ok, oppure 'bad request'.
 *   · campi accettati: en, com, ci, loc — gli altri sono ignorati
 *     MA loggati (spec);
 *   · en: solo 0x00 o 0x01;
 *   · com: max 63 caratteri decodificati (hex → ascii);
 *   · hex malformato (caratteri non hex, lunghezza dispari) → 400.
 */
function applySnmpPost(body: string): string | null {
  // formato «JSON rotto»: chiavi nude, valori 'hex' o 0x..
  const fieldRe = /([a-zA-Z0-9_]+)\s*:\s*(?:'([^']*)'|(0x[0-9a-fA-F]+))/g
  const updates = new Map<string, string>()
  let seenRecognized = false
  let m: RegExpExecArray | null
  while ((m = fieldRe.exec(body)) !== null) {
    const key = m[1]!
    const quoted = m[2] // valore fra apici singoli (stringa hex)
    const hexnum = m[3] // valore numerico 0x..
    if (key === 'en') {
      if (hexnum === undefined) return 'bad request' // en dev'essere 0x00/0x01
      const v = Number.parseInt(hexnum, 16)
      if (v !== 0x00 && v !== 0x01) return 'bad request'
      updates.set('en', hexByte(v))
      seenRecognized = true
    } else if (key === 'com' || key === 'ci' || key === 'loc') {
      const hex = (quoted ?? '').toLowerCase()
      if (!/^[0-9a-f]*$/.test(hex) || hex.length % 2 !== 0) return 'bad request'
      if (key === 'com' && Buffer.from(hex, 'hex').length > 63) return 'bad request'
      updates.set(key, hex)
      seenRecognized = true
    } else {
      // campo non gestito: ignorato ma loggato (spec)
      log(`POST /snmp.b campo ignorato: ${key}=${quoted ?? hexnum}`)
    }
  }
  if (!seenRecognized) return 'bad request' // nessun campo riconosciuto

  if (updates.has('en')) state.en = Number.parseInt(updates.get('en')!, 16)
  if (updates.has('com')) state.com = updates.get('com')!
  if (updates.has('ci')) state.ci = updates.get('ci')!
  if (updates.has('loc')) state.loc = updates.get('loc')!
  return null
}

/* ---------------- Rotte statiche ---------------- */

const LINK_B = `{en:0x03ff,nm:['506f727431','506f727432'],an:0x03ff,spd:[0x00,0x00],dpx:0x03ff}`
const SYS_B = `{id:'73776f732d73696d',ver:'322e3130',mac:'48:aa:bb:cc:dd:ee'}`

/* ---------------- Server HTTP ---------------- */

const server = http.createServer((req, res) => {
  const method = req.method ?? 'GET'
  const path = (req.url ?? '/').split('?')[0]!

  /* 1) TUTTE le rotte stanno dietro digest */
  if (!digestOk(method, req.headers.authorization)) {
    res.writeHead(401, { 'Content-Type': 'text/plain', 'WWW-Authenticate': challenge() })
    res.end()
    req.resume() // dreniamo l'eventuale body per non sporcare la keep-alive
    log(`${method} ${path} → 401 (digest mancante o non valido)`)
    return
  }

  /* 2) GET /snmp.b — stato SNMP corrente */
  if (path === '/snmp.b' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain' })
    res.end(snmpBody())
    log(`${method} ${path} → 200`)
    return
  }

  /* 3) POST /snmp.b — aggiorna lo stato SNMP */
  if (path === '/snmp.b' && method === 'POST') {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => {
      const body = Buffer.concat(chunks).toString('utf8')
      const error = applySnmpPost(body)
      if (error !== null) {
        res.writeHead(400, { 'Content-Type': 'text/plain' })
        res.end(error)
        log(`${method} ${path} → 400 (body: ${body})`)
        return
      }
      res.writeHead(200, { 'Content-Type': 'text/plain' })
      res.end() // SwOS risponde vuoto ai POST validi
      const com = Buffer.from(state.com, 'hex').toString('latin1')
      log(`POST /snmp.b → en=0x${hexByte(state.en)} com="${com}"`)
    })
    return
  }

  /* 4) GET /link.b — porte (statico plausibile) */
  if (path === '/link.b' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain' })
    res.end(LINK_B)
    log(`${method} ${path} → 200`)
    return
  }

  /* 5) GET /sys.b — identità dello switch (statico plausibile) */
  if (path === '/sys.b' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain' })
    res.end(SYS_B)
    log(`${method} ${path} → 200`)
    return
  }

  /* 6) qualsiasi altro path (o metodo) → 404 body vuoto */
  res.writeHead(404, { 'Content-Type': 'text/plain' })
  res.end()
  req.resume()
  log(`${method} ${path} → 404`)
})

server.listen(PORT, HOST, () => {
  log(`swos-sim in ascolto su :${PORT} — digest admin/<vuota> — SNMP inizialmente DISABILITATO`)
})

/* ---------------- Chiusura pulita ---------------- */

function shutdown(signal: string): void {
  log(`ricevuto ${signal} — chiudo swos-sim`)
  server.close(() => process.exit(0))
  // rete di sicurezza: forza l'uscita comunque dopo 2 s
  setTimeout(() => process.exit(0), 2000)
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
