/* ================================================================
 * SSH Apparato Simulator — verifica end-to-end dell'«Attivazione
 * SNMP assistita» di FALCO-OS (Task 2-b)
 * ================================================================
 * SIMULATORE ONESTO: non è un apparato reale. È un server SSH
 * (pacchetto ssh2) in ascolto su 127.0.0.1:2222 che risponde ai
 * comandi `exec` (conn.exec del futuro attuatore SNMP) con output
 * plausibili in DUE dialetti:
 *
 *  · RouterOS      — comandi che iniziano con «/parola ...»
 *                    (es. /snmp set, /snmp community add|print);
 *  · BusyBox/airOS — tutto il resto, inclusi i percorsi assoluti
 *                    con slash INTERNI (/usr/etc/rc.d/rc.softreset
 *                    save): la discriminante è «primo token senza
 *                    slash oltre al primo carattere».
 *
 * USO: bun sim/ssh-sim.ts
 *   · porta FISSA 2222 su 127.0.0.1 (nessuna variabile d'ambiente);
 *   · password: SOLO admin / simpass (tutte le altre rifiutate);
 *   · host key RSA-2048 generata a runtime con node:crypto
 *     (nessun file chiave su disco);
 *   · ogni comando è loggato: EXEC (exit=N) <comando>.
 *
 * Stato iniziale DETERMINISTICO (rende riproducibili i test della
 * ricetta di attivazione SNMP):
 *   · snmpEnabled = false;
 *   · communities = [public] → il primo `/snmp community add
 *     name=public` va SEMPRE in «failure: already have such
 *     community» (percorso «warning non fatale» dell'attuatore);
 *   · /tmp/system.cfg (file virtuale in memoria):
 *       snmp.status=disabled
 *       sshd.status=enabled
 *
 * Dipendenze: node:builtin + ssh2 (già in package.json).
 * ================================================================ */

import { generateKeyPairSync } from 'node:crypto'
import { Server } from 'ssh2' // ssh2 non espone tipi: qui sotto interfacce minime ad hoc

/* ---------------- Costanti fisse (spec Task 2-b) ---------------- */

/* v16.19 W21 (setup impianto): host e porta accettati da argv per
 * istanze multiple su IP loopback distinti (default = comportamento
 * storico 127.0.0.1:2222, usato dai demo W19). */
const HOST = process.argv[2] ?? '127.0.0.1'
const PORT = Number(process.argv[3] ?? 2222)
const USER = 'admin'
const PASS = 'simpass'
const VIRT_CFG = '/tmp/system.cfg'

const log = (...args: unknown[]) => console.log(`[${new Date().toISOString()}]`, ...args)

/* ---------------- Interfacce minime per ssh2 ---------------- */

interface ExecStream {
  write(data: string | Buffer): boolean
  stderr: { write(data: string | Buffer): boolean }
  exit(code: number): void
  close(): void
}

interface AuthCtx {
  method: string
  username: string
  password?: string
  accept(): void
  reject(methodsLeft?: string[]): void
}

interface SshSession {
  on(event: 'exec', listener: (accept: () => ExecStream, reject: () => void, info: { command: string }) => void): SshSession
  on(event: string, listener: (...args: unknown[]) => void): SshSession
}

interface SshClientConn {
  on(event: 'authentication', listener: (ctx: AuthCtx) => void): SshClientConn
  on(event: 'session', listener: (accept: () => SshSession, reject: () => void) => void): SshClientConn
  on(event: 'ready' | 'end' | 'close', listener: () => void): SshClientConn
  on(event: 'error', listener: (err: Error) => void): SshClientConn
  on(event: string, listener: (...args: unknown[]) => void): SshClientConn
  end(): void
}

interface ExecResult {
  out: string
  err: string
  code: number
}

/* ---------------- Stato interno del «dispositivo» ---------------- */

const state = {
  snmpEnabled: false,
  communities: ['public'],
  /** Mini filesystem virtuale: path → righe del file. */
  files: new Map<string, string[]>([
    [VIRT_CFG, ['snmp.status=disabled', 'sshd.status=enabled']],
  ]),
}

function setSnmpEnabled(value: boolean, why: string): void {
  if (state.snmpEnabled === value) return
  state.snmpEnabled = value
  log(`stato SNMP: snmpEnabled=${value} (${why})`)
}

/* ---------------- Dialetto RouterOS ---------------- */

/**
 * Tabella `/snmp community print` in stile RouterOS:
 *   · indice largo 2 da col 0, nome da col 5;
 *   · colonna READ-WRITE a col 66, valore «no» allineato a destra
 *     (col 74-75) come nell'output reale di RouterOS.
 * Senza community: SOLO la riga d'intestazione.
 */
function communityPrint(): string {
  const head = ' #   NAME' + ' '.repeat(57) + 'READ-WRITE GROUPS'
  const rows = state.communities.map((name, i) => `${String(i).padStart(2)}   ${name.padEnd(69)}no`)
  return [head, ...rows].join('\n') + '\n'
}

/** Comandi `/...`: RouterOS risponde quasi sempre con exit 0, anche in errore. */
function routerOs(cmd: string): ExecResult {
  const tokens = cmd.split(/\s+/)

  /** Errore RouterOS «bad command name» puntando la colonna del token. */
  const badCommand = (tokenIndex: number): ExecResult => {
    const token = tokenIndex === 0 ? tokens[0]!.slice(1) : tokens[tokenIndex]!
    let col = 1 // colonna 1-based in cui inizia il token incriminato
    for (let i = 0; i < tokenIndex; i++) col += tokens[i]!.length + 1
    return { out: '', err: `\nbad command name ${token} (line 1 column ${col})\n`, code: 0 }
  }

  /** «expected end of command» per i prefissi validi ma incompleti. */
  const expectedEnd = (tokenIndex: number): ExecResult => {
    let col = 1
    for (let i = 0; i <= tokenIndex; i++) col += tokens[i]!.length + 1
    return { out: '', err: `\nexpected end of command (line 1 column ${col})\n`, code: 0 }
  }

  const head = tokens[0]!.slice(1) // primo token senza '/'
  if (head !== 'snmp') return badCommand(0)

  const sub = tokens[1]
  if (!sub) return expectedEnd(0)

  /* /snmp set enabled=yes [contact=..] [location=..] [trap-version=..] */
  if (sub === 'set') {
    const m = /(?:^|\s)enabled=(yes|no|true|false)(?=\s|$)/.exec(cmd)
    if (m) setSnmpEnabled(m[1] === 'yes' || m[1] === 'true', '/snmp set')
    // stdout VUOTO, exit 0: gli altri parametri vengono solo accettati
    return { out: '', err: '', code: 0 }
  }

  if (sub !== 'community') return badCommand(1)

  const subsub = tokens[2]
  if (!subsub) return expectedEnd(1)

  /* /snmp community add name=<community> */
  if (subsub === 'add') {
    const nameMatch = /(?:^|\s)name=([^\s]+)/.exec(cmd)
    if (!nameMatch) {
      // argomento name assente: errore non fatale, come da stile RouterOS
      return { out: '', err: 'failure: no such argument name', code: 0 }
    }
    const name = nameMatch[1]!
    if (state.communities.includes(name)) {
      // percorso «comando con warning non fatale» che l'attuatore deve
      // saper gestire: stderr ESATTO, exit 0
      return { out: '', err: 'failure: already have such community', code: 0 }
    }
    state.communities.push(name)
    return { out: '', err: '', code: 0 }
  }

  /* /snmp community print */
  if (subsub === 'print') return { out: communityPrint(), err: '', code: 0 }

  return badCommand(2)
}

/* ---------------- Dialetto shell BusyBox/airOS ---------------- */

/** Toglie le virgolette che racchiudono TUTTO l'argomento ('...' o "..."). */
function unquote(s: string): string {
  if (s.length >= 2 && ((s.startsWith("'") && s.endsWith("'")) || (s.startsWith('"') && s.endsWith('"')))) {
    return s.slice(1, -1)
  }
  return s
}

function busyBox(cmd: string): ExecResult {
  const tokens = cmd.split(/\s+/)
  const argv0 = tokens[0]!

  /* cp <a> <b> — sempre exit 0 (spec); se la sorgente esiste nel
   * filesystem virtuale ne copiamo davvero le righe. */
  if (argv0 === 'cp') {
    const src = tokens[1]
    const dst = tokens[2]
    if (src && dst && state.files.has(src)) {
      state.files.set(dst, [...state.files.get(src)!])
    }
    return { out: '', err: '', code: 0 }
  }

  /* sed -i '/^snmp\./d' /tmp/system.cfg — cancella le righe snmp.* */
  if (argv0 === 'sed') {
    const m = /^sed\s+-i\s+(['"])([^'"]+)\1\s+(\/\S+)\s*$/.exec(cmd)
    if (m && m[2] === '/^snmp\\./d' && m[3] === VIRT_CFG) {
      state.files.set(
        VIRT_CFG,
        (state.files.get(VIRT_CFG) ?? []).filter((l) => !l.startsWith('snmp.'))
      )
      return { out: '', err: '', code: 0 }
    }
    // espressione sed non prevista dal simulatore: errore onesto
    return { out: '', err: `sed: unsupported expression '${m?.[2] ?? cmd}' (ssh-sim)\n`, code: 1 }
  }

  /* echo '<testo>' [>>|>] <file> — appende/sovrascrive nel file virtuale */
  if (argv0 === 'echo') {
    const redir = /^echo\s+(.*?)\s*(>>|>)\s*(\S+)\s*$/.exec(cmd)
    if (redir) {
      const text = unquote(redir[1] ?? '')
      const append = redir[2] === '>>'
      const path = redir[3]!
      const lines = state.files.get(path) ?? []
      state.files.set(path, append ? [...lines, text] : [text])
      return { out: '', err: '', code: 0 }
    }
    // echo senza redirect: stampa e via (comportamento shell onesto)
    const plain = /^echo\s+(.*)$/.exec(cmd)
    return { out: `${unquote(plain?.[1] ?? '')}\n`, err: '', code: 0 }
  }

  /* cat <file> — stampa il contenuto del file virtuale */
  if (argv0 === 'cat') {
    const path = tokens[1]
    if (path && state.files.has(path)) {
      const lines = state.files.get(path)!
      return { out: lines.length > 0 ? lines.join('\n') + '\n' : '', err: '', code: 0 }
    }
    return { out: '', err: `cat: can't open '${path ?? ''}': No such file or directory\n`, code: 1 }
  }

  /* cfgmtd -w — salva la configurazione (airOS) */
  if (argv0 === 'cfgmtd') {
    if (/^cfgmtd\s+-w\b/.test(cmd)) {
      return { out: 'Writing 460 bytes to cfg\n', err: '', code: 0 }
    }
    return { out: '', err: 'cfgmtd: uso supportato dal sim: cfgmtd -w\n', code: 1 }
  }

  /* /usr/etc/rc.d/rc.softrestart save — applica la config (airOS):
   * nome VERIFICATO su due fonti indipendenti (issue edoput/
   * netjsonconfig#25 + operatore freifunk su airMAX XC reale:
   * «usr/etc/rc.d/rc.softrestart restarts the unit in ~20s»).
   * Accettato anche l'alias rc.softreset per tolleranza. */
  if (argv0 === '/usr/etc/rc.d/rc.softrestart' || argv0 === '/usr/etc/rc.d/rc.softreset') {
    if (cmd === argv0 || new RegExp(`^${argv0.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s+save$`).test(cmd)) {
      const cfg = state.files.get(VIRT_CFG) ?? []
      if (cfg.includes('snmp.status=enabled')) setSnmpEnabled(true, `${argv0} save`)
      return { out: 'Saving Arp cache....done\n', err: '', code: 0 }
    }
    return { out: '', err: `usage: ${argv0} save (ssh-sim)\n`, code: 1 }
  }

  /* comando sconosciuto: percorso d'errore onesto da testare (127) */
  return { out: '', err: `bash: ${argv0}: command not found\n`, code: 127 }
}

/* ---------------- Dispatch dei due dialetti ---------------- */

function handleCommand(raw: string): ExecResult {
  const cmd = raw.trim()
  if (cmd === '') return { out: '', err: '', code: 0 }
  const first = cmd.split(/\s+/)[0]!
  // RouterOS = `/parola` (nessun ALTRO slash nel primo token);
  // un path filesystem tipo /usr/etc/rc.d/rc.softreset è shell.
  const isRouterOs = first.startsWith('/') && !first.slice(1).includes('/')
  return isRouterOs ? routerOs(cmd) : busyBox(cmd)
}

/* ---------------- Server SSH ---------------- */

log('genero host key RSA-2048 a runtime (node:crypto)...')
const { privateKey } = generateKeyPairSync('rsa', {
  modulusLength: 2048,
  privateKeyEncoding: { type: 'pkcs1', format: 'pem' },
  publicKeyEncoding: { type: 'spki', format: 'pem' },
})

/** Client SSH attivi: per chiuderli tutti in shutdown pulito. */
const connections = new Set<SshClientConn>()

const server = new Server({ hostKeys: [privateKey] }, (client: SshClientConn) => {
  connections.add(client)

  client.on('authentication', (ctx: AuthCtx) => {
    const ok = ctx.method === 'password' && ctx.username === USER && ctx.password === PASS
    if (ok) {
      log(`AUTH ${ctx.username} (password) → accettata`)
      ctx.accept()
    } else {
      log(`AUTH ${ctx.username} (${ctx.method}) → RIFIUTATA`)
      ctx.reject()
    }
  })

  client.on('ready', () => log(`client autenticato: sessione SSH aperta`))

  client.on('session', (accept: () => SshSession) => {
    const session = accept()
    session.on('exec', (acceptExec: () => ExecStream, _reject: () => void, info: { command: string }) => {
      const stream = acceptExec()
      // delay artificiale 30-80 ms: un filo di realismo
      const delay = 30 + Math.floor(Math.random() * 51)
      setTimeout(() => {
        let result: ExecResult
        try {
          result = handleCommand(info.command)
        } catch (e) {
          result = { out: '', err: `ssh-sim errore interno: ${e}\n`, code: 1 }
        }
        try {
          if (result.out) stream.write(result.out)
          if (result.err) stream.stderr.write(result.err)
          stream.exit(result.code)
          stream.close()
        } catch {
          /* client già scomparso: ignoriamo */
        }
        log(`EXEC (exit=${result.code}) ${info.command}`)
      }, delay)
    })
  })

  client.on('end', () => connections.delete(client))
  client.on('close', () => connections.delete(client))
  client.on('error', (e: Error) => {
    log(`errore client SSH: ${e.message}`)
    connections.delete(client)
  })
})

server.listen(PORT, HOST, () => {
  log(
    `ssh-sim in ascolto su :${PORT} — ${USER}/${PASS} — ` +
    `stato: snmpEnabled=${state.snmpEnabled}, communities=[${state.communities.join(',')}]`
  )
})

/* ---------------- Chiusura pulita ---------------- */

function shutdown(signal: string): void {
  log(`ricevuto ${signal} — chiudo ssh-sim (${connections.size} client attivi)`)
  for (const c of connections) {
    try { c.end() } catch { /* già chiuso */ }
  }
  server.close(() => process.exit(0))
  // rete di sicurezza: forza l'uscita comunque dopo 2 s
  setTimeout(() => process.exit(0), 2000)
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
