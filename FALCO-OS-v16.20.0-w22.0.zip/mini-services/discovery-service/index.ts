/* ================================================================
 * falco-discovery-service — FALCO-OS v16.8.0 (ondata miglioramenti)
 * ================================================================
 * Mini-service di DISCOVERY, porta FISSA 3002. Motori:
 *
 *   · POST /scan              — sweep TCP-connect su CIDR IPv4 (ping
 *                               adattivo a DUE PASSATE v16.8);
 *   · POST /probe/snmp        — sonda SNMP v1/v2c/v3 MULTI-COMMUNITY
 *                               (v16.8) + identità prodotto dal sysDescr;
 *   · POST /probe/oid         — get singolo OID custom (16.7);
 *   · POST /probe/onvif       — GetDeviceInformation SOAP (WS-Security);
 *   · POST /probe/vendor      — sonda combinata: porte TCP (set v16.8
 *                               con SIP/IPP/JetDirect/TR-069) + SNMP
 *                               multi-community + banner HTTP/realm +
 *                               certificato TLS + ONVIF + OUI → fusione
 *                               evidenze e classificazione;
 *   · POST /probe/vendor/batch — v16.8: identificazione di N IP in UNA
 *                               richiesta (concurrency controllata): il
 *                               «puller» fa UN round-trip invece di N;
 *   · POST /probe/l2          — v16.8: SONTA LAYER-2 (LLDP-MIB, CDP,
 *                               BRIDGE-MIB dot1dBasePort+FDB, Q-BRIDGE,
 *                               IF-MIB) — il motore della ricostruzione
 *                               della rete in bridge;
 *   · POST /probe/radio        — v16.18 W20: TELEMETRIA RADIO & SALUTE
 *                               (CPU/RAM, SSID, segnale, CCQ, frequenza,
 *                               velocità radio, client associati, porte
 *                               ethernet con duplex) con PROVENANCE per
 *                               ogni campo: MikroTik 14988 + HOST-RESOURCES
 *                               + UCD + EtherLike + firma airMAX 41112;
 *   · POST /discover/ubiquiti — UDP 10001 broadcast TLV;
 *   · POST /discover/mndp     — UDP 5678 broadcast MikroTik;
 *   · POST /discover/onvif    — WS-Discovery Probe UDP 3702;
 *   · POST /discover/mdns     — v16.8: DNS-SD/Bonjour UDP 5353 multicast;
 *   · POST /discover/ssdp     — v16.8: UPnP SSDP UDP 1900 multicast;
 *   · GET  /oui?mac=…         — lookup OUI (10.679 prefissi IEEE).
 *
 * REGOLA D'ORO (ondata dei dati): MAI inventare dati. Timeout = esito
 * onesto «timeout», lista vuota = lista vuota. Nessun mock.
 *
 * Deadline PER-ROTTA: default ~15 s; batch (N target) e sonda L2
 * (12+ walk SNMP) hanno guardie dedicate più lunghe.
 * Server: node:http stabile con `bun --hot` (cleanup su globalThis).
 * ================================================================ */

import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'

import { expandCidr, httpBanner, isIpv4, isIpv6, pingHost, scanHostPorts, tlsCertProbe, VENDOR_PROBE_PORTS } from './lib/tcp'
import { snmpGetOid, snmpProbe, type SnmpAuthProtocol, type SnmpPrivProtocol } from './lib/snmp'
import { snmpL2Probe } from './lib/snmp-l2'
import { snmpRadioProbe } from './lib/snmp-radio'
import { SNMP_RECIPES, alternativeRecipeIds, interpolate, pickRecipeId, recipeById, recipesCatalog } from './lib/snmp-recipes'
import { snmpEnable } from './lib/snmp-enable'
import { onvifDiscoverSweep, onvifProbe, parseOnvifScopes } from './lib/onvif'
import { mndpDiscoverSweep, ubntDiscoverSweep } from './lib/udp-vendor'
import { mdnsDiscoverSweep, ssdpDiscoverSweep } from './lib/udp-service'
import { classifyDevice, type VendorEvidenceInput } from './lib/classify'
import { EXTENDED_OUI_STATS, lookupMacOui, normalizeMacAddress } from './lib/oui'
import { sshLoginProbe } from './lib/ssh-probe'

/* ---------------- Config (porta FISSA, mai env) ---------------- */

const PORT = 3002
const VERSION = '16.19.0'
const CAPABILITIES = [
  'tcp-scan',
  'snmp-v2c-v3',
  'multi-community',
  'onvif',
  'oui',
  'ubiquiti-udp',
  'mndp',
  'ws-discovery',
  // --- v16.8 ---
  'lldp-mib',
  'cdp-cache',
  'bridge-mib',
  'qbridge-mib',
  'mdns',
  'ssdp',
  'vendor-batch',
  'tls-fingerprint',
  'adaptive-ping',
  // --- v16.15 W13/W14 ---
  'stp-mib',
  'arp-table',
  'vlan-inventory',
  'l2-batch',
  // --- v16.18 W19 ---
  'snmp-actuator',
  'ssh-transport',
  'swos-api',
  'ping-presence',
  // --- v16.18 W20 ---
  'radio-telemetry',
  'health-cpu-ram',
  'etherlike-duplex',
  // --- v16.19 W21 (setup impianto) ---
  'ssh-login-probe',
]
const REQUEST_TIMEOUT_MS = 14_500 // guardia globale default (~15 s)
const BODY_LIMIT = 64 * 1024

/** Guardie dedicate: le rotte N-target e la sonda L2 hanno più lavoro
 *  REALE (walk multipli, batch) — la guardia resta, solo più realistica. */
const ROUTE_DEADLINES: Record<string, number> = {
  '/probe/vendor/batch': 55_000,
  '/probe/l2': 40_000,
  '/probe/l2/batch': 300_000, // v16.15 W14: max 12 switch × walk multipli
  '/probe/radio': 30_000, // v16.18 W20: batteria health+radio+porte (~10 walk)
  '/actuate/snmp-enable': 75_000, // v16.18 W19: SSH 7 s connect + passi 6 s + verify
  '/probe/ping': 25_000, // v16.18 W19: max 64 target di presenza × ping adattivo
  '/probe/ssh': 25_000, // v16.19 W21: login SSH (connect+auth, nessun comando)
}

const startedAt = Date.now()

/* ---------------- Log (timestamp ISO, stile realtime-service) ---------------- */

const log = (...args: unknown[]) => console.log(`[${new Date().toISOString()}]`, ...args)
const errMessage = (e: unknown) => (e instanceof Error ? e.message : String(e))

/* ---------------- bun --hot: libera le risorse della valutazione precedente ---------------- */

type CleanupFn = () => void
const g = globalThis as unknown as { __falcoDiscoveryCleanup?: CleanupFn }
if (g.__falcoDiscoveryCleanup) {
  try {
    g.__falcoDiscoveryCleanup()
  } catch {
    /* già liberate */
  }
}

/* ---------------- Helper HTTP ---------------- */

function sendJson(res: ServerResponse, status: number, payload: unknown): void {
  const body = JSON.stringify(payload)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  })
  res.end(body)
}

/** Lettura corpo JSON con limite (64 KB) — MAI crash: errore → reject pulito. */
function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    let size = 0
    req.on('data', (c: Buffer) => {
      size += c.length
      if (size > BODY_LIMIT) {
        reject(Object.assign(new Error('body troppo grande'), { code: 'PAYLOAD_TOO_LARGE' }))
        req.destroy()
        return
      }
      chunks.push(c)
    })
    req.on('end', () => {
      if (chunks.length === 0) {
        resolve({})
        return
      }
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        resolve(parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : {})
      } catch (e) {
        reject(Object.assign(new Error(`JSON non valido: ${errMessage(e).slice(0, 120)}`), { code: 'BAD_JSON' }))
      }
    })
    req.on('error', (e) => reject(Object.assign(new Error(`lettura body: ${errMessage(e)}`), { code: 'BAD_BODY' })))
  })
}

/** Deadline globale: nessuna richiesta può pendere oltre la guardia. */
function withDeadline<T>(p: Promise<T>, ms = REQUEST_TIMEOUT_MS): Promise<T | { __deadline: true }> {
  return Promise.race([p, new Promise<{ __deadline: true }>((r) => setTimeout(() => r({ __deadline: true }), ms))])
}

/* ---------------- Validatori ---------------- */

const IPV4_RE = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/

/** Host puntuale: IPv4 OPPURE IPv6 letterale (v16.8 — le sonde SNMP/
 *  ONVIF/L2 funzionano anche su IPv6; lo sweep CIDR resta IPv4). */
function requireHost(body: Record<string, unknown>): string {
  const ip = String(body.ip ?? '').trim()
  if (!isIpv4(ip) && !isIpv6(ip)) {
    throw Object.assign(new Error(`ip non valido: "${ip}"`), { code: 'BAD_IP' })
  }
  return ip
}

/** Retrocompatibilità: /scan e rotte che RICHIEDONO IPv4. */
function requireIpv4(body: Record<string, unknown>): string {
  const ip = String(body.ip ?? '').trim()
  if (!IPV4_RE.test(ip)) throw Object.assign(new Error(`ip non valido: "${ip}"`), { code: 'BAD_IP' })
  return ip
}

function clampInt(v: unknown, def: number, min: number, max: number): number {
  const n = typeof v === 'number' ? v : typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : NaN
  if (!Number.isFinite(n)) return def
  return Math.min(max, Math.max(min, Math.round(n)))
}

function parsePorts(v: unknown): number[] {
  if (v === undefined || v === null) return [...VENDOR_PROBE_PORTS]
  if (!Array.isArray(v)) throw Object.assign(new Error('ports deve essere un array di numeri'), { code: 'BAD_PORTS' })
  const ports = v
    .map((p) => (typeof p === 'number' || /^\d+$/.test(String(p)) ? Number(p) : NaN))
    .filter((p) => Number.isInteger(p) && p >= 1 && p <= 65535)
  if (ports.length === 0) throw Object.assign(new Error('nessuna porta valida (1-65535)'), { code: 'BAD_PORTS' })
  if (ports.length > 64) throw Object.assign(new Error('massimo 64 porte per scan'), { code: 'BAD_PORTS' })
  return [...new Set(ports)].sort((a, b) => a - b)
}

/** v16.8: lista community onesta — stringhe ripulite, dedup, max 8.
 *  DEFAULT ['public'] (nessuna community «indovinata» oltre la standard). */
function parseCommunities(v: unknown, fallback?: string): string[] {
  const out: string[] = []
  const push = (s: string) => {
    const c = s.trim()
    if (c !== '' && !out.includes(c)) out.push(c)
  }
  if (typeof v === 'string') push(v)
  else if (Array.isArray(v)) for (const item of v) if (typeof item === 'string') push(item)
  if (out.length === 0 && fallback !== undefined && fallback.trim() !== '') out.push(fallback.trim())
  if (out.length === 0) out.push('public')
  return out.slice(0, 8)
}

/* ---------------- Route: GET /health ---------------- */

function healthPayload() {
  return {
    ok: true,
    service: 'falco-discovery',
    uptimeSec: Math.round((Date.now() - startedAt) / 1000),
    version: VERSION,
    capabilities: CAPABILITIES,
    oui: { total: EXTENDED_OUI_STATS.total, brands: EXTENDED_OUI_STATS.brands },
  }
}

/* ---------------- Route: POST /scan ---------------- */

async function handleScan(body: Record<string, unknown>) {
  const cidrRaw = String(body.cidr ?? '').trim()
  if (!cidrRaw) throw Object.assign(new Error('cidr mancante'), { code: 'BAD_CIDR' })
  const maxHosts = clampInt(body.maxHosts, 256, 1, 1024)
  const expansion = expandCidr(cidrRaw, Math.max(65536, maxHosts))
  if (!expansion.ok) {
    throw Object.assign(new Error(expansion.detail), {
      code: expansion.error === 'TOO_LARGE' ? 'TOO_LARGE' : 'BAD_CIDR',
    })
  }
  const hosts = expansion.hosts
  if (hosts.length > maxHosts) {
    // contratto Task 25: CIDR oltre maxHosts → 400 TOO_LARGE
    throw Object.assign(new Error(`troppi host (${hosts.length} > maxHosts=${maxHosts})`), { code: 'TOO_LARGE' })
  }

  const ports = parsePorts(body.ports)
  const timeoutMs = clampInt(body.timeoutMs, 600, 100, 5000)
  const concurrency = clampInt(body.concurrency, 64, 1, 256)
  // v16.8: seconda passata adattiva OFF di default nello sweep di massa
  // (onesta al costo: raddoppia il tempo sugli host muti) — ON esplicito.
  const adaptive = body.adaptive === true

  const started = new Date()
  const t0 = Date.now()
  const results: Array<{ ip: string; alive: boolean; latencyMs: number; openPorts: Array<{ port: number; state: 'open' }>; secondPass?: boolean }> = []
  for (let i = 0; i < hosts.length; i += concurrency) {
    const batch = hosts.slice(i, i + concurrency)
    const batchResults = await Promise.all(
      batch.map((ip) => scanHostPorts(ip, ports, timeoutMs, { adaptive })),
    )
    for (const r of batchResults) {
      results.push({
        ip: r.ip,
        alive: r.alive,
        latencyMs: r.latencyMs,
        openPorts: r.openPorts,
        ...(r.secondPass ? { secondPass: true } : {}),
      })
    }
  }
  const alive = results.filter((r) => r.alive)

  return {
    status: 200,
    payload: {
      ok: true,
      job: {
        cidr: cidrRaw,
        adaptive,
        startedAt: started.toISOString(),
        finishedAt: new Date().toISOString(),
        durationMs: Date.now() - t0,
        hosts: alive.map((r) => ({
          ip: r.ip,
          alive: true as const,
          latencyMs: r.latencyMs,
          openPorts: r.openPorts,
          ...(r.secondPass ? { secondPass: true as const } : {}),
        })),
        summary: {
          scanned: hosts.length,
          up: alive.length,
          withOpenPorts: alive.filter((r) => r.openPorts.length > 0).length,
          slowHosts: alive.filter((r) => r.secondPass === true).length,
        },
      },
    },
  }
}

/* ---------------- Route: POST /probe/snmp ---------------- */

async function handleProbeSnmp(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const port = clampInt(body.port, 161, 1, 65535)
  const version = body.version === 'v1' || body.version === 'v3' ? body.version : 'v2c'
  const communities = parseCommunities(body.communities, typeof body.community === 'string' ? body.community : undefined)
  const timeoutMs = clampInt(body.timeoutMs, 2500, 300, 8000)
  const v3raw = (body.v3 && typeof body.v3 === 'object' ? body.v3 : {}) as Record<string, unknown>
  const v3Level: 'noAuthNoPriv' | 'authNoPriv' | 'authPriv' =
    v3raw.level === 'authNoPriv' ? 'authNoPriv' : v3raw.level === 'authPriv' ? 'authPriv' : 'noAuthNoPriv'
  const authProtocolRaw: unknown = v3raw.authProtocol
  const authProtocol: SnmpAuthProtocol =
    authProtocolRaw === 'md5' || authProtocolRaw === 'sha224' || authProtocolRaw === 'sha256' || authProtocolRaw === 'sha384' || authProtocolRaw === 'sha512'
      ? authProtocolRaw
      : 'sha'
  const privProtocolRaw: unknown = v3raw.privProtocol
  const privProtocol: SnmpPrivProtocol =
    privProtocolRaw === 'des' || privProtocolRaw === 'aes192' || privProtocolRaw === 'aes256'
      ? privProtocolRaw
      : 'aes'
  const v3 =
    version === 'v3'
      ? {
          level: v3Level,
          user: String(v3raw.user ?? ''),
          authProtocol,
          authKey: v3raw.authKey !== undefined ? String(v3raw.authKey) : undefined,
          privProtocol,
          privKey: v3raw.privKey !== undefined ? String(v3raw.privKey) : undefined,
        }
      : undefined

  /* v16.19 W21: includeMac → ifPhysAddress.1 nella get (il MAC è un
   *  dato d'identità: la fase credenziali del wizard lo salva
   *  sull'inventario quando manca). */
  const includeMac = body.includeMac === true
  const result = await snmpProbe({ ip, port, version, communities, timeoutMs, v3, ...(includeMac ? { includeIfPhysAddress: true } : {}) })

  if (!result.reachable) {
    return {
      status: 200,
      payload: {
        ok: true,
        result: {
          reachable: false,
          communitiesTried: version === 'v3' ? undefined : communities,
          error: result.error,
          detail: result.detail,
        },
      },
    }
  }
  return {
    status: 200,
    payload: {
      ok: true,
      result: {
        reachable: true,
        matched: result.matched,
        sysDescr: result.sysDescr,
        sysObjectID: result.sysObjectID,
        sysName: result.sysName,
        sysLocation: result.sysLocation,
        sysContact: result.sysContact,
        uptimeTicks: result.uptimeTicks,
        ifCount: result.ifCount,
        mac: includeMac ? result.mac : undefined,
        vendorGuess: result.vendorGuess,
        product: result.product,
      },
    },
  }
}

/* ---------------- Route: POST /probe/onvif ---------------- */

async function handleProbeOnvif(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const port = clampInt(body.port, 80, 1, 65535)
  const user = typeof body.user === 'string' && body.user !== '' ? body.user : undefined
  const pass = typeof body.pass === 'string' && body.pass !== '' ? body.pass : undefined
  const timeoutMs = clampInt(body.timeoutMs, 3000, 500, 8000)

  const outcome = await onvifProbe(ip, port, user, pass, timeoutMs)
  if (!outcome.reachable) {
    return { status: 200, payload: { ok: true, result: { reachable: false, error: outcome.error, detail: outcome.detail } } }
  }
  return {
    status: 200,
    payload: {
      ok: true,
      result: {
        reachable: true,
        manufacturer: outcome.manufacturer,
        model: outcome.model,
        firmwareVersion: outcome.firmwareVersion,
        serialNumber: outcome.serialNumber,
        hardwareId: outcome.hardwareId,
      },
    },
  }
}

/* ---------------- Sonda combinata vendor (core condiviso) ---------------- */

interface VendorProbeOpts {
  snmpCommunities: string[]
  snmpVersion: 'v1' | 'v2c' | 'v3'
  onvifUser?: string
  onvifPass?: string
  pingTimeoutMs: number
  /** v16.19 W21: porta SNMP dell'agente (default 161). Alcuni impianti
   *  usano porte non standard (NAT, esposizioni, laboratori): la sonda
   *  resta identica, solo la destinazione cambia. */
  snmpPort?: number
  /** v16.19 W21: porta TCP aggiuntiva da includere nello sweep e da
   *  trattare come candidato banner HTTP (es. pannello web su 8081). */
  httpPortHint?: number | null
  /** v16.19 W21: porte TCP aggiuntive dello sweep ( SSH su 2222 in
   *  laboratorio, API su porte alte…): entrano nel ping adattivo della
   *  sonda così gli openPorts le dichiarano. */
  extraTcpPorts?: number[]
}

/** Sonda combinata di UN host: ping TCP adattivo + SNMP multi-community
 *  + banner HTTP/realm + certificato TLS + ONVIF → classificazione.
 *  Usata da /probe/vendor e dal /probe/vendor/batch (stessa logica). */
async function probeVendorCore(ip: string, opts: VendorProbeOpts) {
  // (1) ping TCP (due passate) e (2) SNMP IN PARALLELO: la sonda SNMP
  //     viene comunque tentata perché è UDP — un host con tutte le porte
  //     TCP filtrate può comunque rispondere.
  // v16.19 W21: la porta SNMP arriva dalle opzioni (161 di default) e
  //     l'eventuale httpPortHint entra sia nello sweep TCP sia tra i
  //     candidati banner HTTP.
  const probePorts = [
    ...VENDOR_PROBE_PORTS,
    ...(opts.extraTcpPorts ?? []).filter((p) => !VENDOR_PROBE_PORTS.includes(p)),
    ...(opts.httpPortHint != null && !VENDOR_PROBE_PORTS.includes(opts.httpPortHint) && !(opts.extraTcpPorts ?? []).includes(opts.httpPortHint) ? [opts.httpPortHint] : []),
  ]
  const pingPromise = pingHost(ip, opts.pingTimeoutMs, probePorts)
  const snmpPromise = snmpProbe({
    ip,
    port: opts.snmpPort ?? 161,
    version: opts.snmpVersion,
    communities: opts.snmpCommunities,
    timeoutMs: 2500,
    includeIfPhysAddress: true,
  })
  const ping = await pingPromise

  const sub: {
    http: Awaited<ReturnType<typeof httpBanner>>
    onvif: Awaited<ReturnType<typeof onvifProbe>> | null
    tls: Awaited<ReturnType<typeof tlsCertProbe>>
  } = { http: null, onvif: null, tls: null }

  if (ping.alive) {
    const httpCandidates = [80, 8080, ...(opts.httpPortHint != null ? [opts.httpPortHint] : [])]
    const httpPort = httpCandidates.find((p) => ping.openPorts.includes(p)) ?? null
    const doOnvif = ping.openPorts.includes(80) || ping.openPorts.includes(8899)
    const doTls = ping.openPorts.includes(443)

    const tasks: Array<Promise<void>> = []
    if (httpPort !== null) {
      tasks.push(
        httpBanner(ip, httpPort, 2500).then((r) => {
          sub.http = r
        }),
      )
    }
    if (doTls) {
      // v16.8: impronta del certificato self-signed (CN spesso = vendor+modello)
      tasks.push(
        tlsCertProbe(ip, 443, 2500).then((r) => {
          sub.tls = r
        }),
      )
    }
    if (doOnvif) {
      tasks.push(
        onvifProbe(ip, httpPort === 80 ? 80 : 8899, opts.onvifUser, opts.onvifPass, 3000).then((r) => {
          sub.onvif = r
        }),
      )
    }
    if (tasks.length > 0) await Promise.all(tasks)
  }
  const httpBannerResult = sub.http
  const snmpResult = await snmpPromise // mai rigettata: timeout/error → reachable:false
  const onvifResult = sub.onvif
  const tlsResult = sub.tls

  // alive onesto: TCP (almeno una porta, anche alla seconda passata)
  // OPPURE prova reale SNMP (un agente che risponde in UDP dimostra la
  // vita dell'host anche a porte TCP chiuse)
  const alive = ping.alive || snmpResult.reachable

  // MAC: solo da ifPhysAddress SNMP (omissione onesta dichiarata)
  const mac = snmpResult?.reachable ? snmpResult?.mac : null
  const oui = mac ? lookupMacOui(mac) : null
  const ouiBlock: { mac: string; vendor: string; category: string } | null =
    oui && mac
      ? { mac: oui.prefixHex.match(/.{2}/g)?.join(':') ?? mac, vendor: oui.vendor, category: oui.category }
      : null

  /* Vista SNMP GIÀ ristretta al discriminante reachable (la fusione in
   * classify non vuole il campo error, solo l'identità quando c'è). */
  const snmpBlock: VendorEvidenceInput['snmp'] = snmpResult
    ? snmpResult.reachable
      ? {
          reachable: true,
          sysDescr: snmpResult.sysDescr,
          sysObjectID: snmpResult.sysObjectID,
          vendorGuess: snmpResult.vendorGuess,
          product: snmpResult.product,
        }
      : { reachable: false as const, error: snmpResult.error ?? 'error', detail: snmpResult.detail ?? '' }
    : null

  const classification = classifyDevice({
    ip,
    alive,
    openPorts: ping.openPorts,
    http: httpBannerResult
      ? {
          server: httpBannerResult.server ?? null,
          title: httpBannerResult.title ?? null,
          realm: httpBannerResult.realm ?? null,
          certCn: tlsResult?.cn ?? null,
        }
      : null,
    snmp: snmpBlock,
    onvif: onvifResult,
    oui: ouiBlock,
  })

  return {
    ip,
    alive,
    latencyMs: ping.latencyMs,
    slowHost: ping.secondPass === true,
    openPorts: ping.openPorts,
    http: httpBannerResult,
    tls: tlsResult,
    snmp: snmpResult
      ? snmpResult.reachable
        ? {
            reachable: true,
            matched: snmpResult.matched,
            sysDescr: snmpResult.sysDescr,
            sysObjectID: snmpResult.sysObjectID,
            sysName: snmpResult.sysName,
            sysLocation: snmpResult.sysLocation,
            sysContact: snmpResult.sysContact,
            uptimeTicks: snmpResult.uptimeTicks,
            ifCount: snmpResult.ifCount,
            vendorGuess: snmpResult.vendorGuess,
            product: snmpResult.product,
            /* v16.19 W21: MAC GREZZO di ifPhysAddress sempre esposto quando
             * letto — anche se il prefisso OUI non è nel database IEEE
             * (un MAC sconosciuto resta un MAC letto: il vendor si
             * specifica a mano, non si cancella il dato). */
            mac: snmpResult.mac ?? null,
          }
        : { reachable: false, error: snmpResult.error, detail: snmpResult.detail }
      : null,
    onvif: onvifResult
      ? onvifResult.reachable
        ? {
            reachable: true,
            manufacturer: onvifResult.manufacturer,
            model: onvifResult.model,
            firmwareVersion: onvifResult.firmwareVersion,
            serialNumber: onvifResult.serialNumber,
            hardwareId: onvifResult.hardwareId,
          }
        : { reachable: false, error: onvifResult.error, detail: onvifResult.detail }
      : null,
    oui: ouiBlock,
    classification,
  }
}

/* ---------------- Route: POST /probe/vendor ---------------- */

async function handleProbeVendor(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const snmpOpt = (body.snmp && typeof body.snmp === 'object' ? body.snmp : {}) as Record<string, unknown>
  const onvifOpt = (body.onvif && typeof body.onvif === 'object' ? body.onvif : {}) as Record<string, unknown>
  const pingTimeoutMs = clampInt(body.timeoutMs, 1200, 200, 4000)

  const snmpCommunities = parseCommunities(
    snmpOpt.communities,
    typeof snmpOpt.community === 'string' ? snmpOpt.community : undefined,
  )
  const snmpVersion = snmpOpt.version === 'v1' || snmpOpt.version === 'v3' ? snmpOpt.version : 'v2c'
  /* v16.19 W21: porta SNMP + hint porta HTTP (coerenti col batch). */
  const snmpPort = clampInt(snmpOpt.port, 161, 1, 65535)
  const httpPortHint = body.httpPort != null ? clampInt(body.httpPort, 80, 1, 65535) : null
  const onvifUser = typeof onvifOpt.user === 'string' && onvifOpt.user !== '' ? onvifOpt.user : undefined
  const onvifPass = typeof onvifOpt.pass === 'string' && onvifOpt.pass !== '' ? onvifOpt.pass : undefined

  const result = await probeVendorCore(ip, {
    snmpCommunities,
    snmpVersion,
    onvifUser,
    onvifPass,
    pingTimeoutMs,
    snmpPort,
    httpPortHint,
  })
  return { status: 200, payload: { ok: true, result } }
}

/* ---------------- Route: POST /probe/vendor/batch (v16.8) ---------------- */

/** Identificazione di N IP in UNA richiesta: il «puller» del backend
 *  fa UN solo round-trip (prima: N fetch sequenziali da ~5-15 s l'uno).
 *  Concurrency controllata (default 8, max 16), cap 32 target: oltre,
 *  il chiamante spezza in più batch (guardia onesta). */
async function handleVendorBatch(body: Record<string, unknown>) {
  const targetsRaw = body.targets
  if (!Array.isArray(targetsRaw) || targetsRaw.length === 0) {
    throw Object.assign(new Error('targets mancante (array di IP richiesto)'), { code: 'BAD_TARGETS' })
  }
  const targets: string[] = []
  for (const t of targetsRaw) {
    const ip = String(t ?? '').trim()
    if (!isIpv4(ip) && !isIpv6(ip)) {
      throw Object.assign(new Error(`target non valido: "${ip}"`), { code: 'BAD_TARGETS' })
    }
    if (!targets.includes(ip)) targets.push(ip)
  }
  if (targets.length > 32) {
    throw Object.assign(new Error(`massimo 32 target per batch (${targets.length}) — spezzare la richiesta`), { code: 'TOO_MANY_TARGETS' })
  }

  const snmpOpt = (body.snmp && typeof body.snmp === 'object' ? body.snmp : {}) as Record<string, unknown>
  const onvifOpt = (body.onvif && typeof body.onvif === 'object' ? body.onvif : {}) as Record<string, unknown>
  const pingTimeoutMs = clampInt(body.timeoutMs, 1200, 200, 4000)
  const concurrency = clampInt(body.concurrency, 8, 1, 16)

  const snmpCommunities = parseCommunities(
    snmpOpt.communities,
    typeof snmpOpt.community === 'string' ? snmpOpt.community : undefined,
  )
  const snmpVersion = snmpOpt.version === 'v1' || snmpOpt.version === 'v3' ? snmpOpt.version : 'v2c'
  /* v16.19 W21: porta SNMP globale del batch (161 default) + hint porta
   *  HTTP per pannelli su porte non standard. */
  const snmpPort = clampInt(snmpOpt.port, 161, 1, 65535)
  const httpPortHint = body.httpPort != null ? clampInt(body.httpPort, 80, 1, 65535) : null
  /* v16.19 W21: porte TCP aggiuntive per lo sweep della sonda. */
  const extraTcpPorts = Array.isArray(body.tcpPorts)
    ? (body.tcpPorts as unknown[]).map((p) => clampInt(p, 0, 1, 65535)).filter((p) => p > 0).slice(0, 8)
    : []
  const onvifUser = typeof onvifOpt.user === 'string' && onvifOpt.user !== '' ? onvifOpt.user : undefined
  const onvifPass = typeof onvifOpt.pass === 'string' && onvifOpt.pass !== '' ? onvifOpt.pass : undefined

  const opts: VendorProbeOpts = { snmpCommunities, snmpVersion, onvifUser, onvifPass, pingTimeoutMs, snmpPort, httpPortHint, extraTcpPorts }

  const t0 = Date.now()
  const results: Array<Awaited<ReturnType<typeof probeVendorCore>>> = []
  for (let i = 0; i < targets.length; i += concurrency) {
    const batch = targets.slice(i, i + concurrency)
    const batchResults = await Promise.all(batch.map((ip) => probeVendorCore(ip, opts)))
    results.push(...batchResults)
  }

  return {
    status: 200,
    payload: {
      ok: true,
      job: {
        concurrency,
        communitiesTried: snmpVersion === 'v3' ? undefined : snmpCommunities,
        durationMs: Date.now() - t0,
        total: results.length,
        alive: results.filter((r) => r.alive).length,
        classified: results.filter((r) => r.classification.type !== 'UNKNOWN').length,
        results,
      },
    },
  }
}

/* ---------------- Route: POST /probe/l2 (v16.8) ---------------- */

/** Forma compatta del risultato L2 per il client (batch e singolo). */
function l2ResultPayload(result: Awaited<ReturnType<typeof snmpL2Probe>>) {
  return {
    reachable: result.reachable,
    ...(result.reachable
      ? {
          matched: result.matched,
          sysName: result.sysName,
          sysDescr: result.sysDescr,
          sysObjectID: result.sysObjectID,
          lldp: result.lldp,
          cdp: result.cdp,
          bridgePorts: result.bridgePorts,
          fdb: result.fdb,
          vlanFdb: result.vlanFdb,
          interfaces: result.interfaces,
          arp: result.arp,
          stp: result.stp,
          vlans: result.vlans,
          portVlans: result.portVlans,
          warnings: result.warnings,
          summary: {
            lldpNeighbors: result.lldp.length,
            cdpNeighbors: result.cdp.length,
            bridgePorts: result.bridgePorts.length,
            fdbEntries: result.fdb.length,
            vlanFdbEntries: result.vlanFdb.length,
            interfaces: result.interfaces.length,
            arpEntries: result.arp.length,
            stpPorts: result.stp?.ports.length ?? 0,
            vlans: result.vlans.length,
          },
        }
      : {
          communitiesTried: undefined,
          error: result.error,
          detail: result.detail,
        }),
  }
}

async function handleProbeL2(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const port = clampInt(body.port, 161, 1, 65535)
  const version = body.version === 'v1' || body.version === 'v3' ? body.version : 'v2c'
  const communities = parseCommunities(body.communities, typeof body.community === 'string' ? body.community : undefined)
  const timeoutMs = clampInt(body.timeoutMs, 2000, 300, 8000)
  const walkTimeoutMs = clampInt(body.walkTimeoutMs, 1500, 300, 5000)

  const result = await snmpL2Probe({ ip, port, version, communities, timeoutMs, walkTimeoutMs })

  return {
    status: 200,
    payload: {
      ok: true,
      result: {
        ...l2ResultPayload(result),
        ...(result.reachable ? {} : { communitiesTried: version === 'v3' ? undefined : communities }),
      },
    },
  }
}

/* ---------------- Route: POST /probe/l2/batch (v16.15 W14) ---------------- */

/** Target del batch: OGNI switch può avere community/versione/porta proprie
 *  (il chiamante Next le risolve dal DB: prima la cifrata del device). */
interface L2BatchTarget {
  ip: string
  port: number
  version: 'v1' | 'v2c' | 'v3'
  communities: string[]
}

async function handleProbeL2Batch(body: Record<string, unknown>) {
  const targetsRaw = body.targets
  if (!Array.isArray(targetsRaw) || targetsRaw.length === 0) {
    throw Object.assign(new Error('targets mancante (array di apparati richiesto)'), { code: 'BAD_TARGETS' })
  }
  if (targetsRaw.length > 12) {
    throw Object.assign(new Error(`massimo 12 apparati per batch L2 (${targetsRaw.length}) — spezzare la richiesta`), { code: 'TOO_MANY_TARGETS' })
  }
  const targets: L2BatchTarget[] = []
  const seen = new Set<string>()
  for (const t of targetsRaw) {
    const o = (t && typeof t === 'object' ? t : {}) as Record<string, unknown>
    const ip = String(o.ip ?? '').trim()
    if (!isIpv4(ip) && !isIpv6(ip)) {
      throw Object.assign(new Error(`target non valido: "${ip}"`), { code: 'BAD_TARGETS' })
    }
    const port = clampInt(o.port, 161, 1, 65535)
    // dedup per ip:PORT (due agenti SNMP sullo stesso host con porte
    // diverse sono due apparati distinti — capita nelle reti OEM e nei test)
    const key = `${ip}:${port}`
    if (seen.has(key)) continue // doppioni: uno basta
    seen.add(key)
    targets.push({
      ip,
      port,
      version: o.version === 'v1' || o.version === 'v3' ? o.version : 'v2c',
      communities: parseCommunities(o.communities, typeof o.community === 'string' ? o.community : undefined),
    })
  }

  const timeoutMs = clampInt(body.timeoutMs, 2000, 300, 8000)
  const walkTimeoutMs = clampInt(body.walkTimeoutMs, 1500, 300, 5000)
  // concorrenza bassa e onesta: i walk L2 sono many-RTT e martellare UDP
  // un agente con 4 sessioni parallele alza i timeout, non la velocità
  const concurrency = clampInt(body.concurrency, 2, 1, 4)

  const t0 = Date.now()
  const results: Array<{ ip: string; port: number } & ReturnType<typeof l2ResultPayload>> = []
  for (let i = 0; i < targets.length; i += concurrency) {
    const batch = targets.slice(i, i + concurrency)
    const batchResults = await Promise.all(
      batch.map(async (t) => {
        const r = await snmpL2Probe({ ip: t.ip, port: t.port, version: t.version, communities: t.communities, timeoutMs, walkTimeoutMs })
        return { ip: t.ip, port: t.port, ...l2ResultPayload(r) }
      }),
    )
    results.push(...batchResults)
  }

  return {
    status: 200,
    payload: {
      ok: true,
      job: {
        concurrency,
        durationMs: Date.now() - t0,
        total: results.length,
        reachable: results.filter((r) => r.reachable).length,
        results,
      },
    },
  }
}

/* ---------------- Route: POST /probe/radio (v16.18 W20) ---------------- */

async function handleProbeRadio(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const port = clampInt(body.port, 161, 1, 65535)
  const version = body.version === 'v1' || body.version === 'v3' ? body.version : 'v2c'
  const communities = parseCommunities(body.communities, typeof body.community === 'string' ? body.community : undefined)
  const timeoutMs = clampInt(body.timeoutMs, 2000, 300, 8000)
  const walkTimeoutMs = clampInt(body.walkTimeoutMs, 1500, 300, 5000)

  const t0 = Date.now()
  const result = await snmpRadioProbe({ ip, port, version, communities, timeoutMs, walkTimeoutMs })
  log(`probe/radio ${ip}:${port} → reachable=${result.reachable} cpu=${result.health.cpuLoadPct ?? '–'} ram=${result.health.ramUsedKb != null ? Math.round(result.health.ramUsedKb / 1024) + 'MB' : '–'} radio=${result.radios.length} client=${result.clients.length} porte=${result.ports.length} (${Date.now() - t0}ms)`)

  return {
    status: 200,
    payload: {
      ok: true,
      result: result.reachable
        ? {
            reachable: true,
            matched: result.matched,
            sysName: result.sysName,
            sysDescr: result.sysDescr,
            sysObjectID: result.sysObjectID,
            uptimeTicks: result.uptimeTicks,
            health: result.health,
            radios: result.radios,
            clients: result.clients,
            ports: result.ports,
            provenance: result.provenance,
            warnings: result.warnings,
            notes: result.notes,
          }
        : {
            reachable: false,
            matched: version === 'v3' ? undefined : communities,
            error: result.error,
            detail: result.detail,
            notes: result.notes,
          },
    },
  }
}

/* ---------------- Route: POST /discover/* (sweep UDP, liste oneste) ---------------- */

async function handleDiscoverUbiquiti(body: Record<string, unknown>) {
  const broadcastRaw = String(body.broadcast ?? '').trim()
  const broadcast = IPV4_RE.test(broadcastRaw) ? broadcastRaw : '255.255.255.255'
  const timeoutMs = clampInt(body.timeoutMs, 2500, 500, 10000)
  const devices = await ubntDiscoverSweep(broadcast, timeoutMs)
  return {
    status: 200,
    payload: {
      ok: true,
      devices: devices.map((d) => ({ mac: d.mac, ip: d.ip, name: d.name, firmware: d.firmware, platform: d.platform })),
    },
  }
}

async function handleDiscoverMndp(body: Record<string, unknown>) {
  const timeoutMs = clampInt(body.timeoutMs, 2500, 500, 10000)
  const devices = await mndpDiscoverSweep(timeoutMs)
  return {
    status: 200,
    payload: {
      ok: true,
      devices: devices.map((d) => ({
        ip: d.ip,
        mac: d.mac,
        identity: d.identity,
        version: d.version,
        platform: d.platform,
        board: d.board,
      })),
    },
  }
}

async function handleDiscoverOnvif(body: Record<string, unknown>) {
  const timeoutMs = clampInt(body.timeoutMs, 4000, 500, 10000)
  const matches = await onvifDiscoverSweep(timeoutMs)
  const devices = matches.map((m) => {
    const ip = m.xaddr.match(/https?:\/\/([^:/]+)/)?.[1] ?? null
    const scopes = parseOnvifScopes(m.scopes ?? '')
    return {
      ip,
      xaddrs: m.xaddr,
      scopes: m.scopes ?? null,
      name: scopes.name ?? null,
      hardware: scopes.hardware ?? null,
      profile: scopes.profiles.length > 0 ? scopes.profiles.join(',') : null,
    }
  })
  return { status: 200, payload: { ok: true, devices } }
}

async function handleDiscoverMdns(body: Record<string, unknown>) {
  const timeoutMs = clampInt(body.timeoutMs, 4000, 500, 10000)
  const devices = await mdnsDiscoverSweep(timeoutMs)
  return {
    status: 200,
    payload: {
      ok: true,
      devices: devices.map((d) => ({ ip: d.ip, hostname: d.hostname, services: d.services, port: d.port })),
    },
  }
}

async function handleDiscoverSsdp(body: Record<string, unknown>) {
  const timeoutMs = clampInt(body.timeoutMs, 4000, 500, 10000)
  const devices = await ssdpDiscoverSweep(timeoutMs)
  return {
    status: 200,
    payload: {
      ok: true,
      devices: devices.map((d) => ({ ip: d.ip, server: d.server, usn: d.usn, st: d.st, location: d.location })),
    },
  }
}

/* ---------------- Route: GET /oui?mac=… ---------------- */

function handleOui(query: URLSearchParams): { status: number; payload: unknown } {
  const mac = (query.get('mac') ?? '').trim()
  if (!mac) return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: 'parametro mac mancante' } }
  const normalized = normalizeMacAddress(mac)
  if (!normalized) {
    return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: `mac non valido: "${mac}"` } }
  }
  const hit = lookupMacOui(normalized)
  if (!hit) return { status: 404, payload: { ok: false, error: 'NOT_FOUND', detail: `prefisso non nel database OUI (${normalized})` } }
  return {
    status: 200,
    payload: { ok: true, mac: normalized, prefix: hit.prefix, vendor: hit.vendor, category: hit.category, blockType: hit.blockType },
  }
}

/* ---------------- Route: POST /probe/oid (16.7 W3.5 — test OID custom) ---------------- */

async function handleProbeOid(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const oidRaw = String(body.oid ?? '').trim()
  const OID_RE = /^(\.?\d{1,10})(\.\d{1,10})*$/
  if (!OID_RE.test(oidRaw)) {
    return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: 'OID numerico atteso (es. 1.3.6.1.2.1.1.1.0)' } }
  }
  const port = clampInt(body.port, 161, 1, 65535)
  const version = body.version === 'v1' || body.version === 'v3' ? body.version : 'v2c'
  const community = typeof body.community === 'string' && body.community.trim() !== '' ? body.community : 'public'
  const timeoutMs = clampInt(body.timeoutMs, 2500, 300, 8000)
  const t0 = Date.now()
  const result = await snmpGetOid({ ip, port, version, community, oid: oidRaw, timeoutMs })
  return {
    status: 200,
    payload: { ok: true, result: { ...result, durationMs: Date.now() - t0 } },
  }
}

/* ---------------- v16.18 W19 — Attuatore SNMP assistito ---------------- */

/* ---------------- Route: POST /probe/ping (v16.18 W19 — presenza) ---------------- */

/** Sonda di PRESENZA per la modalità ping-only (telecamere): N target
 *  (max 64) in UNA richiesta, ognuno con la SUA porta di gestione
 *  (fallback: le porte probe standard). È il «poller» dichiarato del
 *  monitoraggio ICMP/TCP-adattivo: vivo, latenza, seconda passata —
 *  onesto come sempre (un host muto resta muto, timeout incluso). */
async function handleProbePing(body: Record<string, unknown>): Promise<{ status: number; payload: unknown }> {
  const rawTargets = body.targets
  if (!Array.isArray(rawTargets) || rawTargets.length === 0) {
    return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: 'targets richiesto: [{ip, port?}] (max 64)' } }
  }
  if (rawTargets.length > 64) {
    return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: 'massimo 64 target per richiesta' } }
  }
  const targets: Array<{ ip: string; ports: number[] }> = []
  for (const t of rawTargets) {
    if (t == null || typeof t !== 'object') continue
    const rec = t as Record<string, unknown>
    const ip = String(rec.ip ?? '').trim()
    if (!isIpv4(ip)) {
      return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: `IPv4 atteso, ricevuto: ${ip || '(vuoto)'}` } }
    }
    const port = clampInt(rec.port, 0, 1, 65535)
    const extraPorts = parsePorts(rec.ports)
    const ports = port > 0 ? [...new Set([port, ...extraPorts])].sort((a, b) => a - b) : extraPorts
    targets.push({ ip, ports })
  }
  const timeoutMs = clampInt(body.timeoutMs, 1200, 200, 5000)
  const t0 = Date.now()
  const results = await Promise.all(
    targets.map(async (t) => {
      const r = await pingHost(t.ip, timeoutMs, t.ports, { adaptive: true })
      return {
        ip: t.ip,
        alive: r.alive,
        latencyMs: r.latencyMs,
        openPorts: r.openPorts,
        ...(r.secondPass ? { secondPass: true } : {}),
      }
    }),
  )
  const alive = results.filter((r) => r.alive).length
  return {
    status: 200,
    payload: {
      ok: true,
      result: {
        total: results.length,
        alive,
        durationMs: Date.now() - t0,
        results,
      },
    },
  }
}

/* ---------------- Attuatore SNMP assistito (rotte /actuate/*) ---------------- */

/** GET /actuate/recipes — catalogo pubblico delle ricette (nessun
 *  segreto: comandi modello con token, fonti, confidenza). Serve alla
 *  preview lato Next/UI: l'operatore vede PRIMA cosa verrà eseguito. */
function handleActuateRecipes(): { status: number; payload: unknown } {
  return { status: 200, payload: { ok: true, result: { recipes: recipesCatalog() } } }
}

/** POST /actuate/recipe-plan — sceglie la ricetta per marca/modello/
 *  tipo (o accetta l'override dell'operatore) e la restituisce con i
 *  comandi INTERPOLATI: è ciò che la finestra mostra prima di confermare. */
async function handleActuateRecipePlan(body: Record<string, unknown>): Promise<{ status: number; payload: unknown }> {
  const brand = String(body.brand ?? '').trim()
  const model = String(body.model ?? '').trim()
  const type = String(body.type ?? '').trim()
  const community = typeof body.community === 'string' && body.community.trim() !== '' ? body.community.trim() : 'public'
  const contact = typeof body.contact === 'string' && body.contact.trim() !== '' ? body.contact.trim() : 'FALCO-OS'
  const location = typeof body.location === 'string' ? body.location.trim() : ''

  const picked = body.recipeId != null && String(body.recipeId).trim() !== ''
    ? (recipeById(String(body.recipeId).trim()) ? String(body.recipeId).trim() : pickRecipeId(brand, model, type))
    : pickRecipeId(brand, model, type)

  const recipe = recipeById(picked)
  if (!recipe) {
    return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: `ricetta sconosciuta: ${picked}` } }
  }

  const vars = { community, contact, location }
  const plan = {
    recipeId: recipe.id,
    vendor: recipe.vendor,
    family: recipe.family,
    transport: recipe.transport,
    confidence: recipe.confidence,
    source: recipe.source,
    note: recipe.note,
    webPath: recipe.webPath ?? null,
    steps: recipe.steps.map((s) => ({
      cmd: interpolate(s.cmd, vars),
      note: s.note ?? null,
      fatal: s.fatal ?? true,
      benign: s.benign ?? null,
    })),
    manualSteps: recipe.manualSteps,
  }

  return {
    status: 200,
    payload: {
      ok: true,
      result: {
        picked,
        pingOnly: recipe.transport === 'ping-only',
        alternatives: alternativeRecipeIds(picked, brand).map((id) => {
          const r = SNMP_RECIPES.find((x) => x.id === id)
          return { recipeId: id, label: r ? `${r.vendor} · ${r.family}` : id, transport: r?.transport ?? 'manual' }
        }),
        recipe: plan,
      },
    },
  }
}

/** POST /actuate/snmp-enable — ESEGUE la ricetta sull'apparato.
 *  Chiamato SOLO dal proxy Next /api/v2/discovery/snmp-enable (auth
 *  + conferma umana a monte): qui nessuna decisione, solo esecuzione
 *  onesta con verifica finale via sonda SNMP. */
async function handleActuateSnmpEnable(body: Record<string, unknown>): Promise<{ status: number; payload: unknown }> {
  const ip = String(body.ip ?? '').trim()
  if (!isIpv4(ip)) {
    return { status: 400, payload: { ok: false, error: 'BAD_IP', detail: 'IPv4 atteso' } }
  }
  const recipeId = String(body.recipeId ?? '').trim()
  if (recipeId === '' || !recipeById(recipeId)) {
    return { status: 400, payload: { ok: false, error: 'BAD_REQUEST', detail: 'recipeId richiesto e deve esistere nel catalogo' } }
  }
  const community = typeof body.community === 'string' && body.community.trim() !== '' ? body.community.trim() : 'public'
  const contact = typeof body.contact === 'string' && body.contact.trim() !== '' ? body.contact.trim() : 'FALCO-OS'
  const location = typeof body.location === 'string' ? body.location.trim() : ''
  const snmpPort = clampInt(body.snmpPort, 161, 1, 65535)
  const verifyCommunities = Array.isArray(body.verifyCommunities)
    ? (body.verifyCommunities as unknown[]).filter((c): c is string => typeof c === 'string' && c.trim() !== '').map((c) => c.trim()).slice(0, 8)
    : []

  const ssh = (body.ssh != null && typeof body.ssh === 'object')
    ? {
        port: clampInt((body.ssh as Record<string, unknown>).port, 22, 1, 65535),
        username: String((body.ssh as Record<string, unknown>).username ?? '').trim(),
        password: String((body.ssh as Record<string, unknown>).password ?? ''),
      }
    : undefined
  const swos = (body.swos != null && typeof body.swos === 'object')
    ? {
        username: String((body.swos as Record<string, unknown>).username ?? 'admin').trim(),
        password: String((body.swos as Record<string, unknown>).password ?? ''),
        port: clampInt((body.swos as Record<string, unknown>).port, 80, 1, 65535),
      }
    : undefined

  const t0 = Date.now()
  const result = await snmpEnable({ ip, recipeId, community, contact, location, ssh, swos, snmpPort, verifyCommunities })
  log(`actuate/snmp-enable ${ip} ricetta=${recipeId} → ${result.state} (${Date.now() - t0}ms)`)
  return { status: 200, payload: { ok: true, result } }
}

/* ---------------- Route: POST /probe/ssh (v16.19 W21) ---------------- */

/** Verifica del LOGIN SSH (nessun comando eseguito): l'evento 'ready'
 *  di ssh2 è la prova che utente+password sono stati accettati. */
async function handleProbeSsh(body: Record<string, unknown>) {
  const ip = requireHost(body)
  const port = clampInt(body.port, 22, 1, 65535)
  const username = typeof body.username === 'string' ? body.username.trim() : ''
  const password = typeof body.password === 'string' ? body.password : ''
  const timeoutMs = clampInt(body.timeoutMs, 7000, 1500, 20000)

  const result = await sshLoginProbe({ ip, port, username, password, timeoutMs })
  log(`probe/ssh ${ip}:${port} user=${username || '—'} → ${result.authenticated ? 'AUTH_OK' : (result.error ?? 'FAILED')} (${result.durationMs}ms)`)
  return { status: 200, payload: { ok: true, result } }
}

/* ---------------- Router ---------------- */

type Handler = (body: Record<string, unknown>, query: URLSearchParams) => Promise<{ status: number; payload: unknown }>

const POST_ROUTES: Record<string, Handler> = {
  '/scan': handleScan,
  '/probe/snmp': handleProbeSnmp,
  '/probe/oid': handleProbeOid,
  '/probe/onvif': handleProbeOnvif,
  '/probe/vendor': handleProbeVendor,
  '/probe/vendor/batch': handleVendorBatch,
  '/probe/l2': handleProbeL2,
  '/probe/l2/batch': handleProbeL2Batch,
  // --- v16.18 W20: telemetria radio & salute ---
  '/probe/radio': handleProbeRadio,
  '/discover/ubiquiti': handleDiscoverUbiquiti,
  '/discover/mndp': handleDiscoverMndp,
  '/discover/onvif': handleDiscoverOnvif,
  '/discover/mdns': handleDiscoverMdns,
  '/discover/ssdp': handleDiscoverSsdp,
  // --- v16.18 W19: presenza per la modalità ping-only ---
  '/probe/ping': handleProbePing,
  // --- v16.19 W21: verifica login SSH (setup impianto) ---
  '/probe/ssh': handleProbeSsh,
  // --- v16.18 W19: attuatore SNMP assistito ---
  '/actuate/recipe-plan': handleActuateRecipePlan,
  '/actuate/snmp-enable': handleActuateSnmpEnable,
}

const server = createServer((req, res) => {
  const started = Date.now()
  const url = new URL(req.url ?? '/', `http://127.0.0.1:${PORT}`)
  const path = url.pathname.replace(/\/+$/, '') || '/'

  const finish = (status: number, payload: unknown) => {
    sendJson(res, status, payload)
    log(`${req.method} ${path} → ${status} (${Date.now() - started}ms)`)
  }

  // GET /health
  if (req.method === 'GET' && path === '/health') {
    finish(200, healthPayload())
    return
  }
  // GET /oui?mac=…
  if (req.method === 'GET' && path === '/oui') {
    const r = handleOui(url.searchParams)
    finish(r.status, r.payload)
    return
  }
  // GET /actuate/recipes — v16.18 W19: catalogo ricette (nessun segreto)
  if (req.method === 'GET' && path === '/actuate/recipes') {
    const r = handleActuateRecipes()
    finish(r.status, r.payload)
    return
  }

  const handler = req.method === 'POST' ? POST_ROUTES[path] : undefined
  if (!handler) {
    finish(404, { ok: false, error: 'NOT_FOUND', detail: `route sconosciuta: ${req.method} ${path}` })
    return
  }

  // guardia per-rotta (batch e L2 hanno lavori reali più lunghi)
  const deadline = ROUTE_DEADLINES[path] ?? REQUEST_TIMEOUT_MS

  void (async () => {
    try {
      const body = await readJsonBody(req)
      const raced = await withDeadline(handler(body, url.searchParams), deadline)
      if (raced && typeof raced === 'object' && '__deadline' in raced) {
        finish(504, { ok: false, error: 'GLOBAL_TIMEOUT', detail: `timeout globale ${deadline}ms` })
        return
      }
      finish(raced.status, raced.payload)
    } catch (e) {
      const code = (e as { code?: string })?.code
      const detail = errMessage(e).slice(0, 200)
      if (code === 'TOO_LARGE') {
        finish(400, { ok: false, error: 'TOO_LARGE', detail })
      } else if (code === 'PAYLOAD_TOO_LARGE') {
        finish(413, { ok: false, error: 'PAYLOAD_TOO_LARGE', detail })
      } else if (code === 'BAD_JSON' || code === 'BAD_BODY') {
        finish(400, { ok: false, error: 'BAD_REQUEST', detail })
      } else if (code === 'BAD_IP' || code === 'BAD_CIDR' || code === 'BAD_PORTS' || code === 'BAD_TARGETS') {
        finish(400, { ok: false, error: 'BAD_REQUEST', detail })
      } else if (code === 'TOO_MANY_TARGETS') {
        finish(400, { ok: false, error: 'TOO_MANY_TARGETS', detail })
      } else {
        // MAI eccezione non gestita verso il client
        log('ERRORE interno route', path, detail)
        finish(500, { ok: false, error: 'INTERNAL', detail })
      }
    }
  })()
})

server.on('error', (e) => {
  log(`ERRORE server HTTP su :${PORT}:`, errMessage(e))
  process.exit(1)
})

g.__falcoDiscoveryCleanup = () => {
  try {
    server.close()
  } catch {
    /* noop */
  }
}

server.listen(PORT, () => {
  log(`falco-discovery in ascolto su :${PORT} (porta fissa, v${VERSION})`)
  log('motori: tcp-scan (2 passate) · snmp v1/v2c/v3 multi-community · l2: LLDP+CDP+BRIDGE-MIB+Q-BRIDGE+STP+ARP+VLAN · l2-batch (max 12) · RADIO&HEALTH (CPU/RAM/SSID/segnale/CCQ/client/porte+duplex, provenance per campo) · onvif · oui 10.679 prefissi · ubiquiti-udp · mndp · ws-discovery · mdns · ssdp · vendor-batch · ATTUATORE SNMP (SSH + SwOS API, ricette ' + SNMP_RECIPES.length + ')')
  log('regola d\'oro: timeout = timeout, lista vuota = lista vuota — nessun dato inventato')
})

for (const sig of ['SIGTERM', 'SIGINT'] as const) {
  process.on(sig, () => {
    log(`ricevuto ${sig}: chiusura pulita`)
    g.__falcoDiscoveryCleanup?.()
    process.exit(0)
  })
}
