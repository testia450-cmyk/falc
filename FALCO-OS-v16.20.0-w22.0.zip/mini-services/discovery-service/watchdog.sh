#!/bin/bash
# Watchdog FALCO-OS (v16.18.1): tiene in vita il dev server Next (porta
# 3000), il mini-service realtime (porta 3001) e il mini-service discovery
# (porta 3002). Nato per l'ambiente sandbox, dove l'OOM killer e il cleanup
# delle sessioni shell possono fermare i processi: qui vengono riavviati
# entro ~20 s. Log: /tmp/discovery-watchdog.log
# v16.18.1: aggiunto il realtime (muore anch'esso per OOM di sistema);
# avviato SENZA --hot come il discovery (l'hot-reload tiene in RAM copie
# extra del modulo: sulla sandbox da 4 GB è memoria regalata all'OOM
# killer — stessa decisione già documentata per il discovery).
while true; do
  if ! curl -s -m 3 -o /dev/null http://127.0.0.1:3000/api/auth/session 2>/dev/null; then
    echo "[$(date -Is)] next DOWN: riavvio" >> /tmp/discovery-watchdog.log
    cd /home/z/my-project || exit 1
    setsid nohup bun run dev >> /tmp/falco-dev.log 2>&1 < /dev/null &
    sleep 8
  fi
  if ! curl -s -m 2 http://127.0.0.1:3001/health >/dev/null 2>&1; then
    echo "[$(date -Is)] realtime DOWN: riavvio" >> /tmp/discovery-watchdog.log
    cd /home/z/my-project/mini-services/realtime-service || exit 1
    setsid nohup bun index.ts >> /tmp/falco-realtime.log 2>&1 < /dev/null &
    sleep 3
  fi
  if ! curl -s -m 2 http://127.0.0.1:3002/health >/dev/null 2>&1; then
    echo "[$(date -Is)] discovery DOWN: riavvio" >> /tmp/discovery-watchdog.log
    cd /home/z/my-project/mini-services/discovery-service || exit 1
    setsid nohup bun index.ts >> /tmp/discovery.log 2>&1 < /dev/null &
    sleep 3
  fi
  sleep 15
done
