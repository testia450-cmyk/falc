/* ================================================================
 * discovery-service/lib/classify.ts — classificazione dispositivi +
 * fusione evidenze (Task 25 → v16.8 INTELLIGENZA)
 * ================================================================
 * v16.8 — EVOLUZIONE del motore di riconoscimento:
 *   · NUOVI TIPI: UPS (APC NMC/Eaton/MGE/Vertiv), PRINTER (JetDirect,
 *     porte 9100/631, LaserJet…), PBX (UCM/3CX/Asterisk), PHONE (SIP
 *     5060 con firma VoIP), NAS (Synology/QNAP/ReadyNAS), MODEM
 *     (TR-069 7547), SERVER (agente net-snmp Linux + SSH + HTTP,
 *     ESXi, Windows gestito);
 *   · IDENTITÀ PRODOTTO: dal sysDescr via guessProductIdentity di
 *     snmp.ts (IOS/NX-OS/ASA, RouterOS, ePMP, FortiOS, VRP, Comware,
 *     Linux, Windows, DSM, APC NMC) → os/osVersion/model/fwVersion
 *     nella classificazione — ciò che l'apparato DICHIARA, non supposizioni;
 *   · CONFIDENZA PESATA: punteggio per fonte (ONVIF 4 · enterprise-OID
 *     3 · sysDescr 2 · banner 1,5 · OUI 0,75 · porte 0,5) con soglie
 *     high ≥3 / medium ≥1,5; la concordanza di ≥2 fonti resta «high»;
 *   · FIRME VENDOR ALLARGATE (Arista, H3C, Synology, QNAP, DrayTek,
 *     Yealink, Fanvil, printer brand, pfSense/VyOS…).
 *
 * Fusione evidenze con priorità v15: ONVIF > SNMP sysDescr > banner
 * HTTP > porte; MAC/OUI come segnale di supporto. NESSUN dato inventato:
 * senza firme il tipo resta UNKNOWN e il brand null.
 * ================================================================ */

import type { ProductIdentity } from './snmp'

/* ---------------- Firme vendor su banner/titolo/sysDescr ---------------- */

/** guessVendor v16.8: firme banner/titolo/sysDescr (v15 + allargate). */
export function guessVendor(text?: string | null): string | null {
  const t = (text || '').toLowerCase()
  if (!t) return null
  if (/(ubiquiti|airos|airmax|unifi|nanobeam|litebeam|powerbeam|nanostation|aircube|edgeswitch|edgerouter|edgeos|ubnt|amplifi)/.test(t)) return 'Ubiquiti'
  if (/(mikrotik|routeros|router ?os|winbox|swos)/.test(t)) return 'MikroTik'
  if (/(cambium|epmp|cnmaestro|cnmatrix|canopy|pmp ?450|cnpulse|cnreach)/.test(t)) return 'Cambium'
  if (/hikvision/.test(t)) return 'Hikvision'
  if (/(dahua|imou)/.test(t)) return 'Dahua'
  if (/(tp-?link|omada|archer)/.test(t)) return 'TP-Link'
  if (/(cisco|catalyst|nexus operating|adaptive security appliance)/.test(t)) return 'Cisco'
  if (/meraki/.test(t)) return 'Meraki'
  if (/axis/.test(t)) return 'Axis'
  if (/\bhuawei\b|versatile routing platform|\bvrp\b/.test(t)) return 'Huawei'
  if (/\bh3c\b|comware/.test(t)) return 'H3C'
  if (/(planet|gs105|gs205|gs305|gs322)/.test(t)) return 'Planet'
  if (/(zyxel|gs1900|xs1930)/.test(t)) return 'Zyxel'
  if (/(d-?link)/.test(t)) return 'D-Link'
  if (/netgear|prosafe/.test(t)) return 'Netgear'
  if (/(aruba|procurve|instant on)/.test(t)) return 'Aruba'
  if (/(juniper|junos)/.test(t)) return 'Juniper'
  if (/(arista)/.test(t)) return 'Arista'
  if (/extreme/.test(t)) return 'Extreme'
  if (/(allied telesis|alliedware)/.test(t)) return 'Allied Telesis'
  if (/(alcatel|omniswitch)/.test(t)) return 'Alcatel-Lucent Enterprise'
  if (/linksys/.test(t)) return 'Linksys'
  if (/tenda/.test(t)) return 'Tenda'
  if (/draytek|vigor/.test(t)) return 'DrayTek'
  if (/uniview/.test(t)) return 'Uniview'
  if (/(hanwha|techwin|sunmoon|samsung techwin)/.test(t)) return 'Hanwha Vision'
  if (/bosch/.test(t)) return 'Bosch'
  if (/vivotek/.test(t)) return 'Vivotek'
  if (/tiandy/.test(t)) return 'Tiandy'
  if (/(cp ?plus)/.test(t)) return 'CP Plus'
  if (/avigilon/.test(t)) return 'Avigilon'
  if (/geovision/.test(t)) return 'GeoVision'
  if (/(provision-isr)/.test(t)) return 'Provision-ISR'
  if (/lilin/.test(t)) return 'Merit LILIN'
  if (/(fortinet|fortigate|fortios)/.test(t)) return 'Fortinet'
  if (/sonicwall/.test(t)) return 'SonicWall'
  if (/(palo alto|pan-?os)/.test(t)) return 'Palo Alto'
  if (/(check point|gaia)/.test(t)) return 'Check Point'
  if (/telrad/.test(t)) return 'Telrad'
  if (/tarana/.test(t)) return 'Tarana'
  if (/ignitenet/.test(t)) return 'IgniteNet'
  if (/ligowave/.test(t)) return 'LigoWave'
  if (/infinet/.test(t)) return 'InfiNet'
  if (/mimosa/.test(t)) return 'Mimosa'
  if (/(ruckus|zoneflex|smartzone|unleashed)/.test(t)) return 'Ruckus'
  if (/(siklu|eh ?700|multihaul)/.test(t)) return 'Siklu'
  if (/(teltonika|rut9|rut2|rutx)/.test(t)) return 'Teltonika'
  if (/(lancom|l-?series|wlan ?controller)/.test(t)) return 'LANCOM'
  if (/mobotix/.test(t)) return 'Mobotix'
  if (/\bpelco\b/.test(t)) return 'Pelco'
  if (/(grandstream|gxv|gds|ucm\d)/.test(t)) return 'Grandstream'
  if (/yealink|sip-t\d/.test(t)) return 'Yealink'
  if (/fanvil/.test(t)) return 'Fanvil'
  // --- infrastruttura/server/storage (v16.8) ---
  if (/(synology|diskstation|\bdsm\b)/.test(t)) return 'Synology'
  if (/(qnap|ts-\d{3})/.test(t)) return 'QNAP'
  if (/readynas/.test(t)) return 'Netgear'
  if (/vmware|esxi/.test(t)) return 'VMware'
  if (/(netapp|ontap)/.test(t)) return 'NetApp'
  if (/supermicro/.test(t)) return 'Supermicro'
  if (/dell |poweredge/.test(t)) return 'Dell'
  if (/lenovo|thinksystem/.test(t)) return 'Lenovo'
  if (/proliant|hpe /.test(t)) return 'HPE'
  if (/(pfsense|opnsense)/.test(t)) return 'pfSense/OPNsense'
  if (/(vyos|vyatta|edgeos)/.test(t)) return 'VyOS/EdgeOS'
  if (/openwrt|lede/.test(t)) return 'OpenWrt'
  if (/(net-?snmp|ucd-snmp)/.test(t)) return 'net-snmp (Linux)'
  // --- printer brand (v16.8) ---
  if (/(laserjet|pagewide|jetdirect|hp ?ethernet multi)/.test(t)) return 'HP'
  if (/brother/.test(t)) return 'Brother'
  if (/(kyocera|taskalfa|ecosys)/.test(t)) return 'Kyocera'
  if (/\brix\b|ricoh/.test(t)) return 'Ricoh'
  if (/\bxerox\b|workcentre/.test(t)) return 'Xerox'
  if (/lexmark/.test(t)) return 'Lexmark'
  if (/epson|surecolor/.test(t)) return 'Epson'
  if (/\bzebra\b|zt\d{3}/.test(t)) return 'Zebra'
  // --- UPS brand (v16.8) ---
  if (/(apc web|smart-ups|matrix-ups|powernet|ap96)/.test(t)) return 'APC'
  if (/(eaton|mge) ?ups|network ?management card/.test(t)) return 'Eaton'
  if (/vertiv|liebert/.test(t)) return 'Vertiv'
  return null
}

/** normalizeVendorName v16.8 (varianti → nome canonico). */
export function normalizeVendorName(raw?: string | null): string | null {
  if (!raw) return null
  const v = raw.trim()
  if (!v) return null
  const l = v.toLowerCase()
  if (l.includes('ubiquiti') || l === 'ubnt') return 'Ubiquiti'
  if (l.includes('mikrotik') || l.includes('mikro tik') || l.includes('routerboard') || l.includes('mikrotikls')) return 'MikroTik'
  if (l.includes('cambium')) return 'Cambium'
  if (l.includes('hikvision')) return 'Hikvision'
  if (l.includes('ezviz')) return 'EZVIZ'
  if (l.includes('dahua') || l.includes('imou')) return 'Dahua'
  if (l.includes('tp-link') || l.includes('tplink')) return 'TP-Link'
  if (l.includes('cisco') && !l.includes('meraki')) return 'Cisco'
  if (l.includes('meraki')) return 'Meraki'
  if (l.includes('axis')) return 'Axis'
  if (l.includes('motorola')) return 'Motorola (legacy)'
  if (/\bhuawei\b/.test(l)) return 'Huawei'
  if (/\bh3c\b/.test(l)) return 'H3C'
  if (/\bplanet\b/.test(l) || l.includes('planet technology')) return 'Planet'
  if (/\brad\b/.test(l) && l.includes('data')) return 'RAD'
  if (l.includes('zyxel')) return 'Zyxel'
  if (l.includes('d-link') || l.includes('dlink')) return 'D-Link'
  if (l.includes('netgear') && !l.includes('readynas')) return 'Netgear'
  if (l.includes('readynas')) return 'Netgear'
  if (l.includes('aruba') || l.includes('procurve')) return 'Aruba'
  if (l.includes('hewlett packard enterprise') || l === 'hpe') return 'Aruba'
  if (l.includes('hewlett') || l.includes('hp inc')) return 'HP'
  if (l.includes('juniper')) return 'Juniper'
  if (l.includes('extreme networks')) return 'Extreme'
  if (l.includes('allied telesis')) return 'Allied Telesis'
  if (l.includes('alcatel-lucent enterprise')) return 'Alcatel-Lucent Enterprise'
  if (l.includes('linksys')) return 'Linksys'
  if (l.includes('tenda')) return 'Tenda'
  if (l.includes('draytek')) return 'DrayTek'
  if (l.includes('netonix')) return 'Netonix'
  if (l.includes('edimax')) return 'Edimax'
  if (l.includes('nokia')) return 'Nokia'
  if (l.includes('fiberhome')) return 'FiberHome'
  if (/\bzte\b/.test(l)) return 'ZTE'
  if (l.includes('uniview')) return 'Uniview'
  if (l.includes('hanwha') || l.includes('techwin')) return 'Hanwha Vision'
  if (l.includes('bosch')) return 'Bosch'
  if (l.includes('vivotek')) return 'Vivotek'
  if (l.includes('tiandy')) return 'Tiandy'
  if (l.includes('avigilon')) return 'Avigilon'
  if (l.includes('fortinet') || l.includes('fortigate')) return 'Fortinet'
  if (l.includes('check point')) return 'Check Point'
  if (l.includes('sonicwall')) return 'SonicWall'
  if (l.includes('palo alto')) return 'Palo Alto'
  if (l.includes('telrad')) return 'Telrad'
  if (l.includes('teltonika')) return 'Teltonika'
  if (l.includes('lancom')) return 'LANCOM'
  if (l.includes('ruckus') || l.includes('commscope wireless')) return 'Ruckus'
  if (l.includes('grandstream')) return 'Grandstream'
  if (l.includes('yealink')) return 'Yealink'
  if (l.includes('fanvil')) return 'Fanvil'
  if (l.includes('synology')) return 'Synology'
  if (l.includes('qnap')) return 'QNAP'
  if (l.includes('vmware')) return 'VMware'
  if (l.includes('netapp')) return 'NetApp'
  if (l.includes('arista')) return 'Arista'
  if (l.includes('net-snmp') || l.includes('ucd-snmp')) return 'net-snmp (Linux)'
  if (l.includes('american power') || /^apc\b/.test(l)) return 'APC'
  if (l.includes('eaton') || l.includes('mge')) return 'Eaton'
  if (l.includes('vertiv') || l.includes('liebert')) return 'Vertiv'
  if (l.includes('dell')) return 'Dell'
  if (l.includes('supermicro') || l.includes('super micro')) return 'Supermicro'
  if (l.includes('brocade')) return 'Brocade'
  if (l.includes('siemens')) return 'Siemens'
  if (l.includes('kyocera')) return 'Kyocera'
  if (l.includes('ricoh')) return 'Ricoh'
  if (l.includes('xerox')) return 'Xerox'
  if (l.includes('lexmark')) return 'Lexmark'
  if (l.includes('brother')) return 'Brother'
  return v
}

/* ---------------- MikroTik per modello (v15 network-discovery.ts) ---------------- */

const MIKROTIK_SWITCH_MODELS = /^(CRS|CSS|RB260|RB250|AF|CR)/i
const MIKROTIK_RADIO_MODELS = /^(wAP|SXT|LHG|LDF|QRT|DISC|mANT|cAP|CAP|Groove|Metal|OmniTIK|DYN)/i
const MIKROTIK_ROUTER_MODELS = /^(hEX|hAP|RB750|RB751|RB2011|RB3011|RB4011|RB951|RB962|RB1100|RB1200|CCR|Chateau|Aud)/i

export function classifyMikrotikModel(model: string): 'SWITCH' | 'AP' | 'ROUTER' | '' {
  const m = (model || '').trim()
  if (!m) return ''
  if (MIKROTIK_SWITCH_MODELS.test(m)) return 'SWITCH'
  if (MIKROTIK_RADIO_MODELS.test(m)) return 'AP'
  if (MIKROTIK_ROUTER_MODELS.test(m)) return 'ROUTER'
  return ''
}

/** Estrae il board name MikroTik dal banner/sysDescr (v15, COPIA). */
function extractMikrotikBoard(source: string): string {
  const m = source.match(/(RB[\w\-]*|CRS[\w\-]*|CSS[\w\-]*|wAP[\w\-]*|SXT[\w\-]*|LHG[\w\-]*|LDF[\w\-]*|QRT[\w\-]*|hEX[\w\-]*|hAP[\w\-]*|CCR[\w\-]*)/i)
  return m ? m[1] : ''
}

/* ---------------- identifyDevice (v15 rami + tipi v16.8) ---------------- */

export interface IdentifyContext {
  /** true se l'IP è il .1 del suo /24 (convenzione gateway d'impianto v15). */
  isSubnetFirst?: boolean
  /** sysDescr SNMP (se la sonda ha risposto) — firma vendor/modello. */
  sysDescr?: string
  /** informazioni ONVIF se il device ha risposto a GetDeviceInformation/Probe. */
  onvif?: { manufacturer?: string | null; model?: string | null }
  /** vendor OUI (segnale di supporto dal MAC — es. APC per un UPS). */
  ouiVendor?: string | null
}

/** Firme UPS oneste: SOLO stringhe che un UPS con scheda SNMP dichiara. */
const UPS_SYSDESCR = /(apc web\/snmp management card|smart-ups|matrix-ups|powernet|mge|eaton .*ups|ups.*eaton|liebert|vertiv|network management card|ap96\d\d|p93\d\d|sma\d{3,4})/i

/** Firme stampanti: sysDescr JetDirect (HP) o banner/titolo noti. */
const PRINTER_TEXT = /(laserjet|pagewide|jetdirect|ethernet multi-environment|deskjet|brother|kyocera|taskalfa|ecosys|\bricoh\b|\brix\b|workcentre|lexmark|epson|surecolor|oki|duplex printing|printer)/i

/** Firme telefonia/VoIP: centralini e telefoni SIP. */
const PBX_TEXT = /(ucm\d{3,4}|grandstream ucm|3cx|asterisk|freepbx|isa\d{3,4} ?gx|ip ?pbx|virtual ?pbx|elastix)/i
const PHONE_TEXT = /(yealink|fanvil|sip-t\d|gxv\d|grandstream|aastra|snom|polycom|spa\d{3,4}|cisco spa|kuo)/i

const NAS_TEXT = /(synology|diskstation|\bdsm\b|qnap|ts-\d{3}|readynas|my ?cloud|ix2|storeedge)/i

/**
 * Identifica il tipo di dispositivo: porte aperte, banner, titolo e
 * segnali ONVIF/SNMP/OUI. I rami v15 restano negli ordini collaudati;
 * i tipi v16.8 (UPS/PRINTER/PBX/PHONE/NAS/MODEM/SERVER) entrano
 * PRIMA delle euristiche generiche perché una firma dichiarata
 * dall'apparato batte qualsiasi supposizione di porta.
 */
export function identifyDevice(
  ports: number[],
  banner?: string,
  title?: string,
  ctx?: IdentifyContext,
): { type: string; method?: string } {
  const has = (p: number) => ports.includes(p)
  const b = (banner || '').toLowerCase()
  const t = (title || '').toLowerCase()
  const sysDescr = (ctx?.sysDescr || '').toLowerCase()
  const onvif = ctx?.onvif
  const ouiVendor = (ctx?.ouiVendor || '').toLowerCase()

  // v11.27 — ONVIF esplicito vince su tutto
  if (onvif && (onvif.manufacturer || onvif.model)) {
    const nvrHint = /nvr|dvr|recorder/i.test(`${onvif.manufacturer || ''} ${onvif.model || ''}`) || has(37777) || has(34567)
    return { type: nvrHint ? 'NVR' : 'CAMERA', method: nvrHint ? 'ONVIF_NVR' : 'ONVIF' }
  }

  // v16.8 — UPS con scheda di rete SNMP: la dichiarazione più forte che esista
  if (UPS_SYSDESCR.test(sysDescr)) return { type: 'UPS', method: 'SNMP_UPS_CARD' }
  if (/^(apc|eaton|mge|vertiv|liebert)/.test(ouiVendor) && has(161) && !has(80) && !has(554)) {
    return { type: 'UPS', method: 'OUI_UPS' }
  }

  // v16.8 — stampanti: JetDirect nel sysDescr, porte di stampa 9100/631,
  // o brand di stampa nel banner/titolo
  if (/hp ethernet multi-environment|jetdirect/.test(sysDescr)) return { type: 'PRINTER', method: 'SNMP_JETDIRECT' }
  if (has(9100) && (has(631) || has(80) || has(515))) return { type: 'PRINTER', method: 'PORT_9100' }
  if (has(631) && (PRINTER_TEXT.test(b) || PRINTER_TEXT.test(t))) return { type: 'PRINTER', method: 'PORT_IPP' }
  if ((PRINTER_TEXT.test(b) || PRINTER_TEXT.test(t)) && !t.includes('camera') && !t.includes('switch')) {
    return { type: 'PRINTER', method: 'HTTP_PRINTER' }
  }

  // v16.8 — NAS: dichiarazione esplicita nel banner/titolo/sysDescr
  if (NAS_TEXT.test(t) || NAS_TEXT.test(b) || NAS_TEXT.test(sysDescr)) {
    return { type: 'NAS', method: 'HTTP_NAS' }
  }

  // v16.8 — MODEM/gateway CPE: CWMP TR-069 in ascolto (7547)
  if (has(7547)) return { type: 'MODEM', method: 'PORT_TR069' }

  // v16.8 — centralino VoIP (PBX) o telefono SIP (PHONE)
  if (PBX_TEXT.test(t) || PBX_TEXT.test(b) || PBX_TEXT.test(sysDescr)) {
    return { type: 'PBX', method: 'HTTP_PBX' }
  }
  if (has(5060) && (PHONE_TEXT.test(t) || PHONE_TEXT.test(b) || PHONE_TEXT.test(sysDescr))) {
    return { type: 'PHONE', method: 'PORT_SIP' }
  }

  // v16.8 — hypervisor/server SNMP: ESXi, net-snmp Linux con SSH+HTTP
  if (/vmware|esxi/.test(sysDescr)) return { type: 'SERVER', method: 'SNMP_ESXI' }
  if (/net-snmp|ucd-snmp|^linux /i.test(sysDescr) && has(22) && (has(80) || has(443) || has(8080))) {
    return { type: 'SERVER', method: 'SNMP_LINUX' }
  }
  if (/windows version|windows nt/i.test(sysDescr)) {
    return { type: 'CLIENT', method: 'SNMP_WINDOWS' }
  }

  // v12.5.0 (C1) — LPR PRIMA di NVR e CAMERA
  const lprTitleHint = /\blpr\b|anpr|\btarga\b|\bplate\b|itse|ids-tvl|itc\d/i.test(t)
  if (lprTitleHint || (has(5000) && has(554))) {
    return { type: 'LPR', method: 'LPR_TITLE' }
  }

  // v12.5.0 (C1) — SWITCH dichiarata nel titolo/banner: switch smart
  if (t.includes('switch') && !t.includes('camera')) {
    return { type: 'SWITCH', method: 'HTTP_GENERIC' }
  }

  // NVR: porta 37777 (Hikvision) o 34567 (Dahua) o titolo NVR
  if (has(37777) || has(34567) || t.includes('nvr') || t.includes('dvr')) {
    if (b.includes('hikvision') || has(37777)) return { type: 'NVR', method: 'HIKVISION_ISAPI' }
    if (b.includes('dahua') || has(34567)) return { type: 'NVR', method: 'DAHUA_CGI' }
    return { type: 'NVR', method: 'HTTP_GENERIC' }
  }

  // v11.20.1/v12.5.0 — banner Hikvision/Dahua (+ SNMP 161 → SWITCH)
  if (b.includes('hikvision')) {
    if (has(161)) return { type: 'SWITCH', method: 'SNMP_AGENT' }
    return { type: 'CAMERA', method: 'HIKVISION_ISAPI' }
  }
  if (b.includes('dahua') || b.includes('imou')) {
    if (has(161)) return { type: 'SWITCH', method: 'SNMP_AGENT' }
    return { type: 'CAMERA', method: 'DAHUA_CGI' }
  }

  // v11.21 — FIX switch MikroTik SwOS (RB260GSP/CSS106): ramo PRIMA di MikroTik
  if (b.includes('swos') || b.includes('css106') || b.includes('rb260') || sysDescr.includes('swos')) {
    return { type: 'SWITCH', method: 'MIKROTIK_SWOS' }
  }

  // MikroTik: porta 8291 (WinBox), banner o sysDescr RouterOS
  if (has(8291) || b.includes('mikrotik') || b.includes('routeros') || sysDescr.includes('routeros') || sysDescr.includes('mikrotik')) {
    const model = extractMikrotikBoard(b + ' ' + sysDescr)
    const byModel = classifyMikrotikModel(model)
    if (byModel === 'SWITCH') return { type: 'SWITCH', method: 'MIKROTIK_SWOS' }
    if (byModel === 'AP') return { type: has(554) ? 'NVR' : 'AP', method: 'MIKROTIK_WIRELESS' }
    if (byModel === 'ROUTER') {
      return { type: ctx?.isSubnetFirst ? 'GATEWAY' : 'ROUTER', method: 'MIKROTIK_REST' }
    }
    return { type: ctx?.isSubnetFirst ? 'GATEWAY' : 'AP', method: 'MIKROTIK_REST' }
  }

  // v11.21 — radio Cambium ePMP
  if (b.includes('cambium') || b.includes('epmp') || sysDescr.includes('cambium') || sysDescr.includes('epmp')) {
    return { type: 'AP', method: 'CAMBIUM_EPMP' }
  }

  // v11.21 — PC client Windows (banner IIS/Microsoft)
  if (b.includes('iis') || b.includes('microsoft') || t.includes('windows')) {
    return { type: 'CLIENT', method: 'HTTP_GENERIC' }
  }

  // Telecamera: RTSP (554) + HTTP (80)
  if (has(554)) {
    if (b.includes('hikvision')) return { type: 'CAMERA', method: 'HIKVISION_ISAPI' }
    if (b.includes('dahua')) return { type: 'CAMERA', method: 'DAHUA_CGI' }
    if (b.includes('ubiquiti')) return { type: 'CAMERA', method: 'UBIQUITI_API' }
    return { type: 'CAMERA', method: 'ONVIF' }
  }

  // AP/STA Radio: Ubiquiti, Mikrotik wireless
  if (b.includes('ubiquiti') || t.includes('airos') || t.includes('unifi') || sysDescr.includes('airos')) {
    return { type: 'AP', method: 'UBIQUITI_API' }
  }

  // Switch gestibile
  if (has(161) || b.includes('cisco') || b.includes('netgear') || b.includes('tp-link')) {
    return { type: 'SWITCH', method: 'HTTP_GENERIC' }
  }

  // v11.27 — RIMOSSO il fallback «80+443 = GATEWAY» (falsi gateway)
  if (has(80) && has(443)) {
    return { type: ctx?.isSubnetFirst ? 'GATEWAY' : 'CLIENT', method: 'HTTP_GENERIC' }
  }

  // Default: porta 80 → tentativo camera (RTSP non standard)
  if (has(80)) {
    return { type: 'CAMERA', method: 'ONVIF' }
  }

  return { type: 'UNKNOWN', method: 'HTTP_GENERIC' }
}

/* ---------------- Fusione evidenze (priorità v15 + pesi v16.8) ---------------- */

export interface VendorEvidenceInput {
  ip: string
  alive: boolean
  openPorts: number[]
  http:
    | {
        server?: string | null
        title?: string | null
        /** v16.8: realm WWW-Authenticate e CN certificato TLS — impronte vendor. */
        realm?: string | null
        certCn?: string | null
      }
    | null
  snmp:
    | {
        reachable: true
        sysDescr: string | null
        sysObjectID: string | null
        vendorGuess: { vendor: string; source: string } | null
        /** v16.8: identità prodotto estratta dal sysDescr. */
        product?: ProductIdentity | null
      }
    | { reachable: false; error: string; detail?: string }
    | null
  onvif:
    | {
        reachable: true
        manufacturer: string | null
        model: string | null
        firmwareVersion?: string | null
        serialNumber?: string | null
        hardwareId?: string | null
      }
    | { reachable: false; error: string; detail?: string }
    | null
  oui: { mac: string; vendor: string; category: string } | null
}

export interface Classification {
  type: string
  brand: string | null
  model: string | null
  confidence: 'high' | 'medium' | 'low'
  /** v16.8: identità dichiarata dall'apparato (sysDescr/ONVIF). */
  os: string | null
  osVersion: string | null
  firmwareVersion: string | null
  evidence: Array<{ source: 'onvif' | 'snmp' | 'banner' | 'port' | 'oui'; value: string }>
}

/** Pesi delle fonti (v16.8): la dichiarazione esplicita batte l'euristica. */
const SOURCE_WEIGHTS = {
  onvif: 4,
  snmpEnterpriseOid: 3,
  snmpSysDescr: 2,
  banner: 1.5,
  oui: 0.75,
  ports: 0.5,
} as const

/**
 * Fusione delle evidenze con priorità v15 (ONVIF > SNMP > banner > porte)
 * e PESI v16.8. NESSUN dato inventato: senza firme → type UNKNOWN, brand
 * null, confidence low; os/model/versione SOLO se dichiarati.
 */
export function classifyDevice(input: VendorEvidenceInput): Classification {
  const evidence: Classification['evidence'] = []
  const bannerText = [input.http?.server, input.http?.title, input.http?.realm, input.http?.certCn]
    .filter(Boolean)
    .join(' ')

  // (1) ONVIF — evidenza più forte
  if (input.onvif?.reachable) {
    const parts = [input.onvif.manufacturer, input.onvif.model].filter(Boolean).join(' ')
    if (parts) evidence.push({ source: 'onvif', value: parts })
  }

  // (2) SNMP sysDescr / vendorGuess / identità prodotto
  if (input.snmp?.reachable) {
    if (input.snmp.vendorGuess) {
      evidence.push({
        source: 'snmp',
        value: `sysObjectID/sysDescr → ${input.snmp.vendorGuess.vendor}${
          input.snmp.vendorGuess.source === 'enterprise-oid' ? ' (OID)' : ''
        }`,
      })
    } else if (input.snmp.sysDescr) {
      evidence.push({ source: 'snmp', value: input.snmp.sysDescr.slice(0, 120) })
    }
  }

  // (3) banner HTTP
  if (bannerText.trim()) evidence.push({ source: 'banner', value: bannerText.slice(0, 120) })

  // (4) porte aperte
  if (input.openPorts.length > 0) evidence.push({ source: 'port', value: input.openPorts.join(',') })

  // (5) OUI (segnale di supporto dal MAC)
  if (input.oui) evidence.push({ source: 'oui', value: `${input.oui.mac} → ${input.oui.vendor}` })

  /* ---- tipo (identifyDevice v15+v16.8, con contesto ONVIF/SNMP/OUI) ---- */
  const isSubnetFirst = /\.1$/.test(input.ip)
  const sysDescr = input.snmp?.reachable ? input.snmp.sysDescr : null
  const identified = identifyDevice(
    input.openPorts,
    input.http?.server || '',
    input.http?.title || '',
    {
      isSubnetFirst,
      sysDescr: sysDescr ?? undefined,
      onvif: input.onvif?.reachable
        ? { manufacturer: input.onvif.manufacturer, model: input.onvif.model }
        : undefined,
      ouiVendor: input.oui?.vendor ?? null,
    },
  )

  /* ---- brand: priorità ONVIF > SNMP(OID) > SNMP(sysDescr) > banner > OUI ---- */
  const onvifBrand = normalizeVendorName(input.onvif?.reachable ? input.onvif?.manufacturer : null)
  const snmpBrand = normalizeVendorName(input.snmp?.reachable ? (input.snmp.vendorGuess?.vendor ?? null) : null)
  const snmpDescrBrand = input.snmp?.reachable && input.snmp.sysDescr ? guessVendor(input.snmp.sysDescr) : null
  const bannerBrand = guessVendor(bannerText)
  const ouiBrand = normalizeVendorName(input.oui?.vendor ?? null)
  const brand = onvifBrand ?? snmpBrand ?? snmpDescrBrand ?? bannerBrand ?? ouiBrand ?? null

  /* ---- modello: ONVIF > sysDescr (identità prodotto) > board MikroTik ---- */
  let model: string | null = null
  if (input.onvif?.reachable && input.onvif.model) {
    model = input.onvif.model
  } else if (input.snmp?.reachable && input.snmp.product?.model) {
    model = input.snmp.product.model
  } else {
    const board = extractMikrotikBoard(`${input.http?.server || ''} ${sysDescr || ''}`)
    if (board) model = board
  }

  /* ---- OS / versioni: SOLO ciò che l'apparato dichiara ---- */
  const product = input.snmp?.reachable ? (input.snmp.product ?? null) : null
  const os = product?.osFamily ?? null
  const osVersion = product?.osVersion ?? null
  const firmwareVersion =
    input.onvif?.reachable && input.onvif.firmwareVersion
      ? input.onvif.firmwareVersion
      : product?.osVersion ?? null

  /* ---- confidence PESATA (v16.8) ---- */
  let score = 0
  if (input.onvif?.reachable && (input.onvif.manufacturer || input.onvif.model)) score += SOURCE_WEIGHTS.onvif
  if (input.snmp?.reachable && input.snmp.vendorGuess) {
    score +=
      input.snmp.vendorGuess.source === 'enterprise-oid'
        ? SOURCE_WEIGHTS.snmpEnterpriseOid
        : SOURCE_WEIGHTS.snmpSysDescr
  } else if (input.snmp?.reachable && input.snmp.sysDescr) {
    score += SOURCE_WEIGHTS.snmpSysDescr
  }
  if (bannerBrand) score += SOURCE_WEIGHTS.banner
  if (ouiBrand) score += SOURCE_WEIGHTS.oui
  if (input.openPorts.length > 0) score += SOURCE_WEIGHTS.ports

  const twoConcordant =
    brand !== null &&
    [onvifBrand, snmpBrand, snmpDescrBrand, bannerBrand, ouiBrand].filter((x) => x === brand).length >= 2

  let confidence: Classification['confidence']
  if (score >= 3 || twoConcordant) confidence = 'high'
  else if (score >= 1.5) confidence = 'medium'
  else confidence = 'low'

  return {
    type: identified.type,
    brand,
    model,
    confidence,
    os,
    osVersion,
    firmwareVersion,
    evidence,
  }
}
