/* ================================================================
 * discovery-service/lib/snmp-l2.ts — SONTA LAYER-2 (v16.8)
 * ================================================================
 * IL motore della «ricostruzione della rete in bridge»: legge via SNMP
 * tutto ciò che uno switch/router DICHIARA davvero sui propri vicini e
 * sulla tabella MAC appresa. Nessuna euristica inventata: ogni riga
 * nasce da un varbind di walk REALE.
 *
 *   · LLDP-MIB (IEEE 802.1AB, 1.0.8802.1.1.2.1.4.1) — lldpRemTable:
 *     vicini dichiarati per porta locale con sysName/sysDesc/chassisId/
 *     portId/portDesc (ID decodificati per subtype: MAC, indirizzo di
 *     rete, nome interfaccia, locale);
 *   · CISCO-CDP-MIB (1.3.6.1.4.1.9.9.23.1.2.1.1) — cdpCacheTable:
 *     vicini CDP per ifIndex (deviceId, devicePort, version, platform);
 *   · BRIDGE-MIB (1.3.6.1.2.1.17):
 *       - dot1dBasePortIfIndex (17.1.4.1.2): porta bridge → ifIndex;
 *       - dot1dTpFdbPort (17.4.3.1.2): MAC appreso → porta bridge
 *         (il MAC è nell'INDICE OID, 6 archi finali — fonte canonica
 *         della FDB; i MAC multicast/broadcast sono scartati);
 *   · Q-BRIDGE-MIB (dot1qTpFdbPort 17.7.1.2.2.1.2): FDB VLAN-aware
 *     (indice: dot1qFdbId + MAC — il VLAN ID è decodificato dai byte
 *     dell'FdbId, tollerante a 4 e 8 ottetti);
 *   · IF-MIB: ifDescr/ifType/ifSpeed/ifAdminStatus/ifOperStatus +
 *     ifName/ifHighSpeed (ifXTable) → stato e nome REALI delle porte.
 *
 * REGOLA D'ORO: ogni walk fallito produce un AVVISO onesto, non un
 * campo inventato; unreachable ⇒ {reachable:false, error, detail}.
 * Multi-community + fallback v2c→v1 come nella sonda di sistema.
 * ================================================================ */

import {
  classifySnmpError,
  openSession,
  sessionGet,
  sessionWalk,
  varbindText,
  type Session,
  type SnmpProbeOptions,
  type Varbind,
} from './snmp'
import { snmpStpRead, type SnmpStpResult, type StpPortRow } from './snmp-stp'
import { snmpArpRead, type ArpRow, type ArpEntryType } from './snmp-arp'
import { snmpVlanRead, type VlanRow, type PortVlanRow } from './snmp-vlan'

export type { SnmpStpResult, StpPortRow, ArpRow, ArpEntryType, VlanRow, PortVlanRow }

/* ---------------- OID Layer-2 (LLDP / CDP / BRIDGE / Q-BRIDGE / IF) ---------------- */

const L2_OIDS = {
  lldpRemTable: '1.0.8802.1.1.2.1.4.1.1',
  cdpCacheTable: '1.3.6.1.4.1.9.9.23.1.2.1.1',
  dot1dBasePortIfIndex: '1.3.6.1.2.1.17.1.4.1.2',
  dot1dTpFdbPort: '1.3.6.1.2.1.17.4.3.1.2',
  dot1qTpFdbPort: '1.3.6.1.2.1.17.7.1.2.2.1.2',
  ifDescr: '1.3.6.1.2.1.2.2.1.2',
  ifType: '1.3.6.1.2.1.2.2.1.3',
  ifSpeed: '1.3.6.1.2.1.2.2.1.5',
  ifAdminStatus: '1.3.6.1.2.1.2.2.1.7',
  ifOperStatus: '1.3.6.1.2.1.2.2.1.8',
  ifName: '1.3.6.1.2.1.31.1.1.1.1',
  ifHighSpeed: '1.3.6.1.2.1.31.1.1.1.15',
  // v16.18 W20 — duplex negozziato per porta (EtherLike-MIB, standard):
  // dot3StatsDuplexStatus: 1=unknown 2=half 3=full
  dot3StatsDuplexStatus: '1.3.6.1.2.1.10.7.2.1.19',
  sysDescr: '1.3.6.1.2.1.1.1.0',
  sysName: '1.3.6.1.2.1.1.5.0',
  sysObjectID: '1.3.6.1.2.1.1.2.0',
} as const

/* ---------------- Limiti onesti (cap per walk) ---------------- */

const CAP_L2 = 1024 // LLDP: ~12 varbind/vicino ⇒ ≈85 vicini
const CAP_CDP = 512
const CAP_FDB = 1024 // ≈1024 MAC appresi per FDB classica
const CAP_IF = 256 // porte fisiche + logiche: oltre → avviso troncamento

/* ---------------- Tipi pubblici ---------------- */

export interface LldpNeighbor {
  /** Numero porta locale LLDP (lldpRemLocalPortNum, indice della riga). */
  localPortNum: number
  chassisId: string | null
  chassisIdSubtype: number | null
  sysName: string | null
  sysDesc: string | null
  portId: string | null
  portIdSubtype: number | null
  portDesc: string | null
}

export interface CdpNeighbor {
  ifIndex: number
  deviceId: string | null
  devicePort: string | null
  version: string | null
  platform: string | null
}

/** Mappatura porta bridge → ifIndex (BRIDGE-MIB dot1dBasePortIfIndex). */
export interface BridgePortMap {
  port: number
  ifIndex: number
}

/** Riga FDB classica: MAC appreso sulla porta bridge «port». */
export interface FdbRow {
  mac: string
  port: number
}

/** Riga FDB VLAN-aware (Q-BRIDGE): MAC appreso su porta per VLAN. */
export interface VlanFdbRow {
  vlan: number
  mac: string
  port: number
}

export interface IfRow {
  ifIndex: number
  descr: string | null
  name: string | null
  ifType: number | null
  adminStatus: number | null
  operStatus: number | null
  /** Velocità in Mbps: ifHighSpeed se >0, altrimenti ifSpeed/1e6. */
  speedMbps: number | null
  /** v16.18 W20 — duplex negozziato (dot3StatsDuplexStatus: full/half,
   *  null = MIB assente o unknown). */
  duplex: 'full' | 'half' | null
}

export interface SnmpL2Result {
  reachable: boolean
  sysName: string | null
  sysDescr: string | null
  sysObjectID: string | null
  /** Quale community+versione ha risposto (onesto: provate in ordine). */
  matched: { community: string; version: 'v1' | 'v2c' | 'v3' } | null
  lldp: LldpNeighbor[]
  cdp: CdpNeighbor[]
  bridgePorts: BridgePortMap[]
  fdb: FdbRow[]
  vlanFdb: VlanFdbRow[]
  interfaces: IfRow[]
  /** v16.15 W13 — tabella ARP (ipNetToMedia + ipNetToPhysical). */
  arp: ArpRow[]
  /** v16.15 W13 — Spanning Tree (dot1dStp + dot1dStpPortTable). */
  stp: SnmpStpResult | null
  /** v16.15 W13 — VLAN statiche dichiarate (dot1qVlanStaticTable). */
  vlans: VlanRow[]
  /** v16.15 W13 — PVID per porta bridge (dot1qPortVlanTable). */
  portVlans: PortVlanRow[]
  /** Avvisi onesti: walk mancato/t Worcester, troncamenti, cap raggiunti. */
  warnings: string[]
  error?: 'timeout' | 'error'
  detail?: string
}

export interface SnmpL2Options extends SnmpProbeOptions {
  /** Timeout per i singoli walk L2 (default 1500 — le tabelle sono many-
   *  RTT: un timeout alto su 12 walk sfora la guardia della route). */
  walkTimeoutMs?: number
}

/* ---------------- Utility OID ---------------- */

/** Suffix numerico di `oid` dopo il prefisso `base` ([] se non inizia
 *  con base — riga di un'altra tabella, scartata dal chiamante). */
function oidSuffixArcs(base: string, oid: string): number[] {
  if (!oid.startsWith(base + '.')) return []
  return oid
    .slice(base.length + 1)
    .split('.')
    .map((a) => Number(a))
}

/** MAC dai 6 archi finali dell'indice (fonte canonica BRIDGE/Q-BRIDGE). */
function macFromArcs(arcs: number[]): string | null {
  if (arcs.length < 6) return null
  const six = arcs.slice(arcs.length - 6)
  if (six.some((b) => !Number.isInteger(b) || b < 0 || b > 255)) return null
  const hex = six.map((b) => b.toString(16).padStart(2, '0')).join('')
  return hex.match(/.{2}/g)?.join(':').toUpperCase() ?? null
}

/** TRUE per MAC multicast/broadcast (bit I/G del primo ottetto): il
 *  traffico inondato NON è un dispositivo — scartato con onestà. */
function isMulticastMac(mac: string): boolean {
  const first = Number.parseInt(mac.slice(0, 2), 16)
  return Number.isFinite(first) && (first & 0x01) === 0x01
}

/** Decodifica un identificatore LLDP (chassisId/portId) per subtype. */
function decodeLldpId(value: unknown, subtype: number | null): string | null {
  if (value === null || value === undefined) return null
  if (typeof value === 'string') {
    const s = value.trim()
    return s === '' ? null : s
  }
  if (!Buffer.isBuffer(value)) return null
  switch (subtype) {
    case 3: { // macAddress: 6 ottetti
      if (value.length === 6) return value.toString('hex').match(/.{2}/g)?.join(':').toUpperCase() ?? null
      return value.toString('hex')
    }
    case 4: { // networkAddress: primo byte = tipo (1 IPv4, 2 IPv6)
      if (value.length >= 5 && value[0] === 1) {
        return `${value[1]}.${value[2]}.${value[3]}.${value[4]}`
      }
      if (value.length >= 17 && value[0] === 2) {
        const groups: string[] = []
        for (let i = 1; i < 17; i += 2) groups.push(value.subarray(i, i + 2).toString('hex'))
        return groups.join(':')
      }
      return value.toString('hex')
    }
    default: {
      // interfaceAlias/interfaceName/local o subtype assente → testo
      const text = value.toString('utf8')
      // se non è testo stampabile l'hex è la rappresentazione onesta
      if (/^[\x20-\x7e\xa0-\xff]*$/.test(text) && text.trim() !== '') return text.trim()
      return value.toString('hex')
    }
  }
}

/** VLAN ID dai byte dell'indice dot1qFdbId (4 o 8 ottetti, big-endian):
 *  il VLAN reale vive nei byte bassi (& 0xFFF gestisce FID+VLAN a 8). */
function vlanFromFdbIdArcs(arcs: number[]): number | null {
  if (arcs.length === 0 || arcs.length > 8) return null
  let value = 0
  for (const b of arcs) {
    if (!Number.isInteger(b) || b < 0 || b > 255) return null
    value = value * 256 + b
  }
  return value & 0x0fff
}

/* ---------------- Walk singoli (ognuno con avviso onesto) ---------------- */

type WalkChunk = { oids: Array<{ oid: string; value: unknown }>; error: string | null }

async function safeWalk(session: Session, base: string, cap: number): Promise<WalkChunk> {
  try {
    const rows = await sessionWalk(session, base, cap)
    return { oids: rows, error: null }
  } catch (e) {
    const c = classifySnmpError(e)
    return { oids: [], error: `${c.error}: ${c.detail}` }
  }
}

function asInt(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v)
  if (typeof v === 'string' && /^-?\d+$/.test(v)) return Number(v)
  return null
}

function asText(v: unknown): string | null {
  if (v === null || v === undefined) return null
  if (Buffer.isBuffer(v)) {
    const s = v.toString('utf8')
    return s.trim() === '' ? null : s.trim()
  }
  const s = String(v).trim()
  return s === '' ? null : s
}

/* ---------------- Walk LLDP (lldpRemTable) ---------------- */

/** Riga grezza LLDP: i valori binari (chassisId/portId) restano GREZZI
 *  finché non arriva il subtype (colonna 5/9 arriva DOPO il valore 4/8
 *  nell'ordine OID) — la decodifica avviene una volta sola, alla fine. */
interface RawLldpRow {
  localPortNum: number
  chassisIdRaw?: unknown
  chassisIdSubtype?: number | null
  sysName?: string | null
  sysDesc?: string | null
  portIdRaw?: unknown
  portIdSubtype?: number | null
  portDesc?: string | null
}

function parseLldp(chunk: WalkChunk): LldpNeighbor[] {
  const byRow = new Map<string, RawLldpRow>()
  for (const { oid, value } of chunk.oids) {
    const arcs = oidSuffixArcs(L2_OIDS.lldpRemTable, oid)
    // [colonna, timeMark, localPortNum, remIndex]
    if (arcs.length !== 4) continue
    const [col, , localPortNum] = arcs
    if (!Number.isInteger(localPortNum) || localPortNum < 0) continue
    const key = String(localPortNum)
    let row = byRow.get(key)
    if (!row) {
      row = { localPortNum }
      byRow.set(key, row)
    }
    switch (col) {
      case 4:
        row.chassisIdRaw = value
        break
      case 5:
        row.chassisIdSubtype = asInt(value)
        break
      case 6:
        row.sysName = asText(value)
        break
      case 7:
        row.sysDesc = asText(value)
        break
      case 8:
        row.portIdRaw = value
        break
      case 9:
        row.portIdSubtype = asInt(value)
        break
      case 10:
        row.portDesc = asText(value)
        break
      default:
        break
    }
  }
  const out: LldpNeighbor[] = []
  for (const r of byRow.values()) {
    const chassisId = decodeLldpId(r.chassisIdRaw ?? null, r.chassisIdSubtype ?? null)
    const portId = decodeLldpId(r.portIdRaw ?? null, r.portIdSubtype ?? null)
    if (!r.sysName && !chassisId && !portId && !r.sysDesc) continue // riga vuota = nessun vicino
    out.push({
      localPortNum: r.localPortNum,
      chassisId,
      chassisIdSubtype: r.chassisIdSubtype ?? null,
      sysName: r.sysName ?? null,
      sysDesc: r.sysDesc ?? null,
      portId,
      portIdSubtype: r.portIdSubtype ?? null,
      portDesc: r.portDesc ?? null,
    })
  }
  return out
}

/* ---------------- Walk CDP (cdpCacheTable) ---------------- */

function parseCdp(chunk: WalkChunk): CdpNeighbor[] {
  const byRow = new Map<string, CdpNeighbor>()
  for (const { oid, value } of chunk.oids) {
    const arcs = oidSuffixArcs(L2_OIDS.cdpCacheTable, oid)
    // [colonna, ifIndex, deviceIndex]
    if (arcs.length !== 3) continue
    const [col, ifIndex] = arcs
    if (!Number.isInteger(ifIndex) || ifIndex < 0) continue
    const key = String(ifIndex)
    let row = byRow.get(key)
    if (!row) {
      row = { ifIndex, deviceId: null, devicePort: null, version: null, platform: null }
      byRow.set(key, row)
    }
    if (col === 3) row.deviceId = asText(value)
    else if (col === 4) row.devicePort = asText(value)
    else if (col === 5) row.version = asText(value)
    else if (col === 6) row.platform = asText(value)
  }
  return [...byRow.values()].filter((r) => r.deviceId || r.devicePort || r.platform)
}

/* ---------------- Walk BRIDGE-MIB ---------------- */

function parseBridgePorts(chunk: WalkChunk): BridgePortMap[] {
  const out: BridgePortMap[] = []
  for (const { oid, value } of chunk.oids) {
    const arcs = oidSuffixArcs(L2_OIDS.dot1dBasePortIfIndex, oid)
    if (arcs.length !== 1) continue
    const port = arcs[0]
    const ifIndex = asInt(value)
    if (!Number.isInteger(port) || port <= 0 || ifIndex === null || ifIndex <= 0) continue
    out.push({ port, ifIndex })
  }
  return out
}

function parseFdb(chunk: WalkChunk): { rows: FdbRow[]; truncated: boolean } {
  const rows: FdbRow[] = []
  for (const { oid, value } of chunk.oids) {
    const arcs = oidSuffixArcs(L2_OIDS.dot1dTpFdbPort, oid)
    if (arcs.length !== 6) continue // il MAC È l'indice: 6 archi esatti
    const port = asInt(value)
    if (port === null || port <= 0) continue // 0 = voce filtrata, non porta
    const mac = macFromArcs(arcs)
    if (!mac || isMulticastMac(mac)) continue // inondati/multicast: non dispositivi
    rows.push({ mac, port })
  }
  const truncated = chunk.oids.length >= CAP_FDB
  return { rows, truncated }
}

/* ---------------- Walk Q-BRIDGE-MIB (FDB VLAN-aware) ---------------- */

function parseVlanFdb(chunk: WalkChunk): { rows: VlanFdbRow[]; truncated: boolean } {
  const rows: VlanFdbRow[] = []
  for (const { oid, value } of chunk.oids) {
    const arcs = oidSuffixArcs(L2_OIDS.dot1qTpFdbPort, oid)
    // indice: dot1qFdbId (4 o 8 archi) + MAC (6 archi finali)
    if (arcs.length < 7 || arcs.length > 14) continue
    const port = asInt(value)
    if (port === null || port <= 0) continue
    const mac = macFromArcs(arcs)
    if (!mac || isMulticastMac(mac)) continue
    const vlan = vlanFromFdbIdArcs(arcs.slice(0, arcs.length - 6))
    if (vlan === null || vlan <= 0) continue
    rows.push({ vlan, mac, port })
  }
  const truncated = chunk.oids.length >= CAP_FDB
  return { rows, truncated }
}

/* ---------------- Walk IF-MIB (porte con stato reale) ---------------- */

async function walkInterfaces(session: Session, warnings: string[]): Promise<IfRow[]> {
  const byIf = new Map<number, IfRow>()
  const touch = (ifIndex: number): IfRow => {
    let row = byIf.get(ifIndex)
    if (!row) {
      row = {
        ifIndex,
        descr: null,
        name: null,
        ifType: null,
        adminStatus: null,
        operStatus: null,
        speedMbps: null,
        duplex: null,
      }
      byIf.set(ifIndex, row)
    }
    return row
  }
  const columns: Array<{ base: string; apply: (row: IfRow, v: unknown) => void; label: string }> = [
    { base: L2_OIDS.ifDescr, apply: (r, v) => (r.descr = asText(v)), label: 'ifDescr' },
    { base: L2_OIDS.ifName, apply: (r, v) => (r.name = asText(v)), label: 'ifName' },
    { base: L2_OIDS.ifType, apply: (r, v) => (r.ifType = asInt(v)), label: 'ifType' },
    { base: L2_OIDS.ifAdminStatus, apply: (r, v) => (r.adminStatus = asInt(v)), label: 'ifAdminStatus' },
    { base: L2_OIDS.ifOperStatus, apply: (r, v) => (r.operStatus = asInt(v)), label: 'ifOperStatus' },
  ]
  for (const col of columns) {
    const chunk = await safeWalk(session, col.base, CAP_IF)
    if (chunk.error) {
      warnings.push(`walk ${col.label} saltato (${chunk.error})`)
      continue
    }
    for (const { oid, value } of chunk.oids) {
      const arcs = oidSuffixArcs(col.base, oid)
      if (arcs.length !== 1) continue
      const ifIndex = arcs[0]
      if (!Number.isInteger(ifIndex) || ifIndex <= 0) continue
      col.apply(touch(ifIndex), value)
    }
  }
  // velocità: ifHighSpeed (Mbps diretti) con fallback ifSpeed (bps → Mbps)
  const hs = await safeWalk(session, L2_OIDS.ifHighSpeed, CAP_IF)
  const speedByIf = new Map<number, number>()
  if (!hs.error) {
    for (const { oid, value } of hs.oids) {
      const arcs = oidSuffixArcs(L2_OIDS.ifHighSpeed, oid)
      if (arcs.length !== 1) continue
      const v = asInt(value)
      if (v !== null && v > 0) speedByIf.set(arcs[0], v)
    }
  }
  const sp = await safeWalk(session, L2_OIDS.ifSpeed, CAP_IF)
  if (!sp.error) {
    for (const { oid, value } of sp.oids) {
      const arcs = oidSuffixArcs(L2_OIDS.ifSpeed, oid)
      if (arcs.length !== 1) continue
      const ifIndex = arcs[0]
      if (speedByIf.has(ifIndex)) continue
      const bps = asInt(value)
      if (bps !== null && bps > 0) speedByIf.set(ifIndex, Math.round(bps / 1_000_000))
    }
  }
  for (const [ifIndex, mbps] of speedByIf) touch(ifIndex).speedMbps = mbps

  // v16.18 W20 — duplex negozziato per porta (EtherLike-MIB). Un agente
  // senza dot3Stats lascia tutto a null: onesto, non è un errore.
  const dx = await safeWalk(session, L2_OIDS.dot3StatsDuplexStatus, CAP_IF)
  if (!dx.error) {
    for (const { oid, value } of dx.oids) {
      const arcs = oidSuffixArcs(L2_OIDS.dot3StatsDuplexStatus, oid)
      if (arcs.length !== 1) continue
      const v = asInt(value)
      if (v === 2) touch(arcs[0]).duplex = 'half'
      else if (v === 3) touch(arcs[0]).duplex = 'full'
    }
  }

  const out = [...byIf.values()].sort((a, b) => a.ifIndex - b.ifIndex)
  if (sp.oids.length >= CAP_IF || hs.oids.length >= CAP_IF) {
    warnings.push(`ifTable troncata a ${CAP_IF} righe (switch molto grande)`)
  }
  return out
}

/* ---------------- Sonda L2 completa ---------------- */

/** Sonda Layer-2 di UN apparato (switch/router/ONV): sistema + LLDP +
 *  CDP + BRIDGE-MIB + Q-BRIDGE + IF-MIB. I walk mancati diventano
 *  AVVISI (l'apparato può non supportare una MIB — onestà, non errore);
 *  l'irraggiungibilità SNMP è l'unico esito non-200 semanticamente
 *  completo. MAI dati inventati. */
export async function snmpL2Probe(o: SnmpL2Options): Promise<SnmpL2Result> {
  const communities = o.communities && o.communities.length > 0 ? o.communities : [o.community ?? 'public']
  const walkTimeoutMs = o.walkTimeoutMs ?? 1500

  let matched: SnmpL2Result['matched'] = null
  let matchedOpts: SnmpProbeOptions | null = null
  let sysName: string | null = null
  let sysDescr: string | null = null
  let sysObjectID: string | null = null
  let lastErrorKind: 'timeout' | 'error' = 'timeout'
  let lastDetail = 'nessuna risposta SNMP'

  // (1) sistema: multi-community. Per ogni community si tenta v2c E v1
  //     (un agente solo-v1 riceve una richiesta v2c e la SCARTA in
  //     silenzio: senza il tentativo v1 resterebbe invisibile — costo
  //     onesto: un pacchetto in più per community).
  const attempts: Array<{ community: string; version: 'v1' | 'v2c' | 'v3' }> =
    o.version === 'v3'
      ? [{ community: '—', version: 'v3' }]
      : []
  if (attempts.length === 0) {
    for (const community of communities) {
      attempts.push({ community, version: o.version === 'v1' ? 'v1' : 'v2c' })
      if (o.version !== 'v1' && o.tryV1Fallback !== false) {
        attempts.push({ community, version: 'v1' })
      }
    }
  }

  for (const a of attempts) {
    const attemptOpts: SnmpProbeOptions = {
      ...o,
      community: a.community === '—' ? undefined : a.community,
      version: a.version,
      retries: o.retries ?? 1,
      timeoutMs: o.timeoutMs ?? 2000,
    }
    let s: Session | null = null
    try {
      s = openSession(attemptOpts)
      const map = await sessionGet(s, [L2_OIDS.sysDescr, L2_OIDS.sysName, L2_OIDS.sysObjectID])
      const descr = varbindText(map.get(L2_OIDS.sysDescr))
      const name = varbindText(map.get(L2_OIDS.sysName))
      const objid = varbindText(map.get(L2_OIDS.sysObjectID))
      if (descr || name || objid) {
        matched = { community: a.community, version: a.version }
        matchedOpts = attemptOpts
        sysDescr = descr
        sysName = name
        sysObjectID = objid
        break
      }
      try { s.close() } catch { /* noop */ }
      lastErrorKind = 'error'
      lastDetail = 'risposta senza varbind validi'
    } catch (e) {
      const c = classifySnmpError(e)
      lastErrorKind = c.error
      lastDetail = c.detail
    }
  }

  if (!matchedOpts) {
    return {
      reachable: false,
      sysName: null,
      sysDescr: null,
      sysObjectID: null,
      matched: null,
      lldp: [],
      cdp: [],
      bridgePorts: [],
      fdb: [],
      vlanFdb: [],
      interfaces: [],
      arp: [],
      stp: null,
      vlans: [],
      portVlans: [],
      warnings: [],
      error: lastErrorKind,
      detail: lastDetail,
    }
  }

  // (2) sessione DEDICATA ai walk: timeout più corto (le tabelle sono
  //     many-RTT) e 1 ritrasmissione per tollerare la perdita UDP.
  const warnings: string[] = []
  let session: Session
  try {
    session = openSession({ ...matchedOpts, timeoutMs: walkTimeoutMs, retries: o.retries ?? 1 })
  } catch (e) {
    const c = classifySnmpError(e)
    return {
      reachable: false,
      sysName,
      sysDescr,
      sysObjectID,
      matched,
      lldp: [],
      cdp: [],
      bridgePorts: [],
      fdb: [],
      vlanFdb: [],
      interfaces: [],
      arp: [],
      stp: null,
      vlans: [],
      portVlans: [],
      warnings: ['riapertura sessione walk fallita'],
      error: c.error,
      detail: c.detail,
    }
  }

  // (3) LLDP — la dichiarazione dei vicini
  const lldpChunk = await safeWalk(session, L2_OIDS.lldpRemTable, CAP_L2)
  const lldp = lldpChunk.error ? (warnings.push(`LLDP non leggibile (${lldpChunk.error})`), []) : parseLldp(lldpChunk)

  // (4) CDP — la dichiarazione dei vicini Cisco
  const cdpChunk = await safeWalk(session, L2_OIDS.cdpCacheTable, CAP_CDP)
  const cdp = cdpChunk.error ? (warnings.push(`CDP non leggibile (${cdpChunk.error})`), []) : parseCdp(cdpChunk)

  // (5) BRIDGE-MIB: mappatura porta bridge → ifIndex
  const bpChunk = await safeWalk(session, L2_OIDS.dot1dBasePortIfIndex, CAP_IF)
  const bridgePorts = bpChunk.error
    ? (warnings.push(`dot1dBasePortIfIndex assente (${bpChunk.error}) — porte bridge senza nome ifIndex`), [])
    : parseBridgePorts(bpChunk)

  // (6) BRIDGE-MIB: FDB classica (MAC → porta bridge)
  const fdbChunk = await safeWalk(session, L2_OIDS.dot1dTpFdbPort, CAP_FDB)
  const fdbParsed = fdbChunk.error
    ? { rows: [] as FdbRow[], truncated: false }
    : parseFdb(fdbChunk)
  if (fdbChunk.error) warnings.push(`FDB dot1dTp non leggibile (${fdbChunk.error})`)
  else if (fdbParsed.truncated) warnings.push(`FDB dot1dTp troncata a ${CAP_FDB} varbind (lette ${fdbParsed.rows.length} MAC)`)

  // (7) Q-BRIDGE: FDB VLAN-aware (switch moderni con VLAN)
  const qChunk = await safeWalk(session, L2_OIDS.dot1qTpFdbPort, CAP_FDB)
  const vlanParsed = qChunk.error
    ? { rows: [] as VlanFdbRow[], truncated: false }
    : parseVlanFdb(qChunk)
  if (!qChunk.error && qChunk.oids.length === 0) {
    warnings.push('Q-BRIDGE dot1qTpFdb vuota o non supportata (switch non VLAN-aware)')
  } else if (vlanParsed.truncated) {
    warnings.push(`FDB dot1qTp troncata a ${CAP_FDB} varbind`)
  }

  // (8) IF-MIB: porte con stato/nome/velocità reali
  const interfaces = await walkInterfaces(session, warnings)

  // (9) v16.15 W13 — STP (dichiarazione Spanning Tree per porta)
  const stp = await snmpStpRead(session)
  warnings.push(...stp.warnings)

  // (10) v16.15 W13 — tabella ARP (IP → MAC appresi)
  const arp = await snmpArpRead(session)
  warnings.push(...arp.warnings)

  // (11) v16.15 W13 — inventario VLAN + PVID per porta
  const vlanResult = await snmpVlanRead(session)
  warnings.push(...vlanResult.warnings)

  try {
    session.close()
  } catch {
    /* noop */
  }

  return {
    reachable: true,
    sysName,
    sysDescr,
    sysObjectID,
    matched,
    lldp,
    cdp,
    bridgePorts,
    fdb: fdbParsed.rows,
    vlanFdb: vlanParsed.rows,
    interfaces,
    arp: arp.rows,
    stp: stp.present ? stp : null,
    vlans: vlanResult.vlans,
    portVlans: vlanResult.portVlans,
    warnings,
  }
}

/** Export di comodo per i test/riuso delle utility di decoding. */
export const __l2Internals = { macFromArcs, isMulticastMac, vlanFromFdbIdArcs, decodeLldpId, oidSuffixArcs }

/** Tipo di comodo per il varbind (riuso esterno senza dipendenze circolari). */
export type { Varbind }
