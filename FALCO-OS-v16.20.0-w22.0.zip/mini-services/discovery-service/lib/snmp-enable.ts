/* ================================================================
 * discovery-service/lib/snmp-enable.ts — v16.18 (W19)
 * ATTUATORE «Attivazione SNMP assistita»
 * ================================================================
 * Esegue una RICETTA del catalogo lib/snmp-recipes.ts su UN apparato:
 *   · trasporto SSH (ssh2) — comandi CLI per RouterOS/airOS/Cisco/…;
 *   · trasporto HTTP-SwOS (digest MD5 RFC 2617 scritto a mano) —
 *     l'unica automazione possibile su RB260GSP & fratelli (SwOS
 *     non ha SSH): GET /snmp.b → merge → POST /snmp.b → read-back;
 *   · verifiche finali con la SONDA SNMP esistente (snmpProbe):
 *     ENABLED solo se l'agente risponde DAVVERO, altrimenti
 *     ENABLED_UNVERIFIED (onesto: l'agente può impiegare secondi
 *     a partire dopo l'applicazione).
 *
 * REGOLA D'ORO (ereditata): MAI eccezioni non gestite verso il
 * client, MAI dati inventati. SSH rifiutato → AUTH_FAILED; comando
 * con exit != 0 → passo fallito con output integro; digest errato →
 * AUTH_FAILED; /snmp.b assente → SWOS_UNSUPPORTED (manuale).
 * ================================================================ */

import { createHash } from 'node:crypto'
import { Client as SshClient } from 'ssh2'

import { snmpProbe } from './snmp'
import { interpolate, recipeById, type RecipeStep } from './snmp-recipes'

/* ---------------- Input / output (contratto interno) ---------------- */

export interface SnmpEnableSshCreds {
  port: number
  username: string
  password: string
}

export interface SnmpEnableInput {
  ip: string
  recipeId: string
  community: string
  contact: string
  location: string
  /** Trasporto SSH: credenziali (arrivano già risolte dal chiamante). */
  ssh?: SnmpEnableSshCreds
  /** Trasporto SwOS: utente/password del pannello (digest) e porta HTTP
   *  del pannello web (default 80 — Device.port dell'inventario). */
  swos?: { username: string; password: string; port?: number }
  /** Verifica finale: porta SNMP e community da tentare. */
  snmpPort: number
  verifyCommunities: string[]
}

export interface EnableStepResult {
  step: string
  note: string | null
  ok: boolean
  exitCode: number | null
  output: string
  benign: boolean
}

export interface SnmpEnableResult {
  recipeId: string
  transport: 'ssh' | 'http-swos' | 'manual' | 'ping-only'
  applied: boolean
  steps: EnableStepResult[]
  verify: {
    reachable: boolean
    matchedCommunity: string | null
    sysName: string | null
    sysDescr: string | null
    error: string | null
  }
  state: 'ENABLED' | 'ENABLED_UNVERIFIED' | 'FAILED'
  notes: string[]
}

/* ---------------- Costanti ---------------- */

const SSH_READY_TIMEOUT_MS = 7000
const SSH_STEP_TIMEOUT_MS = 6000
const HTTP_TIMEOUT_MS = 6000
const VERIFY_TIMEOUT_MS = 2200

/* ---------------- Utilità ---------------- */

const clampText = (s: string, max = 400) => (s.length > max ? `${s.slice(0, max)}…` : s)

/** Exit code != 0 oppure (per CLI che rispondono exit 0 con output
 *  d'errore) testo d'errore riconosciuto. `benign` matcha quando il
 *  pattern è presente: l'esito è atteso e NON fatale. */
function stepOutcome(step: RecipeStep, exitCode: number | null, output: string): { ok: boolean; benign: boolean } {
  const fatal = step.fatal ?? true
  const failedHard = exitCode != null && exitCode !== 0
  if (failedHard) {
    const benign = step.benign != null && new RegExp(step.benign, 'i').test(output)
    return { ok: benign, benign }
  }
  /* exit 0: alcune CLI (RouterOS) scrivono «failure: …» senza exit code */
  const failureInOutput = /(\bbad command\b|failure:|command not found|syntax error|invalid input)/i.test(output)
  if (failureInOutput) {
    const benign = step.benign != null && new RegExp(step.benign, 'i').test(output)
    return { ok: benign, benign }
  }
  return { ok: true, benign: false }
}

/* ---------------- Trasporto SSH ---------------- */

interface SshExecOutcome {
  code: number | null
  stdout: string
  stderr: string
}

/** Esegue UN comando via exec e ne cattura l'esito onesto. */
function sshExec(conn: SshClient, cmd: string): Promise<SshExecOutcome> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout comando SSH (${SSH_STEP_TIMEOUT_MS} ms)`)), SSH_STEP_TIMEOUT_MS)
    conn.exec(cmd, (err, stream) => {
      if (err) {
        clearTimeout(timer)
        reject(err)
        return
      }
      let stdout = ''
      let stderr = ''
      let code: number | null = null
      stream.on('close', (exitCode: number | null) => {
        clearTimeout(timer)
        code = exitCode ?? 0
        resolve({ code, stdout: stdout.slice(0, 2000), stderr: stderr.slice(0, 2000) })
      })
      stream.on('data', (d: Buffer) => { stdout += d.toString('utf8') })
      stream.stderr.on('data', (d: Buffer) => { stderr += d.toString('utf8') })
    })
  })
}

async function runSshRecipe(input: SnmpEnableInput, steps: RecipeStep[]): Promise<Partial<SnmpEnableResult> & { steps: EnableStepResult[]; applied: boolean; notes: string[] }> {
  const creds = input.ssh
  if (!creds || creds.username === '') {
    return {
      steps: [],
      applied: false,
      notes: ['Credenziali SSH mancanti: inserirle nella finestra di attivazione (o salvarle nella scheda apparato)'],
    }
  }

  const conn = new SshClient()
  const closeConn = () => { try { conn.end() } catch { /* noop */ } }

  try {
    await new Promise<void>((resolve, reject) => {
      const onErr = (e: Error) => reject(Object.assign(new Error(e.message), { code: /auth|password|all configured/i.test(e.message) ? 'AUTH_FAILED' : 'SSH_CONNECT_FAILED' }))
      conn.once('error', onErr)
      conn.once('ready', () => { conn.removeListener('error', onErr); conn.on('error', () => closeConn()); resolve() })
      conn.connect({
        host: input.ip,
        port: creds.port || 22,
        username: creds.username,
        password: creds.password,
        readyTimeout: SSH_READY_TIMEOUT_MS,
        keepaliveInterval: 4000,
      })
    })

    const results: EnableStepResult[] = []
    const notes: string[] = []
    let applied = true

    for (const step of steps) {
      const cmd = interpolate(step.cmd, input)
      try {
        const out = await sshExec(conn, cmd)
        const { ok, benign } = stepOutcome(step, out.code, `${out.stdout}\n${out.stderr}`)
        results.push({
          step: cmd,
          note: step.note ?? null,
          ok,
          exitCode: out.code,
          output: clampText(`${out.stdout}${out.stderr ? (out.stderr.startsWith('\n') ? '' : '\n') + out.stderr : ''}`.trim()),
          benign,
        })
        if (!ok) {
          applied = false
          notes.push(`Passo fallito: «${cmd}» — ${clampText(`${out.stdout} ${out.stderr}`).trim() || `exit ${out.code}`}`)
          break
        }
        if (benign) {
          notes.push(`Esito benigno su «${cmd}» (atteso, es. già presente)`)
        }
      } catch (e) {
        applied = false
        results.push({
          step: cmd,
          note: step.note ?? null,
          ok: false,
          exitCode: null,
          output: clampText(e instanceof Error ? e.message : String(e)),
          benign: false,
        })
        notes.push(`Passo interrotto: «${cmd}» — ${e instanceof Error ? e.message : String(e)}`)
        break
      }
    }

    return { steps: results, applied, notes }
  } finally {
    closeConn()
  }
}

/* ---------------- Trasporto SwOS (HTTP digest) ---------------- */

/** Client HTTP Digest MD5 (RFC 2617) — SwOS non accetta Basic.
 *  Due passate: richiesta nuda → 401 con challenge → richiesta con
 *  Authorization. Funziona sia con nonce riutilizzabili sia con
 *  challenge fresche ad ogni richiesta (come il simulatore e come
 *  molti firmware SwOS). */
async function swosRequest(
  ip: string,
  port: number,
  method: 'GET' | 'POST',
  path: string,
  creds: { username: string; password: string },
  body?: string,
): Promise<{ status: number; text: string; error: string | null }> {
  const url = `http://${ip}:${port}${path}`
  const base = { 'Content-Type': 'text/plain' } as Record<string, string>

  /* prima passata: raccoglie la challenge */
  let res: Response
  try {
    res = await fetch(url, { method, headers: body != null ? { ...base, 'Content-Length': String(Buffer.byteLength(body)) } : base, body, signal: AbortSignal.timeout(HTTP_TIMEOUT_MS) })
  } catch (e) {
    return { status: 0, text: '', error: `SwOS non raggiungibile su ${url}: ${e instanceof Error ? e.message : String(e)}` }
  }

  if (res.status !== 401) {
    const text = await res.text().catch(() => '')
    return { status: res.status, text, error: res.status === 200 ? null : `SwOS ha risposto ${res.status}` }
  }

  const challenge = res.headers.get('www-authenticate') ?? ''
  const realm = /realm="([^"]*)"/i.exec(challenge)?.[1] ?? ''
  const nonce = /nonce="([^"]*)"/i.exec(challenge)?.[1] ?? ''
  const qop = /qop="([^"]*)"/i.exec(challenge)?.[1] ?? ''
  const opaque = /opaque="([^"]*)"/i.exec(challenge)?.[1] ?? ''
  if (nonce === '') {
    return { status: 401, text: '', error: 'SwOS non ha presentato una challenge digest valida' }
  }

  const md5 = (s: string) => createHash('md5').update(s).digest('hex')
  const ha1 = md5(`${creds.username}:${realm}:${creds.password}`)
  const ha2 = md5(`${method}:${path}`)
  const cnonce = md5(`${Date.now()}:${Math.random()}`)
  const nc = '00000001'
  const response = qop !== ''
    ? md5(`${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}`)
    : md5(`${ha1}:${nonce}:${ha2}`)
  const auth = [
    `Digest username="${creds.username}"`,
    `realm="${realm}"`,
    `nonce="${nonce}"`,
    `uri="${path}"`,
    qop !== '' ? `qop=${qop}` : null,
    qop !== '' ? `nc=${nc}` : null,
    qop !== '' ? `cnonce="${cnonce}"` : null,
    `response="${response}"`,
    opaque !== '' ? `opaque="${opaque}"` : null,
  ].filter(Boolean).join(', ')

  try {
    const res2 = await fetch(url, {
      method,
      headers: { ...base, Authorization: auth },
      body,
      signal: AbortSignal.timeout(HTTP_TIMEOUT_MS),
    })
    const text = await res2.text().catch(() => '')
    if (res2.status === 401) {
      return { status: 401, text: '', error: 'Autenticazione SwOS rifiutata (digest errato: utente o password)' }
    }
    return { status: res2.status, text, error: res2.status === 200 ? null : `SwOS ha risposto ${res2.status}` }
  } catch (e) {
    return { status: 0, text: '', error: `Richiesta digest SwOS fallita: ${e instanceof Error ? e.message : String(e)}` }
  }
}

/** Parsing del «JSON rotto» di SwOS: {en:0x01,com:'7075626c6963',ci:'',loc:''}
 *  o SwOS Lite {i01:0x01,i02:'…',i03:'',i04:''}. Ritorna la mappa
 *  campo→valore RAW (hex stringa o numero) senza inventare nulla. */
function parseSwosObject(text: string): Map<string, string> {
  const out = new Map<string, string>()
  const re = /([a-zA-Z0-9_]+)\s*:\s*(?:'([^']*)'|(0x[0-9a-fA-F]+))/g
  let m: RegExpExecArray | null
  while ((m = re.exec(text)) !== null) {
    out.set(m[1], m[2] != null ? m[2] : (m[3] ?? ''))
  }
  return out
}

/** Formatta un numero come hex pari (browser Ha() di SwOS): 1 → 0x01. */
function swosHex(n: number): string {
  const h = Math.max(0, Math.trunc(n)).toString(16)
  return `0x${h.length % 2 === 1 ? `0${h}` : h}`
}

/** ASCII → hex (wire format stringhe SwOS). */
function swosStr(s: string): string {
  return Buffer.from(s, 'ascii').toString('hex')
}

async function runSwosRecipe(input: SnmpEnableInput, steps: RecipeStep[]): Promise<Partial<SnmpEnableResult> & { steps: EnableStepResult[]; applied: boolean; notes: string[] }> {
  const creds = { username: input.swos?.username ?? 'admin', password: input.swos?.password ?? '' }
  const httpPort = input.swos?.port ?? 80
  const results: EnableStepResult[] = []
  const notes: string[] = []

  /* Passo 1 — GET /snmp.b (stato attuale + dialetto) */
  const get1 = await swosRequest(input.ip, httpPort, 'GET', '/snmp.b', creds)
  const step1 = steps[0]
  if (get1.error && get1.status === 0) {
    results.push({ step: 'GET /snmp.b', note: step1?.note ?? null, ok: false, exitCode: null, output: get1.error, benign: false })
    return { steps: results, applied: false, notes: [get1.error] }
  }
  if (get1.status === 401) {
    results.push({ step: 'GET /snmp.b', note: step1?.note ?? null, ok: false, exitCode: 401, output: get1.error ?? 'Autenticazione rifiutata', benign: false })
    return { steps: results, applied: false, notes: [get1.error ?? 'Autenticazione digest rifiutata'] }
  }
  if (get1.status === 404) {
    results.push({ step: 'GET /snmp.b', note: step1?.note ?? null, ok: false, exitCode: 404, output: 'endpoint /snmp.b assente (firmware SwOS senza API SNMP)', benign: false })
    return { steps: results, applied: false, notes: ['Firmware SwOS senza endpoint /snmp.b: attivare dal pannello web (System → SNMP)'] }
  }
  if (get1.status !== 200) {
    results.push({ step: 'GET /snmp.b', note: step1?.note ?? null, ok: false, exitCode: get1.status, output: get1.error ?? `stato ${get1.status}`, benign: false })
    return { steps: results, applied: false, notes: [get1.error ?? `SwOS ha risposto ${get1.status}`] }
  }

  const fields = parseSwosObject(get1.text)
  const isLite = fields.has('i01') && !fields.has('en')
  const fEnabled = isLite ? 'i01' : 'en'
  const fCommunity = isLite ? 'i02' : 'com'
  const fContact = isLite ? 'i03' : 'ci'
  const fLocation = isLite ? 'i04' : 'loc'
  if (!fields.has(fEnabled)) {
    results.push({ step: 'GET /snmp.b', note: step1?.note ?? null, ok: false, exitCode: 200, output: clampText(get1.text), benign: false })
    return { steps: results, applied: false, notes: ['Risposta /snmp.b senza campi SNMP attesi (dialetto sconosciuto): attivare manualmente dal pannello web'] }
  }
  const beforeEnabled = fields.get(fEnabled) === '0x01'
  results.push({
    step: `GET /snmp.b → {${[...fields.entries()].map(([k, v]) => `${k}:${v.startsWith('0x') ? v : `'${v}'`}`).join(',')}}${isLite ? ' (dialetto SwOS Lite)' : ''}`,
    note: step1?.note ?? null,
    ok: true,
    exitCode: 200,
    output: `SNMP ${beforeEnabled ? 'GIÀ attivo' : 'disattivo'} su questo switch`,
    benign: false,
  })

  /* Passo 2 — POST /snmp.b con SOLO i campi SNMP (merge della risposta
   *  letta: gli altri campi non vengono toccati perché non vengono
   *  rinviati — SwOS applica solo i campi presenti nel POST). */
  const postBody = `{${fEnabled}:0x01,${fCommunity}:'${swosStr(input.community)}',${fContact}:'${swosStr(input.contact)}',${fLocation}:'${swosStr(input.location)}'}`
  const postCmd = interpolate(steps[1]?.cmd ?? 'POST /snmp.b', input)
  const post = await swosRequest(input.ip, httpPort, 'POST', '/snmp.b', creds, postBody)
  if (post.status !== 200) {
    results.push({ step: postCmd, note: steps[1]?.note ?? null, ok: false, exitCode: post.status, output: post.error ?? `stato ${post.status}`, benign: false })
    return { steps: results, applied: false, notes: [post.error ?? `POST /snmp.b ha risposto ${post.status}`] }
  }
  results.push({ step: postCmd, note: steps[1]?.note ?? null, ok: true, exitCode: 200, output: 'applicato (campi en/com/ci/loc)', benign: false })

  /* Passo 3 — read-back di conferma (non fatale: il POST 200 basta) */
  const get2 = await swosRequest(input.ip, httpPort, 'GET', '/snmp.b', creds)
  let readBackOk = false
  if (get2.status === 200) {
    const after = parseSwosObject(get2.text)
    const en = after.get(fEnabled) === '0x01'
    const com = after.get(fCommunity) === swosStr(input.community)
    readBackOk = en && com
    results.push({
      step: 'GET /snmp.b (conferma)',
      note: steps[2]?.note ?? null,
      ok: readBackOk,
      exitCode: 200,
      output: readBackOk
        ? `read-back OK: en=0x01 com="${input.community}"${isLite ? ' (SwOS Lite)' : ''}`
        : `read-back discorde: en=${after.get(fEnabled)} com=${after.get(fCommunity)}`,
      benign: false,
    })
    if (!readBackOk) notes.push('Read-back discorde dal valore atteso: verificare dal pannello web SwOS')
  } else {
    results.push({ step: 'GET /snmp.b (conferma)', note: steps[2]?.note ?? null, ok: false, exitCode: get2.status, output: get2.error ?? `stato ${get2.status}`, benign: true })
    notes.push('Read-back non riuscito (non fatale): il POST è andato a buon fine')
  }

  return { steps: results, applied: true, notes }
}

/* ---------------- Entry point ---------------- */

export async function snmpEnable(input: SnmpEnableInput): Promise<SnmpEnableResult> {
  const recipe = recipeById(input.recipeId)
  if (!recipe) {
    return {
      recipeId: input.recipeId,
      transport: 'manual',
      applied: false,
      steps: [],
      verify: { reachable: false, matchedCommunity: null, sysName: null, sysDescr: null, error: null },
      state: 'FAILED',
      notes: [`Ricetta «${input.recipeId}» inesistente nel catalogo`],
    }
  }

  /* Transport senza scrittura: niente da attuare (la API a monte
   * gestisce ping-only/manual senza arrivare qui — difensivo). */
  if (recipe.transport === 'manual' || recipe.transport === 'ping-only') {
    return {
      recipeId: recipe.id,
      transport: recipe.transport,
      applied: false,
      steps: [],
      verify: { reachable: false, matchedCommunity: null, sysName: null, sysDescr: null, error: null },
      state: 'FAILED',
      notes: ['Ricetta senza automazione: usare le istruzioni manuali mostrate nella finestra'],
    }
  }

  const vars = { community: input.community, contact: input.contact, location: input.location }
  const steps = recipe.steps.map((s) => ({ ...s, cmd: interpolate(s.cmd, vars) }))

  let partial: Partial<SnmpEnableResult> & { steps: EnableStepResult[]; applied: boolean; notes: string[] }
  let transportError: string | null = null

  try {
    if (recipe.transport === 'ssh') {
      partial = await runSshRecipe(input, steps)
    } else {
      partial = await runSwosRecipe(input, steps)
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    const code = (e as { code?: string })?.code
    transportError = code === 'AUTH_FAILED'
      ? `Credenziali rifiutate dall'apparato (${msg})`
      : `Trasporto non riuscito: ${msg}`
    partial = { steps: [], applied: false, notes: [transportError] }
  }

  /* Verifica finale: sonda SNMP (la stessa della scansione) */
  const communities = input.verifyCommunities.length > 0 ? input.verifyCommunities : [input.community]
  let verify: SnmpEnableResult['verify'] = { reachable: false, matchedCommunity: null, sysName: null, sysDescr: null, error: null }
  if (partial.applied) {
    try {
      const probe = await snmpProbe({
        ip: input.ip,
        port: input.snmpPort,
        version: 'v2c',
        communities,
        timeoutMs: VERIFY_TIMEOUT_MS,
      })
      verify = {
        reachable: probe.reachable,
        matchedCommunity: probe.matched?.community ?? null,
        sysName: probe.sysName ?? null,
        sysDescr: probe.sysDescr ?? null,
        error: probe.reachable ? null : (probe.error ?? 'timeout'),
      }
    } catch (e) {
      verify = { reachable: false, matchedCommunity: null, sysName: null, sysDescr: null, error: e instanceof Error ? e.message : String(e) }
    }
  }

  const state: SnmpEnableResult['state'] = !partial.applied
    ? 'FAILED'
    : verify.reachable
      ? 'ENABLED'
      : 'ENABLED_UNVERIFIED'

  const notes = [...(partial.notes ?? [])]
  if (state === 'ENABLED_UNVERIFIED') {
    notes.push('Comandi applicati ma la sonda SNMP non risponde ancora: l\'agente può impiegare alcuni secondi a partire (o la porta/community differisce) — rilanciare la verifica dal dialogo')
  }

  return {
    recipeId: recipe.id,
    transport: recipe.transport,
    applied: partial.applied,
    steps: partial.steps ?? [],
    verify,
    state,
    notes,
  }
}
