/* ================================================================
 * discovery-service/lib/snmp-stp.ts — LETTURA SPANNING TREE (v16.15 W13)
 * ================================================================
 * IL pezzo che mancava alla ricostruzione della rete in bridge: la
 * dichiarazione STP di ogni porta. BRIDGE-MIB (RFC 4188, OID verificati
 * sul file MIB ufficiale net-snmp):
 *
 *   · dot1dStpProtocolSpecification  17.2.1.0   — ieee8021d(3) | decLb100(2) | unknown(1);
 *   · dot1dStpDesignatedRoot         17.2.5.0   — BridgeId (8 ottetti: 2 priorità + 6 MAC);
 *   · dot1dStpRootPort               17.2.7.0   — 0 = QUESTO bridge è la root;
 *   · dot1dBaseBridgeAddress         17.1.1.0   — il MAC bridge PROPRIO (chi siamo noi);
 *   · dot1dStpPortTable              17.2.15.1  — per porta bridge {dot1dStpPort}:
 *        col 3  dot1dStpPortState            disabled(1) blocking(2) listening(3)
 *                                       learning(4) forwarding(5) broken(6);
 *        col 4  dot1dStpPortEnable           enabled(1) disabled(2);
 *        col 5  dot1dStpPortPathCost         (16 bit — legacy);
 *        col 8  dot1dStpPortDesignatedBridge — BridgeId (8 ottetti): CHI comanda
 *                                             il segmento di questa porta;
 *        col 9  dot1dStpPortDesignatedPort   — PortId (2 ottetti: priorità+porta);
 *        col 11 dot1dStpPortPathCost32       — costo esteso (preferito se >0).
 *
 * PERCHÉ conta (NetDisco / OpenNMS Enlinkd): «la porta il cui bridge
 * designato è un ALTRO switch noto guarda VERSO quello switch» — l'STP
 * orienta l'albero anche dove LLDP tace e la FDB è ambigua.
 *
 * REGOLA D'ORO: walk mancato = AVVISO onesto (molti switch piccoli non
 * fanno STP o non espongono la tabella); nessun campo inventato.
 * ================================================================ */

import {
  sessionGet,
  sessionWalk,
  type Session,
  type Varbind,
} from './snmp'

/* ---------------- OID STP (BRIDGE-MIB, verificati) ---------------- */

const STP_OIDS = {
  dot1dBaseBridgeAddress: '1.3.6.1.2.1.17.1.1.0',
  dot1dStpProtocolSpecification: '1.3.6.1.2.1.17.2.1.0',
  dot1dStpDesignatedRoot: '1.3.6.1.2.1.17.2.5.0',
  dot1dStpRootPort: '1.3.6.1.2.1.17.2.7.0',
  dot1dStpPortTable: '1.3.6.1.2.1.17.2.15.1',
} as const

/** Cap onesto: porte STP per switch (oltre → avviso di troncamento). */
const CAP_STP_PORTS = 256

/* ---------------- Tipi pubblici ---------------- */

/** Stato della porta STP (enum BRIDGE-MIB → etichetta minuscola). */
export type StpPortState =
  | 'disabled' | 'blocking' | 'listening' | 'learning' | 'forwarding' | 'broken' | ''

export interface StpPortRow {
  /** Numero porta bridge (indice dot1dStpPort). */
  port: number
  state: StpPortState
  /** dot1dStpPortEnable: 1 enabled, 2 disabled, null assente. */
  enable: number | null
  /** Costo del percorso (PathCost32 se >0, altrimenti PathCost legacy). */
  pathCost: number
  /** BridgeId designato del segmento, hex 16 caratteri ('' se assente). */
  designatedBridgeId: string
  /** MAC del bridge designato, normalizzato AA:BB:CC:DD:EE:FF ('' se n.d.). */
  designatedBridgeMac: string
  /** Numero porta del bridge designato (dal PortId, byte basso). */
  designatedPortNum: number
  /** BridgeId designato ROOT del segmento, hex ('' se assente). */
  designatedRootId: string
}

export interface SnmpStpResult {
  /** FALSE = STP non esposto dall'apparato (walk falliti): onesto. */
  present: boolean
  /** 'ieee8021d' | 'decLb100' | 'unknown' | '' */
  protocol: string
  /** MAC bridge dell'apparato sondato (chi siamo nel dominio STP). */
  bridgeMac: string
  /** BridgeId della root come vista da qui (hex 16 caratteri). */
  rootBridgeId: string
  /** MAC della root ('' se non decodificabile). */
  rootBridgeMac: string
  /** 0 = questo bridge È la root; N = porta bridge verso la root. */
  rootPort: number
  ports: StpPortRow[]
  warnings: string[]
}

/* ---------------- Utility ---------------- */

function asInt(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v)
  if (typeof v === 'string' && /^-?\d+$/.test(v)) return Number(v)
  return null
}

function asBuffer(v: unknown): Buffer | null {
  return Buffer.isBuffer(v) ? v : null
}

/** BridgeId (8 ottetti) → { id hex, mac normalizzato } */
function decodeBridgeId(buf: Buffer | null): { id: string; mac: string } {
  if (!buf || buf.length !== 8) return { id: '', mac: '' }
  const id = buf.toString('hex').toUpperCase()
  const mac = buf.subarray(2, 8).toString('hex').match(/.{2}/g)?.join(':').toUpperCase() ?? ''
  return { id, mac }
}

/** PortId (2 ottetti: priorità + porta) → numero porta del designato. */
function decodePortId(buf: Buffer | null): number {
  if (!buf || buf.length < 2) return 0
  return buf[buf.length - 1]
}

const STATE_BY_NUM: Record<number, StpPortState> = {
  1: 'disabled', 2: 'blocking', 3: 'listening',
  4: 'learning', 5: 'forwarding', 6: 'broken',
}

/** Suffisso numerico dopo il prefisso della tabella ([] = altra tabella). */
function oidSuffixArcs(base: string, oid: string): number[] {
  if (!oid.startsWith(base + '.')) return []
  return oid.slice(base.length + 1).split('.').map((a) => Number(a))
}

async function safeWalk(
  session: Session,
  base: string,
  cap: number,
): Promise<{ oids: Array<{ oid: string; value: unknown }>; error: string | null }> {
  try {
    const rows = await sessionWalk(session, base, cap)
    return { oids: rows, error: null }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    return { oids: [], error: msg.slice(0, 200) }
  }
}

/* ---------------- Lettura STP completa ---------------- */

/** Buffer dal varbind (GET scalare). */
function bufferOf(vb: Varbind | undefined): Buffer | null {
  return vb && Buffer.isBuffer(vb.value) ? vb.value : null
}

function intOf(vb: Varbind | undefined): number | null {
  if (!vb) return null
  const v = vb.value
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v)
  if (typeof v === 'string' && /^-?\d+$/.test(v)) return Number(v)
  return null
}

/**
 * Legge la dichiarazione Spanning-Tree di UN apparato usando la sessione
 * del chiamante (stessa sessione della sonda L2: zero round-trip extra
 * di handshake). STP assente ⇒ present:false con avvisi, mai errori finti.
 */
export async function snmpStpRead(session: Session): Promise<SnmpStpResult> {
  const warnings: string[] = []

  // scalari in UNA get multi-varbind (1 RTT): root designato, protocollo,
  // root port e MAC bridge proprio. GET (non walk): sono istanze .0.
  let scalars: Map<string, Varbind>
  try {
    scalars = await sessionGet(session, [
      STP_OIDS.dot1dStpDesignatedRoot,
      STP_OIDS.dot1dStpProtocolSpecification,
      STP_OIDS.dot1dStpRootPort,
      STP_OIDS.dot1dBaseBridgeAddress,
    ])
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    warnings.push(`STP non leggibile (${msg.slice(0, 160)}) — l'apparato può non fare spanning tree`)
    return { present: false, protocol: '', bridgeMac: '', rootBridgeId: '', rootBridgeMac: '', rootPort: 0, ports: [], warnings }
  }

  const root = decodeBridgeId(bufferOf(scalars.get(STP_OIDS.dot1dStpDesignatedRoot)))
  if (!root.id) {
    warnings.push('dot1dStpDesignatedRoot senza valore valido — STP non attivo su questo apparato')
    return { present: false, protocol: '', bridgeMac: '', rootBridgeId: '', rootBridgeMac: '', rootPort: 0, ports: [], warnings }
  }

  // protocollo (enum 1..3)
  const protoNum = intOf(scalars.get(STP_OIDS.dot1dStpProtocolSpecification))
  let protocol = ''
  if (protoNum === 3) protocol = 'ieee8021d'
  else if (protoNum === 2) protocol = 'decLb100'
  else if (protoNum === 1) protocol = 'unknown'

  // root port (0 = siamo root)
  const rootPort = intOf(scalars.get(STP_OIDS.dot1dStpRootPort)) ?? 0

  // MAC bridge proprio
  const ownBuf = bufferOf(scalars.get(STP_OIDS.dot1dBaseBridgeAddress))
  const bridgeMac = ownBuf && ownBuf.length === 6
    ? ownBuf.toString('hex').match(/.{2}/g)?.join(':').toUpperCase() ?? ''
    : ''
  if (!bridgeMac) warnings.push('dot1dBaseBridgeAddress assente: MAC bridge proprio sconosciuto')

  // tabella porte STP (colonne 3,4,5,8,9,11)
  interface RawPort {
    state?: number | null
    enable?: number | null
    pathCost?: number | null
    pathCost32?: number | null
    desBridge?: Buffer | null
    desPort?: Buffer | null
    desRoot?: Buffer | null
  }
  const byPort = new Map<number, RawPort>()
  let truncated = false
  const columns: Array<{ col: number; apply: (row: RawPort, v: unknown) => void }> = [
    { col: 3, apply: (r, v) => (r.state = asInt(v)) },
    { col: 4, apply: (r, v) => (r.enable = asInt(v)) },
    { col: 5, apply: (r, v) => (r.pathCost = asInt(v)) },
    { col: 8, apply: (r, v) => (r.desBridge = asBuffer(v)) },
    { col: 9, apply: (r, v) => (r.desPort = asBuffer(v)) },
    { col: 11, apply: (r, v) => (r.pathCost32 = asInt(v)) },
    { col: 6, apply: (r, v) => (r.desRoot = asBuffer(v)) },
  ]
  for (const col of columns) {
    const chunk = await safeWalk(session, `${STP_OIDS.dot1dStpPortTable}.${col.col}`, CAP_STP_PORTS)
    if (chunk.error) continue // colonna assente su questo vendor: campo vuoto
    if (chunk.oids.length >= CAP_STP_PORTS) truncated = true
    for (const { oid, value } of chunk.oids) {
      const arcs = oidSuffixArcs(`${STP_OIDS.dot1dStpPortTable}.${col.col}`, oid)
      if (arcs.length !== 1) continue
      const port = arcs[0]
      if (!Number.isInteger(port) || port <= 0) continue
      let row = byPort.get(port)
      if (!row) {
        row = {}
        byPort.set(port, row)
      }
      col.apply(row, value)
    }
  }
  if (truncated) warnings.push(`tabella STP troncata a ${CAP_STP_PORTS} porte`)
  if (byPort.size === 0) warnings.push('dot1dStpPortTable vuota (nessuna porta STP dichiarata)')

  const ports: StpPortRow[] = [...byPort.entries()]
    .map(([port, r]) => {
      const des = decodeBridgeId(r.desBridge ?? null)
      return {
        port,
        state: STATE_BY_NUM[r.state ?? 0] ?? '',
        enable: r.enable ?? null,
        pathCost: r.pathCost32 && r.pathCost32 > 0 ? r.pathCost32 : (r.pathCost ?? 0),
        designatedBridgeId: des.id,
        designatedBridgeMac: des.mac,
        designatedPortNum: decodePortId(r.desPort ?? null),
        designatedRootId: decodeBridgeId(r.desRoot ?? null).id,
      }
    })
    .sort((a, b) => a.port - b.port)

  return {
    present: true,
    protocol,
    bridgeMac,
    rootBridgeId: root.id,
    rootBridgeMac: root.mac,
    rootPort,
    ports,
    warnings,
  }
}
