/* ================================================================
 * discovery-service/lib/snmp-radio.ts — TELEMETRIA RADIO & SALUTE (W20)
 * ================================================================
 * Domanda a cui risponde: «Cosa dichiara DAVVERO quest'antenna/router
 * via SNMP — SSID, segnale, CCQ, frequenza, velocità radio, CPU, RAM,
 * velocità/duplex della porta ethernet — e quali client radio ha?»
 *
 * REGOLE COSTITUZIONALI (ereditate da tutta v16):
 *   · SONDA in SOLA LETTURA: nessun set, nessun write;
 *   · NESSUN dato inventato: ogni campo nasce da un varbind REALE e
 *     porta la PROVENANCE (OID esatto che ha risposto + confidenza);
 *   · timeout = timeout, lista vuota = lista vuota.
 *
 * STRATEGIA OID «candidati» (motivata nell'intestazione di ogni
 * batteria): le MIB vendor (MIKROTIK-MIB 14988, Ubiquiti 41112) non
 * sono RFC e i numeri di colonna vanno confermati sull'apparato reale.
 * Per ogni dato si provano in ordine:
 *   1. gli OID STANDARD verificati (HOST-RESOURCES, IF-MIB, EtherLike);
 *   2. gli OID vendor candidati con VALIDAZIONE DI INTERVALLO/tipo
 *      (es. segnale ∈ [-100, -30] dBm, CPU ∈ [0, 100] %);
 *   3. un'analisi a firma («pattern») del walk del sottoalbero vendor,
 *      etichettata confidenza «media» con l'OID che ha risposto.
 * Il primo candidato che risponde con un valore PLAUSIBILE vince e la
 * provenance dichiara quale OID è stato: sull'hardware reale l'operatore
 * vede esattamente cosa è stato letto e può verificare la colonna.
 *
 * LIMITI DICHIARATI (onesti, sempre restituiti nelle note):
 *   · country/dominio regolatorio: NON esposto via SNMP da RouterOS né
 *     da airOS — richiede SSH/console (roadmap);
 *   · Cambium ePMP e altri vendor radio: non ancora sondati (nota);
 *   · le colonne delle tabelle wireless MikroTik hanno confidenza
 *     «media»: la validazione di intervallo filtra i falsi ma la
 *     colonna esatta va confermata sul campo tramite la provenance.
 * ================================================================ */

import {
  classifySnmpError,
  openSession,
  sessionGet,
  sessionWalk,
  varbindText,
  type Session,
  type SnmpProbeOptions,
} from './snmp'

/* ---------------- OID delle batterie ---------------- */

const R_OIDS = {
  sysDescr: '1.3.6.1.2.1.1.1.0',
  sysName: '1.3.6.1.2.1.1.5.0',
  sysObjectID: '1.3.6.1.2.1.1.2.0',
  sysUpTime: '1.3.6.1.2.1.1.3.0',

  /* --- Salute (health) --- */
  // MIKROTIK-MIB (mtxrHl) — scalari documentati nei template di
  // monitoraggio (confidenza «alta», numeri da confermare sul campo):
  cpuLoad: '1.3.6.1.4.1.14988.1.1.4.3.0', // mtxrHlCpuLoad (%)
  mtMemA: '1.3.6.1.4.1.14988.1.1.4.4.0', // mtxrHl memory (usata o totale)
  mtMemB: '1.3.6.1.4.1.14988.1.1.4.5.0', // mtxrHl memory (complementare)
  // HOST-RESOURCES-MIB — standard VERIFICATO:
  hrProcessorLoad: '1.3.6.1.2.1.25.3.3.1.2', // walk: carico per CPU
  hrStorageTable: '1.3.6.1.2.1.25.2.3.1', // walk: riga RAM (hrStorageRam)
  // UCD-SNMP-MIB — agente Linux standard (VERIFICATO, valori in KB):
  ucdMemTotalReal: '1.3.6.1.4.1.2021.4.5.0',
  ucdMemAvailReal: '1.3.6.1.4.1.2021.4.6.0',

  /* --- Radio wireless --- */
  // MIKROTIK-MIB wireless (mtxrWl*): si walka l'INTERO sottoalbero
  // 14988.1.1.1 (cap onesto) e si identificano le tabelle per prefisso:
  //   · tabella 2 → registration table (client associati all'AP);
  //   · tabella 3 → stat table (la radio dell'apparato stesso);
  //   · altre tabelle → scansione a firma (SSID/segnale plausibili).
  mtxrWl: '1.3.6.1.4.1.14988.1.1.1',
  // Ubiquiti airMAX (enterprise 41112): sottoalbero walked + scansione
  // a firma (signal/SSID/CCQ con validazione di intervallo).
  ubntTree: '1.3.6.1.4.1.41112',

  /* --- Porte ethernet dell'apparato --- */
  ifName: '1.3.6.1.2.1.31.1.1.1.1',
  ifDescr: '1.3.6.1.2.1.2.2.1.2',
  ifHighSpeed: '1.3.6.1.2.1.31.1.1.1.15',
  ifSpeed: '1.3.6.1.2.1.2.2.1.5',
  // EtherLike-MIB — duplex NEGOZIATO per porta (standard VERIFICATO):
  // dot3StatsDuplexStatus: 1=unknown 2=half 3=full
  dot3StatsDuplexStatus: '1.3.6.1.2.1.10.7.2.1.19',
} as const

/* ---------------- Limiti onesti (cap per walk) ---------------- */

const CAP_MT_WL = 256 // sottoalbero wireless MikroTik (per-client multi-colonne)
const CAP_UBNT = 128 // sottoalbero airMAX
const CAP_IF = 64 // porte dell'apparato
const CAP_HR = 64 // hrStorageTable / hrProcessorLoad

/* ---------------- Tipi pubblici ---------------- */

/** Una radio dichiarata dall'apparato (stat table MikroTik o firma airMAX). */
export interface RadioInterface {
  /** ifIndex/indice della riga così come dichiarato dall'agente. */
  index: number
  ssid: string | null
  band: string | null
  frequencyMhz: number | null
  signalDbm: number | null
  noiseFloorDbm: number | null
  snrDb: number | null
  txRateMbps: number | null
  rxRateMbps: number | null
  ccqPercent: number | null
}

/** Un client radio visto dall'AP (registration table MikroTik / airMAX). */
export interface RadioClientEntry {
  mac: string | null
  signalDbm: number | null
  txRateMbps: number | null
  rxRateMbps: number | null
  lastIp: string | null
}

/** Porta ETHERNET dell'apparato: velocità e duplex negoziali. */
export interface RadioPortRow {
  ifIndex: number
  name: string | null
  speedMbps: number | null
  duplex: 'full' | 'half' | null
}

/** Riga di provenance: QUALE OID ha risposto per QUALE campo. */
export interface RadioProvenanceRow {
  field: string
  oid: string
  label: string
  confidence: 'verified' | 'high' | 'medium'
}

export interface SnmpRadioResult {
  reachable: boolean
  sysName: string | null
  sysDescr: string | null
  sysObjectID: string | null
  uptimeTicks: number | null
  matched: { community: string; version: 'v1' | 'v2c' | 'v3' } | null
  health: {
    cpuLoadPct: number | null
    ramUsedKb: number | null
    ramTotalKb: number | null
    provenance: RadioProvenanceRow[]
  }
  radios: RadioInterface[]
  clients: RadioClientEntry[]
  ports: RadioPortRow[]
  /** Provenance COMPLESSIVA (health + radio + porte): quale OID ha
   *  risposto per quale campo — l'operatore può verificare sul campo. */
  provenance: RadioProvenanceRow[]
  warnings: string[]
  notes: string[]
  error?: 'timeout' | 'error'
  detail?: string
}

export interface SnmpRadioOptions extends SnmpProbeOptions {
  walkTimeoutMs?: number
}

/* ---------------- Utility ---------------- */

/** Walk tollerante: errore → { error }, mai eccezione. */
function safeWalk(
  session: Session,
  oid: string,
  maxRows: number,
): Promise<{ oids: Array<{ oid: string; value: unknown }>; error: string | null }> {
  return sessionWalk(session, oid, maxRows)
    .then((oids) => ({ oids, error: null }))
    .catch((e: unknown) => ({ oids: [] as Array<{ oid: string; value: unknown }>, error: classifySnmpError(e).error }))
}

/** Valore varbind → intero (null se non numerico). */
function asInt(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.round(v)
  if (typeof v === 'bigint') return Number(v)
  if (typeof v === 'string' && /^-?\d+$/.test(v.trim())) return Number(v.trim())
  return null
}

/** Valore varbind → testo (stringa/Buffer). */
function asText(v: unknown): string | null {
  if (v === null || v === undefined) return null
  if (typeof v === 'string') return v.trim() === '' ? null : v.trim()
  if (Buffer.isBuffer(v)) {
    const s = v.toString('utf8').trim()
    return s === '' ? null : s
  }
  return null
}

/** TRUE se la stringa è stampabile e non control-chars (candidato SSID). */
function isPrintable(s: string): boolean {
  return !/[\u0000-\u001f\u007f-\uffff]/.test(s)
}

/** Stringa che SEMBRA un SSID: stampabile, 1..32, non «banda» né MAC. */
function looksLikeSsid(s: string): boolean {
  if (s.length < 1 || s.length > 32) return false
  if (!isPrintable(s)) return false
  if (/ghz|channel|radio|wireless|mode/i.test(s)) return false // band/ruba
  if (/^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/.test(s)) return false // MAC
  if (/^([0-9a-fA-F]{12})$/.test(s)) return false // MAC nudo
  return true
}

/** Stringa IPv4 valida. */
function looksLikeIpv4(s: string): boolean {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(s) && s.split('.').every((o) => Number(o) <= 255)
}

/**
 * Velocità radio → Mbps con normalizzazione dichiarata (unità delle MIB
 * vendor non univoche): ≤1300 → Mbps diretti; ≤1.3M → Kbps→Mbps;
 * oltre → bps→Mbps. La provenance riporta il valore GREZZO nel label.
 */
function normalizeRateMbps(raw: number): { mbps: number; unit: string } | null {
  if (!Number.isFinite(raw) || raw <= 0) return null
  if (raw <= 1300) return { mbps: Math.round(raw), unit: 'Mbps (valore diretto)' }
  if (raw <= 1_300_000) return { mbps: Math.round(raw / 1000), unit: 'Kbps → Mbps' }
  return { mbps: Math.round(raw / 1_000_000), unit: 'bps → Mbps' }
}

/** Frequenza → MHz (range 2.4-7.2 GHz copre 2.4/5/6 GHz). */
function normalizeFrequencyMhz(raw: number): number | null {
  if (raw >= 2_400 && raw <= 7_200) return Math.round(raw)
  if (raw >= 24_000 && raw <= 72_000) return Math.round(raw / 10) // deci-MHz
  if (raw >= 2_400_000 && raw <= 7_200_000) return Math.round(raw / 1000) // kHz
  return null
}

/** Suffisso numerico dopo un prefisso OID ([] se non appartiene). */
function arcsAfter(base: string, oid: string): number[] {
  if (!oid.startsWith(base + '.')) return []
  return oid.slice(base.length + 1).split('.').map((a) => Number(a))
}

/** MAC dai 6 archi finali (indice tabella MikroTik per client). */
function macFromArcs(arcs: number[]): string | null {
  if (arcs.length < 6) return null
  const six = arcs.slice(arcs.length - 6)
  if (six.some((b) => !Number.isInteger(b) || b < 0 || b > 255)) return null
  return six.map((b) => b.toString(16).padStart(2, '0')).join(':').toUpperCase()
}

/** RAM MikroTik: un valore < 8.4M è già in KB (RAM ≤ 8 GB), oltre è in
 *  byte → KB. Euristiche DICHIARATE (unità dell'OID non documentata). */
function mtMemToKb(raw: number): number {
  return raw < 8_400_000 ? raw : Math.round(raw / 1024)
}

/* ---------------- Batteria SALUTE (CPU / RAM) ---------------- */

interface HealthOutcome {
  cpuLoadPct: number | null
  ramUsedKb: number | null
  ramTotalKb: number | null
  provenance: RadioProvenanceRow[]
  warnings: string[]
}

async function readHealth(session: Session): Promise<HealthOutcome> {
  const provenance: RadioProvenanceRow[] = []
  const warnings: string[] = []
  let cpuLoadPct: number | null = null
  let ramUsedKb: number | null = null
  let ramTotalKb: number | null = null

  /* (1) UNA get multi-varbind con TUTTI gli scalari candidati: MikroTik
   *     (mtxrHl) + UCD (net-snmp). I varbind assenti restano fuori mappa
   *     (agente che non implementa l'OID = silenzio onesto). */
  const scalars = await sessionGet(session, [
    R_OIDS.cpuLoad,
    R_OIDS.mtMemA,
    R_OIDS.mtMemB,
    R_OIDS.ucdMemTotalReal,
    R_OIDS.ucdMemAvailReal,
    R_OIDS.sysUpTime,
  ]).catch(() => null)

  /* (2) CPU — MikroTik mtxrHlCpuLoad (validazione 0..100)… */
  if (scalars) {
    const mtCpu = asInt(scalars.get(R_OIDS.cpuLoad)?.value)
    if (mtCpu !== null && mtCpu >= 0 && mtCpu <= 100) {
      cpuLoadPct = mtCpu
      provenance.push({ field: 'cpuLoadPct', oid: R_OIDS.cpuLoad, label: 'mtxrHlCpuLoad (MIKROTIK-MIB)', confidence: 'high' })
    }
  }

  /* (3) RAM — PRIORITÀ agli standard verificati; MikroTik come ripiego
   *     euristico (colonne .4/.5: usata+totale nell'ordine che rende
   *     used ≤ total, unità normalizzata). */
  const hrWalk = await safeWalk(session, R_OIDS.hrStorageTable, CAP_HR)
  if (!hrWalk.error) {
    // hrStorageEntry: col 2 type (OID), 3 descr, 4 allocationUnits, 5 size, 6 used
    const rows = new Map<string, Record<number, number | string>>()
    for (const { oid, value } of hrWalk.oids) {
      const arcs = arcsAfter(R_OIDS.hrStorageTable, oid)
      if (arcs.length !== 2) continue
      const [col, idx] = arcs
      const key = String(idx)
      const row = rows.get(key) ?? {}
      if (col === 2 || col === 3) {
        const t = asText(value)
        if (t) row[col] = t
      } else {
        const n = asInt(value)
        if (n !== null) row[col] = n
      }
      rows.set(key, row)
    }
    for (const [idx, row] of rows) {
      const typeOid = typeof row[2] === 'string' ? row[2] : ''
      const descr = typeof row[3] === 'string' ? row[3] : ''
      const isRam = typeOid.endsWith('.2') || /mem|ram/i.test(descr) // hrStorageRam = …25.2.1.2
      if (!isRam) continue
      const units = typeof row[4] === 'number' ? row[4] : null
      const size = typeof row[5] === 'number' ? row[5] : null
      const used = typeof row[6] === 'number' ? row[6] : null
      if (size === null || used === null) continue
      const mul = units && units > 0 ? units : 1
      ramTotalKb = Math.round((size * mul) / 1024)
      ramUsedKb = Math.round((used * mul) / 1024)
      provenance.push({
        field: 'ramUsedKb / ramTotalKb',
        oid: `${R_OIDS.hrStorageTable}.{3,4,5,6}.${idx}`,
        label: `hrStorageTable riga RAM (units ${mul} B) — HOST-RESOURCES-MIB`,
        confidence: 'verified',
      })
      break
    }
  } else {
    warnings.push(`hrStorageTable non leggibile (${hrWalk.error}) — RAM dagli OID vendor/UCD`)
  }

  /* (3b) RAM MikroTik (solo se hrStorage non ha risposto). */
  if (ramTotalKb === null && scalars) {
    const a = asInt(scalars.get(R_OIDS.mtMemA)?.value)
    const b = asInt(scalars.get(R_OIDS.mtMemB)?.value)
    if (a !== null && b !== null && a > 0 && b > 0) {
      // ordine onesto: usata ≤ totale; se invertite, dichiarato nel label
      const [usedRaw, totalRaw, order] = a <= b ? [a, b, '4=usata, 5=totale'] : [b, a, '4=totale, 5=usata']
      if (usedRaw <= totalRaw) {
        ramUsedKb = mtMemToKb(usedRaw)
        ramTotalKb = mtMemToKb(totalRaw)
        provenance.push({
          field: 'ramUsedKb / ramTotalKb',
          oid: `${R_OIDS.mtMemA} + ${R_OIDS.mtMemB}`,
          label: `mtxrHl memory (ordine ${order}, unità normalizzata) — MIKROTIK-MIB`,
          confidence: 'medium',
        })
      }
    }
  }

  /* (3c) RAM UCD net-snmp (Linux) — totale e disponibile in KB. */
  if (ramTotalKb === null && scalars) {
    const total = asInt(scalars.get(R_OIDS.ucdMemTotalReal)?.value)
    const avail = asInt(scalars.get(R_OIDS.ucdMemAvailReal)?.value)
    if (total !== null && total > 0 && avail !== null && avail >= 0 && avail <= total) {
      ramTotalKb = total
      ramUsedKb = total - avail
      provenance.push({
        field: 'ramUsedKb / ramTotalKb',
        oid: `${R_OIDS.ucdMemTotalReal} + ${R_OIDS.ucdMemAvailReal}`,
        label: 'memTotalReal / memAvailReal — UCD-SNMP-MIB',
        confidence: 'verified',
      })
    }
  }

  /* (4) CPU — HOST-RESOURCES hrProcessorLoad: media delle CPU (solo se
   *     l'OID vendor non ha risposto). */
  if (cpuLoadPct === null) {
    const cpuWalk = await safeWalk(session, R_OIDS.hrProcessorLoad, CAP_HR)
    if (!cpuWalk.error && cpuWalk.oids.length > 0) {
      const loads: number[] = []
      for (const { value } of cpuWalk.oids) {
        const v = asInt(value)
        if (v !== null && v >= 0 && v <= 100) loads.push(v)
      }
      if (loads.length > 0) {
        cpuLoadPct = Math.round(loads.reduce((s, v) => s + v, 0) / loads.length)
        provenance.push({
          field: 'cpuLoadPct',
          oid: R_OIDS.hrProcessorLoad,
          label: `hrProcessorLoad (media di ${loads.length} CPU) — HOST-RESOURCES-MIB`,
          confidence: 'verified',
        })
      }
    }
  }

  return { cpuLoadPct, ramUsedKb, ramTotalKb, provenance, warnings }
}

/* ---------------- Batteria RADIO (wireless MikroTik) ---------------- */

/** Riga generica del sottoalbero wireless MikroTik, raggruppata per
 *  (tabella, indice): { tableId, indexKey, indexArcs, col → value }. */
interface MtRow {
  tableId: number
  indexArcs: number[]
  cols: Map<number, unknown>
  colOids: Map<number, string>
}

function groupMtRows(
  walk: Array<{ oid: string; value: unknown }>,
): Map<string, MtRow> {
  const out = new Map<string, MtRow>()
  for (const { oid, value } of walk) {
    // atteso: <base>.<tableId>.<entry=1>.<col>.<indice…>
    const arcs = arcsAfter(R_OIDS.mtxrWl, oid)
    if (arcs.length < 4) continue
    if (arcs[1] !== 1) continue // non è una riga di entry
    const [tableId, , col] = arcs
    const indexArcs = arcs.slice(3)
    if (!Number.isInteger(tableId) || !Number.isInteger(col)) continue
    const key = `${tableId}:${indexArcs.join('.')}`
    let row = out.get(key)
    if (!row) {
      row = { tableId, indexArcs, cols: new Map(), colOids: new Map() }
      out.set(key, row)
    }
    row.cols.set(col, value)
    row.colOids.set(col, oid)
  }
  return out
}

/** Stat table (tabella 3): la radio dell'apparato. Colonne CANDIDATE
 *  (confidenza «media», validazione di intervallo + provenance):
 *  ssid [5,4,6,7] · signal [3,4,7,8,9] · snr [4,6,10] · ccq [12,13,11,10]
 *  · txRate [1] · rxRate [2] · frequency [7,9,8]. */
function parseStatRow(row: MtRow, prov: RadioProvenanceRow[]): RadioInterface {
  const radio: RadioInterface = {
    index: row.indexArcs[0] ?? 0,
    ssid: null, band: null, frequencyMhz: null, signalDbm: null,
    noiseFloorDbm: null, snrDb: null, txRateMbps: null, rxRateMbps: null, ccqPercent: null,
  }
  const usedCols = new Set<number>()

  // SSID: prima stringa valida tra le colonne candidate
  for (const col of [5, 4, 6, 7]) {
    const s = asText(row.cols.get(col))
    if (s && looksLikeSsid(s)) {
      radio.ssid = s
      prov.push({ field: 'ssid', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (mtxrWlStatSsid candidata) — MIKROTIK-MIB`, confidence: 'medium' })
      usedCols.add(col)
      break
    }
  }
  // banda: stringa «…ghz…» in qualunque colonna
  for (const [col, v] of row.cols) {
    if (usedCols.has(col)) continue
    const s = asText(v)
    if (s && /ghz/i.test(s) && s.length <= 24) {
      radio.band = s
      prov.push({ field: 'band', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (stringa banda) — MIKROTIK-MIB`, confidence: 'medium' })
      usedCols.add(col)
      break
    }
  }
  // segnale: primo intero ∈ [-100, -30] tra le colonne candidate
  for (const col of [3, 4, 7, 8, 9]) {
    if (usedCols.has(col)) continue
    const v = asInt(row.cols.get(col))
    if (v !== null && v >= -100 && v <= -30) {
      radio.signalDbm = v
      prov.push({ field: 'signalDbm', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (mtxrWlStatSignal candidata) — MIKROTIK-MIB`, confidence: 'medium' })
      usedCols.add(col)
      break
    }
  }
  // noise floor: intero ∈ [-120, -86] su colonna NON usata per il segnale
  for (const [col, v] of row.cols) {
    if (usedCols.has(col)) continue
    const n = asInt(v)
    if (n !== null && n >= -120 && n <= -86) {
      radio.noiseFloorDbm = n
      prov.push({ field: 'noiseFloorDbm', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (noise floor candidata) — MIKROTIK-MIB`, confidence: 'medium' })
      usedCols.add(col)
      break
    }
  }
  // SNR: intero ∈ [1, 60]
  for (const col of [4, 6, 10]) {
    if (usedCols.has(col)) continue
    const v = asInt(row.cols.get(col))
    if (v !== null && v >= 1 && v <= 60) {
      radio.snrDb = v
      prov.push({ field: 'snrDb', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (SNR candidata) — MIKROTIK-MIB`, confidence: 'medium' })
      usedCols.add(col)
      break
    }
  }
  // CCQ: intero ∈ [0, 100]
  for (const col of [12, 13, 11, 10]) {
    if (usedCols.has(col)) continue
    const v = asInt(row.cols.get(col))
    if (v !== null && v >= 0 && v <= 100) {
      radio.ccqPercent = v
      prov.push({ field: 'ccqPercent', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (mtxrWlStatTxCCQ candidata) — MIKROTIK-MIB`, confidence: 'medium' })
      usedCols.add(col)
      break
    }
  }
  // velocità tx/rx: colonna 1/2 con normalizzazione unità dichiarata
  const txRaw = asInt(row.cols.get(1))
  if (txRaw !== null) {
    const n = normalizeRateMbps(txRaw)
    if (n) {
      radio.txRateMbps = n.mbps
      prov.push({ field: 'txRateMbps', oid: row.colOids.get(1) ?? '', label: `colonna 1 (txRate) — grezzo ${txRaw}, ${n.unit}`, confidence: 'medium' })
    }
  }
  const rxRaw = asInt(row.cols.get(2))
  if (rxRaw !== null) {
    const n = normalizeRateMbps(rxRaw)
    if (n) {
      radio.rxRateMbps = n.mbps
      prov.push({ field: 'rxRateMbps', oid: row.colOids.get(2) ?? '', label: `colonna 2 (rxRate) — grezzo ${rxRaw}, ${n.unit}`, confidence: 'medium' })
    }
  }
  // frequenza: colonne candidate con normalizzazione
  for (const col of [7, 9, 8]) {
    if (usedCols.has(col)) continue
    const v = asInt(row.cols.get(col))
    if (v !== null) {
      const f = normalizeFrequencyMhz(v)
      if (f !== null) {
        radio.frequencyMhz = f
        prov.push({ field: 'frequencyMhz', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (frequenza) — grezzo ${v}`, confidence: 'medium' })
        usedCols.add(col)
        break
      }
    }
  }
  return radio
}

/** Registration table (tabella 2): i client radio visti da un AP. */
function parseClientRow(row: MtRow, prov: RadioProvenanceRow[]): RadioClientEntry {
  const entry: RadioClientEntry = { mac: null, signalDbm: null, txRateMbps: null, rxRateMbps: null, lastIp: null }
  // MAC: dall'INDICE (6 archi finali — convenzione MikroTik)…
  entry.mac = macFromArcs(row.indexArcs)
  if (entry.mac) {
    prov.push({ field: 'client.mac', oid: `${R_OIDS.mtxrWl}.2.1.<col>.${row.indexArcs.join('.')}`, label: 'indice riga = MAC del client — MIKROTIK-MIB registration table', confidence: 'medium' })
  } else {
    // …o da una colonna stringa con MAC testuale
    for (const [col, v] of row.cols) {
      const s = asText(v)
      if (s && (/^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/.test(s) || /^[0-9a-fA-F]{12}$/.test(s))) {
        entry.mac = s.replace(/[:-]/g, '').match(/.{2}/g)!.join(':').toUpperCase()
        prov.push({ field: 'client.mac', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (MAC testuale) — MIKROTIK-MIB`, confidence: 'medium' })
        break
      }
    }
  }
  // segnale client: primo intero ∈ [-100, -30]
  for (const [col, v] of row.cols) {
    const n = asInt(v)
    if (n !== null && n >= -100 && n <= -30) {
      entry.signalDbm = n
      prov.push({ field: 'client.signalDbm', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (segnale client) — MIKROTIK-MIB`, confidence: 'medium' })
      break
    }
  }
  // velocità: i due interi > 1000 più grandi (Kbps/bps tipici)
  const bigInts: Array<{ col: number; v: number }> = []
  for (const [col, v] of row.cols) {
    const n = asInt(v)
    if (n !== null && n > 1000) bigInts.push({ col, v: n })
  }
  bigInts.sort((a, b) => b.v - a.v)
  if (bigInts[0]) {
    const n = normalizeRateMbps(bigInts[0].v)
    if (n) {
      entry.txRateMbps = n.mbps
      prov.push({ field: 'client.txRateMbps', oid: row.colOids.get(bigInts[0].col) ?? '', label: `colonna ${bigInts[0].col} — grezzo ${bigInts[0].v}, ${n.unit}`, confidence: 'medium' })
    }
  }
  if (bigInts[1]) {
    const n = normalizeRateMbps(bigInts[1].v)
    if (n) {
      entry.rxRateMbps = n.mbps
      prov.push({ field: 'client.rxRateMbps', oid: row.colOids.get(bigInts[1].col) ?? '', label: `colonna ${bigInts[1].col} — grezzo ${bigInts[1].v}, ${n.unit}`, confidence: 'medium' })
    }
  }
  // IP: colonna stringa IPv4
  for (const [col, v] of row.cols) {
    const s = asText(v)
    if (s && looksLikeIpv4(s)) {
      entry.lastIp = s
      prov.push({ field: 'client.lastIp', oid: row.colOids.get(col) ?? '', label: `colonna ${col} (lastIp client) — MIKROTIK-MIB`, confidence: 'medium' })
      break
    }
  }
  return entry
}

/** Scansione a firma del sottoalbero radio di UN vendor generico
 *  (airMAX 41112 o tabelle MikroTik non note): estra SSID (stringa
 *  valida), segnale (-100..-30), CCQ (0..100) con provenance. */
function patternScan(
  walk: Array<{ oid: string; value: unknown }>,
  base: string,
  vendorLabel: string,
  prov: RadioProvenanceRow[],
): { ssid: string | null; signalDbm: number | null; ccqPercent: number | null; snrDb: number | null } {
  let ssid: string | null = null
  let signalDbm: number | null = null
  let ccqPercent: number | null = null
  let snrDb: number | null = null
  let signalOid = ''
  let ccqOid = ''
  let snrOid = ''
  for (const { oid, value } of walk) {
    if (ssid === null) {
      const s = asText(value)
      if (s && looksLikeSsid(s)) {
        ssid = s
        prov.push({ field: 'ssid', oid, label: `firma stringa SSID — ${vendorLabel}`, confidence: 'medium' })
      }
    }
    const n = asInt(value)
    if (n !== null) {
      if (signalDbm === null && n >= -100 && n <= -30) {
        signalDbm = n
        signalOid = oid
      } else if (snrDb === null && n >= 1 && n <= 60) {
        snrDb = n
        snrOid = oid
      } else if (ccqPercent === null && n >= 0 && n <= 100) {
        ccqPercent = n
        ccqOid = oid
      }
    }
  }
  if (signalDbm !== null) prov.push({ field: 'signalDbm', oid: signalOid, label: `firma intero ${signalDbm} dBm — ${vendorLabel}`, confidence: 'medium' })
  if (snrDb !== null) prov.push({ field: 'snrDb', oid: snrOid, label: `firma intero ${snrDb} (SNR candidato) — ${vendorLabel}`, confidence: 'medium' })
  if (ccqPercent !== null) prov.push({ field: 'ccqPercent', oid: ccqOid, label: `firma intero ${ccqPercent}% (CCQ candidato) — ${vendorLabel}`, confidence: 'medium' })
  return { ssid, signalDbm, ccqPercent, snrDb }
}

/* ---------------- Batteria PORTE ETHERNET ---------------- */

async function readPorts(session: Session, prov: RadioProvenanceRow[]): Promise<RadioPortRow[]> {
  // nomi: ifName con fallback ifDescr
  const [names, descrs, speeds, rawSpeeds, duplex] = await Promise.all([
    safeWalk(session, R_OIDS.ifName, CAP_IF),
    safeWalk(session, R_OIDS.ifDescr, CAP_IF),
    safeWalk(session, R_OIDS.ifHighSpeed, CAP_IF),
    safeWalk(session, R_OIDS.ifSpeed, CAP_IF),
    safeWalk(session, R_OIDS.dot3StatsDuplexStatus, CAP_IF),
  ])

  const nameByIf = new Map<number, string>()
  for (const src of [names, descrs]) {
    if (src.error) continue
    for (const { oid, value } of src.oids) {
      const arcs = arcsAfter(src === names ? R_OIDS.ifName : R_OIDS.ifDescr, oid)
      if (arcs.length !== 1) continue
      if (!nameByIf.has(arcs[0])) {
        const s = asText(value)
        if (s) nameByIf.set(arcs[0], s)
      }
    }
  }
  const speedByIf = new Map<number, number>()
  if (!speeds.error) {
    for (const { oid, value } of speeds.oids) {
      const arcs = arcsAfter(R_OIDS.ifHighSpeed, oid)
      if (arcs.length !== 1) continue
      const v = asInt(value)
      if (v !== null && v > 0) speedByIf.set(arcs[0], v)
    }
  }
  if (!rawSpeeds.error) {
    for (const { oid, value } of rawSpeeds.oids) {
      const arcs = arcsAfter(R_OIDS.ifSpeed, oid)
      if (arcs.length !== 1) continue
      const ifIndex = arcs[0]
      if (speedByIf.has(ifIndex)) continue
      const bps = asInt(value)
      if (bps !== null && bps > 0) speedByIf.set(ifIndex, Math.round(bps / 1_000_000))
    }
  }
  if (speeds.oids.length > 0 || rawSpeeds.oids.length > 0) {
    prov.push({
      field: 'ports[].speedMbps',
      oid: `${R_OIDS.ifHighSpeed} (+ fallback ${R_OIDS.ifSpeed})`,
      label: 'ifHighSpeed/ifSpeed per ifIndex — IF-MIB (standard)',
      confidence: 'verified',
    })
  }
  const duplexByIf = new Map<number, 'full' | 'half'>()
  if (!duplex.error) {
    let anyDuplex = false
    for (const { oid, value } of duplex.oids) {
      const arcs = arcsAfter(R_OIDS.dot3StatsDuplexStatus, oid)
      if (arcs.length !== 1) continue
      const v = asInt(value)
      if (v === 3) { duplexByIf.set(arcs[0], 'full'); anyDuplex = true }
      else if (v === 2) { duplexByIf.set(arcs[0], 'half'); anyDuplex = true }
    }
    if (anyDuplex) {
      prov.push({
        field: 'ports[].duplex',
        oid: R_OIDS.dot3StatsDuplexStatus,
        label: 'dot3StatsDuplexStatus (2=half, 3=full) — EtherLike-MIB (standard)',
        confidence: 'verified',
      })
    }
  }

  // filtra le interfacce logiche: contano solo le porte FISICHE con
  // velocità o duplex dichiarati (bridge/wlan/vlan/tun NON sono porte)
  const out: RadioPortRow[] = []
  for (const [ifIndex, name] of nameByIf) {
    const speedMbps = speedByIf.get(ifIndex) ?? null
    const d = duplexByIf.get(ifIndex) ?? null
    if (speedMbps === null && d === null) continue
    if (/^(bridge|lo|wlan|wds|tun|tap|pptp|ppp|sstp|l2tp|vlan|bonding|vpls|eoip|gre|dummy)/i.test(name)) continue
    out.push({ ifIndex, name, speedMbps, duplex: d })
  }
  return out.sort((a, b) => a.ifIndex - b.ifIndex)
}

/* ---------------- Sonda completa ---------------- */

/** Sonda telemetria radio & salute di UN apparato: sistema + health
 *  (CPU/RAM) + tabelle wireless (MikroTik / airMAX a firma) + porte
 *  ethernet con duplex. MAI dati inventati: ogni campo ha provenance. */
export async function snmpRadioProbe(o: SnmpRadioOptions): Promise<SnmpRadioResult> {
  const communities = o.communities && o.communities.length > 0 ? o.communities : [o.community ?? 'public']
  const walkTimeoutMs = o.walkTimeoutMs ?? 1500

  const notes: string[] = [
    'Il dominio regolatorio (country) NON è esposto via SNMP da RouterOS/airOS: leggibile solo via SSH o console (roadmap FALCO-OS).',
    'Colonne tabelle wireless vendor: confidenza «media» — la provenance mostra l\'OID esatto che ha risposto, verificabile sul campo.',
  ]
  const warnings: string[] = []
  const provenance: RadioProvenanceRow[] = []

  /* (1) sistema: multi-community (v2c + fallback v1 per community). */
  let matched: SnmpRadioResult['matched'] = null
  let matchedOpts: SnmpProbeOptions | null = null
  let sysName: string | null = null
  let sysDescr: string | null = null
  let sysObjectID: string | null = null
  let uptimeTicks: number | null = null
  let lastErrorKind: 'timeout' | 'error' = 'timeout'
  let lastDetail = 'nessuna risposta SNMP'

  const attempts: Array<{ community: string; version: 'v1' | 'v2c' | 'v3' }> =
    o.version === 'v3' ? [{ community: '—', version: 'v3' }] : []
  if (attempts.length === 0) {
    for (const community of communities) {
      attempts.push({ community, version: o.version === 'v1' ? 'v1' : 'v2c' })
      if (o.version !== 'v1' && o.tryV1Fallback !== false) attempts.push({ community, version: 'v1' })
    }
  }

  for (const a of attempts) {
    const attemptOpts: SnmpProbeOptions = {
      ...o,
      community: a.community === '—' ? undefined : a.community,
      version: a.version,
      retries: o.retries ?? 1,
      timeoutMs: o.timeoutMs ?? 2000,
    }
    let s: Session | null = null
    try {
      s = openSession(attemptOpts)
      const map = await sessionGet(s, [R_OIDS.sysDescr, R_OIDS.sysName, R_OIDS.sysObjectID, R_OIDS.sysUpTime])
      const descr = varbindText(map.get(R_OIDS.sysDescr))
      const name = varbindText(map.get(R_OIDS.sysName))
      const objid = varbindText(map.get(R_OIDS.sysObjectID))
      if (descr || name || objid) {
        matched = { community: a.community, version: a.version }
        matchedOpts = attemptOpts
        sysDescr = descr
        sysName = name
        sysObjectID = objid
        const upVb = map.get(R_OIDS.sysUpTime)
        uptimeTicks = upVb ? asInt(upVb.value) : null
        break
      }
      try { s.close() } catch { /* noop */ }
      lastErrorKind = 'error'
      lastDetail = 'risposta senza varbind validi'
    } catch (e) {
      const c = classifySnmpError(e)
      lastErrorKind = c.error
      lastDetail = c.detail
    }
  }

  const emptyResult = (): SnmpRadioResult => ({
    reachable: false,
    sysName, sysDescr, sysObjectID, uptimeTicks: null, matched,
    health: { cpuLoadPct: null, ramUsedKb: null, ramTotalKb: null, provenance: [] },
    radios: [], clients: [], ports: [], provenance: [],
    warnings, notes, error: lastErrorKind, detail: lastDetail,
  })

  if (!matchedOpts) return emptyResult()

  /* (2) sessione dedicata ai walk (timeout corto, 1 retry). */
  let session: Session
  try {
    session = openSession({ ...matchedOpts, timeoutMs: walkTimeoutMs, retries: o.retries ?? 1 })
  } catch (e) {
    const c = classifySnmpError(e)
    return { ...emptyResult(), warnings: ['riapertura sessione walk fallita'], error: c.error, detail: c.detail }
  }

  /* (3) salute: CPU/RAM. */
  const health = await readHealth(session)
  warnings.push(...health.warnings)
  provenance.push(...health.provenance)

  /* (4) radio wireless MikroTik: UN walk del sottoalbero 14988.1.1.1. */
  const isMikrotik = (sysObjectID ?? '').startsWith('1.3.6.1.4.1.14988') || /routeros|mikrotik/i.test(sysDescr ?? '')
  const isUbiquiti = (sysObjectID ?? '').startsWith('1.3.6.1.4.1.41112') || /airos|ubiquiti/i.test(sysDescr ?? '')

  let radios: RadioInterface[] = []
  let clients: RadioClientEntry[] = []

  if (isMikrotik || !isUbiquiti) {
    const mtWalk = await safeWalk(session, R_OIDS.mtxrWl, CAP_MT_WL)
    if (mtWalk.error) {
      warnings.push(`sottoalbero wireless MikroTik non leggibile (${mtWalk.error})`)
    } else if (mtWalk.oids.length > 0) {
      if (mtWalk.oids.length >= CAP_MT_WL) {
        warnings.push(`sottoalbero wireless MikroTik troncato a ${CAP_MT_WL} varbind (AP con molti client)`)
      }
      const rows = groupMtRows(mtWalk.oids)
      const statRows: MtRow[] = []
      const clientRows: MtRow[] = []
      const otherRows: MtRow[] = []
      for (const row of rows.values()) {
        if (row.tableId === 3) statRows.push(row)
        else if (row.tableId === 2) clientRows.push(row)
        else otherRows.push(row)
      }
      radios = statRows.map((r) => parseStatRow(r, provenance))
      clients = clientRows.map((r) => parseClientRow(r, provenance))
      // tabelle non note: firma (migliora la compatibilità hardware reale)
      if (radios.length === 0 && otherRows.length > 0) {
        const scan = patternScan(
          otherRows.flatMap((r) => [...r.cols.entries()].map(([col, v]) => ({ oid: r.colOids.get(col) ?? '', value: v }))),
          R_OIDS.mtxrWl,
          'MIKROTIK-MIB (tabelle non note)',
          provenance,
        )
        if (scan.ssid || scan.signalDbm !== null) {
          radios.push({
            index: 0,
            ssid: scan.ssid, band: null, frequencyMhz: null,
            signalDbm: scan.signalDbm, noiseFloorDbm: null, snrDb: scan.snrDb,
            txRateMbps: null, rxRateMbps: null, ccqPercent: scan.ccqPercent,
          })
        }
      }
    }
  }

  /* (5) radio Ubiquiti airMAX: firma sul sottoalbero 41112 — SOLO se
   *     MikroTik non ha prodotto dati radio (un apparato è dell'uno o
   *     dell'altro; provare entrambi costa un walk inutile). */
  if (radios.length === 0) {
    const ubWalk = await safeWalk(session, R_OIDS.ubntTree, CAP_UBNT)
    if (ubWalk.error) {
      if (isUbiquiti) warnings.push(`sottoalbero Ubiquiti non leggibile (${ubWalk.error})`)
    } else if (ubWalk.oids.length > 0) {
      if (ubWalk.oids.length >= CAP_UBNT) {
        warnings.push(`sottoalbero Ubiquiti troncato a ${CAP_UBNT} varbind`)
      }
      const scan = patternScan(ubWalk.oids, R_OIDS.ubntTree, 'Ubiquiti airMAX MIB', provenance)
      if (scan.ssid || scan.signalDbm !== null) {
        radios.push({
          index: 0,
          ssid: scan.ssid, band: null, frequencyMhz: null,
          signalDbm: scan.signalDbm, noiseFloorDbm: null, snrDb: scan.snrDb,
          txRateMbps: null, rxRateMbps: null, ccqPercent: scan.ccqPercent,
        })
      }
    }
  }

  if (radios.length === 0 && clients.length === 0) {
    notes.push('Nessuna tabella wireless leggibile via SNMP su questo apparato (provati MikroTik 14988.1.1.1 e Ubiquiti 41112; Cambium ePMP: non ancora supportato).')
  }

  /* (6) porte ethernet con velocità + duplex. */
  const ports = await readPorts(session, provenance)

  try { session.close() } catch { /* noop */ }

  return {
    reachable: true,
    sysName, sysDescr, sysObjectID, uptimeTicks, matched,
    health: {
      cpuLoadPct: health.cpuLoadPct,
      ramUsedKb: health.ramUsedKb,
      ramTotalKb: health.ramTotalKb,
      provenance: health.provenance,
    },
    radios,
    clients,
    ports,
    warnings,
    notes,
    provenance,
  }
}
