/* ================================================================
 * discovery-service/lib/ssh-probe.ts — v16.19 (W21, setup impianto)
 * SONDA LOGIN SSH (sola autenticazione, nessun comando)
 * ================================================================
 * Domanda a cui risponde: «queste credenziali SSH sono GIUSTE su
 * quest'apparato?». È il mattoncino della fase «Credenziali» del
 * wizard di setup iniziale: l'evento 'ready' di ssh2 È la prova che
 * utente+password sono stati accettati dal server; nessun comando
 * viene eseguito (sola lettura, zero side-effect).
 *
 * REGOLA D'ORO (ereditata): MAI dati inventati. Rifiuto → AUTH_FAILED
 * con il motivo integro; porta chiusa → CONNECT_FAILED; handshake
 * lento → TIMEOUT. banner = quello dichiarato dal server (se arriva).
 * ================================================================ */

import { Client as SshClient } from 'ssh2'

export interface SshLoginProbeInput {
  ip: string
  port: number
  username: string
  password: string
  timeoutMs: number
}

export type SshProbeErrorCode = 'AUTH_FAILED' | 'CONNECT_FAILED' | 'TIMEOUT' | null

export interface SshLoginProbeResult {
  authenticated: boolean
  banner: string | null
  /** Tipo ECDSA/RSA del server, se esposto durante l'handshake. */
  serverKeyHint: string | null
  error: SshProbeErrorCode
  detail: string | null
  durationMs: number
}

const DEFAULT_TIMEOUT_MS = 7000

/** Classificazione onesta del messaggio d'errore ssh2. */
function classifySshError(message: string): Exclude<SshProbeErrorCode, null> {
  if (/timed out|timeout/i.test(message)) return 'TIMEOUT'
  if (/auth|password|all configured|authentication/i.test(message)) return 'AUTH_FAILED'
  return 'CONNECT_FAILED'
}

export function sshLoginProbe(input: Partial<SshLoginProbeInput>): Promise<SshLoginProbeResult> {
  const ip = String(input.ip ?? '').trim()
  const port = Number.isInteger(input.port) && (input.port as number) > 0 && (input.port as number) < 65536 ? (input.port as number) : 22
  const username = String(input.username ?? '').trim()
  const password = String(input.password ?? '')
  const timeoutMs = Number.isFinite(input.timeoutMs) && (input.timeoutMs as number) >= 1500 && (input.timeoutMs as number) <= 20000
    ? Math.round(input.timeoutMs as number)
    : DEFAULT_TIMEOUT_MS

  const t0 = Date.now()

  return new Promise<SshLoginProbeResult>((resolve) => {
    if (username === '') {
      resolve({
        authenticated: false,
        banner: null,
        serverKeyHint: null,
        error: 'AUTH_FAILED',
        detail: 'username vuoto: credenziali SSH non dichiarate',
        durationMs: 0,
      })
      return
    }

    const conn = new SshClient()
    let banner: string | null = null
    let serverKeyHint: string | null = null

    const finish = (r: Omit<SshLoginProbeResult, 'durationMs'>) => {
      try { conn.end() } catch { /* già chiusa */ }
      resolve({ ...r, durationMs: Date.now() - t0 })
    }

    /* Il banner arriva prima dell'autenticazione: lo si cattura comunque. */
    conn.once('banner', (message: string) => {
      banner = message.trim().slice(0, 300) || null
    })
    conn.once('handshake', (info: unknown) => {
      const i = info as { kexhash?: string; algorithms?: { serverHostKey?: string } }
      serverKeyHint = i?.algorithms?.serverHostKey ?? null
    })

    conn.once('ready', () => {
      finish({
        authenticated: true,
        banner,
        serverKeyHint,
        error: null,
        detail: banner ? `login accettato — banner: ${banner}` : 'login accettato (utente e password validi)',
      })
    })

    conn.once('error', (e: Error) => {
      const code = classifySshError(e.message)
      finish({
        authenticated: false,
        banner,
        serverKeyHint,
        error: code,
        detail: e.message.slice(0, 400),
      })
    })

    try {
      conn.connect({
        host: ip,
        port,
        username,
        password,
        readyTimeout: timeoutMs,
        keepaliveInterval: 0,
      })
    } catch (e) {
      finish({
        authenticated: false,
        banner,
        serverKeyHint,
        error: 'CONNECT_FAILED',
        detail: (e instanceof Error ? e.message : String(e)).slice(0, 400),
      })
    }
  })
}
