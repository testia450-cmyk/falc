/* ================================================================
 * discovery-service/lib/udp-service.ts — sweep mDNS + SSDP (v16.8)
 * ================================================================
 * «Adattamento a tutte le tipologie di rete»: due protocolli UNIVERSALI
 * che funzionano su QUALSIASI LAN (casa, ufficio, industriale) senza
 * credenziali e senza SNMP:
 *
 *   · mDNS / DNS-SD (UDP 5353 multicast 224.0.0.251 — Bonjour/Avahi):
 *     query PTR _services._dns-sd._udp.local; rispondono stampanti di
 *     rete, NAS, Chromecast, Apple TV, telecamere ONVIF discovery,
 *     server Linux con Avahi. Parser DNS leggero (nomi con compressione
 *     pointer, record PTR/SRV/A/TXT): per ogni risponditore IP →
 *     hostname + servizi dichiarati;
 *   · SSDP / UPnP (UDP 1900 multicast 239.255.255.250): M-SEARCH
 *     ST: ssdp:all; rispondono router CPE, NAS, TV, decoder, Anything
 *     UPnP. Per ogni risponditore → SERVER, USN, ST, LOCATION (URL
 *     della descrizione XML — impronta vendor forte).
 *
 * REGOLA D'ORO: in una rete muta (o sandbox senza multicast) la lista
 * torna VUOTA — nessun dispositivo inventato, nessun errore fittizio.
 * Gli errori di socket (multicast non supportato) degradano a lista
 * vuota con avviso nel log del servizio.
 * ================================================================ */

import dgram from 'node:dgram'

/* ---------------------- Tipi pubblici ---------------------- */

export interface MdnsDevice {
  ip: string
  /** Hostname dichiarato nei record SRV/A (senza «.local» finale). */
  hostname: string | null
  /** Servizi DNS-SD dichiarati (es. _http._tcp, _onvif._tcp, _ipp._tcp). */
  services: string[]
  /** Porta del primo SRV utile (se presente). */
  port: number | null
}

export interface SsdpDevice {
  ip: string
  /** Header SERVER della risposta (firma vendor, es. «Linux UPnP/1.0» o modèle). */
  server: string | null
  /** USN univoco del dispositivo. */
  usn: string | null
  /** ST con cui ha risposto (tipo di servizio). */
  st: string | null
  /** URL della descrizione XML (impronta vendor). */
  location: string | null
}

/* ---------------------- Utility DNS (mDNS) ---------------------- */

/** Decodifica un nome DNS (label length-prefixed) con supporto ai
 *  pointer di compressione (0xC0). Ritorna nome e offset DOPO il nome. */
function decodeDnsName(buf: Buffer, offset: number): { name: string; next: number } {
  const labels: string[] = []
  let pos = offset
  let jumped = false
  let end = offset
  let hops = 0
  while (pos < buf.length && hops < 32) {
    const len = buf[pos]
    hops++
    if (len === 0) {
      if (!jumped) end = pos + 1
      break
    }
    if ((len & 0xc0) === 0xc0) {
      // pointer: 14 bit
      const ptr = ((len & 0x03) << 8) | buf[pos + 1]
      if (!jumped) end = pos + 2
      jumped = true
      pos = ptr
      continue
    }
    if (pos + 1 + len > buf.length) break
    labels.push(buf.subarray(pos + 1, pos + 1 + len).toString('utf8'))
    pos += 1 + len
    if (!jumped) end = pos
  }
  return { name: labels.join('.'), next: end }
}

function readU16(buf: Buffer, off: number): number {
  return buf.readUInt16BE(off)
}

/* ---------------------- Sweep mDNS (UDP 5353) ---------------------- */

/** Query DNS-SD: _services._dns-sd._udp.local IN PTR. */
function buildMdnsQuery(): Buffer {
  const qname = '_services._dns-sd._udp.local'
  const parts = qname.split('.')
  const nameBuf = Buffer.alloc(
    parts.reduce((n, p) => n + 1 + p.length, 0) + 1,
  )
  let off = 0
  for (const p of parts) {
    nameBuf[off] = p.length
    nameBuf.write(p, off + 1, 'latin1')
    off += 1 + p.length
  }
  // nameBuf[off] = 0 (già zero)
  const header = Buffer.alloc(12)
  header.writeUInt16BE(0x0000, 0) // ID
  header.writeUInt16BE(0x0000, 2) // flags: query standard
  header.writeUInt16BE(1, 4) // QD=1
  header.writeUInt16BE(0, 6) // AN
  header.writeUInt16BE(0, 8) // NS
  header.writeUInt16BE(0, 10) // AR
  const tail = Buffer.alloc(4)
  tail.writeUInt16BE(0x000c, 0) // type PTR
  tail.writeUInt16BE(0x8001, 2) // class IN + unicast-response bit tollerato
  return Buffer.concat([header, nameBuf, tail])
}

/** Parse della risposta mDNS: per ogni risponditore raccoglie hostname
 *  (SRV target / nome risorsa) e servizi (PTR rdata). */
function parseMdnsResponse(buf: Buffer): { hostname: string | null; services: string[]; port: number | null } {
  const services = new Set<string>()
  let hostname: string | null = null
  let port: number | null = null
  if (buf.length < 12) return { hostname, services: [], port }
  const qd = readU16(buf, 4)
  const an = readU16(buf, 6)
  let pos = 12
  // salta le question (nome + type + class)
  for (let i = 0; i < qd && pos < buf.length; i++) {
    const { next } = decodeDnsName(buf, pos)
    pos = next + 4
  }
  // risposte
  for (let i = 0; i < an && pos + 10 <= buf.length; i++) {
    const { name, next } = decodeDnsName(buf, pos)
    pos = next
    const type = readU16(buf, pos)
    // const cls = readU16(buf, pos + 2)
    const rdlength = readU16(buf, pos + 8)
    const rdata = pos + 10
    pos = rdata + rdlength
    if (rdata + rdlength > buf.length) break
    if (type === 12) {
      // PTR: rdata è un nome (servizio o tipo)
      const { name: target } = decodeDnsName(buf, rdata)
      if (target) {
        const svc = target.replace(/\.local\.?$/, '')
        if (svc) services.add(svc)
      }
    } else if (type === 33) {
      // SRV: priority(2) weight(2) port(2) target(nome)
      if (rdata + 6 <= buf.length) {
        const srvPort = readU16(buf, rdata + 4)
        const { name: target } = decodeDnsName(buf, rdata + 6)
        if (target && !hostname) {
          hostname = target.replace(/\.local\.?$/, '')
        }
        if (port === null) port = srvPort
      }
    } else if (type === 1 || type === 28) {
      // A / AAAA: il nome della risorsa è l'hostname
      if (!hostname && name) hostname = name.replace(/\.local\.?$/, '')
    } else if (type === 16) {
      // TXT: il nome della risorsa è l'istanza del servizio
      if (name) {
        const svc = name.replace(/\.local\.?$/, '')
        if (svc && !svc.startsWith('_')) services.add(svc)
      }
    }
  }
  return { hostname, services: [...services], port }
}

/** Sweep mDNS/DNS-SD: invia la query PTR al gruppo multicast e raccoglie
 *  i risponditori per timeoutMs. Nessuna risposta ⇒ lista vuota (onesta). */
export function mdnsDiscoverSweep(timeoutMs = 4000): Promise<MdnsDevice[]> {
  return new Promise((resolve) => {
    const found = new Map<string, MdnsDevice>()
    let sock: dgram.Socket | null = null
    let finished = false
    const finish = () => {
      if (finished) return
      finished = true
      clearTimeout(timer)
      try { sock?.close() } catch { /* noop */ }
      resolve([...found.values()])
    }
    const timer = setTimeout(finish, Math.max(500, timeoutMs))
    try {
      sock = dgram.createSocket({ type: 'udp4', reuseAddr: true })
      sock.on('error', (e: Error) => {
        console.log(`[mdns] socket error: ${e.message} — multicast non disponibile, lista vuota`)
        finish()
      })
      sock.on('message', (msg: Buffer, rinfo: { address: string }) => {
        try {
          const parsed = parseMdnsResponse(msg)
          if (!parsed.hostname && parsed.services.length === 0) return
          const key = rinfo.address
          const cur = found.get(key)
          if (cur) {
            cur.hostname = cur.hostname ?? parsed.hostname
            cur.port = cur.port ?? parsed.port
            for (const s of parsed.services) if (!cur.services.includes(s)) cur.services.push(s)
          } else {
            found.set(key, {
              ip: rinfo.address,
              hostname: parsed.hostname,
              services: parsed.services,
              port: parsed.port,
            })
          }
        } catch {
          /* pacchetto malformato: ignorato, nessun dato inventato */
        }
      })
      sock.bind(5353, () => {
        try {
          sock!.addMembership('224.0.0.251')
        } catch {
          /* senza membership il multicast può non arrivare: onesto */
        }
        try {
          sock!.setMulticastTTL(255)
          sock!.send(buildMdnsQuery(), 5353, '224.0.0.251')
        } catch {
          finish()
        }
      })
    } catch {
      finish()
    }
  })
}

/* ---------------------- Sweep SSDP / UPnP (UDP 1900) ---------------------- */

const SSDP_MSEARCH = [
  'M-SEARCH * HTTP/1.1',
  'HOST: 239.255.255.250:1900',
  'MAN: "ssdp:discover"',
  'MX: 2',
  'ST: ssdp:all',
  'USER-AGENT: FALCO-OS/16.8',
  '',
  '',
].join('\r\n')

/** Parse degli header di una risposta SSDP (case-insensitive). */
function parseSsdpHeaders(text: string): Record<string, string> {
  const out: Record<string, string> = {}
  for (const line of text.split('\r\n')) {
    const idx = line.indexOf(':')
    if (idx <= 0) continue
    const k = line.slice(0, idx).trim().toUpperCase()
    const v = line.slice(idx + 1).trim()
    if (v) out[k] = v
  }
  return out
}

/** Sweep SSDP: M-SEARCH ssdp:all al multicast 239.255.255.250:1900 e
 *  raccolta delle risposte per timeoutMs. Nessuna risposta ⇒ vuoto. */
export function ssdpDiscoverSweep(timeoutMs = 4000): Promise<SsdpDevice[]> {
  return new Promise((resolve) => {
    const found = new Map<string, SsdpDevice>()
    let sock: dgram.Socket | null = null
    let finished = false
    const finish = () => {
      if (finished) return
      finished = true
      clearTimeout(timer)
      try { sock?.close() } catch { /* noop */ }
      resolve([...found.values()])
    }
    const timer = setTimeout(finish, Math.max(500, timeoutMs))
    try {
      sock = dgram.createSocket({ type: 'udp4', reuseAddr: true })
      sock.on('error', (e: Error) => {
        console.log(`[ssdp] socket error: ${e.message} — multicast non disponibile, lista vuota`)
        finish()
      })
      sock.on('message', (msg: Buffer, rinfo: { address: string }) => {
        try {
          const text = msg.toString('utf8')
          if (!/^HTTP\/1\.[01] 200/i.test(text)) return // solo risposte OK
          const h = parseSsdpHeaders(text)
          const usn = h['USN'] ?? null
          const st = h['ST'] ?? null
          const key = usn ?? `${rinfo.address}|${st ?? ''}`
          const cur = found.get(key)
          if (cur) {
            cur.server = cur.server ?? (h['SERVER'] ?? null)
            cur.location = cur.location ?? (h['LOCATION'] ?? null)
            cur.st = cur.st ?? st
          } else {
            found.set(key, {
              ip: rinfo.address,
              server: h['SERVER'] ?? null,
              usn,
              st,
              location: h['LOCATION'] ?? null,
            })
          }
        } catch {
          /* pacchetto malformato: ignorato */
        }
      })
      sock.bind(() => {
        try {
          sock!.addMembership('239.255.255.250')
        } catch {
          /* senza membership: comunque i pacchetti in risposta al nostro
             M-SEARCH spesso arrivano in unicast al socket mittente */
        }
        try {
          sock!.setMulticastTTL(255)
          sock!.send(Buffer.from(SSDP_MSEARCH, 'latin1'), 1900, '239.255.255.250')
        } catch {
          finish()
        }
      })
    } catch {
      finish()
    }
  })
}
