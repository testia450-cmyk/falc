/* ================================================================
 * discovery-service/lib/oui.ts — adattatore lookup OUI (Task 25)
 * ================================================================
 * Il database OUI è copiato INTEGRALMENTE (cp, non riscritto) dal
 * repository v15.16.0: lib/oui-vendors-extended.ts (10.679 prefissi
 * IEEE MA-L/MA-M/MA-S + compat legacy, generato 2026-10-10 — vedi
 * l'intestazione del file stesso). Questo modulo è il SOLO adattatore:
 *
 *   lookupMacOui(mac) → lookup longest-prefix MA-S (36 bit) → MA-M
 *   (28 bit) → MA-L (24 bit), stessa semantica di lookupExtendedOui
 *   in v15 src/lib/mac-oui-database.ts (righe 117-134 + lookup
 *   9/7/6 cifre esadecimali del file del DB).
 *
 * NESSUN dato inventato: MAC non presente nel registry IEEE → null.
 * ================================================================ */

import {
  lookupExtendedOui,
  EXTENDED_OUI_STATS,
  type OuiCategory,
} from './oui-vendors-extended'

/* ---------------- Tipi ---------------- */

export interface OuiLookup {
  /** Prefisso formattato a coppie esadecimali: "24:A4:3C" (MA-L) o più
   *  octet per MA-M ("XX:XX:XX:X") / MA-S ("XX:XX:XX:XX:X"). */
  prefix: string
  /** Prefisso esadecimale senza separatori (6/7/9 cifre). */
  prefixHex: string
  /** Brand normalizzato FALCO-OS (es. "Ubiquiti"). */
  brand: string
  /** Nome organizzazione completa del registry IEEE (es. "Ubiquiti Networks Inc."). */
  vendor: string
  /** Categoria della famiglia del brand (RADIO, CAMERA, SWITCH, …). */
  category: OuiCategory
  /** Blocco di assegnazione IEEE del prefisso matched. */
  blockType: 'MA-L (24-bit)' | 'MA-M (28-bit)' | 'MA-S (36-bit)'
}

/* ---------------- Normalizzazione MAC ---------------- */

/** Normalizza un MAC in qualsiasi formato ("AA:BB:CC:11:22:33",
 *  "AA-BB-CC-11-22-33", "AABB.CC11.2233", "aabbcc112233") nella forma
 *  "AA:BB:CC:11:22:33". Null se non sono 12 cifre esadecimali. */
export function normalizeMacAddress(mac: string): string | null {
  if (!mac || typeof mac !== 'string') return null
  const hex = mac.replace(/[^0-9a-fA-F]/g, '').toUpperCase()
  if (!/^[0-9A-F]{12}$/.test(hex)) return null
  return hex.match(/.{2}/g)?.join(':') ?? null
}

/* ---------------- Lookup ---------------- */

/** Lookup OUI con match del prefisso PIÙ LUNGO (MA-S 9 cifre → MA-M 7 →
 *  MA-L 6), esattamente come lookupExtendedOui/lookupMacOui in v15.
 *  Restituisce null se il prefisso non è nel database (onesto). */
export function lookupMacOui(mac: string): OuiLookup | null {
  const hit = lookupExtendedOui(mac)
  if (!hit) return null
  const blockType: OuiLookup['blockType'] =
    hit.prefix.length === 9
      ? 'MA-S (36-bit)'
      : hit.prefix.length === 7
        ? 'MA-M (28-bit)'
        : 'MA-L (24-bit)'
  return {
    // NB: .{1,2} (non .{2}) — i prefissi MA-M/MA-S hanno lunghezza DISPARI
    // (7/9 cifre): l'ultimo gruppo va mostrato con una sola cifra esadecimale
    prefix: hit.prefix.match(/.{1,2}/g)?.join(':') ?? hit.prefix,
    prefixHex: hit.prefix,
    brand: hit.brand,
    vendor: hit.vendor,
    category: hit.category,
    blockType,
  }
}

/** Statistiche del database copiato (per /health e diagnostica). */
export { EXTENDED_OUI_STATS }
