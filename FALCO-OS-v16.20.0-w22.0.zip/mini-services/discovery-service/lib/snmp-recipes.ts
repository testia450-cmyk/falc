/* ================================================================
 * discovery-service/lib/snmp-recipes.ts — v16.18 (W19)
 * KNOWLEDGE BASE «Attivazione SNMP assistita»
 * ================================================================
 * Catalogo di RICETTE per-vendor: la sequenza ESATTA di comandi (o
 * chiamate API) che attiva l'agente SNMP su un apparato, con il
 * trasporto (SSH / API HTTP SwOS / solo manuale) e la verifica finale
 * (sonda SNMP del modulo lib/snmp.ts).
 *
 * REGOLE COSTITUZIONALI (ereditate da tutta v16):
 *   · la SONDA resta in sola lettura; questo catalogo serve SOLO
 *     all'ATTUATORE, che parte da conferma umana esplicita — la UI
 *     mostra i comandi IN CHIARO prima dell'esecuzione;
 *   · NESSUN dato inventato: ogni ricetta dichiara la FONTE e la
 *     confidenza («verified» = vista su fonte primaria/codice reale,
 *     «high» = documentazione ufficiale notoria, «medium» = sintassi
 *     da verificare sul modello preciso — l'operatore la vede);
 *   · telecamere: l'operatore ha dichiarato che contano solo
 *     online/offline → ricetta «ping-only» (nessuna scrittura).
 *
 * PROVENIENZA DELLE RICETTE (ricerca 31/10/2026):
 *   · MikroTik SwOS snmp.b {en,com,ci,loc} — VERIFICATA su
 *     lanrat/python-mikrotik-swos (SWOS_API.md + swos_map.py, testato
 *     CRS305/CRS310/CSS326 SwOS 2.17-2.18) e su payload reale postato
 *     sul forum MikroTik (topic 265667: snmp.b:{en:0x01,com:…}).
 *     SwOS Lite usa ID numerici i01..i04 (SWOS_API.md) — l'attuatore
 *     rileva il dialetto dalla GET di /snmp.b.
 *   · Ubiquiti airOS /tmp/system.cfg + «cfgmtd -w» +
 *     «/usr/etc/rc.d/rc.softrestart save» — VERIFICATA dall'autore del
 *     backend AirOS di netjsonconfig (issue edoput/netjsonconfig#25).
 *     airOS esige che i campi siano SCRITTI (community, contact,
 *     location): la ricetta li valorizza SEMPRE tutti e tre.
 *   · Huawei VRP «snmp-agent community read …» — VERIFICATA in
 *     configurazioni reali (issues GitHub hwos/vrp automation).
 *   · FortiOS «config system snmp community / edit 1 / set name /
 *     set status enable» — VERIFICATA (issues GitHub fortinet/ansible).
 *   · MikroTik RouterOS, Cisco IOS, Aruba AOS-CX/AOS-S, Juniper
 *     Junos, Ubiquiti EdgeOS — documentazione ufficiale notoria.
 *   · TP-Link JetStream, Ruckus ICX, Dell PowerConnect — «medium»:
 *     guide CLI del vendor, sintassi da confermare sul modello.
 *   · Hikvision / Dahua / PLANET / UniFi-controller / Cambium /
 *     Netgear / Zyxel — «manual»: gestione da pannello web (i passi
 *     sono descritti e mostrati all'operatore, MAI eseguiti).
 * ================================================================ */

/* ---------------- Tipi ---------------- */

export type RecipeTransport = 'ssh' | 'http-swos' | 'manual' | 'ping-only'
export type RecipeConfidence = 'verified' | 'high' | 'medium'

export interface RecipeStep {
  /** Comando esatto (SSH) o descrizione dell'operazione API (SwOS). */
  cmd: string
  /** Perché questo passo esiste (mostrato all'operatore). */
  note?: string
  /** default true: un fallimento blocca la ricetta. false = warning
   *  tollerato (es. RouterOS «already have such community»). */
  fatal?: boolean
  /** Pattern (regex) che se presente nell'output/messaggio rende il
   *  fallimento NON fatale (esito atteso e benigno). */
  benign?: string
}

export interface SnmpRecipe {
  id: string
  vendor: string
  family: string
  transport: RecipeTransport
  /** Confidenza dichiarata — l'operatore la vede PRIMA di confermare. */
  confidence: RecipeConfidence
  /** Fonte della ricerca (onestà: sempre citabile). */
  source: string
  /** Nota operativa mostrata nella preview (limiti, prerequisiti). */
  note: string
  /** Percorso web per la variante manuale (trasporto manual) o per
   *  il fallback se l'automazione non riesce. */
  webPath?: string
  /** Comandi modello con token {{community}} {{contact}} {{location}}. */
  steps: RecipeStep[]
  /** Istruzioni manuali (per transport manual, o fallback). */
  manualSteps: string[]
}

/* ---------------- Catalogo ---------------- */

export const SNMP_RECIPES: readonly SnmpRecipe[] = [
  /* --- MikroTik RouterOS (SSH) --- */
  {
    id: 'mikrotik-routeros',
    vendor: 'MikroTik',
    family: 'RouterOS',
    transport: 'ssh',
    confidence: 'verified',
    source: 'Documentazione ufficiale MikroTik (Manual:SNMP) — /snmp set enabled=yes',
    note: 'RouterOS (RB/CCR/hEX/CRS con RouterOS). La community «public» esiste già di fabbrica: il comando add può rispondere «failure: already have such community» — esito benigno, la community c\'è già.',
    steps: [
      { cmd: '/snmp set enabled=yes', note: 'attiva il servizio SNMP', fatal: true },
      { cmd: '/snmp community add name={{community}}', note: 'community di lettura (già presente = benigno)', fatal: true, benign: 'already have such community' },
    ],
    manualSteps: [
      'Winbox/WebFig → IP → SNMP → spunta «Enabled»',
      'IP → SNMP → Communities: voce «public» (o nuova community) — Access: read only',
    ],
  },

  /* --- MikroTik SwOS (API HTTP, digest) — RB260GSP e fratelli --- */
  {
    id: 'mikrotik-swos',
    vendor: 'MikroTik',
    family: 'SwOS',
    transport: 'http-swos',
    confidence: 'verified',
    source: 'lanrat/python-mikrotik-swos (SWOS_API.md, swos_map.py: snmp.b {en,com,ci,loc}) + payload reale forum MikroTik topic 265667',
    note: 'SwOS NON ha SSH né CLI: l\'unica automazione è l\'API HTTP del pannello web (digest auth). Campi: en (enable), com (community), ci (contact), loc (location) — su SwOS Lite gli stessi campi si chiamano i01..i04 (rilevati in automatico). Se /snmp.b non risponde (firmware molto vecchio) → intervento manuale dal pannello.',
    webPath: 'Pannello web SwOS → System → SNMP',
    steps: [
      { cmd: 'GET /snmp.b', note: 'lettura dello stato SNMP attuale (dialetto SwOS/SwOS Lite)', fatal: true },
      { cmd: "POST /snmp.b {en:0x01, com:'{{community}}', ci:'{{contact}}', loc:'{{location}}'}", note: 'attiva SNMP e scrive community/contact/location (hex ASCII)', fatal: true },
      { cmd: 'GET /snmp.b', note: 'rilettura di conferma (read-back)', fatal: false },
    ],
    manualSteps: [
      'Pannello web → System → SNMP: spunta «Enabled»',
      'Community: public · Contact e Location: valorizzarli (SwOS li mostra in sysContact/sysLocation)',
    ],
  },

  /* --- Ubiquiti airMAX / airOS (SSH + cfgmtd) --- */
  {
    id: 'ubiquiti-airos',
    vendor: 'Ubiquiti',
    family: 'airOS (airMAX)',
    transport: 'ssh',
    confidence: 'verified',
    source: 'netjsonconfig backend AirOS (issue edoput/netjsonconfig#25): /tmp/system.cfg + cfgmtd -w + rc.softrestart save',
    note: 'Radio airMAX (NanoBeam/NanoStation/Rocket/LiteBeam…). airOS vuole i campi SNMP SCRITTI: la ricetta valorizza SEMPRE community, contact e location (i «2 campi» che l\'operatore segnala obbligatori su Ubiquiti). cfgmtd -w persiste in NVRAM; rc.softrestart applica riavviando i servizi (~20 s di assenza radio — nome script verificato su due fonti indipendenti).',
    steps: [
      { cmd: 'cp /tmp/system.cfg /tmp/system.cfg.bak', note: 'backup della configurazione corrente (prima di toccare)', fatal: true },
      { cmd: "sed -i '/^snmp\\./d' /tmp/system.cfg", note: 'rimuove le vecchie righe snmp.* (idempotenza)', fatal: true },
      { cmd: "echo 'snmp.status=enabled' >> /tmp/system.cfg", note: 'SNMP attivo', fatal: true },
      { cmd: "echo 'snmp.community={{community}}' >> /tmp/system.cfg", note: 'community (campo obbligatorio: deve essere scritto)', fatal: true },
      { cmd: "echo 'snmp.contact={{contact}}' >> /tmp/system.cfg", note: 'contact (campo obbligatorio su airOS: deve essere scritto)', fatal: true },
      { cmd: "echo 'snmp.location={{location}}' >> /tmp/system.cfg", note: 'location (campo obbligatorio su airOS: deve essere scritto)', fatal: true },
      { cmd: 'cfgmtd -w', note: 'scrive la configurazione in NVRAM (persiste al riavvio)', fatal: true },
      { cmd: '/usr/etc/rc.d/rc.softrestart save', note: 'applica la configurazione senza riavviare la radio', fatal: true },
    ],
    manualSteps: [
      'Web UI airMAX → System → SNMP: spunta «Enable SNMP Daemon»',
      'Community + Contact + Location: riempire TUTTI e tre (airOS li richiede scritti) → Apply',
    ],
  },

  /* --- Ubiquiti EdgeOS (SSH, Vyatta CLI) --- */
  {
    id: 'ubiquiti-edgeos',
    vendor: 'Ubiquiti',
    family: 'EdgeOS (EdgeRouter/EdgePoint)',
    transport: 'ssh',
    confidence: 'high',
    source: 'Guida ufficiale Ubiquiti EdgeOS — set service snmp',
    note: 'EdgeRouter/EdgePoint (ER/EP). CLI Vyatta: configure → set → commit → save.',
    steps: [
      { cmd: 'configure', note: 'entra in modalità configurazione', fatal: true },
      { cmd: 'set service snmp community {{community}} authorization ro', note: 'community in sola lettura', fatal: true },
      { cmd: 'commit', note: 'applica la configurazione', fatal: true },
      { cmd: 'save', note: 'persiste la configurazione', fatal: true },
      { cmd: 'exit', note: 'esce dalla modalità configurazione', fatal: true },
    ],
    manualSteps: [
      'Web UI EdgeOS → System → SNMP Agent → Enable, Community, Location → Save',
    ],
  },

  /* --- Cisco IOS / IOS-XE (SSH) --- */
  {
    id: 'cisco-ios',
    vendor: 'Cisco',
    family: 'IOS / IOS-XE',
    transport: 'ssh',
    confidence: 'high',
    source: 'Documentazione ufficiale Cisco — snmp-server community <name> RO',
    note: 'Catalyst/ISR con IOS classico. «write memory» non chiede conferma.',
    steps: [
      { cmd: 'configure terminal', note: 'modalità configurazione', fatal: true },
      { cmd: 'snmp-server community {{community}} RO', note: 'community read-only', fatal: true },
      { cmd: 'end', note: 'uscita dalla configurazione', fatal: true },
      { cmd: 'write memory', note: 'salva la startup-config', fatal: true },
    ],
    manualSteps: [
      'CLI/telnet: conf t → snmp-server community public RO → end → write memory',
    ],
  },

  /* --- Aruba AOS-CX (SSH) --- */
  {
    id: 'aruba-aoscx',
    vendor: 'Aruba/HPE',
    family: 'AOS-CX',
    transport: 'ssh',
    confidence: 'high',
    source: 'Guida CLI Aruba AOS-CX — snmp-server community <name>',
    note: 'Switch Aruba 6xxx/8xxx con AOS-CX.',
    steps: [
      { cmd: 'configure terminal', note: 'modalità configurazione', fatal: true },
      { cmd: 'snmp-server community {{community}}', note: 'community (default read-only)', fatal: true },
      { cmd: 'end', note: 'uscita', fatal: true },
      { cmd: 'write memory', note: 'salva la configurazione', fatal: true },
    ],
    manualSteps: [
      'Web UI Aruba → System → SNMP → Communities: aggiungi community read-only',
    ],
  },

  /* --- Aruba ProCurve / AOS-S (SSH) --- */
  {
    id: 'aruba-procurve',
    vendor: 'Aruba/HPE',
    family: 'AOS-S (ProCurve)',
    transport: 'ssh',
    confidence: 'high',
    source: 'Guida CLI ProCurve/AOS-S — snmp-server community "name"',
    note: 'Switch ProCurve/AOS-S classici (25xx/26xx/29xx).',
    steps: [
      { cmd: 'configure', note: 'modalità configurazione', fatal: true },
      { cmd: 'snmp-server community "{{community}}"', note: 'community (virgolette richieste su AOS-S)', fatal: true },
      { cmd: 'exit', note: 'uscita', fatal: true },
      { cmd: 'write memory', note: 'salva la configurazione', fatal: true },
    ],
    manualSteps: [
      'Web UI ProCurve → SNMP Communities: aggiungi community read-only',
    ],
  },

  /* --- Huawei VRP (SSH) --- */
  {
    id: 'huawei-vrp',
    vendor: 'Huawei',
    family: 'VRP (S-series)',
    transport: 'ssh',
    confidence: 'verified',
    source: 'Configurazioni reali VRP (issues hwos/vrp su GitHub) — snmp-agent community read <name>',
    note: 'Switch S-series / router Huawei. «save force» evita il prompt Y/N (su VRP molto vecchi usare «save» da console).',
    steps: [
      { cmd: 'system-view', note: 'vista di sistema', fatal: true },
      { cmd: 'snmp-agent', note: 'attiva il servizio SNMP', fatal: true },
      { cmd: 'snmp-agent sys-info version v2c', note: 'versione v2c', fatal: true },
      { cmd: 'snmp-agent community read {{community}}', note: 'community read-only', fatal: true },
      { cmd: 'quit', note: 'uscita dalla vista di sistema', fatal: true },
      { cmd: 'save force', note: 'salva senza prompt (fallback manuale se non supportato)', fatal: false },
    ],
    manualSteps: [
      'CLI: system-view → snmp-agent → snmp-agent sys-info version v2c → snmp-agent community read public → quit → save',
    ],
  },

  /* --- Fortinet FortiOS (SSH) --- */
  {
    id: 'fortinet-fortios',
    vendor: 'Fortinet',
    family: 'FortiOS (FortiGate)',
    transport: 'ssh',
    confidence: 'verified',
    source: 'Issues fortinet-solutions-cse/40ansible — config system snmp community / edit 1 / set name / set status enable',
    note: 'FortiGate. «edit 1» usa la prima voce della tabella community: se contiene già una community diversa, rinominarla fa perdere la vecchia (il risultato è onesto nel read-back).',
    steps: [
      { cmd: 'config system snmp community', note: 'apre la tabella community', fatal: true },
      { cmd: 'edit 1', note: 'prima voce (default vuota o «public»)', fatal: true },
      { cmd: 'set name "{{community}}"', note: 'nome community', fatal: true },
      { cmd: 'set status enable', note: 'attiva la community', fatal: true },
      { cmd: 'next', note: 'chiude la voce', fatal: true },
      { cmd: 'end', note: 'applica la tabella', fatal: true },
    ],
    manualSteps: [
      'Web UI FortiGate → System → SNMP → Community: Edit (o Create New) → Status Enable, Name public',
    ],
  },

  /* --- TP-Link JetStream / Omada (SSH) --- */
  {
    id: 'tplink-jetstream',
    vendor: 'TP-Link',
    family: 'JetStream / Omada',
    transport: 'ssh',
    confidence: 'medium',
    source: 'Guide CLI TP-Link JetStream (snmp-agent community read <name>) — sintassi da confermare sul modello preciso',
    note: 'Switch JetStream/Omada con CLI (T1600G/T2600G/SG34xx/SG39xx). Molti TP-Link economici sono SOLO web (Easy/Green UI): se SSH non risponde → percorso manuale. «enable» può chiedere password: se fallisce in modo benigno il resto prosegue.',
    steps: [
      { cmd: 'enable', note: 'modalità privilegiata (già attiva = benigno)', fatal: true, benign: 'password' },
      { cmd: 'configure', note: 'modalità configurazione', fatal: true },
      { cmd: 'snmp-agent', note: 'attiva il servizio SNMP', fatal: true },
      { cmd: 'snmp-agent community read {{community}}', note: 'community read-only', fatal: true },
      { cmd: 'snmp-agent sys-info version v1 v2c', note: 'versioni accettate', fatal: true },
      { cmd: 'end', note: 'uscita', fatal: true },
      { cmd: 'copy running-config startup-config', note: 'salva la configurazione', fatal: true },
    ],
    manualSteps: [
      'Web UI JetStream → SNMP → SNMP Configuration: Enable, Community (public), Version v1/v2c → Apply',
    ],
  },

  /* --- Juniper Junos (SSH) --- */
  {
    id: 'juniper-junos',
    vendor: 'Juniper',
    family: 'Junos (EX/QFX)',
    transport: 'ssh',
    confidence: 'high',
    source: 'Documentazione Juniper — set snmp community <name> authorization read-only',
    note: 'Switch EX/QFX e router Juniper.',
    steps: [
      { cmd: 'configure', note: 'modalità configurazione (privata se condivisa)', fatal: true },
      { cmd: 'set snmp community {{community}} authorization read-only', note: 'community read-only', fatal: true },
      { cmd: 'commit and-quit', note: 'applica ed esce', fatal: true },
    ],
    manualSteps: [
      'CLI Junos: configure → set snmp community public authorization read-only → commit and-quit',
    ],
  },

  /* --- Ruckus / Brocade ICX (SSH) --- */
  {
    id: 'ruckus-icx',
    vendor: 'Ruckus/Brocade',
    family: 'FastIron ICX',
    transport: 'ssh',
    confidence: 'medium',
    source: 'Guide CLI FastIron — snmp-server community <name> (conf confermare sul modello)',
    note: 'ICX 7xxx/6xxx (già Brocade FastIron).',
    steps: [
      { cmd: 'configure', note: 'modalità configurazione', fatal: true },
      { cmd: 'snmp-server community {{community}}', note: 'community standard', fatal: true },
      { cmd: 'exit', note: 'uscita', fatal: true },
      { cmd: 'write memory', note: 'salva la configurazione', fatal: true },
    ],
    manualSteps: [
      'Web UI Ruckus → System → SNMP: Enable + community read-only',
    ],
  },

  /* --- Dell PowerConnect (SSH) --- */
  {
    id: 'dell-powerconnect',
    vendor: 'Dell',
    family: 'PowerConnect',
    transport: 'ssh',
    confidence: 'medium',
    source: 'Guide CLI Dell PowerConnect (sintassi Cisco-like) — da confermare sul modello',
    note: 'PowerConnect/N-series con CLI. Sintassi Cisco-like.',
    steps: [
      { cmd: 'configure', note: 'modalità configurazione', fatal: true },
      { cmd: 'snmp-server community {{community}} ro', note: 'community read-only', fatal: true },
      { cmd: 'exit', note: 'uscita', fatal: true },
      { cmd: 'copy running-config startup-config', note: 'salva la configurazione', fatal: true },
    ],
    manualSteps: [
      'Web UI Dell → System → SNMP: Enable + community',
    ],
  },

  /* --- Ubiquiti EdgeSwitch (gestione web — CLI non verificata) --- */
  {
    id: 'ubiquiti-edgeswitch-manual',
    vendor: 'Ubiquiti',
    family: 'EdgeSwitch',
    transport: 'manual',
    confidence: 'verified',
    source: 'EdgeSwitch: CLI SSH esiste ma la sintassi SNMP non è stata verificata su fonte primaria — onestà: manuale',
    note: 'EdgeSwitch (ES-16/24/48): la CLI è Cisco-like ma la sintassi SNMP esatta non è stata verificata — niente comandi alla cieca. Attivazione dal pannello web (o confermare la sintassi CLI sul proprio modello e usare la ricetta Ruckus ICX come riferimento).',
    webPath: 'Web UI EdgeSwitch → System → SNMP',
    steps: [],
    manualSteps: [
      'Web UI EdgeSwitch → System → SNMP: Enable, Community public (Read) → Apply',
      'In alternativa via SSH la famiglia CLI è «snmp-server community <nome>» (riferimento Ruckus ICX) — verificare sul proprio firmware prima di usarla',
    ],
  },

  /* --- Telecamere: ping-only (NESSUNA scrittura) --- */
  {
    id: 'camera-ping-only',
    vendor: '(telecamere)',
    family: 'Monitoraggio presenza',
    transport: 'ping-only',
    confidence: 'verified',
    source: 'Decisione operatore 31/10/2026: «se è una telecamera non mi interessa avere i valori, ma solo ping se è online/offline»',
    note: 'Nessuna attivazione: la telecamera viene dichiarata in modalità «ping-only» (presenza ICMP). Nessun comando viene inviato al dispositivo.',
    steps: [],
    manualSteps: [
      'Nessuna azione richiesta: il monitoraggio della telecamera usa il ping (online/offline).',
    ],
  },

  /* --- Manuali (solo istruzioni, mai eseguiti) --- */
  {
    id: 'hikvision-manual',
    vendor: 'Hikvision',
    family: '(switch e NVR — pannello web)',
    transport: 'manual',
    confidence: 'verified',
    source: 'Mancanza di CLI/SSH sui gestiti Hikvision (switch HS/DS-3E, NVR): solo pannello web',
    note: 'Gli switch Hikvision non espongono SSH/CLI: l\'attivazione è manuale dal pannello web. Le telecamere Hikvision non ne hanno bisogno (ping-only).',
    webPath: 'Web UI → Network → Advanced Settings → SNMP',
    steps: [],
    manualSteps: [
      'Web UI Hikvision → Configuration → Network → Advanced Settings → SNMP',
      'Spunta «Enable SNMP», Version: v2c, Community: public → Save',
      'NVR: Configurazione → Rete → Impostazioni avanzate → SNMP → v2c / public',
    ],
  },
  {
    id: 'dahua-manual',
    vendor: 'Dahua',
    family: '(switch e NVR — pannello web)',
    transport: 'manual',
    confidence: 'verified',
    source: 'Mancanza di CLI/SSH sui gestiti Dahua: solo pannello web',
    note: 'Come Hikvision: gestione via web. Le telecamere Dahua non ne hanno bisogno (ping-only).',
    webPath: 'Web UI → Network Settings → SNMP',
    steps: [],
    manualSteps: [
      'Web UI Dahua → Setting → Network → SNMP: Enable, Version v2c, Community public → Save',
    ],
  },
  {
    id: 'planet-manual',
    vendor: 'PLANET',
    family: '(switch gestiti — pannello web)',
    transport: 'manual',
    confidence: 'verified',
    source: 'Switch PLANET (GS/IGS/WGS): gestione via pannello web, SNMP dalla pagina dedicata',
    note: 'PLANET non ha una CLI SSH uniforme: attivazione dal pannello web di gestione.',
    webPath: 'Web UI → System → SNMP Configuration',
    steps: [],
    manualSteps: [
      'Web UI PLANET → System → SNMP Configuration',
      'SNMP: Enable · Community: public (Get) · Trap: opzionale → Apply',
    ],
  },
  {
    id: 'unifi-manual',
    vendor: 'Ubiquiti',
    family: 'UniFi (gestiti dal controller)',
    transport: 'manual',
    confidence: 'verified',
    source: 'UniFi: la configurazione vive sul controller, non sul singolo switch',
    note: 'Switch/AP UniFi: SNMP si abilita dal controller (o da UISP per airMAX gestiti), non via SSH sul singolo apparato.',
    webPath: 'UniFi Controller → Settings → System → SNMP',
    steps: [],
    manualSteps: [
      'Controller UniFi → Settings → System → SNMP: Enable, Community',
      'Per airMAX sotto UISP: UISP → device → Settings → SNMP',
    ],
  },
  {
    id: 'cambium-manual',
    vendor: 'Cambium',
    family: 'ePMP/Force',
    transport: 'manual',
    confidence: 'verified',
    source: 'ePMP: SSH limitato, SNMP gestito dalla pagina Services del pannello web',
    note: 'ePMP/Force: attivazione dal pannello web (l\'SSH della ePMP non espone un CLI di provisioning affidabile).',
    webPath: 'Web UI ePMP → Configuration → Services → SNMP',
    steps: [],
    manualSteps: [
      'Web UI ePMP → Configuration → Services → SNMP: Enable, Community (read), Version v2c → Save',
    ],
  },
  {
    id: 'generic-manual',
    vendor: '(altro vendor)',
    family: 'Pannello web generico',
    transport: 'manual',
    confidence: 'verified',
    source: 'Fallback onesto: vendor non in catalogo — nessuna scrittura tentata alla cieca',
    note: 'Vendor non ancora in catalogo: FALCO-OS non inventa comandi. Attivazione manuale dal pannello di gestione.',
    steps: [],
    manualSteps: [
      'Aprire il pannello web di gestione dell\'apparato',
      'Cercare la sezione SNMP (spesso sotto Network/System/Services)',
      'Attivare l\'agente SNMP v2c con community di lettura (es. public)',
      'Verificare dal browser di FALCO-OS che la sonda ora risponda',
    ],
  },
]

/* ---------------- Selezione ricetta ---------------- */

/** Dialetti/modello SwOS: apparati MikroTik che girano SOLO con SwOS
 *  (niente RouterOS possibile) — RB260GSP compreso. */
const SWOS_ONLY_MODELS = /^(\s*)(rb\s?2(50|60)|css\s?10[66]|css\s?3(18|26)|css\s?6(10|20)|crs\s?1(0[0-9]|1[0-9]|2[0-5]))/i
const SWOS_ONLY_IN_TEXT = /(rb\s?2(50|60)|css\s?10[66]|css\s?3(18|26)|css\s?6(10|20)|swos)/i

function norm(s: string | null | undefined): string {
  return (s ?? '').trim().toLowerCase()
}

/** Sceglie la ricetta per marca/modello/tipo. PURA: nessun accesso IO.
 *  Ritorna l'id ricetta — la UI può sempre forzarne un'altra a tendina. */
export function pickRecipeId(brand: string, model: string, type: string): string {
  const b = norm(brand)
  const m = norm(model)
  const t = norm(type)

  /* Telecamere → SEMPRE ping-only (decisione operatore) */
  if (t === 'camera' || t === 'lpr') return 'camera-ping-only'

  const swosLike = SWOS_ONLY_MODELS.test(m) || SWOS_ONLY_IN_TEXT.test(m)

  if (b.includes('mikrotik') || b.includes('mikrotik routeros')) {
    return swosLike ? 'mikrotik-swos' : 'mikrotik-routeros'
  }
  if (b.includes('ubiquiti') || b.includes('ubnt')) {
    if (/(edge ?router|edge ?point|\ber-|\bep-)/.test(m)) return 'ubiquiti-edgeos'
    if (/(edge ?switch|\bes-)/.test(m)) return 'ubiquiti-edgeswitch-manual'
    if (/(uni ?fi|\bus-|\busw|\budm|dream ?machine)/.test(m)) return 'unifi-manual'
    /* radio airMAX: il caso d'uso WISP principale */
    return 'ubiquiti-airos'
  }
  if (b.includes('tp-link') || b.includes('tplink')) return 'tplink-jetstream'
  if (b.includes('cisco') || b.includes('catalyst')) return 'cisco-ios'
  if (b.includes('aruba') || b.includes('hpe') || b.includes('hp ') || b.includes('procurve')) {
    return /(\bcx\b|\bcx[0-9])/.test(m) ? 'aruba-aoscx' : 'aruba-procurve'
  }
  if (b.includes('huawei')) return 'huawei-vrp'
  if (b.includes('fortinet') || b.includes('fortigate')) return 'fortinet-fortios'
  if (b.includes('juniper')) return 'juniper-junos'
  if (b.includes('ruckus') || b.includes('brocade')) return 'ruckus-icx'
  if (b.includes('dell')) return 'dell-powerconnect'
  if (b.includes('hikvision')) return 'hikvision-manual'
  if (b.includes('dahua')) return 'dahua-manual'
  if (b.includes('planet')) return 'planet-manual'
  if (b.includes('cambium') || b.includes('epmp')) return 'cambium-manual'
  return 'generic-manual'
}

/** Tutte le ricette con lo stesso «gruppo trasporto» del pick — per la
 *  tendina di override dell'operatore (es. CRS con SwOS invece di
 *  RouterOS): gli id ordinati, il pick per primo. */
export function alternativeRecipeIds(pickedId: string, brand: string): string[] {
  const picked = SNMP_RECIPES.find((r) => r.id === pickedId)
  if (!picked) return [pickedId]
  const b = norm(brand)
  const sameVendorOrGroup = SNMP_RECIPES
    .filter((r) => r.id !== pickedId)
    .filter((r) => {
      if (r.id === 'camera-ping-only' || r.id === 'generic-manual') return false
      const rv = norm(r.vendor)
      if (b.includes('mikrotik') && rv.includes('mikrotik')) return true
      if ((b.includes('ubiquiti') || b.includes('ubnt')) && rv.includes('ubiquiti')) return true
      return false
    })
    .map((r) => r.id)
  /* il manuale generico è SEMPRE un'alternativa lecita (trasporto manual) */
  return [pickedId, ...sameVendorOrGroup]
}

/** Catalogo pubblico (nessun segreto): per la rotta GET /actuate/recipes. */
export function recipesCatalog(): unknown {
  return SNMP_RECIPES.map((r) => ({
    id: r.id,
    vendor: r.vendor,
    family: r.family,
    transport: r.transport,
    confidence: r.confidence,
    source: r.source,
    note: r.note,
    webPath: r.webPath ?? null,
    steps: r.steps.map((s) => ({ cmd: s.cmd, note: s.note ?? null, fatal: s.fatal ?? true, benign: s.benign ?? null })),
    manualSteps: r.manualSteps,
  }))
}

/** Ricetta per id (o undefined — onesto). */
export function recipeById(id: string): SnmpRecipe | undefined {
  return SNMP_RECIPES.find((r) => r.id === id)
}

/** Interpolazione dei token {{community}} {{contact}} {{location}}. */
export function interpolate(cmd: string, vars: { community: string; contact: string; location: string }): string {
  return cmd
    .replaceAll('{{community}}', vars.community)
    .replaceAll('{{contact}}', vars.contact)
    .replaceAll('{{location}}', vars.location)
}
