/* ================================================================
 * discovery-service/lib/snmp-arp.ts — TABELLA ARP (v16.15 W13)
 * ================================================================
 * La seconda dichiarazione che mancava: la mappa IP → MAC che il
 * gateway/router ha imparato parlando con la rete (IP-MIB, OID
 * verificati sul file MIB ufficiale net-snmp):
 *
 *   · ipNetToPhysicalTable (RFC 4293) 1.3.6.1.2.1.4.35.1 — la tabella
 *     MODERNA: indice { ifIndex, NetAddressType, NetAddress } dove il
 *     tipo (1=IPv4, 2=IPv6) e l'INDIRIZZO vivono nell'indice OID;
 *     coloni: 4 = PhysAddress, 6 = Type (other/invalid/dynamic/static);
 *   · ipNetToMediaTable (legacy IPv4) 1.3.6.1.2.1.4.22.1 — indice
 *     { ifIndex, NetAddress }: colonna 2 = PhysAddress, 4 = Type.
 *     Deprecata ma ancora l'UNICA esposta da MikroTik RouterOS e da
 *     molti agenti embedded: si legge ENTRAMBE e si fa il merge
 *     (la moderna vince sui conflitti, la legacy riempie i buchi).
 *
 * A COSA SERVE (NetDisco/OpenNMS): la FDB dice «il MAC X sta sulla
 * porta P» ma NON chi è X; l'ARP dice «il MAC X risponde all'IP Y»:
 * insieme identificano l'endpoint anche quando l'inventario non ha
 * il MAC. Alimenta il modello ArpEntry (che esisteva dal v15 senza
 * un motore che lo riempisse) e il correlatore W14.
 *
 * REGOLA D'ORO: nessuna riga inventata; walk mancato = avviso;
 * entry invalid(2) e MAC broadcast/multicast scartati con onestà.
 * ================================================================ */

import {
  sessionWalk,
  type Session,
} from './snmp'

/* ---------------- OID ARP (IP-MIB, verificati) ---------------- */

const ARP_OIDS = {
  // RFC 4293 — tabella moderna (IPv4 + IPv6)
  ipNetToPhysicalPhysAddress: '1.3.6.1.2.1.4.35.1.4',
  ipNetToPhysicalType: '1.3.6.1.2.1.4.35.1.6',
  // legacy IPv4 (deprecata ma MikroTik/embedded la espongono solo lei)
  ipNetToMediaPhysAddress: '1.3.6.1.2.1.4.22.1.2',
  ipNetToMediaType: '1.3.6.1.2.1.4.22.1.4',
} as const

/** Cap onesto: voci ARP per apparato (un gateway domestico ne ha <256). */
const CAP_ARP = 512

/* ---------------- Tipi pubblici ---------------- */

export type ArpEntryType = 'dynamic' | 'static' | 'other'

export interface ArpRow {
  ip: string
  mac: string
  ifIndex: number
  type: ArpEntryType
}

export interface SnmpArpResult {
  rows: ArpRow[]
  warnings: string[]
}

/* ---------------- Utility ---------------- */

function asInt(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v)
  if (typeof v === 'string' && /^-?\d+$/.test(v)) return Number(v)
  return null
}

function asBuffer(v: unknown): Buffer | null {
  return Buffer.isBuffer(v) ? v : null
}

/** MAC da PhysAddress (6 ottetti) → AA:BB:CC:DD:EE:FF ('' se non valido). */
function macFromBuffer(buf: Buffer | null): string {
  if (!buf || buf.length !== 6) return ''
  const hex = buf.toString('hex')
  if (/^0{12}$/.test(hex)) return '' // 00:00:…:00 non è un dispositivo
  if ((buf[0] & 0x01) === 0x01) return '' // multicast/broadcast: inondato
  return hex.match(/.{2}/g)?.join(':').toUpperCase() ?? ''
}

const TYPE_BY_NUM: Record<number, ArpEntryType> = {
  1: 'other', 2: 'other', /* invalid(2) → scartata prima */
  3: 'dynamic', 4: 'static',
}

/** IPv4 compatto da 4 ottetti. */
function ipv4FromBuffer(buf: Buffer): string {
  return `${buf[0]}.${buf[1]}.${buf[2]}.${buf[3]}`
}

/** IPv6 espanso da 16 ottetti (gruppi hex, compressione :: minima). */
function ipv6FromBuffer(buf: Buffer): string {
  const groups: string[] = []
  for (let i = 0; i < 16; i += 2) groups.push(((buf[i] << 8) | buf[i + 1]).toString(16))
  return groups.join(':')
}

function isIPv4Text(ip: string): boolean {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(ip)
}

function suffixArcs(base: string, oid: string): number[] {
  if (!oid.startsWith(base + '.')) return []
  return oid.slice(base.length + 1).split('.').map((a) => Number(a))
}

async function safeWalk(
  session: Session,
  base: string,
  cap: number,
): Promise<{ oids: Array<{ oid: string; value: unknown }>; error: string | null }> {
  try {
    const rows = await sessionWalk(session, base, cap)
    return { oids: rows, error: null }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    return { oids: [], error: msg.slice(0, 200) }
  }
}

/* ---------------- Lettura ARP completa ---------------- */

/**
 * Legge la tabella ARP di UN apparato (gateway/router/switch L3) con la
 * sessione del chiamante. Merge: ipNetToPhysical (moderna) vince,
 * ipNetToMedia (legacy) riempie le coppie IP mancanti.
 */
export async function snmpArpRead(session: Session): Promise<SnmpArpResult> {
  const warnings: string[] = []
  const byIp = new Map<string, ArpRow>()
  let truncated = false

  /* --- (1) ipNetToPhysicalTable (RFC 4293): indice ifIndex.type.addr --- */
  const physChunk = await safeWalk(session, ARP_OIDS.ipNetToPhysicalPhysAddress, CAP_ARP)
  if (!physChunk.error && physChunk.oids.length > 0) {
    if (physChunk.oids.length >= CAP_ARP) truncated = true
    // cache dei tipi (stesso indice della PhysAddress)
    const typeChunk = await safeWalk(session, ARP_OIDS.ipNetToPhysicalType, CAP_ARP)
    const typeByKey = new Map<string, number>()
    for (const { oid, value } of typeChunk.oids) {
      const arcs = suffixArcs(ARP_OIDS.ipNetToPhysicalType, oid)
      typeByKey.set(arcs.join('.'), asInt(value) ?? 0)
    }
    for (const { oid, value } of physChunk.oids) {
      const arcs = suffixArcs(ARP_OIDS.ipNetToPhysicalPhysAddress, oid)
      // indice: ifIndex, addressType, address… (4 o 16 ottetti)
      if (arcs.length < 6) continue
      const ifIndex = arcs[0]
      const addrType = arcs[1]
      const addrArcs = arcs.slice(2)
      let ip = ''
      if (addrType === 1 && addrArcs.length === 4) {
        ip = addrArcs.join('.')
      } else if (addrType === 2 && addrArcs.length === 16) {
        ip = ipv6FromBuffer(Buffer.from(addrArcs))
      } else {
        continue // tipo indirizzo non IPv4/IPv6: scartato
      }
      const mac = macFromBuffer(asBuffer(value))
      if (!mac || !ip) continue
      const t = TYPE_BY_NUM[typeByKey.get(arcs.join('.')) ?? 0] ?? 'other'
      if (typeByKey.get(arcs.join('.')) === 2) continue // invalid: voce morente
      byIp.set(ip, { ip, mac, ifIndex, type: t })
    }
  } else if (physChunk.error) {
    warnings.push(`ipNetToPhysical non leggibile (${physChunk.error})`)
  }

  /* --- (2) ipNetToMediaTable (legacy IPv4): indice ifIndex.ip --- */
  const legacyChunk = await safeWalk(session, ARP_OIDS.ipNetToMediaPhysAddress, CAP_ARP)
  if (!legacyChunk.error && legacyChunk.oids.length > 0) {
    if (legacyChunk.oids.length >= CAP_ARP) truncated = true
    const typeChunk = await safeWalk(session, ARP_OIDS.ipNetToMediaType, CAP_ARP)
    const typeByKey = new Map<string, number>()
    for (const { oid, value } of typeChunk.oids) {
      const arcs = suffixArcs(ARP_OIDS.ipNetToMediaType, oid)
      typeByKey.set(arcs.join('.'), asInt(value) ?? 0)
    }
    for (const { oid, value } of legacyChunk.oids) {
      const arcs = suffixArcs(ARP_OIDS.ipNetToMediaPhysAddress, oid)
      if (arcs.length !== 5) continue // ifIndex + 4 ottetti IPv4
      const ifIndex = arcs[0]
      const ip = arcs.slice(1).join('.')
      if (!isIPv4Text(ip) || byIp.has(ip)) continue // la moderna vince
      const mac = macFromBuffer(asBuffer(value))
      if (!mac) continue
      const t = TYPE_BY_NUM[typeByKey.get(arcs.join('.')) ?? 0] ?? 'other'
      if (typeByKey.get(arcs.join('.')) === 2) continue // invalid
      byIp.set(ip, { ip, mac, ifIndex, type: t })
    }
  } else if (legacyChunk.error && byIp.size === 0) {
    warnings.push(`ipNetToMedia non leggibile (${legacyChunk.error}) — tabella ARP assente`)
  }

  if (truncated) warnings.push(`tabella ARP troncata a ${CAP_ARP} voci`)
  if (byIp.size === 0 && warnings.length === 0) {
    warnings.push('tabella ARP vuota (nessun vicino appreso)')
  }

  return { rows: [...byIp.values()], warnings }
}
