/* ================================================================
 * discovery-service/lib/snmp.ts — sonda SNMP v1/v2c/v3
 * ================================================================
 * v16.8 (ondata miglioramenti) — EVOLUZIONE della sonda Task 25:
 *   · PRIMITIVE ESPOSTE (openSession/sessionGet/sessionWalk): il nuovo
 *     modulo lib/snmp-l2.ts (LLDP/CDP/BRIDGE-MIB) riusa le stesse
 *     primitive invece di duplicarle;
 *   · MULTI-COMMUNITY: `communities: string[]` tenta le community in
 *     ordine (un agente che non riconosce la community scarta il
 *     pacchetto in silenzio — provare la successiva è l'unica strada);
 *     il risultato dichiara QUALE ha risposto (`matched`);
 *   · FALLBACK v2c → v1: un agente v1 che riceve una GetRequest v2c
 *     risponde con errore di versione → si riprova in v1 (onesto:
 *     tentativo reale, non dato inventato);
 *   · RETRIES configurabili (default 0 come prima: UDP loss tollerato
 *     dai walk L2 con retries:1);
 *   · SNMPv3: SHA-2 (sha224/256/384/512) e AES-192/256 passati al
 *     net-snmp moderno (md5/sha/aes/des restano accettati);
 *   · ENTERPRISE_OID_VENDOR: +16 voci IANA verificate (3Com, Apple,
 *     Arista, H3C 25506/2013, Brocade/Foundry, Accton OEM, Ericsson,
 *     Siemens, MGE UPS, Synology, VMware ESXi, NetApp, net-snmp/UCD
 *     2021+8072 — l'agente Linux standard!);
 *   · guessProductIdentity: estrazione modello/OS/versione dal
 *     sysDescr (IOS, NX-OS, ASA, RouterOS, SwOS, AirOS/ePMP, FortiOS,
 *     VRP, Comware, Linux kernel, Windows, Synology DSM, APC UPS).
 *
 * Lettura in UNA get multi-varbind: sysDescr.0, sysObjectID.0, sysName.0,
 * sysLocation.0, sysContact.0, sysUpTime.0 (+ ifPhysAddress.1 opzionale
 * per il probe combinato) e ifCount da walk breve di ifDescr (max 64).
 *
 * REGOLA D'ORO: timeout/error SNMP = {reachable:false, error:'timeout'|
 * 'error', detail} — MAI eccezione non gestita, MAI dati inventati.
 * ================================================================ */

import snmp from 'net-snmp'

/* ---------------- OID standard (MIB-II system + interfaces) ---------------- */

const SYS_OIDS = {
  sysDescr: '1.3.6.1.2.1.1.1.0',
  sysObjectID: '1.3.6.1.2.1.1.2.0',
  sysUpTime: '1.3.6.1.2.1.1.3.0',
  sysContact: '1.3.6.1.2.1.1.4.0',
  sysName: '1.3.6.1.2.1.1.5.0',
  sysLocation: '1.3.6.1.2.1.1.6.0',
  ifDescr: '1.3.6.1.2.1.2.2.1.2',
  ifPhysAddress1: '1.3.6.1.2.1.2.2.1.6.1', // MAC della prima interfaccia (probe combinato)
} as const

/* ---------------- Mappa enterprise OID → vendor (v15 + v16.8) ---------------- */

/** Prefissi enterprise verificati sul registro IANA ufficiale.
 *  v16.8: +16 voci (3Com, Apple, Ericsson, Accton, MGE, Brocade,
 *  Foundry, UCD/net-snmp, Siemens, VMware, NetApp, H3C ×2, Arista,
 *  Synology). 2021/8072 identificano l'agente net-snmp standard dei
 *  server Linux — segnale fortissimo di host gestito. */
export const ENTERPRISE_OID_VENDOR: ReadonlyArray<{ prefix: string; vendor: string; note?: string }> = [
  // --- radio / WISP ---
  { prefix: '1.3.6.1.4.1.14988', vendor: 'MikroTik' },
  { prefix: '1.3.6.1.4.1.41112', vendor: 'Ubiquiti' },
  { prefix: '1.3.6.1.4.1.17713', vendor: 'Cambium', note: 'ePMP/PMP' },
  { prefix: '1.3.6.1.4.1.161', vendor: 'Motorola (legacy)', note: 'Canopy/PMP storici — NON cnMatrix' },
  { prefix: '1.3.6.1.4.1.1301', vendor: 'Telrad' },
  { prefix: '1.3.6.1.4.1.25053', vendor: 'Ruckus', note: 'Ruckus Wireless (IANA 25053)' },
  { prefix: '1.3.6.1.4.1.2356', vendor: 'LANCOM', note: 'LANCOM Systems (IANA 2356)' },
  { prefix: '1.3.6.1.4.1.42397', vendor: 'Grandstream', note: 'Grandstream Networks (IANA 42397)' },
  { prefix: '1.3.6.1.4.1.48690', vendor: 'Teltonika', note: 'Teltonika (IANA 48690)' },
  { prefix: '1.3.6.1.4.1.39660', vendor: 'Tarana' },
  { prefix: '1.3.6.1.4.1.47307', vendor: 'IgniteNet' },
  { prefix: '1.3.6.1.4.1.32750', vendor: 'LigoWave' },
  { prefix: '1.3.6.1.4.1.3942', vendor: 'InfiNet' },
  { prefix: '1.3.6.1.4.1.43356', vendor: 'Mimosa', note: 'ora Airspan' },
  { prefix: '1.3.6.1.4.1.12394', vendor: 'Alvarion' },
  { prefix: '1.3.6.1.4.1.10728', vendor: 'Redline' },
  { prefix: '1.3.6.1.4.1.3373', vendor: 'SIAE', note: 'ALFO/microonde — vendor italiano' },
  { prefix: '1.3.6.1.4.1.2509', vendor: 'Aviat' },
  { prefix: '1.3.6.1.4.1.46242', vendor: 'Netonix' },
  // --- switch / router / core ---
  { prefix: '1.3.6.1.4.1.9', vendor: 'Cisco' },
  { prefix: '1.3.6.1.4.1.2011', vendor: 'Huawei' },
  { prefix: '1.3.6.1.4.1.25506', vendor: 'H3C', note: 'New H3C (IANA 25506)' },
  { prefix: '1.3.6.1.4.1.2013', vendor: 'H3C (legacy)', note: 'Huawei-3Com JV storica' },
  { prefix: '1.3.6.1.4.1.43', vendor: '3Com (legacy)', note: 'Core/switch storici, ancora diffusi' },
  { prefix: '1.3.6.1.4.1.30065', vendor: 'Arista', note: 'Arista Networks (IANA 30065)' },
  { prefix: '1.3.6.1.4.1.1588', vendor: 'Brocade', note: 'FC switch / Ruckus ICX' },
  { prefix: '1.3.6.1.4.1.1991', vendor: 'Foundry (legacy)', note: 'IronWare pre-Brocade' },
  { prefix: '1.3.6.1.4.1.259', vendor: 'Accton (OEM)', note: 'Edge-Core e rebadge vari' },
  { prefix: '1.3.6.1.4.1.11863', vendor: 'TP-Link' },
  { prefix: '1.3.6.1.4.1.890', vendor: 'Zyxel' },
  { prefix: '1.3.6.1.4.1.171', vendor: 'D-Link' },
  { prefix: '1.3.6.1.4.1.4526', vendor: 'Netgear' },
  { prefix: '1.3.6.1.4.1.2636', vendor: 'Juniper' },
  { prefix: '1.3.6.1.4.1.1916', vendor: 'Extreme' },
  { prefix: '1.3.6.1.4.1.14823', vendor: 'Aruba', note: 'HPE Aruba Networking' },
  { prefix: '1.3.6.1.4.1.11', vendor: 'HP', note: 'Hewlett-Packard / ProCurve legacy' },
  { prefix: '1.3.6.1.4.1.207', vendor: 'Allied Telesis' },
  { prefix: '1.3.6.1.4.1.6486', vendor: 'Alcatel-Lucent Enterprise' },
  { prefix: '1.3.6.1.4.1.10456', vendor: 'Planet' },
  { prefix: '1.3.6.1.4.1.164', vendor: 'RAD' },
  { prefix: '1.3.6.1.4.1.674', vendor: 'Dell', note: 'PowerConnect' },
  { prefix: '1.3.6.1.4.1.3955', vendor: 'Linksys' },
  { prefix: '1.3.6.1.4.1.94', vendor: 'Nokia' },
  { prefix: '1.3.6.1.4.1.3902', vendor: 'ZTE' },
  { prefix: '1.3.6.1.4.1.11408', vendor: 'FiberHome' },
  // --- server / storage / virtualizzazione (v16.8) ---
  { prefix: '1.3.6.1.4.1.2021', vendor: 'net-snmp (Linux)', note: 'agente UCD/snmpd standard dei server Linux' },
  { prefix: '1.3.6.1.4.1.8072', vendor: 'net-snmp', note: 'agente net-snmp (sourceforge)' },
  { prefix: '1.3.6.1.4.1.6876', vendor: 'VMware', note: 'host ESXi' },
  { prefix: '1.3.6.1.4.1.789', vendor: 'NetApp', note: 'storage ONTAP' },
  { prefix: '1.3.6.1.4.1.65201', vendor: 'Synology', note: 'NAS DSM' },
  { prefix: '1.3.6.1.4.1.4329', vendor: 'Siemens' },
  { prefix: '1.3.6.1.4.1.193', vendor: 'Ericsson' },
  { prefix: '1.3.6.1.4.1.63', vendor: 'Apple', note: 'AirPort/Time Capsule' },
  // --- camere / VMS ---
  { prefix: '1.3.6.1.4.1.39165', vendor: 'Hikvision' },
  { prefix: '1.3.6.1.4.1.37496', vendor: 'Dahua' },
  { prefix: '1.3.6.1.4.1.368', vendor: 'Axis' },
  { prefix: '1.3.6.1.4.1.39747', vendor: 'Uniview' },
  { prefix: '1.3.6.1.4.1.36849', vendor: 'Hanwha Vision', note: 'ex Hanwha Techwin' },
  { prefix: '1.3.6.1.4.1.3967', vendor: 'Bosch' },
  { prefix: '1.3.6.1.4.1.23465', vendor: 'Vivotek' },
  { prefix: '1.3.6.1.4.1.60913', vendor: 'Tiandy' },
  { prefix: '1.3.6.1.4.1.46202', vendor: 'Avigilon' },
  // --- firewall / UPS ---
  { prefix: '1.3.6.1.4.1.12356', vendor: 'Fortinet' },
  { prefix: '1.3.6.1.4.1.2620', vendor: 'Check Point' },
  { prefix: '1.3.6.1.4.1.8741', vendor: 'SonicWall' },
  { prefix: '1.3.6.1.4.1.25461', vendor: 'Palo Alto' },
  { prefix: '1.3.6.1.4.1.318', vendor: 'APC', note: 'UPS Schneider' },
  { prefix: '1.3.6.1.4.1.534', vendor: 'Eaton', note: 'UPS Powerware' },
  { prefix: '1.3.6.1.4.1.705', vendor: 'MGE UPS', note: 'MGE UPS Systems (ora Eaton)' },
  { prefix: '1.3.6.1.4.1.476', vendor: 'Vertiv', note: 'ex Emerson/Liebert' },
]

/** Estrae la parte enterprise da un sysObjectID e risolve il vendor. */
export function parseSysObjectID(oid: string): { enterprise: number | null; vendor: string | null; note?: string } {
  const clean = (oid || '').trim().replace(/^\./, '')
  if (!clean || !/^(\d+\.)*\d+$/.test(clean)) return { enterprise: null, vendor: null }
  const m = clean.match(/^1\.3\.6\.1\.4\.1\.(\d+)(?:\.|$)/)
  if (!m) return { enterprise: null, vendor: null }
  const enterprise = Number(m[1])
  for (const entry of ENTERPRISE_OID_VENDOR) {
    if (clean === entry.prefix || clean.startsWith(entry.prefix + '.')) {
      return { enterprise, vendor: entry.vendor, note: entry.note }
    }
  }
  return { enterprise, vendor: null }
}

/** Fallback vendor da sysDescr con regex (firme vendor, v16.8 allargate). */
export function sysDescrVendorGuess(sysDescr: string): string | null {
  const t = (sysDescr || '').toLowerCase()
  if (!t) return null
  if (/(ubiquiti|airos|airmax|airfiber|unifi|nanobeam|litebeam|powerbeam|nanostation|rocket ?m|aircube|edgeswitch|edgeos|edgerouter|ubnt|amplifi)/.test(t)) return 'Ubiquiti'
  if (/(mikrotik|routeros|router ?os|swos|winbox|routerboard|mikrotikls)/.test(t)) return 'MikroTik'
  if (/(cambium|epmp|cnmaestro|cnmatrix|canopy|pmp ?450|cnpulse|cnreach)/.test(t)) return 'Cambium'
  if (/hikvision/.test(t)) return 'Hikvision'
  if (/(dahua|imou)/.test(t)) return 'Dahua'
  if (/(tp-?link|omada|archer)/.test(t)) return 'TP-Link'
  if (/(cisco|catalyst|nexus operating|adaptive security appliance)/.test(t)) return 'Cisco'
  if (/axis/.test(t)) return 'Axis'
  if (/\bhuawei\b|versatile routing platform|\bvrp\b/.test(t)) return 'Huawei'
  if (/(zyxel|gs1900|xs1930)/.test(t)) return 'Zyxel'
  if (/(d-?link)/.test(t)) return 'D-Link'
  if (/netgear|prosafe/.test(t)) return 'Netgear'
  if (/(aruba|procurve|instant on)/.test(t)) return 'Aruba'
  if (/(juniper|junos)/.test(t)) return 'Juniper'
  if (/(allied telesis|alliedware)/.test(t)) return 'Allied Telesis'
  if (/(fortinet|fortigate|fortios)/.test(t)) return 'Fortinet'
  if (/(sonicwall)/.test(t)) return 'SonicWall'
  if (/(palo alto|pan-?os)/.test(t)) return 'Palo Alto'
  if (/(check point|gaia)/.test(t)) return 'Check Point'
  if (/(uniview)/.test(t)) return 'Uniview'
  if (/(hanwha|techwin)/.test(t)) return 'Hanwha Vision'
  if (/(bosch)/.test(t)) return 'Bosch'
  if (/(vivotek)/.test(t)) return 'Vivotek'
  if (/(tiandy)/.test(t)) return 'Tiandy'
  if (/(ruckus|zoneflex|smartzone|unleashed)/.test(t)) return 'Ruckus'
  if (/(teltonika|rut9|rut2|rutx)/.test(t)) return 'Teltonika'
  if (/(lancom)/.test(t)) return 'LANCOM'
  if (/(grandstream)/.test(t)) return 'Grandstream'
  if (/(telrad)/.test(t)) return 'Telrad'
  if (/(ligowave)/.test(t)) return 'LigoWave'
  if (/(infinet)/.test(t)) return 'InfiNet'
  if (/(mimosa)/.test(t)) return 'Mimosa'
  if (/(tarana)/.test(t)) return 'Tarana'
  // --- v16.8: apparati infrastrutturali comuni ---
  if (/(synology|diskstation|\bdsm\b)/.test(t)) return 'Synology'
  if (/(qnap)/.test(t)) return 'QNAP'
  if (/vmware|esxi/.test(t)) return 'VMware'
  if (/(netapp|ontap)/.test(t)) return 'NetApp'
  if (/(net-?snmp|ucd-snmp|linux )/.test(t)) return 'net-snmp (Linux)'
  if (/windows (version|nt)/.test(t)) return 'Microsoft Windows'
  if (/(arista)/.test(t)) return 'Arista'
  if (/(comware|\bh3c\b)/.test(t)) return 'H3C'
  if (/(vyatta|vyos)/.test(t)) return 'VyOS'
  if (/(openwrt|lede)/.test(t)) return 'OpenWrt'
  if (/(opnsense|pfense|pfsense)/.test(t)) return 'pfSense/OPNsense'
  if (/(hp |hewlett-packard) ?ethernet multi-environment|jetdirect|laserjet|pagewide/.test(t)) return 'HP'
  if (/(brocade|foundry|ironware)/.test(t)) return 'Brocade'
  if (/(aruba|raritan|apc web|smart-ups|matrix-ups|powernet)/.test(t)) return 'APC'
  if (/(eaton|mge) ?ups/.test(t)) return 'Eaton'
  if (/(siemens|hipath)/.test(t)) return 'Siemens'
  return null
}

/* ---------------- Estrazione prodotto/OS dal sysDescr (v16.8) ---------------- */

export interface ProductIdentity {
  /** Famiglia OS/firmware letta DALLA STRINGA REALE (mai dedotta a vuoto). */
  osFamily: string | null
  osVersion: string | null
  /** Modello dichiarato nel sysDescr (es. C2960, RB4011, ePMP 3000). */
  model: string | null
  /** Note oneste su cosa ha prodotto l'estrazione. */
  source: 'sysdescr'
}

/** Estrae modello e OS/versione dal sysDescr con regex per famiglia.
 *  Ogni ramo nasce da stringhe REALI di sysDescr osservate sul campo:
 *  Cisco IOS/NX-OS/ASA, RouterOS/SwOS, AirOS/ePMP, FortiOS, VRP,
 *  Comware, Linux, Windows, Synology DSM, APC NMC. */
export function guessProductIdentity(sysDescr: string): ProductIdentity {
  const s = sysDescr || ''
  const t = s.toLowerCase()
  const out: ProductIdentity = { osFamily: null, osVersion: null, model: null, source: 'sysdescr' }
  if (!t) return out

  // Cisco IOS: "Cisco IOS Software, C2960 Software (C2960-LANBASEK9-M), Version 12.2(55)SE5"
  let m = s.match(/Cisco IOS Software,?\s+(?:\w+\s+Software\s+)?\(?([A-Z0-9][A-Z0-9-]{2,})\)?[^,]*,\s*Version\s+([\w.()]+)/)
  if (m) { out.osFamily = 'Cisco IOS'; out.osVersion = m[2]; out.model = m[1].replace(/-.*$/, ''); return out }
  // Cisco IOS vecchio: "IOS (tm) C2960 Software (C2960-...), Version 12.2(25)SEE"
  m = s.match(/IOS \(tm\) (\w+) Software[^,]*,\s*Version\s+([\w.()]+)/)
  if (m) { out.osFamily = 'Cisco IOS'; out.osVersion = m[2]; out.model = m[1]; return out }
  // Cisco NX-OS
  m = s.match(/Nexus Operating System \(NX-OS\)[^V]*Version\s+([\w.()]+)/)
  if (m) { out.osFamily = 'Cisco NX-OS'; out.osVersion = m[1]; out.model = s.match(/Nexus\s*(\w+[\w-]*)/i)?.[1] ?? null; return out }
  // Cisco ASA / FTD
  m = s.match(/Adaptive Security Appliance\s*Version\s+([\w.()]+)/)
  if (m) { out.osFamily = 'Cisco ASA'; out.osVersion = m[1]; return out }
  // Cisco SG small business
  m = s.match(/Cisco (?:Small Business |SG )?(\w+[\w-]*)[ ,].*Version\s+([\w.()]+)/)
  if (m && /cisco/.test(t)) { out.osFamily = 'Cisco'; out.osVersion = m[2]; out.model = m[1]; return out }

  // MikroTik RouterOS: "router - RBNOS 6.49.16 (long-term)" / "RouterOS 6.48.3"
  // / "RouterOS 7.15.2 (stable) CRS317-1G-16S+" (board DOPO la versione)
  m = s.match(/(?:RouterOS|router - \w*OS)\s+([\d][\w.-]*)/i)
  if (m) {
    out.osFamily = 'RouterOS'
    out.osVersion = m[1]
    out.model = s.match(/(?:RouterOS|router - \w*OS)\s+[\d][\w.-]*\s*(?:\([^)]*\)\s*)?((?:CRS|CSS|RB|CCR|hEX|hAP|Chateau|L009|LDF|SXT|LHG|cAP|wAP|QRT|DISC|mANT|OmniTIK|AF|aud)[\w-]*)/i)?.[1] ?? null
    return out
  }
  // MikroTik SwOS
  m = s.match(/SwOS\s+([\d][\w.-]*)/i)
  if (m) { out.osFamily = 'SwOS'; out.osVersion = m[1]; return out }

  // Cambium ePMP: "ePMP ..." con versione tipo "ePMP 3000" o "CAMBIUM-ePMP-..."
  m = s.match(/(?:ePMP|PMP)\s?(\d{3,4}\w*)/)
  if (m) { out.osFamily = 'ePMP'; out.model = `ePMP ${m[1]}`; out.osVersion = s.match(/v?(\d+\.\d+\.\d+[\w-]*)/i)?.[1] ?? null; return out }

  // FortiOS: "Fortigate-100D v6.2.7"
  m = s.match(/Forti(?:Gate|WiFi|AP)(-?\w*)\s+v([\d.]+)/i)
  if (m) { out.osFamily = 'FortiOS'; out.model = `FortiGate${m[1]}`.replace(/^-/, ''); out.osVersion = m[2]; return out }

  // Huawei VRP: "... V200R010C00SPC600 ..."
  m = s.match(/\b(V\d{3}R\d{3}C\d{3}(?:SPC\d+)?)/)
  if (m) { out.osFamily = 'Huawei VRP'; out.osVersion = m[1]; out.model = s.match(/\b(S\d{4}[\w-]*|AR\d{3}[\w-]*|USG\d{3,4}[\w-]*)/i)?.[1] ?? null; return out }

  // HPE Comware
  if (/comware/i.test(s)) {
    out.osFamily = 'Comware'
    out.osVersion = s.match(/Version\s+([\w.]+)/i)?.[1] ?? null
    out.model = s.match(/\b(HP )?(?:A)?(\w{2,3}\d{3,4}[\w-]*)/i)?.[2] ?? null
    return out
  }

  // APC NMC: "APC Web/SNMP Management Card (MB v3.8.5 ...)"
  m = s.match(/APC Web\/SNMP Management Card\s*\((?:MB|93 )?v?([\d.]+)/i)
  if (m) { out.osFamily = 'APC NMC'; out.osVersion = m[1]; out.model = s.match(/Smart-UPS\s*(\w+)/i)?.[1] ?? null; return out }

  // Synology DSM
  m = s.match(/DSM\s+([\d.]+)/i)
  if (m && /synology|diskstation/i.test(s)) { out.osFamily = 'Synology DSM'; out.osVersion = m[1]; out.model = s.match(/(DS\d{3,4}[+\w]*)/i)?.[1] ?? null; return out }

  // Windows: "Software: Windows Version 6.3 (Build 9600)"
  m = s.match(/Windows Version\s+([\d.]+)\s*\(Build\s+(\d+)\)/)
  if (m) { out.osFamily = 'Windows'; out.osVersion = `${m[1]} build ${m[2]}`; return out }

  // Linux/net-snmp: "Linux hostname 5.15.0-91-generic ..."
  m = s.match(/Linux\s+(\S+)\s+(\d+\.\d+[\w.-]*)/)
  if (m) { out.osFamily = 'Linux'; out.osVersion = m[2]; return out }
  // agente net-snmp generico
  if (/net-snmp|ucd-snmp/i.test(s)) { out.osFamily = 'net-snmp'; out.osVersion = s.match(/(?:V|v)ersion\s+([\d.]+)/)?.[1] ?? null; return out }

  // OpenWrt / VyOS / pfSense
  if (/openwrt|lede/i.test(s)) { out.osFamily = 'OpenWrt'; out.osVersion = s.match(/(?:OpenWrt|LEDE)\s+([\w.-]+)/i)?.[1] ?? null; return out }
  if (/vyatta|vyos/i.test(s)) { out.osFamily = 'VyOS/EdgeOS'; out.osVersion = s.match(/(?:VyOS|EdgeOS)?\s*v?([\d.]+[\w-]*)/i)?.[1] ?? null; return out }
  if (/pfsense|opnsense/i.test(s)) { out.osFamily = /opnsense/i.test(s) ? 'OPNsense' : 'pfSense'; out.osVersion = s.match(/([\d.]+[a-z]?)/i)?.[1] ?? null; return out }

  // Ubiquiti AirOS: " ... v6.3.1" su sysDescr con firma airos/ubnt
  if (/airos|ubiquiti|airmax|unifi/i.test(s)) {
    out.osFamily = /unifi/i.test(s) ? 'UniFi' : 'AirOS'
    out.osVersion = s.match(/\bv?(\d+\.\d+\.\d+[\w-]*)/i)?.[1] ?? null
    out.model = s.match(/(NanoStation\s*\w+|NanoBeam\s*\w+|LiteBeam\s*\w+|PowerBeam\s*\w+|Rocket\s*\w+|airFiber\s*\w+|EdgeSwitch\s*[\w-]+|EdgeRouter\s*[\w-]+|UniFi\s*[\w-]+)/i)?.[1] ?? null
    return out
  }
  return out
}

/* ---------------- Opzioni e risultato della sonda ---------------- */

export type SnmpAuthProtocol = 'md5' | 'sha' | 'sha224' | 'sha256' | 'sha384' | 'sha512'
export type SnmpPrivProtocol = 'des' | 'aes' | 'aes192' | 'aes256'

export interface SnmpV3Options {
  level: 'noAuthNoPriv' | 'authNoPriv' | 'authPriv'
  user: string
  authProtocol?: SnmpAuthProtocol
  authKey?: string
  privProtocol?: SnmpPrivProtocol
  privKey?: string
}

export interface SnmpProbeOptions {
  ip: string
  port?: number
  version?: 'v1' | 'v2c' | 'v3'
  community?: string
  /** v16.8: lista di community da tentare IN ORDINE (default: [community
   *  ?? 'public']). Un agente con community errata scarta il pacchetto:
   *  l'unico modo onesto di scoprire quella giusta è provare. */
  communities?: string[]
  /** v16.8: se true (default) un fallimento v2c con ERRORE (non timeout)
   *  provoca UN tentativo v1 con la stessa community. */
  tryV1Fallback?: boolean
  timeoutMs?: number
  /** Ritrasmissioni UDP per get/walk (default 0 — invariato rispetto a v15). */
  retries?: number
  v3?: SnmpV3Options
  /** true nel probe combinato /probe/vendor: aggiunge ifPhysAddress.1
   *  alla get multi-varbind per imparare il MAC (se presente). */
  includeIfPhysAddress?: boolean
}

export interface SnmpProbeResult {
  reachable: boolean
  sysDescr: string | null
  sysObjectID: string | null
  sysName: string | null
  sysLocation: string | null
  sysContact: string | null
  uptimeTicks: number | null
  /** Numero interfacce dal walk di ifDescr (max 64); null se walk fallito. */
  ifCount: number | null
  vendorGuess: { vendor: string; source: 'enterprise-oid' | 'sysdescr' } | null
  /** MAC della prima interfaccia (solo con includeIfPhysAddress). */
  mac: string | null
  /** v16.8: identità prodotto estratta dal sysDescr (os/modello/versione). */
  product: ProductIdentity | null
  /** v16.8: quale combinazione community+versione ha risposto. */
  matched: { community: string; version: 'v1' | 'v2c' | 'v3' } | null
  /** Presenti SOLO quando reachable=false (timeout o errore, onesti). */
  error?: 'timeout' | 'error'
  detail?: string
}

/* ---------------- Primitive net-snmp (esportate per snmp-l2.ts) ---------------- */

export type Varbind = { oid: string; type: number; value: unknown }
export type Session = {
  get: (oids: string[], cb: (err: Error | null, varbinds?: Varbind[]) => void) => void
  subtree: (
    oid: string,
    maxRows: number,
    feed: (varbinds: Varbind[]) => void,
    done: (err: Error | null) => void,
  ) => void
  close: () => void
}

/** TRUE se il varbind contiene un errore di protocollo (NoSuchInstance…). */
function isVarbindError(vb: Varbind): boolean {
  try {
    return Boolean((snmp as unknown as { isVarbindError: (vb: unknown) => boolean }).isVarbindError(vb))
  } catch {
    return false
  }
}

/** Get multi-varbind → mappa oid→varbind (i varbind in errore restano
 *  assenti: campo null, nessun dato inventato). */
export function sessionGet(session: Session, oids: string[]): Promise<Map<string, Varbind>> {
  return new Promise((resolve, reject) => {
    session.get(oids, (err, varbinds) => {
      if (err) {
        reject(err)
        return
      }
      const map = new Map<string, Varbind>()
      for (const vb of varbinds ?? []) {
        if (!vb || isVarbindError(vb)) continue
        map.set(vb.oid, vb)
      }
      resolve(map)
    })
  })
}

/** Walk breve (subtree, max `maxRows` righe) → righe {oid, value}. */
export function sessionWalk(
  session: Session,
  oid: string,
  maxRows: number,
): Promise<Array<{ oid: string; value: unknown }>> {
  return new Promise((resolve, reject) => {
    const rows: Array<{ oid: string; value: unknown }> = []
    const feed = (varbinds: Varbind[]) => {
      for (const vb of varbinds) {
        if (!vb || isVarbindError(vb)) continue
        rows.push({ oid: vb.oid, value: vb.value })
      }
    }
    session.subtree(oid, maxRows, feed, (err) => {
      if (err) reject(err)
      else resolve(rows)
    })
  })
}

/** Valore varbind → testo tollerante (stringa/numero/Buffer). */
export function varbindText(vb: Varbind | undefined): string | null {
  if (!vb) return null
  const v = vb.value
  if (v === null || v === undefined) return null
  if (Buffer.isBuffer(v)) return v.toString('utf8').trim() || null
  const s = String(v).trim()
  return s === '' ? null : s
}

/** MAC da ifPhysAddress (Buffer di 6 octet, esclude 00:00:…:00). */
function macFromIfPhysAddress(vb: Varbind | undefined): string | null {
  if (!vb) return null
  const v = vb.value
  let hex = ''
  if (Buffer.isBuffer(v)) hex = v.toString('hex')
  else if (typeof v === 'string') hex = v.replace(/[^0-9a-fA-F]/g, '')
  if (hex.length !== 12) return null
  if (/^0{12}$/.test(hex)) return null // interfaccia senza MAC (loopback…)
  return hex.match(/.{2}/g)?.join(':').toUpperCase() ?? null
}

/** Classifica l'errore net-snmp: 'timeout' (nessuna risposta entro il
 *  timeout) oppure 'error' con dettaglio — entrambi onesti. */
export function classifySnmpError(e: unknown): { error: 'timeout' | 'error'; detail: string } {
  const msg = e instanceof Error ? e.message : String(e)
  const timedOut =
    (typeof (snmp as unknown as { RequestTimedOutError?: unknown }).RequestTimedOutError === 'function' &&
      e instanceof (snmp as unknown as { RequestTimedOutError: new (...a: unknown[]) => Error }).RequestTimedOutError) ||
    /timed?\s*out/i.test(msg)
  return { error: timedOut ? 'timeout' : 'error', detail: msg.slice(0, 300) }
}

/* ---------------- Apertura sessione (v1/v2c/v3) ---------------- */

export function openSession(o: SnmpProbeOptions): Session {
  const base = {
    port: o.port ?? 161,
    timeout: o.timeoutMs ?? 2500,
    retries: o.retries ?? 0,
  }
  if (o.version === 'v3') {
    const v3 = o.v3
    const levelName = v3?.level ?? 'noAuthNoPriv'
    const levelMap: Record<string, number> = {
      noAuthNoPriv: 1,
      authNoPriv: 2,
      authPriv: 3,
    }
    // net-snmp moderno accetta le stringhe direttamente (md5/sha/sha224/
    // sha256/sha384/sha512, des/aes/aes192/aes256)
    const user = {
      name: v3?.user ?? '',
      level: levelMap[levelName] ?? 1,
      authProtocol: v3?.authProtocol ?? 'sha',
      authKey: v3?.authKey,
      privProtocol: v3?.privProtocol ?? 'aes',
      privKey: v3?.privKey,
    }
    return (snmp as unknown as {
      createV3Session: (target: string, user: unknown, options: unknown) => Session
    }).createV3Session(o.ip, user, base) as Session
  }
  const version =
    o.version === 'v1'
      ? (snmp as unknown as { Version1: number }).Version1
      : (snmp as unknown as { Version2c: number }).Version2c
  return (snmp as unknown as {
    createSession: (target: string, community: string, options: unknown) => Session
  }).createSession(o.ip, o.community ?? 'public', { ...base, version }) as Session
}

/* ---------------- Sonda SNMP completa ---------------- */

interface AttemptOutcome {
  result: SnmpProbeResult | null // null = NON raggiungibile con questi parametri
  errorKind: 'timeout' | 'error' | null
  detail: string
}

/** UNA get multi-varbind + walk breve ifDescr, SENZA tentativi multipli. */
async function probeOnce(o: SnmpProbeOptions): Promise<AttemptOutcome> {
  let session: Session | null = null
  try {
    session = openSession(o)
  } catch (e) {
    const c = classifySnmpError(e)
    return { result: null, errorKind: c.error, detail: c.detail }
  }
  const close = () => {
    try {
      session?.close()
    } catch {
      /* noop */
    }
  }

  try {
    const oids: string[] = [
      SYS_OIDS.sysDescr,
      SYS_OIDS.sysObjectID,
      SYS_OIDS.sysUpTime,
      SYS_OIDS.sysContact,
      SYS_OIDS.sysName,
      SYS_OIDS.sysLocation,
    ]
    if (o.includeIfPhysAddress) oids.push(SYS_OIDS.ifPhysAddress1)

    const map = await sessionGet(session, oids)

    const sysDescr = varbindText(map.get(SYS_OIDS.sysDescr))
    const sysObjectID = varbindText(map.get(SYS_OIDS.sysObjectID))
    const sysName = varbindText(map.get(SYS_OIDS.sysName))
    const sysLocation = varbindText(map.get(SYS_OIDS.sysLocation))
    const sysContact = varbindText(map.get(SYS_OIDS.sysContact))
    const upRaw = map.get(SYS_OIDS.sysUpTime)?.value
    const uptimeTicks = typeof upRaw === 'number' ? upRaw : upRaw !== undefined && /^\d+$/.test(String(upRaw)) ? Number(String(upRaw)) : null
    const mac = o.includeIfPhysAddress ? macFromIfPhysAddress(map.get(SYS_OIDS.ifPhysAddress1)) : null

    // Agent raggiunto SOLO se almeno un varbind di sistema è tornato:
    // una risposta vuota NON è «reachable» (nessun dato inventato).
    const anyValue = sysDescr !== null || sysObjectID !== null || sysName !== null || sysLocation !== null || sysContact !== null || uptimeTicks !== null
    if (!anyValue) {
      close()
      return { result: null, errorKind: 'error', detail: 'risposta SNMP senza varbind validi' }
    }

    // ifCount: walk breve di ifDescr (max 64 interfacce, limite v15)
    let ifCount: number | null = null
    try {
      const rows = await sessionWalk(session, SYS_OIDS.ifDescr, 64)
      ifCount = rows.length
    } catch {
      ifCount = null // walk fallito: conteggio onestamente assente
    }

    // vendorGuess: enterprise OID (ALTA) → sysDescr regex (MEDIA)
    let vendorGuess: SnmpProbeResult['vendorGuess'] = null
    if (sysObjectID) {
      const p = parseSysObjectID(sysObjectID)
      if (p.vendor) vendorGuess = { vendor: p.vendor, source: 'enterprise-oid' }
    }
    if (!vendorGuess && sysDescr) {
      const g = sysDescrVendorGuess(sysDescr)
      if (g) vendorGuess = { vendor: g, source: 'sysdescr' }
    }

    const product = sysDescr ? guessProductIdentity(sysDescr) : null

    close()
    return {
      result: {
        reachable: true,
        sysDescr,
        sysObjectID,
        sysName,
        sysLocation,
        sysContact,
        uptimeTicks,
        ifCount,
        vendorGuess,
        mac,
        product: product && (product.osFamily || product.model) ? product : null,
        matched: {
          community: o.community ?? 'public',
          version: o.version === 'v3' ? 'v3' : o.version === 'v1' ? 'v1' : 'v2c',
        },
      },
      errorKind: null,
      detail: '',
    }
  } catch (e) {
    close()
    const c = classifySnmpError(e)
    return { result: null, errorKind: c.error, detail: c.detail }
  }
}

/** Sonda SNMP completa con MULTI-COMMUNITY e fallback v2c→v1 (v16.8).
 *  Le community sono tentate IN ORDINE; per ciascuna, un errore di
 *  protocollo (NON timeout) prova anche la versione v1. Il primo
 *  successo vince; se nessuna combinazione risponde, l'esito è l'ultimo
 *  timeout/errore ONESTO. MAI eccezione, MAI dati inventati. */
export async function snmpProbe(o: SnmpProbeOptions): Promise<SnmpProbeResult> {
  const communities = o.communities && o.communities.length > 0 ? o.communities : [o.community ?? 'public']
  // v3 non ha community: un solo tentativo
  if (o.version === 'v3') {
    const one = await probeOnce(o)
    return one.result ?? unreachable({ error: one.errorKind ?? 'error', detail: one.detail })
  }

  let lastErrorKind: 'timeout' | 'error' = 'timeout'
  let lastDetail = 'nessuna risposta SNMP'
  for (const community of communities) {
    const primaryVersion = o.version === 'v1' ? 'v1' : 'v2c'
    const attempt = await probeOnce({ ...o, community, version: primaryVersion })
    if (attempt.result) return attempt.result
    lastErrorKind = attempt.errorKind ?? 'error'
    lastDetail = attempt.detail
    // fallback v1 SOLO su errore di protocollo (versione non capita):
    // un timeout è silenzio — non ha senso riprovare subito la v1.
    if (
      primaryVersion === 'v2c' &&
      o.tryV1Fallback !== false &&
      attempt.errorKind === 'error'
    ) {
      const v1 = await probeOnce({ ...o, community, version: 'v1' })
      if (v1.result) return v1.result
      lastErrorKind = v1.errorKind ?? 'error'
      lastDetail = v1.detail
    }
  }
  return unreachable({ error: lastErrorKind, detail: lastDetail })
}

function unreachable(c: { error: 'timeout' | 'error'; detail: string }): SnmpProbeResult {
  return {
    reachable: false,
    sysDescr: null,
    sysObjectID: null,
    sysName: null,
    sysLocation: null,
    sysContact: null,
    uptimeTicks: null,
    ifCount: null,
    vendorGuess: null,
    mac: null,
    product: null,
    matched: null,
    error: c.error,
    detail: c.detail,
  }
}

/* ---------------- Get singolo OID custom (16.7 W3.5) ---------------- */

export interface OidGetOptions {
  ip: string
  port?: number
  version?: 'v1' | 'v2c' | 'v3'
  community?: string
  oid: string
  timeoutMs?: number
}

export interface OidGetResult {
  reachable: boolean
  /** Valore grezzo del varbind come testo (buffer → hex). */
  rawValue: string | null
  error?: 'timeout' | 'error' | 'noSuchObject' | 'noSuchInstance'
  detail?: string
}

/** Get di UN OID arbitrario (test OID custom): onesto al 100% —
 *  timeout/errore varbind → reachable:false o noSuchObject, MAI
 *  eccezione verso il chiamante. */
export async function snmpGetOid(o: OidGetOptions): Promise<OidGetResult> {
  let session: Session | null = null
  try {
    session = openSession(o)
  } catch (e) {
    const c = classifySnmpError(e)
    return { reachable: false, rawValue: null, error: c.error, detail: c.detail }
  }
  const close = () => {
    try { session?.close() } catch { /* noop */ }
  }
  try {
    const map = await sessionGet(session, [o.oid])
    const vb = map.get(o.oid)
    if (!vb) {
      // varbind d'errore (NoSuchObject/NoSuchInstance) o assente
      return { reachable: true, rawValue: null, error: 'noSuchObject', detail: 'OID non presente su questo agente' }
    }
    const v = vb.value
    let raw: string
    if (Buffer.isBuffer(v)) raw = v.toString('hex')
    else if (typeof v === 'object' && v !== null) raw = JSON.stringify(v)
    else raw = String(v)
    return { reachable: true, rawValue: raw }
  } catch (e) {
    const c = classifySnmpError(e)
    return { reachable: false, rawValue: null, error: c.error, detail: c.detail }
  } finally {
    close()
  }
}
