/* ================================================================
 * discovery-service/lib/onvif.ts — ONVIF: GetDeviceInformation +
 * WS-Discovery (Task 25)
 * ================================================================
 * Portato dal repository v15.16.0, src/lib/vendor-discovery.ts:
 *   · WS-Security UsernameToken PasswordDigest =
 *     Base64(SHA1(nonce_raw + created + password)) — onvifPasswordDigest
 *     + buildOnvifGetDeviceInformation (righe ~474-501 v15, COPIA);
 *   · HTTP con auth automatica Digest/Basic di trasporto (digestRequest,
 *     righe ~124-270 v15, COPIA: 1ª richiesta senza auth, su 401 riprova
 *     con la sfida — alcune camere chiedono ANCHE l'auth HTTP);
 *   · parser della risposta (parseOnvifDeviceInformation, ~511-521 v15);
 *   · WS-Discovery Probe UDP 3702 multicast 239.255.255.250 con
 *     Types=NetworkVideoTransmitter + parsing ProbeMatch/XAddrs/Scopes
 *     (buildOnvifProbe / parseOnvifProbeMatches / parseOnvifScopes /
 *     onvifDiscoverSweep, righe ~408-575 v15, COPIA).
 *
 * Adattamento Task 25: GetDeviceInformation SENZA credenziali manda
 * l'envelope senza header Security (tentativo anonimo onesto); con
 * user/pass manda il UsernameToken digest v15. Fallback porta 8899
 * path /onvif/device_service.
 *
 * REGOLA D'ORO: nessuna risposta ⇒ reachable:false con error/detail,
 * MAI eccezione non gestita, MAI dati inventati.
 * ================================================================ */

import crypto from 'node:crypto'
import http from 'node:http'
import https from 'node:https'
import dgram from 'node:dgram'

/* ------------------ HTTP con Digest/Basic auth (v15, COPIA) ------------------ */

export function md5Hex(s: string): string {
  return crypto.createHash('md5').update(s, 'utf8').digest('hex')
}

/** Calcolo della "response" RFC 2617 (v15 vendor-discovery.ts, COPIA). */
export function computeDigestResponse(
  username: string,
  realm: string,
  password: string,
  method: string,
  uri: string,
  nonce: string,
  nc: string,
  cnonce: string,
  qop: string,
): string {
  const ha1 = md5Hex(`${username}:${realm}:${password}`)
  const ha2 = md5Hex(`${method}:${uri}`)
  if (qop) return md5Hex(`${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}`)
  return md5Hex(`${ha1}:${nonce}:${ha2}`)
}

export interface AuthChallenge {
  scheme: string
  realm?: string
  nonce?: string
  qop?: string
  opaque?: string
  algorithm?: string
  stale?: string
}

/** Parser dell'header WWW-Authenticate (v15, COPIA). */
export function parseWwwAuthChallenge(header: string): AuthChallenge | null {
  if (!header) return null
  const scheme = header.split(/\s+/)[0].toUpperCase()
  const out: AuthChallenge = { scheme }
  const re = /(\w+)\s*=\s*(?:"([^"]*)"|([^\s,]+))/g
  let m: RegExpExecArray | null
  while ((m = re.exec(header)) !== null) {
    const key = m[1].toLowerCase()
    const val = m[2] !== undefined ? m[2] : m[3]
    if (key === 'realm') out.realm = val
    else if (key === 'nonce') out.nonce = val
    else if (key === 'qop') out.qop = val
    else if (key === 'opaque') out.opaque = val
    else if (key === 'algorithm') out.algorithm = val
    else if (key === 'stale') out.stale = val
  }
  return out
}

export function buildDigestAuthorization(
  ch: AuthChallenge,
  username: string,
  password: string,
  method: string,
  uri: string,
): string {
  const nc = '00000001'
  const cnonce = crypto.randomBytes(8).toString('hex')
  const qop = ch.qop ? ch.qop.split(',')[0].trim() : ''
  const response = computeDigestResponse(username, ch.realm || '', password, method, uri, ch.nonce || '', nc, cnonce, qop)
  const parts = [
    `username="${username}"`,
    `realm="${ch.realm || ''}"`,
    `nonce="${ch.nonce || ''}"`,
    `uri="${uri}"`,
    `response="${response}"`,
  ]
  if (ch.algorithm) parts.push(`algorithm="${ch.algorithm}"`)
  if (qop) parts.push(`qop=${qop}`, `nc=${nc}`, `cnonce="${cnonce}"`)
  if (ch.opaque) parts.push(`opaque="${ch.opaque}"`)
  return `Digest ${parts.join(', ')}`
}

interface RawRequestOptions {
  protocol?: 'http' | 'https'
  host: string
  port: number
  path: string
  method?: string
  body?: string
  headers?: Record<string, string>
  timeoutMs?: number
}

interface RawResponse {
  status: number
  headers: http.IncomingHttpHeaders
  body: string
}

/** Richiesta HTTP grezza con timeout (v15 vendor-discovery.ts, COPIA). */
function rawRequest(o: RawRequestOptions): Promise<RawResponse> {
  return new Promise((resolve, reject) => {
    const transport = o.protocol === 'https' ? https : http
    const payload = o.body !== undefined ? Buffer.from(o.body, 'utf8') : undefined
    const req = transport.request(
      {
        host: o.host,
        port: o.port,
        path: o.path,
        method: o.method || 'GET',
        headers: {
          ...(payload ? { 'Content-Length': String(payload.length) } : {}),
          ...(o.headers || {}),
        },
        timeout: o.timeoutMs || 6000,
      },
      (res) => {
        let data = ''
        res.setEncoding('utf8')
        res.on('data', (c: string) => {
          data += c
          if (data.length > 65536) {
            // corpo anomalo: chiudi e restituisci ciò che abbiamo
            try { res.destroy() } catch { /* noop */ }
            resolve({ status: res.statusCode || 0, headers: res.headers, body: data })
          }
        })
        res.on('end', () => resolve({ status: res.statusCode || 0, headers: res.headers, body: data }))
        res.on('error', (e) => reject(e))
      },
    )
    req.on('timeout', () => {
      req.destroy(new Error(`HTTP timeout ${o.timeoutMs}ms`))
    })
    req.on('error', reject)
    if (payload) req.write(payload)
    req.end()
  })
}

export interface DigestRequestOptions extends RawRequestOptions {
  username?: string
  password?: string
}

/** HTTP con autenticazione automatica: 1ª richiesta senza auth; su 401
 *  riprova con Digest (se la sfida lo richiede) o Basic (v15, COPIA). */
export async function digestRequest(o: DigestRequestOptions): Promise<RawResponse> {
  const res1 = await rawRequest(o)
  if (res1.status !== 401 || !o.username) return res1
  const www = (res1.headers['www-authenticate'] as string) || ''
  const ch = parseWwwAuthChallenge(www)
  if (!ch) return res1
  const headers = { ...(o.headers || {}) }
  if (ch.scheme === 'BASIC') {
    headers['Authorization'] = 'Basic ' + Buffer.from(`${o.username}:${o.password || ''}`, 'utf8').toString('base64')
  } else {
    headers['Authorization'] = buildDigestAuthorization(ch, o.username, o.password || '', o.method || 'GET', o.path)
  }
  return rawRequest({ ...o, headers })
}

/* ------------------ WS-Security UsernameToken digest (v15, COPIA) ------------------ */

/** WS-Security PasswordDigest = Base64(SHA1(nonce_raw + created + password)). */
export function onvifPasswordDigest(password: string, nonceRaw: Buffer, created: string): string {
  return crypto
    .createHash('sha1')
    .update(Buffer.concat([nonceRaw, Buffer.from(created, 'utf8'), Buffer.from(password, 'utf8')]))
    .digest('base64')
}

function xmlEsc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

/** Envelope SOAP GetDeviceInformation (v15 righe ~483-501, COPIA).
 *  Adattamento Task 25: senza username NON viene incluso l'header
 *  Security (tentativo anonimo onesto, molte camere rispondono). */
export function buildOnvifGetDeviceInformation(
  username: string | undefined,
  password: string | undefined,
  nonceRaw: Buffer,
  created: string,
): string {
  const securityBlock =
    username !== undefined && username !== ''
      ? `
<Security s:mustUnderstand="1" xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
<UsernameToken>
<Username>${xmlEsc(username)}</Username>
<Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">${onvifPasswordDigest(password || '', nonceRaw, created)}</Password>
<Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">${nonceRaw.toString('base64')}</Nonce>
<Created xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">${created}</Created>
</UsernameToken>
</Security>`
      : ''
  return `<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing">
<s:Header>
<a:Action s:mustUnderstand="1">http://www.onvif.org/ver10/device/wsdl/GetDeviceInformation</a:Action>${securityBlock}
</s:Header>
<s:Body><GetDeviceInformation xmlns="http://www.onvif.org/ver10/device/wsdl"/></s:Body>
</s:Envelope>`
}

/* ------------------ Parser risposta (v15, COPIA) ------------------ */

function xmlTagValue(xml: string, tag: string): string | undefined {
  const m = xml.match(new RegExp(`<(?:[\\w]+:)?${tag}(?:\\s[^>]*)?>([^<]*)<`, 'i'))
  return m && m[1] ? m[1].trim() : undefined
}

export interface OnvifDeviceInfo {
  manufacturer?: string
  model?: string
  firmware?: string
  serial?: string
  hardware?: string
}

/** Parser della risposta GetDeviceInformation (namespace tds/tt con
 *  prefissi variabili) — v15 parseOnvifDeviceInformation, COPIA. */
export function parseOnvifDeviceInformation(xml: string): OnvifDeviceInfo | null {
  if (!/GetDeviceInformationResponse/i.test(xml)) return null
  const manufacturer = xmlTagValue(xml, 'Manufacturer')
  const model = xmlTagValue(xml, 'Model')
  const firmware = xmlTagValue(xml, 'FirmwareVersion')
  const serial = xmlTagValue(xml, 'SerialNumber')
  const hardware = xmlTagValue(xml, 'HardwareId')
  if (!manufacturer && !model && !firmware && !serial) return null
  return { manufacturer, model, firmware, serial, hardware }
}

/* ------------------ GetDeviceInformation con fallback 8899 (Task 25) ------------------ */

export type OnvifProbeOutcome =
  | {
      reachable: true
      manufacturer: string | null
      model: string | null
      firmwareVersion: string | null
      serialNumber: string | null
      hardwareId: string | null
      port: number
    }
  | { reachable: false; error: 'timeout' | 'refused' | 'http' | 'auth' | 'parse'; detail: string }

function classifyHttpError(e: unknown): 'timeout' | 'refused' | 'http' {
  const msg = e instanceof Error ? e.message : String(e)
  if (/timeout/i.test(msg)) return 'timeout'
  if (/ECONNREFUSED|EHOSTUNREACH|ENETUNREACH|ECONNRESET/i.test(msg)) return 'refused'
  return 'http'
}

/** SOAP GetDeviceInformation su /onvif/device_service della porta data;
 *  se non produce informazioni (e la porta non è già 8899) riprova sulla
 *  porta ONVIF alternativa 8899. Nessuna risposta ⇒ reachable:false. */
export async function onvifProbe(
  ip: string,
  port: number,
  username?: string,
  password?: string,
  timeoutMs = 3000,
): Promise<OnvifProbeOutcome> {
  const attempt = async (p: number): Promise<OnvifProbeOutcome> => {
    const nonceRaw = crypto.randomBytes(16)
    const created = new Date().toISOString().replace(/\.\d+Z$/, 'Z')
    const body = buildOnvifGetDeviceInformation(username, password, nonceRaw, created)
    let res: RawResponse
    try {
      res = await digestRequest({
        host: ip,
        port: p,
        path: '/onvif/device_service',
        method: 'POST',
        body,
        username: username || undefined,
        password: password || undefined,
        timeoutMs,
        headers: {
          'Content-Type': 'application/soap+xml; charset=utf-8; action="http://www.onvif.org/ver10/device/wsdl/GetDeviceInformation"',
        },
      })
    } catch (e) {
      const kind = classifyHttpError(e)
      return { reachable: false, error: kind, detail: (e instanceof Error ? e.message : String(e)).slice(0, 200) }
    }
    if (res.status === 401 || res.status === 403) {
      return { reachable: false, error: 'auth', detail: `HTTP ${res.status} (credenziali ONVIF rifiutate)` }
    }
    if (res.status !== 200) {
      return { reachable: false, error: 'http', detail: `HTTP ${res.status} su /onvif/device_service:${p}` }
    }
    const info = parseOnvifDeviceInformation(res.body)
    if (!info) {
      return { reachable: false, error: 'parse', detail: `risposta non GetDeviceInformationResponse (porta ${p})` }
    }
    return {
      reachable: true,
      manufacturer: info.manufacturer ?? null,
      model: info.model ?? null,
      firmwareVersion: info.firmware ?? null,
      serialNumber: info.serial ?? null,
      hardwareId: info.hardware ?? null,
      port: p,
    }
  }

  const first = await attempt(port || 80)
  if (first.reachable) return first
  // fallback porta 8899 (Task 25) — SOLO se diversa dalla già tentata
  if ((port || 80) !== 8899) {
    const second = await attempt(8899)
    if (second.reachable) return second
    // riporta l'esito del tentativo PRINCIPALE (il fallback è best-effort)
    return first
  }
  return first
}

/* ------------------ WS-Discovery Probe (v15, COPIA) ------------------ */

export const ONVIF_MULTICAST = '239.255.255.250'
export const ONVIF_PORT = 3702

export interface OnvifProbeMatch {
  xaddr: string
  types?: string
  scopes?: string
  endpoint?: string
}

/** Envelope WS-Discovery Probe (Types=NetworkVideoTransmitter) — v15, COPIA. */
export function buildOnvifProbe(messageId: string): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://www.w3.org/2003/05/soap-envelope" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:wsd="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:d="http://www.onvif.org/ver10/network/wsdl">
<SOAP-ENV:Header>
<wsa:MessageID>${messageId}</wsa:MessageID>
<wsa:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</wsa:To>
<wsa:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</wsa:Action>
</SOAP-ENV:Header>
<SOAP-ENV:Body><wsd:Probe><d:Types>d:NetworkVideoTransmitter</d:Types></wsd:Probe></SOAP-ENV:Body>
</SOAP-ENV:Envelope>`
}

/** Estrae i ProbeMatch dalla risposta WS-Discovery (v15, COPIA). */
export function parseOnvifProbeMatches(xml: string): OnvifProbeMatch[] {
  const out: OnvifProbeMatch[] = []
  const blocks = xml.match(/<[\w]+:ProbeMatch[\s\S]*?<\/[\w]+:ProbeMatch>/g) || []
  for (const b of blocks) {
    const xaddr = xmlTagValue(b, 'XAddrs')
    if (!xaddr) continue
    out.push({
      xaddr,
      types: xmlTagValue(b, 'Types'),
      scopes: xmlTagValue(b, 'Scopes'),
      endpoint: xmlTagValue(b, 'Address'),
    })
  }
  return out
}

/** Scopes ONVIF ("onvif://www.onvif.org/name/CAM onvif://www.onvif.org/
 *  hardware/MODEL …") — v15 parseOnvifScopes, COPIA. */
export function parseOnvifScopes(scopes: string): { name?: string; hardware?: string; profiles: string[] } {
  const res: { name?: string; hardware?: string; profiles: string[] } = { profiles: [] }
  if (!scopes) return res
  const dec = (s: string) => {
    try {
      return decodeURIComponent(s)
    } catch {
      return s
    }
  }
  for (const token of scopes.split(/\s+/)) {
    try {
      const u = new URL(token)
      if (u.hostname !== 'www.onvif.org') continue
      const parts = u.pathname.split('/').filter(Boolean).map(dec)
      if (parts[0]?.toLowerCase() === 'profile' && parts[1]) res.profiles.push(parts[1])
      else if (parts[0]?.toLowerCase() === 'name' && parts[1]) res.name = parts.slice(1).join('/')
      else if (parts[0]?.toLowerCase() === 'hardware' && parts[1]) res.hardware = parts.slice(1).join('/')
    } catch {
      /* token non URL → skip */
    }
  }
  return res
}

/** WS-Discovery sweep: Probe su multicast+broadcast UDP 3702, raccoglie
 *  i ProbeMatch (v15 onvifDiscoverSweep, COPIA — lista vuota onesta). */
export function onvifDiscoverSweep(timeoutMs = 4000, onProbe?: (m: OnvifProbeMatch) => void): Promise<OnvifProbeMatch[]> {
  return new Promise((resolve) => {
    const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true })
    const found = new Map<string, OnvifProbeMatch>()
    let closed = false
    const finish = () => {
      if (closed) return
      closed = true
      clearTimeout(timer)
      try {
        sock.close()
      } catch {
        /* noop */
      }
      resolve([...found.values()])
    }
    const timer = setTimeout(finish, Math.max(500, timeoutMs))
    sock.on('error', finish)
    sock.on('message', (buf: Buffer) => {
      for (const m of parseOnvifProbeMatches(buf.toString('utf8'))) {
        if (m.xaddr && !found.has(m.xaddr)) {
          found.set(m.xaddr, m)
          if (onProbe) onProbe(m)
        }
      }
    })
    sock.bind(() => {
      const msg = Buffer.from(buildOnvifProbe(`urn:uuid:${crypto.randomUUID()}`))
      sock.setBroadcast(true)
      try {
        sock.setMulticastTTL(4)
      } catch {
        /* noop */
      }
      sock.send(msg, ONVIF_PORT, ONVIF_MULTICAST)
      sock.send(msg, ONVIF_PORT, '255.255.255.255')
    })
  })
}
