/* ================================================================
 * discovery-service/lib/snmp-vlan.ts — INVENTARIO VLAN (v16.15 W13)
 * ================================================================
 * La terza dichiarazione: quali VLAN esistono su questo switch e su
 * quali porte viaggiano (Q-BRIDGE-MIB, RFC 2674, OID verificati sul
 * testo ufficiale del RFC):
 *
 *   · dot1qVlanStaticTable 1.3.6.1.2.1.17.7.1.4.3.1 — per VLAN {dot1qVlanIndex}:
 *        col 1 dot1qVlanStaticName          — nome (stringa, max 32);
 *        col 2 dot1qVlanStaticEgressPorts   — BITMAP ottetti: la porta
 *        bridge N è membra ⇔ bit (7-((N-1)%8)) dell'ottetto (N-1)/8 = 1
 *        (il primo ottetto copre le porte 1..8, LSB = porta 8);
 *        col 5 dot1qVlanStaticRowStatus     — si tengono SOLO active(1).
 *   · dot1qPortVlanTable   1.3.6.1.2.1.17.7.1.4.5.1.1 — dot1qPvid per
 *        porta bridge: la VLAN di ingresso dei frame NON taggati.
 *
 * A COSA SERVE: la FDB VLAN-aware (dot1qTpFdbPort) conta MAC per VLAN;
 * l'inventario dice COME SI CHIAMA quella VLAN e su quali porte vive:
 * il report L2 diventa leggibile per un umano («MAC X visto su VLAN
 * 20 "CAMERE" porta ether4»), e la segmentazione reale dell'impianto
 * smette di essere invisibile.
 *
 * REGOLA D'ORO: walk mancato = avviso (switch non VLAN-aware: valido);
 * VLAN 1 «default» riportata senza vergogna quando dichiarata.
 * ================================================================ */

import {
  sessionWalk,
  type Session,
} from './snmp'

/* ---------------- OID VLAN (Q-BRIDGE-MIB RFC 2674, verificati) ---------------- */

const VLAN_OIDS = {
  dot1qVlanStaticName: '1.3.6.1.2.1.17.7.1.4.3.1.1',
  dot1qVlanStaticEgressPorts: '1.3.6.1.2.1.17.7.1.4.3.1.2',
  dot1qVlanStaticRowStatus: '1.3.6.1.2.1.17.7.1.4.3.1.5',
  dot1qPvid: '1.3.6.1.2.1.17.7.1.4.5.1.1',
} as const

/** Cap onesti: VLAN per switch, porte per PVID. */
const CAP_VLANS = 64
const CAP_PVID_PORTS = 256

/* ---------------- Tipi pubblici ---------------- */

export interface VlanRow {
  vlanId: number
  name: string
  /** Porte bridge egress (bitmap decodificata, ordine crescente). */
  egressPorts: number[]
}

export interface PortVlanRow {
  /** Porta bridge (indice dot1dBasePort). */
  port: number
  /** PVID: VLAN di ingresso dei frame non taggati. */
  pvid: number
}

export interface SnmpVlanResult {
  vlans: VlanRow[]
  portVlans: PortVlanRow[]
  warnings: string[]
}

/* ---------------- Utility ---------------- */

function asInt(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v)
  if (typeof v === 'string' && /^-?\d+$/.test(v)) return Number(v)
  return null
}

function asBuffer(v: unknown): Buffer | null {
  return Buffer.isBuffer(v) ? v : null
}

function asText(v: unknown): string | null {
  if (v === null || v === undefined) return null
  if (Buffer.isBuffer(v)) {
    const s = v.toString('utf8')
    return s.trim() === '' ? null : s.trim()
  }
  const s = String(v).trim()
  return s === '' ? null : s
}

/**
 * Bitmap porte egress → numeri porta bridge crescenti.
 * Ottetto k copre le porte 8k+1..8k+8; la porta 8k+1 è il bit 0x80.
 */
function decodePortBitmap(buf: Buffer | null): number[] {
  if (!buf || buf.length === 0) return []
  const ports: number[] = []
  for (let k = 0; k < buf.length && k * 8 + 8 <= CAP_PVID_PORTS; k++) {
    const byte = buf[k]
    if (byte === 0) continue
    for (let bit = 0; bit < 8; bit++) {
      if (byte & (0x80 >> bit)) ports.push(k * 8 + bit + 1)
    }
  }
  return ports
}

function suffixArcs(base: string, oid: string): number[] {
  if (!oid.startsWith(base + '.')) return []
  return oid.slice(base.length + 1).split('.').map((a) => Number(a))
}

async function safeWalk(
  session: Session,
  base: string,
  cap: number,
): Promise<{ oids: Array<{ oid: string; value: unknown }>; error: string | null }> {
  try {
    const rows = await sessionWalk(session, base, cap)
    return { oids: rows, error: null }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    return { oids: [], error: msg.slice(0, 200) }
  }
}

/* ---------------- Lettura VLAN completa ---------------- */

/**
 * Legge l'inventario VLAN di UN apparato con la sessione del chiamante.
 * Switch non VLAN-aware ⇒ liste vuote con avviso onesto.
 */
export async function snmpVlanRead(session: Session): Promise<SnmpVlanResult> {
  const warnings: string[] = []

  /* --- (1) dot1qVlanStaticTable: nome + egress + rowStatus --- */
  const nameChunk = await safeWalk(session, VLAN_OIDS.dot1qVlanStaticName, CAP_VLANS)
  const vlans: VlanRow[] = []
  if (nameChunk.error) {
    warnings.push(`dot1qVlanStaticTable non leggibile (${nameChunk.error}) — switch non VLAN-aware o MIB non esposta`)
  } else {
    const egressChunk = await safeWalk(session, VLAN_OIDS.dot1qVlanStaticEgressPorts, CAP_VLANS)
    const statusChunk = await safeWalk(session, VLAN_OIDS.dot1qVlanStaticRowStatus, CAP_VLANS)
    const egressByVlan = new Map<number, number[]>()
    for (const { oid, value } of egressChunk.oids) {
      const arcs = suffixArcs(VLAN_OIDS.dot1qVlanStaticEgressPorts, oid)
      if (arcs.length !== 1) continue
      egressByVlan.set(arcs[0], decodePortBitmap(asBuffer(value)))
    }
    const statusByVlan = new Map<number, number>()
    for (const { oid, value } of statusChunk.oids) {
      const arcs = suffixArcs(VLAN_OIDS.dot1qVlanStaticRowStatus, oid)
      if (arcs.length !== 1) continue
      statusByVlan.set(arcs[0], asInt(value) ?? 0)
    }
    for (const { oid, value } of nameChunk.oids) {
      const arcs = suffixArcs(VLAN_OIDS.dot1qVlanStaticName, oid)
      if (arcs.length !== 1) continue
      const vlanId = arcs[0]
      if (!Number.isInteger(vlanId) || vlanId < 0 || vlanId > 4094) continue
      // RowStatus: 1=active è l'unica che conta; assente = la tengo (agenti minimi)
      const status = statusByVlan.get(vlanId)
      if (status !== undefined && status !== 1) continue
      vlans.push({
        vlanId,
        name: asText(value) ?? `VLAN ${vlanId}`,
        egressPorts: egressByVlan.get(vlanId) ?? [],
      })
    }
    if (nameChunk.oids.length >= CAP_VLANS) {
      warnings.push(`tabella VLAN troncata a ${CAP_VLANS} righe`)
    }
    if (vlans.length === 0) {
      warnings.push('nessuna VLAN statica dichiarata (solo default o gestione via GVRP)')
    }
  }

  /* --- (2) dot1qPortVlanTable: PVID per porta bridge --- */
  const portVlans: PortVlanRow[] = []
  const pvidChunk = await safeWalk(session, VLAN_OIDS.dot1qPvid, CAP_PVID_PORTS)
  if (!pvidChunk.error) {
    for (const { oid, value } of pvidChunk.oids) {
      const arcs = suffixArcs(VLAN_OIDS.dot1qPvid, oid)
      if (arcs.length !== 1) continue
      const port = arcs[0]
      const pvid = asInt(value)
      if (!Number.isInteger(port) || port <= 0 || pvid === null || pvid < 0) continue
      portVlans.push({ port, pvid })
    }
    portVlans.sort((a, b) => a.port - b.port)
  }
  // PVID assente non è un errore: la bitmap egress già dice l'essenziale

  return { vlans, portVlans, warnings }
}
