/* ================================================================
 * discovery-service/lib/tcp.ts — sonde TCP (Task 25 → v16.8)
 * ================================================================
 * Porta dal repository v15.16.0 la tecnica di «ping» multi-porta TCP
 * e la EVOLVE (v16.8 — performance e visione tecnica):
 *   · PING ADATTIVO A DUE PASSATE: prima passata col timeout richesto
 *     (host vivi → risposta immediata, costo invariato); SOLO se tutte
 *     le porte tacciono si riprova le stesse porte con timeout ~2,5×
 *     (host lenti o firewall SYN-drop). Gli host veloci NON pagano
 *     il prezzo di quelli lenti — è il compromesso giusto di uno sweep;
 *   · SET PORTE ALLARGATO: +161(SNMP già v15)+5060(SIP)+631(IPP)+
 *     9100(JetDirect)+7547(TR-069 CPE): il triage ora vede UPS,
 *     stampanti, centralini e modem TR-069, non solo camere e radio;
 *   · CERTIFICATO TLS (443): peer certificate con rejectUnauthorized
 *     off (SOLO lettura del CN/issuer — i router spesso dichiarano
 *     vendor e modello nel CN del certificato self-signed: un'impronta
 *     gratuita che nessuno sfrutta);
 *   · isIpv6(): le sonde puntuali (SNMP/ONVIF/L2) accettano IPv6;
 *     lo sweep CIDR resta IPv4 (onesto: enumerare IPv6 non ha senso).
 *
 * REGOLA D'ORO (ondata dei dati): NESSUN dato inventato. Una porta che
 * non risponde entro il timeout è «non aperta»; un host senza nessuna
 * connect riuscita NON viene dichiarato vivo.
 * ================================================================ */

import net from 'node:net'
import http from 'node:http'
import https from 'node:https'
import tls from 'node:tls'

/* ---------------- Porte di default (set v16.8, ordinato) ---------------- */

/** Porte sondate dal probe combinato /probe/vendor e dallo sweep /scan
 *  quando il chiamante non ne passa di esplicite: il set fisso v15
 *  allargato da v16.8 con 5060 (SIP), 631 (IPP stampanti), 9100
 *  (JetDirect raw 9100) e 7547 (TR-069 dei CPE/modem). */
export const VENDOR_PROBE_PORTS: readonly number[] = [22, 80, 161, 443, 554, 631, 5000, 5060, 7547, 8080, 8291, 8899, 9100, 34567, 37777]

/* ---------------- Validazione indirizzi ---------------- */

const IPV4_RE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/

/** TRUE per un IPv4 valido. */
export function isIpv4(ip: string): boolean {
  const m = (ip || '').match(IPV4_RE)
  if (!m) return false
  return [m[1], m[2], m[3], m[4]].every((o) => Number(o) <= 255)
}

/** TRUE per un IPv6 letterale accettabile (forma compressa inclusa).
 *  Volutamente tollerante: la validazione REALE la fa la socket. */
export function isIpv6(ip: string): boolean {
  const s = (ip || '').trim()
  if (!s.includes(':')) return false
  if (!/^[0-9a-fA-F:.]+$/.test(s)) return false
  // almeno un gruppo di cifre e non più di 8 «:»
  const colons = (s.match(/:/g) ?? []).length
  return colons >= 2 && colons <= 8
}

/* ---------------- Connect TCP con timeout (v15 core.ts, copiata) ---------------- */

/** Latenza di connect TCP (ms) oppure null (timeout/refused/error). */
export function tcpConnectLatency(ip: string, port: number, timeoutMs: number): Promise<number | null> {
  return new Promise((resolve) => {
    const start = Date.now()
    const socket = new net.Socket()
    let settled = false
    const done = (ok: boolean) => {
      if (settled) return
      settled = true
      socket.destroy()
      resolve(ok ? Date.now() - start : null)
    }
    socket.setTimeout(timeoutMs)
    socket.once('connect', () => done(true))
    socket.once('timeout', () => done(false))
    socket.once('error', () => done(false))
    socket.connect(port, ip)
  })
}

/* ---------------- pingHost multi-porta ADATTIVO (v16.8) ---------------- */

export interface PingHostResult {
  alive: boolean
  latencyMs: number
  openPorts: number[] // ordine crescente
  /** v16.8: true se la risposta è arrivata alla SECONDA passata
   *  (host lento — informazione onesta, utile in diagnosi). */
  secondPass?: boolean
}

export interface PingHostOptions {
  /** v16.8: seconda passata con timeout ~2,5× sugli host muti alla
   *  prima (default TRUE qui: il costo lo paga solo chi non ha risposto). */
  adaptive?: boolean
}

/** «Ping» TCP multi-porta con DUE PASSATE: la prima col timeout dato,
 *  la seconda (solo host ancora muti, solo porte chiuse) con timeout
 *  moltiplicato ~2,5. UP = almeno una connect riuscita su una delle
 *  due passate; latenza = minima misurata. */
export async function pingHost(
  ip: string,
  timeoutMs = 2000,
  ports: readonly number[] = VENDOR_PROBE_PORTS,
  opts: PingHostOptions = {},
): Promise<PingHostResult> {
  const start = Date.now()
  const adaptive = opts.adaptive !== false
  try {
    const results = await Promise.all(
      [...ports].map((p) => tcpConnectLatency(ip, p, Math.min(timeoutMs, 6000))),
    )
    const ok: Array<{ port: number; latency: number; secondPass: boolean }> = []
    const failed: number[] = []
    results.forEach((r, i) => {
      if (r !== null) ok.push({ port: ports[i], latency: r, secondPass: false })
      else failed.push(ports[i])
    })

    if (ok.length === 0 && adaptive && failed.length > 0) {
      // seconda passata: SOLO le porte chiuse, SOLO host ancora muti
      const longTimeout = Math.min(Math.max(Math.round(timeoutMs * 2.5), 1200), 3000)
      const retry = await Promise.all(failed.map((p) => tcpConnectLatency(ip, p, longTimeout)))
      retry.forEach((r, i) => {
        if (r !== null) ok.push({ port: failed[i], latency: r, secondPass: true })
      })
    }

    if (ok.length > 0) {
      return {
        alive: true,
        latencyMs: Math.min(...ok.map((o) => o.latency)),
        openPorts: ok.map((o) => o.port).sort((a, b) => a - b),
        secondPass: ok.some((o) => o.secondPass),
      }
    }
    return { alive: false, latencyMs: Date.now() - start, openPorts: [], secondPass: false }
  } catch {
    return { alive: false, latencyMs: Date.now() - start, openPorts: [], secondPass: false }
  }
}

/* ---------------- Scan di un host su porte arbitrarie (/scan) ---------------- */

export interface ScanHostResult {
  ip: string
  alive: boolean
  latencyMs: number
  openPorts: Array<{ port: number; state: 'open' }>
  secondPass?: boolean
}

/** Sweep TCP-connect di un host sulle porte richieste (tutte in parallelo,
 *  con seconda passata adattiva sugli host muti). alive = almeno una
 *  connect riuscita (nessuna prova di vita ⇒ onesto down). */
export async function scanHostPorts(
  ip: string,
  ports: readonly number[],
  timeoutMs: number,
  opts: PingHostOptions = {},
): Promise<ScanHostResult> {
  const r = await pingHost(ip, timeoutMs, ports, opts)
  return {
    ip,
    alive: r.alive,
    latencyMs: r.latencyMs,
    openPorts: r.openPorts.map((port) => ({ port, state: 'open' as const })),
    secondPass: r.secondPass,
  }
}

/* ---------------- Espansione CIDR IPv4 ---------------- */

export type CidrExpansion =
  | { ok: true; hosts: string[] }
  | { ok: false; error: 'BAD_CIDR'; detail: string }
  | { ok: false; error: 'TOO_LARGE'; detail: string }

function ipToInt(octets: number[]): number {
  return ((octets[0] << 24) | (octets[1] << 16) | (octets[2] << 8) | octets[3]) >>> 0
}

function intToIp(n: number): string {
  return `${(n >>> 24) & 255}.${(n >>> 16) & 255}.${(n >>> 8) & 255}.${n & 255}`
}

/** Espande un CIDR IPv4 negli host effettivi: per prefissi ≤ /30 salta
 *  indirizzo di rete e broadcast; /31 e /32 restituiscono tutto il blocco.
 *  Guardia anti-esaurimento: rifiuta enumerazioni oltre `hardCap`. */
export function expandCidr(cidr: string, hardCap = 65536): CidrExpansion {
  const raw = (cidr || '').trim()
  const m = raw.match(/^(.+?)\/(\d{1,2})$/)
  const ipStr = m ? m[1] : raw
  const prefix = m ? Number(m[2]) : 32
  const ipm = ipStr.match(IPV4_RE)
  if (!ipm) return { ok: false, error: 'BAD_CIDR', detail: `cidr non valido: "${cidr}"` }
  const octets = [Number(ipm[1]), Number(ipm[2]), Number(ipm[3]), Number(ipm[4])]
  if (octets.some((o) => !Number.isInteger(o) || o < 0 || o > 255) || prefix < 0 || prefix > 32) {
    return { ok: false, error: 'BAD_CIDR', detail: `cidr non valido: "${cidr}"` }
  }
  const base = ipToInt(octets) & (prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0)
  const total = prefix === 0 ? 2 ** 32 : 2 ** (32 - prefix)
  const count = prefix >= 31 ? total : total - 2
  if (count > hardCap) {
    return { ok: false, error: 'TOO_LARGE', detail: `CIDR troppo grande (${count} host > ${hardCap})` }
  }
  const first = prefix >= 31 ? base : base + 1
  const hosts: string[] = []
  for (let i = 0; i < count; i++) hosts.push(intToIp((first + i) >>> 0))
  return { ok: true, hosts }
}

/* ---------------- Banner HTTP (GET / su 80/8080/443) ---------------- */

export interface HttpBanner {
  server?: string
  title?: string
  /** v16.8: realm di autenticazione (i router espongono vendor nel realm). */
  realm?: string
  /** v16.8: CN del certificato TLS quando la sonda HTTPS lo legge. */
  certCn?: string
  /** v16.8: issuer del certificato TLS. */
  certIssuer?: string
}

/** GET / sull'host:porta con User-Agent FALCO-OS/16.8 — raccoglie
 *  l'header `Server`, il realm `WWW-Authenticate` e il `<title>` dai
 *  PRIMI 2 KB di corpo (poi chiude il socket: non serve scaricare
 *  pagine intere per un fingerprint). Null su errore o timeout. */
export function httpBanner(ip: string, port: number, timeoutMs = 2500): Promise<HttpBanner | null> {
  return new Promise((resolve) => {
    const transport = port === 443 ? https : http
    let settled = false
    const finish = (v: HttpBanner | null) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      try { req.destroy() } catch { /* già chiuso */ }
      resolve(v)
    }
    const timer = setTimeout(() => finish(null), Math.max(300, timeoutMs))
    const req = transport.request(
      {
        host: ip,
        port,
        path: '/',
        method: 'GET',
        headers: {
          'user-agent': 'FALCO-OS/16.8 (discovery-service)',
          accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
        },
      },
      (res) => {
        const server = (res.headers['server'] as string | undefined) || undefined
        const wwwAuth = (res.headers['www-authenticate'] as string | undefined) || undefined
        const realm = wwwAuth?.match(/realm="?([^",]+)"?/i)?.[1] || undefined
        let body = ''
        let solved = false
        res.setEncoding('utf8')
        res.on('data', (chunk: string) => {
          if (solved) return
          body += chunk
          if (body.length >= 2048) {
            solved = true
            const titleMatch = body.match(/<title[^>]*>([^<]+)/i)
            finish({
              server,
              title: titleMatch ? titleMatch[1].trim().slice(0, 200) : undefined,
              realm,
            })
          }
        })
        res.on('end', () => {
          if (solved) return
          solved = true
          const titleMatch = body.match(/<title[^>]*>([^<]+)/i)
          finish({
            server,
            title: titleMatch ? titleMatch[1].trim().slice(0, 200) : undefined,
            realm,
          })
        })
        res.on('error', () => finish(server || realm ? { server, realm } : null))
      },
    )
    req.on('timeout', () => finish(null))
    req.on('error', () => finish(null))
    req.end()
  })
}

/* ---------------- Certificato TLS (v16.8) ---------------- */

export interface TlsCertInfo {
  cn: string | null
  issuer: string | null
  validTo: string | null
}

/** Handshake TLS in SOLA LETTURA (rejectUnauthorized off: non stiamo
 *  autenticando, stiamo IMPRONTANDO il certificato self-signed che
 *  router/camere espongono — il CN spesso contiene vendor e modello).
 *  Null su errore/timeout. */
export function tlsCertProbe(ip: string, port = 443, timeoutMs = 2500): Promise<TlsCertInfo | null> {
  return new Promise((resolve) => {
    let settled = false
    const finish = (v: TlsCertInfo | null) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      try { socket.destroy() } catch { /* già chiuso */ }
      resolve(v)
    }
    const timer = setTimeout(() => finish(null), Math.max(300, timeoutMs))
    const socket = tls.connect(
      {
        host: ip,
        port,
        rejectUnauthorized: false,
        servername: undefined, // nessun SNI: certificati self-signed con IP
      },
      () => {
        try {
          const cert = socket.getPeerCertificate()
          if (!cert || cert.subject === undefined) {
            finish(null)
            return
          }
          finish({
            cn: (cert.subject && cert.subject.CN) || null,
            issuer: (cert.issuer && (cert.issuer.CN || cert.issuer.O)) || null,
            validTo: cert.valid_to || null,
          })
        } catch {
          finish(null)
        }
      },
    )
    socket.on('error', () => finish(null))
    socket.on('timeout', () => finish(null))
  })
}
