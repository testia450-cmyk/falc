/* ================================================================
 * discovery-service/lib/udp-vendor.ts — sweep UDP vendor (Task 25)
 * ================================================================
 * Portato dal repository v15.16.0:
 *   · UBIQUITI DISCOVERY PROTOCOL (UDP 10001 broadcast): richiesta
 *     magica 0x01 + len + "test string"; risposta TLV [tag:1][len:2 BE]
 *     con 0x01 MAC / 0x02 hostname / 0x03 firmware / 0x05 piattaforma.
 *     → parseUbntDiscoveryPacket + ubntDiscoverSweep (v15
 *     src/lib/uisp-discovery.ts righe ~297-360, COPIA);
 *   · MNDP MikroTik (UDP 5678 broadcast): richiesta vuota type 0,
 *     risposta TLV [type u8][len u16 BE] con MAC/IDENTITY/VERSION/
 *     UPTIME/BOARD/PLATFORM → parseMndpPacket + mndpDiscoverSweep
 *     (v15 src/lib/vendor-discovery.ts righe ~1050-1107, COPIA);
 *   · normalizeMac / macFromOctets (v15 src/lib/airos-ssh.ts, COPIA).
 *
 * REGOLA D'ORO: in sandbox senza dispositivi la lista è VUOTA (onesta):
 * nessun pacchetto ricevuto ⇒ nessun dispositivo inventato.
 * ================================================================ */

import dgram from 'node:dgram'

/* ------------------ MAC utils (v15 airos-ssh.ts, COPIA) ------------------ */

/** Normalizza un MAC (qualsiasi formato/esadecimale compatto) in
 *  "AA:BB:CC:DD:EE:FF"; stringa vuota se non sono 12 cifre esadecimali. */
export function normalizeMac(raw: string): string {
  const hex = (raw || '').toLowerCase().replace(/[^0-9a-f]/g, '')
  if (hex.length !== 12) return ''
  return hex.match(/.{2}/g)!.join(':').toUpperCase()
}

/** MAC da octet string SNMP (Buffer/array/stringa) — v15, COPIA. */
export function macFromOctets(v: unknown): string {
  if (Buffer.isBuffer(v)) return normalizeMac(v.toString('hex'))
  if (typeof v === 'string') return normalizeMac(v)
  if (Array.isArray(v)) return normalizeMac(Buffer.from(v as number[]).toString('hex'))
  return ''
}

/* ------------------ Tipi ------------------ */

export interface UbntDiscoveredDevice {
  mac: string
  name: string
  firmware: string
  platform: string
  ip: string // IP sorgente della risposta UDP
}

export interface MndpDevice {
  ip: string
  mac: string
  identity: string
  version: string
  platform: string
  board: string
}

/* ------------------ Ubiquiti Discovery Protocol (UDP 10001, v15 COPIA) ------------------ */

/**
 * Parser del pacchetto di risposta Ubiquiti discovery (UDP 10001):
 * [0]=0x01 magico, [1..3]=lunghezza payload BE, poi TLV [tag:1][len:2 BE][val].
 * Tag noti: 0x01 MAC, 0x02 hostname, 0x03 firmware, 0x05 piattaforma.
 */
export function parseUbntDiscoveryPacket(buf: Buffer): Omit<UbntDiscoveredDevice, 'ip'> | null {
  try {
    if (!buf || buf.length < 4 || buf[0] !== 0x01) return null
    const payloadLen = buf.readUIntBE(1, 3)
    const end = Math.min(4 + payloadLen, buf.length)
    let off = 4
    let mac = ''
    let name = ''
    let firmware = ''
    let platform = ''
    while (off + 3 <= end) {
      const tag = buf[off]
      const len = buf.readUIntBE(off + 1, 2)
      if (off + 3 + len > end) break
      const val = buf.subarray(off + 3, off + 3 + len)
      if (tag === 0x01 && len === 6) mac = normalizeMac(val.toString('hex'))
      else if (tag === 0x02) name = val.toString('latin1').trim()
      else if (tag === 0x03) firmware = val.toString('latin1').trim()
      else if (tag === 0x05) platform = val.toString('latin1').trim()
      off += 3 + len
    }
    if (!mac && !name && !platform) return null
    return { mac: mac || '', name: name || '', firmware: firmware || '', platform: platform || '' }
  } catch {
    return null
  }
}

/**
 * Sweep Ubiquiti discovery: invia il pacchetto magico a <broadcast>:10001
 * (default 255.255.255.255) e raccoglie le risposte per timeoutMs.
 * NON richiede credenziali: stesso meccanismo del Discovery Tool UISP.
 */
export function ubntDiscoverSweep(broadcast: string, timeoutMs = 3000): Promise<UbntDiscoveredDevice[]> {
  return new Promise((resolve) => {
    const found = new Map<string, UbntDiscoveredDevice>()
    let socket: dgram.Socket | null = null
    const finish = () => {
      try {
        socket?.close()
      } catch {
        /* noop */
      }
      resolve([...found.values()])
    }
    try {
      socket = dgram.createSocket({ type: 'udp4', reuseAddr: true })
      socket.on('error', () => finish())
      socket.on('message', (msg, rinfo) => {
        const parsed = parseUbntDiscoveryPacket(msg)
        if (!parsed) return
        const key = parsed.mac || `${rinfo.address}:${parsed.name}`
        if (!found.has(key)) {
          found.set(key, { mac: parsed.mac, name: parsed.name, firmware: parsed.firmware, platform: parsed.platform, ip: rinfo.address })
        }
      })
      // Pacchetto richiesta standard: 0x01 + len=25 + "test string" + padding
      const payload = Buffer.from('test string\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'latin1').subarray(0, 25)
      const packet = Buffer.concat([
        Buffer.from([0x01]),
        (() => {
          const b = Buffer.alloc(3)
          b.writeUIntBE(payload.length, 0, 3)
          return b
        })(),
        payload,
      ])
      socket.bind(() => {
        try {
          socket!.setBroadcast(true)
        } catch {
          /* noop */
        }
        socket!.send(packet, 10001, broadcast || '255.255.255.255')
      })
      setTimeout(finish, Math.max(500, timeoutMs))
    } catch {
      finish()
    }
  })
}

/* ------------------ MNDP MikroTik (UDP 5678, v15 COPIA) ------------------ */

export const MNDP_PORT = 5678

/** TLV del protocollo MNDP (type u8 + len u16 BE). Tag noti Wiki MikroTik. */
const MNDP_TLV = { MAC: 1, IDENTITY: 2, VERSION: 3, UPTIME: 5, BOARD: 8, PLATFORM: 9 } as const

/** Parser pacchetto MNDP (v15 vendor-discovery.ts, COPIA). */
export function parseMndpPacket(buf: Buffer, senderIp?: string): MndpDevice | null {
  if (!buf || buf.length < 3) return null
  // salta l'header del pacchetto (type u8 + len u16): i TLV iniziano subito dopo
  let off = 3
  let mac = '',
    identity = '',
    version = '',
    platform = '',
    board = ''
  while (off + 3 <= buf.length) {
    const type = buf.readUInt8(off)
    const len = buf.readUInt16BE(off + 1)
    if (off + 3 + len > buf.length) break
    const val = buf.subarray(off + 3, off + 3 + len)
    if (type === MNDP_TLV.MAC && len === 6) {
      mac = [...val].map((b) => b.toString(16).padStart(2, '0')).join(':')
    } else if (type === MNDP_TLV.IDENTITY) identity = val.toString('utf8').trim()
    else if (type === MNDP_TLV.VERSION) version = val.toString('utf8').trim()
    else if (type === MNDP_TLV.PLATFORM) platform = val.toString('utf8').trim()
    else if (type === MNDP_TLV.BOARD) board = val.toString('utf8').trim()
    off += 3 + len
  }
  if (!mac && !identity && !platform && !version) return null
  return { ip: senderIp || '', mac, identity, version, platform, board }
}

/** Sweep MNDP: pacchetto vuoto type 0 in broadcast 5678, i MikroTik
 *  rispondono con i TLV (v15 vendor-discovery.ts, COPIA). */
export function mndpDiscoverSweep(timeoutMs = 4000, onDevice?: (d: MndpDevice) => void): Promise<MndpDevice[]> {
  return new Promise((resolve) => {
    const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true })
    const found = new Map<string, MndpDevice>()
    let closed = false
    const finish = () => {
      if (closed) return
      closed = true
      clearTimeout(timer)
      try {
        sock.close()
      } catch {
        /* noop */
      }
      resolve([...found.values()])
    }
    const timer = setTimeout(finish, Math.max(500, timeoutMs))
    sock.on('error', finish)
    sock.on('message', (buf: Buffer, rinfo: { address: string }) => {
      const parsed = parseMndpPacket(buf, rinfo.address)
      if (!parsed) return
      const key = parsed.mac || parsed.ip
      if (!found.has(key)) {
        found.set(key, parsed)
        if (onDevice) onDevice(parsed)
      }
    })
    sock.bind(() => {
      // richiesta MNDP standard: header type 0, length 0 (Winbox/Neighbor viewer)
      const msg = Buffer.from([0x00, 0x00, 0x00])
      sock.setBroadcast(true)
      sock.send(msg, MNDP_PORT, '255.255.255.255')
    })
  })
}
