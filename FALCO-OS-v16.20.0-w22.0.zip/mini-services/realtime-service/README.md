# FALCO-OS v16 — realtime-service (porta 3001)

Mini-service Bun indipendente (socket.io) per il canale realtime del frontend NOC,
in **modalità RIPRODUZIONE dichiarata** (decisione D2 del worklog): il sandbox non ha
poller reali, quindi il tick riproduce/aggancia dati reali del DB senza inventare
cambi di stato.

## Avvio

```bash
cd /home/z/my-project/mini-services/realtime-service
(bun run dev > /home/z/my-project/mini-services/realtime-service/service.log 2>&1 &)
```

Porta fissa 3001 (mai da variabile d'ambiente). `bun --hot` riavvia sui sorgenti.

## Contratto

- `GET /health` → `{"ok":true,"service":"falco-realtime","lastTickAt":…,"replay":true}`
- socket.io path `/` (il gateway inoltra con `XTransformPort=3001`)
- Eventi server→client: `noc:tick` (30 s), `metrics:jitter`, `alarms:new`, `noc:snapshot`
- Client→server: `plant:subscribe` (room `plant:<id>` + snapshot)
- heartbeat atomico su `state.json` (`.tmp` + rename): `{importedAt, lastTickAt, nextTickAt, intervalSec}`
  — `derive.ts/getReplayState` lo usa per dichiarare `mode:'replay'` nelle risposte API.

## Tick (ogni 30 s)

1. solo dispositivi già visti: `lastSeenAt = now` per ONLINE/DEGRADED
2. campioni jitter deterministici (seed deviceId+tick) per max 60 dispositivi a rotazione
3. `signalStrength = valore reale ±1 dBm` (solo se != 0)
4. `io.emit('noc:tick', …)`, `metrics:jitter`, `alarms:new` solo se ci sono AlertEvent nuovi

NESSUNA logica di cambio stato dispositivo (regola «nessun dato inventato»).
Dipendenze risolte risalendo al `node_modules` della root (nessuna installazione locale).
