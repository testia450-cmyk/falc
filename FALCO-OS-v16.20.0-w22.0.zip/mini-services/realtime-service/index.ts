/* ================================================================
 * falco-realtime-service — FALCO-OS v16 (Task 6-b)
 * Canale realtime del frontend NOC — porta fissa 3001, path '/'
 * (il browser NON fa polling aggressivo: passa dal gateway con
 *  /?XTransformPort=3001 e riceve qui noc:tick / metrics:jitter / alarms:new).
 *
 * «Modalità riproduzione — ambiente dimostrativo senza poller reali:
 *  avanza solo la freschezza dei dati reali importati; non cambia stati,
 *  non inventa guasti.» (decisione D2 — docs/ARCHITETTURA_E_DECISIONI.md)
 *
 * Ogni tick (30s = Plant.pingIntervalSec REALE dell'impianto «egidio»):
 *   1. seleziona i dispositivi del plant GIÀ VISTI (lastSeenAt != null):
 *      i 30 mai-visti restano UNKNOWN (onestà §2.2, mai OFFLINE per mancanza dato);
 *   2. aggiorna lastSeenAt = now SOLO per ONLINE/DEGRADED (updateMany);
 *   3. scrive campioni MetricValue di jitter attorno ai valori REALI per un
 *      sottoinsieme a rotazione (max 60 dispositivi/tick):
 *        · pingLatency: base 20-80 ms per dispositivo, rumore ±15%
 *          deterministico (seed deviceId + numero di tick);
 *        · signalStrength: valore REALE del Device ±1 dBm (solo radio, != 0);
 *   3c. «HOLD» flussi video: riscrive l'ULTIMO valore reale noto di
 *      cameraStreamAlive per gli apparati già campionati dal poller reale
 *      (ogni 10° tick + primo tick). La serie reale è congelata all'import:
 *      senza hold il registro flussi decadrebbe a «n.d.» entro 24h mentre il
 *      dispositivo resta ONLINE (lastSeenAt fresco al punto 2) — incoerente.
 *      Il valore NON cambia mai (1 resta 1, 0 resta 0) e i mai-campionati
 *      restano tali: NESSUNA transizione inventata, solo freschezza;
 *   4. ricalcola { asOf, devicesOnline, devicesDegraded, devicesUnknown }
 *      (group by status + check semplice: lastSeenAt null → unknown) e
 *      emette io.emit('noc:tick', payload);
 *   5. emette io.emit('metrics:jitter', { devices: [...i campioni scritti...] });
 *   6. emette io.emit('alarms:new', ...) SOLO se nel DB compaiono AlertEvent
 *      aggiornati dall'ultimo tick (query reale su updatedAt, take 10);
 *   7. aggiorna il heartbeat atomico state.json (writeFileSync + rename),
 *      letto dal processo Next.js (src/lib/v2/derive.ts getReplayState)
 *      per esporre mode: 'replay' | 'static'.
 *
 * Cosa NON fa mai (regola: nessun dato inventato):
 *   · NON cambia gli stati dei dispositivi (nessuna logica ONLINE→DEGRADED…);
 *   · NON genera guasti o allarmi sintetici;
 *   · NON tocca i dispositivi mai visti (restano UNKNOWN per sempre,
 *     finché un poller reale non li veda).
 *
 * Dipendenze: socket.io e @prisma/client del progetto padre
 * (/home/z/my-project/node_modules — bun risale le cartelle, NON reinstallate).
 * ================================================================ */

import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { renameSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Server as IOServer } from 'socket.io'
import { PrismaClient } from '@prisma/client'

/* ---------------- Config (porta fissa, percorsi dinamici e portabili) ---------------- */

const PORT = 3001
/* v16.18.1: i percorsi NON sono più assoluti hardocoded (funzionavano solo
 * nella sandbox Linux) ma derivati dalla cartella di QUESTO file — identici
 * su Linux, corretti anche su Windows (URL→path è portabile ovunque). */
const HERE = fileURLToPath(new URL('.', import.meta.url))
const STATE_PATH = join(HERE, 'state.json')
const IMPORTED_AT = 1793011380744 // epoch ms dell'import del DB reale (fisso, contratto con derive.ts)
const MAX_JITTER_DEVICES = 60 // dispositivi campionati per tick, a rotazione
const STREAM_HOLD_EVERY_TICKS = 10 // hold flussi video: ogni 10° tick (~5 min)

/* DB del progetto padre, risolto in modo portabile (v16.18.1):
 * mini-services/realtime-service → ../../db/custom.db. Su Linux coincide
 * col vecchio path assoluto; su Windows funziona senza modifiche.
 * L'URL Prisma su Windows vuole lo slash come separatore.
 * Un DATABASE_URL già presente nell'ambiente VINCE (avvii espliciti). */
const DB_FILE = join(HERE, '..', '..', 'db', 'custom.db')
if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = 'file:' + DB_FILE.replace(/\\/g, '/')
}
const prisma = new PrismaClient({ log: ['error', 'warn'] })

/* ---------------- Stato del servizio ---------------- */

let plantId = ''
let intervalSec = 30
let tickIndex = 0 // semovente della rotazione deterministica
let lastTickAt: number | null = null
let nextTickAt: number | null = null
let lastAlertCheckAt = new Date() // baseline avvio: gli allarmi PRE-esistenti non sono «nuovi»
let ticking = false

/* ---------------- Log (timestamp ISO, nessun segreto) ---------------- */

const log = (...args: unknown[]) => console.log(`[${new Date().toISOString()}]`, ...args)
const errMessage = (e: unknown) => (e instanceof Error ? e.message : String(e))

/* ---------------- Jitter deterministico (seed deviceId + tick) ---------------- */

function hash32(s: string): number {
  let h = 2166136261 // FNV-1a
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function rand01(seed: string): number {
  // mulberry32 su hash del seed: stesso seed → stesso valore (riproducibile)
  let a = (hash32(seed) + 0x6d2b79f5) >>> 0
  let t = Math.imul(a ^ (a >>> 15), 1 | a)
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296
}

/* ---------------- Flussi video: «hold» dell'ultimo valore reale ---------------- */

/** deviceId → ultimo valore REALE di cameraStreamAlive (caricato al boot, vedi 3c).
 *  106 apparati nel DB reale hanno campioni (inclusi 15 SWITCH e 1 SERVER che il
 *  poller reale campionava davvero: la serie reale è fatta così, la preserviamo).
 *  I 12 apparati video MAI campionati restano fuori → registro onesto «n.d.». */
let streamHold: { deviceId: string; value: number }[] = []

async function loadStreamHold(): Promise<void> {
  streamHold = await prisma.$queryRawUnsafe<Array<{ deviceId: string; value: number }>>(
    `SELECT deviceId, value FROM (
       SELECT deviceId, value,
              ROW_NUMBER() OVER (PARTITION BY deviceId ORDER BY timestamp DESC) AS rn
       FROM MetricValue
       WHERE plantId = ? AND metric = 'cameraStreamAlive'
     ) WHERE rn = 1`,
    plantId,
  )
  log(`flussi video: hold dell'ultimo valore reale per ${streamHold.length} apparati campionati (nessuna transizione, nessun nuovo apparato)`)
}

/* ---------------- Heartbeat atomico su state.json ---------------- */

function writeHeartbeat(): void {
  const state = { importedAt: IMPORTED_AT, lastTickAt, nextTickAt, intervalSec }
  const tmp = `${STATE_PATH}.tmp`
  writeFileSync(tmp, `${JSON.stringify(state, null, 2)}\n`, 'utf8')
  renameSync(tmp, STATE_PATH) // atomico per il lettore (Next.js: getReplayState)
}

/* ---------------- bun --hot: libera le risorse della valutazione precedente ---------------- */

type CleanupFn = () => void
const g = globalThis as unknown as { __falcoRealtimeCleanup?: CleanupFn }
if (g.__falcoRealtimeCleanup) {
  try { g.__falcoRealtimeCleanup() } catch { /* già liberate */ }
}
const timers: ReturnType<typeof setInterval>[] = []

/* ---------------- Server HTTP + socket.io (porta 3001, path '/') ---------------- */

const httpServer = createServer()

const io = new IOServer(httpServer, {
  path: '/', // il gateway inoltra / → 3001 (browser: /?XTransformPort=3001)
  cors: { origin: true, credentials: true },
  pingInterval: 25_000,
  pingTimeout: 20_000,
})

// Con path '/' engine.io rivendica OGNI URL che inizia per '/': wrappo i
// listener di richiesta (stesso pattern che engine.io usa internamente) per
// servire GET /health prima che engine.io risponda «Transport unknown».
type ReqListener = (req: IncomingMessage, res: ServerResponse) => void
const engineListeners = httpServer.listeners('request') as ReqListener[]
httpServer.removeAllListeners('request')
httpServer.on('request', (req, res) => {
  const url = (req.url ?? '').split('?')[0]
  if (req.method === 'GET' && (url === '/health' || url === '/health/')) {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
    res.end(JSON.stringify({ ok: true, service: 'falco-realtime', lastTickAt, replay: true }))
    return
  }
  for (const l of engineListeners) l.call(httpServer, req, res)
})

g.__falcoRealtimeCleanup = () => {
  for (const t of timers) clearInterval(t)
  timers.length = 0
  try { io.close() } catch { /* noop */ }
  try { httpServer.close() } catch { /* noop */ }
  void prisma.$disconnect().catch(() => {})
}

io.on('connection', (socket) => {
  log('client connesso', socket.id)
  socket.on('plant:subscribe', async (payload: unknown, maybeAck?: unknown) => {
    let ack: ((snapshot: unknown) => void) | undefined
    if (typeof payload === 'function') {
      ack = payload as (snapshot: unknown) => void
      payload = undefined
    } else if (typeof maybeAck === 'function') {
      ack = maybeAck as (snapshot: unknown) => void
    }
    const wanted =
      payload && typeof payload === 'object' && typeof (payload as { plantId?: unknown }).plantId === 'string'
        ? (payload as { plantId: string }).plantId
        : plantId
    socket.join(`plant:${wanted}`)
    log('subscribe', socket.id, '→', `plant:${wanted}`)
    try {
      const snapshot = await buildSnapshot()
      socket.emit('noc:snapshot', snapshot)
      ack?.(snapshot)
    } catch (e) {
      log('ERRORE snapshot per', socket.id, errMessage(e))
    }
  })
  socket.on('disconnect', (reason) => log('client disconnesso', socket.id, reason))
  socket.on('error', (e) => log('ERRORE socket', socket.id, errMessage(e)))
})

/* ---------------- Conteggi (group by status + lastSeenAt null → unknown) ---------------- */

/** «Dispositivi del plant»: con plantId DIRETTO (v16.12 W10) — ogni
 *  dispositivo appartiene al suo impianto, gli orfani (locationId null)
 *  SCOPI nel loro e non appariscono negli altri impianti. */
function plantScope() {
  return { plantId, decommissionedAt: null }
}

async function countByState() {
  const [groups, unknownCount] = await Promise.all([
    prisma.device.groupBy({ by: ['status'], where: { ...plantScope(), lastSeenAt: { not: null } }, _count: { _all: true } }),
    prisma.device.count({ where: { ...plantScope(), lastSeenAt: null } }),
  ])
  return {
    devicesOnline: groups.find((x) => x.status === 'ONLINE')?._count._all ?? 0,
    devicesDegraded: groups.find((x) => x.status === 'DEGRADED')?._count._all ?? 0,
    devicesUnknown: unknownCount,
  }
}

async function buildSnapshot() {
  const counts = await countByState()
  return {
    ...counts,
    asOf: Date.now(),
    plantId,
    replay: { mode: 'replay', importedAt: IMPORTED_AT, lastTickAt, nextTickAt, intervalSec },
  }
}

/* ---------------- Tick di riproduzione ---------------- */

async function tick(): Promise<void> {
  const now = new Date()
  tickIndex += 1

  // (1) SOLO i dispositivi già visti: i 30 mai-visti restano UNKNOWN (§2.2)
  const seen = await prisma.device.findMany({
    where: { ...plantScope(), lastSeenAt: { not: null } },
    select: { id: true, status: true, signalStrength: true },
    orderBy: { id: 'asc' },
  })
  const active = seen.filter((d) => d.status === 'ONLINE' || d.status === 'DEGRADED')

  // (2) FRESCHEZZA: lastSeenAt = now per ONLINE/DEGRADED già visti.
  //     NESSUN cambio di stato: gli stati restano quelli REALI del DB.
  const refreshed = await prisma.device.updateMany({
    where: { ...plantScope(), lastSeenAt: { not: null }, status: { in: ['ONLINE', 'DEGRADED'] } },
    data: { lastSeenAt: now },
  })

  // (3) JITTER attorno ai valori reali — sottoinsieme a rotazione (max 60/tick)
  const n = active.length
  const take = Math.min(MAX_JITTER_DEVICES, n)
  const start = n > 0 ? (tickIndex * MAX_JITTER_DEVICES) % n : 0
  const samples: { deviceId: string; metric: string; value: number; unit: string }[] = []
  for (let i = 0; i < take; i++) {
    const d = active[(start + i) % n]
    // pingLatency: base 20-80 ms deterministica per deviceId, rumore ±15% per (deviceId, tick)
    const base = 20 + (hash32(d.id) % 61)
    const noise = rand01(`${d.id}:${tickIndex}`) * 0.3 - 0.15
    samples.push({ deviceId: d.id, metric: 'pingLatency', value: Math.round(base * (1 + noise) * 10) / 10, unit: 'ms' })
    // signalStrength: valore REALE del Device ±1 dBm (solo radio: signalStrength != 0)
    if (d.signalStrength !== 0) {
      const jit = Math.floor(rand01(`sig:${d.id}:${tickIndex}`) * 3) - 1
      samples.push({ deviceId: d.id, metric: 'signalStrength', value: d.signalStrength + jit, unit: 'dBm' })
    }
  }
  if (samples.length > 0) {
    await prisma.metricValue.createMany({ data: samples.map((s) => ({ ...s, plantId, timestamp: now })) })
  }

  // (3b) JITTER del traffico di porta — SOLO per i dispositivi che HANNO
  //      campioni port_traffic recenti (ultime 6h): base = ULTIMO valore
  //      reale per (device, metrica), rumore ±25%, clamp ≥ 0. Nessun
  //      traffico inventato dove il poller reale non ne scriveva.
  //      Max 20 dispositivi/tick (i core di distribuzione reali).
  try {
    const trafficDevices = await prisma.$queryRawUnsafe<Array<{ deviceId: string; metric: string; value: number }>>(
      `SELECT deviceId, metric, value FROM (
         SELECT deviceId, metric, value,
                ROW_NUMBER() OVER (PARTITION BY deviceId, metric ORDER BY timestamp DESC) AS rn
         FROM MetricValue
         WHERE plantId = ? AND metric IN ('port_traffic_in','port_traffic_out')
           AND timestamp > ?
       ) WHERE rn = 1 LIMIT 40`,
      plantId, now.getTime() - 6 * 3600 * 1000,
    )
    const trafficSamples: { deviceId: string; metric: string; value: number; unit: string }[] = []
    for (const t of trafficDevices) {
      const noise = rand01(`traf:${t.deviceId}:${t.metric}:${tickIndex}`) * 0.5 - 0.25
      const v = Math.max(0, Math.round(Number(t.value) * (1 + noise) * 100) / 100)
      trafficSamples.push({ deviceId: t.deviceId, metric: t.metric, value: v, unit: 'Mbps' })
    }
    if (trafficSamples.length > 0) {
      await prisma.metricValue.createMany({ data: trafficSamples.map((s) => ({ ...s, plantId, timestamp: now })) })
      samples.push(...trafficSamples)
    }
  } catch (err) {
    log(`jitter traffico saltato (non bloccante): ${String(err).slice(0, 80)}`)
  }

  // (3c) HOLD flussi video: riscrive l'ultimo valore reale noto (vedi header 3c).
  //      Primo tick dopo l'avvio + ogni 10° tick (~5 min): il registro torna
  //      fresco subito e la densità resta comparabile alla serie reale.
  let streamHoldWritten = 0
  if (streamHold.length > 0 && (tickIndex === 1 || tickIndex % STREAM_HOLD_EVERY_TICKS === 0)) {
    await prisma.metricValue.createMany({
      data: streamHold.map((s) => ({
        deviceId: s.deviceId, plantId, metric: 'cameraStreamAlive',
        value: s.value, unit: '0/1', timestamp: now,
      })),
    })
    streamHoldWritten = streamHold.length
  }

  // (4) payload NOC → io.emit('noc:tick')
  const counts = await countByState()
  io.emit('noc:tick', { asOf: now.getTime(), ...counts })

  // (5) campioni jitter scritti (max 60 dispositivi) → io.emit('metrics:jitter')
  io.emit('metrics:jitter', {
    devices: samples.map((s) => ({ deviceId: s.deviceId, metric: s.metric, value: s.value, timestamp: now.getTime() })),
  })

  // (6) allarmi NUOVI reali (eventuali ack/dedup dell'utente via API v2):
  //     query semplice su updatedAt > ultimo check → io.emit('alarms:new')
  const alarms = await prisma.alertEvent.findMany({
    where: { plantId, updatedAt: { gt: lastAlertCheckAt } },
    orderBy: { openedAt: 'desc' },
    take: 10,
    select: { id: true, severity: true, message: true, deviceId: true, openedAt: true, occurrenceCount: true },
  })
  if (alarms.length > 0) {
    io.emit('alarms:new', { alarms: alarms.map((a) => ({ ...a, openedAt: a.openedAt.getTime() })) })
  }
  lastAlertCheckAt = now

  // (7) heartbeat atomico: attestazione dell'ultimo tick RIUSCITO
  lastTickAt = now.getTime()
  nextTickAt = lastTickAt + intervalSec * 1000
  writeHeartbeat()

  log(
    `tick #${tickIndex}: refreshed=${refreshed.count} sample=${samples.length} holdStreams=${streamHoldWritten}`,
    `online=${counts.devicesOnline} degraded=${counts.devicesDegraded} unknown=${counts.devicesUnknown}`,
    `alarms=${alarms.length} clients=${io.engine.clientsCount}`,
  )
}

/** Robustezza: un errore DB in un tick NON uccide il processo (se il tick fallisce
 *  il heartbeat non viene aggiornato → il frontend ricade onestamente in 'static'). */
async function runTick(): Promise<void> {
  if (ticking) {
    log('tick precedente ancora in corso: salto questo intervallo')
    return
  }
  ticking = true
  try {
    await tick()
  } catch (e) {
    log('ERRORE tick (il processo resta vivo):', errMessage(e))
  } finally {
    ticking = false
  }
}

/* ---------------- Avvio ---------------- */

async function boot(): Promise<void> {
  // v16.12 W10: riproduzione deterministicamente legata all'impianto PIÙ
  // VECCHIO (createdAt asc — stessa regola del default W8). Prima era
  // orderBy name asc: col secondo impianto reale («cagliari» < «egidio»
  // alfabeticamente) il tick della RIPRODUZIONE dell'import egidio
  // sarebbe migrato sull'impianto nuovo e vuoto.
  const plant = await prisma.plant.findFirst({
    where: { isActive: true },
    orderBy: { createdAt: 'asc' },
    select: { id: true, name: true, pingIntervalSec: true },
  })
  if (!plant) throw new Error('nessun Plant attivo nel DB: impossibile avviare la riproduzione')
  plantId = plant.id
  intervalSec = plant.pingIntervalSec > 0 ? plant.pingIntervalSec : 30
  log(
    `modalità RIPRODUZIONE — plant «${plant.name}» (${plantId})`,
    `tick=${intervalSec}s import=${new Date(IMPORTED_AT).toISOString()}`,
  )
  log('la riproduzione avanza SOLO freschezza e jitter attorno ai valori reali: nessun cambio di stato, nessun guasto inventato')
  try {
    await loadStreamHold() // cache flussi video per l'hold (3c); se fallisce: feature off, non blocca
  } catch (e) {
    log('hold flussi non caricato (non bloccante):', errMessage(e))
  }
  await runTick() // primo tick immediato → state.json fresco da subito
  timers.push(setInterval(() => void runTick(), intervalSec * 1000))
}

httpServer.on('error', (e) => {
  log(`ERRORE server HTTP su :${PORT}:`, errMessage(e))
  process.exit(1)
})

httpServer.listen(PORT, () => {
  log(`falco-realtime in ascolto su :${PORT} — socket.io path '/' (gateway /?XTransformPort=${PORT})`)
  void (async () => {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await boot()
        return
      } catch (e) {
        log(`boot fallito (${attempt}/3):`, errMessage(e))
        await new Promise((r) => setTimeout(r, 5000))
      }
    }
    log('DB non raggiungibile dopo 3 tentativi: esco')
    process.exit(1)
  })()
})

for (const sig of ['SIGTERM', 'SIGINT'] as const) {
  process.on(sig, () => {
    log(`ricevuto ${sig}: chiusura pulita`)
    g.__falcoRealtimeCleanup?.()
    void prisma.$disconnect().catch(() => {}).finally(() => process.exit(0))
  })
}
