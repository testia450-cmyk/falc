# API v2 — Contratti (GENERATO da src/lib/v2/contracts.ts)

> Non editare a mano: rigenerare con `bun scripts/gen-api-contracts.ts` (regola §14.4 del piano v16).
> Busta comune: successo `{ ok: true, asOf: epoch_ms, mode: 'replay'|'static', data }`; errore `{ ok: false, error: { code, message, details? } }` con HTTP 401/403/404/422/500.
> Autenticazione: sessione NextAuth (Credentials) richiesta su ogni rotta; POST `ack` richiede ruolo ≥ TECNICO.
> Additività (§2.5): nessuna rotta v1 è stata modificata o rimossa.
> Validazione: in sviluppo ogni risposta è validata col proprio schema (devValidate in shared.ts).


## GET /api/v2/noc/summary

Sintesi NOC: KPI, apparati video, link radio, allarmi, copertura, pipeline, eventi recenti.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "plant": object {
      "id": string
      "name": string
      "comune": string
      "pingIntervalSec": number
      "mapCenterLat": number
      "mapCenterLng": number
      "mapZoom": number
    }
      "devices": object {
      "total": number
      "byState": object {
      "online": number
      "degraded": number
      "offline": number
      "maintenance": number
      "unknown": number
      "notMonitored": number
    }
      "byType": record<string, number>
    }
      "cameras": object {
      "total": number
      "online": number
      "degraded": number
      "offline": number
      "unknown": number
      "streamDown": number
      "streamUnknown": number
    }
      "wirelessLinks": object {
      "total": number
      "active": number
      "degraded": number
      "weak": number
      "unknown": number
    }
      "alarms": object {
      "open": number
      "bySeverity": record<string, number>
      "suppressed": number
      "oldestOpenMinutes": number | null
    }
      "coverage": object {
      "certain": number
      "uncertain": number
      "unknown": number
      "coveragePct": number
      "goalPct": number
      "goalMet": boolean
    } | null
      "pipeline": object {
      "realtimeConnected": boolean
      "lastTickAt": number | null
      "dbReachable": boolean
      "version": string
    }
      "recentEvents": array<object {
      "id": string
      "deviceId": string | null
      "deviceHostname": string | null
      "eventType": string
      "oldValue": string
      "newValue": string
      "source": string
      "createdAt": number
    }>
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
    }
```

## GET /api/v2/devices

Inventario dispositivi (filtri famiglia/stato/testo, ordinamento, paginazione server-side).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "connectionType": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
      "dbStatus": string
      "statusReason": string | null
      "brand": string
      "model": string
      "antennaType": string
      "signalStrength": number
      "signalPresent": boolean
      "linkQuality": number
      "radioMode": string
      "linkMode": string
      "currentFrequency": string
      "ssid": string
      "macAddress": string
      "firmwareVersion": string
      "uptimeSeconds": number
      "cpuLoad": number
      "ramTotal": number (default 0)
      "ramUsed": number (default 0)
      "lastSeenAt": number | null
      "stale": boolean
      "monitored": boolean
      "locationId": string | null
      "locationName": string | null
      "lat": number | null
      "lng": number | null
      "plantId": string
      "snmpEnableState": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED" (default "")
      "monitorMode": "full" | "ping" (default "full")
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "type": string | undefined
      "status": string | undefined
      "q": string | undefined
      "locationId": string | undefined
      "family": "network" | "radio" | "cameras" | "all" | undefined
      "page": number (default 1)
      "pageSize": number (default 50)
      "sort": "hostname" | "ip" | "type" | "status" | "signal" | "lastSeen" | "uptime" (default "hostname")
      "dir": "asc" | "desc" (default "asc")
    }
```

## GET /api/v2/devices/{id}/overview

Scheda apparato completa: identità, catena a monte, causa radice, impatto, metriche, collegamenti, eventi, allarmi, serie 24h.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "identity": object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "connectionType": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
      "dbStatus": string
      "statusReason": string | null
      "brand": string
      "model": string
      "antennaType": string
      "signalStrength": number
      "signalPresent": boolean
      "linkQuality": number
      "radioMode": string
      "linkMode": string
      "currentFrequency": string
      "ssid": string
      "macAddress": string
      "firmwareVersion": string
      "uptimeSeconds": number
      "cpuLoad": number
      "ramTotal": number (default 0)
      "ramUsed": number (default 0)
      "lastSeenAt": number | null
      "stale": boolean
      "monitored": boolean
      "locationId": string | null
      "locationName": string | null
      "lat": number | null
      "lng": number | null
      "plantId": string
      "snmpEnableState": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED" (default "")
      "monitorMode": "full" | "ping" (default "full")
    }
      "snmpActivation": object {
      "state": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED"
      "method": string
      "note": string
      "at": number | null
    }
      "parentChain": array<object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
    }>
      "rootCause": object {
      "id": string
      "hostname": string
      "ip": string
    } | null
      "impact": object {
      "devicesDownstream": number
      "camerasDownstream": number
      "offlineDownstream": number
    }
      "keyMetrics": array<object {
      "metric": string
      "value": number
      "unit": string | null
      "timestamp": number
    }>
      "camera": object {
      "streamAlive": boolean | null
      "lastStreamCheck": number | null
      "rttMs": number | null
    } | null
      "stations": array<object {
      "id": string
      "hostname": string
      "signalStrength": number | null
      "linkQuality": number
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
    }>
      "uplinkAp": object {
      "id": string
      "hostname": string
      "signalStrength": number | null
    } | null
      "links": array<object {
      "id": string
      "peerId": string | null
      "peerHostname": string
      "linkType": string
      "linkStatus": string
      "confidence": string
      "evidence": string
      "speedMbps": number
      "trafficInMbps": number
      "trafficOutMbps": number
      "trafficUpdatedAt": number | null
      "direction": "upstream" | "downstream"
    }>
      "recentEvents": array<object {
      "id": string
      "eventType": string
      "oldValue": string
      "newValue": string
      "source": string
      "createdAt": number
    }>
      "openAlerts": array<object {
      "id": string
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "message": string
      "openedAt": number
      "occurrenceCount": number
      "status": string
    }>
      "series": array<object {
      "metric": string
      "points": array<object {
      "t": number
      "v": number
    }>
    }>
    }
    }
```

## GET /api/v2/topology/graph

Albero topologico unico (computeNetworkTiers): nodi con tier, archi dello spanning tree, blocchi, irraggiungibili.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "plantId": string
      "gatewayId": string | null
      "rootSource": "operator" | "inferred" | "none"
      "sources": array<string>
      "linkStats": object {
      "total": number
      "included": number
      "excludedInferred": number
      "confirmedAlwaysIn": number
    }
      "nodes": array<object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
      "tier": number
      "parentId": string | null
      "locationId": string | null
      "locationName": string | null
      "model": string
      "signalDbm": number | null
      "linkQuality": number
      "downstreamCount": number
    }>
      "edges": array<object {
      "id": string
      "source": string
      "target": string
      "linkType": string
      "linkStatus": string
      "confidence": string
      "evidence": string
      "manual": boolean
      "speedMbps": number
      "trafficInMbps": number
      "trafficOutMbps": number
      "label": string
    }>
      "blocks": array<object {
      "level": number
      "label": string
      "nodeIds": array<string>
    }>
      "discardedAutoEdges": number
      "unreachableCount": number
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "sources": string | undefined
    }
```

## GET /api/v2/links/weak

Link radio più deboli per segnale di uplink (semantica STA=uplink, AP=stazione più debole).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": array<object {
      "deviceId": string
      "hostname": string
      "ip": string
      "type": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
      "signalDbm": number
      "health": "excellent" | "good" | "fair" | "poor" | "critical"
      "score": number
      "linkQuality": number
      "frequency": string
      "ssid": string
      "uplinkApHostname": string | null
      "locationName": string | null
      "lastSeenAt": number | null
    }>
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "limit": number (default 8)
    }
```

## GET /api/v2/events

Eventi dispositivo con paginazione a cursore (before).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "deviceId": string | null
      "deviceHostname": string | null
      "eventType": string
      "oldValue": string
      "newValue": string
      "source": string
      "createdAt": number
    }>
      "nextCursor": number | null
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "deviceId": string | undefined
      "limit": number (default 25)
      "before": number | undefined
    }
```

## GET /api/v2/alarms

Allarmi con filtri stato/severità/dispositivo/testo, ordinamento per gravità.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "ruleId": string
      "ruleName": string | null
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "status": "OPEN" | "ACK" | "ESCALATED" | "CLOSED" | "SUPPRESSED"
      "message": string
      "occurrenceCount": number
      "openedAt": number
      "acknowledgedAt": number | null
      "acknowledgedBy": string | null
      "closedAt": number | null
      "escalatedAt": number | null
      "deviceId": string | null
      "deviceHostname": string | null
      "deviceIp": string | null
      "deviceUiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED" | null
      "suppressedByRootCause": boolean
      "rootCauseHostname": string | null
      "ageMinutes": number
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "status": string | undefined
      "severity": string | undefined
      "deviceId": string | undefined
      "q": string | undefined
      "page": number (default 1)
      "pageSize": number (default 25)
    }
```

## POST /api/v2/alarms/{id}/ack

Presa in carico allarme (role ≥ TECNICO): scrive acknowledgedAt/By + voce di audit ALERT_ACK.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "ruleId": string
      "ruleName": string | null
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "status": "OPEN" | "ACK" | "ESCALATED" | "CLOSED" | "SUPPRESSED"
      "message": string
      "occurrenceCount": number
      "openedAt": number
      "acknowledgedAt": number | null
      "acknowledgedBy": string | null
      "closedAt": number | null
      "escalatedAt": number | null
      "deviceId": string | null
      "deviceHostname": string | null
      "deviceIp": string | null
      "deviceUiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED" | null
      "suppressedByRootCause": boolean
      "rootCauseHostname": string | null
      "ageMinutes": number
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
    }
    }
```
### Body
```
object {
      "note": string | undefined
    }
```

## GET /api/v2/cameras

Apparati video con stato flusso RTSP (cameraStreamAlive) e RTT; 16.3: filtro sede locationId (CSV di id, opzionale).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "connectionType": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
      "dbStatus": string
      "statusReason": string | null
      "brand": string
      "model": string
      "antennaType": string
      "signalStrength": number
      "signalPresent": boolean
      "linkQuality": number
      "radioMode": string
      "linkMode": string
      "currentFrequency": string
      "ssid": string
      "macAddress": string
      "firmwareVersion": string
      "uptimeSeconds": number
      "cpuLoad": number
      "ramTotal": number (default 0)
      "ramUsed": number (default 0)
      "lastSeenAt": number | null
      "stale": boolean
      "monitored": boolean
      "locationId": string | null
      "locationName": string | null
      "lat": number | null
      "lng": number | null
      "plantId": string
      "snmpEnableState": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED" (default "")
      "monitorMode": "full" | "ping" (default "full")
      "streamAlive": boolean | null
      "lastStreamCheck": number | null
      "rttMs": number | null
      "nvrHostname": string | null
      "rtspStream": string
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "q": string | undefined
      "stream": "all" | "down" | "unknown" | "alive" (default "all")
      "locationId": string | undefined
      "page": number (default 1)
      "pageSize": number (default 50)
    }
```

## GET /api/v2/cameras/streams

Registro flussi per apparato video (16.3, onda W2 residua): serie cameraStreamAlive sulla finestra analizzata (windowHours dichiarata nella risposta — ridotta a 48h se la serie richiesta supera ~120.000 campioni), uptime 24h/finestra calcolati solo sui campioni presenti (null = zero campioni), ultima transizione di valore, campioni e ultimo RTT reale.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "deviceId": string
      "hostname": string
      "type": string
      "locationId": string | null
      "locationName": string | null
      "streamAlive": boolean | null
      "lastCheck": number | null
      "lastChange": number | null
      "samples": number
      "uptime24h": number | null
      "uptime7d": number | null
      "rttMs": number | null
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
      "windowHours": number
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "q": string | undefined
      "stream": "alive" | "down" | "unknown" | undefined
      "locationId": string | undefined
      "page": number (default 1)
      "pageSize": number (default 25)
      "windowHours": number (default 168)
    }
```

## GET /api/v2/traffic/series

Serie traffico aggregata sul core di distribuzione (definizione D3 dichiarata nella risposta).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "definition": string
      "coreDeviceId": string | null
      "coreHostname": string | null
      "inMbps": array<object {
      "t": number
      "v": number
    }>
      "outMbps": array<object {
      "t": number
      "v": number
    }>
      "lastInMbps": number | null
      "lastOutMbps": number | null
      "lastSampleAt": number | null
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "hours": number (default 24)
    }
```

## GET /api/v2/search

Ricerca globale raggruppata: dispositivi, sedi, allarmi.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "devices": array<object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "uiStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED"
    }>
      "locations": array<object {
      "id": string
      "name": string
      "identifier": string
      "lat": number | null
      "lng": number | null
      "deviceCount": number
    }>
      "alarms": array<object {
      "id": string
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "message": string
      "deviceId": string | null
    }>
    }
    }
```
### Parametri query
```
object {
      "q": string
      "plantId": string | undefined
    }
```

## GET /api/v2/plants

Elenco impianti (16.10, riga ESTESA: comune, indirizzo, note, telegramChatId, kmzFile, mappa centro/zoom, pingIntervalSec, outageTimerMinutes, snmpCommunities, topologyRootDeviceId+hostname della radice scelta, conteggi reali dispositivi/sedi/ticket, createdAt). Perimetro v15: chi non è SUPER_ADMIN vede SOLO gli impianti assegnati (PlantAssignment); ?plantId → solo quello.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": array<object {
      "id": string
      "name": string
      "comune": string
      "address": string
      "notes": string
      "telegramChatId": string
      "kmzFile": string
      "isActive": boolean
      "mapCenterLat": number
      "mapCenterLng": number
      "mapZoom": number
      "pingIntervalSec": number
      "outageTimerMinutes": number
      "snmpCommunities": string
      "topologyRootDeviceId": string | null
      "topologyRootHostname": string | null
      "deviceCount": number
      "locationCount": number
      "ticketCount": number
      "createdAt": number
    }>
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
    }
```

## POST /api/v2/plants

Crea impianto (16.10, W8 — parità v15 /api/plants): atto amministrativo, role ≥ RESPONSABILE_COMUNE (v15 F-11). Default v15: mappa 41/14/zoom 14, ping 30 s, timer interruzione 5 min, isActive true. L’impianto nasce VUOTO: in riproduzione NESSUN job/poller viene registrato (D2, dichiarato in audit PLANT_CREATE). 422 con path per campi invalidi.

### Risposta
```
object {
      "id": string
      "name": string
      "comune": string
      "address": string
      "notes": string
      "telegramChatId": string
      "kmzFile": string
      "isActive": boolean
      "mapCenterLat": number
      "mapCenterLng": number
      "mapZoom": number
      "pingIntervalSec": number
      "outageTimerMinutes": number
      "snmpCommunities": string
      "topologyRootDeviceId": string | null
      "topologyRootHostname": string | null
      "deviceCount": number
      "locationCount": number
      "ticketCount": number
      "createdAt": number
    }
```
### Body
```
object {
      "name": string
      "comune": string
      "address": string | undefined
      "notes": string | undefined
      "telegramChatId": string | undefined
      "mapCenterLat": number | undefined
      "mapCenterLng": number | undefined
      "mapZoom": number | undefined
      "pingIntervalSec": number | undefined
      "outageTimerMinutes": number | undefined
      "snmpCommunities": string | undefined
      "isActive": boolean | undefined
    }
```

## PATCH /api/v2/plants/{id}

Modifica impianto (16.10, W8): whitelist campi gestibili + topologyRootDeviceId (v11.27: la radice SCELTA dall'operatore batte ogni euristica; il dispositivo deve appartenere ALL’impianto → 404; null esplicito = torna all'inferenza). Diff per campo → 422 NO_CHANGES se il payload non cambia nulla. Audit PLANT_UPDATE con diff.

### Risposta
```
object {
      "id": string
      "name": string
      "comune": string
      "address": string
      "notes": string
      "telegramChatId": string
      "kmzFile": string
      "isActive": boolean
      "mapCenterLat": number
      "mapCenterLng": number
      "mapZoom": number
      "pingIntervalSec": number
      "outageTimerMinutes": number
      "snmpCommunities": string
      "topologyRootDeviceId": string | null
      "topologyRootHostname": string | null
      "deviceCount": number
      "locationCount": number
      "ticketCount": number
      "createdAt": number
    }
```
### Body
```
object {
      "name": string | undefined
      "comune": string | undefined
      "address": string | undefined
      "notes": string | undefined
      "telegramChatId": string | undefined
      "mapCenterLat": number | undefined
      "mapCenterLng": number | undefined
      "mapZoom": number | undefined
      "pingIntervalSec": number | undefined
      "outageTimerMinutes": number | undefined
      "snmpCommunities": string | undefined
      "isActive": boolean | undefined
      "topologyRootDeviceId": string | null | undefined
    }
```

## DELETE /api/v2/plants/{id}

Elimina impianto (16.10, W8, SUPER_ADMIN only): guardia onesta 409 PLANT_NOT_EMPTY con conteggi reali (sedi/dispositivi/collegamenti/ticket/manutenzioni/KB) se contiene dati — l’impianto «egidio» con 200 dispositivi NON è cancellabile per errore. Un impianto VUOTO si elimina (assegnazioni utente incluse). Audit PLANT_DELETE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deleted": const [true]
      "id": string
    }
    }
```

## GET /api/v2/locations

Sedi con coordinate e conteggi per stato (vista mappa).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": array<object {
      "id": string
      "name": string
      "identifier": string
      "lat": number | null
      "lng": number | null
      "devices": number
      "online": number
      "degraded": number
      "offline": number
      "unknown": number
      "notMonitored": number
      "worstStatus": "ONLINE" | "DEGRADED" | "OFFLINE" | "MAINTENANCE" | "UNKNOWN" | "NOT_MONITORED" | null
      "cameraCount": number
    }>
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
    }
```

## GET /api/v2/system/health

Salute sistema: versione build, DB, stato riproduzione.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "version": string
      "dbReachable": boolean
      "realtimeUrl": string
      "replay": object {
      "enabled": boolean
      "importedAt": number | null
      "lastTickAt": number | null
      "nextTickAt": number | null
      "intervalSec": number
    }
      "lastDbWrite": number | null
    }
    }
```

## GET /api/v2/tickets

Ticket reali del DB con filtri stato/priorità/testo, paginazione e KPI globali dell'impianto (aperti, in lavorazione, risolti 7gg, SLA scaduti).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "title": string
      "description": string
      "status": string
      "priority": string
      "source": string
      "plantId": string
      "device": object {
      "id": string
      "hostname": string
      "ip": string
    } | null
      "locationName": string | null
      "assignedTo": string
      "rootCause": string
      "resolution": string
      "createdAt": number
      "updatedAt": number
      "resolvedAt": number | null
      "closedAt": number | null
      "slaResolutionDueAt": number | null
      "escalationLevel": number
      "interventionsCount": number
      "commentsCount": number
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
      "kpis": object {
      "open": number
      "inProgress": number
      "resolved7d": number
      "slaOverdue": number
    }
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "status": string | undefined
      "priority": string | undefined
      "q": string | undefined
      "page": number (default 1)
      "pageSize": number (default 25)
    }
```

## POST /api/v2/tickets

Creazione ticket reale (role ≥ TECNICO): source MANUAL, status OPEN, assegnazione all'operatore in sessione; audit TICKET_CREATE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "title": string
      "description": string
      "status": string
      "priority": string
      "source": string
      "plantId": string
      "device": object {
      "id": string
      "hostname": string
      "ip": string
    } | null
      "locationName": string | null
      "assignedTo": string
      "rootCause": string
      "resolution": string
      "createdAt": number
      "updatedAt": number
      "resolvedAt": number | null
      "closedAt": number | null
      "slaResolutionDueAt": number | null
      "escalationLevel": number
      "interventionsCount": number
      "commentsCount": number
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
      "kpis": object {
      "open": number
      "inProgress": number
      "resolved7d": number
      "slaOverdue": number
    }
    }
    }
```
### Body
```
object {
      "title": string
      "description": string
      "priority": "CRITICAL" | "HIGH"
      "deviceId": string | undefined
    }
```

## PATCH /api/v2/tickets/{id}

Macchina a stati del ticket: OPEN→IN_PROGRESS/CLOSED, IN_PROGRESS→RESOLVED (resolution obbligatoria), RESOLVED→CLOSED. Salti illegali → 422 INVALID_TRANSITION; audit TICKET_STATUS_CHANGE con nota e risoluzione.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "title": string
      "description": string
      "status": string
      "priority": string
      "source": string
      "plantId": string
      "device": object {
      "id": string
      "hostname": string
      "ip": string
    } | null
      "locationName": string | null
      "assignedTo": string
      "rootCause": string
      "resolution": string
      "createdAt": number
      "updatedAt": number
      "resolvedAt": number | null
      "closedAt": number | null
      "slaResolutionDueAt": number | null
      "escalationLevel": number
      "interventionsCount": number
      "commentsCount": number
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
      "kpis": object {
      "open": number
      "inProgress": number
      "resolved7d": number
      "slaOverdue": number
    }
    }
    }
```
### Body
```
object {
      "status": "IN_PROGRESS" | "RESOLVED" | "CLOSED" | undefined
      "resolution": string | undefined
      "assignedTo": string | undefined
      "note": string | undefined
    }
```

## GET /api/v2/maintenance

Finestre di manutenzione reali dell'impianto (scope gruppi con NOME, orari, validità, stato). Nel DB reale al 16.1 non ce ne erano: la prima arriva dalla POST.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "plantId": string
      "name": string
      "description": string
      "type": string
      "scheduleType": string
      "daysOfWeek": array<number>
      "dayOfMonth": number
      "startTime": string
      "endTime": string
      "activeSince": number
      "activeUntil": number | null
      "state": string
      "scopesCount": number
      "scopes": array<object {
      "groupId": string
      "name": string
    }>
    }>
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
    }
```

## POST /api/v2/maintenance

Creazione finestra di manutenzione reale (role ≥ TECNICO, 16.2): validazione zod completa (orari HH:mm, giorni 1-7 per WEEKLY, giorno 1-31 per MONTHLY, activeUntil nel futuro); 16.3 W3: groupIds OPZIONALE = scope su gruppi REALI del plant (422 con id offensori altrimenti) → MaintenanceWindowGroup in $transaction; audit MAINTENANCE_CREATE con scopes: [nomi gruppi reali] quando forniti.

### Risposta
```
object {
      "id": string
      "plantId": string
      "name": string
      "description": string
      "type": string
      "scheduleType": string
      "daysOfWeek": array<number>
      "dayOfMonth": number
      "startTime": string
      "endTime": string
      "activeSince": number
      "activeUntil": number | null
      "state": string
      "scopesCount": number
      "scopes": array<object {
      "groupId": string
      "name": string
    }>
    }
```
### Body
```
object {
      "name": string
      "description": string (default "")
      "type": "WITH_DATA" | "NO_DATA"
      "scheduleType": "ONCE" | "DAILY" | "WEEKLY" | "MONTHLY"
      "daysOfWeek": array<number> (default [])
      "dayOfMonth": number (default 1)
      "startTime": string
      "endTime": string
      "activeUntil": number | null (default null)
      "groupIds": array<string> | undefined
    }
```

## PATCH /api/v2/maintenance/{id}

Modifica finestra (role ≥ TECNICO, 16.3 W3, retrocompatibile): { state } da solo = pausa/ripresa con audit MAINTENANCE_STATE (16.2); campi name/description/type/scheduleType/daysOfWeek/dayOfMonth/startTime/endTime/activeUntil/groupIds con refine almeno-uno, validazione semantica sulla COMBINAZIONE con la finestra esistente (orari diversi, WEEKLY → giorni non vuoti, activeUntil futuro o null); groupIds = sostituzione integrale degli scope; patch senza effetto → 422 NO_CHANGES; audit MAINTENANCE_UPDATE con diff {campo: from→to} + scopes {added, removed}.

### Risposta
```
object {
      "id": string
      "plantId": string
      "name": string
      "description": string
      "type": string
      "scheduleType": string
      "daysOfWeek": array<number>
      "dayOfMonth": number
      "startTime": string
      "endTime": string
      "activeSince": number
      "activeUntil": number | null
      "state": string
      "scopesCount": number
      "scopes": array<object {
      "groupId": string
      "name": string
    }>
    }
```
### Body
```
object {
      "state": "ACTIVE" | "PAUSED" | undefined
      "name": string | undefined
      "description": string | undefined
      "type": "WITH_DATA" | "NO_DATA" | undefined
      "scheduleType": "ONCE" | "DAILY" | "WEEKLY" | "MONTHLY" | undefined
      "daysOfWeek": array<number> | undefined
      "dayOfMonth": number | undefined
      "startTime": string | undefined
      "endTime": string | undefined
      "activeUntil": number | null | undefined
      "groupIds": array<string> | undefined
    }
```

## DELETE /api/v2/maintenance/{id}

Eliminazione finestra di manutenzione (role ≥ TECNICO, 16.2): audit MAINTENANCE_DELETE; gli Intervention collegati restano nel registro (schema onDelete: SetNull), i gruppi collegati vengono rimossi a cascata.

### Risposta
```
object {
      "id": string
    }
```

## GET /api/v2/device-groups

Gruppi di dispositivi del plant (16.3/16.4 W3), name asc. MANUAL: membri dalla relazione (cap onesto: primi 500, memberCount = totale reale). DYNAMIC (16.4): membership CALCOLATA a runtime dalla ruleJson sullo stato reale dei dispositivi (non salvata, ricalcolata a ogni lettura; ruleType + rules in ogni riga). NESSUNA paginazione: i gruppi sono poche decine. DB reale: parte da 0 gruppi → items: [] total: 0 (onesto).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "description": string
      "color": string
      "ruleType": "MANUAL" | "DYNAMIC"
      "rules": object {
      "deviceTypes": array<string> | undefined
      "statuses": array<string> | undefined
      "connectionTypes": array<string> | undefined
      "locationIds": array<string> | undefined
    } | null
      "memberCount": number
      "members": array<object {
      "id": string
      "hostname": string
      "type": string
      "locationName": string | null
    }>
    }>
      "total": number
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
    }
```

## POST /api/v2/device-groups

Creazione gruppo di dispositivi reale (role ≥ TECNICO, 16.3/16.4 W3): ruleType opzionale — assente = MANUAL (retrocompat 16.3); MANUAL → deviceIds opzionali deduplicati, tutti esistenti e nello scope del plant (OR location.plantId / locationId null, come /devices) → 422 con lista id offensori (max 5); DYNAMIC → rules OBBLIGATORIE (refine del contratto) e deviceIds VIETATI, valori della regola validati contro i dati REALI del plant (tipi/stati/connessioni distinti dell'inventario, sedi del plant) → 422 con offensori per criterio. Name univoco per plant (check in $transaction → 422 GROUP_EXISTS); audit DEVICE_GROUP_CREATE in $transaction (con ruleType, regola e conteggio membri — calcolato per i DYNAMIC); 201 con la riga creata (membership ricalcolata per i DYNAMIC).

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "color": string
      "ruleType": "MANUAL" | "DYNAMIC"
      "rules": object {
      "deviceTypes": array<string> | undefined
      "statuses": array<string> | undefined
      "connectionTypes": array<string> | undefined
      "locationIds": array<string> | undefined
    } | null
      "memberCount": number
      "members": array<object {
      "id": string
      "hostname": string
      "type": string
      "locationName": string | null
    }>
    }
```
### Body
```
object {
      "name": string
      "description": string | undefined
      "color": string | undefined
      "ruleType": "MANUAL" | "DYNAMIC" | undefined
      "rules": object {
      "deviceTypes": array<string> | undefined
      "statuses": array<string> | undefined
      "connectionTypes": array<string> | undefined
      "locationIds": array<string> | undefined
    } | undefined
      "deviceIds": array<string> | undefined
    }
```

## PATCH /api/v2/device-groups/{id}

Modifica gruppo (role ≥ TECNICO, 16.3/16.4 W3): campi opzionali con refine almeno-uno; name cambiato → univocità per plant verificata in $transaction (escluso il gruppo stesso) → 422 GROUP_EXISTS; deviceIds presente = SOSTITUZIONE INTEGRALE della membership (SOLO MANUAL: su un DYNAMIC → 422 RULE_TYPE); rules presente = SOSTITUZIONE INTEGRALE della regola (SOLO DYNAMIC: su un MANUAL → 422 RULE_TYPE; valori validati contro i dati reali → 422 con offensori); ruleType nel corpo → 422 RULE_TYPE_IMMUTABLE (check sul corpo grezzo); patch senza alcun effetto → 422 NO_CHANGES (anche regola identica, confronto normalizzato); audit DEVICE_GROUP_UPDATE con diff sintetico {name?/description?/color? from→to, members {added, removed}, rules {from, to}}; 404 se inesistente.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "color": string
      "ruleType": "MANUAL" | "DYNAMIC"
      "rules": object {
      "deviceTypes": array<string> | undefined
      "statuses": array<string> | undefined
      "connectionTypes": array<string> | undefined
      "locationIds": array<string> | undefined
    } | null
      "memberCount": number
      "members": array<object {
      "id": string
      "hostname": string
      "type": string
      "locationName": string | null
    }>
    }
```
### Body
```
object {
      "name": string | undefined
      "description": string | undefined
      "color": string | undefined
      "rules": object {
      "deviceTypes": array<string> | undefined
      "statuses": array<string> | undefined
      "connectionTypes": array<string> | undefined
      "locationIds": array<string> | undefined
    } | undefined
      "deviceIds": array<string> | undefined
    }
```

## DELETE /api/v2/device-groups/{id}

Eliminazione gruppo (role ≥ TECNICO, 16.3/16.4 W3): conta PRIMA i membri (righe per i MANUAL, CALCOLATI dalla regola per i DYNAMIC) e le finestre che lo usano come scope; delete in $transaction con audit DEVICE_GROUP_DELETE {name, ruleType, members|rules+computedMembers, removedScopes}; le finestre NON vengono eliminate (perdono solo questo scope, cascade su MaintenanceWindowGroup); risponde {id, removedScopes}.

### Risposta
```
object {
      "id": string
      "removedScopes": number
    }
```

## GET /api/v2/reports/availability

Report disponibilità di rete (16.4, W2 residua): dalla serie REALE packetLoss (disponibilità = 100 − perdita media; congelata alla fine del prelievo reale: copertura effettiva DICHIARATA con coverageFrom/coverageTo, righe senza campioni → valori null = «n.d.», mai 100% inventato). pingLatency come statistiche supplementari (media/max ms, NON fonte di disponibilità). slaTargetsDefined = conteggio reale di SLADefinition del plant (0 nel DB reale: nessuna soglia applicata). Scope dispositivi come /devices (host scoperti compresi), items per hostname asc, NESSUNA paginazione (impianto reale: 200 attivi).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "deviceId": string
      "hostname": string
      "type": string
      "dbStatus": string
      "locationId": string | null
      "locationName": string | null
      "lossSamples": number
      "lossAvgPct": number | null
      "lossMaxPct": number | null
      "availabilityPct": number | null
      "firstSampleAt": number | null
      "lastSampleAt": number | null
      "pingSamples": number
      "pingAvgMs": number | null
      "pingMaxMs": number | null
    }>
      "byLocation": array<object {
      "locationId": string | null
      "locationName": string | null
      "devices": number
      "withData": number
      "withoutData": number
      "availabilityAvgPct": number | null
      "availabilityMinPct": number | null
      "worstHostname": string | null
      "lossSamples": number
      "coverageFrom": number | null
      "coverageTo": number | null
    }>
      "total": number
      "windowHours": number
      "coverageFrom": number | null
      "coverageTo": number | null
      "slaTargetsDefined": number
    }
    }
```
### Parametri query
```
object {
      "windowHours": number (default 48)
      "plantId": string | undefined
    }
```

## GET /api/v2/devices/{id}/ports

Tabella per porta «cosa c'è su ogni porta» (16.5.0, W3-proroga — parità v15 G3), SOLO dati REALI del DB in union di tre fonti (nessuna porta inventata): (1) TopologyLink lato source E target → collegato a (hostname/IP/type dell'altro capo), evidenza/confidenza della ricostruzione, speedMbps/duplex come dati del LINK (velocità negoziata STORICA, non lettura live — per porta il link migliore: confermati > confidenza > evidenza > peer infra); (2) FdbObservation → macsSeen per porta + elenco dei primi 20 MAC per porta (ultima osservazione prima) con risoluzione inventario (Device.macAddress + extraMacs normalizzati; non risolto → hostname null = «non in inventario»; NESSUN database OUI — D20: produttore non esposto); (3) serie MetricValue «port_utilization:<porta>» → ultimo campione + copertura REALE della serie dichiarata in summary.windowDeclared.utilCoverage. uplink = peer INFRA secondo INFRA_TYPES di tiers.ts (GATEWAY/ROUTER/FIREWALL/SWITCH/AP/BRIDGE/REPEATER — la stessa classificazione dell'albero unico; STA escluse, differenza dichiarata da v15). Ordinamento: uplink prima, poi macsSeen desc, poi nome porta. summary: totalPorts/portsWithMacs/macsTotal/resolvedCount/unattachedMacs (MAC su porte senza link) + windowDeclared {fdbLastSeenAt, utilCoverage}. Nessuna delle tre fonti (es. non-switch) → ports=[] + summary a zero (onesto). 401 senza sessione; 404 dispositivo assente/fuori plant. Stato live/velocità corrente/PoE richiedono SNMP: fuori replay, dichiarato in UI.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "ports": array<object {
      "portName": string
      "macsSeen": number
      "connectedTo": object {
      "deviceId": string
      "hostname": string
      "type": string
      "ip": string | null
    } | null
      "evidence": string | null
      "confidence": string | null
      "speedMbps": number
      "duplex": string
      "utilization": object {
      "last": number
      "at": number
    } | null
      "uplink": boolean
      "macs": array<object {
      "mac": string
      "display": string
      "resolved": boolean
      "hostname": string | null
      "deviceId": string | null
      "deviceType": string | null
      "lastSeenAt": number
    }>
      "stp": object {
      "portState": string
      "designatedBridgeMac": string
      "isRootPort": boolean
    } | null | undefined
    }>
      "summary": object {
      "totalPorts": number
      "portsWithMacs": number
      "macsTotal": number
      "resolvedCount": number
      "unattachedMacs": number
      "windowDeclared": object {
      "fdbLastSeenAt": number | null
      "utilCoverage": object {
      "from": number
      "to": number
    } | null
    }
    }
    }
    }
```

## GET /api/v2/mac-inventory

Inventario MAC — FDB × inventario (16.5.0, W4 anticipata perché il dato REALE esiste): ogni riga è UNA osservazione FDB (apparato · porta · MAC · ultima volta visto) con risoluzione verso l'inventario (Device.macAddress + extraMacs normalizzati, primo vincente; non risolto → hostname null; nessun OUI — D20). Filtri: q (sottostringa su MAC o hostname risolto), switchId (apparato che ha visto il MAC), scope (all|resolved|unresolved), sort (lastSeen desc | mac asc | hostname asc con non-risolti in coda). Paginazione reale (page ≥ 1, pageSize 10–200 default 25; total DOPO i filtri). switches = apparati con osservazioni FDB reali (id+hostname, per il filtro). summary GLOBALE (prima dei filtri, dichiarato): resolvedCount/unresolvedCount sull'intero dataset + lastSeenMax (serie congelata: la UI dichiara la copertura). Lettura pura, nessun dato inventato.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "mac": string
      "macDisplay": string
      "switchId": string
      "switchHostname": string
      "portName": string
      "lastSeenAt": number
      "resolved": boolean
      "hostname": string | null
      "deviceId": string | null
      "deviceType": string | null
      "arpIp": string | null (default "")
    }>
      "total": number
      "page": number
      "pageSize": number
      "pageCount": number
      "switches": array<object {
      "id": string
      "hostname": string
    }>
      "summary": object {
      "resolvedCount": number
      "unresolvedCount": number
      "lastSeenMax": number | null
    }
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "page": number (default 1)
      "pageSize": number (default 25)
      "q": string | undefined
      "switchId": string | undefined
      "scope": "all" | "resolved" | "unresolved" (default "all")
      "sort": "lastSeen" | "mac" | "hostname" (default "lastSeen")
    }
```

## GET /api/v2/audit

Registro audit più recente (id, azione, autore, oggetto, data/ora): i dettagli NON vengono esposti (possono contenere payload di azioni SYSTEM).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "action": string
      "actor": string
      "targetLabel": string | null
      "createdAt": number
    }>
      "total": number
      "returned": number
    }
    }
```
### Parametri query
```
object {
      "action": string | undefined
      "limit": number (default 50)
    }
```

## GET /api/v2/admin/stats

Conteggi reali del DB per la vista Amministrazione: entità, allarmi, ticket per stato, campioni metriche, polling, copertura topologica.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "devices": number
      "locations": number
      "plants": number
      "alertsOpen": number
      "alertsSuppressed": number
      "ticketsByStatus": record<string, number>
      "ticketsTotal": number
      "maintenanceWindows": number
      "auditLogEntries": number
      "metricSamples": number
      "pollingSchedules": number
      "coveragePct": number | null
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
    }
```

## GET /api/v2/discovery/health

Stato del motore di scansione (16.6.0, W3.4 — motori v15 portati nel mini-service :3002): proxy pass-through con auth a monte. capabilities = tcp-scan, snmp-v2c-v3, onvif, oui, ubiquiti-udp, mndp, ws-discovery; oui = database IEEE portato da v15 (10.679 prefissi, 101 brand — la decisione D20 «nessun OUI» valeva per i dati congelati: qui il motore REALE v15 è ripristinato come capacità viva). Servizio spento → 503 SERVICE_DOWN (onesto, il NOC continua).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "service": string
      "uptimeSec": number
      "version": string
      "capabilities": array<string>
      "oui": object {
      "total": number
      "brands": number
    }
    }
    }
```

## POST /api/v2/discovery/scan

Scansione di rete (16.6.0, W3.4): sweep TCP-connect multi-porta portato da v15 (pingHost agents/core.ts: UP = almeno una porta risponde, latenza = minima). CIDR IPv4 fino a 256 host (oltre → 400 TOO_LARGE dal servizio); porte opzionali (assente = set v15 [80,443,554,8080,8291,37777,34567,22,161,5000,8899]), timeoutMs 100–3000. Risposta: SOLO host vivi (rete muta = lista vuota onesta) + summary. Audit DISCOVERY_SCAN (chi/quale intervallo/esito). Ambiente sandbox: raggiunge solo 127.0.0.1; in produzione opera sulla rete dell'impianto.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "cidr": string
      "adaptive": boolean | undefined
      "durationMs": number
      "hosts": array<object {
      "ip": string
      "alive": const [true]
      "latencyMs": number
      "secondPass": boolean | undefined
      "openPorts": array<object {
      "port": number
      "state": string
    }>
    }>
      "summary": object {
      "scanned": number
      "up": number
      "withOpenPorts": number
      "slowHosts": number | undefined
    }
    }
    }
```
### Body
```
object {
      "cidr": string
      "ports": array<number> | undefined
      "timeoutMs": number | undefined
      "maxHosts": number | undefined
      "adaptive": boolean | undefined
    }
```

## POST /api/v2/discovery/probe

Sonda combinata «che apparato è questo IP» (16.6.0, W3.4): port-scan set v15 + banner HTTP + SNMP v1/v2c/v3 (sysDescr/sysObjectID/sysName/ifCount, vendor da enterprise OID — 48 voci v15) + ONVIF GetDeviceInformation (WS-Security digest, fallback 8899) + OUI da ifPhysAddress. Fusione evidenze priorità v15: ONVIF > SNMP > banner > porte → classification {type, brand, model, confidence, evidence[]}. NESSUNA scrittura su DB (adozione = azione umana su /api/v2/adozione). Host muto = alive:false con evidenze vuote (onesto).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "ip": string
      "alive": boolean
      "latencyMs": number | null
      "slowHost": boolean | undefined
      "openPorts": array<object {
      "port": number
      "state": string
    }>
      "http": object {
      "server": string | null
      "title": string | null
      "realm": string | undefined | null
      "certCn": string | undefined | null
      "certIssuer": string | undefined | null
    } | null
      "snmp": object {
      "reachable": boolean
      "matched": object {
      "community": string
      "version": string
    } | undefined | null
      "sysDescr": string | undefined | null
      "sysObjectID": string | undefined | null
      "sysName": string | undefined | null
      "ifCount": number | undefined | null
      "vendorGuess": object {
      "vendor": string
      "source": string
    } | undefined | null
      "product": object {
      "osFamily": string | null
      "osVersion": string | null
      "model": string | null
      "source": string
    } | undefined | null
      "error": string | undefined
    } | null
      "onvif": object {
      "reachable": boolean
      "manufacturer": string | undefined | null
      "model": string | undefined | null
      "firmwareVersion": string | undefined | null
      "serialNumber": string | undefined | null
      "hardwareId": string | undefined | null
      "error": string | undefined
    } | null
      "oui": object {
      "mac": string
      "vendor": string
      "category": string
    } | null
      "classification": object {
      "type": string
      "brand": string | null
      "model": string | null
      "confidence": "high" | "medium" | "low"
      "os": string | null | undefined
      "osVersion": string | null | undefined
      "firmwareVersion": string | null | undefined
      "evidence": array<object {
      "source": string
      "value": string
    }>
    }
    }
    }
```
### Body
```
object {
      "ip": string
      "snmp": object {
      "community": string | undefined
      "communities": array<string> | undefined
      "version": "v1" | "v2c" | "v3" | undefined
    } | undefined
      "onvif": object {
      "user": string | undefined
      "pass": string | undefined
    } | undefined
      "timeoutMs": number | undefined
    }
```

## GET /api/v2/discovery/oui

Lookup MAC → vendor IEEE (16.6.0, W3.4): database OUI v15 completo (10.679 prefissi, longest-prefix MA-S 36 → MA-M 28 → MA-L 24). MAC assente → 404 onesto. Formato AA:BB:CC:DD:EE:FF.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "mac": string
      "prefix": string
      "vendor": string
      "category": string
      "blockType": string
    }
    }
```
### Parametri query
```
object {
      "mac": string
    }
```

## POST /api/v2/discovery/snmp-enable/plan

PREVIEW attivazione SNMP assistita (16.18 W19, role ≥ TECNICO): ricetta per-vendor scelta su marca/modello/tipo DELL'INVENTARIO (o override umano) con comandi INTERPOLATI in chiaro, confidenza (verified/high/medium) e fonte citata, alternative, presenza credenziali cifrate (username mostrato, password MAI). Zero scritture, zero contatti con l'apparato. Dispositivo dismesso → 422 DECOMMISSIONED.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "device": object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "brand": string
      "model": string
      "snmpPort": number
      "snmpEnableState": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED"
      "monitorMode": "full" | "ping"
      "hasSavedCredentials": boolean
      "savedUsername": string
    }
      "picked": string
      "pingOnly": boolean
      "recipe": object {
      "recipeId": string
      "vendor": string
      "family": string
      "transport": "ssh" | "http-swos" | "manual" | "ping-only"
      "confidence": "verified" | "high" | "medium"
      "source": string
      "note": string
      "webPath": string | null
      "steps": array<object {
      "cmd": string
      "note": string | null
      "fatal": boolean
      "benign": string | null
    }>
      "manualSteps": array<string>
    }
      "alternatives": array<object {
      "recipeId": string
      "label": string
      "transport": string
    }>
    }
    }
```
### Body
```
object {
      "deviceId": string
      "recipeId": string | undefined
      "community": string | undefined
      "contact": string | undefined
      "location": string | undefined
    }
```

## POST /api/v2/discovery/snmp-enable

ESEGUI la ricetta confermata (16.18 W19, role ≥ TECNICO): trasporti ssh/http-swos contattano l'apparato con credenziali della finestra OPPURE decifrate dal dispositivo; ricette ping-only (telecamere → monitorMode=ping) e manual (→ MANUAL_REQUIRED) sono DICHIARAZIONI senza alcun contatto. Verifica finale con la sonda (ENABLED solo se risponde davvero, altrimenti ENABLED_UNVERIFIED); community di lettura salvata CIFRATA AES-256-GCM se ENABLED; stati persistiti sul Device; audit DEVICE_SNMP_ENABLE con sola sintesi (mai password/community). 422 SSH_CREDS_REQUIRED/SWOS_CREDS_REQUIRED se credenziali assenti (nessun comando eseguito).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "recipeId": string
      "transport": "ssh" | "http-swos" | "manual" | "ping-only"
      "applied": boolean
      "steps": array<object {
      "step": string
      "note": string | null
      "ok": boolean
      "exitCode": number | null
      "output": string
      "benign": boolean
    }>
      "verify": object {
      "reachable": boolean
      "matchedCommunity": string | null
      "sysName": string | null
      "sysDescr": string | null
      "error": string | null
    }
      "state": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED"
      "notes": array<string>
      "persisted": object {
      "snmpEnableState": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED"
      "snmpEnableMethod": string
      "monitorMode": "full" | "ping"
      "communitySaved": boolean
    }
    }
    }
```
### Body
```
object {
      "deviceId": string
      "recipeId": string
      "community": string (default "public")
      "contact": string (default "FALCO-OS")
      "location": string (default "")
      "snmpPort": number | undefined
      "ssh": object {
      "port": number | undefined
      "username": string
      "password": string
    } | undefined
      "swos": object {
      "port": number | undefined
      "username": string (default "admin")
      "password": string (default "")
    } | undefined
    }
```

## POST /api/v2/discovery/snmp-enable/verify

Riverifica post-attivazione (16.18 W19, role ≥ TECNICO): sonda read-only con le community del dispositivo (cifrata + public). Riuscita → promuove a ENABLED (e salva cifrata la community trovata); fallita NON retrocede MAI uno stato applicato (i comandi restano applicati). Audit DEVICE_SNMP_VERIFY.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deviceId": string
      "reachable": boolean
      "matchedCommunity": string | null
      "sysName": string | null
      "sysDescr": string | null
      "error": string | null
      "snmpEnableState": "" | "ENABLED" | "ENABLED_UNVERIFIED" | "FAILED" | "MANUAL_REQUIRED"
    }
    }
```
### Body
```
object {
      "deviceId": string
    }
```

## POST /api/v2/monitoring/ping

Spazzata di presenza (16.18 W19, role ≥ TECNICO) sui dispositivi monitorMode=ping del plant attivo (o UNO per deviceId): sonda /probe/ping del mini-service (TCP-adattiva, porta di gestione per target, N≤64), campioni REALI pingLatency/packetLoss scritti (storia online/offline che alimenta disponibilità e storico), stato aggiornato con onestà (muto = OFFLINE + loss 100). Nessun ping-mode → lista vuota onesta; deviceId non ping-mode → 422 NOT_PING_MODE. Audit MONITOR_PING_SWEEP.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "swept": number
      "alive": number
      "durationMs": number
      "results": array<object {
      "deviceId": string
      "hostname": string
      "ip": string
      "port": number
      "alive": boolean
      "latencyMs": number | null
      "dbStatus": string
      "newStatus": string
      "samplesWritten": number
    }>
    }
    }
```
### Body
```
object {
      "deviceId": string | undefined
    }
```

## POST /api/v2/discovery/radio

Sonda telemetria RADIO (16.19 W20): SNMP su un apparato AP/STA con OID MikroTik 14988.1.1.1 + Ubiquiti airMAX 41112 + IF-MIB/BRIDGE-MIB/HOST-RESOURCES/UCD-SNMP — SSID, segnale dBm, CCQ, SNR, frequenza, tx/rx rate, linkMode (classificazione AP/PTP/PTMP), CPU/RAM, porte con speed/duplex, MAC; ogni campo con PROVENANCE OID; valori LETTI persistiti su Device + MetricValue (campioni reali, mai dichiarativi); audit DEVICE_RADIO_PROBE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "device": object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
    }
      "reachable": boolean
      "sysName": string | null
      "sysDescr": string | null
      "matched": object {
      "community": string
      "version": string
    } | null
      "error": string | null
      "detail": string | null
      "health": object {
      "cpuLoadPct": number | null
      "ramUsedKb": number | null
      "ramTotalKb": number | null
      "provenance": array<object {
      "field": string
      "oid": string
      "label": string
      "confidence": "verified" | "high" | "medium"
    }>
    }
      "radios": array<object {
      "index": number
      "ssid": string | null
      "band": string | null
      "frequencyMhz": number | null
      "signalDbm": number | null
      "noiseFloorDbm": number | null
      "snrDb": number | null
      "txRateMbps": number | null
      "rxRateMbps": number | null
      "ccqPercent": number | null
    }>
      "clients": array<object {
      "mac": string | null
      "signalDbm": number | null
      "txRateMbps": number | null
      "rxRateMbps": number | null
      "lastIp": string | null
    }>
      "ports": array<object {
      "ifIndex": number
      "name": string | null
      "speedMbps": number | null
      "duplex": "full" | "half" | null
    }>
      "provenance": array<object {
      "field": string
      "oid": string
      "label": string
      "confidence": "verified" | "high" | "medium"
    }>
      "derived": object {
      "radioMode": "ap" | "sta" | "" | null
      "linkMode": "PTP" | "PTMP" | "" | null
      "note": string
    }
      "persisted": object {
      "cpuLoad": boolean
      "ram": boolean
      "ssid": boolean
      "signalStrength": boolean
      "linkQuality": boolean
      "currentFrequency": boolean
      "radioMode": boolean
      "uptimeSeconds": boolean
      "metricsSaved": number
      "snmpEnableState": string
    }
      "warnings": array<string>
      "notes": array<string>
    }
    }
```
### Body
```
object {
      "plantId": string | undefined
      "deviceId": string
      "communities": array<string> | undefined
      "timeoutMs": number | undefined
    }
```

## POST /api/v2/setup/scan

FASE 2 del wizard setup (16.19 W21, role ≥ TECNICO): sweep TCP sul CIDR dell'impianto + identificazione batch (SNMP multi-community, banner HTTP, OUI) con job PERSISTITO (DiscoveryJob) e CONFRONTO con l'inventario dichiarato in Excel: confermati / mancanti (dichiarati e non visti — restano a libro) / nuovi (visti e non adottati). Scansione READ-ONLY sull'inventario: NESSUNA scrittura di Device. Audit SETUP_SCAN.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "jobId": string
      "cidr": string
      "scanned": number
      "up": number
      "durationMs": number
      "identified": number
      "candidates": array<object {
      "ip": string
      "alive": boolean
      "latencyMs": number | null
      "openPorts": array<number>
      "snmp": object {
      "reachable": boolean
      "matchedCommunity": string | null
      "sysName": string | null
      "sysDescr": string | null
      "mac": string | null
      "vendor": string | null
      "model": string | null
      "osFamily": string | null
      "snmpPort": number
    }
      "http": object {
      "server": string | null
      "title": string | null
    } | null
      "classification": object {
      "type": string
      "brand": string | null
      "model": string | null
      "confidence": string
      "evidenceCount": number
    }
      "inInventory": boolean
      "deviceId": string | null
      "deviceHostname": string | null
      "suggestedType": string
      "suggestedMonitorMode": "full" | "ping"
      "suggestionReason": string
    }>
      "comparison": object {
      "confirmed": number
      "missing": number
      "newSeen": number
      "missingIps": array<string>
    }
      "warnings": array<string>
    }
    }
```
### Body
```
object {
      "plantId": string | undefined
      "cidr": string
      "ports": array<number> | undefined
      "communities": array<string> | undefined
      "snmpPort": number | undefined
      "httpPort": number | undefined
      "timeoutMs": number | undefined
    }
```

## POST /api/v2/setup/verify

FASE 3 del wizard setup (16.19 W21, role ≥ TECNICO): verifica credenziali PER APPARATO con sonde reali — monitorMode=full → SNMP multi-community (community CIFRATA del device → CSV impianto → public) + LOGIN SSH (solo autenticazione, nessun comando); monitorMode=ping → presenza TCP-adattiva (TLC: «solo ping»). Esiti onesti per apparato: OK / WRONG / MISSING / UNKNOWN; porta verificata e community nuova salvate CIFRATE; MAC letto (ifPhysAddress) salvato se l'inventario non lo conosceva.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "devices": array<object {
      "deviceId": string
      "hostname": string
      "ip": string
      "type": string
      "monitorMode": "full" | "ping"
      "snmp": object {
      "tried": boolean
      "reachable": boolean
      "matchedCommunity": string | null
      "sysName": string | null
      "error": string | null
    }
      "ssh": object {
      "tried": boolean
      "authenticated": boolean | null | undefined
      "error": string | null | undefined
    }
      "ping": object {
      "tried": boolean
      "alive": boolean | null | undefined
      "latencyMs": number | null
    }
      "credentialState": string
      "credentialReason": string
      "macRead": string | null
      "communitySaved": boolean
    }>
      "summary": object {
      "total": number
      "snmpOk": number
      "snmpMute": number
      "sshOk": number
      "sshFailed": number
      "pingAlive": number
      "pingMute": number
      "credentialsOk": number
      "credentialsWrong": number
      "credentialsMissing": number
      "credentialsUnknown": number
    }
      "durationMs": number
      "warnings": array<string>
    }
    }
```
### Body
```
object {
      "plantId": string | undefined
      "snmpPort": number | undefined
      "sshPort": number | undefined
      "httpPort": number | undefined
    }
```

## POST /api/v2/setup/adopt

FASE 4 del wizard setup (16.19 W21, role ≥ TECNICO): riprende l'ultimo job di scansione COMPLETATO e per OGNI candidato vivo non in inventario crea il Device con l'EVIDENZA della scansione (MAC, brand/modello, community CIFRATA della community che ha risposto, snmpEnableState ENABLED quando SNMP ha parlato, monitorMode ping per i TLC, baselineUntil +24 h anti falsi allarmi, requiresConfirmation per impianti SENSIBILI). SKIP onesto per IP già in inventario (pattern LibreNMS) e per IP esclusi. La SEDE resta decisione umana: i nuovi arrivano ORFANI. Audit SETUP_ADOPT.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "created": array<object {
      "deviceId": string
      "hostname": string
      "ip": string
      "type": string
      "monitorMode": string
      "macAddress": string
      "brand": string
      "snmpEnabled": boolean
      "baselineUntil": number | null
    }>
      "skipped": array<object {
      "ip": string
      "reason": string
    }>
      "orphansAfter": number
      "comparison": object {
      "confirmed": number
      "missing": number
      "newSeen": number
      "adoptedNow": number
      "missingIps": array<string>
    }
      "warnings": array<string>
    }
    }
```
### Body
```
object {
      "plantId": string | undefined
      "jobId": string | undefined
      "overrides": array<object {
      "ip": string
      "type": string | undefined
      "monitorMode": "full" | "ping" | undefined
    }> | undefined
      "skipIps": array<string> | undefined
      "note": string | undefined
    }
```

## POST /api/v2/setup/alarms

FASE 6 del wizard setup (16.19 W21, role ≥ TECNICO): (1) assicura sul plant LE 6 REGOLE richieste (SYS:LOW_SIGNAL segnale scarso, SYS:DEVICE_DOWN dispositivo offline, SYS:PORT_STATE_CHANGE porta cambia stato, SYS:TOPOLOGY_CHANGE rete che cambia alberatura, SYS:NEW_HOST nuovi dispositivi non adottati, SYS:NEW_DEVICE_SEEN nuovi apparati visti) — upsert idempotente per (plantId, systemKey), soglia segnale tarabile; (2) VALUTAZIONE ONE-SHOT sui dati reali (segnaletica, presenza, orfani, link recenti) → AlertEvent APERTI con dedup (stessa regola+dispositivo+finestra = conta, non duplica).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "rules": array<object {
      "systemKey": string
      "name": string
      "enabled": boolean
      "metric": string
      "threshold": number | null
      "severity": string
      "justCreated": boolean
    }>
      "events": array<object {
      "eventId": string
      "systemKey": string
      "severity": string
      "deviceId": string | null
      "deviceHostname": string | null
      "message": string
      "deduplicated": boolean
    }>
      "evaluated": object {
      "devicesChecked": number
      "signalLow": number
      "offline": number
      "orphansNew": number
      "topologyLinksFresh": number
      "portStateBaseline": number
    }
      "honestNotes": array<string>
    }
    }
```
### Body
```
object {
      "plantId": string | undefined
      "signalThresholdDbm": number | undefined
    }
```

## GET /api/v2/setup/summary

FASE 7 del wizard setup (16.19 W21): la verifica globale ALLA CHIUSURA — TUTTO contato dal DB reale e dai servizi reali: importPhase (sedi, apparati per tipo, con credenziali), scanPhase (ultimo job, candidati visti/nuovi), verifyPhase (credenziali OK/sbagliate/missing/unknown, SNMP attivi, pingMode), telemetryPhase (sonde radio/L2/ping, campioni 2 h, online/offline), topologyPhase (link con fonte, FDB/ARP/STP/VLAN, MAC noti vs visti-non-in-inventario, vendor sconosciuti con hostname), alarmsPhase (regole attive, eventi aperti per severità), engines (discovery, realtime, puller con cicli/campioni/eventi/notifiche, dbReachable, apiReachable) + note oneste di chiusura.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "plant": object {
      "id": string
      "name": string
      "comune": string
      "criticalityLevel": string
      "kmzFile": string
      "createdAt": number
    }
      "importPhase": object {
      "locations": number
      "devicesInInventory": number
      "devicesByType": array<object {
      "type": string
      "count": number
    }>
      "devicesWithSshCredentials": number
    }
      "scanPhase": object {
      "lastJob": object {
      "id": string
      "subnet": string
      "status": string
      "hostsScanned": number
      "devicesFound": number
      "startedAt": number
      "finishedAt": number | null
    } | null
      "candidatesSeen": number
      "candidatesInInventory": number
      "candidatesNew": number
    }
      "verifyPhase": object {
      "credentialsOk": number
      "credentialsWrong": number
      "credentialsMissing": number
      "credentialsUnknown": number
      "snmpEnabled": number
      "pingMode": number
    }
      "telemetryPhase": object {
      "radioProbed": number
      "l2Probed": number
      "pingSwept": number
      "metricSamples2h": number
      "radioMetrics2h": number
      "pingMetrics2h": number
      "trafficMetrics2h": number
      "devicesSeen2h": number
      "devicesOnline": number
      "devicesOffline": number
    }
      "topologyPhase": object {
      "links": number
      "linksByEvidence": array<object {
      "evidence": string
      "count": number
    }>
      "fdbObservations": number
      "arpEntries": number
      "stpObservations": number
      "vlans": number
      "macKnownInInventory": number
      "macSeenNotInInventory": number
      "vendorUnknown": number
      "vendorUnknownDevices": array<object {
      "hostname": string
      "ip": string
      "macAddress": string
    }>
    }
      "alarmsPhase": object {
      "rulesEnabled": number
      "rulesTotal": number
      "eventsOpen": number
      "eventsBySeverity": array<object {
      "severity": string
      "count": number
    }>
    }
      "engines": object {
      "discoveryService": object {
      "reachable": boolean
      "version": string | null
      "uptimeSec": number | null
      "capabilities": number | null
      "ouiPrefixes": number | null
    }
      "realtimeService": object {
      "mode": string
      "lastTickAt": number | null
      "intervalSec": number | null
    }
      "monitoringEngine": object {
      "running": boolean
      "busy": boolean
      "startedVia": string | null
      "autoResume": boolean
      "intervalSec": number | null
      "radioEvery": number | null
      "cycles": number
      "lastCycleAt": number | null
      "lastCycleDurationMs": number | null
      "metricsWritten": number
      "eventsOpened": number
      "eventsClosed": number
      "notificationsSent": number
      "notificationsSkipped": number
      "errors": array<string>
    }
      "dbReachable": boolean
      "apiReachable": boolean
    }
      "honestNotes": array<string>
    }
    }
```

## GET /api/v2/setup/engine

Stato VIVO dei motori di monitoraggio attivi (16.19 W21-bis): per ogni motore — running, intervallo, cicli completati, ultimo ciclo (at + durata), campioni scritti, sonde radio/ping/SNMP, eventi aperti/chiusi, notifiche inviate/skippate, errori. Nessun segreto. ONESTÀ: il motore vive nel processo del server — al riavvio si ferma e NON riparte da solo in questa build.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "engines": array<object {
      "plantId": string
      "plantName": string
      "running": boolean
      "busy": boolean
      "intervalSec": number
      "radioEvery": number
      "startedVia": "WIZARD" | "AUTO_RESUME" | "API"
      "startedAt": number
      "cycles": number
      "lastCycleAt": number | null
      "lastCycleDurationMs": number | null
      "metricsWritten": number
      "eventsOpened": number
      "eventsClosed": number
      "notificationsSent": number
      "notificationsFailed": number
      "notificationsSkipped": number
      "pingSweeps": number
      "snmpProbes": number
      "radioProbes": number
      "errors": array<string>
    }>
      "runtimes": array<object {
      "plantId": string
      "plantName": string
      "enabled": boolean
      "intervalSec": number
      "radioEveryNCycles": number
      "startedVia": string
      "lastStartedAt": number | null
      "lastHeartbeatAt": number | null
      "lastStoppedAt": number | null
      "stopReason": string
      "cycles": number
      "totalCycles": number
      "lastError": string
    }>
      "honestNotes": array<string>
    }
    }
```

## POST /api/v2/setup/engine

Avvia/arresta il MOTORE DI MONITORAGGIO CONTINUO (16.19 W21-bis, role ≥ TECNICO): start {intervalSec?, radioEvery?} — primo ciclo SUBITO, poi ogni intervalSec: presenza ping sui ping-only (isteresi 2 giù/2 su), liveness SNMP sugli apparati full, telemetria radio ogni N cicli, valutazione allarmi con dedup, notifiche Telegram (esito SCRITTO in NotificationLog), polling schedule per dispositivo. stop → arresto pulito. Audit SETUP_ENGINE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "action": "start" | "stop"
      "stopped": boolean | undefined
      "engine": object {
      "plantId": string
      "plantName": string
      "running": boolean
      "busy": boolean
      "intervalSec": number
      "radioEvery": number
      "startedVia": "WIZARD" | "AUTO_RESUME" | "API"
      "startedAt": number
      "cycles": number
      "lastCycleAt": number | null
      "lastCycleDurationMs": number | null
      "metricsWritten": number
      "eventsOpened": number
      "eventsClosed": number
      "notificationsSent": number
      "notificationsFailed": number
      "notificationsSkipped": number
      "pingSweeps": number
      "snmpProbes": number
      "radioProbes": number
      "errors": array<string>
    } | undefined
      "engines": array<object {
      "plantId": string
      "plantName": string
      "running": boolean
      "busy": boolean
      "intervalSec": number
      "radioEvery": number
      "startedVia": "WIZARD" | "AUTO_RESUME" | "API"
      "startedAt": number
      "cycles": number
      "lastCycleAt": number | null
      "lastCycleDurationMs": number | null
      "metricsWritten": number
      "eventsOpened": number
      "eventsClosed": number
      "notificationsSent": number
      "notificationsFailed": number
      "notificationsSkipped": number
      "pingSweeps": number
      "snmpProbes": number
      "radioProbes": number
      "errors": array<string>
    }>
    }
    }
```
### Body
```
object {
      "action": "start" | "stop"
      "plantId": string | undefined
      "intervalSec": number | undefined
      "radioEvery": number | undefined
    }
```

## POST /api/v2/discovery/l2

Sonda Layer-2 di uno switch (16.14 W12): LLDP-MIB+CDP+BRIDGE-MIB FDB+Q-BRIDGE VLAN+IF-MIB in UNA sessione walk; ricostruzione link con confidenza dichiarata (HIGH LLDP/CDP · MEDIUM FDB · LOW DAISY_CHAIN); persistenza FdbObservation + TopologyLink SOLO inferiti; audit TOPOLOGY_L2_SCAN.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "switch": object {
      "id": string
      "hostname": string
      "ip": string
      "sysName": string | null
      "matched": object {
      "community": string
      "version": string
    } | null
    }
      "reachable": boolean
      "error": string | undefined
      "detail": string | undefined
      "links": array<object {
      "switchDeviceId": string
      "targetDeviceId": string
      "targetHostname": string
      "targetIp": string
      "sourcePort": string
      "sourcePortNum": number (default 0)
      "targetPort": string
      "sourceOfTruth": "LLDP" | "CDP" | "FDB" | "DAISY_CHAIN"
      "confidence": "HIGH" | "MEDIUM" | "LOW"
      "evidence": string
      "speedMbps": number
      "duplex": "full" | "half" | null (default null)
      "stpCorroborated": boolean (default false)
      "detail": string
    }>
      "unmatchedNeighbors": array<object {
      "via": "LLDP" | "CDP"
      "name": string
      "port": string | null
    }>
      "sharedPorts": array<object {
      "port": string
      "devices": array<string>
    }>
      "unmatchedMacsWithIp": array<object {
      "mac": string
      "ip": string
      "portName": string
    }> | undefined
      "stp": object {
      "present": boolean
      "protocol": string
      "bridgeMac": string
      "rootBridgeMac": string
      "rootPort": number
      "corroboratedLinks": number
    } | null | undefined
      "vlans": array<object {
      "vlanId": number
      "name": string
      "ports": string
    }> | undefined
      "arp": array<object {
      "ip": string
      "mac": string
      "ifIndex": number
      "type": string
    }> | undefined
      "warnings": array<string>
      "persistence": object {
      "linksCreated": number
      "linksUpdated": number
      "linksSkippedOperator": number
      "observationsSaved": number
      "arpSaved": number | undefined
      "stpSaved": number | undefined
      "vlanSaved": number | undefined
    }
      "stats": object {
      "lldpNeighbors": number
      "cdpNeighbors": number
      "fdbEntries": number
      "vlanFdbEntries": number
      "matchedLinks": number
      "observations": number
      "unmatchedNeighbors": number
      "sharedPorts": number
      "arpEntries": number | undefined
      "stpPorts": number | undefined
      "vlans": number | undefined
      "unmatchedMacsWithIp": number | undefined
    }
    }
    }
```
### Body
```
object {
      "plantId": string | undefined
      "deviceId": string
      "communities": array<string> | undefined
      "timeoutMs": number | undefined
    }
```

## GET /api/v2/adozione

Coda adozione (16.6.0, W3.4 — portata da v15 §13.8): orphans = dispositivi SENZA sede (locationId null, decommissionedAt null) — gli host scoperti SYS:NEW_HOST mai adottati (30 reali nel DB egidio); toConfirm = requiresConfirmation=true (impianti sensibili GAP 2); locations = sedi reali del plant per la scelta. Lettura pura, scope impianto con pattern OR di /devices.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "orphans": array<object {
      "id": string
      "hostname": string
      "type": string
      "brand": string | null
      "model": string | null
      "macAddress": string | null
      "ip": string | null
      "firmwareVersion": string | null
      "lastSeenAt": number | null
      "status": string
      "requiresConfirmation": boolean
    }>
      "toConfirm": array<object {
      "id": string
      "hostname": string
      "type": string
      "brand": string | null
      "model": string | null
      "macAddress": string | null
      "ip": string | null
      "firmwareVersion": string | null
      "lastSeenAt": number | null
      "status": string
      "requiresConfirmation": boolean
    }>
      "locations": array<object {
      "id": string
      "name": string
    }>
    }
    }
```

## POST /api/v2/adozione

Azione UMANA di adozione (16.6.0, role ≥ TECNICO): adopt {deviceId, locationId} assegna la sede reale del plant, azzera requiresConfirmation, locationAssignedBy='' (manuale: il motore topologico non la tocca), audit ADOZIONE_ADOPT; dismiss {deviceId} archivia SOLO per i «da confermare» (audit ADOZIONE_DISMISS) senza toccare il dispositivo. Dispositivo già adottato e confermato → 422 BAD_STATE; sede inesistente → 422. NESSUNA auto-adozione (regola v15 §13.8: la decisione resta umana).

### Risposta
```
object {
      "id": string
      "action": string
      "locationId": string | undefined
    }
```
### Body
```
object {
      "action": const ["adopt"]
      "deviceId": string
      "locationId": string
    } | object {
      "action": const ["dismiss"]
      "deviceId": string
    }
```

## GET /api/v2/event-policies

Regole evento (16.7, W3.5 — event-policies v15): 10 regole SYS:* REALI del motore + regole utente. SYS = tarabili (enabled/soglie/cooldown/severità) MAI eliminabili o ristrutturate; utente = CRUD completo con validazione su dati REALI (metriche vocabolario v15, deviceTypes ⊆ tipi distinti inventario, scope SITE/DEVICE/LINK ⊆ sedi/dispositivi/link del plant, nome univoco per impianto). Nessun conteggio eventi per regola (ruleId NULL negli eventi storici: onesto «n.d.»).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "description": string
      "enabled": boolean
      "systemKey": string | null
      "metric": string
      "deviceTypes": array<string>
      "scopeType": "ALL" | "SITE" | "DEVICE" | "LINK"
      "scopeIds": array<string>
      "comparison": "gt" | "lt" | "eq" | "ne" | "between"
      "threshold": number
      "recoveryThreshold": number | null
      "betweenMax": number | null
      "sustainSeconds": number
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "escalateAfterMinutes": number
      "cooldownMinutes": number
      "maintenanceStart": string
      "maintenanceEnd": string
      "maintenanceDays": array<number>
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
      "systemCount": number
      "userCount": number
    }
    }
```

## POST /api/v2/event-policies

Creazione regola utente (role ≥ TECNICO, 16.7): guardrail zod (metrica vocabolario, between ⇒ betweenMax > threshold) + validazioni reali; audit EVENT_POLICY_CREATE.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "enabled": boolean
      "systemKey": string | null
      "metric": string
      "deviceTypes": array<string>
      "scopeType": "ALL" | "SITE" | "DEVICE" | "LINK"
      "scopeIds": array<string>
      "comparison": "gt" | "lt" | "eq" | "ne" | "between"
      "threshold": number
      "recoveryThreshold": number | null
      "betweenMax": number | null
      "sustainSeconds": number
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "escalateAfterMinutes": number
      "cooldownMinutes": number
      "maintenanceStart": string
      "maintenanceEnd": string
      "maintenanceDays": array<number>
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "name": string
      "description": string | undefined
      "metric": "anomalyScore" | "cameraStreamAlive" | "cameraRtt" | "freqChange" | "linkChange" | "unknownHost" | "packetLoss" | "pingJitter" | "pingLatency" | "portMoved" | "port_utilization" | "signalStrength" | "linkQuality" | "cpuLoad" | "memoryUsage" | "temperature" | "reachable"
      "deviceTypes": array<string> | undefined
      "scopeType": "ALL" | "SITE" | "DEVICE" | "LINK" | undefined
      "scopeIds": array<string> | undefined
      "comparison": "gt" | "lt" | "eq" | "ne" | "between"
      "threshold": number
      "recoveryThreshold": number | null | undefined
      "betweenMax": number | null | undefined
      "sustainSeconds": number | undefined
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL" | undefined
      "escalateAfterMinutes": number | undefined
      "cooldownMinutes": number | undefined
    }
```

## PATCH /api/v2/event-policies/{id}

Taratura: SYS accetta SOLO campi operativi (threshold/recoveryThreshold/betweenMax/sustainSeconds/severity/escalateAfterMinutes/cooldownMinutes/enabled — altro campo → 422 SYSTEM_RULE); utente accetta tutto; no-op → 422 NO_CHANGES; audit EVENT_POLICY_UPDATE con diff.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "enabled": boolean
      "systemKey": string | null
      "metric": string
      "deviceTypes": array<string>
      "scopeType": "ALL" | "SITE" | "DEVICE" | "LINK"
      "scopeIds": array<string>
      "comparison": "gt" | "lt" | "eq" | "ne" | "between"
      "threshold": number
      "recoveryThreshold": number | null
      "betweenMax": number | null
      "sustainSeconds": number
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL"
      "escalateAfterMinutes": number
      "cooldownMinutes": number
      "maintenanceStart": string
      "maintenanceEnd": string
      "maintenanceDays": array<number>
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "enabled": boolean | undefined
      "name": string | undefined
      "description": string | undefined
      "metric": "anomalyScore" | "cameraStreamAlive" | "cameraRtt" | "freqChange" | "linkChange" | "unknownHost" | "packetLoss" | "pingJitter" | "pingLatency" | "portMoved" | "port_utilization" | "signalStrength" | "linkQuality" | "cpuLoad" | "memoryUsage" | "temperature" | "reachable" | undefined
      "deviceTypes": array<string> | undefined
      "scopeType": "ALL" | "SITE" | "DEVICE" | "LINK" | undefined
      "scopeIds": array<string> | undefined
      "comparison": "gt" | "lt" | "eq" | "ne" | "between" | undefined
      "threshold": number | undefined
      "recoveryThreshold": number | null | undefined
      "betweenMax": number | null | undefined
      "sustainSeconds": number | undefined
      "severity": "INFO" | "WARNING" | "AVERAGE" | "HIGH" | "CRITICAL" | undefined
      "escalateAfterMinutes": number | undefined
      "cooldownMinutes": number | undefined
    }
```

## DELETE /api/v2/event-policies/{id}

Eliminazione (role ≥ TECNICO): SYS → 422 SYSTEM_RULE (regole del motore); utente → delete + audit EVENT_POLICY_DELETE.

### Risposta
```
object {
      "id": string
    }
```

## GET /api/v2/custom-oids

OID custom SNMP (16.7, W3.5 — custom-oids v15): template metriche vendor (es. CCQ Ubiquiti). Tabella VUOTA nel DB reale → empty state onesto; appliedCount = statistiche reali (0 in replay).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "oid": string
      "unit": string
      "scale": number
      "dataType": "FLOAT" | "INT" | "COUNTER"
      "intervalSec": number
      "description": string
      "enabled": boolean
      "appliedCount": number
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/custom-oids

Creazione OID custom (role ≥ TECNICO): name univoco tecnico, OID numerico, unità/scala/tipo/intervallo; audit CUSTOM_OID_CREATE.

### Risposta
```
object {
      "id": string
      "name": string
      "oid": string
      "unit": string
      "scale": number
      "dataType": "FLOAT" | "INT" | "COUNTER"
      "intervalSec": number
      "description": string
      "enabled": boolean
      "appliedCount": number
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "name": string
      "oid": string
      "unit": string | undefined
      "scale": number | undefined
      "dataType": "FLOAT" | "INT" | "COUNTER" | undefined
      "intervalSec": number | undefined
      "description": string | undefined
      "enabled": boolean | undefined
    }
```

## PATCH /api/v2/custom-oids/{id}

Modifica (role ≥ TECNICO): name immutabile; no-op → 422 NO_CHANGES; audit CUSTOM_OID_UPDATE diff.

### Risposta
```
object {
      "id": string
      "name": string
      "oid": string
      "unit": string
      "scale": number
      "dataType": "FLOAT" | "INT" | "COUNTER"
      "intervalSec": number
      "description": string
      "enabled": boolean
      "appliedCount": number
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "oid": string | undefined
      "unit": string | undefined | undefined
      "scale": number | undefined | undefined
      "dataType": "FLOAT" | "INT" | "COUNTER" | undefined | undefined
      "intervalSec": number | undefined | undefined
      "description": string | undefined | undefined
      "enabled": boolean | undefined | undefined
    }
```

## DELETE /api/v2/custom-oids/{id}

Eliminazione (role ≥ TECNICO); audit CUSTOM_OID_DELETE.

### Risposta
```
object {
      "id": string
    }
```

## POST /api/v2/custom-oids/{id}/test

Test SNMP LIVE (16.7): get REALE dell'OID sull'IP del dispositivo via mini-service discovery :3002 (community: legacy in chiaro se presente, altrimenti «public», dichiarato nella nota). In sandbox gli IP dell'impianto non sono instradati → timeout ONESTO; su sito legge il valore vero. Audit CUSTOM_OID_TEST (mai la community).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deviceId": string
      "hostname": string
      "ip": string | null
      "oid": string
      "reachable": boolean
      "rawValue": string | null
      "numericValue": number | null
      "error": string | null
      "durationMs": number
      "note": string
    }
    }
```

## GET /api/v2/config-requests

Richieste di configurazione (16.7, W3.5 — config-requests v15): macchina a stati PENDING→APPROVED→APPLIED→CONFIRMED|ROLLED_BACK (+REJECTED). Guardrail v15 alla creazione: comandi matchati contro FORBIDDEN_COMMAND_PATTERNS (rm -rf, erase flash, factory-reset…) → 422 FORBIDDEN_COMMAND. In replay: apply solo executor SIMULATED (dry-run dichiarato «NESSUN comando inviato»); SSH → 422 REPLAY_NOEXEC; confirmBy = finestra commit-confirm (scaduta → 422 WINDOW_EXPIRED). Tabella vuota → empty state onesto.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceType": string
      "title": string
      "commands": array<string>
      "rollback": array<string>
      "executor": "SSH" | "SIMULATED"
      "status": string
      "confirmMinutes": number
      "confirmBy": number | null
      "requestedBy": string
      "approvedBy": string | null
      "appliedAt": number | null
      "output": string
      "note": string
      "safety": object {
      "checked": number
      "forbidden": array<string>
      "maxCommands": number
      "dryRunOnly": boolean
    }
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/config-requests

Creazione richiesta (role ≥ TECNICO): device reale scope plant, comandi 1-50 con guardrail, rollback opzionale, confirmMinutes 0-120; audit CONFIG_REQUEST_CREATE.

### Risposta
```
object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceType": string
      "title": string
      "commands": array<string>
      "rollback": array<string>
      "executor": "SSH" | "SIMULATED"
      "status": string
      "confirmMinutes": number
      "confirmBy": number | null
      "requestedBy": string
      "approvedBy": string | null
      "appliedAt": number | null
      "output": string
      "note": string
      "safety": object {
      "checked": number
      "forbidden": array<string>
      "maxCommands": number
      "dryRunOnly": boolean
    }
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "deviceId": string
      "title": string
      "commands": array<string>
      "rollback": array<string> | undefined
      "executor": "SSH" | "SIMULATED" | undefined
      "confirmMinutes": number | undefined
      "note": string | undefined
    }
```

## POST /api/v2/config-requests/{id}/action

Azioni di stato (role ≥ TECNICO): approve/reject/apply/confirm/rollback con transizioni valide (illegale → 422 INVALID_TRANSITION); ogni azione audit CONFIG_REQUEST_*; output onesto del dry-run.

### Risposta
```
object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceType": string
      "title": string
      "commands": array<string>
      "rollback": array<string>
      "executor": "SSH" | "SIMULATED"
      "status": string
      "confirmMinutes": number
      "confirmBy": number | null
      "requestedBy": string
      "approvedBy": string | null
      "appliedAt": number | null
      "output": string
      "note": string
      "safety": object {
      "checked": number
      "forbidden": array<string>
      "maxCommands": number
      "dryRunOnly": boolean
    }
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "action": "approve" | "reject" | "apply" | "confirm" | "rollback"
    }
```

## GET /api/v2/bulk-config

Ondate bulk (16.7, W3.5 — bulk-config v15 R8): max 50 target (guardrail), risultati per dispositivo. In replay: SOLO executor SIMULATED (dry-run: results {ok, simulated:true, «nessun comando inviato»}); SSH → 422 REPLAY_NOEXEC alla creazione. Tabella vuota → empty state.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "title": string
      "commands": array<string>
      "targetCount": number
      "targetHostnames": array<string>
      "executor": "SSH" | "SIMULATED"
      "status": string
      "safety": object {
      "checked": number
      "forbidden": array<string>
      "maxTargets": number
      "maxCommands": number
      "dryRunOnly": boolean
    }
      "results": array<object {
      "deviceId": string
      "hostname": string
      "ok": boolean
      "simulated": boolean
      "error": string | null
      "durationMs": number
    }>
      "requestedBy": string
      "startedAt": number | null
      "completedAt": number | null
      "createdAt": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/bulk-config

Creazione ondata (role ≥ TECNICO): title, comandi 1-30 con guardrail, deviceIds 1-50 deduplicati ⊆ inventario reale (422 offensori); esecuzione SIMULATA sincrona con report per-device; audit BULK_CONFIG_CREATE.

### Risposta
```
object {
      "id": string
      "title": string
      "commands": array<string>
      "targetCount": number
      "targetHostnames": array<string>
      "executor": "SSH" | "SIMULATED"
      "status": string
      "safety": object {
      "checked": number
      "forbidden": array<string>
      "maxTargets": number
      "maxCommands": number
      "dryRunOnly": boolean
    }
      "results": array<object {
      "deviceId": string
      "hostname": string
      "ok": boolean
      "simulated": boolean
      "error": string | null
      "durationMs": number
    }>
      "requestedBy": string
      "startedAt": number | null
      "completedAt": number | null
      "createdAt": number
    }
```
### Body
```
object {
      "title": string
      "commands": array<string>
      "deviceIds": array<string>
      "executor": "SSH" | "SIMULATED" | undefined
    }
```

## GET /api/v2/firmware

Firmware center (16.7, W3.5): job di upgrade schedulati (SCHEDULED/CANCELED/…). NESSUNA esecuzione in replay (dichiarato); firmware attuale del dispositivo dal DB («n.d.» se vuoto). Tabella vuota → empty state.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceType": string
      "deviceFirmware": string
      "targetFirmware": string
      "executor": "SSH" | "SIMULATED"
      "scheduledAt": number
      "confirmMinutes": number
      "status": string
      "output": string
      "error": string
      "requestedBy": string
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/firmware

Schedulazione upgrade (role ≥ TECNICO): device reale, targetFirmware obbligatorio, comandi opzionali con guardrail, confirmMinutes 1-120; audit FIRMWARE_JOB_CREATE.

### Risposta
```
object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceType": string
      "deviceFirmware": string
      "targetFirmware": string
      "executor": "SSH" | "SIMULATED"
      "scheduledAt": number
      "confirmMinutes": number
      "status": string
      "output": string
      "error": string
      "requestedBy": string
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "deviceId": string
      "targetFirmware": string
      "commands": array<string> | undefined
      "executor": "SSH" | "SIMULATED" | undefined
      "scheduledAt": number | undefined
      "confirmMinutes": number | undefined
    }
```

## POST /api/v2/firmware/{id}/cancel

Annullamento job (role ≥ TECNICO): SCHEDULED→CANCELED (altri stati → 422 INVALID_TRANSITION); audit FIRMWARE_JOB_CANCEL.

### Risposta
```
object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceType": string
      "deviceFirmware": string
      "targetFirmware": string
      "executor": "SSH" | "SIMULATED"
      "scheduledAt": number
      "confirmMinutes": number
      "status": string
      "output": string
      "error": string
      "requestedBy": string
      "createdAt": number
      "updatedAt": number
    }
```

## GET /api/v2/playbooks

Playbook (16.7, W3.5 — v15): procedure multi-step (check_status, check_metric, send_command, open_ticket, notify, wait). CRUD completo; NESSUNA esecuzione in replay (dichiarato in UI: runCount 0 onesto). Tabella vuota → empty state.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "description": string
      "triggerRule": string
      "enabled": boolean
      "runCount": number
      "lastRunAt": number | null
      "createdBy": string
      "steps": array<object {
      "id": string
      "stepOrder": number
      "name": string
      "action": string
      "params": string
    }>
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/playbooks

Creazione playbook (role ≥ TECNICO): steps 1-30 con azioni del vocabolario; audit PLAYBOOK_CREATE.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "triggerRule": string
      "enabled": boolean
      "runCount": number
      "lastRunAt": number | null
      "createdBy": string
      "steps": array<object {
      "id": string
      "stepOrder": number
      "name": string
      "action": string
      "params": string
    }>
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "name": string
      "description": string | undefined
      "triggerRule": string | undefined
      "enabled": boolean | undefined
      "steps": array<object {
      "name": string
      "action": "check_status" | "check_metric" | "send_command" | "open_ticket" | "notify" | "wait"
      "params": string | undefined
    }>
    }
```

## PATCH /api/v2/playbooks/{id}

Modifica (role ≥ TECNICO): steps = SOSTITUZIONE integrale; no-op → 422 NO_CHANGES; audit PLAYBOOK_UPDATE.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "triggerRule": string
      "enabled": boolean
      "runCount": number
      "lastRunAt": number | null
      "createdBy": string
      "steps": array<object {
      "id": string
      "stepOrder": number
      "name": string
      "action": string
      "params": string
    }>
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "name": string | undefined
      "description": string | undefined | undefined
      "triggerRule": string | undefined | undefined
      "enabled": boolean | undefined | undefined
      "steps": array<object {
      "name": string
      "action": "check_status" | "check_metric" | "send_command" | "open_ticket" | "notify" | "wait"
      "params": string | undefined
    }> | undefined
    }
```

## DELETE /api/v2/playbooks/{id}

Eliminazione (role ≥ TECNICO, cascade steps); audit PLAYBOOK_DELETE.

### Risposta
```
object {
      "id": string
    }
```

## GET /api/v2/automation-tasks

Automation task (16.7, W3.5 — v15): comandi periodici con tetto guardrailMaxDevices. CRUD; NESSUN run in replay (runCount 0 onesto). Tabella vuota → empty state.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "description": string
      "targetCount": number
      "targetHostnames": array<string>
      "category": string
      "commands": array<string>
      "executor": "SSH" | "SIMULATED"
      "intervalSec": number
      "confirmMinutes": number
      "enabled": boolean
      "guardrailMaxDevices": number
      "runCount": number
      "lastRunAt": number | null
      "lastError": string
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/automation-tasks

Creazione (role ≥ TECNICO): name univoco, comandi 1-30 con guardrail, target ⊆ inventario (422 offensori), intervalSec 60-86400; audit AUTOMATION_TASK_CREATE.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "targetCount": number
      "targetHostnames": array<string>
      "category": string
      "commands": array<string>
      "executor": "SSH" | "SIMULATED"
      "intervalSec": number
      "confirmMinutes": number
      "enabled": boolean
      "guardrailMaxDevices": number
      "runCount": number
      "lastRunAt": number | null
      "lastError": string
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "name": string
      "description": string | undefined
      "deviceIds": array<string> | undefined
      "category": string | undefined
      "commands": array<string>
      "executor": "SSH" | "SIMULATED" | undefined
      "intervalSec": number | undefined
      "confirmMinutes": number | undefined
      "guardrailMaxDevices": number | undefined
      "enabled": boolean | undefined
    }
```

## PATCH /api/v2/automation-tasks/{id}

Modifica (role ≥ TECNICO): deviceIds = sostituzione integrale; no-op → 422 NO_CHANGES; audit AUTOMATION_TASK_UPDATE.

### Risposta
```
object {
      "id": string
      "name": string
      "description": string
      "targetCount": number
      "targetHostnames": array<string>
      "category": string
      "commands": array<string>
      "executor": "SSH" | "SIMULATED"
      "intervalSec": number
      "confirmMinutes": number
      "enabled": boolean
      "guardrailMaxDevices": number
      "runCount": number
      "lastRunAt": number | null
      "lastError": string
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "name": string | undefined
      "description": string | undefined | undefined
      "deviceIds": array<string> | undefined | undefined
      "category": string | undefined | undefined
      "commands": array<string> | undefined
      "executor": "SSH" | "SIMULATED" | undefined | undefined
      "intervalSec": number | undefined | undefined
      "confirmMinutes": number | undefined | undefined
      "guardrailMaxDevices": number | undefined | undefined
      "enabled": boolean | undefined | undefined
    }
```

## DELETE /api/v2/automation-tasks/{id}

Eliminazione (role ≥ TECNICO); audit AUTOMATION_TASK_DELETE.

### Risposta
```
object {
      "id": string
    }
```

## POST /api/v2/terminal/probe

Terminale SSH (16.7, W3.5): tentativo REALE di porta 22 via discovery-service (sonda TCP): esito onesto (in sandbox «host non raggiungibile — rete dimostrativa»); sessionOpened SEMPRE false in replay (nessuna sessione fittizia, nessun terminale emulato); audit TERMINAL_PROBE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deviceId": string
      "hostname": string
      "ip": string | null
      "sshPortOpen": boolean
      "reachable": boolean
      "latencyMs": number | null
      "detail": string
      "sessionOpened": boolean
    }
    }
```

## GET /api/v2/integrations

Configurazioni integrazione (16.7, W7.0 — IntegrationConfig v15): valori cifrati AES-256-GCM a riposo (chiave master DEVICE_CREDENTIALS_KEY, crypto.ts portata da v15); isSecret=true → value «***» (MAI il segreto in risposta). Tabella vuota → empty state.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "configs": array<object {
      "id": string
      "key": string
      "category": string
      "value": string
      "isSecret": boolean
      "enabled": boolean
      "note": string
      "updatedBy": string
      "updatedAt": number
      "hasValue": boolean
    }>
      "webhooks": array<string>
      "totalConfigs": number
      "categories": array<string>
    }
    }
```

## POST /api/v2/integrations

Upsert per chiave (role ≥ TECNICO): cifratura obbligatoria (senza chiave master → 422 KEY_MISSING, nessun fallback in chiaro); audit INTEGRATION_UPSERT senza MAI il valore.

### Risposta
```
object {
      "id": string
      "key": string
      "category": string
      "value": string
      "isSecret": boolean
      "enabled": boolean
      "note": string
      "updatedBy": string
      "updatedAt": number
      "hasValue": boolean
    }
```
### Body
```
object {
      "key": string
      "category": "email" | "telegram" | "osticket" | "grafana" | "checkmk" | "cnmaestro" | "unifi" | "splashtop" | "ldap" | "prometheus" | "ollama" | "backup" | "general"
      "value": string
      "isSecret": boolean | undefined
      "note": string | undefined
      "enabled": boolean | undefined
    }
```

## DELETE /api/v2/integrations

Eliminazione configurazione (role ≥ TECNICO, ?id=): 404 se assente; audit INTEGRATION_DELETE {key, category}.

### Risposta
```
object {
      "id": string
    }
```

## POST /api/v2/integrations/test

Test di connessione REALE (role ≥ TECNICO): http (fetch con timeout), tcp (net.connect), telegram (getMe: token valido/rifiutato); webhook → 422 BAD_KIND (si testa da /webhooks/{id}/test). Esiti onesti della rete (in sandbox Telegram risponde 401 ai token falsi: verità, non simulazione); audit INTEGRATION_TEST {kind, target} mai token.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "kind": "http" | "tcp" | "telegram" | "webhook"
      "target": string
      "reachable": boolean
      "statusCode": number | null
      "latencyMs": number
      "detail": string
    }
    }
```
### Body
```
object {
      "kind": "http" | "tcp" | "telegram" | "webhook"
      "url": string | undefined
      "host": string | undefined
      "port": number | undefined
      "token": string | undefined
      "timeoutMs": number | undefined
    }
```

## GET /api/v2/integrations/webhooks

Endpoint webhook (16.7, W7.0 — WebhookEndpoint v15): segreto HMAC cifrato AES (hasSecret, mai esposto), ultime 10 consegne per endpoint + totale; lastDeliveryAt/lastStatus reali. Tabella vuota → empty state.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "url": string
      "events": array<string>
      "plantId": string | null
      "active": boolean
      "description": string
      "hasSecret": boolean
      "lastDeliveryAt": number | null
      "lastStatus": string
      "deliveries": array<object {
      "id": string
      "endpointId": string
      "eventType": string
      "status": string
      "attempts": number
      "lastStatusCode": number | null
      "lastError": string
      "latencyMs": number
      "deliveredAt": number | null
      "createdAt": number
    }>
      "deliveriesTotal": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/integrations/webhooks

Creazione endpoint (role ≥ TECNICO): segreto fornito o GENERATO (48 hex, cifrato); alla creazione la risposta include secretOneTime in chiaro UNA VOLTA (poi non più recuperabile — dichiarato); audit WEBHOOK_CREATE senza segreto.

### Risposta
```
object {
      "id": string
      "name": string
      "url": string
      "events": array<string>
      "plantId": string | null
      "active": boolean
      "description": string
      "hasSecret": boolean
      "lastDeliveryAt": number | null
      "lastStatus": string
      "deliveries": array<object {
      "id": string
      "endpointId": string
      "eventType": string
      "status": string
      "attempts": number
      "lastStatusCode": number | null
      "lastError": string
      "latencyMs": number
      "deliveredAt": number | null
      "createdAt": number
    }>
      "deliveriesTotal": number
    }
```
### Body
```
object {
      "name": string
      "url": string
      "secret": string | undefined
      "events": array<string> | undefined
      "plantId": string | null | undefined
      "description": string | undefined
    }
```

## PATCH /api/v2/integrations/webhooks/{id}

Modifica (role ≥ TECNICO): name/url/active/events/description; no-op → 422 NO_CHANGES; audit WEBHOOK_UPDATE diff.

### Risposta
```
object {
      "id": string
      "name": string
      "url": string
      "events": array<string>
      "plantId": string | null
      "active": boolean
      "description": string
      "hasSecret": boolean
      "lastDeliveryAt": number | null
      "lastStatus": string
      "deliveries": array<object {
      "id": string
      "endpointId": string
      "eventType": string
      "status": string
      "attempts": number
      "lastStatusCode": number | null
      "lastError": string
      "latencyMs": number
      "deliveredAt": number | null
      "createdAt": number
    }>
      "deliveriesTotal": number
    }
```
### Body
```
object {
      "name": string | undefined
      "url": string | undefined
      "active": boolean | undefined
      "events": array<string> | undefined
      "description": string | undefined
    }
```

## DELETE /api/v2/integrations/webhooks/{id}

Eliminazione (role ≥ TECNICO, cascade consegne); audit WEBHOOK_DELETE {name, url, removedDeliveries}.

### Risposta
```
object {
      "id": string
    }
```

## POST /api/v2/integrations/webhooks/{id}/test

Consegna di test FIRMATA (role ≥ TECNICO): payload {type webhook.test} + header X-Falco-Signature «t=<epoch>,v1=HMAC-SHA256(secret, t.body)»; POST reale all'URL (timeout 8 s); il ricevitore locale /api/hooks/test-receiver (pubblico) risponde con l'eco {bodySha256, timestamp} → verifica crittografica end-to-end lato mittente (signatureVerified). Registra WebhookDelivery (DELIVERED/DEAD, attempts 1/6, latenza) + aggiorna endpoint + audit WEBHOOK_TEST.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deliveryId": string
      "delivered": boolean
      "statusCode": number | null
      "latencyMs": number
      "signature": string
      "signatureVerified": boolean
      "detail": string
    }
    }
```

## GET /api/v2/reports/sla

Report SLA mensile + storico (16.8, W2 residua): tempi di prima risposta (firstResponseAt) e risoluzione (resolvedAt al netto di slaPausedMinutes) sulla coorte dei ticket CREATI nel mese; conformità valutata SOLO dove i target slaDueAt esistono; copertura DICHIARATA (nel DB reale firstResponseAt 0/74, slaDueAt 0/74, SLADefinition 0 — D19); months + history = storico reale mese per mese; default month = ultimo mese con ticket.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "month": string
      "windowFrom": number
      "windowTo": number
      "tickets": object {
      "total": number
      "created": number
      "closed": number
      "byStatus": array<object {
      "status": string
      "count": number
    }>
      "byPriority": array<object {
      "priority": string
      "count": number
    }>
      "bySource": array<object {
      "source": string
      "count": number
    }>
    }
      "responseTime": object {
      "measured": number
      "coverage": string
      "medianMin": number | null
      "avgMin": number | null
      "minMin": number | null
      "maxMin": number | null
    }
      "resolutionTime": object {
      "measured": number
      "coverage": string
      "medianMin": number | null
      "avgMin": number | null
      "minMin": number | null
      "maxMin": number | null
      "pausedMinutesTotal": number
    }
      "slaCompliance": object {
      "response": object {
      "evaluated": number
      "inSla": number
      "late": number
    }
      "resolution": object {
      "evaluated": number
      "inSla": number
      "late": number
    }
      "slaDefinitions": number
      "note": string
    }
      "escalation": object {
      "maxLevel": number
      "ticketsEscalated": number
    }
      "months": array<string>
      "history": array<object {
      "month": string
      "created": number
      "closed": number
      "responseMeasured": number
      "resolutionMeasured": number
      "responseInSla": number
      "resolutionInSla": number
    }>
    }
    }
```
### Parametri query
```
object {
      "month": string | undefined
      "plantId": string | undefined
    }
```

## GET /api/v2/tickets/{id}

Scheda intervento (16.8, W2 residua): dati REALI del ticket per il documento stampabile del tecnico — device/sede/impianto, diagnosticSteps (parse difensivo), rootCause/resolution, interventi collegati (Registro REALE: 0 nel plant egidio, dichiarato), timeline = audit REALE per targetId, conteggi commenti/allegati/ore.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "ticket": object {
      "id": string
      "title": string
      "description": string
      "status": string
      "priority": string
      "source": string
      "createdAt": number
      "updatedAt": number
      "assignedTo": string
      "assignedAt": number | null
      "firstResponseAt": number | null
      "resolvedAt": number | null
      "closedAt": number | null
      "slaResponseDueAt": number | null
      "slaResolutionDueAt": number | null
      "slaPausedMinutes": number
      "escalationLevel": number
      "rootCause": string
      "resolution": string
      "diagnosticSteps": array<string>
    }
      "device": object {
      "id": string
      "hostname": string
      "ip": string | null
      "type": string
      "brand": string | null
      "model": string | null
      "status": string
    } | null
      "location": object {
      "id": string
      "name": string
    } | null
      "plant": object {
      "id": string
      "name": string
    }
      "interventions": array<object {
      "id": string
      "action": string
      "component": string
      "description": string
      "technicianName": string
      "status": string
      "createdAt": number
    }>
      "timeline": array<object {
      "action": string
      "actor": string
      "createdAt": number
    }>
      "counts": object {
      "comments": number
      "attachments": number
      "timeEntries": number
    }
      "honesty": string
    }
    }
```

## GET /api/v2/reports/scheduled

Report pianificati (16.8, W2 residua — ScheduledReport v15): frequenza HOURLY/DAILY/WEEKLY/MONTHLY, ora, canali EMAIL/TELEGRAM/PDF, destinatari, sezioni; nextRunAt = proiezione pura (dichiarata). ONESTÀ D2: il motore di schedulazione NON gira in riproduzione → lastRunAt null, runCount 0, NESSUN artefatto generato (honesty nel payload).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "frequency": string
      "hour": number
      "dayOfWeek": number | null
      "dayOfMonth": number | null
      "channels": array<string>
      "recipients": array<string>
      "includeSections": array<string>
      "enabled": boolean
      "lastRunAt": number | null
      "lastStatus": string
      "nextRunAt": number | null
      "runCount": number
      "artifactsCount": number
      "createdAt": number
    }>
      "total": number
      "honesty": string
    }
    }
```

## POST /api/v2/reports/scheduled

Creazione report pianificato (role ≥ TECNICO): validazione semantica frequenza (WEEKLY → dayOfWeek obbligatorio, MONTHLY → dayOfMonth obbligatorio, 422 espliciti), destinatari e-mail valide max 20, canali/sezioni non vuoti del vocabolario v15; audit REPORT_SCHEDULED_CREATE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "frequency": string
      "hour": number
      "dayOfWeek": number | null
      "dayOfMonth": number | null
      "channels": array<string>
      "recipients": array<string>
      "includeSections": array<string>
      "enabled": boolean
      "lastRunAt": number | null
      "lastStatus": string
      "nextRunAt": number | null
      "runCount": number
      "artifactsCount": number
      "createdAt": number
    }>
      "total": number
      "honesty": string
    }
    }
```
### Body
```
object {
      "name": string
      "frequency": "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY"
      "hour": number
      "dayOfWeek": number | undefined
      "dayOfMonth": number | undefined
      "channels": array<"EMAIL" | "TELEGRAM" | "PDF">
      "recipients": array<string>
      "includeSections": array<"devices" | "tickets" | "sla" | "metrics" | "alarms" | "availability">
      "enabled": boolean | undefined
      "plantId": string | undefined
    }
```

## PATCH /api/v2/reports/scheduled/{id}

Modifica report pianificato (role ≥ TECNICO): sostituzione integrale degli array, guard NO_CHANGES (422), nextRunAt ricalcolata; audit REPORT_SCHEDULED_UPDATE con diff {campo: from→to}.

### Risposta
```
object {
      "id": string
      "name": string
      "frequency": string
      "hour": number
      "dayOfWeek": number | null
      "dayOfMonth": number | null
      "channels": array<string>
      "recipients": array<string>
      "includeSections": array<string>
      "enabled": boolean
      "lastRunAt": number | null
      "lastStatus": string
      "nextRunAt": number | null
      "runCount": number
      "artifactsCount": number
      "createdAt": number
    }
```
### Body
```
object {
      "name": string | undefined
      "frequency": "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | undefined
      "hour": number | undefined
      "dayOfWeek": number | undefined
      "dayOfMonth": number | undefined
      "channels": array<"EMAIL" | "TELEGRAM" | "PDF"> | undefined
      "recipients": array<string> | undefined
      "includeSections": array<"devices" | "tickets" | "sla" | "metrics" | "alarms" | "availability"> | undefined
      "enabled": boolean | undefined
    }
```

## DELETE /api/v2/reports/scheduled/{id}

Eliminazione report pianificato (role ≥ TECNICO, cascade artefatti — 0 in riproduzione); audit REPORT_SCHEDULED_DELETE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "id": string
      "deleted": boolean
      "removedArtifacts": number
    }
    }
```

## GET /api/v2/audit/export

Export certificato audit (16.8, W6): righe con chainSeq/recordHash quando sigillate + manifest {totalRows, sealedRows, unsealedRows, firstSeq/lastSeq, chainDigest = SHA-256 di TUTTI i recordHash in ordine di seq (null se catena non sigillata), exportDigest = SHA-256 canonico dell'export}; finestra from/to opzionale, limit default 200 max 5000, truncated onesto; details MAI esportati.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "filters": object {
      "from": number | null
      "to": number | null
      "limit": number
    }
      "totalMatching": number
      "returned": number
      "truncated": boolean
      "rows": array<object {
      "id": string
      "action": string
      "actor": string
      "targetId": string | null
      "targetLabel": string | null
      "plantId": string | null
      "createdAt": number
      "chainSeq": number | null
      "recordHash": string | null
    }>
      "manifest": object {
      "totalRows": number
      "sealedRows": number
      "unsealedRows": number
      "firstSeq": number | null
      "lastSeq": number | null
      "chainDigest": string | null
      "exportDigest": string
      "note": string
    }
    }
    }
```
### Parametri query
```
object {
      "from": number | undefined
      "to": number | undefined
      "limit": number | undefined
      "format": "csv" | "json" | undefined
      "action": string | undefined
    }
```

## GET /api/v2/audit/chain

Stato catena audit (16.8, W6): conteggi totali/sigillate/non sigillate + sigilli AuditSeal (lastSeq, lastHash, recordCount, prevSealId, sealedBy, sealedAt) in ordine. Sola lettura.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "totalRows": number
      "sealedRows": number
      "unsealedRows": number
      "firstSeq": number | null
      "lastSeq": number | null
      "seals": array<object {
      "id": string
      "lastSeq": number
      "lastRecordId": string
      "lastHash": string
      "recordCount": number
      "prevSealId": string | null
      "sealedBy": string
      "sealedAt": number
    }>
    }
    }
```

## GET /api/v2/audit/chain/verify

Verifica crittografica INTEGRALE della catena (16.8, W6): ricalcolo di TUTTI i recordHash (formula D22), sequenze crescenti senza salti, coerenza sigilli (lastRecordId/lastSeq/lastHash/recordCount) e spina prevSealId; esito verified + firstBreak col motivo; durationMs dichiarato. Sola lettura.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "verified": boolean
      "genesisHash": string
      "sealsTotal": number
      "sealsVerified": number
      "recordsSealed": number
      "recordsVerified": number
      "unsealedCount": number
      "breakages": array<object {
      "sealId": string | undefined
      "recordId": string | undefined
      "seq": number | undefined
      "reason": string
      "expected": string | undefined
      "actual": string | undefined
    }>
      "durationMs": number
      "checkedAt": number
    }
    }
```

## POST /api/v2/audit/seal

Sigillo della catena (16.8, W6 — sealer v12.1.0 V12-F portato): in UNA transazione assegna chainSeq sequenziale + recordHash (SHA-256 canonico, formula D22) a TUTTE le righe non sigillate, crea AuditSeal con spina prevSealId, voce audit AUDIT_SEAL_CREATE; verifica immediata inclusa nella risposta. Role ≥ SUPER_ADMIN; 422 NOTHING_TO_SEAL se tutto già sigillato; operazione persistente (cancellare righe sigillate rompe la catena — tamper-evidence voluto).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "sealId": string
      "sealedRows": number
      "lastSeq": number
      "lastHash": string
      "skipped": boolean
      "remainingUnsealed": number
      "verified": boolean
      "note": string
    }
    }
```

## GET /api/v2/kb

Knowledge base dell'impianto (16.9, W4): articoli con titolo/corpo/tag (parse difensivo del JSON v15), ordinamento updatedAt DESC, take 200; filtro q contains su title/body. Nel DB reale: 0 righe → items: [] onesto.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "plantId": string | null
      "title": string
      "body": string
      "tags": array<string>
      "ticketId": string | null
      "createdBy": string
      "createdAt": number
      "updatedAt": number
    }>
      "total": number
    }
    }
```
### Parametri query
```
object {
      "q": string | undefined
      "plantId": string | undefined
    }
```

## POST /api/v2/kb

Creazione articolo KB (16.9, W4, role ≥ TECNICO): plantId dell'impianto risolto, createdBy = email di sessione, tags JSON; audit KB_CREATE in transazione.

### Risposta
```
object {
      "id": string
      "plantId": string | null
      "title": string
      "body": string
      "tags": array<string>
      "ticketId": string | null
      "createdBy": string
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "title": string
      "body": string
      "tags": array<string> | undefined
    }
```

## PATCH /api/v2/kb/{id}

Modifica articolo (16.9, W4): title/body/tags con refine almeno-uno; 422 NO_CHANGES su patch senza effetto; 404 se inesistente; audit KB_UPDATE.

### Risposta
```
object {
      "id": string
      "plantId": string | null
      "title": string
      "body": string
      "tags": array<string>
      "ticketId": string | null
      "createdBy": string
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "title": string | undefined
      "body": string | undefined
      "tags": array<string> | undefined
    }
```

## DELETE /api/v2/kb/{id}

Eliminazione articolo (16.9, W4): audit KB_DELETE; 404 se inesistente.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deleted": const [true]
      "id": string
    }
    }
```

## POST /api/v2/kb/from-ticket

Conoscenza ripetibile v15 (16.9, W4): crea articolo dal ticket REALE (titolo «KB: …», corpo Problema/Soluzione dai campi del ticket, tags [ticket, priorità], ticketId legato); 404 se il ticket non esiste; audit KB_CREATE con fromTicket.

### Risposta
```
object {
      "id": string
      "plantId": string | null
      "title": string
      "body": string
      "tags": array<string>
      "ticketId": string | null
      "createdBy": string
      "createdAt": number
      "updatedAt": number
    }
```
### Body
```
object {
      "ticketId": string
    }
```

## GET /api/v2/rma

Piano della sostituzione guasto RMA (16.9, W4 — 5 passi v15.12.0 decisione 53, sola lettura): impatto a valle (BFS reachability multi-gateway su link attivi, SEMPRE calcolata dal sistema), portabilità (campi credenziali cifrate AES portati tal quali, punto, gruppi, collegamenti confermati), genealogia, avvisi (guasto probabile a MONTE, dispositivi a valle).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deviceId": string
      "hostname": string
      "plantId": string
      "impact": object {
      "downstreamVictims": number
      "victims": array<object {
      "id": string
      "hostname": string
      "ip": string
      "type": string
      "status": string
    }>
    }
      "portable": object {
      "credentials": array<string>
      "locationId": string | null
      "pointIdentifier": string | null
      "notes": boolean
      "groupIds": array<string>
      "confirmedLinks": number
    }
      "genealogy": array<object {
      "oldDeviceId": string
      "newDeviceId": string
      "at": number
    }>
      "warnings": array<string>
    }
    }
```
### Parametri query
```
object {
      "deviceId": string
    }
```

## POST /api/v2/rma

Esecuzione RMA guidata (16.9, W4, role ≥ TECNICO, IRREVERSIBILE): dismissione controllata del vecchio (DECOMMISSIONED, credenziali revocate, allarmi aperti chiusi, polling spento, cronologia INTATTA), creazione del sostituto nello STESSO punto con finestra baselineUntil 24h anti falsi allarmi, credenziali CIFRATE copiate tal quali, gruppi riassegnati, genealogia DeviceReplacement append-only, collegamenti topologici portati; audit RMA_* per ogni passo in transazione.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "newDeviceId": string
      "steps": array<object {
      "step": string
      "ok": boolean
      "detail": string
    }>
    }
    }
```
### Body
```
object {
      "oldDeviceId": string
      "reason": string | undefined
      "replacement": object {
      "hostname": string
      "ip": string
      "type": "AP" | "STA" | "CAMERA" | "LPR" | "SWITCH" | "NVR" | "GATEWAY" | "ONT"
      "brand": string | undefined
      "model": string | undefined
      "macAddress": string | undefined
      "port": number | undefined
      "connectionType": string | undefined
    }
    }
```

## GET /api/v2/waves

Ondate di configurazioni/firmware dell'impianto (16.9, W4): preflight parsed, counts per stato item, executionAvailable SEMPRE false in riproduzione (onestà D2: il motore per-item non gira). Nel DB reale: 0 ondate.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "items": array<object {
      "id": string
      "name": string
      "kind": string
      "action": string
      "status": string
      "batchSize": number
      "canarySize": number
      "stopOnFirstFailure": boolean
      "dryRun": boolean
      "createdBy": string
      "createdAt": number
      "preflight": array<object {
      "deviceId": string
      "hostname": string
      "ok": boolean
      "reason": string
    }> | null
      "counts": object {
      "total": number
      "canary": number
      "applied": number
      "failed": number
      "skipped": number
      "pending": number
    }
    }>
      "total": number
      "executionAvailable": const [false]
    }
    }
```

## POST /api/v2/waves

Pianificazione ondata (16.9, W4, role ≥ TECNICO): PREFLIGHT reale per target (dismesso / in manutenzione attiva con scope gruppi / credenziali assenti / OFFLINE → scarto con MOTIVO onesto), lotti col lotto 1 = canary (planWaveBatches v15), righe ConfigWaveItem PREFLIGHT_OK, stato DRAFT (nessuna adozione automatica, nessuna esecuzione senza il motore); audit WAVE_CREATED con scarti e canary.

### Risposta
```
object {
      "id": string
      "name": string
      "kind": string
      "action": string
      "status": string
      "batchSize": number
      "canarySize": number
      "stopOnFirstFailure": boolean
      "dryRun": boolean
      "createdBy": string
      "createdAt": number
      "preflight": array<object {
      "deviceId": string
      "hostname": string
      "ok": boolean
      "reason": string
    }> | null
      "counts": object {
      "total": number
      "canary": number
      "applied": number
      "failed": number
      "skipped": number
      "pending": number
    }
    }
```
### Body
```
object {
      "name": string
      "kind": "CONFIG" | "FIRMWARE" (default "CONFIG")
      "action": string | undefined
      "deviceIds": array<string>
      "batchSize": number | undefined
      "canarySize": number | undefined
      "stopOnFirstFailure": boolean | undefined
      "dryRun": boolean | undefined
    }
```

## DELETE /api/v2/waves/{id}

Eliminazione ondata (16.9, W4): SOLO stato DRAFT (422 INVALID_STATE altrimenti — eliminare una ondata in esecuzione richiederebbe il congelamento del report); item in cascata; audit WAVE_DELETED.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deleted": const [true]
      "id": string
    }
    }
```

## GET /api/v2/cve

Catalogo CveEntry REALE (16.9, W4): voci con patterns, ordinamento per gravità desc poi cveId; demoCatalogAvailable = 12 voci pubbliche v15 importabili (NON un feed NVD, dichiarato). Nel DB reale: 0 voci.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "entries": array<object {
      "id": string
      "cveId": string
      "title": string
      "description": string
      "severity": string
      "cvss": number
      "reference": string
      "publishedAt": number | null
      "patterns": array<object {
      "vendorPattern": string
      "modelPattern": string
      "firmwareMin": string
      "firmwareMax": string
    }>
    }>
      "total": number
      "demoCatalogAvailable": number
    }
    }
```

## GET /api/v2/cve/findings

Finding REali con join device+entry (16.9, W4): ranking gravità desc (rankFindings v15), filtro status opzionale, take 500; counts OPEN/IGNORED/RESOLVED sempre globali. 0 finding se nessuna scan ha mai girato.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "findings": array<object {
      "id": string
      "deviceId": string
      "hostname": string
      "ip": string
      "brand": string
      "model": string
      "firmwareVersion": string
      "cveId": string
      "title": string
      "severity": string
      "cvss": number
      "reference": string
      "status": string
      "firstSeenAt": number
      "lastSeenAt": number
      "firmwareAtFind": string
    }>
      "counts": object {
      "OPEN": number
      "IGNORED": number
      "RESOLVED": number
    }
    }
    }
```
### Parametri query
```
object {
      "status": "OPEN" | "IGNORED" | "RESOLVED" | undefined
    }
```

## POST /api/v2/cve/scan

Scan CVE REALE dell'inventario (16.9, W4, role ≥ RESPONSABILE_COMUNE): dispositivi attivi × catalogo, matching PURO glob vendor/model + range firmware tollerante (cve-match v15 portato fedele); upsert finding preservando IGNORED/RESOLVED (decisioni umane); auto-resolve delle OPEN il cui match è scomparso; senza firmware noto non si afferma nulla; con catalogo vuoto: scanned=N, findings=0, NESSUNA riga scritta. Audit CVE_SCAN_RUN.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "scanned": number
      "findings": number
      "newFindings": number
      "autoResolved": number
      "summary": object {
      "total": number
      "critical": number
      "high": number
      "medium": number
      "low": number
    }
      "errors": array<string>
    }
    }
```

## POST /api/v2/cve/import

Importazione catalogo (16.9, W4, role ≥ RESPONSABILE_COMUNE): {demo:true} = 12 voci pubbliche v15 semplificate, oppure entries custom (regex CVE-YYYY-NNNN+); upsert per cveId con patterns sostituiti; audit CVE_IMPORT.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "imported": number
      "errors": array<string>
    }
    }
```
### Body
```
object {
      "demo": boolean | undefined
      "entries": array<object {
      "cveId": string
      "title": string (default "")
      "description": string (default "")
      "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" (default "MEDIUM")
      "cvss": number (default 0)
      "publishedAt": string | undefined
      "reference": string (default "")
      "patterns": array<object {
      "vendorPattern": string (default "*")
      "modelPattern": string (default "*")
      "firmwareMin": string (default "")
      "firmwareMax": string (default "")
    }>
    }> | undefined
    }
```

## PATCH /api/v2/cve/findings/{id}

Stato finding OPEN|IGNORED|RESOLVED (16.9, W4, role ≥ RESPONSABILE_COMUNE): lastSeenAt aggiornata; audit CVE_FINDING_UPDATE con from→to e nota; 404 se inesistente.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "findings": array<object {
      "id": string
      "deviceId": string
      "hostname": string
      "ip": string
      "brand": string
      "model": string
      "firmwareVersion": string
      "cveId": string
      "title": string
      "severity": string
      "cvss": number
      "reference": string
      "status": string
      "firstSeenAt": number
      "lastSeenAt": number
      "firmwareAtFind": string
    }>
      "counts": object {
      "OPEN": number
      "IGNORED": number
      "RESOLVED": number
    }
    }
    }
```
### Body
```
object {
      "status": "OPEN" | "IGNORED" | "RESOLVED"
      "note": string | undefined
    }
```

## GET /api/v2/speed-tests

Storico speed test (16.9, W4): per deviceId o impianto, take 200; statistiche REALI vs SIMULATE separate (media/max banda SOLO sui test ok con executor IPERF3, come v15). 0 righe nel DB reale.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "tests": array<object {
      "id": string
      "deviceId": string
      "deviceHostname": string
      "deviceIp": string
      "mode": string
      "direction": string
      "host": string
      "port": number
      "durationSec": number
      "executor": string
      "ok": boolean
      "bandwidthMbps": number
      "retransmits": number
      "jitterMs": number
      "lossPercent": number
      "error": string
      "createdAt": number
    }>
      "stats": object {
      "total": number
      "real": number
      "simulated": number
      "avgMbps": number
      "maxMbps": number
      "lastRealAt": number | null
    }
    }
    }
```
### Parametri query
```
object {
      "deviceId": string | undefined
    }
```

## POST /api/v2/speed-tests

Esecuzione speed test (16.9, W4, role ≥ RESPONSABILE_COMUNE — v11.9 G6 portato): executor IPERF3 = spawn reale con parse JSON PURO; binario assente → 501 EXECUTOR_DOWN ONESTO, NESSUNA riga scritta; executor SIMULATED = riga MARCATA con misure a zero (mai spacciata per reale). Audit SPEED_TEST_RUN con esito.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "testId": string | null
      "ok": boolean
      "executor": string
      "bandwidthMbps": number
      "retransmits": number
      "jitterMs": number
      "lossPercent": number
      "error": string
    }
    }
```
### Body
```
object {
      "deviceId": string
      "host": string | undefined
      "port": number (default 5201)
      "durationSec": number (default 10)
      "mode": "TCP" | "UDP" (default "TCP")
      "direction": "UP" | "DOWN" (default "DOWN")
      "executor": "IPERF3" | "SIMULATED" (default "IPERF3")
    }
```

## POST /api/v2/assistente

Assistente AI operatore (16.9, W4, role ≥ TECNICO): SSE text/event-stream (NON busta JSON). Contesto di sistema costruito da dati REALI del plant (conteggi per tipo/stato, allarmi aperti per severità, ticket, link radio più deboli per segnale, KB, sedi); model della piattaforma (z-ai-web-dev-sdk, SOLO backend) in STREAMING reale. Eventi: status (fase), delta (frammenti), done {durationMs, contextChars}, error. Audit ASSISTENTE_QUERY bounded (domanda troncata, durata — MAI il contenuto della risposta).

### Risposta
```
object {
      "message": string
      "history": array<object {
      "role": "user" | "assistant"
      "content": string
    }> | undefined
    }
```
### Body
```
object {
      "message": string
      "history": array<object {
      "role": "user" | "assistant"
      "content": string
    }> | undefined
    }
```

## GET /api/v2/admin/users

Elenco utenti (16.9, W4, SUPER_ADMIN only): plantIds reali delle assegnazioni + sessionCount (tabella Session: JWT stateless → 0 per costruzione). Nel DB reale: 1 utente (admin demo SUPER_ADMIN).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "users": array<object {
      "id": string
      "name": string
      "email": string
      "role": string
      "mustChangePassword": boolean
      "totpEnabled": boolean
      "createdAt": number
      "updatedAt": number
      "plantIds": array<string>
      "sessionCount": number
    }>
      "total": number
    }
    }
```

## POST /api/v2/admin/users

Creazione utente (16.9, W4, SUPER_ADMIN only — port v15): policy password enterprise (min 10, quattro classi, lista nera top-100, divieto dati personali — 422 BAD_PASSWORD con violazioni), plantIds verificati PRIMA di scrivere, email unique 409, hash bcrypt(12), mustChangePassword true; audit USER_CREATE.

### Risposta
```
object {
      "id": string
      "name": string
      "email": string
      "role": string
      "mustChangePassword": boolean
      "totpEnabled": boolean
      "createdAt": number
      "updatedAt": number
      "plantIds": array<string>
      "sessionCount": number
    }
```
### Body
```
object {
      "name": string
      "email": string
      "password": string
      "role": "TECNICO" | "RESPONSABILE_COMUNE" | "SUPER_ADMIN" | "CLIENTE" (default "TECNICO")
      "plantIds": array<string> | undefined
    }
```

## PATCH /api/v2/admin/users/{id}

Aggiornamento utente (16.9, W4, SUPER_ADMIN only — guardie v15): policy password sul DESTINATARIO; guardia ultimo SUPER_ADMIN anche sul downgrade (422); plantIds = sostituzione integrale IN TRANSAZIONE (mai utente senza perimetro a metà); reset password → passwordChangedAt + mustChangePassword; audit USER_UPDATE con fields (mai l'hash).

### Risposta
```
object {
      "id": string
      "name": string
      "email": string
      "role": string
      "mustChangePassword": boolean
      "totpEnabled": boolean
      "createdAt": number
      "updatedAt": number
      "plantIds": array<string>
      "sessionCount": number
    }
```
### Body
```
object {
      "name": string | undefined
      "email": string | undefined
      "password": string | undefined
      "role": "TECNICO" | "RESPONSABILE_COMUNE" | "SUPER_ADMIN" | "CLIENTE" | undefined
      "mustChangePassword": boolean | undefined
      "plantIds": array<string> | undefined
    }
```

## DELETE /api/v2/admin/users/{id}

Eliminazione utente (16.9, W4, SUPER_ADMIN only): vietato auto-eliminarsi (422 INVALID_STATE); guardia ultimo SUPER_ADMIN; audit USER_DELETE.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deleted": const [true]
      "id": string
    }
    }
```

## GET /api/v2/admin/permissions

Matrice RBAC v2 (16.9, W4, SUPER_ADMIN only — catalogo statico v15 V12-B portato fedele): 36 permessi modulo:azione, raggruppamento per moduli, matrice 4 ruoli (CLIENTE sola lettura). Payload statico in-memory.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "version": number
      "catalog": array<string>
      "modules": array<object {
      "module": string
      "permissions": array<string>
    }>
      "roles": record<string, array<string>>
    }
    }
```

## GET /api/v2/admin/sessions

Sessioni attive (16.9, W4, SUPER_ADMIN only — V12-G): ONESTÀ v16, la sessione è JWT stateless → tabella Session a 0 righe PER COSTRUZIONE, la nota nel payload lo dichiara invece di fingere un elenco; righe future (database sessions) elencate con utente/scadenza.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "total": number
      "sessions": array<object {
      "id": string
      "userEmail": string
      "userRole": string
      "expires": number
    }>
      "note": string
    }
    }
```

## POST /api/v2/locations/import-kmz/preview

Import punti KMZ/KML FASE 1 — dry-run (16.10, W8 · porta fedele v15 v11.16): multipart/form-data { file (.kmz|.kml max 10 MB), plantId }. Parser v15 completo (zip-bomb 200 voci/20 MB, namespace kml/2.2, description CDATA Google Earth, validazione coordinate e null-island). Produce il PIANO: per ogni placemark CREATE/UPDATE_COORDS/NOOP con motivo (match nome/identificatore/parziale) + proposte dispositivo→punto (ExtendedData IP/hostname = ALTA, token nome = ALTA/MEDIA/BASSA, ambiguo = NESSUNA) — la conferma spetta ALL'OPERATORE. NESSUNA scrittura: il file va in area temporanea (os.tmpdir) con fileId opaco che la apply RIAPRE e RI-PARSA; pulizia file >2 h. BAD_FILE onesto per file non leggibili.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "fileId": string
      "fileName": string
      "plantId": string
      "points": array<object {
      "placemarkIndex": number
      "name": string
      "description": string
      "lat": number
      "lng": number
      "action": "CREATE" | "UPDATE_COORDS" | "NOOP"
      "existingLocationId": string | null
      "existingLocationName": string | null
      "identifier": string | null
      "reason": string
      "deviceProposals": array<object {
      "deviceId": string
      "hostname": string
      "ip": string
      "type": string
      "confidence": "ALTA" | "MEDIA" | "BASSA"
      "basis": string
    }>
    }>
      "created": number
      "updated": number
      "noop": number
      "skipped": array<object {
      "name": string
      "reason": string
    }>
      "unplacedDevices": number
      "totalDevices": number
    }
    }
```

## POST /api/v2/locations/import-kmz/apply

Import punti FASE 2 — conferma operatore (16.10, W8): il client invia SOLO ciò che ha spuntato { fileId, plantId, points[{ placemarkIndex, action, existingLocationId?, deviceIds? }] }. SICUREZZA v15: il file viene RI-PARSA dal server (nome/coordinate dal FILE, non dal payload), existingLocationId e deviceIds riverificati (perimetro dispositivi senza punto reale), un placemark una sola volta, NOOP non riscrive. Le associazioni confermate diventano MANUALI (locationAssignedBy «» = àncore del motore topologico). Il KMZ viene conservato in upload/kmz e registrato su Plant.kmzFile. Audit LOCATION_IMPORT. Tutto in UNA transazione (errore → nulla scritto).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "created": number
      "updated": number
      "assigned": number
      "noop": number
      "linksCreated": number | undefined
      "plantKmzFile": string
    }
    }
```
### Body
```
object {
      "fileId": string
      "plantId": string
      "points": array<object {
      "placemarkIndex": number
      "action": "CREATE" | "UPDATE_COORDS" | "NOOP"
      "existingLocationId": string | null | undefined
      "deviceIds": array<string> | undefined
    }>
    }
```

## DELETE /api/v2/locations/{id}

Elimina punto di ripresa (16.10, W8, role ≥ TECNICO): guardia 409 LOCATION_IN_USE con conteggio se ha dispositivi assegnati (prima vanno spostati). Audit LOCATION_DELETE.

### Risposta
```
object {
      "data": object {
      "deleted": const [true]
      "id": string
    }
    }
```

## GET /api/v2/topology/links

Inventario collegamenti topologici dell'impianto (16.10, W8): filtri source (LINK_SOURCES, 422 se sconosciuta), confidence (HIGH/MEDIUM/LOW/EMPTY), confirmed, q (hostname/etichette/note), paginazione. stats = inventario COMPLETO prima dei filtri (total, confirmed, bySource, byConfidence) — la base del pannello «gestione collegamenti» e del purge. Endpoint arricchiti (hostname/ip/tipo).

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "links": array<object {
      "id": string
      "sourceDeviceId": string | null
      "sourceHostname": string | null
      "sourceIp": string
      "sourceType": string
      "targetDeviceId": string | null
      "targetHostname": string | null
      "targetIp": string
      "targetType": string
      "sourceLabel": string
      "targetLabel": string
      "linkType": string
      "linkStatus": string
      "confidence": string
      "evidence": string
      "sourceOfTruth": string
      "confirmed": boolean
      "sourcePort": string
      "targetPort": string
      "speedMbps": number
      "duplex": string
      "trafficInMbps": number
      "trafficOutMbps": number
      "label": string
      "notes": string
      "updatedAt": number
    }>
      "total": number
      "page": number
      "pageSize": number
      "stats": object {
      "total": number
      "confirmed": number
      "bySource": array<object {
      "source": string
      "count": number
    }>
      "byConfidence": array<object {
      "confidence": string
      "count": number
    }>
    }
    }
    }
```
### Parametri query
```
object {
      "plantId": string | undefined
      "source": string | undefined
      "confidence": "HIGH" | "MEDIUM" | "LOW" | "EMPTY" | undefined
      "confirmed": "true" | "false" | undefined
      "q": string | undefined
      "page": number (default 1)
      "pageSize": number (default 50)
    }
```

## POST /api/v2/topology/links

Crea collegamento MANUALE (16.10, W8, role ≥ TECNICO): la verità dell'operatore — nasce sourceOfTruth=TECHNICIAN, confirmed=true, confidence=HIGH, evidence=TECHNICIAN, linkStatus=ACTIVE (il cavo esiste perché l'operatore lo dichiara). Dispositivi verificati nell'ambito impianto (404), sorgente ≠ destinazione (422), 409 LINK_EXISTS se un collegamento tra i due esiste già (entrambe le direzioni). Audit TOPOLOGY_LINK_CREATE.

### Risposta
```
object {
      "id": string
      "sourceDeviceId": string | null
      "sourceHostname": string | null
      "sourceIp": string
      "sourceType": string
      "targetDeviceId": string | null
      "targetHostname": string | null
      "targetIp": string
      "targetType": string
      "sourceLabel": string
      "targetLabel": string
      "linkType": string
      "linkStatus": string
      "confidence": string
      "evidence": string
      "sourceOfTruth": string
      "confirmed": boolean
      "sourcePort": string
      "targetPort": string
      "speedMbps": number
      "duplex": string
      "trafficInMbps": number
      "trafficOutMbps": number
      "label": string
      "notes": string
      "updatedAt": number
    }
```
### Body
```
object {
      "plantId": string
      "sourceDeviceId": string
      "targetDeviceId": string
      "linkType": "RADIO" | "FIBRA" | "UTP_COPPER" | "FIBRA_SINGLEMODE" | "FIBRA_MULTIMODE" | "WIRELESS_BRIDGE" | "POE_SWITCH" | "ETHERNET" (default "ETHERNET")
      "label": string | undefined
      "notes": string | undefined
      "sourcePort": string | undefined
      "targetPort": string | undefined
      "speedMbps": number | undefined
    }
```

## PATCH /api/v2/topology/links/{id}

Correggi/conferma collegamento (16.10, W8, role ≥ TECNICO): campi cablatura (tipo/etichetta/porte/velocità/stato/note) + confirmed=true = CRISTALLIZZAZIONE v15 (sourceOfTruth=TECHNICIAN, confidence=HIGH, evidence=TECHNICIAN: l'inferenza promossa a verità dell'operatore). 422 NO_CHANGES su payload senza effetto. Audit TOPOLOGY_LINK_UPDATE con diff + crystallized.

### Risposta
```
object {
      "id": string
      "sourceDeviceId": string | null
      "sourceHostname": string | null
      "sourceIp": string
      "sourceType": string
      "targetDeviceId": string | null
      "targetHostname": string | null
      "targetIp": string
      "targetType": string
      "sourceLabel": string
      "targetLabel": string
      "linkType": string
      "linkStatus": string
      "confidence": string
      "evidence": string
      "sourceOfTruth": string
      "confirmed": boolean
      "sourcePort": string
      "targetPort": string
      "speedMbps": number
      "duplex": string
      "trafficInMbps": number
      "trafficOutMbps": number
      "label": string
      "notes": string
      "updatedAt": number
    }
```
### Body
```
object {
      "linkType": "RADIO" | "FIBRA" | "UTP_COPPER" | "FIBRA_SINGLEMODE" | "FIBRA_MULTIMODE" | "WIRELESS_BRIDGE" | "POE_SWITCH" | "ETHERNET" | undefined
      "label": string | undefined
      "notes": string | undefined
      "sourcePort": string | undefined
      "targetPort": string | undefined
      "speedMbps": number | undefined
      "linkStatus": "ACTIVE" | "INACTIVE" | "DEGRADED" | "FAULTY" | "UNKNOWN" | undefined
      "confirmed": boolean | undefined
    }
```

## DELETE /api/v2/topology/links/{id}

Elimina collegamento SBAGLIATO (16.10, W8, role ≥ TECNICO): l'operatore ha dichiarato che le letture bridge/SNMP non riflettono la rete reale — questo è lo strumento per correggerle. Audit TOPOLOGY_LINK_DELETE con la provenienza del link eliminato.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "deleted": const [true]
      "id": string
    }
    }
```

## POST /api/v2/topology/links/purge

Ripulisci le inferenze in blocco (16.10, W8, role ≥ TECNICO): dryRun=true (default) → conteggio onesto + campione di 5, NESSUNA scrittura; dryRun=false → deleteMany in UNA transazione + audit TOPOLOGY_LINK_PURGE. GUARDIA STRUTTURALE: la query esclude SEMPRE confirmed=true e sourceOfTruth=TECHNICIAN (i collegamenti dell'operatore non spariscono MAI); TECHNICIAN tra le fonti → 422 già dal contratto.

### Risposta
```
object {
      "ok": const [true]
      "asOf": number
      "mode": "replay" | "static"
      "data": object {
      "dryRun": boolean
      "count": number
      "sample": array<object {
      "sourceHostname": string
      "targetHostname": string
      "sourceOfTruth": string
    }>
    }
    }
```
### Body
```
object {
      "plantId": string
      "sources": array<"TECHNICIAN" | "LLDP" | "CDP" | "MNDP" | "UISP" | "INFERRED" | "FDB" | "BRIDGE_MIB" | "DAISY_CHAIN" | "FDB_MUTUAL" | "FDB_PAIR" | "STP_DESIGNATED">
      "dryRun": boolean (default true)
    }
```
