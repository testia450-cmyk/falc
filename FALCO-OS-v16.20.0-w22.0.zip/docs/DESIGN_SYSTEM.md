# DESIGN SYSTEM — FALCO-OS v16 (W1 + 16.1.0-w2.0)

## 1. Token (DUE TEMI ATTIVI: scuro predefinito + chiaro — piano §4.1, D7 aggiornata)

Implementati in `src/app/globals.css` come variabili CSS e mappati su Tailwind 4 (`@theme inline`) e sulle variabili shadcn/ui: **nessun colore sparso nei componenti** (verifica: `rg '#[0-9a-f]{6}' src/views src/components` → solo i port dei motori, mai classi UI).

**Commutazione tema**: next-themes (`attribute="class"`, default **scuro**, scelta persistita in locale; `enableSystem=false`: scelta esplicita dell'operatore). `color-scheme` segue il tema (controlli nativi coerenti); `--on-primary` token dedicato (nel chiaro il testo su `--primary` è bianco: il riuso di `--text` scuro dava contrasto insufficiente).

| Token | Valore | Uso Tailwind | Contrasto su superficie |
|---|---|---|---|
| `--bg` | `#051224` | `bg-background` | — |
| `--sidebar-bg` | `#06172C` | `bg-sidebar-bg` | — |
| `--surface` | `#0A1B33` | `bg-surface` (Card/Popover) | — |
| `--raised` | `#14263E` | `bg-raised` (Secondary/Muted/Accent) | — |
| `--primary` | `#0A4FB8` | `bg-primary` / voce nav attiva | — |
| `--link` | `#4DA3FF` | `text-link`, `--ring` | 6,57:1 ✓ testo |
| `--text` | `#F2F6FC` | `text-foreground` | 15,9:1 ✓ |
| `--text-2` | `#8FA3BF` | `text-text-2` | 6,7:1 ✓ testo secondario |
| `--text-dim` | `#5E7391` | `text-dim` | 3,56:1 — **solo decorativo** (mai informazioni utili; usato per etichette di gruppo e voci disabilitate con testo nel `title`) |
| `--ok` | `#06BF72` | `text-ok`, `bg-ok` | 7,15:1 ✓ |
| `--warn` | `#FCA830` | `text-warn` | 8,86:1 ✓ |
| `--crit` | `#F54146` | `text-crit` | 4,70:1 — mai sotto 14px senza icona |
| `--border` | `#1B3150` | `border-border` | 1,32:1 — **solo decorativo** |
| `--control-border` | `#5F7BA0` | `border-control-border` (input/select/pulsanti secondari) | 3,97:1 ≥ 3:1 ✓ controlli |

Varianti `-soft` (fondi tinta 12-16%) per badge e riquadri: `bg-ok-soft`, `bg-warn-soft`, `bg-crit-soft`, `bg-info-soft`.

Token di supporto per tema: `--on-primary`, `--scrim`/`--scrim-shadow` (velo etichette), `--marker-ring` (anello marker mappa/nodi mini), `--minimap-mask`.

**Tema chiaro — ATTIVO dal 26/10/2026** (richiesta operatore; era pianificato in W6 — D7 aggiornata). Stessi token, palette `.light`: bg `#f4f7fb`, surface `#ffffff`, testo `#101826`/`#46596F`, ok `#06875A`, warn `#B26A00`, crit `#D02A30`, border `#D4DDE8`. Contrasti dichiarati: testo 15,8:1 · testo-2 8,9:1 · link 7,0:1 · ok 5,3:1 · warn 5,3:1 · crit 5,9:1 · control-border 4,9:1.

**Palette JS** (`src/lib/client/theme-palette.ts`): per gli elementi che NON possono usare classi token (attributi SVG di recharts, `divIcon` di Leaflet, MiniMap di xyflow) l'hook `usePalette()` restituisce la palette del tema attivo; `useIsHydrated()` (useSyncExternalStore) evita mismatch di idratazione; `statusColor(status, palette)` per marker/punti. Duplicazione 1:1 dei token CSS documentata qui (fonte visiva unica di fatto: globals.css). Tile mappa per tema: scuro → CartoDB `dark_all` (attribuzione «© OpenStreetMap contributors © CARTO»), chiaro → OSM standard, satellite invariato.

## 2. Regole fissate

- **Stato = colore + icona + testo, sempre** (`StatusBadge`): Online (Wifi), Degradato (TriangleAlert), Offline (WifiOff), Manutenzione (Wrench), Sconosciuto (HelpCircle), Non monitorato (EyeOff). Nessun «punto colorato» in tabella (difetto mockup §3.3.2 sanato).
- **Tipografia**: Geist Sans (Geist Mono per gli import tecnici); `font-variant-numeric: tabular-nums` globale (classe `.num` rafforza) per IP/MAC/metriche. Scala: 12/13/14/16/20/28 px.
- **Spaziatura**: griglia 4 px (`gap-1/2/3/4/6`, padding `p-4/p-6`); raggi 8 px (`--radius`); ombre minime; niente neon.
- **«Live»**: pulse dell'anello SOLO senza `prefers-reduced-motion` (media query globale che disattiva ogni animazione).
- **Focus visibile**: `:focus-visible` globale con anello `--link` 2px + offset 2.
- **Scrim**: `.scrim-label` con velo `--scrim` e colore testo `--text` (adatta al tema: scuro 82% / bianco 92%) per ogni etichetta sopra mappa e grafo (difetto mockup §3.3.4 sanato).
- **Footer sticky**: wrapper `min-h-screen flex flex-col` + `footer.mt-auto` (verificato: contenuto lungo → spinto; contenuto corto → attaccato al fondo).

## 3. Componenti condivisi (una sola versione ciascuno — §4.2)

| Componente | File | Stati obbligatori |
|---|---|---|
| `AppShell` | `components/app-shell.tsx` | login/loading/authenticated |
| `Sidebar` | `components/sidebar.tsx` | **8 voci attive** (IA completa); su mobile dentro lo Sheet della Topbar |
| `Topbar` | `components/topbar.tsx` | ricerca cmdk, **hamburger+Sheet sotto lg**, toggle tema, badge allarmi reale, badge Live onesto, orologio client, meta theme-color dinamica |
| `GlobalSearch` | dentro Topbar (CommandDialog) | vuoto / min 2 caratteri / caricamento / risultati raggruppati |
| `KpiCard` | `components/kpi-card.tsx` | barra a stati con aria-label testuale, definizione in tooltip, asOf |
| `StatusBadge` / `StatusDot` | `components/status-badge.tsx` | 6 stati |
| `DataTable` | `views/dispositivi-view.tsx` (TanStack Table + virtualizzazione) | skeleton/errore/vuoto |
| `QuickLook` | `components/quick-look.tsx` | §6.3: 360px desktop, bottom sheet mobile, Esc, «n.d.» |
| `PageHeader` | `components/page-header.tsx` | breadcrumb + data/ora + ReplayBadge |
| `StaleIndicator` / `AsOf` / `ReplayBadge` | `components/stale-indicator.tsx` | onestà §2.1-2.2 |
| `EmptyState` / `ErrorPanel` / `LoadingRows` | `components/states.tsx` | — |
| `MapView` | `components/map-view.tsx` | Leaflet, tile per tema (CartoDB dark/OSM) + ArcGIS satellite con attribuzioni, marker scrim, legenda |
| `TrafficChart` | `components/traffic-chart.tsx` | definizione D3 in tooltip, vuoto senza dati, palette tema |
| `TopologyView` | `components/topology-view.tsx` | §6.2: ELK layered, zoom semantico (<0.55 = pallini), keyboard nav, minimappa palette tema |
| `OperazioniView` | `views/operazioni-view.tsx` | tab Ticket/Finestre: KPI con definizioni, filtri, righe espandibili, azioni solo transizioni legali, dialog nuovo ticket, dialog «Nuova finestra» (16.2), azioni pausa/elimina con conferma, EmptyState onesto |
| `WallboardView` | `views/wallboard-view.tsx` (16.2) | overlay fullscreen per monitor: 4 KPI grandi con tick realtime, allarmi per gravità, link deboli, orologio, badge Live/Riproduzione onesti, Fullscreen API con fallback, Esc=uscita, tema chiaro/scuro; NON è voce di menu (modalità di presentazione) |
| `ReportView` | `views/report-view.tsx` | 4 export reali (3 CSV + «Sintesi impianto PDF» via stampa del browser, 16.2), roadmap W2 statica NON interattiva, sintesi reale |
| `AmministrazioneView` | `views/amministrazione-view.tsx` | Sistema/Conteggi/Registro audit (max-h-96 scroll)/Account/Roadmap |

Ogni vista rispetta: caricamento (skeleton) · vuoto (EmptyState) · errore (ErrorPanel con Riprova) · dato obsoleto (StaleIndicator) · permesso negato (401 → login, 403 → messaggio).

## 4. Onestà del dato nella UI (regole applicate)

- Valori mancanti → **«n.d.»** (mai 0 spacciato per misura): `fmtDbm/fmtPct/fmtUptime` restituiscono «n.d.» su 0/null (convenzione radio-metrics.ts:25 del repo).
- `signalStrength 0` = mai interrogato → `signalPresent=false` → non mostrato.
- Ogni numero aggregates mostra `asOf`; la KPI porta la definizione in tooltip; il footer dichiara versione build reale e modalità riproduzione.
- KPI barre: `totale = online+degradato+offline+manutenzione+sconosciuto+non monitorato` (gli allarmi non entrano nella somma — sanato il difetto mockup §3.3.1).

## 5. Accessibilità (W1 + 16.1.0-w2.0)

- Navigazione tastiera: sidebar bottoni, tabella (TanStack), grafo (nodi focusable + frecce + Invio), palette (cmdk), dialog (Radix focus-trap), Esc chiude quick-look; **su mobile navigazione a sportello** (hamburger + Sheet, sotto lg).
- `aria-live="polite"` sul contatore allarmi della campanella e sul badge Live.
- Tabelle con `caption`, `scope="col"`, `aria-sort`; icone decorative `aria-hidden`; testi alternativi reali.
- Target tocco ≥ 44px dove interattivo su mobile (bottoni h-9/44px, righe cliccabili alte).
- `prefers-reduced-motion`: pulse e transizioni disattivate.
- Toggle tema con `aria-label` dinamico («Passa al tema chiaro/scuro»); tema applicato prima del paint (nessun flash).
- Non ancora fatto (W2 piena): audit axe sistematico, screen reader manuale, wallboard TV.
