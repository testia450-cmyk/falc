> **AGGIORNAMENTO 16.13.0 (30/10, onde W4+W8+W9+W10+W11 chiuse):** W4 piena (knowledge
> base, RMA guidata, ondate, CVE con 79 finding reali, speed test, assistente AI, utenti e
> permessi); multi-impianto con import KMZ/KML; topologia «a raggiera»; impianti «a sé
> stanti» (Device.plantId diretto); RETE REALE dell'operatore: import Excel «formato SETI»
> e percorsi KMZ che hanno SOSTITUITO i 892 link auto-scoperti con 181 collegamenti reali
> (183 nodi · 178 archi · 1 irraggiungibile dichiarato, radice Router SETI). Colmati i gap
> §1.5 import KMZ/Excel. Dettagli nel ROADMAP §3.

# PARITÀ v15.16.0 → v16 — matrice di verifica (29/10/2026, aggiornata 16.13.0-w11.0)

> **AGGIORNAMENTO 16.8.0 (29/10, onde W2+W6 chiuse):** report SLA mensile+storico, scheda
> intervento stampabile, report schedulati (W2 piena); catena audit a prova di manomissione
> con formula RECUPERATA dal sorgente v15 superstite (il verificatore v16 conferma la catena
> REALE: 64/64 sigilli · 47.348 righe · zero rotture), export certificato SHA-256 col
> contratto v15, hardening dimostrato (W6). Dettagli nelle sezioni 1.8/1.9/1.10.

> Verifica richiesta dall'operatore: «vedi cosa manca nella roadmap, verifica con lo zip del
> progetto originale se hai impostato tutto quello che faceva il vecchio software».
>
> **AGGIORNAMENTO 16.6.0-w3.4 (27/10 sera):** su richiesta dell'operatore («riesci a fare
> scansione rete? adozione, SNMP, OUI, ONVIF, vendor?») i MOTORI DI RETE ATTIVI di v15 sono
> stati portati in v16 come capacità viva (mini-service discovery :3002 + API /api/v2/discovery/*
> + coda adozione /api/v2/adozione + tab «Scansione & Adozione"): scansione TCP, sonda SNMP
> v1/v2c/v3 con vendor da enterprise OID, ONVIF GetDeviceInformation, database OUI IEEE
> 10.679 prefissi, sweep UDP Ubiquiti/MNDP/WS-Discovery, fusione evidenze v15. Questo NON
> cambia la natura replay del DB (i poller non girano in sandbox): la sonda è ON DEMAND
> dall'operatore e scrive solo attraverso l'adozione umana. Voci aggiornate: §1.6 coda adozione,
> §1.2 righe discovery, §2.5, §3.
>
> **Fonti**: repo originale estratto da `FALCO-OS-v15.16.0.zip` (upload/folder/7da6efe5,
> estratto in /home/z/falco-ref — 248 file route · 117 gruppi API · 174 con scrittura ·
> 21 job per impianto + 17 globali · 20+ integrazioni · ~4200 test) contro il progetto v16
> corrente **16.4.0-w3.2** (24 file route v2 / 29 endpoint · 8 viste + wallboard ·
> realtime replay :3001). Metodo: inventario v15 per dominio (CodiceBase, STATO-PROGETTO,
> lettura diretta delle rotte) × stato v16 (codice + verify-api.sh + worklog Task 1–24).

## Legenda

| Simbolo | Significato |
|---|---|
| ✅ | Consegnato e verificato in v16 (riferimento release) |
| 🟡 | Parziale: il dato è visibile/in lettura, mancano parti dell'originale |
| ⬜ | Pianificato in una onda della roadmap §1 (non ancora costruito) |
| ⚠️ | **GAP NON PIANIFICATO** — esisteva in v15.16.0, non è in nessuna onda: serve decisione |
| ❌ | VETATO dall'operatore (W5: VPN/ISP/VLAN, ARCHITETTURA §16) |
| ⚙️ | Non applicabile alla sandbox: richiede poller/rete reale (modalità riproduzione D2 dichiarata) |

**Riepilogo**: capacità v15 inventoriate **92** → ✅ **24** · 🟡 **11** · ⬜ **21** · ⚠️ **28** · ❌ **3** · ⚙️ **5**.

Il core NOC (stati, dashboard, topologia, allarmi+ACK, telecamere, ticket, manutenzioni,
gruppi, wallboard, report disponibilità) è **consegnato e verificato**; la parte operativa
pesante di v15 (config/firmware/terminal/integrazioni/AI) è in gran parte **fuori roadmap
esplicita** → vedi §3 (28 voci ⚠️ da allocare).

---

## 1. Matrice per dominio

### 1.1 Shell, navigazione, presentazione

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Login NextAuth credentials + gate password | ✅ 16.0 (W1) | overlay login reale bcrypt |
| Mappa home: vista geografica | ✅ 16.0 (W1) → **16.17** | Rete → tab Mappa (coordinate reali KMZ); **v16.17 W18 (pattern UISP): popup col nome del punto al click, pannello «dispositivi della sede» con elenco completo cliccabile (filtro locationId), LINEE della rete sul territorio dall'albero topologico (stesse fonti/colori del canvas, tooltip con capi e segnale)**; tasto «Importa Excel/KMZ» → deep-link ?sez=impianti |
| Mappa home: vista topologica React Flow | ✅ 16.0 (W1) | 200 nodi/171 archi, ELK, vista gateway |
| Mappa home: vista «Livelli» (tiers) | 🟡 | tiers calcolati (buildPlantTiers) e usati nel grafo/cluster; vista dedicata con scelta root operatore non separata |
| Wallboard multi-monitor | ✅ 16.2.0-w2.1 | ?view=wallboard, KPI live dal tick |
| Command palette | ✅ 16.0 (W1) | ⌘K raggruppata |
| Tema chiaro/scuro | ✅ 16.1.0-w2.0 | next-themes + token AA (16.3.1) |
| Selettore impianto multi-plant / flotta 100+ impianti | ⚠️ | v16 è single-plant (l'impianto reale è 1); /api/v2/plants esiste in lettura; workspace «flotta» v15 non pianificato |
| Profili shell NOC/Campo/Admin | ⚠️ | non pianificato |
| PWA (service worker, offline.html, push registrar) | ⚠️ | non pianificato |
| Notification dropdown in-shell | 🟡 | toast sonner sì; centro notifiche v15 no |

### 1.2 Monitoraggio

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Stati autoritativi (monitoring-engine) | ✅ port (D-B) | computeDegradedStatus portato; UNKNOWN mai OFFLINE (regola §2.2) |
| Dashboard KPI + qualità del dato | ✅ 16.0 (W1) | somma esatta, copertura 56,1% dichiarata |
| Tabella dispositivi con filtri/export | ✅ 16.0 (W1) → **16.17** | virtualizzata, CSV; **v16.17: filtro per sede (locationId additivo) — alimenta il pannello dispositivi del punto sulla mappa** |
| Scheda dispositivo multi-tab | 🟡 | 16.0: 5 tab (Panoramica/Collegamenti/Metriche/Configurazione/Storico); v15 ne aveva 10 — mancano: porte, credenziali, azioni (poll/reboot), stazioni radio live |
| Tabella PORTE switch (PoE, MAC, speed) | ✅ 16.5.0-w3.3 → 16.15 | consegnata W3-proroga; **v16.15: + stato STP per porta** (forwarding/blocking/root port, bridge designato) dal modello StpObservation |
| Metriche serie temporali | ✅ 16.0/16.4 | traffic series + overview device + disponibilità |
| Rollup aggregati 5m/1h + retention metriche | ⚙️ | job di aggregazione: senza poller non ha dato da aggregare; in produzione con v15 backend |
| Health score composito 0–100 (device/impianto) | ⚠️ | motori v15 (health-score) NON nella roadmap v16 |
| «Perché non ho metriche» (polling health) | 🟡 | derivazione NOT_MONITORED + pannello qualità; diagnosi cause (NO_SCHEDULE/AUTH_FAILED/…) non riprodotta |
| Camera health RTSP/HTTP | ✅ 16.3.0-w3.0 | registro flussi con finestra dichiarata + hold D17 |
| Radio metrics (CCQ/SNR/catene) | ✅ port (W1) | computeSnr/deduceLinkMode portati |
| Link deboli / signal score | ✅ 16.0 (W1) | computeSignalScore portato; ST 60 Comune −93 visibile |
| NetFlow/sFlow (top talkers, analytics) | ⚙️ | nessun dato flow nel DB reale; capacità non pianificata nella roadmap |
| Speed test iperf3 | ✅ 16.9 | API+UI v15 G6 portate; executor assente → 501 onesto senza riga; SIMULATED marcato |
| Service check TCP/HTTP + cron | ⚠️ | esisteva (services/*); non pianificato |
| DCI SNMP/HTTP custom | ✅ 16.7 | custom-oids CRUD + test SNMP LIVE via discovery-service; HTTP custom resta da fare (HTTP DCI) |
| Packet capture / syslog / trap ingest | ⚙️ | listener UDP: richiede rete reale; non pianificato. La SONDA SNMP on-demand è invece operativa dal 16.6 (motore :3002) |
| **Attivazione SNMP assistita (v15 non l'aveva!)** | ✅ **16.18 W19** | attuatore separato dalla sonda (read-only intoccabile): ricette per-vendor con comandi mostrati IN CHIARO prima della conferma — SSH (RouterOS/airOS coi 3 campi scritti/EdgeOS/Cisco/Aruba/Huawei/FortiGate/Juniper/TP-Link/Ruckus/Dell), API HTTP digest SwOS (RB260GSP), manuali onesti (Hikvision/Dahua/PLANET/UniFi/Cambium), telecamere ping-only con spazzata presenza + storia online/offline; stati persistenti in UI (ENABLED/UNVERIFIED/FAILED/MANUAL_REQUIRED) e community cifrata |
| Statistiche flotta / MTTD-MTTR / forecast | 🟡 | admin/stats (coveragePct reale) + report disponibilità; MTTR/previsionale v15 non riprodotti |
| Capacity forecast (fit r², saturazione) | ⚠️ | motori v15 non in roadmap v16 |

### 1.3 Allarmi

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Lista eventi + filtri + severità | ✅ 16.0 (W1) | 82 aperti reali |
| ACK con nota + audit | ✅ 16.0 (W1) | ALERT_ACK verificato end-to-end |
| Correlazione first-out (RCA) | ✅ port (W1) | rootCause/catena a valle visibili (SW_P01 → 19 vittime) |
| Sospensione da finestre manutenzione | ✅ 16.2→16.4 | fail-open preservato, scope gruppi |
| Regole allarme CRUD (SYS:* + utente) | ✅ 16.7 | event-policies CONSEGNATE: 10 regole SYS reali tarabili (MAI eliminabili), CRUD utente validato su dati reali |
| Instradamento gravità→canali (alert-routing) | ⚠️ | non pianificato (dipende dalle integrazioni) |
| Digest / escalation / rate-limit | ⚠️ | non pianificati |
| Watchdog proattivo (regole + check) | ⚠️ | non pianificato |
| Threshold suggestions + pattern learning | ⚠️ | non pianificati |
| Anomalie 1G/2G (MAD+EWMA+stagionale) | ⚠️ | motori v15 non in roadmap v16 |
| Post-mortem SRE per incidente | ⚠️ | non pianificato |
| Diagnosi guidata (prove→ipotesi→1 proposta) | 🟡 16.9 | «assistente» consegnato con AI su contesto reale (D24); il ReAct orchestrato v15 con prove→ipotesi non portato |

### 1.4 Topologia e mappa

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Grafo collegamenti reale | ✅ 16.0 (W1) | 892 link reali, confidenze |
| Motore verità (link-rules + reachability BFS) | ✅ port (D-B) | portati con provenienza file:riga |
| Quick-look / catena verso gateway | ✅ 16.0 (W1) | |
| Pannello link detail (stile UISP) | 🟡 | weak links + catena; pannello dedicato per singolo link non separato |
| Qualità topologia (copertura, unplaced) | ✅ 16.0 (W1) | 56,1% vs goal 70 dichiarato |
| CRUD link / inferenza / import LibreNMS-NetBox | 🟡 16.10→16.15 | gestore collegamenti ✅ W8; sorgenti link LLDP/CDP/FDB ✅ W12; **correlazione multi-switch FDB_MUTUAL/STP ✅ 16.15** (batch «Tutti gli switch»); import LibreNMS/NetBox non pianificato |
| Tabella ARP (ipNetToMedia) + correlazione IP→MAC | ✅ 16.15 → 16.16 | il modello ArpEntry esisteva da v15 SENZA motore: la sonda L2 v16.15 legge ipNetToMedia+ipNetToPhysical (OID verificati) e la riempie; **v16.16: i candidati ARP (MAC→IP non in inventario) si adottano a un click dal report batch** (POST /api/v2/discovery/l2/adopt-arp: dichiarazione umana, vendor IEEE dal database OUI, guardie MAC/IP, audit ADOZIONE_ARP_ADOPT) |
| Lettura STP (dot1dStpPortDesignatedBridge) | ✅ 16.15 | nuovo modello StpObservation + motore: porte, bridge designati, root; alimenta la direzione dell'albero della correlazione |
| Inventario VLAN (dot1qVlanStaticTable) | ✅ 16.15 | nuovo modello VlanInventory + PVID per porta nel report L2 |
| Pannello conflitti link | ⚠️ | non pianificato |
| Wireless: subscriber→AP map, domini WLC | ⚠️ | non pianificato (link radio deboli ✅ in dashboard) |
| Routing OSPF/BGP sessions | ⚙️ | nessun dato nel DB reale; non pianificato |
| MAC inventory (FDB × inventario) | ✅ 16.5.0-w3.3 → 16.15 | GET /api/v2/mac-inventory, tab MAC in Rete; **v16.15: + IP risolto dalla tabella ARP** per ogni MAC (join ArpEntry) |
| Mappa custom (layout salvato) | 🟡 | layout ELK deterministico; posizioni nodi persistenti v15 no |

### 1.5 Telecamere / LPR

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| KPI flussi + tabella apparati video | ✅ 16.0 (W1) | 102 apparati, 5 flussi fermi reali |
| Registro flussi con finestra dichiarata | ✅ 16.3.0-w3.0 | uptime SOLO su campioni presenti |
| Filtro sede | ✅ 16.3.0-w3.0 | 41 sedi reali |
| Punti di ripresa + triage «da classificare» | 🟡 | locations in lettura; triage/auto-assegnazione v15 no |
| Import punti KMZ/KML con preview | ✅ 16.10.0-w8.0 · 16.13.0-w11.0 · **16.17** | porta v15 a 2 fasi (preview→apply, fileId opaco, zip-bomb guard); 16.13: anche POLILINEE «Linea» → gap-link sede↔sede con regole d'onestà (mai secondo padre, mai gateway come stazione); **16.17 W18: tasto «Importa Excel/KMZ» direttamente dalla tab Mappa (deep-link ?sez=impianti)** |
| Import Excel installazione (SETI) + template | ✅ 16.13.0-w11.0 · **16.17** | parser «formato SETI» (sezioni-sede, apparati IPv4, SSID, seriali), piano con abbinamento fuzzy sezione↔sede correggibile in anteprima, apply in transazione con credenziali CIFRATE AES-256-GCM, link radio dai gruppi SSID + LAN di sede, proposte basestation sintetica mai pre-spinflate; tetti 15 MB/200k celle; **16.17 W18: raggiungibile anche dalla mappa — è il motore di ricostruzione della rete e la mappa lo presenta subito** |

### 1.6 Config, firmware, operazioni evolute

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Config backup SSH + archivio + diff | 🟡 16.7 | config-requests CONSEGNATE (guardrail v15 + commit-confirm + dry-run dichiarato); backup SSH con archivio/diff richiede esecuzione reale — non in replay |
| Config requests con guardrail/commit-confirm | ✅ 16.7 | macchina a stati completa + FORBIDDEN_COMMAND_PATTERNS + finestra confirmBy (WINDOW_EXPIRED) |
| Bulk config (max 50, report per-device) | ✅ 16.7 | guardrail R8 + report per-device (dry-run SIMULATED dichiarato; SSH → 422 REPLAY_NOEXEC) |
| Vendor CLI registry + script SSH | 🟡 16.7 | automation-tasks con category template CLI; l'esecuzione SSH richiede i motori attivi |
| Terminale SSH in-app con audit | 🟡 16.7 | sonda REALE porta 22 + audit TERMINAL_PROBE; sessione interattiva MAI emulata in replay (onesto) |
| FalcoScript DSL / automation-tasks | ✅ 16.7 | CRUD completo con tetto guardrailMaxDevices; run non disponibile in replay (runCount 0 onesto) |
| Firmware center + rollout + scheduler | 🟡 16.7 | schedulazione job + cancel con audit; esecuzione NON disponibile in replay (dichiarato) |
| Ondate preflight→canary→lotti (R8) | ✅ 16.9 | pianificazione COMPLETA (preflight reale con scarti onesti, lotto 1 canary, ConfigWaveItem) + D2: motore di esecuzione dichiarato non attivo in riproduzione |
| Provisioning multi-vendor | ⚠️ | resta non pianificato (richiede esecuzione SSH attiva) |
| RMA guidata con genealogia | ✅ 16.9 | port fedele decisione 53 v15.12.0: piano BFS + esecuzione 5 passi con credenziali cifrate portate; verificata E2E e revertita (D25) |
| Playbooks multi-step | ✅ 16.7 | CRUD con builder passi (vocabolario azioni v15); esecuzione dichiarata non disponibile in replay |
| Template SNMP vendor importabili (v15.16!) | ⚠️ | RESTA il gap più concreto di parità v15.16: non consegnato (SnmpVendorTemplate=0 nel DB; il motore probe custom-oid copre il bisogno base) |
| Ondate (waves) config già nel DB reale | ⚙️ | 37 ScheduledJob reali visibili; motori non eseguiti in replay |

### 1.7 Manutenzione e gruppi

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Finestre manutenzione CRUD + scope | ✅ 16.2→16.4 | create/pause/resume/delete + PATCH completa + scope gruppi |
| Gruppi dispositivi MANUAL | ✅ 16.3.0-w3.0 | CRUD + membership sostituzione |
| Gruppi dispositivi DYNAMIC (regole runtime) | ✅ 16.4.0-w3.2 | regola validata sui valori reali, D18 |
| Coda adozione (orfani/duplicati/nuovi host) | 🟡 16.6 | **Coda orfani CONSEGNATA (16.6.0)**: GET/POST /api/v2/adozione — 30 orfani reali, adozione umana con audit ADOZIONE_ADOPT, dismiss per i «da confermare»; UI nel tab Scansione & Adozione. Duplicati e lifecycle restano non pianificati |
| Duplicati device (coda, mai auto-merge) | ⚠️ | non pianificato |
| Lifecycle installazione→dismissione | ⚠️ | non pianificato |

### 1.8 Ticket, SLA, interventi

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Ticket CRUD + macchina a stati | ✅ 16.1.0-w2.0 | INVALID_TRANSITION 422, audit |
| KPI ticket (open/overdue…) | ✅ 16.1.0-w2.0 | |
| SLA definizioni + escalation | 🟡 | SLADefinition=0 nel DB reale (dichiarato D19); escalation engine non pianificato |
| Report SLA (tempi risposta/risoluzione) | ✅ 16.8.0 | GET /api/v2/reports/sla: coorte mensile, tempi al netto pause SLA, copertura dichiarata (0/74) |
| Scheda intervento PDF | ✅ 16.8.0 | GET /api/v2/tickets/{id} + dialog stampa browser (pattern sintesi impianto) |
| Interventi workflow (Telegram) | 🟡 | modello Intervention esiste (0 righe reali); workflow v15 no |
| Auto-ticketing da allarmi (osTicket/interno) | ⚠️ | non pianificato |
| Email→ticket (IMAP) | ⚠️ | non pianificato |
| Knowledge base per impianto | ✅ 16.9 | CRUD + «da ticket» (Problema/Soluzione reali); KB=0 righe nel DB reale → empty onesto |
| Portale clienti read-only | ⚠️ | non pianificato |
| Commenti/allegati/ore su ticket | 🟡 | TicketComment=0 nel DB reale; UI dettaglio con rootCause/resolution; allegati/ore no |

### 1.9 Report

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Export CSV reali (inventario, disponibilità) | ✅ 16.1/16.4 | |
| Sintesi impianto PDF (stampa browser) | ✅ 16.2.0-w2.1 | |
| Report disponibilità rete (perdita pacchetti) | ✅ 16.4.0-w3.2 | finestra dichiarata + copertura effettiva (D19) |
| Report schedulati PDF (job + artefatti) | ✅ 16.8.0 | CRUD ScheduledReport v15 completo; il MOTORE non gira in replay (D2): runCount 0, nessun artefatto — dichiarato |
| Report con sezione TOPOLOGIA (cambi 7gg) | ⚠️ | cambi topologia storici non pianificati |
| Export impianto JSON completo | 🟡 | esporti CSV; export JSON perimetro v15 no |
| Export audit certificato (SHA-256) | ✅ 16.8.0 | contratto v15 V12-F: header x-falco-export-sha256 = digest del body (verificato byte-per-byte), CSV RFC 4180 |
| Report SLA storico | ✅ 16.8.0 | history mese-per-mese nella stessa API + tabella con export CSV |

### 1.10 Amministrazione e sicurezza

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Vista amministrazione (statistiche reali) | ✅ 16.1.0-w2.0 | sola lettura + roadmap onesta |
| Utenti/ruoli RBAC matrice | ✅ 16.9 | CRUD utenti con policy password V12-H + guardie v15; matrice RBAC v2 statica (36 permessi × 4 ruoli); sessioni con onestà JWT |
| Ruoli in API v2 (TECNICO/SUPER_ADMIN) | ✅ | hasRole su mutazioni |
| 2FA TOTP | ⚠️ | non pianificato |
| Sessioni attive + revoca | 🟡 16.9 | elenco onesto (JWT stateless → 0 righe per costruzione, nota nel payload); revoca non applicabile senza sessioni persistite |
| API token personali | ⚠️ | non pianificato |
| Password policy / scadenza | ⚠️ | lockout portato ( decisione B) ma policy UI no |
| Audit log visualizzazione | ✅ 16.1.0-w2.0 | 48k righe, filtro azione |
| Audit chain seal + verifica integrità | ✅ 16.8.0 | formula RECUPERATA dal sorgente v15 superstite: verificatore conferma la catena reale 64/64 sigilli · 47.348 righe; sealer API continua la catena v15 |
| Backup sistema in-app + retention | ⚠️ | il runbook usa zip esterni; backup in-app non pianificato |
| Feature flags runtime | ⚠️ | non pianificato |
| OpenAPI generata | ✅ equivalente | API_CONTRATTI.md generato da zod (gen-api-contracts.ts) |
| Cifratura AES-256-GCM credenziali | 🟡 | presente nel DB/modello; gestione UI credenziali no |
| System health / DB health | ✅ 16.1 | /api/v2/system/health |
| Suite test / certificazione | ✅ 16.8.0 | a11y 19/19, verify-api §1-§3g TUTTO VERDE (82 route), pacchetto certificazione (scripts/gen-cert-package.sh); vitest NON portato (dichiarato: la disciplina della piattaforma è verify-api+tsc+lint+browser) |

### 1.11 Integrazioni (onda W7 CONSEGNATA 16.7.0: configurazione cifrata + test reali + webhook HMAC verificato)

| Capacità v15.16.0 | Stato v16 |
|---|---|
| Telegram (bot, notifiche, comandi, report) | 🟡 16.7 | config cifrata AES + test getMe REALE (401 ai token falsi = verità); il BOT attivo richiede i motori |
| osTicket (auto-ticketing + sync) | 🟡 16.7 | config cifrata; sync richiede i motori |
| SMTP/IMAP (email, email→ticket) | 🟡 16.7 | config cifrata + test TCP reale; invio/ricezione richiedono i motori |
| Grafana (endpoint Infinity) | 🟡 16.7 | config cifrata + test HTTP reale |
| check_mk agent | 🟡 16.7 | config cifrata |
| cnMaestro / UniFi controller read-only | 🟡 16.7 | config cifrata; autosync richiede i motori |
| Splashtop sessioni remote | 🟡 16.7 | config cifrata |
| Web Push VAPID | ⬜ | non nella linea d'onda W4 §1 della roadmap e non consegnata (nessun dato/driver reale; dichiarata) |
| Webhook firmati HMAC + retry/dead-letter | ✅ 16.7 | firma HMAC-SHA256 CONSEGNATA E VERIFICATA end-to-end in sandbox (eco sha256+timestamp, signatureVerified); consegne registrate con attempts/maxAttempts; il worker di retry periodico resta da attivare con i motori |
| LDAP/AD | 🟡 16.7 | config cifrata; autenticazione richiede i motori |
| Exporter Prometheus | ⬜ | non consegnata |
| Proxy agents / zone / poller workers / discovery relay / field-worker | ⚙️ ⚠️ | protocolli di raccolta: senso solo con rete reale |

### 1.12 AI / assistente

| Capacità v15.16.0 | Stato v16 | Nota |
|---|---|---|
| Chat AI operatore (Ollama, SSE) | ✅ 16.9 | assistente in STREAMING reale su contesto REALE del DB — model della piattaforma z-ai al posto di Ollama (D24); audit bounded senza contenuto |
| Agenti ReAct con 2-man rule / memoria | ⚠️ | non pianificato |
| Rizzo Flow sidecar + calibrazione | ⚠️ | servizio esterno; non pianificato |

### 1.13 VETATE (decisione operatore 26/10/2026)

| Capacità | Stato |
|---|---|
| Tunnel VPN | ❌ W5 |
| Uplink ISP/WAN | ❌ W5 |
| Entità VLAN | ❌ W5 |

---

## 2. Lettura di insieme (cosa dice la verifica)

1. **Il core NOC è davvero consegnato**: tutto ciò che l'operatore usa ogni giorno per
   VEDERE lo stato dell'impianto (dashboard, dispositivi, scheda, topologia, allarmi+ACK,
   telecamere, ticket, manutenzioni, gruppi, wallboard, report) è ✅ e verificato con i dati
   reali dell'impianto «egidio» (200 dispositivi, 725k+ metriche, 82 allarmi aperti).
2. **La parte «si agisce sulla rete» di v15 è quasi tutta da costruire**: config/firmware/
   terminal/bulk/playbook/automation (⬜ W3) sono pianificati; provisioning e template SNMP
   v15.16 NON lo sono (⚠️).
3. **Le integrazioni sono il buco più grande**: 12 famiglie di integrazione di v15
   (Telegram, osTicket, SMTP/IMAP, Grafana, check_mk, controller, Splashtop, Push, webhook,
   LDAP, Prometheus, agenti remoti) non hanno alcuna voce nelle onde W3/W4/W6.
4. **L'intelligenza MOTORIA di v15 non è in roadmap** (l'assistente AI invece È consegnato in
   16.9 con streaming su contesto reale — D24): anomalie 1G/2G, watchdog proattivo, pattern
   learning, threshold suggestions, health score, capacity forecast, post-mortem, adozione
   restano 8 motori non allocati.
5. **Modalità riproduzione onesta**: i job e i poller di raccolta NON girano nella sandbox
   (D2 dichiarato in UI e API con mode:'replay'); il dato reale congelato + jitter minimi
   attorno ai valori reali. In produzione servirà una decisione: far girare i motori v15
   (backend originale) accanto a v16, o portarli (decisione B già prevista per i puri).

## 3. GAP NON PIANIFICATI (28 voci ⚠️) — proposta di allocazione

| Proposta | Voci |
|---|---|
| **W3-proroga** (operazioni evolute, coerenza con «config evolute») | porte switch nella scheda; provisioning; template SNMP vendor (v15.16); CRUD link/inferenza UI; import KMZ/Excel UI; pannello conflitti link |
| **W4-proroga** (intelligenza e amministrazione) | health score; anomalie 1G/2G; watchdog+threshold suggestions+pattern learning; post-mortem; coda adozione+duplicati+lifecycle; capacity forecast; instradamento allarmi+digest/escalation; 2FA; sessioni attive; API token; feature flags; backup in-app |
| **W7 — Integrazioni** (nuova onda, oggi inesistente) | Telegram; osTicket; SMTP/IMAP; Grafana; check_mk; controller read-only; Splashtop; Web Push; webhook HMAC; LDAP; Prometheus exporter; flotta multi-impianto; portale clienti |
| **Post-W6 / su richiesta** | agenti ReAct 2-man rule; Rizzo Flow; PWA; profili shell; server check; flusso NetFlow (⚙️ senza rete reale) |

> Nessuna di queste voci è stata costruita in anticipo: questa matrice È il registro
> dell'onestà della roadmap. La decisione su come allocare le 28 voci ⚠️ spetta all'operatore.

## 4. Prossimi passi consigliati (in ordine)

1. ~~Chiudere W2 residua~~ **FATTO in 16.8.0** (report SLA mensile+storico, scheda
   intervento, report schedulati; vitest dichiarato non portato).
2. **Chiudere W3** (pianificata): config-requests, bulk-config, firmware-center, playbooks,
   terminal, automation, event-policies, custom-oids.
3. **Decisione operatore sulle 28 voci ⚠️** di §3: allocare in W3/W4 o creare W7
   (integrazioni). Senza questa decisione, «tutto quello che faceva il vecchio software»
   non sarà ripristinato anche a W4 completata.
4. **Decisione produzione motori**: far girare il backend v15 accanto a v16 (consigliato:
   è lo strangler pattern originale) oppure portare i motori batch uno a uno.
