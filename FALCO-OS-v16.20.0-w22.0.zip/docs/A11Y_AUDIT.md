# Audit accessibilità WCAG 2.2 AA — 2026-10-27

Strumento ripetibile: `bun scripts/a11y-audit.mjs` (Playwright chromium headless + axe-core, tag wcag2a, wcag2aa, wcag21a, wcag21aa, wcag22aa).
Contesti auditati: **19/19** · **violazioni totali: 0** · errori pagina durante l'audit: 0.

Copertura: 9 viste desktop 1280×800 con attraversamento delle schede non di default (Registro flussi; Finestre, Gruppi) + dettaglio dispositivo (deep link ?device=) + 3 viste mobile 390×844 + 3 viste in tema CHIARO 1280×800, login reale, DOM a riposo dopo caricamento dati. Stati di focus/hover e finestre di dialogo NON coperti (verifica manuale, TEST §1).

## Esito: 🟢 NESSUNA violazione WCAG 2.2 AA rilevata da axe-core in copertura

JSON macchina dell'ultimo run: `scripts/.a11y-last.json` (rigenerato a ogni esecuzione).
