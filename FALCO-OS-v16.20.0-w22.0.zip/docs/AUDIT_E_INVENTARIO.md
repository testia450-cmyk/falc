# AUDIT E INVENTARIO — FALCO-OS v16 (W0)

Data: 26/10/2026 · Autore: agente di sviluppo · Metodo: lettura diretta del repository `FALCO-OS-v15.16.0` estratto in `/home/z/falco-ref` e del **database reale di produzione** caricato dall'utente (unità Google Drive → `/home/z/falco-real/work/custom.db`, 281 MB + WAL 23 MB integrati con checkpoint `wal_checkpoint(FULL)` = 1001/1001 frame).

> Regola di lettura: ogni affermazione ha la prova (`file:riga` oppure query SQL con risultato). Ciò che non ha prova è marcato `[DA VERIFICARE]`.

---

## 1. Base di partenza verificata

### 1.1 Repository (v15.16.0)

| Elemento | Prova | Esito |
|---|---|---|
| Schema Prisma | `prisma/schema.prisma` (3225 righe, 123 modelli; variante SQLite `prisma/schema.sqlite.prisma`) | MANTENERE: importato integralmente nel progetto v16 |
| Stati dispositivo | `src/lib/monitoring-engine.ts:35` `type DeviceStatus = 'ONLINE' \| 'OFFLINE' \| 'DEGRADED' \| 'MAINTENANCE' \| 'UNKNOWN'` | RIUSARE identico |
| Macchina a stati falcoState | `src/lib/device-states.ts:34` («online, degradato, disconnesso, interruzione», timer impianto 5 min default) | RIUSARE per «stato con durata» |
| Albero unico | `src/lib/topology-reconstruction.ts:1038` `computeNetworkTiers` (BFS dal gateway; root = `Plant.topologyRootDeviceId`, altrimenti inferenza) | RIUSARE: **nessuna seconda logica nel frontend** |
| Raggiungibilità/RCA | `src/lib/topology-reachability.ts:65` `computeReachability` (BFS multi-sorgente, `isLinkStatusActive` UP/ACTIVE/CONFIRMED/ON); `rca-engine.ts:35,50` (downstream vittime = solo OFFLINE; root cause = upstream più vicino) | RIUSARE |
| Soppressione allarmi | `src/lib/alert-engine.ts` (~righe 297-345: soppressione causa-radice + finestre manutenzione fail-open + finestre per-regola v11.17) | RIUSARE la semantica; le finestre nel DB reale sono 0 (nessuna attiva oggi) |
| Semantica segnale radio | `src/lib/radio-metrics.ts` (SNR = segnale−noise con null-onesti; `deduceLinkMode`: 1 stazione=PTP, >1=PTMP; per STA il conteggio proprio non conta — il linkMode si copia dall'AP) | RIUSARE |
| Punteggio salute radio | `src/lib/link-detail.ts:129` `computeSignalScore`: −50→100 excellent, −65→80 good, −75→60 fair, −85→30 poor, <−90→critical | RIUSARE (scala identica, nessuna soglia reinventata) |
| Realtime | `src/lib/realtime/socket-server.ts` / `socket-client.ts` (socket.io) | RIUSARE il canale: nuovo mini-service socket.io in v16 |
| Auth | `src/lib/auth.ts` (NextAuth v4 Credentials + JWT + bcryptjs + lockout per-account 5 tentativi/15 min) | RIUSARE (port minimale senza LDAP: nel DB reale `LdapConfig` = 0 righe) |
| Mappa | tile OSM + ArcGIS World Imagery (geographic-view) | RIUSARE in sviluppo; fornitore per produzione = decisione aperta §16.3 |

### 1.2 Database reale (impianto «egidio») — numeri verificati con query

| Tabella | Righe | Osservazioni operative |
|---|---|---|
| Plant | 1 | «egidio», pingIntervalSec 30, outageTimerMinutes 5, topologyRootDeviceId **null** (inferenza automatica dal GATEWAY) |
| Location | 41 | 40 con coordinate reali (import KMZ: P1-P20 e sedi nominate), 1 senza |
| Device | 200 | 29 AP · 34 STA · 87 CAMERA · 15 LPR · 16 SWITCH · 1 GATEWAY (Router SETI, Mikrotik RB750Gr3) · 2 SERVER · 16 UNKNOWN |
| Device.status reale | — | 168 ONLINE · 3 DEGRADED · 30 UNKNOWN (lastSeenAt NULL: mai visti dal riavvio del sistema) · **0 OFFLINE** |
| TopologyLink | 892 | ETHERNET 536 (439 HIGH / 22 MEDIUM / 75 LOW confidenza), BRIDGE_MIB 179, LAN 127, WIRELESS 14, MNDP 11, UTP_COPPER 13, MIKROTIK 6, RADIO 6 |
| AlertEvent | 9235 | OPEN 75 (68 HIGH · 2 CRITICAL · 4 WARNING · 1 INFO), SUPPRESSED 7, CLOSED 9153. Dedup reale: occorrenze fino a 279 su un singolo evento |
| AlertRule | 10 | 10 regole SYS:* (SYS:ANOMALY, SYS:CAMERA_STREAM_DOWN, SYS:NEW_HOST, SYS:PORT_MOVED, SYS:PING_JITTER, SYS:PING_LATENCY, SYS:PACKET_LOSS, SYS:FREQ_CHANGE, SYS:LINK_CHANGE, SYS:PORT_UTILIZATION) |
| DeviceEvent | 8191 | STATUS_CHANGE POLLER 5660 / WATCHDOG 2525, FREQ_CHANGE TELEMETRY 6 |
| MetricValue | 687.264 | cameraStreamAlive 136k, cameraRtt 136k, pingLatency 126k, pingJitter/packetLoss 51k, port_traffic_in/out 32k, port_utilization:* 20k+, cpuLoad/memoryUsage/temperature/ethSpeedMbps 3,5k, mt* (Mikrotik) 442/dispositivo. Finestra ~2,7 giorni |
| PollingSchedule | 171 | 169 OK · 1 FAILED · 1 SNMP_SILENT |
| Ticket | 71 | tutti OPEN |
| AuditLog | 48.021 | picco `CREDENTIALS_DECRYPT` 44.975 (rumore da decifratura a ogni ciclo — difetto di rumore, segnalato) |
| User | 1 | admin@falco-os.local, SUPER_ADMIN, bcrypt ($2b$12) |
| TopologyCoverageSnapshot | 52 | ultima: 307 certi / 240 incerti / 0 ignoti su 170 dispositivi = **56,1%** (goal 70% NON raggiunto) |
| VPN / ISP / VLAN | 0 | **nessun modello, nessun dato**: confermata la regola §1.4 (non compaiono nella UI) |

### 1.3 Confronto mockup → backend (tabella §1.4 del prompt, ora verificata)

| Elemento mockup | Verdetto sull'impianto reale |
|---|---|
| 5 KPI (dispositivi, telecamere, link wireless, allarmi) | **Copribile con dati reali** (Device, TopologyLink WIRELESS/RADIO + segnali, AlertEvent) |
| Tunnel VPN (KPI/riquadro/menu) | **Assente** → escluso (onda W5 solo con decisione) |
| ISP 1 FTTH / ISP 2 LTE | **Assente** → escluso (W5) |
| VLAN come entità | **Assente** → escluso (W5) |
| «Stato registrazione / flusso» telecamere | **Presente come dato**: metrica `cameraStreamAlive` (136k campioni reali) → lo stato del flusso si deriva da essa + `cameraRtt` |
| Traffico aggregato impianto 24h | **Definibile**: esistono `port_traffic_in/out` per link e `trafficInMbps/OutMbps` sui TopologyLink. Definizione scelta (documentata): somma delle interfacce di **distribuzione principale** raggiunte dal BFS di tier-1 dal gateway — il gateway stesso (Router SETI) **non** espone port_traffic (verificato: sue metriche = cpuLoad, memoryUsage, ping*, mt*, sysUpTime). Aggregato calcolato lato server, etichetta con definizione nel riquadro |
| «Link più deboli» | **Reale**: STA con segnale proprio (semantica uplink §1.4). Valori reali disponibili (−40…−93 dBm) |
| Mappa satellitare | **Reale**: 40 sedi con coordinate |
| Versione e stato sistema | **Reale**: versione del build v16 da `package.json` via API + pipeline health dal servizio realtime |

### 1.4 Difetti backend noti (§1.5 del prompt) — stato nel repo v15.16.0

| Difetto | Prova nel repo | Decisione W1 |
|---|---|---|
| sFlow expanded (1001/36 byte vs specifica 3/40) | `[DA VERIFICARE]`: il modulo flow non è eseguibile senza sorgente sFlow reale | Fuori perimetro W1 (nessun flusso sFlow nel DB reale) — documentato |
| OID Ubiquiti tabella stazioni `…4.7.1.1.N` vs MIB `…4.7.1.N` | `[DA VERIFICARE]`: richiede snmpwalk su antenna reale, impossibile in sandbox | Non toccato; nessun dato del DB dipende da questa tabella per W1 |
| cnMaestro archi con evidenza ARP | `[DA VERIFICARE]` (provisioning/cnmaestro-topology.ts) | Non in perimetro: ExternalController = 0 righe nel DB reale |
| Classificazione SERVER da OID Microsoft | verificabile solo su rete reale | Non in perimetro W1 |
| Exit status SSH RouterOS | verificabile solo su apparato reale | Non in perimetro W1 |

> Nota onestà: la dashboard NON nasconde questi limiti: il pannello «qualità del dato» mostra copertura topologica reale (56,1% vs goal 70%), dispositivi UNKNOWN (30) e la finestra temporale dei dati.

---

## 2. INVENTARIO FUNZIONALE (decisioni per area, perimetro W1)

| ID | Area | Utenti/permessi | Fonti backend | Stato reale | Decisione | Destinazione W1 |
|---|---|---|---|---|---|---|
| F01 | Login/sessione/ruoli | tutti | User, next-auth (repo) | funzionante | MANTENERE | Login overlay su `/` + route `/api/auth/*` |
| F02 | Dashboard NOC (KPI, mappa, criticità, link deboli, eventi) | TECNICO+ | Device, AlertEvent, TopologyLink, MetricValue | dati reali presenti | SOSTITUIRE (nuova v2 aggregata) | `GET /api/v2/noc/summary` |
| F03 | Topologia logica | TECNICO+ | TopologyLink + computeNetworkTiers | 892 link reali, albero da gateway | MIGLIORARE (grafo @xyflow+elk, zoom semantico) | `GET /api/v2/topology/graph` |
| F04 | Mappa geografica | TECNICO+ | Location (40 geolocalizzate) | presente | MIGLIORARE (scrim, badge stato, contrasto) | dentro Rete |
| F05 | Elenco dispositivi + filtri | TECNICO+ | Device | 200 reali | SOSTITUIRE (tabella virtualizzata v2) | `GET /api/v2/devices` |
| F06 | Quick-look apparato | TECNICO+ | Device + RCA + MetricValue | pannello attuale con 25 tipi/10 tab (difetto §1.3) | RISCRIVERE (pattern QuickLook §6.3) | `GET /api/v2/devices/:id/overview` |
| F07 | Scheda apparato | TECNICO+ | idem | doppio modello concorrente (pannello vs pagina) | RISCRIVERE (5 sezioni §6.4) | idem + history |
| F08 | Allarmi attivi/storico + ACK | TECNICO+ | AlertEvent, AlertRule | 9235 reali, soppressione RCA funzionante | MIGLIORARE (v2 + causa radice visibile) | `GET /api/v2/alarms`, `POST …/ack` |
| F09 | Telecamere (stato flusso) | TECNICO+ | MetricValue cameraStreamAlive/cameraRtt | 136k campioni reali | MIGLIORARE | `GET /api/v2/cameras` |
| F10 | Eventi dispositivo | TECNICO+ | DeviceEvent | 8191 reali | MIGLIORARE (cursori) | `GET /api/v2/events` |
| F11 | Ricerca globale | tutti | cmdk + Device/Location/AlertEvent | presente | MIGLIORARE (raggruppata) | `GET /api/v2/search` |
| F12 | Realtime | tutti | socket-server (repo) | canale esistente | RIUSARE (nuovo mini-service port 3001) | socket.io via gateway |
| F13 | Manutenzioni/ticket/interventi | RESPONSABILE+ | Ticket (71 OPEN), MaintenanceWindow (0) | ticket reali, manutenzioni vuote | W2 (fuori W1, menu nascosto) | — |
| F14 | Report/esportazioni | RESPONSABILE+ | ReportArtifact (0 righe) | vuoto | W2/W4 | — |
| F15 | Operazioni (config, bulk, firmware, playbook, terminale…) | TECNICO+ | 57 gruppi API senza schermata (§1.3) | backend presente, UI assente | W3 (NON DECIDIBILE in W1) | — |
| F16 | Amministrazione (utenti, integrazioni, audit) | SUPER_ADMIN | User, AuditLog, IntegrationConfig | funzionante | W4 | — |
| F17 | VPN/ISP/VLAN | — | **nessun modello** | assente | NON COSTRUIRE (W5 con decisione esplicita §12) | — |
| F18 | Wallboard/TV | tutti | derivato da F02 | assente | W2 | — |

---

## 3. Rischi e contro-misure (W1)

1. **Dati statici in sandbox** (nessun poller): contro-misura — servizio realtime con «modalità riproduzione» **dichiarata** in UI (banner permanente con data/ora dell'import), eventi simulati marcati `TELEMETRY`, `asOf` su ogni dato. Senza riproduzione attiva si applica la regola di obsolescenza → UNKNOWN.
2. **SQLite multi-process** (Next.js + mini-service): DB già in WAL; concorrenza in scrittura accettabile per il carico demo (1 write/30s); checkpoint verificato busy=0.
3. **281 MB di metriche**: aggregati lato server (nessun `findMany` non paginato); serie temporali limitate a finestra 24h.
4. **Grafo 200 nodi / 892 link**: l'endpoint restituisce l'**albero** (computeNetworkTiers), non tutti i link grezzi; `onlyRenderVisibleElements` + layout ELK lato client.
5. **Segreti**: campi `password`, `snmpCommunityEnc`, `snmpAuthKey`, `snmpPrivKey`, `passwordHash` **mai selezionati** dalle API v2 (allowlist di colonne; risposta ispezionabile).

## 4. Cosa NON si fa in W1 (regole §2)

- Nessun pulsante azione per operazioni intrusive (riavvio, config, VLAN, firmware): nessun endpoint v2 di scrittura per quelle operazioni in W1. Azioni mostrate: solo **lettura**. Unico POST v2: ACK allarme (backend reale: `AlertEvent.acknowledgedAt/By` + voce di audit).
- Nessuna migrazione distruttiva: schema importato = schema originale (nessun `db push` sui dati reali; solo `prisma generate`; differenza schema↔DB verificata nulla con `prisma migrate diff`).
