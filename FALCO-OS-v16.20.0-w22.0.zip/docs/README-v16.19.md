# FALCO-OS v16.19.0-w20.0-w21.0 — IL SETUP DELL'IMPIANTO DALL'INIZIO ALLA FINE

> «Quello che voglio è creare impianto, importare i dati excel e kmz,
> avviare scansione della rete dell'impianto, mettere credenziali (con
> verifica se tutte le credenziali sono giuste su ogni apparato) se sono
> TLC evitiamo magari solo ping va bene, nel frattempo parte tutta la
> telemetria, vengono raccolti già tutti i dati, poi la fase di adozione
> dove li scriviamo nel db e confrontiamo già ipotetica rete la
> costruzione, poi fase di allarmi (segnale scarso, porte che cambiano
> stato, dispositivi offline, rete che cambia alberatura, nuovi
> dispositivi rilevati e non adottati, nuovi apparati visti) poi la fase
> di chiusura ovvero riepilogo e verificare globale.» — operatore, 01/11/2026

## La risposta: il wizard «Setup impianto» (7 fasi)

Nuova voce nella barra laterale. Ogni fase dichiara cosa ha **fatto
davvero** — nessun successo inventato, «n.d.» sui valori mancanti.

| Fase | Cosa fa | Cosa scrive |
|---|---|---|
| **1 — Impianto & Import** | Crea l'impianto; importa l'Excel «formato SETI» (rete ipotetica con credenziali) e il KMZ (sedi/coordinate), anteprima a zero scritture | Plant, Location, Device dichiarati, link radio/LAN |
| **2 — Scansione rete** | Sweep TCP sul CIDR + identificazione (SNMP multi-community, banner HTTP, OUI) | **DiscoveryJob persistito** + confronto dichiarato-vs-visto: confermati / mancanti / nuovi |
| **3 — Credenziali** | Verifica **per apparato** con sonde reali: SNMP (community cifrata → CSV impianto → `public`), **login SSH** (solo autenticazione, nessun comando), presenza ping per i TLC | `credentialState` + porta verificata + community cifrata + MAC letto |
| **4 — Adozione & DB** | I candidati **visti e non in inventario** diventano Device con l'evidenza della scansione; skip onesto per IP già presenti (pattern LibreNMS) | Device con MAC/brand/modello/community cifrata/baseline 24 h — la **sede resta umana** |
| **5 — Telemetria** | Sonda radio sulle antenne (SSID/segnale/CCQ/CPU/RAM), sonda L2 batch sugli switch (FDB/ARP/STP/VLAN → topologia), spazzata ping sulle TLC | Device + MetricValue + FdbObservation/ArpEntry/StpObservation/VlanInventory + TopologyLink |
| **6 — Allarmi** | **Le 6 regole richieste** assicurate sul plant + valutazione ORA sui dati reali | AlertRule ×6 + AlertEvent (con dedup) |
| **7 — Riepilogo** | La verifica globale **contata dal DB e dai motori** | «Il motore è avviato?»: verdetto riga per riga |

## Il riepilogo che l'operatore ha chiesto

La fase 7 risponde esattamente alla domanda «esempio 100 apparati visti,
30 antenne con SNMP ok e dati letti, 30 switch, 40 TLC monitorate,
motore avviato, puller avviato, DB che costruisce la topologia, MAC
letti e confrontati, vendor letti o sconosciuti da specificare»:

- KPI: apparati in inventario (per tipo) · visti in scansione ·
  credenziali OK/sbagliate/non verificabili · SNMP attivi · TLC in
  ping-only · sonde radio 2 h (campioni scritti) · switch sondati L2 ·
  online/offline;
- topologia: link con fonte, FDB/ARP/STP/VLAN, **MAC noti vs visti e
  non in inventario** (i candidati da adottare), vendor sconosciuti da
  specificare (con hostname);
- «Il motore è avviato?»: inventario scritto, job completato,
  credenziali verificate, SNMP attivi, telemetria raccolta, sonde L2,
  rete topologica costruita, allarmi armati, **puller** (cicli, campioni
  scritti, eventi aperti/chiusi, notifiche), discovery, realtime,
  API e DB.

## Il motore di monitoraggio continuo (il «puller»)

Dalla fase Telemetria si avvia il motore che **raccoglie da solo** a
ogni ciclo: presenza ping sulle TLC (con isteresi 2 giù / 2 su), liveness
SNMP sugli apparati full, telemetria radio ogni N cicli, valutazione
allarmi con dedup, notifiche Telegram (esito scritto, mai silenziose).

**Onestà dichiarata** (visibile nel riepilogo): il motore vive nel
processo del server — **al riavvio si ferma** e non riparte da solo in
questa build; `PORT_STATE_CHANGE` e `NEW_DEVICE_SEEN` restano on-demand
(servono sonde L2 / scansioni).

## Telemetria radio (W20)

`POST /api/v2/discovery/radio` legge per antenna: SSID, segnale dBm,
CCQ, SNR, frequenza, tx/rx rate, linkMode (AP/PTP/PTMP), CPU/RAM, porte
con speed/duplex, MAC — OID MikroTik `14988.1.1.1` + Ubiquiti airMAX
`41112` + IF-MIB/BRIDGE/HOST-RESOURCES/UCD. Ogni campo con provenance
OID nella scheda apparato; valori persistiti (Device + MetricValue).

## Come provarlo dal Preview

Il DB demo contiene **«Setup Demo Verona» già percorso per intero**
(import → scansione → credenziali → adozione di un ONT nuovo →
telemetria → 6 regole → motore con storia) e `demo-assets/` ha i file
originali:

| File | Contenuto |
|---|---|
| `demo-assets/w21-impianto.xlsx` | Excel formato SETI: 2 sedi, 8 apparati dichiarati (con utente/password), rete `127.0.0.0/29` |
| `demo-assets/w21-sedi.kmz` | 2 placemark (Verona) abbinati alle sedi |

Con i **simulatori** attivi (`mini-services/discovery-service/sim/`) la
rete risponde davvero: 3 apparati gestiti su 127.0.0.2/.3/.4 (SNMP
:16111, SSH :2222 — admin/simpass), un'ONT TLC su :8081 e **una ONT
NUOVA non dichiarata** su 127.0.0.6:8081 che la scansione vede, la fase
adozione scrive e il monitoraggio ping tiene d'occhio.

1. Login (`admin@falco-os.local` / `FalcoDemo2026!`) → selettore impianto
   → «Setup Demo Verona»;
2. «Setup impianto» nella barra laterale → fasi con lo stepper;
3. Fase 2: CIDR `127.0.0.0/29`, porte extra `2222,8081`, porta SNMP
   `16111`, porta HTTP `8081` → «Avvia scansione»;
4. Fase 3: porta SSH `2222` → «Verifica tutte le credenziali»;
5. Fase 7: il riepilogo contato dal DB.

Su Windows i simulatori si avviano con Bun dalla cartella del servizio
(vedi `docs/INSTALLAZIONE_WINDOWS.md` § simulatori demo): le stesse
istruzioni del wizard funzionano identiche.

## Verifica di questo rilascio

- **API e2e a mano** (login reale): tutte le 7 fasi + motore con
  conteggi coerenti (scansione 6 IP / 5 vivi / confronto onesto;
  credenziali 3 SNMP+SSH OK, TLC MISSING oneste; adozione 1 creato + 4
  skip; radio -58 dBm CCQ 92%; L2 10 FDB/10 ARP/10 STP/3 VLAN; 6 regole;
  motore 3 cicli / 26 campioni / 6 eventi / 0 errori);
- **browser e2e** desktop 1440 + mobile 390: fasi eseguite DAL VIVO
  dalla UI, riepilogo con puller attivo (5 cicli / 42 campioni), zero
  errori console, `scrollW == clientW == 390`;
- **6 screenshot** in `release/evidence/w21/` verificati col VLM;
- `tsc --noEmit` **0 errori** (16 errori TypeScript ereditati da W21
  corretti in questo rilascio) · ESLint **0 errori / 1 warning noto**;
- **Riverifica post-rilascio (01/11, 14:26)** con pacchetto verificato
  dal vivo: fase 7 contato dal DB (9 apparati · 4 credenziali OK · 174
  campioni radio · 6 link · 6/6 regole), motore riavviato DAL VIVO (3
  cicli / 12 campioni / 0 errori, sonde 3 ping + 24 SNMP + 2 radio),
  valutazione ORA 7 eventi deduplicati, mobile 390 senza overflow, zero
  errori console — +3 screenshot `verify-zip-*` in `evidence/w21/`;
  ZIP aggiornato (fix locate-422 in `api.ts` e variabili env documentate
  in `.env.example` inclusi; DB demo snapshot consistente `VACUUM INTO`).
- **COLLAUDO DAL VUOTO interamente dalla UI (01/11, 14:42–14:55)** —
  impianto «Collaudo Setup Onesto» creato da zero col wizard: fase 1
  (Excel 8 apparati + KMZ 2 sedi geolocalizzate, anteprima a zero
  scritture) · fase 2 (6 IP scansionati, 5 vivi, 4 confermati + 1 nuovo,
  4 dichiarati-non-visti onesti) · fase 3 (3 SNMP OK + SSH OK verificati
  per apparato; **TLC dichiarato «Solo ping» dal bottone del wizard →
  credenziali OK 4, TLC vivo 1/1 a 1 ms**) · fase 4 (1 adottato con
  baseline 24 h, orfano con sede = decisione umana) · fase 5 (radio
  −58 dBm CCQ 92% 6 campioni; L2 6 link con SW-CENTRALE↔SW-DISTRIBUZIONE
  promosso FDB_MUTUAL, 10 MAC/10 ARP/10 STP; ping 2/2; motore avviato:
  3 cicli/18 campioni/0 errori) · fase 6 (6 regole armate, valutazione
  ORA 6 eventi onesti) · fase 7 (riepilogo contato dal DB: puller attivo
  4 cicli/28 campioni/1 evento chiuso con isteresi). Conteggi DB prima/dopo
  verificati (+9 device, +148 campioni, +7 eventi, +4 link, +1 job) —
  **+7 screenshot `collaudo-*` in `evidence/w21/`**, zero errori console,
  mobile 390 senza overflow, lint 0 errori.

## Limiti dichiarati

- Il puller **non ha auto-resume**: al riavvio del server si riavvia
  dalla fase Telemetria (o via API `POST /api/v2/setup/engine`).
- `PORT_STATE_CHANGE` e `NEW_DEVICE_SEEN` sono regole armabili ma la
  loro valutazione continua richiede sonde L2/scansioni periodiche
  (on-demand in questa build).
- I TLC **già dichiarati nell'Excel** nascono in modalità full con
  credenziali MISSING: la dichiarazione ping-only è una scelta umana
  (dalla fase Credenziali del wizard o dalla scheda apparato W19).
- L'hostname degli adottati senza sysName è auto-generato dal brand+IP
  (es. `Alcatel-LucentEnterprise-0-6`): rinominabile dall'inventario.

## DB reale

NESSUNA modifica allo schema in W20/W21 (le tabelle usate —
DiscoveryJob, AlertRule, AlertEvent, MetricValue, FdbObservation,
ArpEntry, StpObservation, VlanInventory, NotificationLog, PollingSchedule
— esistono già). Quando arriva il DB reale (~292 MB):
`bun scripts/prepare-real-db.ts --yes` (vedi `db/LEGGO.md`).
