# FALCO-OS v16 — GUIDA COMPLETA DI INSTALLAZIONE SU WINDOWS

> Versione guida: **16.18.1-w19.1** (31/10/2026) — valida per le release
> v16.18.x e successive. Ambienti verificati: Windows 10 e Windows 11
> 64-bit. Aggiornata dopo l'intervento di compatibilità Windows del
> 31/10/2026 (vedi «Cosa è stato sistemato» in fondo).

---

## 1. Che cosa si installa (i 3 processi)

FALCO-OS NON è un unico eseguibile: sono **tre processi che parlano tra
loro in locale**. Conoscerli in anticipo rende tutto il resto ovvio:

| Processo | Porta | Che cosa fa | Come si avvia |
|---|---|---|---|
| **NOC** (Next.js 16) | 3000 | l'applicazione: UI, API, autenticazione, DB | `bun run dev:win` (sviluppo) o `bun run start` (produzione) |
| **realtime** (socket.io) | 3001 | canale live: tick, metriche jitter, allarmi in tempo reale | `bun run dev` in `mini-services\realtime-service` |
| **discovery** (sonde di rete) | 3002 | scansione TCP, SNMP v1/v2c/v3, ONVIF, **attivazione SNMP assistita W19** (SSH/SwOS) | `bun run dev` in `mini-services\discovery-service` |

Il **database è un file SQLite** (`db\custom.db`): nessun server database
da installare. Il browser apre **solo la porta 3000**; il NOC parla da sé
con gli altri due processi.

**Differenza con la sandbox (dichiarata, onesta):** nell'ambiente di
sviluppo sandbox esiste un gateway Caddy che instrada le porte; su
Windows NON serve e NON si installa: il canale live si collega direttamente
al realtime con la variabile `NEXT_PUBLIC_REALTIME_URL` (passo 4).

---

## 2. Requisiti

| Requisito | Dettaglio |
|---|---|
| Sistema | Windows 10 o 11, 64-bit |
| RAM | 4 GB liberi consigliati (il build di produzione vuole ~2 GB) |
| Disco | ~1,5 GB (release + dipendenze + DB) |
| Runtime | **Bun ≥ 1.1** (unico runtime da installare: porta Node compatibile, Prisma, TypeScript) |
| Permessi | utente normale. **NON servono diritti amministratore**: il «ping» di FALCO-OS è TCP-connect, non ICMP raw |
| Rete | nessuna porta privilegiata (3000/3001/3002 e simulatori 2222/8080/1161/1162) |
| Browser | Edge/Chrome/Firefox aggiornati |

**Consiglio sul percorso**: installare in un percorso **senza spazi e senza
accenti** (es. `C:\FALCO-OS`). Evitare `C:\Documenti\Sant'Egidio…`:
alcuni tool di build storicono male sui percorsi con caratteri speciali.

---

## 3. Passo 1 — Installare Bun

Aprire **PowerShell** e scegliere UNA delle opzioni:

```powershell
# opzione A — installer ufficiale (consigliata)
powershell -c "irm bun.sh/install.ps1 | iex"

# opzione B — se si usa scoop
scoop install bun

# opzione C — se si usa chocolatey
choco install bun
```

Chiudere e riaprire il terminale, poi verificare:

```powershell
bun --version
# atteso: 1.1.x o superiore (es. 1.3.14)
```

Se «bun non riconosciuto»: riaprire il terminale (il PATH si aggiorna solo
alle nuove sessioni) o riavviare il terminale dopo l'installazione.

---

## 4. Passo 2 — Scompattare la release

Scompattare lo zip della release (es. `FALCO-OS-v16.18.0-w19.0.zip`) in
`C:\FALCO-OS`. Alla fine la cartella deve contenere:

```
C:\FALCO-OS\
  package.json
  next.config.ts
  prisma\schema.prisma
  db\custom.db            ← DB demo pronto (5 apparati demo W19)
  mini-services\
    realtime-service\
    discovery-service\
  scripts\
  src\
  public\
  .env.example
```

> Il DB **demo** è già incluso e funzionante (login
> `admin@falco-os.local` / `FalcoDemo2026!`). Il DB **reale** si carica a
> parte (passo 7b) e NON è incluso nella release.

---

## 5. Passo 3 — Installare le dipendenze

Da PowerShell, nella root del progetto:

```powershell
cd C:\FALCO-OS
bun install

cd mini-services\discovery-service
bun install
cd ..\..
```

Note oneste:

- `realtime-service` **non ha** dipendenze proprie (usa node_modules del
  progetto padre, come da progetto): nessun `bun install` da fare lì;
- durante l'installazione di `ssh2` può comparire un avviso su
  **`cpu-features`** (binding nativo opzionale che su Windows talvolta non
  compila): è **benigno e ignorabile** — ssh2 funziona in JavaScript puro;
- `net-snmp` (le sonde SNMP) è JavaScript puro: nessun problema su Windows.

---

## 6. Passo 4 — Il file .env (le 4 variabili)

Copiare l'esempio e rinominarlo:

```powershell
Copy-Item .env.example .env
```

Aprire `.env` con un editor qualsiasi e compilare (attenzione: **usare
sempre `/` nei path, mai `\`**):

```ini
DATABASE_URL=file:../db/custom.db
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=<generato al passo sotto>
DEVICE_CREDENTIALS_KEY=<generato al passo sotto>
NEXT_PUBLIC_REALTIME_URL=http://localhost:3001
```

Generare i due segreti (uno per ciascuno) e incollarli:

```powershell
bun -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Significato delle variabili:

| Variabile | Valore | Note |
|---|---|---|
| `DATABASE_URL` | `file:../db/custom.db` | relativo alla cartella `prisma\` → punta a `db\custom.db`. In alternativa assoluto: `file:C:/FALCO-OS/db/custom.db` |
| `NEXTAUTH_URL` | `http://localhost:3000` | in produzione: l'indirizzo con cui gli operatori raggiungono il NOC |
| `NEXTAUTH_SECRET` | 64 caratteri hex | segreto delle sessioni. **Diverso per ogni installazione** |
| `DEVICE_CREDENTIALS_KEY` | 64 caratteri hex | chiave AES-256-GCM delle credenziali SSH/SwOS salvate nei dispositivi (W19). Se la si cambia, le credenziali salvate vanno reinserite |
| `NEXT_PUBLIC_REALTIME_URL` | `http://localhost:3001` | **su Windows va tenuta DECOMMENTATA**: collega il canale live senza gateway. In produzione: `http://<nome-pc>:3001` o l'IP del server |

> `NEXT_PUBLIC_*` viene «cucita» dentro il codice **al momento del
> build/dev**: se la si cambia, riavviare il dev server (o rifare il build).

---

## 7. Passo 5 — Preparare il database

### 7a. DB demo (già incluso)

```powershell
cd C:\FALCO-OS
bun run db:push
```

Crea/aggiorna lo schema Prisma sul file. Alla fine: «Your database is now
in sync».

### 7b. DB reale dell'impianto (quando arriva)

1. **Fermare i tre processi** (finestre chiuse o `scripts\windows\ferma-falco.cmd`);
2. salvare una copia del proprio DB reale e copiarlo in `C:\FALCO-OS\db\custom.db`
   (sovrascrivere quello demo — la release demo si può sempre ri-scompattare);
3. eseguire lo script di preparazione, **idempotente e sicuro** (backup
   automatico, integrity check, push solo additivo, conteggi di sanità):

```powershell
bun scripts/prepare-real-db.ts --yes
```

Il comando stampa un report di ogni passo e **fallisce fermamente al primo
problema** senza toccare oltre il DB. Il backup resta in
`db\custom.db.bak-<data-ora>`. Dettagli: `db\LEGGO.md`.

---

## 8. Passo 6 — Avviare (sviluppo)

### Modo rapido — doppio clic

Doppio clic su **`scripts\windows\avvia-falco.cmd`**: apre le tre finestre
(NOC, realtime, discovery) già impostate. Per fermare: chiudere le finestre
oppure `scripts\windows\ferma-falco.cmd`.

### Modo manuale — tre terminali

```powershell
# terminale 1 — NOC (UI + API)
cd C:\FALCO-OS
bun run dev:win

# terminale 2 — canale live
cd C:\FALCO-OS\mini-services\realtime-service
bun run dev

# terminale 3 — sonde di rete + attivazione SNMP
cd C:\FALCO-OS\mini-services\discovery-service
bun run dev
```

> `dev:win` è identico a `dev` senza il tee del log della sandbox Linux.
> Il discovery si avvia con `bun` diretto (senza --hot): dopo modifiche ai
> sorgenti va riavviato — scelta documentata del progetto (il hot-reload di
> Bun spezzava i socket UDP delle sonde).

**Prima apertura**: la prima pagina impiega 30-60 s (compilazione a caldo
di Turbopack); le successive sono immediate.

Al primo avvio **Windows Firewall** può chiedere il permesso di ascolto per
bun: rispondere **«Consenti accesso»** (almeno su «Reti private»). Serve
solo per il canale live se il browser gira su un altro PC; tutto in locale
funziona anche rifiutando.

---

## 9. Verifica dell'installazione (checklist)

| # | Controllo | Come | Risultato atteso |
|---|---|---|---|
| 1 | NOC su | navigare `http://localhost:3000` | pagina di login FALCO-OS |
| 2 | login | `admin@falco-os.local` / `FalcoDemo2026!` (DB demo) | dashboard con KPI reali del DB |
| 3 | realtime su | PowerShell: `curl.exe http://localhost:3001/health` | `{"ok":true,"service":"falco-realtime",...,"replay":true}` |
| 4 | discovery su | `curl.exe http://localhost:3002/health` | `{"ok":true,"service":"falco-discovery",...}` con l'elenco capabilities |
| 5 | canale live | nella UI: l'indicatore realtime della dashboard (badge «riproduzione») | aggiorna i numeri ogni 30 s senza ricaricare |
| 6 | attivazione SNMP (W19) | Dispositivi → riga demo → scheda → tab Configurazione → «Attiva SNMP assistita…» | dialog con preview comandi in chiaro |
| 7 | discovery dal NOC | vista Rete → esegui una scansione | risposta strutturata (mai schermata vuota) |

Con il **DB demo** gli apparati che puntano ai simulatori sono
`SW-ROUTEROS-DEMO`, `SW-SWOS-DEMO` (RB260GSP), `ANT-AIRMAX-DEMO`,
`NVR-HIKVISION-DEMO` (manuale), `DEMO-CAM-PING` (ping). Per provarli per
intero servono anche i simulatori (opzionali, solo demo):

```powershell
cd C:\FALCO-OS\mini-services\discovery-service
bun sim\ssh-sim.ts        # SSH :2222 (RouterOS/airOS)
bun sim\swos-sim.ts       # SwOS :8080 (digest)
bun sim\snmp-sim.ts       # SNMP :1161 (scenario centrale)
bun sim\snmp-sim.ts 1162  # SNMP :1162 (scenario distribuzione)
```

---

## 10. Build di produzione (e la sua verifica)

Il progetto produce un build **standalone** di Next 16. Su Windows i due
comandi sono già cross-platform (v16.18.1: niente più `cp -r` Unix):

```powershell
cd C:\FALCO-OS
bun run build    # 1) next build  2) scripts/postbuild.mjs (copia static+public in standalone)
bun run start    # avvia .next/standalone/server.js su :3000 (log su server.log)
```

Note operative:

- **il build «cucisce» dentro le variabili NEXT_PUBLIC_***: prima di
  produrre, sistemare `NEXTAUTH_URL` e `NEXT_PUBLIC_REALTIME_URL`
  all'indirizzo definitivo (es. `http://192.168.1.50:3000` e
  `http://192.168.1.50:3001`), altrimenti il canale live punterà a
  localhost e gli altri PC non vedranno l'app viva;
- in produzione il realtime e il discovery restano processi separati da
  avviare come in sviluppo (`bun run dev` nelle loro cartelle, o vedi
  «avvio automatico» sotto);
- memoria del build: ~2 GB liberi; su PC con 4 GB chiudere le altre app;
- il build NON tocca il DB: `.env` e `db\custom.db` restano invariati.

**Risultato della verifica build del 31/10/2026** (ambiente di sviluppo
del progetto): typecheck TypeScript **0 errori** (`tsc --noEmit` su tutto
il progetto, mini-services inclusi), ESLint **0 errori / 1 warning noto**
(TanStack Table + React Compiler, benigno e documentato), pagina `/` a
200 con login funzionante, canale live attivo (`replay: true`), tre
servizi in salute, dialog di attivazione SNMP operativa end-to-end.

### Avvio automatico dopo il riavvio (opzionale)

Windows non ha il watchdog bash della sandbox. Opzioni oneste:

- **manuale**: doppio clic su `scripts\windows\avvia-falco.cmd` (per lo
  sviluppo) — la via semplice;
- **servizio vero**: [NSSM](https://nssm.cc) (`nssm install FalcoNOC "C:\Program Files\bun\bun.exe" "C:\FALCO-OS\.next\standalone\server.js"` con variabili d'ambiente da impostare in NSSM) oppure Utilità di pianificazione con azione all'avvio;
- tenere presente che un servizio Windows gira con altri permessi/path:
  impostare in NSSM `NODE_ENV=production`, `PORT=3000` e le variabili del
  `.env`.

---

## 11. Compatibilità nota — cosa funziona e come (limiti dichiarati)

| Argomento | Stato su Windows | Dettaglio |
|---|---|---|
| Bun / Next 16 / React 19 | ✅ pieno | stack ufficiale multipiattaforma |
| Prisma + SQLite | ✅ pieno | file DB con path `/` nel `DATABASE_URL` |
| sonde SNMP (net-snmp) | ✅ pieno | libreria JS pura, dgram di sistema |
| attivazione SSH (ssh2) | ✅ pieno | JS puro; avviso opzionale `cpu-features` ignorabile |
| «ping» / spazzata presence | ✅ pieno | TCP-connect su porte note: **nessun ICMP raw, nessun amministratore** |
| SwOS digest MD5 | ✅ pieno | HTTP standard |
| canale live socket.io | ✅ con `NEXT_PUBLIC_REALTIME_URL` | diretto :3001, CORS permissivo di fabbrica |
| gateway Caddy sandbox | ➖ **non serve** | su Windows il browser parla solo con :3000; il NOC fa da ponte verso :3002 |
| `watchdog.sh`, script `.sh` | ➖ non applicabili | nati per la sandbox; equivalenti: le finestre aperte, `ferma-falco.cmd`, NSSM (§10) |
| test shell (`tests/*.sh`, `verify-api.sh`) | ➖ Git Bash | eseguibili solo con Git Bash/WSL, non toccano il prodotto |
| simulatori demo | ✅ pieno | porte 2222/8080/1161/1162, tutte non privilegiate |
| firewall | ⚠ una volta | «Consenti accesso» al primo avvio (reti private) |

### Cosa è stato sistemato nella v16.18.1 (31/10/2026)

Verifica di compatibilità Windows completata con questi interventi:

1. **`package.json`**: `build` e `start` ora usano `scripts/postbuild.mjs`
   e `scripts/start-standalone.mjs` (Node/Bun `fs.cpSync` + spawn portabili)
   al posto di `cp -r` e `NODE_ENV=…` Unix, che cmd.exe non esegue. Aggiunto
   `dev:win` (dev senza tee Linux);
2. **realtime-service**: `state.json` e `DATABASE_URL` non sono più path
   assoluti della sandbox ma derivati dalla posizione del servizio —
   identici su Linux, corretti su Windows;
3. **`src/lib/v2/derive.ts`**: il percorso dell'heartbeat realtime è
   risolto dalla root del progetto (o da `REALTIME_STATE_PATH` se serve);
4. **`src/lib/client/socket.ts`**: `NEXT_PUBLIC_REALTIME_URL` opzionale —
   senza gateway il browser si collega direttamente al :3001; senza la
   variabile il comportamento sandbox resta identico;
5. **`scripts/prepare-real-db.ts`**: path del DB e cartella di lavoro
   derivati dalla posizione dello script (più `REALTIME_STATE_PATH` per
   derive);
6. **nuovi file**: `.env.example` commentato in italiano,
   `scripts\windows\avvia-falco.cmd`, `scripts\windows\ferma-falco.cmd`.

Tutto il resto era già portabile (verificato con analisi completa: nessun
comando nativo nel percorso utente; i `/tmp/system.cfg` che compaiono nelle
ricette SNMP sono comandi **remoti** sugli apparati, mai eseguiti sul PC).

---

## 12. Risoluzione problemi (sintomo → causa → rimedio)

| Sintomo | Causa probabile | Rimedio |
|---|---|---|
| «bun non è riconosciuto» | PATH non ricaricato | chiudere/riaprire PowerShell; verificare `bun --version` |
| pagina bianca o «impossibile raggiungere il sito» su :3000 | NOC non avviato o prima compilazione in corso | guardare la finestra NOC (attesa 30-60 s); poi `curl.exe http://localhost:3000` |
| «La porta 3000 è già in uso» | altro servizio (o un vecchio NOC) | `netstat -aon | findstr :3000` → `taskkill /PID <pid> /F`; oppure `scripts\windows\ferma-falco.cmd` |
| «Servizio discovery non raggiungibile (porta 3002)» | finestra discovery spenta | riavviare `bun run dev` in `mini-services\discovery-service` |
| numeri «fermi», badge realtime assente / static | `NEXT_PUBLIC_REALTIME_URL` assente o realtime spento | decommentare la variabile nel `.env`, riavviare NOC e realtime; `curl.exe http://localhost:3001/health` |
| login rifiutato | DB non predisposto o segreti assenti | `bun run db:push`; ricontrollare `.env` (`NEXTAUTH_SECRET` presente e non uguale all'esempio) |
| errore Prisma `P1001` / «Cannot open database» | `DATABASE_URL` con `\` o percorso sbagliato | usare `/`: `file:C:/FALCO-OS/db/custom.db` o il relativo `file:../db/custom.db` |
| credenziali apparato «non decifrabili» dopo un cambio | `DEVICE_CREDENTIALS_KEY` cambiata | comportamento dichiarato: reinserire le credenziali nei dispositivi |
| `bun install` si lamenta di `cpu-features` | binding nativo opzionale di ssh2 | ignorare: ssh2 lavora in JS puro |
| build interrotto / esaurita memoria | RAM insufficiente | chiudere le app; servono ~2 GB liberi; ripetere `bun run build` |
| comportamenti strani dopo lo spostamento della cartella | path con spazi/accenti | spostare in `C:\FALCO-OS`; rifare `bun install` |
| antivirus lento sulle scansioni | ispeziona i socket del discovery | aggiungere esclusione per la cartella di FALCO-OS (facoltativo) |

---

## 13. Aggiornare a una nuova release

1. fermare i tre processi (`ferma-falco.cmd`);
2. scompattare la nuova release in una cartella **nuova** (mai sopra la vecchia);
3. copiare dalla vecchia: `.env` e `db\custom.db` (i propri dati);
4. `bun install` (root e discovery-service) + `bun run db:push`
   (le migrazioni sono additive: mai perdita di dati — se uno script di
   preparazione serve, la release lo dichiara, vedi 7b);
5. riavviare con `avvia-falco.cmd`.

---

*Guide correlate: `docs\ROADMAP_CHANGELOG_RUNBOOK.md` (runbook sandbox e
changalog), `db\LEGGO.md` (gestione DB reale), `release\README-v16.18.md`
(funzione W19 attivazione SNMP assistita).*

— FALCO-OS v16.18.1-w19.1 · 31/10/2026
