# FALCO-OS v16.20.0-w22.0 — AUTO-RESUME ENTERPRISE DEL MOTORE DI MONITORAGGIO

> «puller senza auto-resume al riavvio server risolvi, se si riavvia il
> server non funziona più il monitoraggio? Rendiamo logica funzionale e
> software a Enterprise» — operatore, 01/11/2026

## La risposta: il monitoraggio che sopravvive ai riavvii del server

Il limite dichiarato della v16.19 («il motore vive nel processo: al
riavvio si ferma e non riparte») **non esiste più**. Non un workaround:
logica enterprise completa.

| Pezzo | Cosa fa |
|---|---|
| **Tabella `EngineRuntime`** (NUOVA) | La configurazione del motore vive nel DB: `enabled`, `intervalSec`, `radioEveryNCycles`, `startedVia`, heartbeat per ciclo, contatori di sessione, `totalCycles` **storico** (mai perso attraverso i riavvii) |
| **`src/instrumentation.ts`** (NUOVO) | Hook nativo Next.js eseguito a ogni avvio del processo: dopo `FALCO_ENGINE_RESUME_DELAY_MS` (default 8 s) **riattiva da sola** ogni motore con `enabled=true`, con gli stessi parametri |
| **Arresto volontario rispettato** | Un motore fermato da un operatore (`enabled=false`) **non viene resuscitato** al riavvio — mai sorprese |
| **Audit** | Ogni ripresa è registrata: azione `ENGINE_AUTO_RESUME`, attore `system:auto-resume` — mai silenziosa |
| **Heartbeat persistito** | Ogni ciclo aggiorna `lastHeartbeatAt` + contatori su DB: il NOC vede «il motore è vivo» anche leggendo il database |
| **Guardie enterprise** | Anti-duplicazione per processo (globalThis), best-effort ovunque (il boot del server NON fallisce mai per l'auto-resume), ritardo configurabile in `.env` |

## Cosa vedi nella UI

- **Fase Telemetria**: badge **«avvio: WIZARD / AUTO-RESUME (riavvio
  server)»** + **«auto-resume persistito»**; se la sessione non è attiva
  ma la configurazione è armata: «auto-resume armato · tick Xs» con
  cicli storici e ultimo heartbeat;
- **Fase Riepilogo**: verdetto «attivo **(riattivato dall'auto-resume
  dopo il riavvio del server)**» e note di onestà che spiegano la
  semantica; `GET /api/v2/setup/engine` espone anche le righe
  `runtimes` persistite.

## Verifica di questo rilascio (crash-riavvii CRUDELI, dal vivo)

1. **Test positivo**: motore avviato via API (WIZARD, 2 cicli con
   heartbeat su DB) → **kill del dev server** → riavvio → log
   «[falco auto-resume] motore RIATTIVATO per 1 impianto: Setup Demo
   Verona» → stato `running` con **`startedVia: AUTO_RESUME`**, cicli
   che ripartono, **`totalCycles` preservato attraverso il riavvio**,
   audit presente;
2. **Test negativo (arresto volontario)**: stop da API → riavvio del
   server → «nessun motore da riattivare» — il fermo umano è rispettato;
3. **Test dalla UI**: avvio dalla fase Telemetria → kill del server →
   riavvio → **badge «avvio: AUTO-RESUME (riavvio server)»** nel
   browser, motore che raccoglie in autonomia (26 campioni), fase 7 con
   verdetto auto-resume — screenshot desktop + mobile in
   `release/evidence/w22/` verificati col VLM;
- 4 screenshot in `release/evidence/w22/` · `tsc --noEmit` **0 errori**
  · ESLint **0 errori / 1 warning noto** · mobile 390 senza overflow
  (fix badge lunghi trovato in questa stessa verifica) · zero errori
  console.

## Schema DB

**+1 tabella** (`EngineRuntime`), nessuna modifica alle esistenti:
`bun run db:push` dopo l'aggiornamento (nessuna perdita di dati).

## Come provarlo dal Preview

1. Login (`admin@falco-os.local` / `FalcoDemo2026!`) → «Setup Demo
   Verona» → «Setup impianto» → fase 5 Telemetria;
2. «Avvia motore» → badge «auto-resume persistito»;
3. Il DB in consegna ha `EngineRuntime.enabled=true` su Setup Demo
   Verona: **al primo avvio dell'app il motore si riattiva da solo** —
   oppure riavvia il server quando vuoi e guarda il badge
   «avvio: AUTO-RESUME (riavvio server)»;
4. «Arresta» → riavvia il server → il motore resta fermo (scelta umana
   rispettata).

## Limiti dichiarati (onestà di sempre)

- `PORT_STATE_CHANGE` e `NEW_DEVICE_SEEN` restano on-demand: la loro
  valutazione continua richiede sonde L2 / scansioni periodiche
  (candidati naturali per una prossima onda: sonde L2 schedulate).
- Il motore gira **nel processo web** (single-instance): per
  multi-istanza/scale-out il master plan v15.6 prevede già il
  collection-queue con claim a lease — dichiarato, non nascosto.
- `src/instrumentation.ts` richiede Next.js 15+ (hook `register()`):
  soddisfatta dalla v16 di questo progetto.

## DB reale

NESSUNA modifica alle tabelle esistenti: quando arriva il DB reale
(~292 MB) `bun scripts/prepare-real-db.ts --yes` resta valido; la
tabella `EngineRuntime` nasce vuota e si popola al primo «Avvia motore»
(vedi `db/LEGGO.md`).
