# FALCO-OS v16.18.0-w19.0 — ATTIVAZIONE SNMP ASSISTITA

> «Una volta identificato il prodotto e modello esatto provare dopo conferma
> attivazione SNMP — antenne via SSH (impostare snmp enable e i 2 campi su
> public, perché Ubiquiti ha bisogno che devono essere scritti), telecamere
> solo ping online/offline, switch RB260GSP MikroTik via SwOS di monitorare
> scrivere e abilitare, stessa cosa con gli altri vendor… se qualche
> apparato non riesci ad avere i valori fammelo notare nella UI in modo che
> lo faccio in modo manuale.» — operatore, 31/10/2026

## L'architettura della risposta

FALCO-OS non «attiva l'SNMP di nascosto»: la **sonda resta in sola lettura**
come da regola costituzionale v16 (mai un SET SNMP). L'attivazione è un
**ATTUATORE SEPARATO** che parte solo dalla conferma esplicita
dell'operatore:

1. **PREVIEW** — la finestra mostra PRIMA i comandi IN CHIARO che verranno
   eseguiti sull'apparato, con fonte e confidenza della ricetta;
2. **CONFERMA** — l'operatore preme «Esegui attivazione»;
3. **ESECUZIONE** — SSH (o API HTTP SwOS) applicano i comandi del vendor;
4. **VERIFICA** — la sonda SNMP (la stessa delle scansioni) prova l'agente:
   ENABLED solo se risponde DAVVERO, altrimenti ENABLED_UNVERIFIED con
   «Riverifica ora» (l'agente può impiegare secondi a partire);
5. **PERSISTENZA** — stato/metodo/esito sul dispositivo + community di
   lettura salvata **CIFRATA** (AES-256-GCM) + audit con la sola sintesi
   (mai password, mai community in chiaro nel registro).

## Le ricette (19, fonti citate per ognuna)

| Trasporto | Vendor |
|---|---|
| **SSH** | MikroTik RouterOS · **Ubiquiti airOS/airMAX** (community+contact+location scritti ESPLICITAMENTE — «i 2 campi» — cfgmtd + rc.softrestart, ricetta verificata su due fonti) · Ubiquiti EdgeOS · Cisco IOS · Aruba AOS-CX · Aruba ProCurve/AOS-S · Huawei VRP · Fortinet FortiOS · Juniper Junos · TP-Link JetStream · Ruckus ICX · Dell PowerConnect |
| **API HTTP SwOS** (digest MD5 RFC 2617) | **MikroTik SwOS — RB260GSP e fratelli**: nessun SSH esiste su SwOS; campi `en/com/ci/loc` (dialetto SwOS Lite `i01-i04` rilevato in automatico), read-back di conferma |
| **Manuale** (istruzioni mostrate, MAI eseguite) | Hikvision · Dahua · PLANET · UniFi (controller) · Cambium ePMP · EdgeSwitch · generico |
| **Ping-only** (nessun contatto) | Telecamere: `monitorMode='ping'` + spazzata presenza ICMP |

La confidenza è dichiarata per ognuna: **verified** (fonte primaria/codice
reale), **high** (documentazione ufficiale notoria), **medium** (sintassi da
confermare sul modello preciso) — l'operatore la vede prima di confermare.

## Telecamere: solo online/offline

La ricetta `camera-ping-only` non tocca la telecamera: la dichiara in
modalità ping. La **spazzata ping** (`POST /api/v2/monitoring/ping`, sonda
`/probe/ping` del mini-service) misura presenza e latenza, scrive i campioni
reali `pingLatency`/`packetLoss` (la storia online/offline vive dove vive già
la disponibilità: Report → disponibilità, scheda → storico) e aggiorna lo
stato con onestà. Si lancia da un pulsante per dispositivo, dalla scheda
apparato, o su tutte le telecamere in modalità ping dalla vista Dispositivi.

## «Non riesco ad avere i valori» → si VEDE

Chi non può dare valori SNMP è marcato in UI: chip **«SNMP manuale»**
(MANUAL_REQUIRED) e **«SNMP KO»** (FAILED) nell'elenco dispositivi, chip
**«ping»** per le telecamere in modalità presenza, scheda apparato con
stato/metodo/ultimo esito leggibile. Le istruzioni manuali del vendor sono
sempre a un click (dialog → «Istruzioni manuali»).

## Come provarla dal Preview

Il DB demo contiene 5 apparati che puntano ai simulatori:

| Apparato | Percorso |
|---|---|
| `SW-ROUTEROS-DEMO` (MikroTik CRS317) | dialog con credenziali cifrate salvate → «Esegui attivazione» → ENABLED con esito benigno |
| `SW-SWOS-DEMO` (MikroTik **RB260GSP**, SwOS) | ricetta API SwOS: utente `admin`, password VUOTA → 3 passi con read-back |
| `ANT-AIRMAX-DEMO` (Ubiquiti NanoBeam) | ricetta airOS 8 passi (backup → cfgmtd → softrestart) con credenziali salvate |
| `NVR-HIKVISION-DEMO` | percorso MANUALE: istruzioni mostrate, stato «SNMP manuale» |
| `DEMO-CAM-PING` | telecamera già in modalità ping: «Spazzata ping» → ONLINE con campioni reali |

Dispositivi → riga → scheda → tab **Configurazione** → «Attiva SNMP
assistita…». (Login demo: `admin@falco-os.local` / `FalcoDemo2026!`.)

## DB reale

Nessuna tabella toccata: colonne additive su `Device`
(`snmpEnableState/Method/Note/At` + `monitorMode`). Quando arriva il DB
reale (~292 MB): `bun scripts/prepare-real-db.ts --yes` (backup automatico +
integrity + push additivo + conteggi di sanità — vedi `db/LEGGO.md`).

## Verifica (la disciplina di sempre)

- Simulatori dedicati: SSH :2222 (dialetti RouterOS/airOS), SwOS :8080
  (digest), SNMP :1161/:1162 — le tre ricette eseguite per intero contro di
  essi PRIMA dell'interfaccia;
- API e2e login reale: plan (pick corretti CRS317→routeros, RB260GSP→swos,
  NBE-5AC-Gen2→airos) · execute con credenziali cifrate salvate → ENABLED ·
  SwOS read-back · camera → monitorMode=ping · Hikvision → MANUAL_REQUIRED ·
  ping sweep → campioni + UNKNOWN→ONLINE · verify → ENABLED;
- audit via Prisma: sintesi senza segreti;
- browser e2e desktop 1440 + mobile 390: dialog completo su SwOS (3/3) e
  airMAX (8/8), dichiarazione ping, spazzate, chip nelle liste, dialog
  mobile scorribile, NESSUN overflow, zero errori console;
- tsc 0 · lint 0 (1 warning noto TanStack Table).

## File del rilascio

- `mini-services/discovery-service/lib/snmp-recipes.ts` — catalogo ricette
- `mini-services/discovery-service/lib/snmp-enable.ts` — attuatore
  (SSH ssh2 / SwOS digest / verifica sonda)
- `mini-services/discovery-service/sim/ssh-sim.ts`, `sim/swos-sim.ts` —
  simulatori di verifica
- API: `/api/v2/discovery/snmp-enable[/plan|/verify]`,
  `/api/v2/monitoring/ping`, `/probe/ping` (servizio :3002)
- UI: `src/components/snmp-enable-dialog.tsx` + scheda apparato + chip

— FALCO-OS v16.18.0-w19.0 · 31/10/2026
