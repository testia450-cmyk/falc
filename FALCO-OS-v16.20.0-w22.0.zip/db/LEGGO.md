# Posizionare qui il custom.db (schema Prisma 123 modelli, vedi README.md)
#
# Il DB reale dell'impianto (~292 MB) NON è incluso in questo pacchetto:
# resta di proprietà dell'operatore. Copiare il file in questa cartella
# con il nome `custom.db` prima di avviare l'applicazione:
#
#   cp /percorso/del/vostro/custom.db db/custom.db
#
# ⚠️ v16.15 (onde W13-W16): DOPO aver copiato il DB reale eseguire la
# preparazione additiva (crea SOLO le due tabelle nuove StpObservation e
# VlanInventory — nessuna tabella esistente viene toccata; backup
# automatico + integrity check + conteggi di sanità):
#
#   bun scripts/prepare-real-db.ts --yes
#
# (senza --yes lo script stampa il piano e non scrive nulla)
#
# Il file è referenziato da DATABASE_URL nel .env (vedi .env.example):
#   DATABASE_URL="file:/percorso/assoluto/di/db/custom.db"
#
# Nota: il servizio realtime (mini-services/realtime-service) richiede
# la STESSA DATABASE_URL assoluta al suo avvio.
#
# ---
# NOTE SUL DB PLACEHOLDER ATTUALE (fino al caricamento di quello reale):
# il custom.db in consegna contiene l'impianto di verifica «test-l2»
# (10 apparati che puntano ai due simulatori SNMP su 127.0.0.1:1161 e
# :1162 — avviarli con `bun sim/snmp-sim.ts 1161 centrale` e
# `bun sim/snmp-sim.ts 1162 distribuzione` da
# mini-services/discovery-service) e l'utente admin demo documentato
# (admin@falco-os.local / FalcoDemo2026!, decisione D1): serve a provare
# SUBITO la ricostruzione L2 e la correlazione multi-switch dal Preview.
# Sostituendo il file con il DB reale l'impianto di test sparisce da sé.
